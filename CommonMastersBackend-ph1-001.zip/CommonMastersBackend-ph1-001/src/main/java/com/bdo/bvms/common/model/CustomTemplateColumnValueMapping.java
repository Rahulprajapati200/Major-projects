package com.bdo.bvms.common.model;

import java.util.Date;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class CustomTemplateColumnValueMapping {

	Integer id;
	Integer customTemplateMappingId;
	Integer optionId;
	@EqualsAndHashCode.Include
	String values;
	Integer entityId;
	Date createdAt;
	Integer createdBy;
	Date modifiedAt;
	Integer modifiedBy;
	
}
