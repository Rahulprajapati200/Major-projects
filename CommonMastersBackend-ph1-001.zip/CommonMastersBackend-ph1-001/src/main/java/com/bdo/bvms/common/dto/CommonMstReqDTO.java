package com.bdo.bvms.common.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CommonMstReqDTO extends BaseReqDTO {

	private static final long serialVersionUID = 1L;
	
	private int pageCount;
	
	private String financialYear;
	
	private int defPageRecords;
	
	private String searchValues;
	

}
