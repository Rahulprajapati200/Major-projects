package com.bdo.bvms.common.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.config.AzureClientProvider;
import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.CommonMasterDao;
import com.bdo.bvms.common.dto.AddWorkflowCommunicationReqDTO;
import com.bdo.bvms.common.dto.AdvanceSearchReqDto;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.DownloadFileDTO;
import com.bdo.bvms.common.dto.DownloadFileInfo;
import com.bdo.bvms.common.dto.ErrorCodeDescriptionResponseDTO;
import com.bdo.bvms.common.dto.ErrorMessageListDto;
import com.bdo.bvms.common.dto.ExceptionLogDTO;
import com.bdo.bvms.common.dto.FieldNameResponseDto;
import com.bdo.bvms.common.dto.FinancialPeriodMonthResDTO;
import com.bdo.bvms.common.dto.FinancialYearReqDTO;
import com.bdo.bvms.common.dto.FinancialYearResDTO;
import com.bdo.bvms.common.dto.GetCustomizedColumnListReqDTO;
import com.bdo.bvms.common.dto.GetCustomizedColumnListResDTO;
import com.bdo.bvms.common.dto.GetDefaultUploadTemplateReqDTO;
import com.bdo.bvms.common.dto.GetDefaultUploadTemplateResDTO;
import com.bdo.bvms.common.dto.GetFpByYearIdReqDTO;
import com.bdo.bvms.common.dto.GetFpByYearIdResDTO;
import com.bdo.bvms.common.dto.PaginationResDTO;
import com.bdo.bvms.common.dto.PaginationSearchResponseDTO;
import com.bdo.bvms.common.dto.PickupDetailListResDTO;
import com.bdo.bvms.common.dto.PickupListDetailReqDTO;
import com.bdo.bvms.common.dto.PreviewInvoiceUploadDTO;
import com.bdo.bvms.common.dto.SaveCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.SearchByLkupcodeReqDTO;
import com.bdo.bvms.common.dto.SearchPLDByPickKey;
import com.bdo.bvms.common.dto.SearchWorkflowCommunicationReqDTO;
import com.bdo.bvms.common.dto.TaxpayerMultilevelDetailsDTO;
import com.bdo.bvms.common.dto.TaxpayerVendor;
import com.bdo.bvms.common.dto.WorkflowCommunication;
import com.bdo.bvms.common.dto.WorkflowCommunicationResDTO;
import com.bdo.bvms.common.exception.apierror.CustomValidationError;
import com.bdo.bvms.common.exceptions.BVMSException;
import com.bdo.bvms.common.exceptions.CommonMasterBusinessException;
import com.bdo.bvms.common.exceptions.CustomValidationViolationException;
import com.bdo.bvms.common.exceptions.ResourceNotFoundException;
import com.bdo.bvms.common.model.EntityCloudCredentials;
import com.bdo.bvms.common.model.PickupListDetail;
import com.bdo.bvms.common.reports.constants.ReportsConstants;
import com.bdo.bvms.common.repository.IEntityCloudCredentialsRepository;
import com.bdo.bvms.common.repository.impl.PickupMasterRepositoryImpl;
import com.bdo.bvms.common.service.CommonMasterService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service

public class CommonMasterServiceImpl implements CommonMasterService {

    @Autowired
    CommonMasterDao commonMasterDao;

    @Autowired
    public AzureClientProvider client;

    @Autowired
    private PickupMasterRepositoryImpl pickupMasterRepositoryImpl;

    @Autowired
    IEntityCloudCredentialsRepository iEntityCloudCredentialsRepository;

    @Override
    public PaginationSearchResponseDTO getFpMonths(FinancialYearReqDTO financialYearReqDTO) throws BVMSException {

        Pageable paging = PageRequest.of(financialYearReqDTO.getPage(), financialYearReqDTO.getSize());
        Page<FinancialPeriodMonthResDTO> pagedResult = null;
        try {
            pagedResult = commonMasterDao.getFpMonths(paging, financialYearReqDTO.getSearchFilterValues());

            return PaginationSearchResponseDTO.builder().curPage(pagedResult.getNumber() + 1)
                            .totalPages(pagedResult.getTotalPages()).totalRecords(pagedResult.getTotalElements())
                            .data(pagedResult.getContent()).build();
        } catch (Exception ex) {

            log.info("Exception in getFpYear Method ", ex);
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();

            String methodName1 = "getFpMonths";

            exceptionLogDTO.setScreenName(Constants.VENDOR_MASTER);
            exceptionLogDTO.setFunctionName(methodName1);
            exceptionLogDTO.setErrorMessage(ex.getMessage());
            exceptionLogDTO.setErrorCause("Some error in getting data from database.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // add exception into exception log table if an exception is
            // coming.
            commonMasterDao.updateExceptionLogTable(exceptionLogDTO);
            throw new BVMSException(ex.getMessage(), ex.getCause());
        }

    }

    @Override
    public PaginationSearchResponseDTO getFpYear(FinancialYearReqDTO financialYearReqDTO) throws BVMSException {

        Pageable paging = PageRequest.of(financialYearReqDTO.getPage(), financialYearReqDTO.getSize());
        String financialYearId = financialYearReqDTO.getFinancialYear();
        Page<FinancialYearResDTO> pagedResult = null;
        try {
            pagedResult = commonMasterDao.getFpYear(paging, financialYearId,
                            financialYearReqDTO.getSearchFilterValues());

            return PaginationSearchResponseDTO.builder().curPage(pagedResult.getNumber() + 1)
                            .totalPages(pagedResult.getTotalPages()).totalRecords(pagedResult.getTotalElements())
                            .data(pagedResult.getContent()).build();
        } catch (Exception ex) {

            log.info("Exception in getFpYear Method ", ex);
            throw new BVMSException(ex.getMessage(), ex.getCause());
        }

    }

    @Override
    public ByteArrayInputStream downloadFileByteStream(DownloadFileDTO downloadFileBytestreamDto,
                    AzureConnectionCredentialsDTO azureConnectionCredentialsDTO) throws BVMSException {

        String fileName = commonMasterDao.getFilename(downloadFileBytestreamDto);

        if (fileName == null) {
            throw new BVMSException();
        }
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            client.getClient(azureConnectionCredentialsDTO).blobName(fileName).buildClient().downloadStream(out);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (Exception ex) {
            throw new BVMSException(Constants.FILENOTFOUNTONBLOB, ex.getCause());
        }
    }

    @Override
    public String getFileType(DownloadFileDTO downloadFileBytestreamDto) {
        return commonMasterDao.getFileType(downloadFileBytestreamDto);

    }

    @Override
    public List<PickupDetailListResDTO> searchPickupListDetail(SearchByLkupcodeReqDTO searchByLkupcode) {
        List<PickupListDetail> pickupListDetailList = null;
        pickupListDetailList = pickupMasterRepositoryImpl.searchPickupMaster(searchByLkupcode.getLkupcode());
        return pickupListDetailList.stream().map(pickupListDetail -> {
            return PickupDetailListResDTO.builder().name(pickupListDetail.getName()).code(pickupListDetail.getCode())
                            .shortDesc(pickupListDetail.getShortDesc()).id(pickupListDetail.getId())
                            .uploadedBy(pickupListDetail.getUserName()).uploadedOn(pickupListDetail.getCreatedAt())
                            .build();
        }).collect(Collectors.toList());
    }

    @Override
    public PickupDetailListResDTO searchPickupListDetailByNameAndCode(PickupListDetailReqDTO pickupListDetailReqDTO) {
        PickupListDetail pickupListDetail = pickupMasterRepositoryImpl.searchPickupDetailByNameAndCode(
                        PickupListDetail.builder().code(pickupListDetailReqDTO.getCode())
                                        .name(pickupListDetailReqDTO.getName()).build());
        return PickupDetailListResDTO.builder().name(pickupListDetail.getName()).code(pickupListDetail.getCode())
                        .shortDesc(pickupListDetail.getShortDesc()).id(pickupListDetail.getId())
                        .uploadedBy(pickupListDetail.getUserName()).uploadedOn(pickupListDetail.getCreatedAt()).build();

    }

    @Override
    public AzureConnectionCredentialsDTO getAzureCredentialFromDB(String entityId, String type) {
        return commonMasterDao.getAzureCredentialFromDB(entityId, type);
    }

    @Override
    public List<GetDefaultUploadTemplateResDTO> getDefaultUploadTemplate(
                    GetDefaultUploadTemplateReqDTO getDefaultUploadTemplateReqDTO) {
        return commonMasterDao.getPldDetailsByMstIdNKey(getDefaultUploadTemplateReqDTO);
    }

    @Override
    public String getFileName(DownloadFileDTO downloadFileBytestreamDto) throws BVMSException {
        String moduleName = commonMasterDao.getModuleName(downloadFileBytestreamDto);
        return moduleName + Constants.UNDERSCORE + System.currentTimeMillis()
                        + commonMasterDao.getFilename(downloadFileBytestreamDto);
    }

    @Override
    public Map<String, String> searchBvmsErrorMappings() {
        return commonMasterDao.searchBvmsErrorMappings();
    }

    @Override
    public DownloadFileInfo getFileInfo(PreviewInvoiceUploadDTO previewInvoiceUploadDTO) {

        DownloadFileInfo fileInfo = commonMasterDao.getFileInfo(previewInvoiceUploadDTO);
        EntityCloudCredentials storageCredentials = iEntityCloudCredentialsRepository
                        .searchEntityCloudCredentials(Integer.parseInt(previewInvoiceUploadDTO.getEntityId()));
        fileInfo.setFileUrl(storageCredentials.getUrl());
        fileInfo.setContainerName(storageCredentials.getContainerName());
        String fileUrl = commonMasterDao.getFileUrl();
        fileInfo.setFileUrl(new StringBuilder(fileUrl).append("/").append(fileInfo.getContainerName()).toString());
        fileInfo.setContainerName("");

        return fileInfo;
    }

    @Override
    public List<GetFpByYearIdResDTO> getFpByYearId(GetFpByYearIdReqDTO getFpByYearIdReqDTO) {
        return commonMasterDao.getFpListByYearId(getFpByYearIdReqDTO);

    }

    @Override
    public List<GetCustomizedColumnListResDTO> getCustomizedColumnListFromService(
                    GetCustomizedColumnListReqDTO getCustomizedColumnListReqDTO) {

        return commonMasterDao.getCustomizedColumnListFromRepo(getCustomizedColumnListReqDTO);
    }

    @Override
    public void getSavedCustomizedColumnListFromService(SaveCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO) {
        if (saveCustomizeColumnListReqDTO.getSaveOrDefault() == Constants.DEFAULT) {

            commonMasterDao.deleteThePreviousRecord(saveCustomizeColumnListReqDTO);
        } else if (saveCustomizeColumnListReqDTO.getSaveOrDefault() == Constants.SAVE) {
            commonMasterDao.deleteThePreviousRecord(saveCustomizeColumnListReqDTO);
            commonMasterDao.enterTheNewRecord(saveCustomizeColumnListReqDTO);
        }

    }

    @Override
    public List<PickupDetailListResDTO> searchPickupListDetailByPickKey(SearchPLDByPickKey searchPLDByPickKey) {
        List<PickupListDetail> pickupListDetailList = pickupMasterRepositoryImpl.searchPickupMasterByNamePickKey(
                        PickupListDetail.builder().pickupMasterName(searchPLDByPickKey.getLkupCode())
                                        .pickKey(searchPLDByPickKey.getPickKey().toString()).build());
        return pickupListDetailList.stream()
                        .map(pickupListDetail -> PickupDetailListResDTO.builder().name(pickupListDetail.getName())
                                        .code(pickupListDetail.getCode()).id(pickupListDetail.getId())
                                        .uploadedOn(pickupListDetail.getCreatedAt()).build())
                        .collect(Collectors.toList());
    }

    @Override
    public void addWorkflowCommunication(AddWorkflowCommunicationReqDTO addWorkflowCommunicationReqDTO)
                    throws BVMSException {

        TaxpayerVendor taxpayerVendorByTaxpayer = null;
        try {

            taxpayerVendorByTaxpayer = commonMasterDao.checkIfTaxpayerVendorExists(
                            TaxpayerVendor.builder().gstinTaxpayer(addWorkflowCommunicationReqDTO.getTaxpayerGstin())
                                            .gstinVendor(addWorkflowCommunicationReqDTO.getVendorGstin())
                                            .pldDataVersion(Constants.PLD_DATA_VERSION_TAXPAYER).build());
        } catch (EmptyResultDataAccessException e) {
            throw new ResourceNotFoundException(TaxpayerVendor.class, Constants.TAXPAYER_GSTIN,
                            addWorkflowCommunicationReqDTO.getTaxpayerGstin(), Constants.VENDOR_GSTIN,
                            addWorkflowCommunicationReqDTO.getVendorGstin());
        }

//        TaxpayerVendor taxpayerVendorByVendor = new TaxpayerVendor();
//        if (addWorkflowCommunicationReqDTO.getIsVendor() == 1) {
//            try {
//                taxpayerVendorByVendor = commonMasterDao.checkIfTaxpayerVendorExists(TaxpayerVendor.builder()
//                                .gstinTaxpayer(addWorkflowCommunicationReqDTO.getTaxpayerGstin())
//                                .gstinVendor(addWorkflowCommunicationReqDTO.getVendorGstin())
//                                .pldDataVersion(Constants.PLD_DATA_VERSION_VENDOR).build());
//            } catch (EmptyResultDataAccessException e) {
//                throw new ResourceNotFoundException(TaxpayerVendor.class, Constants.TAXPAYER_GSTIN,
//                                addWorkflowCommunicationReqDTO.getTaxpayerGstin(), Constants.VENDOR_GSTIN,
//                                addWorkflowCommunicationReqDTO.getVendorGstin());
//            }
//        }

        List<CustomValidationError> customValidationErrorList = new ArrayList<>();

        if (addWorkflowCommunicationReqDTO.getIsNewCommunication()
                        .equals(Constants.WORKFLOW_COMMUNICATION_IS_NEW_COMMUNICATION_YES)) {
            validateNewCommunication(addWorkflowCommunicationReqDTO, customValidationErrorList);
        } else {
            validateReplyToCommunication(addWorkflowCommunicationReqDTO, customValidationErrorList);
        }

        if (!customValidationErrorList.isEmpty()) {
            throw new CustomValidationViolationException(customValidationErrorList);
        }

        String email = "";

        String taxpayerEmailId = null;
        WorkflowCommunication workflowCommunication;

//        if (addWorkflowCommunicationReqDTO.getIsVendor().equals(Constants.WORKFLOW_COMMUNICATION_IS_VENDOR_NO)) {
//            List<TaxpayerVendorContactMapping> taxpayerVendorContactMappingList = commonMasterDao
//                            .getTaxpayerVendorPrimaryContacts(TaxpayerVendorContactMapping.builder()
//                                            .tvcrId(taxpayerVendorByVendor.getChildRelationId())
//                                            .isPrimaryContact(Constants.CONTACT_MAPPING_IS_PRIMARY_CONTACT_YES)
//                                            .build());
//
//            postToEmails = StringUtil.join(taxpayerVendorContactMappingList.stream()
//                            .map(taxpayerVendorContactMapping -> taxpayerVendorContactMapping.getEmail())
//                            .collect(Collectors.toList()));
//        }

        if (addWorkflowCommunicationReqDTO.getIsVendor() == 0) {

            email = commonMasterDao.getEmailIdOfVendor(taxpayerVendorByTaxpayer.getChildRelationId());
            if (StringUtils.isBlank(email)) {

            }
            taxpayerEmailId = commonMasterDao.getTaxpayerLoginId(addWorkflowCommunicationReqDTO.getUserId());
            if (StringUtils.isBlank(taxpayerEmailId)) {
                throw new CommonMasterBusinessException("Taxpayer contact doesn't exist.");
            }
            workflowCommunication = WorkflowCommunication.builder().body(addWorkflowCommunicationReqDTO.getBody())
                            .createdBy(Integer.parseInt(addWorkflowCommunicationReqDTO.getUserId()))
                            .isNewCommunication(addWorkflowCommunicationReqDTO.getIsNewCommunication())
                            .parentId(addWorkflowCommunicationReqDTO.getParentId())
                            .subject(addWorkflowCommunicationReqDTO.getSubject())
                            .taxpayerGstin(addWorkflowCommunicationReqDTO.getTaxpayerGstin())
                            .tvcrid(taxpayerVendorByTaxpayer.getChildRelationId())
                            .vendorGstin(addWorkflowCommunicationReqDTO.getVendorGstin())
                            .isVendor(addWorkflowCommunicationReqDTO.getIsVendor())
                            .wfMstId(addWorkflowCommunicationReqDTO.getWorkflowMstId()).postFrom(taxpayerEmailId)
                            .postTo(email).commentType(String.valueOf(addWorkflowCommunicationReqDTO.getCommentType()))
                            .build();

        } else {

            String vendorEmail = commonMasterDao.getVendorEmailEmail(addWorkflowCommunicationReqDTO);
            if (StringUtils.isBlank(vendorEmail)) {
                throw new CommonMasterBusinessException("Vendor contact doesn't exist.");
            }
            String taxpayerEmail = commonMasterDao
                            .getTaxpayerSingleEmailId(addWorkflowCommunicationReqDTO.getTaxpayerGstin());
            if (StringUtils.isBlank(taxpayerEmail)) {
                throw new CommonMasterBusinessException("Taxpayer contact doesn't exist.");
            }

            workflowCommunication = WorkflowCommunication.builder().body(addWorkflowCommunicationReqDTO.getBody())

                            .createdBy(Integer.parseInt(addWorkflowCommunicationReqDTO.getUserId()))
                            .isNewCommunication(addWorkflowCommunicationReqDTO.getIsNewCommunication())
                            .parentId(addWorkflowCommunicationReqDTO.getParentId())
                            .subject(addWorkflowCommunicationReqDTO.getSubject())
                            .taxpayerGstin(addWorkflowCommunicationReqDTO.getTaxpayerGstin())
                            .tvcrid(taxpayerVendorByTaxpayer.getChildRelationId())
                            .vendorGstin(addWorkflowCommunicationReqDTO.getVendorGstin())
                            .isVendor(addWorkflowCommunicationReqDTO.getIsVendor())
                            .wfMstId(addWorkflowCommunicationReqDTO.getWorkflowMstId()).postFrom(vendorEmail)
                            .postTo(taxpayerEmail)
                            .commentType(String.valueOf(addWorkflowCommunicationReqDTO.getCommentType())).build();
        }

        commonMasterDao.insertWorkflowCommunication(workflowCommunication);
        int moduleId = 0;
        int mailModuleId = 0;
        int vendorModuleId = 0;
        if (addWorkflowCommunicationReqDTO.getModuleId() == Constants.INVITES_TRACKING_TAXPAYER_MODULE_ID
                        || addWorkflowCommunicationReqDTO
                                        .getModuleId() == Constants.INVITES_TRACKING_VENDOR_MODULE_ID) {
            moduleId = Constants.INVITETRACKINGMODULEID;
            mailModuleId = Constants.INVITES_TRACKING_TAXPAYER_MODULE_ID;
            vendorModuleId = 157;

        }
        if (addWorkflowCommunicationReqDTO.getModuleId() == Constants.DOCUMENT_UPLOAD_TAXPAYER_MODULE_ID
                        || addWorkflowCommunicationReqDTO.getModuleId() == Constants.DOCUMENT_UPLOAD_VENDOR_MODULE_ID) {
            moduleId = Constants.DOCUMENTUPLOADID;
            mailModuleId = Constants.DOCUMENT_UPLOAD_TAXPAYER_MODULE_ID;
        }
        if (addWorkflowCommunicationReqDTO.getModuleId() == Constants.COMMUNICATION_TAXPAYER_MODULE_ID
                        || addWorkflowCommunicationReqDTO.getModuleId() == Constants.COMMUNICATION_VENDOR_MODULE_ID) {
            moduleId = Constants.VENDORCOMMUNICATIOID;
            mailModuleId = Constants.COMMUNICATION_TAXPAYER_MODULE_ID;
        }

        try {
            if (addWorkflowCommunicationReqDTO.getIsVendor() == 0) {

                String vendorAllPrimaryMailIds = commonMasterDao.getVendorAllPrimaryMailId(
                                addWorkflowCommunicationReqDTO.getTaxpayerGstin(),
                                addWorkflowCommunicationReqDTO.getVendorGstin());
                String taxpayerSingleMailId = commonMasterDao
                                .getTaxpayerSingleEmailId(addWorkflowCommunicationReqDTO.getTaxpayerGstin());
                List<String> vendorUserIdList = commonMasterDao.getVendorAllPrimaryUserId(
                                addWorkflowCommunicationReqDTO.getTaxpayerGstin(),
                                addWorkflowCommunicationReqDTO.getVendorGstin());

                for (int index = 0; index < vendorUserIdList.size(); index++) {

                    int vendorUserId = Integer.parseInt(vendorUserIdList.get(index));
                    commonMasterDao.commonPostNotification(moduleId,
                                    " comment received from GSTIN -"
                                                    + addWorkflowCommunicationReqDTO.getTaxpayerGstin(),
                                    vendorUserId, vendorUserId, vendorUserId, ReportsConstants.NOTIFICATION_SUCCESS);
                }

                commonMasterDao.insertIntoMailBox(vendorAllPrimaryMailIds, taxpayerSingleMailId,
                                addWorkflowCommunicationReqDTO.getTaxpayerGstin(),
                                addWorkflowCommunicationReqDTO.getBody());
            } else {

                String vendorSingleMailId = commonMasterDao.getSingleMailId(addWorkflowCommunicationReqDTO.getUserId());
                List<TaxpayerMultilevelDetailsDTO> taxpayerMultilevelDetails = commonMasterDao
                                .getTaxpayerMultiLevelDetails(0, addWorkflowCommunicationReqDTO.getTaxpayerGstin(),
                                                vendorModuleId);

                String taxpayerAllLevelMailIds = commonMasterDao.getTaxpayerAllLevelMailIds(taxpayerMultilevelDetails);

                for (int index = 0; index < taxpayerMultilevelDetails.size(); index++) {

                    int taxpayerUserId = taxpayerMultilevelDetails.get(index).getUserId();
                    commonMasterDao.commonPostNotification(moduleId,
                                    " comment received from GSTIN -" + addWorkflowCommunicationReqDTO.getVendorGstin(),
                                    taxpayerUserId, taxpayerUserId, taxpayerUserId,
                                    ReportsConstants.NOTIFICATION_SUCCESS);
                }
                commonMasterDao.insertIntoMailBox(taxpayerAllLevelMailIds, vendorSingleMailId,
                                addWorkflowCommunicationReqDTO.getVendorGstin(),
                                addWorkflowCommunicationReqDTO.getBody());
            }
        } catch (Exception e) {
            log.error("Error coming at the time of adding notification", e);
        }

    }

    private void validateNewCommunication(AddWorkflowCommunicationReqDTO addWorkflowCommunicationReqDTO,
                    List<CustomValidationError> customValidationErrorList) {
        if (StringUtils.isBlank(addWorkflowCommunicationReqDTO.getSubject())) {
            CustomValidationError customValidationError = new CustomValidationError(
                            AddWorkflowCommunicationReqDTO.class.getName(), "subject",
                            addWorkflowCommunicationReqDTO.getSubject(),
                            "Request parameter subject must not be null or blank");
            customValidationErrorList.add(customValidationError);
        }
        if (addWorkflowCommunicationReqDTO.getParentId() != null) {
            CustomValidationError customValidationError = new CustomValidationError(
                            AddWorkflowCommunicationReqDTO.class.getName(), "parentId",
                            addWorkflowCommunicationReqDTO.getParentId(),
                            "Request parameter parentId must be null for new communication");
            customValidationErrorList.add(customValidationError);
        }

    }

    private void validateReplyToCommunication(AddWorkflowCommunicationReqDTO addWorkflowCommunicationReqDTO,
                    List<CustomValidationError> customValidationErrorList) {

        if (addWorkflowCommunicationReqDTO.getParentId() == null) {
            CustomValidationError customValidationError = new CustomValidationError(
                            AddWorkflowCommunicationReqDTO.class.getName(), "parentId",
                            addWorkflowCommunicationReqDTO.getParentId(),
                            "Request parameter parentId must not be null for communication");
            customValidationErrorList.add(customValidationError);
        }
        try {
            commonMasterDao.getWorkflowCommunicationById(
                            WorkflowCommunication.builder().id(addWorkflowCommunicationReqDTO.getParentId()).build());
        } catch (EmptyResultDataAccessException e) {
            throw new ResourceNotFoundException(WorkflowCommunication.class, "id",
                            addWorkflowCommunicationReqDTO.getParentId() + "");
        }
    }

    @Override
    public PaginationResDTO searchWorkflowCommunication(
                    SearchWorkflowCommunicationReqDTO searchWorkflowCommunicationReqDTO) {

        Pageable paging = PageRequest.of(searchWorkflowCommunicationReqDTO.getPage(),
                        searchWorkflowCommunicationReqDTO.getSize());
        WorkflowCommunication workflowCommunicationReq = WorkflowCommunication.builder()
                        .wfMstId(searchWorkflowCommunicationReqDTO.getWorkflowMasterId())
                        .parentId(searchWorkflowCommunicationReqDTO.getParentId()).build();

        Page<WorkflowCommunication> pagedResult = null;
//        if (searchWorkflowCommunicationReqDTO.getParentId() == null) {
//            workflowCommunicationReq.setIsNewCommunication(Constants.WORKFLOW_COMMUNICATION_IS_NEW_COMMUNICATION_YES);
//            pagedResult = commonMasterDao.searchParentWorkflowCommunication(paging, workflowCommunicationReq);
//        } else {
//            List<CustomValidationError> customValidationErrorList = new ArrayList<>();
//            if (workflowCommunicationReq.getParentId() == null) {
//                CustomValidationError customValidationError = new CustomValidationError(
//                                WorkflowCommunication.class.getName(), "parentId",
//                                searchWorkflowCommunicationReqDTO.getParentId(),
//                                "Request parameter parentId must not be null or blank");
//                customValidationErrorList.add(customValidationError);
//                throw new CustomValidationViolationException(customValidationErrorList);
//            }
//
//            try {
//                commonMasterDao.getWorkflowCommunicationById(WorkflowCommunication.builder()
//                                .id(searchWorkflowCommunicationReqDTO.getParentId()).build());
//            } catch (EmptyResultDataAccessException e) {
//                throw new ResourceNotFoundException(WorkflowCommunication.class, "id",
//                                searchWorkflowCommunicationReqDTO.getParentId() + "");
//            }

        pagedResult = commonMasterDao.searchChildWorkflowCommunication(paging, workflowCommunicationReq);
        // }
        if (pagedResult != null) {
            List<WorkflowCommunicationResDTO> workflowCommunicationResDTO = pagedResult.getContent().stream()
                            .map(workflowCommunication -> WorkflowCommunicationResDTO.builder()
                                            .createdAt(workflowCommunication.getCreatedAt())
                                            .id(workflowCommunication.getId()).body(workflowCommunication.getBody())
                                            .isNewCommunication(workflowCommunication.getIsNewCommunication())
                                            .isVendor(workflowCommunication.getIsVendor())
                                            .parentId(workflowCommunication.getParentId())
                                            .postFrom(workflowCommunication.getPostFrom())
                                            .subject(workflowCommunication.getSubject())
                                            .totalComments(workflowCommunication.getChildCount())
                                            .postTo(workflowCommunication.getPostTo())
                                            .workflowMstId(workflowCommunication.getWfMstId())
                                            .commentType(workflowCommunication.getCommentType()).build())
                            .collect(Collectors.toList());

            return PaginationResDTO.builder().totalElements(pagedResult.getTotalElements())
                            .noOfElements(pagedResult.getNumberOfElements()).number(pagedResult.getNumber())
                            .size(pagedResult.getSize()).totalPages(pagedResult.getTotalPages())
                            .searchElements(workflowCommunicationResDTO).build();

        } else {
            return defaultPaginationResponse();
        }
    }

    public static PaginationResDTO defaultPaginationResponse() {
        return PaginationResDTO.builder().totalElements(0).noOfElements(0).number(0).size(0).totalPages(0)
                        .searchElements(Collections.emptyList()).build();
    }

    @Override
    public List<ErrorCodeDescriptionResponseDTO> getErrorDescriptionList(ErrorMessageListDto errorMessageListDto) {
        List<ErrorCodeDescriptionResponseDTO> errorCodeDescriptionResponseDTOList = new ArrayList<>();
        if (errorMessageListDto.getIsVendor() == 0) {
            if ("e-Invoice".equals(errorMessageListDto.getDataType())
                            || "Invoice".equals(errorMessageListDto.getDataType())) {
                errorCodeDescriptionResponseDTOList = commonMasterDao.getErrorCode(errorMessageListDto);
            } else if ("e-Way Bill".equals(errorMessageListDto.getDataType())) {
                errorCodeDescriptionResponseDTOList = commonMasterDao.getErrorCodeEway(errorMessageListDto);
            }
        } else if (errorMessageListDto.getIsVendor() == 1) {
            if ("e-Invoice".equals(errorMessageListDto.getDataType())
                            || "Invoice".equals(errorMessageListDto.getDataType())) {
                errorCodeDescriptionResponseDTOList = commonMasterDao.getErrorCodeInvoiceVendor(errorMessageListDto);
            } else if ("e-Way Bill".equals(errorMessageListDto.getDataType())) {
                errorCodeDescriptionResponseDTOList = commonMasterDao.getErrorCodeVendor(errorMessageListDto);
            }
        }

        List<String> errorCodeList = new ArrayList<>();
        errorCodeDescriptionResponseDTOList.forEach(x -> {
            errorCodeList.addAll(Arrays.asList(x.getErrorCode().replace("|", ",").split(",")));

        });
        List<ErrorCodeDescriptionResponseDTO> newErrorCodeDescriptionResponseDTOList = new ArrayList<>();
        Map<String, String> errorCodeMap = commonMasterDao.setErrorDiscriptionForErrorList();
        errorCodeList.forEach(x -> {
            if (!x.isBlank()) {
                ErrorCodeDescriptionResponseDTO newErrorCodeDescriptionResponseDTO = new ErrorCodeDescriptionResponseDTO();
                newErrorCodeDescriptionResponseDTO.setErrorCode(x);
                newErrorCodeDescriptionResponseDTO.setErrorDescription(errorCodeMap.get(x));
                newErrorCodeDescriptionResponseDTOList.add(newErrorCodeDescriptionResponseDTO);
            }
        });
        return newErrorCodeDescriptionResponseDTOList;
    }

    @Override
    public List<FieldNameResponseDto> getFieldNames(AdvanceSearchReqDto advanceSearchReqDto) {

        return commonMasterDao.getFieldName(advanceSearchReqDto);
    }

}
