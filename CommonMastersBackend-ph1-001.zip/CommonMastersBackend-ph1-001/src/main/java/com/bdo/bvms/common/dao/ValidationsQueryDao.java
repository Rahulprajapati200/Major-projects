package com.bdo.bvms.common.dao;

import java.util.Map;

public interface ValidationsQueryDao {

	public Map<String, String> getHsnCodeList();
}
