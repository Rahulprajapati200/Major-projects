package com.bdo.bvms.common.util;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;

public class EncryptionUtils {

    private EncryptionUtils() {
    }

    public static String decrypt(String appKey, String encryptedString) throws UnsupportedEncodingException,
                    NoSuchAlgorithmException, InvalidKeyException, DecoderException, NoSuchPaddingException,
                    InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

        if (StringUtils.isEmpty(encryptedString)) {
            return "";
        }

        byte[] keyValue = Base64.getDecoder().decode(appKey.getBytes());
        Key key = new SecretKeySpec(keyValue, "AES");
        String aesDataString = new String(Base64.getDecoder().decode(encryptedString.getBytes()));
        AesEncryptionData aesEncryptedData = new Gson().fromJson(aesDataString, AesEncryptionData.class);
        String ivValue = aesEncryptedData.iv;
        String encryptedData = aesEncryptedData.value;
        String macValue = aesEncryptedData.mac;

        byte[] iv = Base64.getDecoder().decode(ivValue.getBytes("UTF-8"));
        byte[] decodedValue = Base64.getDecoder().decode(encryptedData.getBytes("UTF-8"));

        SecretKeySpec macKey = new SecretKeySpec(keyValue, "HmacSHA256");
        Mac hmacSha256 = Mac.getInstance("HmacSHA256");
        hmacSha256.init(macKey);
        hmacSha256.update(ivValue.getBytes("UTF-8"));
        byte[] calcMac = hmacSha256.doFinal(encryptedData.getBytes("UTF-8"));
        byte[] mac = Hex.decodeHex(macValue.toCharArray());
        if (!Arrays.equals(calcMac, mac))
            return "MAC mismatch";

        Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding"); // or
                                                               // PKCS5Padding
        c.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
        byte[] decValue = c.doFinal(decodedValue);

        return new String(decValue);

    }

    public static String decryptJson(String appKey, String encryptedString) throws UnsupportedEncodingException,
                    NoSuchAlgorithmException, InvalidKeyException, DecoderException, NoSuchPaddingException,
                    InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        if (StringUtils.isEmpty(encryptedString)) {
            return "";
        }

        byte[] keyValue = Base64.getDecoder().decode(appKey.getBytes());
        Key key = new SecretKeySpec(keyValue, "AES");

        AesEncryptionData aesEncryptedData = new Gson().fromJson(encryptedString, AesEncryptionData.class);
        String ivValue = aesEncryptedData.iv;
        String encryptedData = aesEncryptedData.value;
        String macValue = aesEncryptedData.mac;

        byte[] iv = Base64.getDecoder().decode(ivValue.getBytes("UTF-8"));
        byte[] decodedValue = Base64.getDecoder().decode(encryptedData.getBytes("UTF-8"));

        SecretKeySpec macKey = new SecretKeySpec(keyValue, "HmacSHA256");
        Mac hmacSha256 = Mac.getInstance("HmacSHA256");
        hmacSha256.init(macKey);
        hmacSha256.update(ivValue.getBytes("UTF-8"));
        byte[] calcMac = hmacSha256.doFinal(encryptedData.getBytes("UTF-8"));
        byte[] mac = Hex.decodeHex(macValue.toCharArray());
        if (!Arrays.equals(calcMac, mac))
            return "MAC mismatch";

        Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding"); // or
        // PKCS5Padding
        c.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
        byte[] decValue = c.doFinal(decodedValue);

        return new String(decValue);

    }

}
