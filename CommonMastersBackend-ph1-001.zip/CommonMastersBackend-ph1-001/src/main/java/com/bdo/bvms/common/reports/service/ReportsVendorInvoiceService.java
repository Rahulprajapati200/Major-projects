package com.bdo.bvms.common.reports.service;

import java.sql.SQLException;
import java.util.Map;

import com.bdo.bvms.common.dto.VendorInvoiceGetReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceInputReportsReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceSyncReqDTO;
import com.bdo.bvms.common.exceptions.AppBusinessException;

public interface ReportsVendorInvoiceService {

    Map<String, Object> getVendorInvoiceInputReports(VendorInvoiceInputReportsReqDTO vendorInvoiceInputReportsReq)
                    throws AppBusinessException, SQLException;

    Map<String, Object> getVendorInvoiceGETReports(VendorInvoiceGetReqDTO vendorInvoiceGetReportsReq)
                    throws AppBusinessException, SQLException;

    Map<String, Object> getVendorInvoiceSyncReports(VendorInvoiceSyncReqDTO vendorInvoiceSyncReq)
                    throws AppBusinessException, SQLException;

}
