package com.bdo.bvms.common.reports.service.impl;

import java.math.BigInteger;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.dto.ReportsCustomColumnsDTO;
import com.bdo.bvms.common.dto.ReportsVendorCommInwardRegisterResDTO;
import com.bdo.bvms.common.dto.ReportsVendorCommInwardVsGSTR2AResDTO;
import com.bdo.bvms.common.dto.ReportsVendorCommInwardVsGSTR2BResDTO;
import com.bdo.bvms.common.dto.ReportsVendorCommVendorEmailStatusResDTO;
import com.bdo.bvms.common.dto.VendorCommunicationEmailStatusReqDTO;
import com.bdo.bvms.common.dto.VendorCommunicationInwardReqDTO;
import com.bdo.bvms.common.dto.VendorCommunicationReconciliationReqDTO;
import com.bdo.bvms.common.exceptions.AppBusinessException;
import com.bdo.bvms.common.reports.constants.ReportsConstants;
import com.bdo.bvms.common.reports.dao.ReportModuleCommonRepo;
import com.bdo.bvms.common.reports.dao.ReportsVendorCommunicationRepo;
import com.bdo.bvms.common.reports.service.ReportsModuleHelperService;
import com.bdo.bvms.common.reports.service.ReportsVendorCommunicationService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j

public class ReportsVendorCommunicationServiceImpl implements ReportsVendorCommunicationService {

    @Autowired
    ReportModuleCommonRepo reportModuleCommonRepo;
    @Autowired
    ReportsVendorCommunicationRepo reportsVendorCommunicationRepo;

    @Autowired
    ReportsModuleHelperService reportsModuleHelperService;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Override
    public Map<String, Object> getVendorCommunicationInwarReports(
                    VendorCommunicationInwardReqDTO vendorCommunicationInwardReq)
                    throws AppBusinessException, SQLException {
        reportModuleCommonRepo.updateAccessLogTable(LocalDateTime.now(), vendorCommunicationInwardReq.getReportId(),
                        vendorCommunicationInwardReq.getUserId(), vendorCommunicationInwardReq.getEntityId(),
                        vendorCommunicationInwardReq.getUserTypeId());
        String monthList = getMonthList(vendorCommunicationInwardReq.getYearOrMonth(),
                        vendorCommunicationInwardReq.getYearOrMonthList());
        String gstinList = getGstinList(vendorCommunicationInwardReq.getGstinOrPan(),
                        vendorCommunicationInwardReq.getGstinOrPanList());

        Map<String, Object> dataAndCount = reportsVendorCommunicationRepo
                        .getInwardDataList(vendorCommunicationInwardReq, monthList, gstinList);
        @SuppressWarnings("unchecked")
        List<ReportsVendorCommInwardRegisterResDTO> data = (List<ReportsVendorCommInwardRegisterResDTO>) dataAndCount
                        .get("InwardTabVendorCommunicationReportData");
        Timestamp timeStamp = new Timestamp(System.currentTimeMillis());
        String containerName = reportModuleCommonRepo.getContainerName(vendorCommunicationInwardReq.getEntityId());
        String fileName = "";
        try {
            fileName = reportModuleCommonRepo.getFileName(vendorCommunicationInwardReq.getReportId());
        } catch (Exception e) {
            log.error("error in getting VendorCommunicationInwarReports file name from database", e);
        }
        int pldTemplateId = 7;
        int summaryType = 0;
        if (vendorCommunicationInwardReq.getSummaryType().equals(ReportsConstants.INVOICE_LEVEL)) {
            summaryType = 1;

        }
        Map<String, Object> dataAndColumns = new HashMap<>();
        if (ReportsConstants.VIEW.equals(vendorCommunicationInwardReq.getButtonType())) {

            List<ReportsCustomColumnsDTO> columnsData = reportModuleCommonRepo.getCustomizeColumnsForView(pldTemplateId,
                            vendorCommunicationInwardReq.getReportId(), vendorCommunicationInwardReq.getUserId(),
                            vendorCommunicationInwardReq.getCustomTemplateId(), summaryType);

            dataAndColumns.put(ReportsConstants.DATA, data);
            dataAndColumns.put(ReportsConstants.COLUMN_DATA, columnsData);
            dataAndColumns.put(ReportsConstants.TOTAL_PAGE_ELEMENTS, dataAndCount.get(ReportsConstants.TOTALCOUNT));
            dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                            fileName + ReportsConstants.SUCCESS_MESSAGE_VIEW_DESCRIPTION);

            return dataAndColumns;

        } else if (ReportsConstants.DOWNLOAD.equals(vendorCommunicationInwardReq.getButtonType())) {

            dataAndColumns = reportsVendorCommunicationRepo.getDownloadVendorCommunicationInwardReports(
                            vendorCommunicationInwardReq, monthList, gstinList, timeStamp, containerName, fileName);
            dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                            fileName + ReportsConstants.SUCCESS_MESSAGE_EXPORT_DESCRIPTION);

            return dataAndColumns;

        } else if (ReportsConstants.BACKGROUND.equals(vendorCommunicationInwardReq.getButtonType())) {
            BigInteger id = reportModuleCommonRepo.insertBackGroundDetails(vendorCommunicationInwardReq.getReportId(),
                            ReportsConstants.IN_PROGRESS, timeStamp, vendorCommunicationInwardReq.getUserId(),
                            timeStamp, fileName);
            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORCOMMUNICATIONMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_IN_PROGRESS,
                            Integer.valueOf(vendorCommunicationInwardReq.getUserId()),
                            Integer.valueOf(vendorCommunicationInwardReq.getUserId()),
                            Integer.valueOf(vendorCommunicationInwardReq.getUserId()),
                            ReportsConstants.NOTIFICATION_INITIATED);

            reportsVendorCommunicationRepo.getGenerateBackgroundVendorCommunicationInwardReports(
                            vendorCommunicationInwardReq, monthList, gstinList, timeStamp, containerName, fileName,
                            (Long) dataAndCount.get(ReportsConstants.TOTALCOUNT), id);
            dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                            ReportsConstants.SUCCESS_MESSAGE_BACKGROUND_DESCRIPTION + fileName + "'");
            return dataAndColumns;

        }

        return new HashMap<>();
    }

    @Override
    public Map<String, Object> getVendorCommunicationReconciliationReports(
                    VendorCommunicationReconciliationReqDTO vendorCommunicationReconciliationReq)
                    throws AppBusinessException, SQLException {

        reportModuleCommonRepo.updateAccessLogTable(LocalDateTime.now(),
                        vendorCommunicationReconciliationReq.getReportId(),
                        vendorCommunicationReconciliationReq.getUserId(),
                        vendorCommunicationReconciliationReq.getEntityId(),
                        vendorCommunicationReconciliationReq.getUserTypeId());

        Map<String, Object> getReconciliationReportsDataList;

        Timestamp timeStamp = new Timestamp(System.currentTimeMillis());
        String containerName = reportModuleCommonRepo
                        .getContainerName(vendorCommunicationReconciliationReq.getEntityId());
        String fileName = "";
        try {
            fileName = reportModuleCommonRepo.getFileName(vendorCommunicationReconciliationReq.getReportId());
        } catch (Exception e) {
            log.error("error in getting file name from database", e);
        }

        String yearId = vendorCommunicationReconciliationReq.getYearOrMonthList().get(0);

        String pan = "";
        String taxpayerGstin = "";
        if (vendorCommunicationReconciliationReq.getGstinOrPan().equals(ReportsConstants.PAN)) {
            pan = vendorCommunicationReconciliationReq.getGstinOrPanList().get(0);
            String[] gstinArray = reportModuleCommonRepo.getGstinFromDB(pan);
            taxpayerGstin = Arrays.asList(gstinArray).get(0);
        } else {
            pan = vendorCommunicationReconciliationReq.getGstinOrPanList().get(0).substring(2, 12);
            taxpayerGstin = vendorCommunicationReconciliationReq.getGstinOrPanList().get(0);
        }

        String vendorGstin = vendorCommunicationReconciliationReq.getVendorGstin().toString().replace("[", "")
                        .replace("]", "").replace("{", "").replace("}", "").replace(" ", "");
        String recoStatus = vendorCommunicationReconciliationReq.getRecoStatus().toString().replace("[", "")
                        .replace("]", "").replace("{", "").replace("}", "").replace(" ", "");
        int pldTemplateId = 7;
        int summaryType = 0;

        getReconciliationReportsDataList = reportsVendorCommunicationRepo
                        .getVendorCommunicationReconciliationReportsResList(taxpayerGstin, yearId, recoStatus,
                                        vendorGstin, vendorCommunicationReconciliationReq, pan);

        if (ReportsConstants.INWARD_VS_GSTR2A_RECO_REPORT.equals(vendorCommunicationReconciliationReq.getReportId())
                        || ReportsConstants.CUSTOM_INWARD_VS_GSTR2A_RECO_REPORT
                                        .equals(vendorCommunicationReconciliationReq.getReportId())) {
            @SuppressWarnings("unchecked")
            List<ReportsVendorCommInwardVsGSTR2AResDTO> data = (List<ReportsVendorCommInwardVsGSTR2AResDTO>) getReconciliationReportsDataList
                            .get("ReconciliationTabVendorCommunicationReportData");

            Map<String, Object> dataAndColumns = new HashMap<>();

            if (ReportsConstants.VIEW.equals(vendorCommunicationReconciliationReq.getButtonType())) {

                List<ReportsCustomColumnsDTO> columnsData = reportModuleCommonRepo.getCustomizeColumnsForView(
                                pldTemplateId, vendorCommunicationReconciliationReq.getReportId(),
                                vendorCommunicationReconciliationReq.getUserId(),
                                vendorCommunicationReconciliationReq.getCustomTemplateId(), summaryType);

                dataAndColumns.put(ReportsConstants.DATA, data);
                dataAndColumns.put(ReportsConstants.COLUMN_DATA, columnsData);
                dataAndColumns.put(ReportsConstants.TOTAL_PAGE_ELEMENTS,
                                getReconciliationReportsDataList.get(ReportsConstants.TOTALCOUNT));
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_VIEW_DESCRIPTION);
                return dataAndColumns;

            } else if (ReportsConstants.DOWNLOAD.equals(vendorCommunicationReconciliationReq.getButtonType())) {

                dataAndColumns = reportsVendorCommunicationRepo.getDownloadVendorCommunicationReconcilationReports(
                                vendorCommunicationReconciliationReq, taxpayerGstin, yearId, recoStatus, vendorGstin,
                                timeStamp, containerName, fileName, pan);
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_EXPORT_DESCRIPTION);

                return dataAndColumns;

            } else if (ReportsConstants.BACKGROUND.equals(vendorCommunicationReconciliationReq.getButtonType())) {
                BigInteger id = reportModuleCommonRepo.insertBackGroundDetails(
                                vendorCommunicationReconciliationReq.getReportId(), ReportsConstants.IN_PROGRESS,
                                timeStamp, vendorCommunicationReconciliationReq.getUserId(), timeStamp, fileName);
                reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORCOMMUNICATIONMODULEID,
                                fileName + ReportsConstants.BACKGROUNG_IN_PROGRESS,
                                Integer.valueOf(vendorCommunicationReconciliationReq.getUserId()),
                                Integer.valueOf(vendorCommunicationReconciliationReq.getUserId()),
                                Integer.valueOf(vendorCommunicationReconciliationReq.getUserId()),
                                ReportsConstants.NOTIFICATION_INITIATED);

                reportsVendorCommunicationRepo.getDownloadBackgroundVendorCommReconcilationReport(
                                vendorCommunicationReconciliationReq, taxpayerGstin, yearId, recoStatus, vendorGstin,
                                timeStamp, containerName, fileName, pan,
                                (Long) getReconciliationReportsDataList.get(ReportsConstants.TOTALCOUNT), id);

                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                ReportsConstants.SUCCESS_MESSAGE_BACKGROUND_DESCRIPTION + fileName + "'");
                return dataAndColumns;
            }

        } else if (ReportsConstants.INWARD_VS_GSTR2B_RECO_REPORT
                        .equals(vendorCommunicationReconciliationReq.getReportId())
                        || ReportsConstants.CUSTOM_INWARD_VS_GSTR2B_RECO_REPORT
                                        .equals(vendorCommunicationReconciliationReq.getReportId())) {

            @SuppressWarnings("unchecked")
            List<ReportsVendorCommInwardVsGSTR2BResDTO> data = (List<ReportsVendorCommInwardVsGSTR2BResDTO>) getReconciliationReportsDataList
                            .get("ReconciliationTabVendorCommunicationReportData");
            Map<String, Object> dataAndColumns = new HashMap<>();
            if (ReportsConstants.VIEW.equals(vendorCommunicationReconciliationReq.getButtonType())) {

                List<ReportsCustomColumnsDTO> columnsData = reportModuleCommonRepo.getCustomizeColumnsForView(
                                pldTemplateId, vendorCommunicationReconciliationReq.getReportId(),
                                vendorCommunicationReconciliationReq.getUserId(),
                                vendorCommunicationReconciliationReq.getCustomTemplateId(), summaryType);

                dataAndColumns.put(ReportsConstants.DATA, data);
                dataAndColumns.put(ReportsConstants.COLUMN_DATA, columnsData);
                dataAndColumns.put(ReportsConstants.TOTAL_PAGE_ELEMENTS,
                                getReconciliationReportsDataList.get(ReportsConstants.TOTALCOUNT));
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_VIEW_DESCRIPTION);
                return dataAndColumns;

            } else if (ReportsConstants.DOWNLOAD.equals(vendorCommunicationReconciliationReq.getButtonType())) {

                dataAndColumns = reportsVendorCommunicationRepo.getDownloadVendorCommunicationReconcilationReports(
                                vendorCommunicationReconciliationReq, taxpayerGstin, yearId, recoStatus, vendorGstin,
                                timeStamp, containerName, fileName, pan);
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_EXPORT_DESCRIPTION);

                return dataAndColumns;

            } else if (ReportsConstants.BACKGROUND.equals(vendorCommunicationReconciliationReq.getButtonType())) {
                BigInteger id = reportModuleCommonRepo.insertBackGroundDetails(
                                vendorCommunicationReconciliationReq.getReportId(), ReportsConstants.IN_PROGRESS,
                                timeStamp, vendorCommunicationReconciliationReq.getUserId(), timeStamp, fileName);
                reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORCOMMUNICATIONMODULEID,
                                fileName + ReportsConstants.BACKGROUNG_IN_PROGRESS,
                                Integer.valueOf(vendorCommunicationReconciliationReq.getUserId()),
                                Integer.valueOf(vendorCommunicationReconciliationReq.getUserId()),
                                Integer.valueOf(vendorCommunicationReconciliationReq.getUserId()),
                                ReportsConstants.NOTIFICATION_INITIATED);

                reportsVendorCommunicationRepo.getDownloadBackgroundVendorCommReconcilationReport(
                                vendorCommunicationReconciliationReq, taxpayerGstin, yearId, recoStatus, vendorGstin,
                                timeStamp, containerName, fileName, pan,
                                (Long) getReconciliationReportsDataList.get(ReportsConstants.TOTALCOUNT), id);
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                ReportsConstants.SUCCESS_MESSAGE_BACKGROUND_DESCRIPTION + fileName + "'");
                return dataAndColumns;

            }

        }

        return new HashMap<>();

    }

    @Override
    public Map<String, Object> getVendorCommunicationEmailStatusReports(
                    VendorCommunicationEmailStatusReqDTO vendorCommunicationEmailStatusReq)
                    throws AppBusinessException, SQLException {// vendorCommunicationEmailStatusReq
        reportModuleCommonRepo.updateAccessLogTable(LocalDateTime.now(),
                        vendorCommunicationEmailStatusReq.getReportId(), vendorCommunicationEmailStatusReq.getUserId(),
                        vendorCommunicationEmailStatusReq.getEntityId(),
                        vendorCommunicationEmailStatusReq.getUserTypeId());
        String gstinList = vendorCommunicationEmailStatusReq.getGstinOrPanList().toString().replace("[", "")
                        .replace("]", "").replace("{", "").replace("}", "").replace(" ", "");
        String yearId = vendorCommunicationEmailStatusReq.getYearOrMonthList().toString().replace("[", "")
                        .replace("]", "").replace("{", "").replace("}", "").replace(" ", "");
        String vendorGstin = vendorCommunicationEmailStatusReq.getVendorGstin().toString().replace("[", "")
                        .replace("]", "").replace("{", "").replace("}", "").replace(" ", "");

        Map<String, Object> dataAndCount = reportsVendorCommunicationRepo
                        .getEmailStatusDataList(vendorCommunicationEmailStatusReq, gstinList, yearId, vendorGstin);
        @SuppressWarnings("unchecked")
        List<ReportsVendorCommVendorEmailStatusResDTO> data = (List<ReportsVendorCommVendorEmailStatusResDTO>) dataAndCount
                        .get("InwardTabVendorCommunicationReportData");
        Timestamp timeStamp = new Timestamp(System.currentTimeMillis());
        String containerName = reportModuleCommonRepo.getContainerName(vendorCommunicationEmailStatusReq.getEntityId());
        String fileName = "";
        try {
            fileName = reportModuleCommonRepo.getFileName(vendorCommunicationEmailStatusReq.getReportId());
        } catch (Exception e) {
            log.error("error in getting file name from database", e);
        }
        int pldTemplateId = 7;
        int summaryType = 0;

        Map<String, Object> dataAndColumns = new HashMap<>();
        if (ReportsConstants.VIEW.equals(vendorCommunicationEmailStatusReq.getButtonType())) {

            List<ReportsCustomColumnsDTO> columnsData = reportModuleCommonRepo.getCustomizeColumnsForView(pldTemplateId,
                            vendorCommunicationEmailStatusReq.getReportId(),
                            vendorCommunicationEmailStatusReq.getUserId(),
                            vendorCommunicationEmailStatusReq.getCustomTemplateId(), summaryType);

            dataAndColumns.put(ReportsConstants.DATA, data);
            dataAndColumns.put(ReportsConstants.COLUMN_DATA, columnsData);
            dataAndColumns.put(ReportsConstants.TOTAL_PAGE_ELEMENTS, dataAndCount.get(ReportsConstants.TOTALCOUNT));
            dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                            fileName + ReportsConstants.SUCCESS_MESSAGE_VIEW_DESCRIPTION);
            return dataAndColumns;

        } else if (ReportsConstants.DOWNLOAD.equals(vendorCommunicationEmailStatusReq.getButtonType())) {

            dataAndColumns = reportsVendorCommunicationRepo.getDownloadEmailStatusReports(
                            vendorCommunicationEmailStatusReq, gstinList, yearId, vendorGstin, timeStamp, containerName,
                            fileName);
            dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                            fileName + ReportsConstants.SUCCESS_MESSAGE_EXPORT_DESCRIPTION);

            return dataAndColumns;

        } else if (ReportsConstants.BACKGROUND.equals(vendorCommunicationEmailStatusReq.getButtonType())) {
            BigInteger id = reportModuleCommonRepo.insertBackGroundDetails(
                            vendorCommunicationEmailStatusReq.getReportId(), ReportsConstants.IN_PROGRESS, timeStamp,
                            vendorCommunicationEmailStatusReq.getUserId(), timeStamp, fileName);
            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORCOMMUNICATIONMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_IN_PROGRESS,
                            Integer.valueOf(vendorCommunicationEmailStatusReq.getUserId()),
                            Integer.valueOf(vendorCommunicationEmailStatusReq.getUserId()),
                            Integer.valueOf(vendorCommunicationEmailStatusReq.getUserId()),
                            ReportsConstants.NOTIFICATION_INITIATED);

            reportsVendorCommunicationRepo.getDownloadBackgroundEmailStatusReport(vendorCommunicationEmailStatusReq,
                            gstinList, yearId, vendorGstin, timeStamp, containerName, fileName,
                            (Long) dataAndCount.get(ReportsConstants.TOTALCOUNT), id);
            dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                            ReportsConstants.SUCCESS_MESSAGE_BACKGROUND_DESCRIPTION + fileName + "'");
            return dataAndColumns;

        }

        return new HashMap<>();
    }

    private String getGstinList(String panOrGstin, List<String> panOrGstinList) {
        String gstinList = "";
        if (ReportsConstants.PAN.equals(panOrGstin)) {

            // here we get all GSTIN into a string array according to single pan
            // from database.
            String[] gstinArray = reportModuleCommonRepo.getGstinFromDB(panOrGstinList.get(0));
            // here we convert GSTIN string array into the string.
            gstinList = Arrays.toString(gstinArray);

        } else if (ReportsConstants.GSTIN.equals(panOrGstin)) {
            // here we get GSTIN list from request body and convert it into
            // string
            gstinList = panOrGstinList.toString();
        }
        return gstinList.replace("[", "").replace("]", "").replace("{", "").replace("}", "").replace(" ", "");

    }

    private String getMonthList(String monthOrYear, List<String> monthOrYearList) {

        String monthList = "";
        if (ReportsConstants.YEAR.equals(monthOrYear)) {

            // here we get all Month into a string array according to single
            // yearId
            // from database.
            String[] monthArray = reportModuleCommonRepo.getMonthFromDB(monthOrYearList.get(0));
            // here we convert Month string array into the string.
            monthList = Arrays.toString(monthArray);

        } else if (ReportsConstants.MONTH.equals(monthOrYear)) {
            // here we get Month list from request body and convert it into
            // string
            monthList = monthOrYearList.toString();
        }
        return monthList.replace("[", "").replace("]", "").replace("{", "").replace("}", "").replace(" ", "");

    }

}
