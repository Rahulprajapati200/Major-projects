package com.bdo.bvms.common.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.dto.EntityMasterResDTO;
import com.bdo.bvms.common.model.EntityMaster;
import com.bdo.bvms.common.repository.IEntityMasterRepository;
import com.bdo.bvms.common.service.IEntityMasterService;

@Service

public class EntityMasterServiceImpl implements IEntityMasterService {

    @Autowired
    private IEntityMasterRepository entityMasterRepositoryImpl;

    @Override
    public EntityMasterResDTO getEntityMaster(Integer userId) {
        EntityMaster em = entityMasterRepositoryImpl.getEntityMaster(userId);
        return EntityMasterResDTO.builder().entityId(em.getEntityId()).pan(em.getPan()).gstin(em.getGstin()).build();

    }

    @Override
    public List<EntityMasterResDTO> getEntityMasterList(List<String> searchList, String panOrGstin,
                    Integer entityTypeId) {
        List<EntityMaster> entityMasterList = entityMasterRepositoryImpl.getEntityMasterList(searchList, panOrGstin,
                        entityTypeId);
        return entityMasterList.stream().map(entityMaster -> {
            return EntityMasterResDTO.builder().gstin(entityMaster.getGstin()).pan(entityMaster.getPan())
                            .entityId(entityMaster.getEntityId()).build();
        }).collect(Collectors.toList());
    }

}
