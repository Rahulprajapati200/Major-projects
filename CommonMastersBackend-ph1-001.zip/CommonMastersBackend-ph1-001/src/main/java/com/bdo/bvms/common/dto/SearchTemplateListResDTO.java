package com.bdo.bvms.common.dto;

import com.bdo.bvms.common.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SearchTemplateListResDTO {

    private Integer id;
    private String name;
    private int code;
    private String uploadedBy;

    private String baseTemplate;
    private Integer isDisabled;
    private Integer pldModuleId;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI)
    private String uploadedOn;
    private String refId;

}
