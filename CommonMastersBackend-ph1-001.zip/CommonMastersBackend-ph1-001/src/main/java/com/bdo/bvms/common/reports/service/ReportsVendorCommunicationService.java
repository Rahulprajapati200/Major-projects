package com.bdo.bvms.common.reports.service;

import java.sql.SQLException;
import java.util.Map;

import com.bdo.bvms.common.dto.VendorCommunicationEmailStatusReqDTO;
import com.bdo.bvms.common.dto.VendorCommunicationInwardReqDTO;
import com.bdo.bvms.common.dto.VendorCommunicationReconciliationReqDTO;
import com.bdo.bvms.common.exceptions.AppBusinessException;

public interface ReportsVendorCommunicationService {

    Map<String, Object> getVendorCommunicationInwarReports(VendorCommunicationInwardReqDTO vendorCommunicationInwardReq)
                    throws AppBusinessException, SQLException;

    Map<String, Object> getVendorCommunicationReconciliationReports(
                    VendorCommunicationReconciliationReqDTO vendorCommunicationReconciliationReq)
                    throws AppBusinessException, SQLException;

    Map<String, Object> getVendorCommunicationEmailStatusReports(
                    VendorCommunicationEmailStatusReqDTO vendorCommunicationEmailStatusReq)
                    throws AppBusinessException, SQLException;

}
