package com.bdo.bvms.common.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class FilingVeiwReportsResDTO {

    String gstinTaxpayer;
    String gstinVendor;
    String pldGstinStatus;
    String returnType;
    String inviteSentByUser;
    String april;
    String may;
    String june;
    String july;
    String august;
    String september;
    String october;
    String november;
    String december;
    String january;
    String february;
    String march;

}
