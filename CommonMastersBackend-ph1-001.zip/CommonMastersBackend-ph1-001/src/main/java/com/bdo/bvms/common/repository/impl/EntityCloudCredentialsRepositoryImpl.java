package com.bdo.bvms.common.repository.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.model.EntityCloudCredentials;
import com.bdo.bvms.common.repository.IEntityCloudCredentialsRepository;
import com.bdo.bvms.common.sql.CommonMstSQL;

@Repository
public class EntityCloudCredentialsRepositoryImpl implements IEntityCloudCredentialsRepository {

	@Autowired
	private JdbcTemplate jdbcTemplateMst;
	
	
	@Override
	public EntityCloudCredentials searchEntityCloudCredentials(int entityId) {
		
		List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));
	  	
	      
	      Map<String, Object> results = jdbcTemplateMst.call(new CallableStatementCreator() {

	          @Override
	          public CallableStatement createCallableStatement(Connection con) throws SQLException {
	              CallableStatement cs = con.prepareCall(CommonMstSQL.GET_AZURE_CREDENTIAL_FROM_DB_PROC_CALL);
	              cs.setInt(1, entityId);
	              return cs;
	          }
	      }, parameters);

	      List<Map<String, Object>> resultset = (List<Map<String, Object>>) results.get("#result-set-1");
	      if(resultset.isEmpty()) {
	      	return null;
	      }

	      EntityCloudCredentials cloudCred= new EntityCloudCredentials();
	      cloudCred.setUrl(String.valueOf(resultset.get(0).get("url")));
	      cloudCred.setContainerName(String.valueOf(resultset.get(0).get("container_name")));
	      
	      return cloudCred;

	}

}
