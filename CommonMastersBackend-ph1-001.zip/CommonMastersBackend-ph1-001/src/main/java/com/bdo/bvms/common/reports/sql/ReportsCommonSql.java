package com.bdo.bvms.common.reports.sql;

import java.math.BigInteger;

public class ReportsCommonSql {

    public static final String GET_APP_KEY = new StringBuilder(
                    "select KeyVALUE from system_parameter where KeyNAME= ? ").toString();;

    public static final String getTaxpayerGstinFromDbSql(String schemaName) {

        return new StringBuilder("select distinct from_base64(gstin) from ").append(schemaName)
                        .append(".am_entity_master where pan=?").toString();
    }

    public static final String GET_MONTH_LIST_FROM_DB_SQL = new StringBuilder(
                    "select fp from sm_return_periods where year_id=?").toString();

    public static final String GET_SUGGESTED_REPORTS_DETAILS = new StringBuilder(
                    "select arcpld.name,arcpld.report_code,spld.name as 'moduleName',arcpld.description from am_report_config  arcpld\r\n"
                                    + " left join sm_pickup_list_details spld\r\n"
                                    + "on arcpld.pld_module_id=spld.code  and arcpld.pld_module_id=63 where arcpld.is_module=0 and arcpld.parent_id=2 limit ?")
                                                    .toString();
    public static final String GET_SUGGESTED_REPORTS_TOTAL_COUNT = new StringBuilder(
                    "select count(1) from am_report_config  arcpld\r\n" + " left join sm_pickup_list_details spld\r\n"
                                    + "on arcpld.pld_module_id=spld.code  and arcpld.pld_module_id=63 where arcpld.is_module=0 and arcpld.parent_id=2 ")
                                                    .toString();

    public static String getRecentReportsTotalCount(String schemaName) {
        return new StringBuilder("select count(1) from report_user_access_log rual \r\n" + "left join " + schemaName
                        + ".am_report_config arc\r\n" + " on arc.id= rual.report_config_id \r\n" + " left  join "
                        + schemaName + ".am_report_config arc1\r\n"
                        + "on arc1.pld_module_id=arc.pld_module_id and arc1.is_module=1\r\n" + "  left join "
                        + schemaName + ".am_user_master aum on rual.user_id=aum.user_id where aum.entity_id=? \r\n"
                        + " order by rual.access_at desc").toString();
    }

    public static String getRecentReportsDetails(String schemaName) {
        return new StringBuilder(
                        "select arc2.report_code as 'submodule_id',arc1.pld_module_id,arc1.name as module_name ,from_base64(aum.first_name) access_by,arc.name,arc.report_code,rual.access_at,arc.description from report_user_access_log rual \r\n"
                                        + "left join " + schemaName + ".am_report_config arc\r\n"
                                        + " on arc.id= rual.report_config_id \r\n" + "    left join " + schemaName
                                        + ".am_report_config arc1\r\n"
                                        + "on arc1.pld_module_id=arc.pld_module_id and arc1.is_module=1\r\n"
                                        + " left    join " + schemaName
                                        + ".am_user_master aum on rual.user_id=aum.user_id \r\n" + " left       join "
                                        + schemaName
                                        + ".am_report_config arc2 on arc.parent_id=arc2.id where aum.entity_id=? "
                                        + " order by rual.access_at desc limit ?").toString();
    }

    public static String getPinnedReportsTotalCount(String schemaName) {
        return new StringBuilder("select count(1) from reports_personalization rp join " + schemaName
                        + ".am_report_config rc on\r\n" + "rp.report_config_id=rc.id \r\n" + "left join " + schemaName
                        + ".sm_pickup_list_details ld on rc.pld_module_id=ld.code \r\n" + "left join " + schemaName
                        + ".am_user_master aum on rp.pinned_by=aum.user_id \r\n"
                        + "where pinned_by=? and is_report=1 and is_active=1  and is_pinned=1  and aum.entity_id=? ")
                                        .toString();
    }

    public static String getPinnedReportsDetails(String schemaName) {
        return new StringBuilder(
                        "select rc.pld_module_id, arc1.report_code as 'submodule_id',from_base64(aum.first_name) pinned_by,rp.pinned_at,rc.report_code,rc.name,rc.description,ld.name as 'module_name' from reports_personalization rp join "
                                        + schemaName + ".am_report_config rc on\r\n" + "rp.report_config_id=rc.id \r\n"
                                        + "left join " + schemaName
                                        + ".sm_pickup_list_details ld on rc.pld_module_id=ld.code \r\n" + "left join "
                                        + schemaName + ".am_user_master aum on rp.pinned_by=aum.user_id left join \r\n"
                                        + schemaName + ".am_report_config arc1 on rc.parent_id=arc1.id   \r\n"
                                        + "where pinned_by=? and rc.is_report=1 and rc.is_active=1  and is_pinned=1 and aum.entity_id=? order by rp.pinned_at desc limit ?")
                                                        .toString();
    }

    public static final String SET_PINNED_AND_UNPINNED_REPORTS = new StringBuilder(
                    "insert into reports_personalization (is_pinned,pinned_at,report_config_id,pinned_by) values(?,?,?,?)")
                                    .toString();
    public static final String UPDATE_PINNED_AND_UNPINNED_REPORTS = new StringBuilder(
                    "update reports_personalization set is_pinned=?,pinned_at=? where report_config_id=? and pinned_by=?")
                                    .toString();
    public static final String COUNT_OF_PINNED_AND_UNPINNED_REPORTS = new StringBuilder(
                    "select count(1) from reports_personalization where report_config_id=? and pinned_by=?").toString();

    public static final int YEAR1718 = 2;
    public static final int YEAR1819 = 3;
    public static final int YEAR1920 = 4;
    public static final int YEAR2021 = 5;
    public static final int YEAR2122 = 6;
    public static final int YEAR2223 = 7;
    public static final int YEAR2324 = 8;

    public static final String GET_AZURE_CREDENTIAL_FROM_DB = "select url,container_name from sm_entity_cloud_credentials where entity_id=? AND type=?";

    public static final String INSERT_BACKGROUNG_REPORTS_DETAILS = "insert into reports_background_jobs(report_code,pld_status,report_generated_at,requested_by,requested_at,file_name) values(?,?,?,?,?,?)";
    // public static final String UPDATE_BACKGROUNG_REPORTS_DETAILS = "update
    // reports_background_jobs set pld_status=?,file_name=?,
    // record_count=?,file_path=? where requested_by=? and requested_at=?";
    public static final String UPDATE_BACKGROUNG_REPORTS_DETAILS = "update reports_background_jobs set pld_status=?,file_name=?, record_count=?,file_path=? where requested_by=? and id=?";

    public static final String QUERY_FOR_GETTING_CONTAINER_NAME = "select container_name from sm_entity_cloud_credentials where entity_id=?";

    public static final String QUERY_FOR_GETTING_CONTAINER_NAME_FROM_SYSTEM_PARAMETER = "select KeyVALUE from system_parameter where KeyNAME = ?";

    public static final String QUERY_FOR_GETTING_FILE_URL = "select KeyVALUE from system_parameter where keyNAME='Azure_storage_base_url'";

    public static String getBackgroudReportsDataQuery(String schemaName) {
        return new StringBuilder(
                        "select  from_base64(aum.first_name) requested_by,rbj.requested_at, rbj.file_path, rbj.file_name, spld.name as 'status', arcc.name as module_name from reports_background_jobs rbj left join  ")
                                        .append(schemaName)
                                        .append(".sm_pickup_list_details spld on rbj.pld_status = spld.code left join ")
                                        .append(schemaName)
                                        .append(".am_report_config arc on rbj.report_code = arc.report_code left join ")
                                        .append(schemaName)
                                        .append(".am_report_config arcc on arcc.pld_module_id = arc.pld_module_id and arcc.is_module = 1 left join ")
                                        .append(schemaName)
                                        .append(".am_user_master aum on rbj.requested_by=aum.user_id ")
                                        .append("where spld.sm_pick_mst_id = 23 and aum.entity_id=? order by rbj.report_generated_at desc limit ?")
                                        .toString();

    }

    public static String getReportsSubmoduleList(String schemaName) {
        return new StringBuilder("select name , report_code from ").append(schemaName).append(
                        ".am_report_config where pld_module_id=? and is_report=0 and is_module=0 and  COALESCE(is_custom_report,0)=0")
                        .toString();

    }

    public static String getSubmodulewiseReportList(String schemaName, int reportPerentId, String isCustomTemplate) {
        if (isCustomTemplate.equals("0")) {
            return new StringBuilder("select name ,report_code from ").append(schemaName)
                            .append(".am_report_config where pld_module_id=? and is_report=1 and parent_id="
                                            + reportPerentId
                                            + " and is_module=0 and  COALESCE(is_custom_report,0)=0 and is_active=1")
                            .toString();

        }
        return new StringBuilder("select name,  report_code from ").append(schemaName).append(
                        ".am_report_config where pld_module_id=? and is_report=1  and is_module=0  and is_active=1 and is_custom_report="
                                        + isCustomTemplate)
                        .toString();
    }

//    public static String getSavedCustomizeColumnList(String schemaName) {
//
//        return new StringBuilder(
//                        "select     column_id, column_name, is_mandatory, CASE WHEN is_mandatory = 1 THEN 1 ELSE CASE WHEN MapExists = 0 THEN 1 ELSE is_Selected END END as is_Selected, sort_order \r\n"
//                                        + "from ( select gridmap.column_key as column_id ,gridTab.column_name, gridTab.is_mandatory, 1 as is_Selected, gridmap.sort_order "
//                                        + ", CASE WHEN EXISTS (SELECT 1 FROM report_custom_columns_user_settings Where user_id = gridmap.user_id ) THEN 1 ELSE 0 END AS MapExists \r\n"
//                                        + "            from " + schemaName
//                                        + ".am_reports_customize_column gridTab inner Join report_custom_columns_user_settings gridmap on gridTab.column_key = gridmap.column_key \r\n"
//                                        + "    where gridmap.report_code = ? and gridmap.user_id = ?         \r\n"
//                                        + "    Union     \r\n"
//                                        + "    select gridTab.column_key  as column_id ,gridTab.column_name,gridTab.is_mandatory,0 as is_Selected, gridTab.sort_order "
//                                        + ", CASE WHEN EXISTS (SELECT 1 FROM report_custom_columns_user_settings Where user_id = ? ) THEN 1 ELSE 0 END AS MapExists \r\n"
//                                        + "    from " + schemaName
//                                        + ".am_reports_customize_column gridTab  where is_active = 1 \r\n"
//                                        + "    and column_key not in ( select column_key from report_custom_columns_user_settings where user_id = ? ) \r\n"
//                                        + "            and gridTab.report_code = ?) a   order by a.sort_order")
//                                                        .toString();
//    }

    public static String getSavedCustomizeColumnList(String schemaName) {

        return new StringBuilder(
                        " select rcc.column_key as 'column_id',rcc.column_name ,rcc.is_mandatory , (case when us.column_key is null then 0 else 1 end) as is_Selected ,\r\n"
                                        + "       IFNULL(us.sort_order,rcc.sort_order) as sort_order from " + schemaName
                                        + ".am_reports_customize_column rcc\r\n"
                                        + "       left join report_custom_columns_user_settings us on us.column_key=rcc.column_key and us.user_id=? where rcc.report_code=? and rcc.is_active = 1 and rcc.is_invoice_level_vendor_comm = ? order by   IFNULL(us.sort_order,rcc.sort_order)")
                                                        .toString();
    }

    public static String deletePreviousRecords() {

        return new StringBuilder("delete from report_custom_columns_user_settings where report_code=? and created_by=?")
                        .toString();
    }

    public static String insertNewCustomizeColumnRecord() {

        return new StringBuilder(
                        "INSERT INTO report_custom_columns_user_settings(user_id,column_key,report_code,created_at,created_by,sort_order) values(?,?,?,?,?,?)")
                                        .toString();
    }

    public static String getDynamicHeadersCount(String mstDatabseName) {
        return new StringBuilder("select count(1) from report_custom_columns_user_settings rcus left join "
                        + mstDatabseName + ".am_reports_customize_column arcc\r\n"
                        + "on rcus.column_key=arcc.column_key where rcus.user_id=? and rcus.report_code=? ").toString();
    }

    public static String getDynamicHeaders(String mstDatabseName) {
        return new StringBuilder(
                        "select column_width,customize_column_name,column_name,field_name from report_custom_columns_user_settings rcus left join "
                                        + mstDatabseName + ".am_reports_customize_column arcc\r\n"
                                        + "on rcus.column_key=arcc.column_key where rcus.user_id=? and rcus.report_code=? ")
                                                        .toString();
    }

    public static String getDefaultHeaders() {
        return new StringBuilder(
                        "select column_name,customize_column_name,column_width,sort_order,field_name from am_reports_customize_column  where report_code=?")
                                        .toString();
    }

    public static String getBackgroudReportsTotalCount(String schemaName) {
        return new StringBuilder("select  count(1) from reports_background_jobs rbj left join  ").append(schemaName)
                        .append(".sm_pickup_list_details spld on rbj.pld_status = spld.code left join ")
                        .append(schemaName)
                        .append(".am_report_config arc on rbj.report_code = arc.report_code left join ")
                        .append(schemaName)
                        .append(".am_report_config arcc on arcc.pld_module_id = arc.pld_module_id and arcc.is_module = 1 left join ")
                        .append(schemaName).append(".am_user_master aum on rbj.requested_by=aum.user_id ")
                        .append("where spld.sm_pick_mst_id = 23 and aum.entity_id=? order by rbj.report_generated_at desc ")
                        .toString();
    }

    public static final String GET_COUNT_OF_ACCESS_LOG = new StringBuilder(
                    "select Count(1) from report_user_access_log where report_config_id=? and user_id=? and entity_id=? and role_type_id=?")
                                    .toString();

    public static final String UPDATE_ACCESS_LOG = new StringBuilder("\r\n"
                    + "update report_user_access_log set access_at=? where report_config_id=? and user_id=? and entity_id=? and role_type_id=?\r\n"
                    + "").toString();

    public static final String INSERT_INTO_ACCESS_LOG = new StringBuilder(
                    "insert into report_user_access_log (access_at,report_config_id,user_id,entity_id,role_type_id) values(?,?,?,?,?)")
                                    .toString();

    public static final String GET_MODULE_NAME_AND_CODE = new StringBuilder(
                    "select name,pld_module_id from am_report_config where is_module=1;").toString();

    public static String getCustomizeColumnCount() {

        return new StringBuilder("  select count(1) from report_custom_columns_user_settings where user_id=? \r\n"
                        + "       and report_code=? ").toString();
    }

    public static String getDefaultCustomizeColumns() {

        return new StringBuilder(" select column_key, column_name ,is_mandatory ,1 as is_Selected ,\r\n"
                        + "        sort_order from am_reports_customize_column  \r\n"
                        + "  where report_code=? AND is_active = 1 and  is_invoice_level_vendor_comm =? order by sort_order")
                                        .toString();

    }

    public static final String GET_PARENT_ID_OF_A_REPORT = new StringBuilder(
                    "select id from am_report_config where report_code=? ").toString();

    public static final String GET_COLUMN_NAME_FROM_DB_SQL = new StringBuilder(
                    "select column_name from am_reports_customize_column where report_code=? AND is_active = 1 and is_invoice_level_vendor_comm =?")
                                    .toString();

    public static final String QUERY_FOR_ISCUSTOM_TEMPLATE = new StringBuilder(
                    "select is_custom_report from am_report_config where report_code= ?").toString();

    public static final String GET_FIRST_AND_LAST_NAME = "select concat(from_base64(first_name),\" \",from_base64(last_name))as'user_name' from am_user_master where user_id=?";

    public static String getCustomDefaultHeaders() {

        return new StringBuilder(
                        "SELECT * from (select  rcc.column_key as 'column_key',ifNull(cm.template_column, rcc.column_name) as 'column_name',rcc.customize_column_name,"
                                        + "  rcc.is_mandatory,1 as is_Selected,rcc.column_width,rcc.sort_order,rcc.field_name from am_reports_customize_column rcc \r\n"
                                        + " JOIN am_template_column_configuration cc ON cc.column_name = rcc.column_name AND cc.pld_template_id = ? "
                                        + " JOIN am_custom_template_column_mapping cm ON cm.am_template_column_configuration_id = cc.id AND cm.custom_template_name_id = ? "
                                        + " WHERE rcc.report_code = ?  UNION ALL select  rcc.column_key as 'column_key',rcc.column_name as 'column_name',rcc.customize_column_name,"
                                        + " rcc.is_mandatory,1 as is_Selected,rcc.column_width,rcc.sort_order,rcc.field_name from am_reports_customize_column rcc "
                                        + " WHERE  rcc.report_code = ? AND rcc.is_active = 1  and rcc.is_invoice_level_vendor_comm =? AND rcc.customize_column_name IN ('error_code', 'error_message'))AA order by sort_order;")
                                                        .toString();

    }

    public static final String GET_INSERT_INTO_LOGPROCEXECUTION = new StringBuilder(
                    "insert into log_proc_execution_time (start_time) values(?)").toString();

    public static final String GET_UPDATE_INTO_LOGPROCEXECUTION = new StringBuilder(
                    "update log_proc_execution_time set end_time =? ,proc_parameters=?,proc_name=? where id=?")
                                    .toString();

    public static final String GET_MAIL_BY_USER_ID = new StringBuilder(
                    "select login_id as email from am_user_master where user_id=?").toString();

    public static final String GET_FIRSTNAME_BY_USER_ID = new StringBuilder(
                    "select from_base64(first_name) from am_user_master where user_id=?\r\n").toString();
    public static final String GET_LASTNAME_BY_USER_ID = new StringBuilder(
                    "select from_base64(last_name) from am_user_master where user_id=?\r\n").toString();

    public static final String UPDATE_MAIL_BOX = new StringBuilder(
                    "insert into mail_box (mail_to,mail_from,mail_subject,mail_body,first_name,last_name,error_success) values(?,?,?,?,?,?,?)")
                                    .toString();

    public static final String GET_SYSTEM_MAIL = new StringBuilder(
                    "SELECT KeyVALUE FROM system_parameter where KeyNAME='system_email_id'").toString();

    public static String getMailDetails(BigInteger id) {
        return "select * from mail_box where id=" + id;
    }

    public static String getSearchReportsTotalCount(String mstDatabseName, String searchParameters) {

        return new StringBuilder("select Count(1) from " + mstDatabseName + ".am_report_config rc left join "
                        + mstDatabseName + ".sm_pickup_list_details ld on rc.pld_module_id = ld.code left join "
                        + mstDatabseName + ".am_report_config arc1 on rc.parent_id = arc1.id "
                        + "where rc.is_report = 1 and rc.is_active = 1 and rc.name like '%" + searchParameters + "%'")
                                        .toString();
    }

    public static String getSearchReportsDetails(String mstDatabseName, String searchParameters) {

        return new StringBuilder("select rc.pld_module_id, arc1.report_code as 'submodule_id',"
                        + " rc.report_code, rc.name, rc.description, ld.name as 'module_name' from " + mstDatabseName
                        + ".am_report_config rc left join " + mstDatabseName
                        + ".sm_pickup_list_details ld on rc.pld_module_id = ld.code left join " + mstDatabseName
                        + ".am_report_config arc1 on rc.parent_id = arc1.id "
                        + "where rc.is_report = 1 and rc.is_active = 1 and rc.name like '%" + searchParameters + "%' "
                        + "limit ? ").toString();
    }

}
