package com.bdo.bvms.common.sql;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Pageable;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.impl.UploadSQL;

public class CommonMstSQL {

    private CommonMstSQL() {
        super();
    }

    public static String getFpMonths(Pageable page, String searchFilterValue) {
        return "select return_period_id,fp,fp_description from sm_return_periods where fp_description like '%"
                        + searchFilterValue + "%'" + " order by return_period_id desc " + Constants.LIMIT
                        + page.getPageSize() + Constants.OFFSET + page.getOffset();
    }

    public static final String GET_WORKFLOW_COMMUNICATION_BY_ID_SQL = new StringBuilder(
                    "select id,  tvcr_id, parent_id, taxpayer_gstin, vendor_gstin, wf_mst_id, post_to, subject, body, is_new_communication, created_at, created_by,post_from,is_vendor  from workflow_communication\r\n")
                                    .append("where id = ? ").toString();
    public static final String INSERT_WORKFLOW_COMMUNICATION_SQL = new StringBuilder(
                    "INSERT INTO workflow_communication \r\n").append(
                                    "(  tvcr_id, parent_id, taxpayer_gstin, vendor_gstin, wf_mst_id, post_to, subject, body, is_new_communication, created_at, created_by, is_vendor , post_from,comment_type ) ")
                                    .append("VALUES ( ?,?,?,?,?,?,?,?,?,now(),?,?,?,?)").toString();

    public static String checkIfContactMappingExistsByColumn(String columnName) {
        return new StringBuilder("SELECT id, contact_id, tvcr_id, gstin_taxpayer, gstin_vendor,\n")
                        .append(" first_name, last_name, email, mobile,  is_primary_contact, created_at, \n")
                        .append(" created_by, modified_at, modified_by ,aadhar_vendor FROM taxpayer_vendor_contact_mapping \r\n")
                        .append("  where   tvcr_id = ?  and ").append(columnName).append(" = ? limit 1").toString();

    }

    public static String checkIfContactMappingExistsByColumnTaxpayerJourney() {
        return new StringBuilder("SELECT id, contact_id, tvcr_id, gstin_taxpayer, gstin_vendor,\n")
                        .append(" first_name, last_name, email, mobile,  is_primary_contact, created_at, \n")
                        .append(" created_by, modified_at, modified_by ,aadhar_vendor FROM taxpayer_vendor_contact_mapping \r\n")
                        .append("  where   tvcr_id = ? limit 1").toString();

    }

    public static final String GET_WORKFLOW_COMMUNICATION_BY_PARENT_ID_SQL = new StringBuilder(
                    "select  id,tvcr_id, parent_id, taxpayer_gstin, vendor_gstin, wf_mst_id, post_to, subject, body, is_new_communication, created_at, created_by  ,post_from,is_vendor,comment_type from workflow_communication\r\n")
                                    .append(" where taxpayer_gstin=( select taxpayer_gstin from workflow_communication \r\n"
                                                    + "  where wf_mst_id=? limit 1) and vendor_gstin=( select vendor_gstin from workflow_communication \r\n"
                                                    + "  where wf_mst_id=? limit 1) ")
                                    .toString();

    public static final String GET_PICKUP_MASTER_SQL = new StringBuilder(Constants.SELECT_PLD_COLUMNS)
                    .append(Constants.FROM_PLD).append(Constants.JOIN_PICKUP_MASTER_PLD)
                    .append(Constants.JOIN_USERMASTER_PLD).append(" where pm.name =?   order by pld.sort_order asc ")
                    .toString();

    public static final String GET_PICKUP_DETAIL_BY_NAME_CODE_SQL = new StringBuilder(Constants.SELECT_PLD_COLUMNS)
                    .append(Constants.FROM_PLD).append(Constants.JOIN_PICKUP_MASTER_PLD)
                    .append(Constants.JOIN_USERMASTER_PLD)
                    .append(" where pm.name =? and pld.code=? order by pld.sort_order asc ").toString();

    public static String getFpYear(Pageable page, String financialYearId, String filterSearchValue) {
        String sql;
        String subQuery = " order by year_id desc";
        if (!StringUtils.isBlank(financialYearId)) {
            sql = UploadSQL.GET_FINACIAL_YEAR + " year_id in (" + financialYearId + ")" + " or financial_year "
                            + "like '%" + filterSearchValue + "%'" + subQuery + Constants.LIMIT + page.getPageSize()
                            + Constants.OFFSET + page.getOffset();
        } else {
            if (StringUtils.isNotBlank(filterSearchValue)) {
                sql = UploadSQL.GET_FINACIAL_YEAR + " financial_year " + "like '%" + filterSearchValue + "%'" + subQuery
                                + Constants.LIMIT + page.getPageSize() + Constants.OFFSET + page.getOffset();
            } else {
                sql = UploadSQL.GET_FINACIAL_YEAR_QUERY + subQuery + Constants.LIMIT + page.getPageSize()
                                + Constants.OFFSET + page.getOffset();
            }

        }
        return sql;
    }

    public static final String GET_CUSTOM_TEMPLATE_OPTIONS_SQL = new StringBuilder(
                    "select cto.id,pld.name,template_column_config_id from am_custom_template_options cto ").append(
                                    " join sm_pickup_list_details pld on pld.id=cto.pld_id where template_column_config_id = ?  ")
                                    .toString();

    public static final String GET_CUSTOM_TEMPLATE_TYPE_SQL = new StringBuilder(
                    "select id,name , from_base64(first_name) user_Name,ctn.created_at from am_custom_template_name ctn ")
                                    .append(" join am_user_master um on ctn.created_by=um.user_id ")
                                    .append("where  ctn.pld_status = ?  and ctn.pan in (?)  ").toString();

    public static final String GET_CUSTOM_TEMPLATE_TYPE_BY_MODULE_SQL = new StringBuilder(
                    "select ctn.id,ctn.name ,  from_base64(first_name) user_Name,ifnull(ctn.modified_at,ctn.created_at) "
                                    + "created_at  ,ctn.pld_status, pld.name as module from am_custom_template_name ctn ")
                                                    .append(" inner  join am_user_master um on ctn.created_by=um.user_id ")
                                                    .append(" inner join    sm_pickup_list_details pld on pld.code=ctn.pld_template_id and pld.sm_pick_mst_id=? and pld.pick_key = ?  ")
                                                    .append(" inner join sm_pickup_list_details pld1 on pld1.code = pld.pick_key and pld1.sm_pick_mst_id = ? ")
                                                    .append("where  ctn.pld_status in(10,20)   ").toString();

    public static final String GET_CUSTOM_TEMPLATE_TYPE_BY_MODULE_COUNT_SQL = new StringBuilder(
                    "select count(1) from am_custom_template_name ctn ")
                                    .append("  inner join am_user_master um on ctn.created_by=um.user_id ")

                                    .append(" inner join sm_pickup_list_details pld on pld.code=ctn.pld_template_id and pld.sm_pick_mst_id=? and pld.pick_key = ?  ")
                                    .append(" inner join sm_pickup_list_details pld1 on pld1.code = pld.pick_key   and pld1.sm_pick_mst_id = ? ")
                                    .append("where  ctn.pld_status in(10,20)    ").toString();

    public static final String GET_CUSTOM_TEMPLATE_HEADER_MAPPING_SQL = new StringBuilder(
                    "SELECT  cc.column_name as standardHeader , cm.template_column as customHeader \n")
                                    .append(" FROM am_template_column_configuration cc ")
                                    .append(" INNER JOIN   am_custom_template_column_mapping cm ON cc.id = cm.am_template_column_configuration_id\n")
                                    .append(" where cm.custom_template_name_id=? order by cc.order_no  ").toString();

    public static String countSql(StringBuilder sql) {
        return new StringBuilder("SELECT  count(1)   from ( ").append(sql).append(") count").toString();
    }

    public static final String GET_PARENT_WORKFLOW_COMMUNICATION_BY_WF_MST_ID_SQL = new StringBuilder(
                    "select p_wc.comment_type, p_wc.id, p_wc.tvcr_id, p_wc.parent_id, p_wc.taxpayer_gstin, p_wc.vendor_gstin,p_wc.wf_mst_id,\r\n")
                                    .append(" p_wc.post_from ,\r\n")
                                    .append("p_wc.subject, p_wc.body,p_wc.is_new_communication, p_wc.created_at,\r\n")
                                    .append("p_wc.created_by,p_wc.is_vendor,sum(if(c_wc.id is not null,1,0))child_count,\r\n")
                                    .append(" p_wc.post_to ")

                                    .append("from workflow_communication p_wc left join workflow_communication c_wc on c_wc.parent_id=p_wc.id where p_wc.wf_mst_id =? and p_wc.is_new_communication = ?")
                                    .toString();

    public static final String INSERT_CUSTOM_TEMPLATE_NAME_SQL = new StringBuilder(
                    "INSERT INTO am_custom_template_name ").append(
                                    "(pld_template_id,pan,entity_id,name,created_at,created_by,pld_status,is_email_template) ")
                                    .append("VALUES(?,?,?,?,now(),?,?,?) ").toString();

    public static final String INSERT_CUSTOM_TEMPLATE_COLUMN_MAPPING_SQL = new StringBuilder(
                    "INSERT INTO am_custom_template_column_mapping\r\n").append(
                                    "(template_column,pld_template_id,pan,entity_id,am_template_column_configuration_id,is_auto_map,created_at,\r\n")
                                    .append("created_by,custom_template_name_id,status) VALUE(?,?,?,?,?,?,now(),?,?,?)  ")
                                    .toString();

    public static final String INSERT_CUSTOM_TEMPLATE_COLUMN_VALUE_MAPPING_SQL = new StringBuilder(
                    " INSERT INTO am_custom_template_column_value_mapping\r\n").append(
                                    "  (custom_template_mapping_id,option_id,`values`,entity_id,created_at,created_by)\r\n")
                                    .append("  VALUES (?,?,?,?,now(),?) ").toString();

    public static final String GET_CUSTOM_TEMPLATE_COLUMN_CONFIG_SQL = new StringBuilder(
                    "  select id,pld_template_id,column_name,data_type,size,is_mandatory,created_at,created_by,conditional_mandatory_grouping  \r\n")
                                    .append(" from am_template_column_configuration where pld_template_id = ?  order by order_no ")
                                    .toString();

    public static final String GET_CUSTOM_TEMPLATE_MAPPING_OPTIONS_MAPPINGS_SQL = new StringBuilder(
                    "select  pm.name as `name`, pld.name as `standardOption`, ifnull(cvm.`values`,pld.name) as `value`, pld.code as `code`  ")
                                    .append("from am_custom_template_column_value_mapping cvm ")
                                    .append("INNER JOIN am_custom_template_column_mapping cm ON cvm.custom_template_mapping_id= cm.id  AND cm.custom_template_name_id=? ")
                                    .append("INNER JOIN am_custom_template_options o ON  cvm.option_id = o.id ")
                                    .append("Right JOIN sm_pickup_list_details pld ON pld.id = o.pld_id ")
                                    .append("Right JOIN sm_pickup_master pm ON pm.pickup_master_id = pld.sm_pick_mst_id ")
                                    .append("where pm.name IN (?,?,?,?)").toString();

    public static final String GET_COUNT_CUSTOM_TEMPLATE_TYPE = new StringBuilder(
                    "select count(1) from am_custom_template_name ctn ")
                                    .append(" join am_user_master um on ctn.created_by=um.user_id ")
                                    .append("where ctn.pan in (?)  and ctn.pld_status = ?  ").toString();

    public static final String UPDATE_CUSTOM_TEMPLATE_PLD_STATUS = new StringBuilder(
                    "update am_custom_template_name set pld_status= ?, modified_by = ? , modified_at=now()  where id = ? ")
                                    .toString();

    public static final String GET_CUSTOM_TEMPLATE_NAME_SQL = new StringBuilder(
                    "SELECT id,pan,entity_id,pld_status,name FROM am_custom_template_name where is_email_template = ? and pan = ? and name = ? and pld_template_id = ? and pld_status<>? ")
                                    .toString();

    public static final String GET_CUSTOM_TEMPLATE_NAME_BY_ID_SQL = new StringBuilder(
                    "SELECT id,pan,entity_id,pld_status,name FROM am_custom_template_name where id = ? ").toString();

    public static final String INSERT_TEMPLATE_SAMPLE_DATA_SQL = new StringBuilder(
                    "INSERT INTO am_template_sample_data(am_custom_template_column_mapping_id,column_name,column_value,created_at,created_by) ")
                                    .append(" VALUES(?,?,?,now(),?)").toString();

    public static final String GET_CUSTOM_TEMPLATE_DETAILS_SQL = new StringBuilder(
                    "SELECT conditional_mandatory_grouping,cc.column_name, cm.pld_template_id , cc.id , cm.template_column , is_auto_map , is_mandatory , cc.data_type , cc.size , cm.id as customTemplateColumnMappingId\r\n")
                                    .append("FROM am_custom_template_column_mapping  cm\r\n")
                                    .append("join am_template_column_configuration cc on cc.id=cm.am_template_column_configuration_id  \r\n")
                                    .append("and custom_template_name_id=? and cm.status = ? order by cc.order_no  ")
                                    .toString();

    public static final String GET_CUSTOM_TEMPLATE_OPTIONS_VALUE_MAPPING_SQL = new StringBuilder(
                    "select cto.id as option_id,custom_template_mapping_id ,pld.name,template_column_config_id,\r\n")
                                    .append("cvm.values , cvm.id \r\n")
                                    .append(" from am_custom_template_options cto \r\n")
                                    .append("join sm_pickup_list_details pld on pld.id=cto.pld_id \r\n")
                                    .append("left join am_custom_template_column_value_mapping cvm on cto.id=cvm.option_id  and custom_template_mapping_id=? \r\n")
                                    .append("where template_column_config_id = ? \r\n").toString();

    public static final String GET_CUSTOM_TEMPLATE_COLUMN_MAPPING_BY_ID_SQL = new StringBuilder(
                    "select id,template_column,is_auto_map,status from am_custom_template_column_mapping where id = ?")
                                    .toString();

    public static final String UPDATE_CUSTOM_TEMPLATE_MAPPING = new StringBuilder(
                    "update am_custom_template_column_mapping\r\n").append(
                                    "set  template_column =? ,is_auto_map =? ,modified_at=now() , modified_by =? , status = ?  where id = ?")
                                    .toString();

    public static final String GET_CUSTOM_TEMPLATE_COLUMN_VALUE_MAPPING_BY_ID_SQL = new StringBuilder(
                    "select cvm.values,id,cvm.option_id from am_custom_template_column_value_mapping cvm where id = ?")
                                    .toString();

    public static final String GET_CUSTOM_TEMPLATE_COLUMN_VALUE_MAPPING_SQL = new StringBuilder(
                    "select cvm.values,id,cvm.option_id from am_custom_template_column_value_mapping cvm where custom_template_mapping_id =?\r\n")
                                    .append(" and option_id =? ").toString();

    public static final String UPDATE_CUSTOM_TEMPLATE_COLUMN_VALUE_MAPPING_SQL = new StringBuilder(
                    "update am_custom_template_column_value_mapping cvm set  cvm.values =?   where cvm.id = ?")
                                    .toString();

    public static final String GET_ENTITY_MASTER_SQL = new StringBuilder(
                    "SELECT  em.entity_id, em.entity_type_id, em.parent_id, em.parent_group_id, em.business_name, em.trade_name, em.pan, em.tan, em.gstin, em.gstin_username, em.mobile_no, em.email_id, em.curr_turnover, em.state_code, em.city_code, em.ward, em.center_jurisdiction, em.composition, em.date_commencement, em.cern_no, em.service_tax_no, em.vat_no, em.sales_tax_no, em.iec_no, em.temp_reg_no, em.cin_no, em.business_nature, em.business_constitution, em.alt_email, em.alt_mobile_no, em.alt_tel, em.out_hsn_summ_conf, em.in_hsn_summ_conf, em.itc_avail_conf, em.template_type_id, em.user_count_limit, em.gstin_count_limit, em.transaction_count_limit, em.entity_status\r\n")
                                    .append("FROM am_entity_master em    \r\n")
                                    .append("INNER JOIN am_user_master um ON um.entity_id = em.entity_id     \r\n")
                                    .append("INNER JOIN sm_entity_type et ON et.entity_type_id = em.entity_type_id\r\n")
                                    .append("WHERE um.user_id = ?     AND et.entity_type_id != ? limit 1").toString();

    public static final String GET_ENTITY_MASTER_LIST_SQL = new StringBuilder(
                    "SELECT em.entity_id, from_base64(em.pan) pan,   from_base64(em.gstin) gstin,  from_base64(em.gstin_username),   from_base64(em.email_id) \r\n")
                                    .append("                FROM  am_entity_master em where ").toString();

    public static final String GET_ENTITY_CLOUD_CREDENTIALS_SQL = new StringBuilder(
                    "SELECT id,    entity_id,    type,    url,    user_id,    password,    is_active , container_name \r\n")
                                    .append(" FROM sm_entity_cloud_credentials where entity_id = ? ").toString();

    public static final String GET_AZURE_CREDENTIAL_FROM_DB_PROC_CALL = "{ call GET_CLOUD_STORAGE_CREDENTIALS (?) }";

    public static final String GET_PICKUP_MASTER_DEFAULT_TEMPLATE_SQL = new StringBuilder(
                    "Select pld.id,sm_pick_mst_id, pld.name, code, short_desc, long_desc,pick_key, sort_order,pld.status, pld.created_at, pld.created_by,from_base64(first_name) userName \r\n")
                                    .append(" from   sm_pickup_list_details pld\r\n")
                                    .append(" INNER JOIN sm_pickup_master pm ON pm.pickup_master_id = pld.sm_pick_mst_id  ")
                                    .append("  join am_user_master um on pld.created_by=um.user_id and pick_key in(63,65,66,67)  ")
                                    .append(" where pm.name =?   order by pld.sort_order asc ").toString();

    public static final String GET_PLD_BY_NAME_PICK_KEY_MODULE_DATA_SQL = new StringBuilder(
                    "Select modulepld.name as moduleName,pld.id,pld.sm_pick_mst_id, pld.name, pld.code, pld.status as pld_status,pld.short_desc, pld.long_desc,pld.pick_key, pld.sort_order,pld.status, pld.created_at, pld.created_by,from_base64(first_name) userName \r\n")
                                    .append(" from sm_pickup_list_details pld\r\n")
                                    .append(" INNER JOIN sm_pickup_master pm ON pm.pickup_master_id = pld.sm_pick_mst_id  ")
                                    .append("  join am_user_master um on pld.created_by=um.user_id  ")
                                    .append(" inner join sm_pickup_list_details modulepld on   modulepld.code = pld.pick_key  and modulepld.sm_pick_mst_id = ? ")
                                    .append(" where pm.name =?  and pld.pick_key=? and pld.status=10 order by pld.sort_order asc ")
                                    .toString();

    public static final String GET_PLD_BY_NAME_PICK_KEY_COUNT_SQL = new StringBuilder("Select count(1) \r\n")
                    .append(" from ( \r\n").append(GET_PLD_BY_NAME_PICK_KEY_MODULE_DATA_SQL).append(" ) count")
                    .toString();

    public static final String GET_CUSTOM_TEMPLATE_SAMPLE_DATA = new StringBuilder(
                    "SELECT tsd.column_name , tsd.column_value,custom_template_name_id FROM am_template_sample_data tsd\r\n")
                                    .append("join am_custom_template_column_mapping cm on cm.id=tsd.am_custom_template_column_mapping_id \r\n")
                                    .append("and cm.custom_template_name_id = ? order by tsd.id asc ").toString();

    public static final String GET_CUSTOM_TEMPLATE_MODULE_LIST_SQL = new StringBuilder("select *   from (\r\n").append(
                    "SELECT modulepld.name as modulename,modulepld.code moduleid, SUM(CASE WHEN ctn.pld_template_id is null THEN 0 ELSE 1 END) count \r\n")
                    .append("from sm_pickup_list_details modulepld\r\n")
                    .append("left join sm_pickup_list_details templatepld on   modulepld.code = templatepld.pick_key \r\n")
                    .append("and templatepld.sm_pick_mst_id =   ?\r\n")
                    .append("left join am_custom_template_name ctn on templatepld.code=ctn.pld_template_id   and ctn.pan in (?)  and ctn.pld_status in(10,20)  \r\n")
                    .append("where modulepld.sm_pick_mst_id  =? and modulepld.pick_key = 110 \r\n").toString();

    public static final String GET_DEFAULT_TEMPLATE_MODULE_LIST_SQL = new StringBuilder("select * from (\r\n").append(
                    "SELECT modulepld.name as modulename,modulepld.code moduleid, SUM(CASE WHEN templatepld.sm_pick_mst_id is null THEN 0 ELSE 1 END) count \r\n")
                    .append("from sm_pickup_list_details modulepld\r\n")
                    .append("left join sm_pickup_list_details templatepld on   modulepld.code = templatepld.pick_key \r\n")
                    .append("and templatepld.sm_pick_mst_id = ?\r\n").append("where modulepld.sm_pick_mst_id=? \r\n")
                    .append("group by modulepld.code,modulepld.name ) moduledata").toString();

    public static final String GET_BVMS_ERROR_CODES_MAPPINGS_SQL = new StringBuilder(
                    "SELECT ErrorCode  as errorCode , LongDescription as errorDescription FROM bvms_error where ErrorCode is not null")
                                    .toString();

    public static String getPreviewFileUploadUrl(String mstDatabaseName) {

        return new StringBuilder(
                        "SELECT sc.container_name as 'containerName', '' as fileUrl, base_file_location as 'basefileName' , error_file_location as 'errorfileName' FROM upload_log ul \n")
                                        .append(" left join " + mstDatabaseName
                                                        + ".sm_entity_cloud_credentials sc on ul.entity_id = sc.entity_id \n")
                                        .append(" where ul.batch_no = ?").toString();
    }

    public static String getModuleWiseCustomTemplateListSql(String mstDatabaseName) {
        return new StringBuilder("SELECT name,code FROM " + mstDatabaseName
                        + ".sm_pickup_list_details where sm_pick_mst_id=? and pick_key=?").toString();
    }

    public static String getDefalutTemplateList(String dbName) {

        return new StringBuilder("select * from (\r\n").append(
                        "SELECT modulepld.name as modulename,modulepld.code moduleid, SUM(CASE WHEN templatepld.sm_pick_mst_id is null THEN 0 ELSE 1 END) count \r\n")
                        .append("from ").append(dbName).append(".sm_pickup_list_details modulepld\r\n")
                        .append(" left join ").append(dbName)
                        .append(".sm_pickup_list_details templatepld on   modulepld.code = templatepld.pick_key \r\n")
                        .append("and templatepld.sm_pick_mst_id = ? and templatepld.status=10  \r\n")
                        .append("where modulepld.sm_pick_mst_id=? and modulepld.pick_key = 110 and modulepld.status=10  \r\n")
                        .append("group by modulepld.code,modulepld.name ) moduledata").toString();
    }

    public static String insertNewCustomizeColumnRecord(String trnsDatabseName) {
        return new StringBuilder("INSERT INTO ").append(trnsDatabseName).append(
                        ".grid_user_customize_column_mapping(user_id,customize_column_id,sort_order) values(?,?,?)")
                        .toString();
    }

    public static String getSavedCustomizeColumnList(String userId, int moduleId, int screenId, String mstDatabseName,
                    int count) {
        if (count > 0) {

            return new StringBuilder(
                            "select mastertable.column_key as column_id, mastertable.is_mandatory,(CASE WHEN map.id IS NULL THEN 0 ELSE 1 END) AS is_selected,\n")
                                            .append(" mastertable.column_screen_name,IFNULL(map.sort_order,mastertable.sort_order) as sort_order\n")
                                            .append(" from " + mstDatabseName
                                                            + ".sm_grid_customize_column mastertable  left join grid_user_customize_column_mapping map\n")
                                            .append(" on mastertable.column_key = map.customize_column_id and map.user_id= "
                                                            + userId + "\n")
                                            .append(" Where mastertable.pld_module_id= " + moduleId
                                                            + " and mastertable.tab_id= " + screenId
                                                            + " order by sort_order ")
                                            .toString();
        } else {
            return new StringBuilder(
                            "select column_key as column_id,is_mandatory,1 AS is_selected,column_screen_name,sort_order\n")
                                            .append(" from " + mstDatabseName
                                                            + ".sm_grid_customize_column where pld_module_id = "
                                                            + moduleId + " and tab_id = " + screenId)
                                            .toString();
        }

    }

    public static String getColumnCountForUser(String mstDatabseName) {
        return new StringBuilder("select count(1) from " + mstDatabseName
                        + ".sm_grid_customize_column grid inner  join grid_user_customize_column_mapping cm on grid.column_key=cm.customize_column_id \n")
                                        .append(" where grid.tab_id=? and cm.user_id = ? and grid.pld_module_id =? ")
                                        .toString();
    }

    public static String deletePreviousRecords(String mstDatabseName, String trnsDatabseName) {

        return new StringBuilder("delete from ").append(trnsDatabseName)
                        .append(".grid_user_customize_column_mapping  where user_id= ?")
                        .append(" and customize_column_id in (select column_key from ").append(mstDatabseName)
                        .append(".sm_grid_customize_column where tab_id= ? )").toString();
    }

    public static String getModuleWiseCustomTemplateListModuleWiseSql(String mstDatabaseName) {
        return new StringBuilder("SELECT name,code FROM " + mstDatabaseName
                        + ".sm_pickup_list_details where sm_pick_mst_id=? and code=?").toString();
    }

    public static final String GET_CUSTOM_EMAIL_TEMPLATE_PLACEHOLDERS_DICTIONARY_SQL = new StringBuilder(
                    "SELECT id, pld_module_id,      ref_template_id,    name,    map_value,    description,    status,\r\n")
                                    .append("    created_by,    created_at FROM sm_custom_email_template_placeholder_dictionary where pld_module_id = ? and ref_template_id =? ")
                                    .toString();

    public static final String INSERT_CUSTOM_TEMPLATE_EMAIL_SQL = new StringBuilder(
                    "INSERT INTO am_custom_template_email\r\n").append(
                                    "(custom_template_name_id,PAN,entity_id,mail_subject,mail_body,mail_footer,default_cc_receipents_email,disclaimer,\r\n")
                                    .append("is_high_importance,enable_notification_queue,ref_template_id,is_default_template,signature_logo_size_kb,signature_logo_file_ext,signature_logo_image,company_logo_size_kb , company_logo_file_ext , company_logo_image,signature_body)\r\n")
                                    .append("VALUES  (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)").toString();

    public static final String INSERT_CUSTOM_TEMPLATE_EMAIL_ARCHIVED_SQL = new StringBuilder(
                    "INSERT INTO am_custom_template_email_archived\r\n").append(
                                    "(am_custom_template_email_id,PAN,entity_id,mail_subject,mail_body,mail_footer,default_cc_receipents_email,disclaimer,\r\n")
                                    .append("is_high_importance,enable_notification_queue,ref_template_id,is_default_template,signature_logo_size_kb,signature_logo_file_ext,signature_logo_image,company_logo_size_kb , company_logo_file_ext , company_logo_image)\r\n")
                                    .append("VALUES  (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)").toString();

    public static final String getInsertCustomTemplateEmailArchiveSql(String dbName) {
        return new StringBuilder("INSERT INTO ").append(dbName).append(".am_custom_template_email_archived\r\n").append(
                        "(am_custom_template_email_id,PAN,entity_id,mail_subject,mail_body,mail_footer,default_cc_receipents_email,disclaimer,\r\n")
                        .append("is_high_importance,enable_notification_queue,ref_template_id,is_default_template,signature_logo_size_kb,signature_logo_file_ext,signature_logo_image)\r\n")
                        .append("VALUES  (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)").toString();
    }

    public static final String UPDATE_CUSTOM_TEMPLATE_EMAIL_SQL = "update am_custom_template_email set mail_subject = ? , mail_body = ? , mail_footer = ? , signature_logo_size_kb= ? ,signature_logo_file_ext = ?, signature_logo_image= ? ,company_logo_size_kb = ? , company_logo_file_ext = ? , company_logo_image = ? ,signature_body=? where custom_template_name_id = ? ";

    public static final String UPDATE_CUSTOM_TEMPLATE_EMAIL_MODIFIED_AT_SQL = "update am_custom_template_name set modified_at = now(), modified_by=?, name=? where id = ?";
    public static final String GET_CUSTOM_TEMPLATE_EMAIL_BY_NAME_ID_SQL = new StringBuilder("select id,\r\n").append(
                    "custom_template_name_id,PAN,entity_id,mail_subject,mail_body,mail_footer,ref_template_id,default_cc_receipents_email,disclaimer,\r\n")
                    .append("is_high_importance,enable_notification_queue,is_default_template,signature_logo_size_kb,signature_logo_file_ext,signature_logo_image,company_logo_size_kb , company_logo_file_ext , company_logo_image from am_custom_template_email where custom_template_name_id = ? ")
                    .toString();

    public static final String getModuleNameOfBatchNo(String mstDatabaseName, String transDatabaseName) {
        return " SELECT name FROM " + mstDatabaseName
                        + ".sm_pickup_list_details where sm_pick_mst_id=13 and code=(select pld_upload_source from "
                        + transDatabaseName + ".upload_log where batch_no=?) ";
    }

    public static final String GET_CUSTOM_TEMPLATE_EMAIL_MODULE_LIST_SQL = new StringBuilder("select *   from (")
                    .append("SELECT modulepld.name as modulename,modulepld.code moduleid, SUM(CASE WHEN tempname.pld_template_id is null THEN 0 ELSE 1 END) count  ")
                    .append(" from sm_pickup_list_details modulepld ")
                    .append(" inner join (select distinct scmtc.pld_module_id from   sm_custom_email_template_category scmtc   where scmtc.is_active= ?) cat on modulepld.code= cat.pld_module_id  ")
                    .append(" left join (select ctn.*  from  am_custom_template_name ctn   ")
                    .append(" inner join am_custom_template_email cte on cte.custom_template_name_id=ctn.id and cte.is_default_template=? and   ctn.pan in (?)  and ctn.pld_status in(?,?) ) tempname on modulepld.code=tempname.pld_template_id  ")
                    .append(" where modulepld.sm_pick_mst_id  =?  and modulepld.pick_key=110  ").toString();

    public static final String GET_CUSTOM_EMAIL_TEMPLATE_TYPE_BY_MODULE_SQL = new StringBuilder(
                    "select cte.ref_template_id,ctn.id,scmtc.pld_module_id as pldModuleId,ctn.name ,  from_base64(first_name) user_Name,ifnull(ctn.modified_at,ctn.created_at) created_at  ,ctn.pld_status, pld.name as module from am_custom_template_name ctn ")

                                    .append(" inner join am_user_master um on ifnull(ctn.modified_by,ctn.created_by)=um.user_id ")
                                    .append(" inner join am_custom_template_email cte on cte.custom_template_name_id= ctn.id  ")
                                    .append(" inner Join  sm_custom_email_template_category scmtc on cte.ref_template_id= scmtc.id ")
                                    .append("  inner join sm_pickup_list_details pld on pld.code=scmtc.pld_module_id  ")
                                    .append("where  ctn.pld_status in(?,?) and ctn.is_email_template= ?  and is_active=? and is_default_template = ? and scmtc.pld_module_id=?  ")
                                    .toString();

    public static final String GET_CUSTOM_EMAIL_TEMPLATE_BY_MODULE_COUNT_SQL = new StringBuilder(
                    "select count(1) from ( ").append(GET_CUSTOM_EMAIL_TEMPLATE_TYPE_BY_MODULE_SQL).toString();

    public static final String UPDATE_PLD_STATUS_CUSTOM_TEMPLATE = "update am_custom_template_name set pld_status=?, modified_at = NOW() where id=?";

    public static final String GET_DEFAULT_EMAIL_TEMPLATE_SQL = new StringBuilder(
                    "select mail_body,mail_subject,ctn.name from  am_custom_template_name  ctn \r\n").append(
                                    "join  am_custom_template_email cte on cte.custom_template_name_id=ctn.id and pld_template_id = ? and ref_template_id = ?\r\n")
                                    .append("and is_default_template = ?  limit 1 ").toString();

    public static final String GET_CUSTOM_EMAIL_TEMPLATE_CATEGORY_SQL = "SELECT id,pld_module_id,sub_category FROM sm_custom_email_template_category where is_active =? and pld_module_id =? ";

    public static final String GET_PLD_BY_NAME_PICK_KEY_SQL = new StringBuilder(
                    "Select  pld.code , pld.name , pld.id, pld.created_at,pld.created_by \r\n")
                                    .append(" from sm_pickup_list_details  pld\r\n")
                                    .append(" INNER JOIN sm_pickup_master pm ON pm.pickup_master_id = pld.sm_pick_mst_id  and  pm.name =? and pld.pick_key = ? ")
                                    .toString();

    public static final String GET_CUSTOM_EMAIL_TEMPLATE_MODULES_SQL = new StringBuilder(
                    "Select  distinct tc.pld_module_id , pld.name \r\n").append("from sm_pickup_list_details pld\r\n")
                                    .append("INNER JOIN sm_pickup_master pm ON pm.pickup_master_id = pld.sm_pick_mst_id  and  pm.name =? \r\n")
                                    .append("join sm_custom_email_template_category tc  on pld.code = tc.pld_module_id")
                                    .toString();

    public static final String GET_CUSTOM_EMAIL_TEMPLATE_DETAILS_SQL = new StringBuilder(
                    "select cte.ref_template_id,ctn.pld_template_id,cte.custom_template_name_id,ctn.name , cte.mail_subject,cte.mail_body, scmtc.sub_category   , pld.name as module_name  ,")
                                    .append(" cte.signature_logo_size_kb , cte.signature_logo_file_ext,cte.signature_body , cte.signature_logo_image,company_logo_size_kb , company_logo_file_ext , company_logo_image from am_custom_template_name ctn\r\n")
                                    .append(" inner join am_custom_template_email cte on cte.custom_template_name_id= ctn.id   \r\n")
                                    .append(" inner Join sm_custom_email_template_category scmtc on cte.ref_template_id= scmtc.id \r\n")
                                    .append(" inner join sm_pickup_list_details pld on pld.code=scmtc.pld_module_id \r\n")
                                    .append(" where  ctn.id = ? ").toString();

    public static final String GET_DEFAULT_TEMPLATE_EMAIL_MODULE_LIST_SQL = new StringBuilder("select *   from (")
                    .append("SELECT modulepld.name as modulename,modulepld.code moduleid, SUM(CASE WHEN tempname.pld_template_id is null THEN 0 ELSE 1 END) count  ")
                    .append(" from sm_pickup_list_details modulepld ")
                    .append(" inner join (select distinct scmtc.pld_module_id from   sm_custom_email_template_category scmtc   where scmtc.is_active= ?) cat on modulepld.code= cat.pld_module_id  ")
                    .append(" left join (select ctn.*  from  am_custom_template_name ctn   ")
                    .append(" inner join am_custom_template_email cte on cte.custom_template_name_id=ctn.id and cte.is_default_template=?  and ctn.pld_status in(?,?) ) tempname on modulepld.code=tempname.pld_template_id  ")
                    .append(" where modulepld.sm_pick_mst_id  =?  and modulepld.code in (64,66) ").toString();

    public static final String GET_DEFAULT_EMAIL_TEMPLATE_TYPE_BY_MODULE_SQL = new StringBuilder(
                    "select ctn.id,ctn.name ,  from_base64(first_name) user_Name,ifnull(ctn.modified_at,ctn.created_at) created_at  ,ctn.pld_status, pld.name as module from am_custom_template_name ctn ")

                                    .append(" inner join am_user_master um  on ctn.created_by=um.user_id ")
                                    .append(" inner join am_custom_template_email cte on cte.custom_template_name_id= ctn.id  ")
                                    .append(" inner Join  sm_custom_email_template_category scmtc on cte.ref_template_id= scmtc.id ")
                                    .append("  inner join sm_pickup_list_details pld on pld.code=scmtc.pld_module_id  ")
                                    .append("where  ctn.pld_status in(?,?) and ctn.is_email_template= ?  and is_active=? and is_default_template = ? and scmtc.pld_module_id=?  ")
                                    .toString();

    public static final String GET_CUSTOM_TEMPLATE_LIST_TYPE_BY_MODULE_SQL = new StringBuilder(
                    "select ctn.id,ctn.name ,  from_base64(first_name) user_Name,ifnull(ctn.modified_at,ctn.created_at) created_at  ,ctn.pld_status, pld.name as module from am_custom_template_name ctn ")
                                    .append(" inner join am_user_master   um on ctn.created_by=um.user_id ")
                                    .append(" inner join sm_pickup_list_details pld on    pld.code=ctn.pld_template_id and pld.sm_pick_mst_id=? and pld.pick_key = ?  ")
                                    .append(" inner join sm_pickup_list_details pld1 on pld1.code = pld.pick_key and   pld1.sm_pick_mst_id = ? ")
                                    .append("where  ctn.pld_status ='10'").toString();

    public static final String CHECK_IF_TAXPAYER_VENDOR_EXISTS_SQL = new StringBuilder().append(
                    "SELECT id, child_relation_id, entity_id, pld_data_version, pan_taxpayer, pan_vendor, gstin_taxpayer,  ")
                    .append("gstin_vendor, company_trade_name, vendor_code_erp, pld_taxpayer_type, company_legal_name, pld_gstin_status,")
                    .append("gstin_registration_date, cancellation_date, gstn_sha, center_jurisdiction, state_jurisdiction, business_constitution, ")
                    .append("business_nature, pld_source, free_search, parent_id, created_at, created_by FROM taxpayer_vendors ")
                    .append("WHERE pld_data_version = ? AND gstin_taxpayer= ? AND gstin_vendor=? limit 1 ").toString();

    public static final String QUERY_FOR_GETTING_FILE_URL = "select KeyVALUE from system_parameter where keyNAME='Azure_storage_base_url'";
    public static final String GETERRORCODEEINVOICE = "select error_code from invoice_upload_err_log where batch_no=?";

    public static final String GETERRORCODEEWAY = "select error_code from ewaybill_upload_err_log where batch_no=?";
    public static final String GET_ERRORCODE_AND_SHORTDESCRIPTION = "SELECT ErrorCode,ShortDescription FROM bvms_error";
    public static final String GETERRORCODEEWAYVENDOR = "select error_code from vendor_ewaybill_upload_err_log where batch_no=?";
    public static final String GETERRORCODEINVOICEVENDOR = "select error_code from vendor_invoice_upload_err_log where batch_no=?";
    public static final String GETALISTNAMESQL = "select distinct column_screen_name,column_screen_name,data_type from sm_grid_customize_column where pld_module_id=? \r\n"
                    + "and is_advance_search=1";

    public static String getTotalCountOfMonths(String searchedValue) {
        return "select count(return_period_id) from sm_return_periods where fp_description like '%" + searchedValue
                        + "%'";
    }

    public static String getTaxpayerEmailId(String mstDB) {
        return "select login_id from " + mstDB + ".am_user_master where user_id=? ";
    }

    public static String getUserForm(String mstDatabaseName) {
        return "select login_id from " + mstDatabaseName + ".am_user_master where user_id=?";
    }

    public static String getDistinctMail(String pan) {
        return "SELECT distinct email FROM taxpayer_vendor_contact_mapping where gstin_taxpayer like'%" + pan
                        + "%'  and email != ''";
    }

    public static String getPan(String mstDatabaseName) {
        return "SELECT PAN FROM " + mstDatabaseName + ".am_custom_template_email where custom_template_name_id=?";
    }

    public static final String GET_VENDOR_CONTACT_EMAIL = "SELECT GROUP_CONCAT(email,';' ) as 'email'"
                    + "    FROM taxpayer_vendor_contact_mapping  where   tvcr_id = ? and is_primary_contact=1" + " ";
    public static final String GETTAXPAYERSQL = "select cast(from_base64(email_id) as char) as email from bvms_master_local.am_entity_master where gstin=to_base64(?);";
    public static final String GETVENDORRSQL = "select email from taxpayer_vendor_contact where id=?";

    public static String getTaxpayerEmail(String mstDatabaseName) {
        StringBuilder sql = new StringBuilder();
        return sql.append("select cast(from_base64(email_id) as char) as email from ").append(mstDatabaseName)
                        .append(".am_entity_master where from_base64(gstin)=?").toString();
    }

    public static final String GET_TEMPLATE_TYPE_SQL = new StringBuilder(
                    "Select pld.id,sm_pick_mst_id, pld.name, code, short_desc, long_desc,pick_key, sort_order,pld.status, pld.created_at, pld.created_by,from_base64(first_name) userName, tmp.mandatoryColumns from sm_pickup_list_details pld\r\n")
                                    .append("LEFT JOIN ( \r\n")
                                    .append("Select  tcc.pld_template_id, group_concat(column_name) as mandatoryColumns \r\n")
                                    .append("from am_template_column_configuration tcc  where tcc.is_mandatory=? \r\n")
                                    .append("group by tcc.pld_template_id) tmp ON tmp.pld_template_id = pld.code \r\n")
                                    .append(Constants.JOIN_USERMASTER_PLD)
                                    .append("where pld.sm_pick_mst_id=? AND pick_key IN (65,63,66) ").toString();
    public static final String GET_CUSTOM_TEMPLATE_NAME_ID = "SELECT count(1) FROM am_config_settings_values where  am_custom_template_name_id = ? ";
    public static final String GET_PLD_TEMPLATE_ID_BY_REPORT_CODE = "SELECT pld_template_id FROM  am_report_config WHERE report_code= ?";

    public static String getTaxpayerUserId(String mstDatabaseName) {
        StringBuilder sql = new StringBuilder();
        return sql.append("select ewc.user_id from entity_workflow_config ewc left join " + mstDatabaseName
                        + ".am_entity_master aem on\r\n"
                        + "ewc.entity_id = aem.entity_id where aem.gstin = to_base64(?) and ewc.pld_module_id = ? group by ewc.user_id;")
                        .toString();
    }

    public static String getVendorUserId() {
        StringBuilder sql = new StringBuilder();
        return sql.append(
                        "select contact_id from am_vendor_role_mapping where vendor_gstin=? and taxpayer_gstin=? order by 1 desc limit 1")
                        .toString();
    }

    public static String getTaxpayerName() {
        StringBuilder sql = new StringBuilder();
        return sql.append(
                        "select concat(from_base64(first_name), ' ', from_base64(last_name)) as user_name from am_user_master where user_id = ?;")
                        .toString();
    }

    public static String getVendorAllPrimaryMailId(String mstDatabaseName) {

        StringBuilder sql = new StringBuilder();
        return sql.append("SELECT  email \r\n" + "FROM taxpayer_vendor_contact_mapping c   \r\n"
                        + "INNER JOIN taxpayer_vendors tv ON tvcr_id=child_relation_id \r\n"
                        + "AND c.gstin_taxpayer = tv.gstin_taxpayer and c.gstin_vendor = tv.gstin_vendor \r\n"
                        + "INNER JOIN " + mstDatabaseName
                        + ".sm_pickup_list_details pld ON c.is_primary_contact = pld.code  \r\n" + "INNER JOIN "
                        + mstDatabaseName
                        + ".sm_pickup_master pm ON pm.pickup_master_id = pld.sm_pick_mst_id AND pm.name= 'primary_contact' \r\n"
                        + "WHERE  tv.pld_data_version = 1 AND tv.gstin_taxpayer = ?   \r\n"
                        + "AND tv.gstin_vendor = ? and is_primary_contact=1 \r\n"
                        + "ORDER BY c.modified_at DESC, c.created_at DESC ").toString();
    }

    public static String getVendorAllUserIds(String mstDatabaseName) {

        StringBuilder sql = new StringBuilder();
        return sql.append("SELECT  contact_id \r\n" + "FROM taxpayer_vendor_contact_mapping c   \r\n"
                        + "INNER JOIN taxpayer_vendors tv ON tvcr_id=child_relation_id \r\n"
                        + "AND c.gstin_taxpayer = tv.gstin_taxpayer and c.gstin_vendor = tv.gstin_vendor \r\n"
                        + "INNER JOIN " + mstDatabaseName
                        + ".sm_pickup_list_details pld ON c.is_primary_contact = pld.code  \r\n" + "INNER JOIN "
                        + mstDatabaseName
                        + ".sm_pickup_master pm ON pm.pickup_master_id = pld.sm_pick_mst_id AND pm.name= 'primary_contact' \r\n"
                        + "WHERE  tv.pld_data_version = 1 AND tv.gstin_taxpayer = ?   \r\n"
                        + "AND tv.gstin_vendor = ? and is_primary_contact=1 \r\n"
                        + "ORDER BY c.modified_at DESC, c.created_at DESC ").toString();
    }

    public static String getVendorSingleMailId() {
        StringBuilder sql = new StringBuilder();
        return sql.append("SELECT email FROM taxpayer_vendor_contact where id=?;").toString();
    }

    public static String getVendorName() {
        StringBuilder sql = new StringBuilder();
        return sql.append(
                        "  SELECT concat(first_name, ' ',last_name) as vendorName FROM taxpayer_vendor_contact where id=?;\r\n"
                                        + "")
                        .toString();
    }

}
