package com.bdo.bvms.common.dto;

import java.time.LocalDateTime;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class UserCustomizeColumnDTO {

    String userId;
    int columnId;
    int sortOrder;
    String reportsCode;
    LocalDateTime createdat;
    String createdBy;

}
