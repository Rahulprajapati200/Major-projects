package com.bdo.bvms.common.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class GetEWayBillRegisterReportRes {

    String taxpayerGstin;
    String userGstin;
    String ewbNo;
    String ewbDate;
    String genMode;
    String supplyType;
    String subSupplyType;
    String docType;
    String docNo;
    String docDate;
    String fromGstin;
    String fromTradeName;
    String fromAddr1;
    String fromAddr2;
    String fromPlace;
    String fromPincode;
    String fromStateCode;
    String toGstin;
    String toTrdName;
    String toAddr1;
    String toAddr2;
    String toPlace;
    String toPincode;
    String toStateCode;
    String totalValue;
    String totInvValue;
    String cgstValue;
    String sgstValue;
    String igstValue;
    String cessValue;
    String transporterId;
    String transporterName;
    String status;
    String actualDist;
    String noValidDays;
    String validUpto;
    String extendedTimes;
    String rejectStatus;
    String actFromStateCode;
    String actToStateCode;
    String vehicleType;
    String transactionType;
    String otherValue;
    String cessNonAdvolValue;
    Long productId;
    String productName;
    String productDesc;
    String hsnCode;
    String quantity;
    String qtyUnit;
    String cgstRate;
    String sgstRate;
    String igstRate;
    String cessRate;
    String cessNonAdvol;
    String taxableAmount;
    String updMode;
    String vehicleNo;

    String fromState;
    String tripshtNo;
    String userGstinTransin;
    String enteredDate;
    String transMode;
    String transDocno;
    String transDocdate;
    String groupNo;

}
