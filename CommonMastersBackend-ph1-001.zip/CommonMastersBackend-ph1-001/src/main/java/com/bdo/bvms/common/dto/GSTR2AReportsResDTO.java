package com.bdo.bvms.common.dto;

import java.math.BigDecimal;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class GSTR2AReportsResDTO {

    String gstin;
    String category;
    String invoiceType;
    String noteType;
    String etin;
    String ctin;
    String companyTradeName;
    String supplierStateCode;
    String orgInvoiceNo;
    String orgInvoiceDate;
    String invoiceNo;
    String invoiceDate;
    String orgNoteNo;
    String orgNoteDate;
    String noteNo;
    String noteDate;
    String portCode;
    String importBillNo;
    String importBillDate;
    String itcEligibility;
    BigDecimal taxableAmount;
    BigDecimal sgstRate;
    String sgstAmount;
    BigDecimal cgstRate;
    BigDecimal cgstAmount;
    BigDecimal igstRate;
    BigDecimal igstAmount;
    String cessRate;
    BigDecimal cessAmount;
    BigDecimal diffPercent;
    BigDecimal totalTaxAmount;

    BigDecimal sumGrossTotalAmount;
    String pos;
    String reverseCharge;
    String fp;
    String cfs;
    String cfsGstr3b;
    String dateOfCancellation;
    String dateOfFilingGstr15;
    String filingPeriodGstr15;
    String delinkFlag;
    String amendmentFp;
    String amendmentType;
    String srctyp;
    String irn;
    String irngendate;
    String preGst;

}
