package com.bdo.bvms.common.exceptions;


public class VendorMasterDataAccessException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    public VendorMasterDataAccessException() {
        super();
    }

    
    
    public VendorMasterDataAccessException(Throwable cause) {

        super(cause);

    }


    public VendorMasterDataAccessException(String message, Throwable cause) {

        super(message, cause);


    }

   
}
