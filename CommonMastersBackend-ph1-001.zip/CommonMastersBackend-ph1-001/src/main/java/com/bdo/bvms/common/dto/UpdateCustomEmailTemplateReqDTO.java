package com.bdo.bvms.common.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.bdo.bvms.common.constant.ValidationConstant;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class UpdateCustomEmailTemplateReqDTO extends BaseReqDTO{

	@Size(min = ValidationConstant.PAN_MIN_SIZE , max = ValidationConstant.PAN_MAX_SIZE , message = "Request param pan size must be between "+ValidationConstant.PAN_MIN_SIZE + " and " + ValidationConstant.PAN_MAX_SIZE)
	@Pattern(regexp=ValidationConstant.PAN_PATTERN,message="{pan.pattern}")
	@NotBlank(message ="{pan.notBlank}")
	String pan;
	
	@Size(min = ValidationConstant.CUSTOM_TEMPLATE_NAME_MIN , max = ValidationConstant.CUSTOM_TEMPLATE_NAME_MAX , message = "Request param name size must be between "+ValidationConstant.CUSTOM_TEMPLATE_NAME_MIN + " and " + ValidationConstant.CUSTOM_TEMPLATE_NAME_MAX)
	@NotBlank(message = "Request parameter name must not be null nor empty")
	String name;
	
	@NotNull(message = "Request parameter pldTemplateId must not be null")
	Integer pldTemplateId;
	
	@NotBlank(message ="{mailSubject.notBlank}")
	String mailSubject;
	
	@NotBlank(message ="{mailBody.notBlank}")
	String mailBody;
	
	@NotNull(message = "{refTemplateId.notNull}")
	Integer refTemplateId;
	
	Integer customTemplateNameId;
	
	String signatureText;
	
	
}
