package com.bdo.bvms.common.dto;

import java.sql.Timestamp;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EInvoiceRegisterReportsResDTO {

    Timestamp rowVersion;
    String gstinUinOfRecipient;
    String gstinOfSupplier;
    String inwardNo;
    String docType;
    String inwardDate;
    String purchaseOrderNo;
    String purchaseOrderDate;
    String totalInvoiceAmount;
    String hsnCode;
    String irn;
    String irnDate;
    Long templateType;
    String udf1;
    String udf2;
    String udf3;
    String udf4;
    String udf5;
    String udf6;
    String udf7;
    String udf8;
    String udf9;
    String udf10;
    String udf11;
    String udf12;
    String udf13;
    String udf14;
    String udf15;
    String udf16;
    String udf17;
    String udf18;
    String udf19;
    String udf20;
    String errorCode;
    String errorMessage;

}
