package com.bdo.bvms.common.service;

import java.io.File;
import java.util.List;
import java.util.Map;

public interface ICommonCsvService {

	List<String> readVendorMasterDetailsTemplateFile(File file, char delimiter);

	Map<String, List<String>> readCustomTemplateSampleData(File file);

}