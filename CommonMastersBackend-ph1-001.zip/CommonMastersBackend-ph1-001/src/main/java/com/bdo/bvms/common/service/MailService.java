package com.bdo.bvms.common.service;

import javax.mail.MessagingException;

import org.springframework.mail.MailException;

import com.bdo.bvms.common.exceptions.BDOException;

public interface MailService {

	void sendEmailWithAttachment() throws MessagingException, MailException, BDOException;

}
