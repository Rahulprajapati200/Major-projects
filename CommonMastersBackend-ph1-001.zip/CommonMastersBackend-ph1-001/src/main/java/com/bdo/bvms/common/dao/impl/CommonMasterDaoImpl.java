package com.bdo.bvms.common.dao.impl;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.CommonMasterDao;
import com.bdo.bvms.common.dto.AddWorkflowCommunicationReqDTO;
import com.bdo.bvms.common.dto.AdvanceSearchReqDto;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.DownloadFileDTO;
import com.bdo.bvms.common.dto.DownloadFileInfo;
import com.bdo.bvms.common.dto.ErrorCodeDescriptionResponseDTO;
import com.bdo.bvms.common.dto.ErrorMessageListDto;
import com.bdo.bvms.common.dto.ExceptionLogDTO;
import com.bdo.bvms.common.dto.FieldNameResponseDto;
import com.bdo.bvms.common.dto.FinancialPeriodMonthResDTO;
import com.bdo.bvms.common.dto.FinancialYearResDTO;
import com.bdo.bvms.common.dto.GetCustomizedColumnListReqDTO;
import com.bdo.bvms.common.dto.GetCustomizedColumnListResDTO;
import com.bdo.bvms.common.dto.GetDefaultUploadTemplateReqDTO;
import com.bdo.bvms.common.dto.GetDefaultUploadTemplateResDTO;
import com.bdo.bvms.common.dto.GetFpByYearIdReqDTO;
import com.bdo.bvms.common.dto.GetFpByYearIdResDTO;
import com.bdo.bvms.common.dto.PreviewInvoiceUploadDTO;
import com.bdo.bvms.common.dto.SaveCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.SmMailBoxDTO;
import com.bdo.bvms.common.dto.TaxpayerMultilevelDetailsDTO;
import com.bdo.bvms.common.dto.TaxpayerVendor;
import com.bdo.bvms.common.dto.TaxpayerVendorContactMapping;
import com.bdo.bvms.common.dto.UserCustomizeColumnDTO;
import com.bdo.bvms.common.dto.WorkflowCommunication;
import com.bdo.bvms.common.exceptions.BDOException;
import com.bdo.bvms.common.exceptions.BVMSException;
import com.bdo.bvms.common.reports.constants.ReportsConstants;
import com.bdo.bvms.common.reports.sql.ReportsCommonSql;
import com.bdo.bvms.common.service.impl.CustomeRowMapper;
import com.bdo.bvms.common.sql.CommonMstSQL;
import com.bdo.bvms.common.util.DateUtil;
import com.bdo.bvms.common.util.EncryptionUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class CommonMasterDaoImpl implements CommonMasterDao {

    @Autowired
    private JdbcTemplate jdbcTemplateMst;

    @Autowired
    private JdbcTemplate jdbcTemplateTrn;

    @Value("${mst.database-name}")
    private String mstDatabaseName;

    @Value("${txn.database-name}")
    private String transDatabaseName;

    String mailto;

    CallableStatement cs = null;

    @Override
    public Page<FinancialPeriodMonthResDTO> getFpMonths(Pageable page, String searchValue) throws BVMSException {

        String sql = CommonMstSQL.getFpMonths(page, searchValue);
        try {
            return new PageImpl<>(
                            jdbcTemplateMst.query(sql,
                                            BeanPropertyRowMapper.newInstance(FinancialPeriodMonthResDTO.class)),
                            page, countFpMonths(searchValue, page));
        } catch (Exception ex) {
            throw new BVMSException(Constants.DATANOTFOUND, ex.getCause());
        }
    }

    @Override
    public int countFpMonths(String searchFilterValue, Pageable page) {

        String sql1 = CommonMstSQL.getTotalCountOfMonths(searchFilterValue);

        return jdbcTemplateMst.queryForObject(sql1, Integer.class);
    }

    @Override
    public Page<FinancialYearResDTO> getFpYear(Pageable page, String financialYearId, String filterSearchValue)
                    throws BVMSException {
        String sql = CommonMstSQL.getFpYear(page, financialYearId, filterSearchValue);
        try {

            List<FinancialYearResDTO> financialDtoList = jdbcTemplateMst.query(sql, new CustomeRowMapper());

            int count = countFpYear(financialYearId, filterSearchValue);

            return new PageImpl<>(financialDtoList, page, count);

        } catch (Exception ex) {
            log.error("Exception in getting Data from DB", ex);
            throw new BVMSException(Constants.DATANOTFOUND, ex.getCause());
        }

    }

    private int countFpYear(String financialYearId, String filterSearchValue) throws BVMSException {
        String sql;
        int cnt = 0;
        if (!StringUtils.isBlank(financialYearId)) {
            sql = UploadSQL.GET_COUNT_FP_YEAR + " year_id in (?) or financial_year like ?";
            cnt = jdbcTemplateMst.queryForObject(sql, Integer.class, financialYearId, "'%" + filterSearchValue + "%'");

        } else {

            sql = UploadSQL.GET_COUNT_FP_YEAR + " financial_year like ?";
            cnt = jdbcTemplateMst.queryForObject(sql, Integer.class, "'%" + filterSearchValue + "%'");
        }
        try {
            return cnt;
        } catch (Exception ex) {
            log.error("Exception in getting Data from DB", ex);
            throw new BVMSException();
        }
    }

    @Override
    public String getFilename(DownloadFileDTO downloadFileBytestreamDto) throws BVMSException {

        List<String> fileName = new ArrayList<>();
        if (StringUtils.isNotBlank(downloadFileBytestreamDto.getCustomtemplateID())
                        && downloadFileBytestreamDto.getTemplatetypepldCode() != null) {
            fileName = jdbcTemplateMst.queryForList(UploadSQL.CUSTOMEPLDTEMPLATE, String.class,
                            downloadFileBytestreamDto.getCustomtemplateID(),
                            downloadFileBytestreamDto.getTemplatetypepldCode());
        } else if (downloadFileBytestreamDto.getDownloadFile().equals("base")) {
            fileName = jdbcTemplateTrn.queryForList(UploadSQL.GET_BASE_FILE_LOC, String.class,
                            downloadFileBytestreamDto.getBatchNo());
        } else if (downloadFileBytestreamDto.getDownloadFile().equals("error")) {
            fileName = jdbcTemplateTrn.queryForList(UploadSQL.GET_ERROR_FILE_LOC, String.class,
                            downloadFileBytestreamDto.getBatchNo());
        }

        if (fileName.isEmpty()) {
            throw new BVMSException(Constants.FILENOTFOUNTONBLOB);
        }
        return fileName.get(0);
    }

    @Override
    public String getFileType(DownloadFileDTO downloadFileBytestreamDto) {
        List<String> fileType;
        fileType = jdbcTemplateTrn.queryForList(UploadSQL.GET_FILE_TYPE, String.class,
                        downloadFileBytestreamDto.getBatchNo());
        return fileType.get(0);

    }

    @Override
    public void updateExceptionLogTable(ExceptionLogDTO exceptionLogDTO) {

        String query = "insert into exception_log(screen_name,function_name,error_message,error_cause,line_no,user_id,created_at,requested_at,requested_by) VALUES (?,?,?,?,?,?,?,?,?)";

        jdbcTemplateTrn.update(query, exceptionLogDTO.getScreenName(), exceptionLogDTO.getFunctionName(),
                        exceptionLogDTO.getErrorMessage(), exceptionLogDTO.getErrorCause(), exceptionLogDTO.getLineNo(),
                        exceptionLogDTO.getUserId(), exceptionLogDTO.getCreatedAt(), exceptionLogDTO.getRequestedAt(),
                        exceptionLogDTO.getRequestedBy());
    }

    @Override
    public AzureConnectionCredentialsDTO getAzureCredentialFromDB(String entityId, String type) {

        Integer count = jdbcTemplateMst.queryForObject(UploadSQL.GET_COUNT_OF_AZURE_CREDENTIAL_FROM_DB, Integer.class,
                        entityId, type);
        if (count > 0) {
            return jdbcTemplateMst.queryForObject(UploadSQL.GET_AZURE_CREDENTIAL_FROM_DB,
                            new BeanPropertyRowMapper<AzureConnectionCredentialsDTO>(
                                            AzureConnectionCredentialsDTO.class),
                            entityId, type);
        }

        AzureConnectionCredentialsDTO azureConnectionCredentials = new AzureConnectionCredentialsDTO();

        String url = jdbcTemplateMst.queryForObject(UploadSQL.GET_URL_FROM_AZURE_CREDENTIAL_FROM_DB, String.class);
        azureConnectionCredentials.setUrl(url);
        String containerName = jdbcTemplateMst.queryForObject(UploadSQL.GET_CONTAINER_NAME_AZURE_CREDENTIAL_FROM_DB,
                        String.class);
        azureConnectionCredentials.setContainerName(containerName);
        return azureConnectionCredentials;
    }

    @Override
    public List<GetDefaultUploadTemplateResDTO> getPldDetailsByMstIdNKey(
                    GetDefaultUploadTemplateReqDTO getDefaultUploadTemplateReqDTO) {

        String sql = UploadSQL.GETDEFAULTTEMPLATE;

        return jdbcTemplateMst.query(sql, new ResultSetExtractor<List<GetDefaultUploadTemplateResDTO>>() {

            public List<GetDefaultUploadTemplateResDTO> extractData(ResultSet rs)
                            throws SQLException, DataAccessException {
                List<GetDefaultUploadTemplateResDTO> eInvoiceTemplateDTOList = new ArrayList<>();
                while (rs.next()) {
                    GetDefaultUploadTemplateResDTO getDefaultUploadTemplateResDTO = new GetDefaultUploadTemplateResDTO();
                    getDefaultUploadTemplateResDTO.setCode(rs.getInt("code"));
                    getDefaultUploadTemplateResDTO.setName(rs.getString("name"));
                    eInvoiceTemplateDTOList.add(getDefaultUploadTemplateResDTO);
                }
                return eInvoiceTemplateDTOList;
            }

        }, Constants.SMPICKTEMPLATEID, getDefaultUploadTemplateReqDTO.getPick_key());

    }

    @Override
    public String getModuleName(DownloadFileDTO downloadFileDto) {
        String query = CommonMstSQL.getModuleNameOfBatchNo(mstDatabaseName, transDatabaseName);
        return jdbcTemplateMst.queryForObject(query, String.class, downloadFileDto.getBatchNo());
    }

    @Override
    public List<SmMailBoxDTO> getListOfMailDataToSend(String pending) throws BDOException {

        try {
            String sql = UploadSQL.GETPENDINGMAILDATA;
            return jdbcTemplateMst.query(sql, new ResultSetExtractor<List<SmMailBoxDTO>>() {

                public List<SmMailBoxDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
                    List<SmMailBoxDTO> smMainBoxDTOList = new ArrayList<>();
                    while (rs.next()) {
                        SmMailBoxDTO smMainBoxDTO = new SmMailBoxDTO();
                        smMainBoxDTO.setMailTo(rs.getString("mail_to"));
                        smMainBoxDTO.setMailFrom(rs.getString("mail_from"));
                        smMainBoxDTO.setMailCc(rs.getString("mail_cc"));
                        smMainBoxDTO.setMailSubject(rs.getString("mail_subject"));
                        smMainBoxDTO.setMailBody(rs.getString("mail_body"));
                        smMainBoxDTO.setTrials(rs.getString("trials"));
                        smMainBoxDTO.setDisclaimer(rs.getString("disclaimer"));
                        smMainBoxDTO.setErrorSuccess(rs.getString("error_success"));
                        smMainBoxDTO.setMailCreatedDate(rs.getString("mail_created_date"));
                        smMainBoxDTO.setMailCreater(rs.getString("mail_creater"));
                        smMainBoxDTO.setMailSendDate(rs.getString("mail_send_date"));
                        smMainBoxDTO.setPldModuleId(rs.getString("pld_module_id"));
                        smMainBoxDTO.setAttachmentPath(rs.getString("attachment_path"));
                        smMainBoxDTO.setIsHighImportance(rs.getString("is_High_Importance"));
                        smMainBoxDTOList.add(smMainBoxDTO);
                    }
                    return smMainBoxDTOList;
                }

            }, pending);
        } catch (Exception ex) {
            throw new BDOException(ex.getMessage());
        }
    }

    @Override
    public void setSent(int trials, String pending) {
        jdbcTemplateMst.update(UploadSQL.UPDATE_ERROR_SUCCESS, Constants.SENT, trials, pending);
    }

    @Override
    public void setFailed(int trials, String pending) {
        jdbcTemplateMst.update(UploadSQL.UPDATE_ERROR_SUCCESS, Constants.FAILED, trials, pending);
    }

    @Override
    public Map<String, String> searchBvmsErrorMappings() {
        return jdbcTemplateMst.query(CommonMstSQL.GET_BVMS_ERROR_CODES_MAPPINGS_SQL,
                        new ResultSetExtractor<Map<String, String>>() {

                            @Override
                            public Map<String, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                Map<String, String> mapRet = new HashMap<>();
                                while (rs.next()) {
                                    mapRet.put(rs.getString("errorCode"), rs.getString("errorDescription"));
                                }
                                return mapRet;
                            }
                        });
    }

    @Override
    public DownloadFileInfo getFileInfo(PreviewInvoiceUploadDTO dto) {
        String sql = CommonMstSQL.getPreviewFileUploadUrl(mstDatabaseName);
        return jdbcTemplateTrn.queryForObject(sql, new BeanPropertyRowMapper<DownloadFileInfo>(DownloadFileInfo.class),
                        dto.getBatchNo());
    }

    @Override
    public List<GetFpByYearIdResDTO> getFpListByYearId(GetFpByYearIdReqDTO dto) {
        String sql = UploadSQL.GET_FP_BY_YEAR_ID;
        return jdbcTemplateMst.query(sql, new ResultSetExtractor<List<GetFpByYearIdResDTO>>() {

            public List<GetFpByYearIdResDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
                List<GetFpByYearIdResDTO> getFpByYearIdResDTOList = new ArrayList<>();
                while (rs.next()) {
                    GetFpByYearIdResDTO getFpByYearIdResDTO = new GetFpByYearIdResDTO();
                    getFpByYearIdResDTO.setId(rs.getString("fp"));
                    getFpByYearIdResDTO.setName(rs.getString("fp_description"));
                    getFpByYearIdResDTOList.add(getFpByYearIdResDTO);
                }
                return getFpByYearIdResDTOList;
            }

        }, dto.getYearId());

    }

    @Override
    public List<GetCustomizedColumnListResDTO> getCustomizedColumnListFromRepo(
                    GetCustomizedColumnListReqDTO getSaveCustomizedColumnListReqDTO) {
        int count = jdbcTemplateTrn.queryForObject(CommonMstSQL.getColumnCountForUser(mstDatabaseName), Integer.class,
                        getSaveCustomizedColumnListReqDTO.getScreenId(), getSaveCustomizedColumnListReqDTO.getUserId(),
                        getSaveCustomizedColumnListReqDTO.getModuleId());

        String sql = CommonMstSQL.getSavedCustomizeColumnList(getSaveCustomizedColumnListReqDTO.getUserId(),
                        getSaveCustomizedColumnListReqDTO.getModuleId(),
                        getSaveCustomizedColumnListReqDTO.getScreenId(), mstDatabaseName, count);

        return jdbcTemplateTrn.query(sql, new ResultSetExtractor<List<GetCustomizedColumnListResDTO>>() {

            public List<GetCustomizedColumnListResDTO> extractData(ResultSet rs)
                            throws SQLException, DataAccessException {
                List<GetCustomizedColumnListResDTO> getCustomizedColumnListResDTOList = new ArrayList<>();
                while (rs.next()) {
                    GetCustomizedColumnListResDTO getCustomizedColumnListResDTO = new GetCustomizedColumnListResDTO();
                    getCustomizedColumnListResDTO.setColumnId(rs.getInt("column_id"));
                    getCustomizedColumnListResDTO.setName(rs.getString("column_screen_name"));
                    getCustomizedColumnListResDTO.setIsSelected(rs.getString("is_Selected"));
                    getCustomizedColumnListResDTO.setIsMandatory(rs.getString("is_mandatory"));
                    getCustomizedColumnListResDTO.setSortOrder(rs.getInt("sort_order"));
                    getCustomizedColumnListResDTOList.add(getCustomizedColumnListResDTO);
                }
                return getCustomizedColumnListResDTOList;
            }

        });
    }

    @Override
    public void deleteThePreviousRecord(SaveCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO) {
        String deleteQuery = CommonMstSQL.deletePreviousRecords(mstDatabaseName, transDatabaseName);
        jdbcTemplateMst.update(deleteQuery, saveCustomizeColumnListReqDTO.getUserId(),
                        saveCustomizeColumnListReqDTO.getScreenId());
    }

    @Override
    public void enterTheNewRecord(SaveCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO) {
        List<UserCustomizeColumnDTO> userCustomizeColumnDTOList = new ArrayList<>();
        for (int size = 0; saveCustomizeColumnListReqDTO.getCustomizeColumnList().size() > size; size++) {
            UserCustomizeColumnDTO userCustomizeColumnDTO = new UserCustomizeColumnDTO();

            if (saveCustomizeColumnListReqDTO.getCustomizeColumnList().get(size)
                            .getIsSelected() == Constants.SELECTED) {
                userCustomizeColumnDTO.setUserId(saveCustomizeColumnListReqDTO.getUserId());
                userCustomizeColumnDTO.setColumnId(
                                saveCustomizeColumnListReqDTO.getCustomizeColumnList().get(size).getColumnId());
                userCustomizeColumnDTO.setSortOrder(
                                saveCustomizeColumnListReqDTO.getCustomizeColumnList().get(size).getSortOrder());

                userCustomizeColumnDTOList.add(userCustomizeColumnDTO);
            }
        }
        insertMultipleColumnRecords(userCustomizeColumnDTOList);

    }

    public void insertMultipleColumnRecords(List<UserCustomizeColumnDTO> userCustomizeColumnDTOList) {
        String insertQuery = CommonMstSQL.insertNewCustomizeColumnRecord(transDatabaseName);
        jdbcTemplateMst.batchUpdate(insertQuery, new BatchPreparedStatementSetter() {

            @Override
            public void setValues(PreparedStatement pStmt, int j) throws SQLException {
                UserCustomizeColumnDTO userCustomizeColumnDTO = userCustomizeColumnDTOList.get(j);
                pStmt.setString(1, userCustomizeColumnDTO.getUserId());
                pStmt.setLong(2, userCustomizeColumnDTO.getColumnId());
                pStmt.setLong(3, userCustomizeColumnDTO.getSortOrder());
            }

            @Override
            public int getBatchSize() {
                return userCustomizeColumnDTOList.size();
            }
        });
    }

    @Override
    public TaxpayerVendor checkIfTaxpayerVendorExists(TaxpayerVendor taxpayerVendor) {
        return jdbcTemplateTrn.queryForObject(CommonMstSQL.CHECK_IF_TAXPAYER_VENDOR_EXISTS_SQL,
                        new RowMapper<TaxpayerVendor>() {

                            public TaxpayerVendor mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return TaxpayerVendor.builder().id(rs.getInt("id"))
                                                .childRelationId(rs.getInt("child_relation_id"))
                                                .entityId(rs.getInt("entity_id"))
                                                .pldDataVersion(rs.getInt("pld_data_version"))
                                                .panTaxpayer(rs.getString("pan_taxpayer"))
                                                .panVendor(rs.getString("pan_vendor"))
                                                .gstinTaxpayer(rs.getString("gstin_taxpayer"))
                                                .gstinVendor(rs.getString("gstin_vendor"))
                                                .companyLegalName(rs.getString("company_legal_name"))
                                                .companyTradeName(rs.getString("company_trade_name"))
                                                .vendorCodeErp(rs.getString("vendor_code_erp"))
                                                .pldTaxpayerType(rs.getString("pld_taxpayer_type"))
                                                .pldGstinStatus(rs.getString("pld_gstin_status"))
                                                .gstinRegistrationDate(rs.getString("gstin_registration_date"))
                                                .cancellationDate(rs.getString("cancellation_date"))
                                                .gstnSha(rs.getString("gstn_sha"))
                                                .centerJurisdiction(rs.getString("center_jurisdiction"))
                                                .stateJurisdiction(rs.getString("state_jurisdiction"))
                                                .businessConstitution(rs.getString("business_constitution"))
                                                .businessNature(rs.getString("business_nature"))
                                                .pldSource(rs.getInt("pld_source"))
                                                .freeSearch(rs.getString("free_search"))
                                                .parentId(rs.getInt("parent_id"))
                                                .createdAt(rs.getTimestamp(ReportsConstants.CREATED_AT))
                                                .createdBy(rs.getInt(ReportsConstants.CREATED_BY)).build();
                            }
                        }, taxpayerVendor.getPldDataVersion(), taxpayerVendor.getGstinTaxpayer(),
                        taxpayerVendor.getGstinVendor());

    }

    @Override
    public TaxpayerVendorContactMapping getTaxpayerVendorPrimaryContactByContactIdAndTvcrId(
                    TaxpayerVendorContactMapping taxpayerVendorContactMapping, int moduleId) {
        if (moduleId == Constants.INVITES_TRACKING_TAXPAYER_MODULE_ID) {

            return jdbcTemplateTrn.queryForObject(CommonMstSQL.checkIfContactMappingExistsByColumnTaxpayerJourney(),
                            new RowMapper<TaxpayerVendorContactMapping>() {

                                public TaxpayerVendorContactMapping mapRow(ResultSet rs, int rowNum)
                                                throws SQLException {
                                    return TaxpayerVendorContactMapping.builder().id(rs.getInt("id"))
                                                    .aadharVendor(rs.getString("aadhar_vendor"))
                                                    .firstName(rs.getString("first_name"))
                                                    .lastName(rs.getString("last_name")).email(rs.getString("email"))
                                                    .mobile(rs.getLong("mobile"))
                                                    .isPrimaryContact(rs.getInt("is_primary_contact"))
                                                    .modifiedAt(rs.getTimestamp(Constants.MODIFIEDAT))
                                                    .createdAt(rs.getTimestamp(Constants.CREATEDAT)).build();
                                }
                            }, taxpayerVendorContactMapping.getTvcrId());

        } else {
            return jdbcTemplateTrn.queryForObject(
                            CommonMstSQL.checkIfContactMappingExistsByColumn(Constants.CONTACT_MAPPING_CONTACT_ID),
                            new RowMapper<TaxpayerVendorContactMapping>() {

                                public TaxpayerVendorContactMapping mapRow(ResultSet rs, int rowNum)
                                                throws SQLException {
                                    return TaxpayerVendorContactMapping.builder().id(rs.getInt("id"))
                                                    .aadharVendor(rs.getString("aadhar_vendor"))
                                                    .firstName(rs.getString("first_name"))
                                                    .lastName(rs.getString("last_name")).email(rs.getString("email"))
                                                    .mobile(rs.getLong("mobile"))
                                                    .isPrimaryContact(rs.getInt("is_primary_contact"))
                                                    .modifiedAt(rs.getTimestamp(Constants.MODIFIEDAT))
                                                    .createdAt(rs.getTimestamp(Constants.CREATEDAT)).build();
                                }
                            }, taxpayerVendorContactMapping.getTvcrId(), taxpayerVendorContactMapping.getContactId());
        }

    }

    @Override
    public Integer insertWorkflowCommunication(WorkflowCommunication workflowCommunication) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(CommonMstSQL.INSERT_WORKFLOW_COMMUNICATION_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1, workflowCommunication.getTvcrid());
            ps.setObject(2, workflowCommunication.getParentId());
            ps.setString(3, workflowCommunication.getTaxpayerGstin());
            ps.setString(4, workflowCommunication.getVendorGstin());
            ps.setObject(5, workflowCommunication.getWfMstId());
            ps.setObject(6, workflowCommunication.getPostTo());
            ps.setString(7, workflowCommunication.getSubject());
            ps.setString(8, workflowCommunication.getBody());
            ps.setObject(9, workflowCommunication.getIsNewCommunication());
            ps.setObject(10, workflowCommunication.getCreatedBy());
            ps.setObject(11, workflowCommunication.getIsVendor());
            ps.setString(12, workflowCommunication.getPostFrom());
            ps.setObject(13, workflowCommunication.getCommentType());
            return ps;
        }, keyHolder);
        if (keyHolder.getKey() == null) {
            return null;
        } else {
            Number key = keyHolder.getKey();
            return key == null ? null : key.intValue();

        }
    }

    @Override
    public List<TaxpayerVendorContactMapping> getTaxpayerVendorPrimaryContacts(
                    TaxpayerVendorContactMapping taxpayerVendorContactMapping) {
        return jdbcTemplateTrn.query(
                        CommonMstSQL.checkIfContactMappingExistsByColumn(Constants.CONTACT_MAPPING_IS_PRIMARY_CONTACT),
                        new RowMapper<TaxpayerVendorContactMapping>() {

                            public TaxpayerVendorContactMapping mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return TaxpayerVendorContactMapping.builder().id(rs.getInt("id"))
                                                .aadharVendor(rs.getString("aadhar_vendor"))
                                                .firstName(rs.getString("first_name"))
                                                .lastName(rs.getString("last_name")).email(rs.getString("email"))
                                                .mobile(rs.getLong("mobile"))
                                                .isPrimaryContact(rs.getInt("is_primary_contact"))
                                                .modifiedAt(rs.getTimestamp(Constants.MODIFIEDAT))
                                                .createdAt(rs.getTimestamp(Constants.CREATEDAT)).build();
                            }
                        }, taxpayerVendorContactMapping.getTvcrId(),
                        taxpayerVendorContactMapping.getIsPrimaryContact());
    }

    @Override
    public WorkflowCommunication getWorkflowCommunicationById(WorkflowCommunication workflowCommunication) {
        return jdbcTemplateTrn.queryForObject(CommonMstSQL.GET_WORKFLOW_COMMUNICATION_BY_ID_SQL,
                        new RowMapper<WorkflowCommunication>() {

                            public WorkflowCommunication mapRow(ResultSet rs, int rowNum) throws SQLException {

                                return getWorkflowCommunication(rs);
                            }
                        }, workflowCommunication.getId());
    }

    private WorkflowCommunication getWorkflowCommunication(ResultSet rs) throws SQLException {
        return WorkflowCommunication.builder().parentId(rs.getInt("parent_id"))
                        .taxpayerGstin(rs.getString("taxpayer_gstin")).vendorGstin(rs.getString("vendor_gstin"))
                        .wfMstId(rs.getInt("wf_mst_id")).postTo(rs.getString("post_to"))
                        .subject(rs.getString(Constants.WORKFLOW_COMMUNICATION_COLUMN_SUBJECT))
                        .body(rs.getString("body"))
                        .isNewCommunication(rs.getInt(Constants.WORKFLOW_COMMUNICATION_COLUMN_IS_NEW_COMMUNICATION))
                        .isVendor(rs.getInt("is_vendor")).postFrom(rs.getString("post_from")).id(rs.getInt("id"))
                        .createdAt(rs.getString(ReportsConstants.CREATED_AT))
                        .createdBy(rs.getInt(ReportsConstants.CREATED_BY)).build();
    }

    @Override
    public Page<WorkflowCommunication> searchParentWorkflowCommunication(Pageable paging,
                    WorkflowCommunication workflowCommunication) {
        StringBuilder sql = new StringBuilder(CommonMstSQL.GET_PARENT_WORKFLOW_COMMUNICATION_BY_WF_MST_ID_SQL)
                        .append(" group by p_wc.id order by id desc limit ? offset ? ");

        Integer count = countWorkflowCommunication(workflowCommunication);

        if (count != 0) {
            return new PageImpl<>(jdbcTemplateTrn.query(sql.toString(), new RowMapper<WorkflowCommunication>() {

                public WorkflowCommunication mapRow(ResultSet rs, int rowNum) throws SQLException {

                    String appKey = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_APP_KEY, String.class,
                                    ReportsConstants.ENCRYPTION_APP_KEY);

                    String postToJson = (rs.getString("post_to")).split(";")[0];
                    String postTo = "";
                    try {
                        postTo = EncryptionUtils.decryptJson(appKey, postToJson);
                    } catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException
                                    | NoSuchPaddingException | InvalidAlgorithmParameterException
                                    | IllegalBlockSizeException | BadPaddingException | DecoderException e) {
                        log.error("error in decription.");
                    }

                    return WorkflowCommunication.builder().parentId(rs.getInt("parent_id"))
                                    .taxpayerGstin(rs.getString("taxpayer_gstin"))
                                    .vendorGstin(rs.getString("vendor_gstin")).wfMstId(rs.getInt("wf_mst_id"))
                                    .postTo(postTo)
                                    .subject(rs.getString(Constants.WORKFLOW_COMMUNICATION_COLUMN_SUBJECT))
                                    .body(rs.getString("body"))
                                    .isNewCommunication(rs.getInt(
                                                    Constants.WORKFLOW_COMMUNICATION_COLUMN_IS_NEW_COMMUNICATION))
                                    .isVendor(rs.getInt("is_vendor")).postFrom(rs.getString("post_from"))
                                    .id(rs.getInt("id"))
                                    .createdAt(DateUtil.convertDBtoScreen(rs.getString(ReportsConstants.CREATED_AT)))
                                    .createdBy(rs.getInt(ReportsConstants.CREATED_BY))
                                    .childCount(rs.getInt("child_count"))
                                    .commentType(getCommentType(rs.getString("comment_type"))).build();
                }

            }, workflowCommunication.getWfMstId(), workflowCommunication.getIsNewCommunication(), paging.getPageSize(),
                            paging.getOffset()), paging, count);
        }
        return null;
    }

    @Override
    public Page<WorkflowCommunication> searchChildWorkflowCommunication(Pageable paging,
                    WorkflowCommunication workflowCommunication) {
        StringBuilder sql = new StringBuilder(CommonMstSQL.GET_WORKFLOW_COMMUNICATION_BY_PARENT_ID_SQL)
                        .append(" order by id  limit ? offset ? ");

        Integer count = countChildWorkflowCommunication(workflowCommunication);

        if (count > 0) {
            return new PageImpl<>(jdbcTemplateTrn.query(sql.toString(), new RowMapper<WorkflowCommunication>() {

                public WorkflowCommunication mapRow(ResultSet rs, int rowNum) throws SQLException {

                    String appKey = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_APP_KEY, String.class,
                                    ReportsConstants.ENCRYPTION_APP_KEY);

//                    String postToJson = (rs.getString("post_to")).split(";")[0];
//                    String postto = "";
//                    try {
//                        postto = EncryptionUtils.decryptJson(appKey, postToJson);
//                    } catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException
//                                    | NoSuchPaddingException | InvalidAlgorithmParameterException
//                                    | IllegalBlockSizeException | BadPaddingException | DecoderException e) {
//                        log.error("error in decription.");
//                    }

                    return WorkflowCommunication.builder().parentId(rs.getInt("parent_id"))
                                    .taxpayerGstin(rs.getString("taxpayer_gstin"))
                                    .vendorGstin(rs.getString("vendor_gstin")).wfMstId(rs.getInt("wf_mst_id"))
                                    .postTo(rs.getString("post_to"))
                                    .subject(rs.getString(Constants.WORKFLOW_COMMUNICATION_COLUMN_SUBJECT))
                                    .body(rs.getString("body"))
                                    .isNewCommunication(rs.getInt(
                                                    Constants.WORKFLOW_COMMUNICATION_COLUMN_IS_NEW_COMMUNICATION))
                                    .isVendor(rs.getInt("is_vendor")).postFrom(rs.getString("post_from"))
                                    .id(rs.getInt("id"))
                                    .createdAt(DateUtil.convertDBtoScreen(rs.getString(ReportsConstants.CREATED_AT)))
                                    .createdBy(rs.getInt(ReportsConstants.CREATED_BY))
                                    .commentType(getCommentType(rs.getString("comment_type"))).build();
                }

            }, workflowCommunication.getWfMstId(), workflowCommunication.getWfMstId(), paging.getPageSize(),
                            paging.getOffset()), paging, count);
        }
        return null;
    }

    protected String getCommentType(String commentTypeId) {
        String commentType = "-";
        if (commentTypeId == null || commentTypeId.equals("0")) {
            return commentType;
        } else {

            try {
                commentType = jdbcTemplateMst.queryForObject("SELECT name FROM sm_pickup_list_details where code= ? ",
                                String.class, commentTypeId);
                return commentType;
            } catch (DataAccessException e) {
                log.error("Issue coming at the time of getting Comment type name based on comment type id", e);
                return "-";
            }

        }
    }

    /**
     * Count child workflow communication.
     *
     * @param workflowCommunication
     *            the workflow communication
     * @return the integer
     */
    private Integer countChildWorkflowCommunication(WorkflowCommunication workflowCommunication) {
        return jdbcTemplateTrn.queryForObject(
                        CommonMstSQL.countSql(
                                        new StringBuilder(CommonMstSQL.GET_WORKFLOW_COMMUNICATION_BY_PARENT_ID_SQL)),
                        Integer.class, workflowCommunication.getWfMstId(), workflowCommunication.getWfMstId());
    }

    private Integer countWorkflowCommunication(WorkflowCommunication workflowCommunication) {
        return jdbcTemplateTrn.queryForObject(CommonMstSQL
                        .countSql(new StringBuilder(CommonMstSQL.GET_PARENT_WORKFLOW_COMMUNICATION_BY_WF_MST_ID_SQL)
                                        .append(" group by p_wc.id  ")),
                        Integer.class, workflowCommunication.getWfMstId(),
                        workflowCommunication.getIsNewCommunication());
    }

    public String getTaxpayerLoginId(String userId) {
        try {
            String encryptLoginId = jdbcTemplateTrn.queryForObject(CommonMstSQL.getTaxpayerEmailId(mstDatabaseName),
                            String.class, userId);
            String appKey = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_APP_KEY, String.class,
                            ReportsConstants.ENCRYPTION_APP_KEY);

            return EncryptionUtils.decrypt(appKey, encryptLoginId);

        } catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException | NoSuchPaddingException
                        | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException
                        | DecoderException ex) {
            log.error("error coming at the time of decripting login ID.");
            return "";
        }

    }

    @Override
    public String getFileUrl() {
        return jdbcTemplateMst.queryForObject(CommonMstSQL.QUERY_FOR_GETTING_FILE_URL, String.class);

    }

    @Override
    public List<ErrorCodeDescriptionResponseDTO> getErrorCode(ErrorMessageListDto errorMessageListDto) {

        return jdbcTemplateTrn.query(CommonMstSQL.GETERRORCODEEINVOICE,
                        new RowMapper<ErrorCodeDescriptionResponseDTO>() {

                            public ErrorCodeDescriptionResponseDTO mapRow(ResultSet rs, int rowNum)
                                            throws SQLException {
                                return ErrorCodeDescriptionResponseDTO.builder()
                                                .errorCode(rs.getString(Constants.ERRORCODE)
                                                                .replaceAll(Constants.SUBSTRINGREGEX, ""))
                                                .build();

                            }
                        }, errorMessageListDto.getBatchNo());
    }

    @Override
    public Map<String, String> setErrorDiscriptionForErrorList() {

        Map<String, String> mapRet = new HashMap<>();

        jdbcTemplateMst.query(CommonMstSQL.GET_ERRORCODE_AND_SHORTDESCRIPTION,
                        new ResultSetExtractor<Map<String, String>>() {

                            @Override
                            public Map<String, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                while (rs.next()) {
                                    mapRet.put(rs.getString("ErrorCode"), rs.getString("ShortDescription"));
                                }
                                return mapRet;
                            }
                        });

        return mapRet;
    }

    @Override
    public List<ErrorCodeDescriptionResponseDTO> getErrorCodeEway(ErrorMessageListDto errorMessageListDto) {
        return jdbcTemplateTrn.query(CommonMstSQL.GETERRORCODEEWAY, new RowMapper<ErrorCodeDescriptionResponseDTO>() {

            public ErrorCodeDescriptionResponseDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
                return ErrorCodeDescriptionResponseDTO.builder().errorCode(rs.getString("error_code")).build();
            }
        }, errorMessageListDto.getBatchNo());

    }

    @Override
    public List<ErrorCodeDescriptionResponseDTO> getErrorCodeVendor(ErrorMessageListDto errorMessageListDto) {
        return jdbcTemplateTrn.query(CommonMstSQL.GETERRORCODEEWAYVENDOR,
                        new RowMapper<ErrorCodeDescriptionResponseDTO>() {

                            public ErrorCodeDescriptionResponseDTO mapRow(ResultSet rs, int rowNum)
                                            throws SQLException {
                                return ErrorCodeDescriptionResponseDTO.builder().errorCode(rs.getString("error_code"))
                                                .build();
                            }
                        }, errorMessageListDto.getBatchNo());
    }

    @Override
    public List<ErrorCodeDescriptionResponseDTO> getErrorCodeInvoiceVendor(ErrorMessageListDto errorMessageListDto) {
        return jdbcTemplateTrn.query(CommonMstSQL.GETERRORCODEINVOICEVENDOR,
                        new RowMapper<ErrorCodeDescriptionResponseDTO>() {

                            public ErrorCodeDescriptionResponseDTO mapRow(ResultSet rs, int rowNum)
                                            throws SQLException {
                                return ErrorCodeDescriptionResponseDTO.builder().errorCode(
                                                rs.getString("error_code").replaceAll(Constants.SUBSTRINGREGEX, ""))
                                                .build();
                            }
                        }, errorMessageListDto.getBatchNo());
    }

    @Override
    public List<FieldNameResponseDto> getFieldName(AdvanceSearchReqDto advanceSearchReqDto) {
        try {
            return jdbcTemplateMst.query(CommonMstSQL.GETALISTNAMESQL,
                            new ResultSetExtractor<List<FieldNameResponseDto>>() {

                                @Override
                                public List<FieldNameResponseDto> extractData(ResultSet rs)
                                                throws SQLException, DataAccessException {
                                    List<FieldNameResponseDto> responseList = new ArrayList<>();
                                    while (rs.next()) {
                                        FieldNameResponseDto fieldNameResponseDto = new FieldNameResponseDto();
                                        fieldNameResponseDto.setAlias(rs.getString("column_screen_name"));
                                        fieldNameResponseDto.setFieldName(rs.getString("column_screen_name"));
                                        fieldNameResponseDto.setDataType(rs.getString("data_type"));
                                        responseList.add(fieldNameResponseDto);
                                    }

                                    return responseList;
                                }

                            }

                            , advanceSearchReqDto.getModuleId());
        } catch (Exception e) {
            log.error("Error in getting Advance data from DB", e);
            return new ArrayList<>();
        }

    }

    @Override
    public String getEmailIdOfVendor(Integer tvcrId) {
        try {
            return jdbcTemplateTrn.queryForObject(CommonMstSQL.GET_VENDOR_CONTACT_EMAIL, String.class, tvcrId);
        } catch (Exception ex) {
            log.error("Error generated in the method:", ex);
            return "";
        }
    }

    @Override
    public String getVendorEmailEmail(AddWorkflowCommunicationReqDTO addWorkflowCommunicationReqDTO) {
        String email = "";
        try {
            email = jdbcTemplateTrn.queryForObject(CommonMstSQL.GETVENDORRSQL, String.class,
                            addWorkflowCommunicationReqDTO.getUserId());
        } catch (Exception ex) {
            email = "";
        }
        return email;
    }

    @Override
    public String getTaxpayerSingleEmailId(String taxpayerGstin) {
        String email = "";
        try {
            email = jdbcTemplateMst.queryForObject(CommonMstSQL.getTaxpayerEmail(mstDatabaseName), String.class,
                            taxpayerGstin);
        } catch (Exception ex) {
            email = "";
        }
        return email;

    }

    @Override
    public Map<String, Object> commonPostNotification(int vendoruploadmstid, String string, int userId, int userId2,
                    int userId3, String notificationCode) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall("{call common_post_notification(?,?,?,?,?,?,?)}");
                if (cs != null) {
                    cs.setInt(1, vendoruploadmstid);
                    cs.setString(2, string);
                    cs.setInt(3, userId);
                    cs.setInt(4, userId2);// touserId
                    cs.setInt(5, userId3);// fromuserId
                    cs.setString(6, mstDatabaseName);
                    cs.setString(7, notificationCode);

                }
                return cs;
            }
        }, parameters);

    }

    @Override
    public int getUserIdBasedOnVendorGstin(String vendorGstin, String taxpayerGstin) {

        return jdbcTemplateMst.queryForObject(CommonMstSQL.getVendorUserId(), Integer.class, vendorGstin,
                        taxpayerGstin);
    }

    @Override
    public int getUserIdBasedOnTaxpayerGstin(String taxpayerGstin, int moduleId) {

        return jdbcTemplateTrn.queryForObject(CommonMstSQL.getTaxpayerUserId(mstDatabaseName), Integer.class,
                        taxpayerGstin, moduleId);
    }

    @Override
    public String getVendorName(String vendorUserId) {
        String vendorName = "";
        try {
            vendorName = jdbcTemplateTrn.queryForObject(CommonMstSQL.getVendorName(), String.class, vendorUserId);
        } catch (Exception ex) {
            vendorName = "";
        }
        return vendorName;
    }

    @Override
    public String getVendorAllPrimaryMailId(String taxpayerGstin, String vendorGstin) {
        List<String> vendorMailId = new ArrayList<>();
        try {
            vendorMailId = jdbcTemplateTrn.queryForList(CommonMstSQL.getVendorAllPrimaryMailId(mstDatabaseName),
                            String.class, taxpayerGstin, vendorGstin);
        } catch (Exception ex) {
            vendorMailId = new ArrayList<>();
        }
        return vendorMailId.stream().map(String::valueOf).collect(Collectors.joining(","));
    }

    @Override
    public List<String> getVendorAllPrimaryUserId(String taxpayerGstin, String vendorGstin) {
        List<String> vendorUserId = new ArrayList<>();
        try {
            vendorUserId = jdbcTemplateTrn.queryForList(CommonMstSQL.getVendorAllUserIds(mstDatabaseName), String.class,
                            taxpayerGstin, vendorGstin);
        } catch (Exception ex) {
            vendorUserId = new ArrayList<>();
        }
        return vendorUserId;
    }

    @Override
    public String getTaxpayerName(int userId) {
        String taxpayerName = "";
        try {
            taxpayerName = jdbcTemplateMst.queryForObject(CommonMstSQL.getTaxpayerName(), String.class, userId);
        } catch (Exception ex) {
            taxpayerName = "";
        }
        return taxpayerName;
    }

    @Override
    public void insertIntoMailBox(String mailTo, String mailFrom, String fromGstin, String remarks) {
        String baseUrl = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_APP_KEY, String.class,
                        ReportsConstants.BASE_URL);
        String mailBody = "<p>Dear Sir/Madam,</p>" + "<p>Your have received a new comment from GSTIN- " + fromGstin
                        + "</p>" + "<p><strong>Comments :</strong> " + remarks + "</p> "
                        + "<p>For providing response, kindly login to ‘Vendor Compliance & AP Automation’ tool and refer ‘Compliance’ module. "
                        + baseUrl + " </p>               \r\n"
                        + "<p>In case of any queries/concerns, you may write to us on vca@bdo.in  </p> " + "      \r\n"
                        + " Best Regards,            <br>\r\n"
                        + "<strong>BDO Vendor Management Solution Support</strong>            \r\n"
                        + "<p>The information contained in this communication is intended solely for the use of the individual or entity to whom it is addressed and \r\n"
                        + "    others authorized to receive it. This communication may contain confidential or legally privileged information. If you are not the \r\n"
                        + "    intended recipient please notify us, preferably by e-mail, and do not read, copy or disclose the contents of this message to anyone.\r\n"
                        + "     No liability is accepted for any harm that may be caused to your systems or data by this message.</p>";

        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplateTrn.update(connection -> {
            // Assuming 'id' is the generated key column
            PreparedStatement ps = connection.prepareStatement(ReportsCommonSql.UPDATE_MAIL_BOX, new String[] { "id" });
            ps.setString(1, mailTo);
            ps.setString(2, mailFrom);
            ps.setString(3, "Notification for comment received ");
            ps.setString(4, mailBody);
            ps.setString(5, "");
            ps.setString(6, "");
            ps.setString(7, Constants.NEW);
            return ps;
        }, keyHolder);

    }

    @Override
    public String getSingleMailId(String userId) {
        String vendorMailId = "";
        try {
            vendorMailId = jdbcTemplateTrn.queryForObject(CommonMstSQL.getVendorSingleMailId(), String.class, userId);
        } catch (Exception ex) {
            return vendorMailId;
        }
        return vendorMailId;
    }

    @Override
    public List<TaxpayerMultilevelDetailsDTO> getTaxpayerMultiLevelDetails(int idOrGstin, String taxpayerGstin,
                    int vendorModuleId) {
        // vendorCommunicationInwardReq

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        Map<String, Object> results;

        results = jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                try {
                    cs = con.prepareCall("{call workflow_user_levels (?,?,?,?)}");

                    cs.setInt(1, idOrGstin);
                    cs.setString(2, taxpayerGstin);
                    cs.setInt(3, vendorModuleId);
                    cs.setString(4, mstDatabaseName);

                    return cs;
                } catch (SQLException e) {
                    if (cs != null) {
                        cs.close();
                    }
                    throw e;
                }
            }
        }, parameters);

        Map<String, Object> syncTabVendorInvoceReportData = new HashMap<>();

        List<TaxpayerMultilevelDetailsDTO> taxpayerMultilevelDetailsDTOList = new ArrayList<>();

        if (!results.isEmpty()) {

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> dataList = (List<Map<String, Object>>) results.get(ReportsConstants.RESULT_SET_1);

            dataList.stream().forEach(dataObject -> {

                TaxpayerMultilevelDetailsDTO dataRes = new TaxpayerMultilevelDetailsDTO();

                dataRes.setId(checkNullValue(String.valueOf(dataObject.get("id"))));
                dataRes.setUserId(((Long) dataObject.get("user_id")).intValue());
                dataRes.setOrder(checkNullValue(String.valueOf(dataObject.get("sentTo"))));

                taxpayerMultilevelDetailsDTOList.add(dataRes);
            });

        }
        return taxpayerMultilevelDetailsDTOList;

    }

    private static String checkNullValue(String value) {
        if (StringUtils.isEmpty(value)) {
            return "-";
        } else {
            return value;
        }
    }

    @Override
    public String getTaxpayerAllLevelMailIds(List<TaxpayerMultilevelDetailsDTO> taxpayerMultilevelDetails) {

        String appKey = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_APP_KEY, String.class,
                        ReportsConstants.ENCRYPTION_APP_KEY);

        Set<String> usersMailIds = new HashSet<>();
        String mailto = "";

        if (!taxpayerMultilevelDetails.isEmpty()) {
            for (int taxpyerDetail = 0; taxpyerDetail < taxpayerMultilevelDetails.size(); taxpyerDetail++) {

                String encryptedMailto = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_MAIL_BY_USER_ID,
                                String.class, taxpayerMultilevelDetails.get(taxpyerDetail).getUserId());
                try {
                    mailto = EncryptionUtils.decrypt(appKey, encryptedMailto);
                } catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException
                                | NoSuchPaddingException | InvalidAlgorithmParameterException
                                | IllegalBlockSizeException | BadPaddingException | DecoderException e) {
                    log.error("error coming at the time of decripting login ID.");
                }
                usersMailIds.add(mailto);

            }
            return usersMailIds.stream().map(String::valueOf).collect(Collectors.joining(","));

        } else {
            return mailto;
        }
    }

}
