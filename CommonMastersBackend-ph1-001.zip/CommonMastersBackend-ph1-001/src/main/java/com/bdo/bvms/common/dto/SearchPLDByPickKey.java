package com.bdo.bvms.common.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class SearchPLDByPickKey {

	@NotBlank(message = "{lkupCode.notBlank}")
	String lkupCode;
	
	@NotNull(message = "{pickKey.notNull}")
	Integer pickKey;
	
}
