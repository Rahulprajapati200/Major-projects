package com.bdo.bvms.common.dto;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class UpdateCustomTemplateDetailsReqDTO extends BaseReqDTO {

	@NotEmpty(message = "{updateCustomTemplateColumnMapping.notEmpty}")
	List<@Valid UpdateCustomTemplateColumnMappingReqDTO> updateCustomTemplateColumnMapping;
	
	@NotNull(message = "{customTemplateId.notnull}")
	private Integer customTemplateId;
	
	
}
