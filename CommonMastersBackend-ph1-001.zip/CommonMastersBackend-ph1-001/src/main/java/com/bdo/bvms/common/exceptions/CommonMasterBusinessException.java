package com.bdo.bvms.common.exceptions;


public class CommonMasterBusinessException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    public CommonMasterBusinessException() {
        super();
    }
    
    public CommonMasterBusinessException(String message) {

        super(message);

    }
    
    public CommonMasterBusinessException(Throwable cause) {

        super(cause);

    }


    public CommonMasterBusinessException(String message, Throwable cause) {

        super(message, cause);


    }

   
}
