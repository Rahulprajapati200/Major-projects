package com.bdo.bvms.common.dto;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SearchByIdReqDTO {
	
	@NotNull(message = "Request parameter id must not be null nor blank")
	Integer id;

}
