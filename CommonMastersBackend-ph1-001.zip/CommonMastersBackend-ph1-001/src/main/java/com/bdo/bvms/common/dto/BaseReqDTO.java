package com.bdo.bvms.common.dto;

import javax.validation.constraints.NotBlank;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class BaseReqDTO extends PageReqDTO {

    // @NotBlank(message = "{bearerToken.notblank}")
    String bearerToken;
    @NotBlank(message = "{userId.notblank}")
    String userId;
    // @NotBlank(message = "{entityId.notblank}")
    String entityId;
    // @NotBlank(message = "{userTypeId.notblank}")
    String userTypeId;
    // @NotBlank(message = "{entityTypeId.notblank}")
    String entityTypeId;
    String ipAddress;

}
