package com.bdo.bvms.common.reports.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;

import com.bdo.bvms.common.dto.APIResponseDTO;
import com.bdo.bvms.common.dto.BaseReqDTO;
import com.bdo.bvms.common.dto.FilingVeiwReportsReqDTO;
import com.bdo.bvms.common.dto.GetReportsCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.GetReportsSavedCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.PinnedAndUnpinnedReportsReqDTO;
import com.bdo.bvms.common.dto.ReportsSubModuleReqDTO;
import com.bdo.bvms.common.dto.ReportsVendorMasterReqDTO;
import com.bdo.bvms.common.dto.SearchReportReqDTO;
import com.bdo.bvms.common.dto.SendInvitesViewReportsReqDTO;
import com.bdo.bvms.common.dto.SubModuleWiseReportsListReqDTO;
import com.bdo.bvms.common.dto.VendorCommunicationEmailStatusReqDTO;
import com.bdo.bvms.common.dto.VendorCommunicationInwardReqDTO;
import com.bdo.bvms.common.dto.VendorCommunicationReconciliationReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceGetReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceInputReportsReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceSyncReqDTO;
import com.bdo.bvms.common.exceptions.AppBusinessException;
import com.bdo.bvms.common.exceptions.BDOException;

public interface ReportsVendorMasterController {

    ResponseEntity<APIResponseDTO> getReportsVendorMaster(HttpServletRequest httpServletRequest,
                    ReportsVendorMasterReqDTO reportsVendorMasterReqDTO) throws AppBusinessException, SQLException;

    ResponseEntity<APIResponseDTO> getPinnedReports(HttpServletRequest httpServletRequest, BaseReqDTO baseReqDTO)
                    throws AppBusinessException;

    ResponseEntity<APIResponseDTO> getSuggestedReports(HttpServletRequest httpServletRequest, BaseReqDTO baseReqDTO)
                    throws AppBusinessException;

    ResponseEntity<APIResponseDTO> getRecentReports(HttpServletRequest httpServletRequest, BaseReqDTO baseReqDTO)
                    throws AppBusinessException;

    ResponseEntity<APIResponseDTO> getReportSubmoduleList(HttpServletRequest httpServletRequest,
                    ReportsSubModuleReqDTO reportsSubModuleReqDTO) throws AppBusinessException;

    ResponseEntity<APIResponseDTO> getSubMduleWiseReportLIst(HttpServletRequest httpServletRequest,
                    SubModuleWiseReportsListReqDTO subModuleWiseReportsListReqDTO) throws AppBusinessException;

    ResponseEntity<APIResponseDTO> downloadVendorMasterReports(HttpServletRequest httpServletRequest,
                    ReportsVendorMasterReqDTO reportsVendorMasterReqDTO) throws BDOException;

    ResponseEntity<APIResponseDTO> insertPinnedAndUnpinnedReports(HttpServletRequest httpServletRequest,
                    PinnedAndUnpinnedReportsReqDTO pinnedAndUnpinnedReportsReq) throws AppBusinessException;

    ResponseEntity<APIResponseDTO> getSendInvitesViewReports(HttpServletRequest httpServletRequest,
                    SendInvitesViewReportsReqDTO sendInvitesViewReportsReqDTO) throws AppBusinessException;

    ResponseEntity<APIResponseDTO> getFilingViewReportsList(HttpServletRequest httpServletRequest,
                    FilingVeiwReportsReqDTO filingVeiwReportsReqDTO) throws AppBusinessException;

    ResponseEntity<APIResponseDTO> getReportsCustomizedColumnList(HttpServletRequest httpServletRequest,
                    GetReportsCustomizeColumnListReqDTO getSaveCustomizedColumnListReqDTO) throws AppBusinessException;

    ResponseEntity<APIResponseDTO> getReportsSavedCustomizedColumnList(HttpServletRequest httpServletRequest,
                    GetReportsSavedCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO) throws AppBusinessException;

    ResponseEntity<APIResponseDTO> vendorMasterBackGroundReports(HttpServletRequest httpServletRequest,
                    ReportsVendorMasterReqDTO generateBackgroundReports) throws AppBusinessException;

    ResponseEntity<APIResponseDTO> getBackgroungReports(HttpServletRequest httpServletRequest, BaseReqDTO requestDTO)
                    throws AppBusinessException;

    ResponseEntity<APIResponseDTO> getVendorInvoiceInputReports(HttpServletRequest httpServletRequest,
                    VendorInvoiceInputReportsReqDTO vendorInvoiceInputReportsReq)
                    throws AppBusinessException, SQLException;

    ResponseEntity<APIResponseDTO> getVendorInvoiceGetReports(HttpServletRequest httpServletRequest,
                    VendorInvoiceGetReqDTO vendorInvoiceGetReportsReq) throws AppBusinessException, SQLException;

    ResponseEntity<APIResponseDTO> getVendorInvoiceSyncReports(HttpServletRequest httpServletRequest,
                    VendorInvoiceSyncReqDTO vendorInvoiceSyncReq) throws AppBusinessException, SQLException;

    ResponseEntity<APIResponseDTO> getVendorCommunicationEmailStatusReports(HttpServletRequest httpServletRequest,
                    VendorCommunicationEmailStatusReqDTO vendorCommunicationEmailStatusReq)
                    throws AppBusinessException, SQLException;

    ResponseEntity<APIResponseDTO> getVendorCommunicationReconciliationReports(HttpServletRequest httpServletRequest,
                    VendorCommunicationReconciliationReqDTO vendorCommunicationReconciliationReq)
                    throws AppBusinessException, SQLException;

    ResponseEntity<APIResponseDTO> getVendorCommunicationInwardReports(HttpServletRequest httpServletRequest,
                    VendorCommunicationInwardReqDTO vendorCommunicationInwardReq)
                    throws AppBusinessException, SQLException;

    ResponseEntity<APIResponseDTO> getCustomModuleList(HttpServletRequest httpServletRequest, BaseReqDTO baseReqDTO)
                    throws AppBusinessException;

    ResponseEntity<APIResponseDTO> getSearchReports(HttpServletRequest httpServletRequest,
                    SearchReportReqDTO searchReportReq) throws AppBusinessException;

}
