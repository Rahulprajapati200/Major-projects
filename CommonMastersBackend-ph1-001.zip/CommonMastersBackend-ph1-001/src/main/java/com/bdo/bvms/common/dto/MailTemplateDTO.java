package com.bdo.bvms.common.dto;

import org.springframework.data.relational.core.mapping.Column;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldDefaults(level = AccessLevel.PRIVATE)
public class MailTemplateDTO {

    @Column(value = "mail_subject")
    String mailSubject;

    @Column(value = "mail_body")
    String mailBody;

    @Column(value = "mail_to")
    String mailTo;

    @Column(value = "mail_from")
    String mailFrom;

}
