package com.bdo.bvms.common.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VendorInvoiceSyncResDTO {

    String taxpayerGstin;
    Boolean syncWithGstr2a;
    Boolean syncWithGstr2b;
    Boolean syncWithEwayBill;
    String vendorGstin;
    String docType;
    String hsnCode;
    String invoiceNo;
    String invoiceDate;
    String totalInvoiceAmt;
    String irn;
    String irnDate;
    String ewayBillNo;
    String ewayBillDate;
    String billValidDate;
    String poNo;
    String poDate;
    String udf1;
    String udf2;
    String udf3;
    String udf4;
    String udf5;
    String udf6;
    String udf7;
    String udf8;
    String udf9;
    String udf10;

}
