package com.bdo.bvms.common.reports.dao;

import java.math.BigInteger;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Map;

import com.bdo.bvms.common.dto.VendorCommunicationEmailStatusReqDTO;
import com.bdo.bvms.common.dto.VendorCommunicationInwardReqDTO;
import com.bdo.bvms.common.dto.VendorCommunicationReconciliationReqDTO;

public interface ReportsVendorCommunicationRepo {

    Map<String, Object> getInwardDataList(VendorCommunicationInwardReqDTO vendorCommunicationInwardReq,
                    String monthList, String gstinList) throws SQLException;

    Map<String, Object> getVendorCommunicationReconciliationReportsResList(String taxpayerGstin, String yearId,
                    String recoStatus, String vendorGstin,
                    VendorCommunicationReconciliationReqDTO vendorCommunicationReconciliationReq, String pan)
                    throws SQLException;

    Map<String, Object> getEmailStatusDataList(VendorCommunicationEmailStatusReqDTO vendorCommunicationEmailStatusReq,
                    String gstinList, String yearId, String vendorGstin) throws SQLException;

    Map<String, Object> getDownloadVendorCommunicationInwardReports(
                    VendorCommunicationInwardReqDTO vendorCommunicationInwardReq, String monthList, String gstinList,
                    Timestamp timeStamp, String containerName, String fileName);

    Map<String, Object> getDownloadVendorCommunicationReconcilationReports(
                    VendorCommunicationReconciliationReqDTO vendorCommunicationReconciliationReq, String taxpayerGstin,
                    String yearId, String recoStatus, String vendorGstin, Timestamp timeStamp, String containerName,
                    String fileName, String pan);

    void getGenerateBackgroundVendorCommunicationInwardReports(
                    VendorCommunicationInwardReqDTO vendorCommunicationInwardReq, String monthList, String gstinList,
                    Timestamp timeStamp, String containerName, String fileName, Long totalcount, BigInteger id);

    void getDownloadBackgroundVendorCommReconcilationReport(
                    VendorCommunicationReconciliationReqDTO vendorCommunicationReconciliationReq, String taxpayerGstin,
                    String yearId, String recoStatus, String vendorGstin, Timestamp timeStamp, String containerName,
                    String fileName, String pan, Long totalCount, BigInteger id);

    Map<String, Object> getDownloadEmailStatusReports(
                    VendorCommunicationEmailStatusReqDTO vendorCommunicationEmailStatusReq, String gstinList,
                    String yearId, String vendorGstin, Timestamp timeStamp, String containerName, String fileName);

    void getDownloadBackgroundEmailStatusReport(VendorCommunicationEmailStatusReqDTO vendorCommunicationEmailStatusReq,
                    String gstinList, String yearId, String vendorGstin, Timestamp timeStamp, String containerName,
                    String fileName, Long long1, BigInteger id);

}
