package com.bdo.bvms.common.exceptions;


public class BVMSException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    public BVMSException() {
        super();
    }

    
    
    public BVMSException(Throwable cause) {

        super(cause);

    }

    public BVMSException(String message) {

        super(message);

    }

    public BVMSException(String message, Throwable cause) {

        super(message, cause);


    }

   
}
