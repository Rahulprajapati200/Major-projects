package com.bdo.bvms.common.dto;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class PreviewInvoiceUploadDTO extends BaseReqDTO {

    @NotBlank(message = "Request parameter lkupcode must not be null nor blank")
    String batchNo;

}
