package com.bdo.bvms.common.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class RoleDTO extends BaseReqDTO {
	private static final long serialVersionUID = 1L;
	private Long roleId;
	private int no;
	private String roleName;
	private String description;
	private Integer authLevel;
	private String siteName;
	private String deptName;
	private String name;
	private String email;

}
