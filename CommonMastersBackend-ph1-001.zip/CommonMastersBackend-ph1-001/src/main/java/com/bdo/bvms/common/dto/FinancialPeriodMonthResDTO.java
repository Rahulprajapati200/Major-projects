package com.bdo.bvms.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FinancialPeriodMonthResDTO {

    @JsonProperty("id")
    private int return_period_id;
    private String fp;
    @JsonProperty("name")
    private String fp_description;

}
