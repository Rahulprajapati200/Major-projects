package com.bdo.bvms.common.dto;

import com.bdo.bvms.common.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class WorkflowCommunication {

    Integer id;

    Integer tvcrid;

    Integer parentId;

    String taxpayerGstin;

    String vendorGstin;

    Integer wfMstId;

    String postTo;

    String subject;

    String body;

    Integer isNewCommunication;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI)
    String createdAt;

    Integer createdBy;

    String postFrom;

    Integer isVendor;

    Integer childCount;

    String commentType;
}
