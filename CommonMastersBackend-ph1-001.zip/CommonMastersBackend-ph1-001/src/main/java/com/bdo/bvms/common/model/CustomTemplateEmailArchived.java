package com.bdo.bvms.common.model;

import java.sql.Blob;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CustomTemplateEmailArchived {

		Integer id;
		Integer customTemplateEmailid;
		String pan;
		Integer entityId;
		String mailSubject;
		String mailBody;
		String mailFooter;
		String defaultCcReceipentsEmail;
		String disclaimer;
		Boolean isHighImportance;
		Boolean enableNotificationQueue;
		Integer refTemplateId;
		Boolean isDefaultTemplate;
		String from;
		String to;
		String customTemplateName;
		String moduleName;
		String refTemplateName;
		Integer pldTemplateId;
		Long signatureLogoSizeKb;
		String signatureLogoFileExt;
		Blob signatureLogoImage;
		
		Long companyLogoSizeKb;
		String companyLogoFileExt;
		Blob companyLogoImage;
		
		
	}


