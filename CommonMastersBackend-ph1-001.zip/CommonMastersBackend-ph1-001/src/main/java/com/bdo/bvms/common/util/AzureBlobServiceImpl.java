package com.bdo.bvms.common.util;

import java.io.File;
import java.io.FileInputStream;

import org.springframework.stereotype.Component;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import com.bdo.bvms.common.exceptions.CommonMasterBusinessException;
import com.bdo.bvms.common.model.EntityCloudCredentials;
import com.bdo.bvms.common.service.IAzureBlobService;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.blob.BlobContainerPermissions;
import com.microsoft.azure.storage.blob.BlobContainerPublicAccessType;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;

@Component
public class AzureBlobServiceImpl implements IAzureBlobService{

	public void createAndConfigureContainer(EntityCloudCredentials entityCloudCredentials)  {
		// Retrieve storage account from connection-string.
		CloudStorageAccount storageAccount;
		try {
			storageAccount = CloudStorageAccount.parse(entityCloudCredentials.getUrl());

			// Create the blob client.
			CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

			// Get a reference to a container.
			// The container name must be lower case
			CloudBlobContainer container = blobClient.getContainerReference(entityCloudCredentials.getContainerName());

			container.createIfNotExists();

			// Create a permissions object.
			BlobContainerPermissions containerPermissions = new BlobContainerPermissions();

			// Include public access in the permissions object.
			containerPermissions.setPublicAccess(BlobContainerPublicAccessType.CONTAINER);

			// Set the permissions on the container.
			container.uploadPermissions(containerPermissions);

		} catch(Exception e) {
			throw new CommonMasterBusinessException("Error while configuring cloud storage account", e);
		}
	}



	public String uploadToAzureBlob(File file, EntityCloudCredentials entityCloudCredentials)  {
		String url = null;        
		try (FileInputStream inputStream = new FileInputStream(file)) {

			createAndConfigureContainer(entityCloudCredentials);

			// Retrieve storage account from connection-string.
			CloudStorageAccount storageAccount = CloudStorageAccount.parse(entityCloudCredentials.getUrl());

			// Create the blob client.
			CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

			// Retrieve reference to a previously created container.
			CloudBlobContainer container = blobClient.getContainerReference(entityCloudCredentials.getContainerName());

			// Create or overwrite the blob with contents from a local file.
			CloudBlockBlob blob = container.getBlockBlobReference(file.getName());

			blob.upload(inputStream, file.length()); 

			url = file.getName();

		}catch(Exception e) {
			throw new CommonMasterBusinessException("Error while uploading file to cloud storage", e);
		}
		return url;
	}

	@Override
	public String getAzureBlobUrl(String fileName, EntityCloudCredentials entityCloudCredentials) {
		BlobContainerClient blobContainerClient = new BlobContainerClientBuilder().connectionString(entityCloudCredentials.getUrl())
			.containerName(entityCloudCredentials.getContainerName())	
		                .buildClient();
		BlobClient blobClient = blobContainerClient.getBlobClient(fileName);
		return blobClient!=null?blobClient.getBlobUrl():null;
	}


	
}
