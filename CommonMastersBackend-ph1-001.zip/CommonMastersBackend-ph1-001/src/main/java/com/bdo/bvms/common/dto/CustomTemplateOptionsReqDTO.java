package com.bdo.bvms.common.dto;

import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CustomTemplateOptionsReqDTO {

	@NotNull(message = "Request parameter templateColumnConfigId must not be null")
	Integer templateColumnConfigId;
	
}
