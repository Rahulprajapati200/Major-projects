package com.bdo.bvms.common.util;

import java.math.BigDecimal;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

public class ExcelUtils {
	
	ExcelUtils(){
		
	}
	
	
	public static int getExcelNonEmptyRows(Sheet sheet) {
		
		int totalNonEmptyRow=0;
		for (int i = 0; i < sheet.getPhysicalNumberOfRows(); i++) {
		    final Row row = sheet.getRow(i);
		    int cellCount=0;
		    if(row!=null) {
		    	cellCount=row.getPhysicalNumberOfCells();
		    }

		    for (int j = 0; j < cellCount; j++) {
		        final Cell cell = row.getCell(j);
		        if(getCellValue(cell)!=null && getCellValue(cell).length()>0) {
		        	totalNonEmptyRow++;
					break;
				}
		    }
		}
		return totalNonEmptyRow;
	}
	
	public static String getCellValue(Cell cell) {
		if(cell==null) {
			return "";
		}
		switch (cell.getCellType()) {
		case STRING: // field that represents string cell type
			return cell.getStringCellValue();
		case NUMERIC: // field that represents number cell type
			return (BigDecimal.valueOf(cell.getNumericCellValue())).toString();
		case BOOLEAN:
			return String.valueOf(cell.getBooleanCellValue());
		default:
			return "";
		}
	}

}
