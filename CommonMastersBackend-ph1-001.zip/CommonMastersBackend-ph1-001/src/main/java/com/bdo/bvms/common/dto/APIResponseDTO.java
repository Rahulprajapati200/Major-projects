package com.bdo.bvms.common.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

/**
 * This is used for custom Post Response
 * 
 * @author akshay.gupta
 *
 */
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class APIResponseDTO {

    Integer status;
    String message;
    String messageDescription;
    Object data;
    String tag;

}
