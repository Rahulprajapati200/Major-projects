package com.bdo.bvms.common.reports.service;

import java.util.List;

import com.bdo.bvms.common.dto.BaseReqDTO;
import com.bdo.bvms.common.dto.ModuleIdAndNameDTO;
import com.bdo.bvms.common.exceptions.AppBusinessException;

public interface ReportsModuleHelperService {

    List<ModuleIdAndNameDTO> getModuleCodeAndName(BaseReqDTO baseReqDTO) throws AppBusinessException;

    String getFileName(String reportId);

}
