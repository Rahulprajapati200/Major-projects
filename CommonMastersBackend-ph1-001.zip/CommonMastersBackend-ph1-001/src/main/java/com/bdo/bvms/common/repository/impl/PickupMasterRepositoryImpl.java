package com.bdo.bvms.common.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageImpl;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.model.PickupListDetail;
import com.bdo.bvms.common.reports.constants.ReportsConstants;
import com.bdo.bvms.common.repository.IPickupMasterRepository;
import com.bdo.bvms.common.sql.CommonMstSQL;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class PickupMasterRepositoryImpl implements IPickupMasterRepository {

    @Autowired
    private JdbcTemplate jdbcTemplateMst;

    /**
     * Search pickup master.
     *
     * @param lkupcode
     *            the lkupcode
     * @return the list
     */
    @Override
    public List<PickupListDetail> searchPickupMaster(String lkupcode) {
        // template_type

        String query = "";
        if ("template_type".equalsIgnoreCase(lkupcode)) {
            query = CommonMstSQL.GET_PICKUP_MASTER_DEFAULT_TEMPLATE_SQL;
        } else {
            query = CommonMstSQL.GET_PICKUP_MASTER_SQL;
        }

        if (log.isDebugEnabled()) {
            log.debug("searchPickupMaster:::lkupcode=" + lkupcode + ", query=" + query);
        }

        return jdbcTemplateMst.query(query, new RowMapper<PickupListDetail>() {

            public PickupListDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
                return PickupListDetail.builder().createdAt(rs.getDate(Constants.CREATED_AT))
                                .createdBy(rs.getInt(Constants.CREATEDBY)).id(rs.getInt("id"))
                                .name(rs.getString("name")).shortDesc(rs.getString(Constants.SHORTDESC))
                                .code(rs.getInt("code")).userName(rs.getString(Constants.USERNAME)).build();
            }
        }, lkupcode);
    }

    @Override
    public PickupListDetail searchPickupDetailByNameAndCode(PickupListDetail pickupListDetail) {
        return jdbcTemplateMst.queryForObject(CommonMstSQL.GET_PICKUP_DETAIL_BY_NAME_CODE_SQL,
                        new RowMapper<PickupListDetail>() {

                            public PickupListDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return PickupListDetail.builder().createdAt(rs.getDate(ReportsConstants.CREATED_AT))
                                                .createdBy(rs.getInt(ReportsConstants.CREATED_BY)).id(rs.getInt("id"))
                                                .name(rs.getString("name")).shortDesc(rs.getString("short_desc"))
                                                .code(rs.getInt("code")).userName(rs.getString("userName")).build();
                            }
                        }, pickupListDetail.getName(), pickupListDetail.getCode());
    }

    @Override
    public PageImpl<PickupListDetail> searchModulesPickupMasterByNamePickKey(PickupListDetail pickupListDetail) {
        Integer count = countDefaultTemplateType(pickupListDetail);
        if (count > 0) {

            return new PageImpl<>(jdbcTemplateMst.query(CommonMstSQL.GET_PLD_BY_NAME_PICK_KEY_MODULE_DATA_SQL,
                            new RowMapper<PickupListDetail>() {

                                public PickupListDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
                                    return PickupListDetail.builder().createdAt(rs.getDate(ReportsConstants.CREATED_AT))
                                                    .createdBy(rs.getInt(ReportsConstants.CREATED_BY))
                                                    .id(rs.getInt("id")).name(rs.getString("name"))
                                                    .pldStatus(rs.getInt("pld_status"))
                                                    .shortDesc(rs.getString("short_desc")).code(rs.getInt("code"))
                                                    .moduleName(rs.getString("moduleName"))
                                                    .userName(rs.getString("userName")).build();
                                }
                            }, Constants.PICKUP_MASTER_MODULES_ID, pickupListDetail.getName(),
                            pickupListDetail.getPickKey()));
        }
        return new PageImpl<>(new ArrayList<>());
    }

    private Integer countDefaultTemplateType(PickupListDetail pickupListDetail) {
        return jdbcTemplateMst.queryForObject(CommonMstSQL.GET_PLD_BY_NAME_PICK_KEY_COUNT_SQL, Integer.class,
                        Constants.PICKUP_MASTER_MODULES_ID, pickupListDetail.getName(), pickupListDetail.getPickKey());
    }

    @Override
    public List<PickupListDetail> searchPickupMasterByNamePickKey(PickupListDetail pickupListDetail) {

        return jdbcTemplateMst.query(CommonMstSQL.GET_PLD_BY_NAME_PICK_KEY_SQL, new RowMapper<PickupListDetail>() {

            public PickupListDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
                return PickupListDetail.builder().createdAt(rs.getTimestamp(ReportsConstants.CREATED_AT))
                                .createdBy(rs.getInt(ReportsConstants.CREATED_BY)).id(rs.getInt("id"))
                                .name(rs.getString("name")).code(rs.getInt("code")).build();
            }
        }, pickupListDetail.getPickupMasterName(), pickupListDetail.getPickKey());

    }

}
//IST