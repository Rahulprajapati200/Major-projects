package com.bdo.bvms.common.service;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.common.dto.AddCustomTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.CustomEmailPlaceHoldersResDTO;
import com.bdo.bvms.common.dto.CustomEmailRefTemplateResDTO;
import com.bdo.bvms.common.dto.CustomEmailTemplateDetailsResDTO;
import com.bdo.bvms.common.dto.CustomEmailTemplateModulesResDTO;
import com.bdo.bvms.common.dto.DefaultEmailTemplateResDTO;
import com.bdo.bvms.common.dto.DeleteCustomTemplateReqDTO;
import com.bdo.bvms.common.dto.DisableCustomTemplateDTO;
import com.bdo.bvms.common.dto.DownloadCustomTemplateReqDTO;
import com.bdo.bvms.common.dto.GetModuleWiseTemplateDTO;
import com.bdo.bvms.common.dto.PaginationResDTO;
import com.bdo.bvms.common.dto.SearchCustomEmailDetailsReqDTO;
import com.bdo.bvms.common.dto.SearchCustomEmailModulesReqDTO;
import com.bdo.bvms.common.dto.SearchCustomEmailPlaceHoldersReqDTO;
import com.bdo.bvms.common.dto.SearchCustomEmailRefTemplateReqDTO;
import com.bdo.bvms.common.dto.SearchCustomTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.SearchDefaultEmailTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.SearchModuleListReqDTO;
import com.bdo.bvms.common.dto.SearchModuleListResDTO;
import com.bdo.bvms.common.dto.SearchTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.SearchTemplateTypeResDTO;
import com.bdo.bvms.common.dto.TemplateHeaderWithColumnConfigResDTO;
import com.bdo.bvms.common.dto.TemplateTypeDetailsResDTO;
import com.bdo.bvms.common.dto.UpdateCustomEmailTemplateReqDTO;
import com.bdo.bvms.common.dto.UpdateCustomTemplateDetailsReqDTO;
import com.bdo.bvms.common.exceptions.AppBusinessException;
import com.bdo.bvms.common.exceptions.BDOException;
import com.bdo.bvms.common.exceptions.BVMSException;
import com.bdo.bvms.common.exceptions.CommonMasterBusinessException;

public interface ICustomTemplateService {

    void addCustomTemplateDetails(AddCustomTemplateDetailsReqDTO addCustomTemplateDetailsReqDTO) throws BDOException;

    TemplateHeaderWithColumnConfigResDTO searchTemplateHeaderWithAutoMappedColumn(MultipartFile file,
                    Integer pldTemplateId) throws BVMSException;

    List<TemplateTypeDetailsResDTO> searchDefaultTemplates();

    PaginationResDTO searchTemplateList(SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO);

    void deleteCustomTemplate(DeleteCustomTemplateReqDTO deleteCustomTemplateReqDTO);

    Object searchCustomTemplateDetails(SearchCustomTemplateDetailsReqDTO searchCustomTemplateDetailsReqDTO);

    void updateCustomTemplateDetails(UpdateCustomTemplateDetailsReqDTO updateCustomTemplateDetailsReqDTO);

    File downloadCustomTemplate(DownloadCustomTemplateReqDTO downloadCustomTemplateReqDTO);

    Map<String, List<String>> previewTemplateSampleData(MultipartFile file, String previewCustomTemplateSampleData)
                    throws CommonMasterBusinessException, BVMSException;

    Map<String, Object> searchCustomTemplateOptionsMappings(int customTemplateId);

    Map<String, String> searchCustomTemplateHeaderMappings(int customTemplateId);

    List<SearchModuleListResDTO> searchModuleList(SearchModuleListReqDTO searchModuleListReqDTO);

    GetModuleWiseTemplateDTO searchModuleWiseTemplateList(SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO);

    List<CustomEmailPlaceHoldersResDTO> searchCustomEmailPlaceHolders(
                    SearchCustomEmailPlaceHoldersReqDTO searchCustomEmailPlaceHoldersReqDTO);

    Integer updateCustomEmailTemplate(MultipartFile signatureLogo, MultipartFile companyLogo,
                    UpdateCustomEmailTemplateReqDTO updateCustomEmailTemplateReqDTO) throws BDOException;

    void disableCustomTemplate(DisableCustomTemplateDTO disableCustomTemplateDTO) throws AppBusinessException;

    List<SearchModuleListResDTO> searchEmailModuleList(SearchModuleListReqDTO searchModuleListReqDTO);

    GetModuleWiseTemplateDTO searchEmailModuleWiseTemplateList(SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO);

    DefaultEmailTemplateResDTO searchDefaultEmailTemplateDetails(
                    SearchDefaultEmailTemplateDetailsReqDTO searchDefaultEmailDetailsReqDTO);

    List<CustomEmailRefTemplateResDTO> seachCustomEmailRefTemplate(
                    SearchCustomEmailRefTemplateReqDTO searchCustomEmailRefTemplateReqDTO);

    List<CustomEmailTemplateModulesResDTO> seachCustomEmailModules(
                    SearchCustomEmailModulesReqDTO searchCustomEmailModulesReqDTO);

    CustomEmailTemplateDetailsResDTO searchCustomEmailDetails(
                    SearchCustomEmailDetailsReqDTO searchCustomEmailDetailsReqDTO);

    PaginationResDTO searchCustomeTemplateList(SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO);

    File searchCustomEmailLogo(SearchCustomEmailDetailsReqDTO searchCustomEmailDetailsReqDTO);

    List<SearchTemplateTypeResDTO> searchTemplateType();

}
