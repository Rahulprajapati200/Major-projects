package com.bdo.bvms.common.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.model.EntityCloudCredentials;
import com.bdo.bvms.common.repository.IEntityCloudCredentialsRepository;
import com.bdo.bvms.common.service.IEntityCloudCredentialsService;

@Service

public class EntityCloudCredentialsServiceImpl implements IEntityCloudCredentialsService {

    @Autowired
    private IEntityCloudCredentialsRepository iEntityCloudCredentialsRepositoryImpl;

    @Override
    public EntityCloudCredentials getEntityCloudCredentials(int entityId) {
        return iEntityCloudCredentialsRepositoryImpl.searchEntityCloudCredentials(entityId);
    }

}
