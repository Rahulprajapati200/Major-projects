package com.bdo.bvms.common.reports.dao;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.BaseReqDTO;
import com.bdo.bvms.common.dto.ModuleIdAndNameDTO;
import com.bdo.bvms.common.dto.ReportsCustomColumnsDTO;

public interface ReportModuleCommonRepo {

    String getContainerName(String entityId);

    String getFileUrl();

    String getFileName(String reportCode);

    AzureConnectionCredentialsDTO getAzureCredentialFromDB(String entityId, String blob);

    void updateBackGroundDetails(String filePath, Long recordCount, String pldStatus, String filename,
                    String modifiedBy, Timestamp modifiedAt, BigInteger id);

    void updateAccessLogTable(LocalDateTime localDateTime, String reportId, String userId, String entityId,
                    String userTypeId);

    BigInteger insertBackGroundDetails(String reportCode, String pldStatus, Timestamp reportGeneratedAt,
                    String modifiedBy, Timestamp modifiedAt, String fileName);

    String[] getGstinFromDB(String pan);

    String[] getMonthFromDB(String yearId);

    List<ModuleIdAndNameDTO> getModuleCodeAndName(BaseReqDTO baseReqDTO);

    String[] getColumnNamesAccToRepoCode(String reportCode);

    List<ReportsCustomColumnsDTO> getCustomizeColumns(int pldTemplateId, String reportId, String userId,
                    int customTemplateId, int summaryType);

    String getCustomOrDefault(String reportId);

    String getCustomOrDefaultValue(String reportId);

    List<ReportsCustomColumnsDTO> getCustomizeColumnsForView(int pldTemplateId, String reportId, String userId,
                    int customTemplateId, int summaryType);

    Map<String, Object> getHeadersStyles(XSSFWorkbook workbook, XSSFSheet sheet);

    void setFilterAndFredgeHeader(XSSFSheet sheet, CellRangeAddress range);

    String getReportsExcelFileName(String reportName, Timestamp timeStamp);

    String getReportsCsvFileName(String reportName, Timestamp timeStamp);

    long getKeyFromKeyHolder();

    void getUpdateLogProcExecution(String callStatement, long key);

    void sendMailDetails(BigInteger id) throws MessagingException;

    BigInteger insertDetailsIntoMailBox1(String userId, String reportName, Timestamp timeStamp);

    Map<String, Object> commonPostNotification(int vendoruploadmstid, String string, int userId, int userId2,
                    int userId3, String notificationCode);

    void setFilterAndFredgeHeader1(XSSFSheet sheet, CellRangeAddress range, int detalsCount);

}
