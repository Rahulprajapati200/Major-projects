package com.bdo.bvms.common.dto;

import java.time.LocalDateTime;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ExceptionLogDTO {

    String screenName;
    String functionName;
    String errorMessage;
    String errorCause;
    int lineNo;
    int userId;
    LocalDateTime createdAt;
    LocalDateTime requestedAt;
    LocalDateTime requestedBy;

}
