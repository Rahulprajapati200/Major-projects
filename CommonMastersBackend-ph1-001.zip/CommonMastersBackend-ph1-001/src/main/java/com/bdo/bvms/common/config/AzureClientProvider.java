package com.bdo.bvms.common.config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import com.azure.storage.blob.BlobClientBuilder;
import com.bdo.bvms.common.dao.CommonMasterDao;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@PropertySource(value={"classpath:application.properties"})
public class AzureClientProvider {

    static final Logger logger = LoggerFactory.getLogger(AzureClientProvider.class);
    private static final String CLASSNAME = "AzureConnectionValidation";

  

    @Autowired
    CommonMasterDao commonDao;
//    /JavaMailSender
    public BlobClientBuilder getClient(AzureConnectionCredentialsDTO dto) {
        final String methodName = "getClient";
        try {
        	
            BlobClientBuilder client = new BlobClientBuilder();
            client.connectionString(dto.getUrl());
            client.containerName(dto.getContainerName());
            
            return client;
            
        } catch (Exception e) {
            log.error(CLASSNAME, methodName, e + "");
        }
        return null;
    }
}
