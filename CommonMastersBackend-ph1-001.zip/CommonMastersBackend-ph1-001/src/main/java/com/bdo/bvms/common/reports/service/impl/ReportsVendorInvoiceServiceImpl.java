package com.bdo.bvms.common.reports.service.impl;

import java.math.BigInteger;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.dto.EInvoiceRegisterReportsResDTO;
import com.bdo.bvms.common.dto.EWayBillRegisterReportRes;
import com.bdo.bvms.common.dto.GSTR2AReportsResDTO;
import com.bdo.bvms.common.dto.GSTR2BReportsResDTO;
import com.bdo.bvms.common.dto.GetEWayBillRegisterReportRes;
import com.bdo.bvms.common.dto.ReportsCustomColumnsDTO;
import com.bdo.bvms.common.dto.VendorInvoiceGetReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceInputReportsReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceSyncReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceSyncResDTO;
import com.bdo.bvms.common.reports.constants.ReportsConstants;
import com.bdo.bvms.common.reports.dao.ReportModuleCommonRepo;
import com.bdo.bvms.common.reports.dao.ReportsVendorInvoiceRepo;
import com.bdo.bvms.common.reports.service.ReportsModuleHelperService;
import com.bdo.bvms.common.reports.service.ReportsVendorInvoiceService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j

public class ReportsVendorInvoiceServiceImpl implements ReportsVendorInvoiceService {

    @Autowired
    ReportsVendorInvoiceRepo reportsVendorInvoiceRepo;
    @Autowired
    ReportsModuleHelperService reportsModuleHelperService;

    @Autowired
    ReportModuleCommonRepo reportModuleCommonRepo;

    String gstinList;

    @Override
    public Map<String, Object> getVendorInvoiceInputReports(
                    VendorInvoiceInputReportsReqDTO vendorInvoiceInputReportsReq) throws SQLException {

        reportModuleCommonRepo.updateAccessLogTable(LocalDateTime.now(), vendorInvoiceInputReportsReq.getReportId(),
                        vendorInvoiceInputReportsReq.getUserId(), vendorInvoiceInputReportsReq.getEntityId(),
                        vendorInvoiceInputReportsReq.getUserTypeId());

        Map<String, Object> inputReportsDataList;

        Timestamp timeStamp = new Timestamp(System.currentTimeMillis());
        String containerName = reportModuleCommonRepo.getContainerName(vendorInvoiceInputReportsReq.getEntityId());

        int summaryType = 0;
        String fileName = "";
        try {
            fileName = reportModuleCommonRepo.getFileName(vendorInvoiceInputReportsReq.getReportId());
        } catch (Exception e) {
            log.error("error in getting VendorInvoiceInputReports file name from database", e);
        }
        String yearOrMonthList = vendorInvoiceInputReportsReq.getYearOrMonthList().toString().replace("[", "")
                        .replace("]", "").replace("{", "").replace("}", "").replace(" ", "");
        String pan = "";
        String gstinList1 = "";
        if (ReportsConstants.PAN.equals(vendorInvoiceInputReportsReq.getGstinOrPan())) {

            pan = vendorInvoiceInputReportsReq.getGstinOrPanList().toString().replace("[", "").replace("]", "")
                            .replace("{", "").replace("}", "").replace(" ", "");
        } else {
            gstinList1 = vendorInvoiceInputReportsReq.getGstinOrPanList().toString().replace("[", "").replace("]", "")
                            .replace("{", "").replace("}", "").replace(" ", "");
        }
        inputReportsDataList = reportsVendorInvoiceRepo.getInputReportsResList(vendorInvoiceInputReportsReq, gstinList1,
                        pan, yearOrMonthList);

        if (ReportsConstants.E_INVOICE_REGISTER_REPORT.equals(vendorInvoiceInputReportsReq.getReportId())
                        || ReportsConstants.CUSTOM_E_INVOICE_ERROR_REPORT
                                        .equals(vendorInvoiceInputReportsReq.getReportId())
                        || ReportsConstants.CUSTOM_E_INVOICE_REGISTER_REPORT
                                        .equals(vendorInvoiceInputReportsReq.getReportId())) {
            int pldTemplateId = 1;
            @SuppressWarnings("unchecked")
            List<EInvoiceRegisterReportsResDTO> data = (List<EInvoiceRegisterReportsResDTO>) inputReportsDataList
                            .get("inputTabVendorInvoceReportData");
            Map<String, Object> dataAndColumns = new HashMap<>();
            if (ReportsConstants.VIEW.equals(vendorInvoiceInputReportsReq.getButtonType())) {

                List<ReportsCustomColumnsDTO> columnsData = reportModuleCommonRepo.getCustomizeColumnsForView(
                                pldTemplateId, vendorInvoiceInputReportsReq.getReportId(),
                                vendorInvoiceInputReportsReq.getUserId(),
                                vendorInvoiceInputReportsReq.getCustomTemplateId(), summaryType);

                dataAndColumns.put(ReportsConstants.DATA, data);
                dataAndColumns.put(ReportsConstants.COLUMN_DATA, columnsData);// totalCount
                dataAndColumns.put(ReportsConstants.TOTAL_PAGE_ELEMENTS,
                                inputReportsDataList.get(ReportsConstants.TOTALCOUNT));
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_VIEW_DESCRIPTION);
                return dataAndColumns;

            } else if (ReportsConstants.DOWNLOAD.equals(vendorInvoiceInputReportsReq.getButtonType())) {

                dataAndColumns = reportsVendorInvoiceRepo.getGenerateExcelOrCsvFileofEInvoiceInputReports(
                                vendorInvoiceInputReportsReq, gstinList1, pan, yearOrMonthList, timeStamp,
                                containerName, fileName);
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_EXPORT_DESCRIPTION);

                return dataAndColumns;

            } else if (ReportsConstants.BACKGROUND.equals(vendorInvoiceInputReportsReq.getButtonType())) {

                BigInteger id = reportModuleCommonRepo.insertBackGroundDetails(
                                vendorInvoiceInputReportsReq.getReportId(), ReportsConstants.IN_PROGRESS, timeStamp,
                                vendorInvoiceInputReportsReq.getUserId(), timeStamp, fileName);
                reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORINVOICEMODULEID,
                                fileName + ReportsConstants.BACKGROUNG_IN_PROGRESS,
                                Integer.valueOf(vendorInvoiceInputReportsReq.getUserId()),
                                Integer.valueOf(vendorInvoiceInputReportsReq.getUserId()),
                                Integer.valueOf(vendorInvoiceInputReportsReq.getUserId()),
                                ReportsConstants.NOTIFICATION_INITIATED);

                reportsVendorInvoiceRepo.getGenerateBackgroundVendorInvoiceInputReports(vendorInvoiceInputReportsReq,
                                gstinList1, pan, yearOrMonthList, timeStamp, containerName, fileName,
                                (Long) inputReportsDataList.get(ReportsConstants.TOTALCOUNT), id);

                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                ReportsConstants.SUCCESS_MESSAGE_BACKGROUND_DESCRIPTION + fileName + "'");
                return dataAndColumns;

            }

        } else if (ReportsConstants.E_WAY_BILL_REGISTER_REPORT.equals(vendorInvoiceInputReportsReq.getReportId())
                        || ReportsConstants.CUSTOM_E_WAY_BILL_ERROR_REPORT
                                        .equals(vendorInvoiceInputReportsReq.getReportId())
                        || ReportsConstants.CUSTOM_E_WAY_BILL_REGISTER_REPORT
                                        .equals(vendorInvoiceInputReportsReq.getReportId())) {

            int pldTemplateId = 2;
            @SuppressWarnings("unchecked")
            List<EWayBillRegisterReportRes> data = (List<EWayBillRegisterReportRes>) inputReportsDataList
                            .get("inputTabVendorInvoceReportData");
            Map<String, Object> dataAndColumns = new HashMap<>();
            if (ReportsConstants.VIEW.equals(vendorInvoiceInputReportsReq.getButtonType())) {

                List<ReportsCustomColumnsDTO> columnsData = reportModuleCommonRepo.getCustomizeColumnsForView(
                                pldTemplateId, vendorInvoiceInputReportsReq.getReportId(),
                                vendorInvoiceInputReportsReq.getUserId(),
                                vendorInvoiceInputReportsReq.getCustomTemplateId(), summaryType);

                dataAndColumns.put(ReportsConstants.DATA, data);
                dataAndColumns.put(ReportsConstants.COLUMN_DATA, columnsData);
                dataAndColumns.put(ReportsConstants.TOTAL_PAGE_ELEMENTS,
                                inputReportsDataList.get(ReportsConstants.TOTALCOUNT));
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_VIEW_DESCRIPTION);
                return dataAndColumns;

            } else if (ReportsConstants.DOWNLOAD.equals(vendorInvoiceInputReportsReq.getButtonType())) {

                dataAndColumns = reportsVendorInvoiceRepo.getGenerateExcelOrCsvFileofEInvoiceInputReports(
                                vendorInvoiceInputReportsReq, gstinList1, pan, yearOrMonthList, timeStamp,
                                containerName, fileName);
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_EXPORT_DESCRIPTION);

                return dataAndColumns;

            } else if (ReportsConstants.BACKGROUND.equals(vendorInvoiceInputReportsReq.getButtonType())) {
                BigInteger id = reportModuleCommonRepo.insertBackGroundDetails(
                                vendorInvoiceInputReportsReq.getReportId(), ReportsConstants.IN_PROGRESS, timeStamp,
                                vendorInvoiceInputReportsReq.getUserId(), timeStamp, fileName);
                reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORINVOICEMODULEID,
                                fileName + ReportsConstants.BACKGROUNG_IN_PROGRESS,
                                Integer.valueOf(vendorInvoiceInputReportsReq.getUserId()),
                                Integer.valueOf(vendorInvoiceInputReportsReq.getUserId()),
                                Integer.valueOf(vendorInvoiceInputReportsReq.getUserId()),
                                ReportsConstants.NOTIFICATION_INITIATED);

                reportsVendorInvoiceRepo.getGenerateBackgroundVendorInvoiceInputReports(vendorInvoiceInputReportsReq,
                                gstinList1, pan, yearOrMonthList, timeStamp, containerName, fileName,
                                (Long) inputReportsDataList.get(ReportsConstants.TOTALCOUNT), id);
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                ReportsConstants.SUCCESS_MESSAGE_BACKGROUND_DESCRIPTION + fileName + "'");
                return dataAndColumns;
            }

        }

        return Collections.emptyMap();
    }

    @Override
    public Map<String, Object> getVendorInvoiceGETReports(VendorInvoiceGetReqDTO vendorInvoiceGETReportsReq)
                    throws SQLException {

        reportModuleCommonRepo.updateAccessLogTable(LocalDateTime.now(), vendorInvoiceGETReportsReq.getReportId(),
                        vendorInvoiceGETReportsReq.getUserId(), vendorInvoiceGETReportsReq.getEntityId(),
                        vendorInvoiceGETReportsReq.getUserTypeId());

        Map<String, Object> getGETReportsDataList;

        Timestamp timeStamp = new Timestamp(System.currentTimeMillis());
        String containerName = reportModuleCommonRepo.getContainerName(vendorInvoiceGETReportsReq.getEntityId());
        String fileName = "";
        try {
            fileName = reportModuleCommonRepo.getFileName(vendorInvoiceGETReportsReq.getReportId());
        } catch (Exception e) {
            log.error("error in getting file name from database", e);
        }

        String gstinList1 = vendorInvoiceGETReportsReq.getGstinOrPanList().toString().replace("[", "").replace("]", "")
                        .replace("{", "").replace("}", "").replace(" ", "");
        String yearOrMonthList = vendorInvoiceGETReportsReq.getYearOrMonthList().toString().replace("[", "")
                        .replace("]", "").replace("{", "").replace("}", "").replace(" ", "");
        String category = vendorInvoiceGETReportsReq.getCategory().toString().replace("[", "").replace("]", "")
                        .replace("{", "").replace("}", "").replace(" ", "");

        int pldTemplateId = 5;
        int summaryType = 0;

        getGETReportsDataList = reportsVendorInvoiceRepo.getVendorInvoiceGETReportsResList(
                        vendorInvoiceGETReportsReq.getGstinOrPan(), gstinList1,
                        vendorInvoiceGETReportsReq.getYearOrMonth(), yearOrMonthList,
                        vendorInvoiceGETReportsReq.getReportId(), category, vendorInvoiceGETReportsReq.getSummaryType(),
                        vendorInvoiceGETReportsReq.getSize(), vendorInvoiceGETReportsReq.getPage(),
                        vendorInvoiceGETReportsReq.getUserId());

        if (ReportsConstants.GSTR2A_REPORT.equals(vendorInvoiceGETReportsReq.getReportId())) {
            @SuppressWarnings("unchecked")
            List<GSTR2AReportsResDTO> data = (List<GSTR2AReportsResDTO>) getGETReportsDataList
                            .get(ReportsConstants.GETTABVENDORINVOCEREPORTDATA);

            Map<String, Object> dataAndColumns = new HashMap<>();

            if (ReportsConstants.VIEW.equals(vendorInvoiceGETReportsReq.getButtonType())) {

                List<ReportsCustomColumnsDTO> columnsData = reportModuleCommonRepo.getCustomizeColumnsForView(
                                pldTemplateId, vendorInvoiceGETReportsReq.getReportId(),
                                vendorInvoiceGETReportsReq.getUserId(),
                                vendorInvoiceGETReportsReq.getCustomTemplateId(), summaryType);

                dataAndColumns.put(ReportsConstants.DATA, data);
                dataAndColumns.put(ReportsConstants.COLUMN_DATA, columnsData);
                dataAndColumns.put(ReportsConstants.TOTAL_PAGE_ELEMENTS,
                                getGETReportsDataList.get(ReportsConstants.TOTALCOUNT));
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_VIEW_DESCRIPTION);
                return dataAndColumns;

            } else if (ReportsConstants.DOWNLOAD.equals(vendorInvoiceGETReportsReq.getButtonType())) {

                dataAndColumns = reportsVendorInvoiceRepo.getGenerateExcelOrCsvFileofVendorInvoiceGetReports(
                                vendorInvoiceGETReportsReq, gstinList1, yearOrMonthList, category, timeStamp,
                                containerName, fileName);
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_EXPORT_DESCRIPTION);

                return dataAndColumns;

            } else if (ReportsConstants.BACKGROUND.equals(vendorInvoiceGETReportsReq.getButtonType())) {
                BigInteger id = reportModuleCommonRepo.insertBackGroundDetails(vendorInvoiceGETReportsReq.getReportId(),
                                ReportsConstants.IN_PROGRESS, timeStamp, vendorInvoiceGETReportsReq.getUserId(),
                                timeStamp, fileName);
                reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORINVOICEMODULEID,
                                fileName + ReportsConstants.BACKGROUNG_IN_PROGRESS,
                                Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                                Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                                Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                                ReportsConstants.NOTIFICATION_INITIATED);

                reportsVendorInvoiceRepo.getGenerateBackgroundVendorInvoiceGetReports(vendorInvoiceGETReportsReq,
                                gstinList1, yearOrMonthList, category, timeStamp, containerName, fileName,
                                (Long) getGETReportsDataList.get(ReportsConstants.TOTALCOUNT), id);

                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                ReportsConstants.SUCCESS_MESSAGE_BACKGROUND_DESCRIPTION + fileName + "'");
                return dataAndColumns;

            }

        } else if (ReportsConstants.GSTR2B_REPORT.equals(vendorInvoiceGETReportsReq.getReportId())) {

            @SuppressWarnings("unchecked")
            List<GSTR2BReportsResDTO> data = (List<GSTR2BReportsResDTO>) getGETReportsDataList
                            .get(ReportsConstants.GETTABVENDORINVOCEREPORTDATA);
            Map<String, Object> dataAndColumns = new HashMap<>();
            if (ReportsConstants.VIEW.equals(vendorInvoiceGETReportsReq.getButtonType())) {

                List<ReportsCustomColumnsDTO> columnsData = reportModuleCommonRepo.getCustomizeColumnsForView(
                                pldTemplateId, vendorInvoiceGETReportsReq.getReportId(),
                                vendorInvoiceGETReportsReq.getUserId(),
                                vendorInvoiceGETReportsReq.getCustomTemplateId(), summaryType);

                dataAndColumns.put(ReportsConstants.DATA, data);
                dataAndColumns.put(ReportsConstants.COLUMN_DATA, columnsData);
                dataAndColumns.put(ReportsConstants.TOTAL_PAGE_ELEMENTS,
                                getGETReportsDataList.get(ReportsConstants.TOTALCOUNT));
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_VIEW_DESCRIPTION);
                return dataAndColumns;

            } else if (ReportsConstants.DOWNLOAD.equals(vendorInvoiceGETReportsReq.getButtonType())) {

                dataAndColumns = reportsVendorInvoiceRepo.getGenerateExcelOrCsvFileofVendorInvoiceGetReports(
                                vendorInvoiceGETReportsReq, gstinList1, yearOrMonthList, category, timeStamp,
                                containerName, fileName);
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_EXPORT_DESCRIPTION);

                return dataAndColumns;

            } else if (ReportsConstants.BACKGROUND.equals(vendorInvoiceGETReportsReq.getButtonType())) {
                BigInteger id = reportModuleCommonRepo.insertBackGroundDetails(vendorInvoiceGETReportsReq.getReportId(),
                                ReportsConstants.IN_PROGRESS, timeStamp, vendorInvoiceGETReportsReq.getUserId(),
                                timeStamp, fileName);
                reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORINVOICEMODULEID,
                                fileName + ReportsConstants.BACKGROUNG_IN_PROGRESS,
                                Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                                Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                                Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                                ReportsConstants.NOTIFICATION_INITIATED);

                reportsVendorInvoiceRepo.getGenerateBackgroundVendorInvoiceGetReports(vendorInvoiceGETReportsReq,
                                gstinList1, yearOrMonthList, category, timeStamp, containerName, fileName,
                                (Long) getGETReportsDataList.get(ReportsConstants.TOTALCOUNT), id);
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                ReportsConstants.SUCCESS_MESSAGE_BACKGROUND_DESCRIPTION + fileName + "'");
                return dataAndColumns;
            }

        } else if (ReportsConstants.GET_E_WAY_BILL_REPORT.equals(vendorInvoiceGETReportsReq.getReportId())) {

            @SuppressWarnings("unchecked")
            List<GetEWayBillRegisterReportRes> data = (List<GetEWayBillRegisterReportRes>) getGETReportsDataList
                            .get(ReportsConstants.GETTABVENDORINVOCEREPORTDATA);
            Map<String, Object> dataAndColumns = new HashMap<>();
            if (ReportsConstants.VIEW.equals(vendorInvoiceGETReportsReq.getButtonType())) {

                List<ReportsCustomColumnsDTO> columnsData = reportModuleCommonRepo.getCustomizeColumnsForView(
                                pldTemplateId, vendorInvoiceGETReportsReq.getReportId(),
                                vendorInvoiceGETReportsReq.getUserId(),
                                vendorInvoiceGETReportsReq.getCustomTemplateId(), summaryType);

                dataAndColumns.put(ReportsConstants.DATA, data);
                dataAndColumns.put(ReportsConstants.COLUMN_DATA, columnsData);
                dataAndColumns.put(ReportsConstants.TOTAL_PAGE_ELEMENTS,
                                getGETReportsDataList.get(ReportsConstants.TOTALCOUNT));
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_VIEW_DESCRIPTION);
                return dataAndColumns;

            } else if (ReportsConstants.DOWNLOAD.equals(vendorInvoiceGETReportsReq.getButtonType())) {

                dataAndColumns = reportsVendorInvoiceRepo.getGenerateExcelOrCsvFileofVendorInvoiceGetReports(
                                vendorInvoiceGETReportsReq, gstinList1, yearOrMonthList, category, timeStamp,
                                containerName, fileName);
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_EXPORT_DESCRIPTION);

                return dataAndColumns;

            } else if (ReportsConstants.BACKGROUND.equals(vendorInvoiceGETReportsReq.getButtonType())) {
                BigInteger id = reportModuleCommonRepo.insertBackGroundDetails(vendorInvoiceGETReportsReq.getReportId(),
                                ReportsConstants.IN_PROGRESS, timeStamp, vendorInvoiceGETReportsReq.getUserId(),
                                timeStamp, fileName);
                reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORINVOICEMODULEID,
                                fileName + ReportsConstants.BACKGROUNG_IN_PROGRESS,
                                Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                                Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                                Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                                ReportsConstants.NOTIFICATION_INITIATED);
                reportsVendorInvoiceRepo.getGenerateBackgroundVendorInvoiceGetReports(vendorInvoiceGETReportsReq,
                                gstinList1, yearOrMonthList, category, timeStamp, containerName, fileName,
                                (Long) getGETReportsDataList.get(ReportsConstants.TOTALCOUNT), id);
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                ReportsConstants.SUCCESS_MESSAGE_BACKGROUND_DESCRIPTION + fileName + "'");
                return dataAndColumns;
            }

        }

        return new HashMap<>();

    }

    @Override
    public Map<String, Object> getVendorInvoiceSyncReports(VendorInvoiceSyncReqDTO vendorInvoiceSyncReq)
                    throws SQLException {
        reportModuleCommonRepo.updateAccessLogTable(LocalDateTime.now(), vendorInvoiceSyncReq.getReportId(),
                        vendorInvoiceSyncReq.getUserId(), vendorInvoiceSyncReq.getEntityId(),
                        vendorInvoiceSyncReq.getUserTypeId());
        String taxPayerGstinList = vendorInvoiceSyncReq.getGstinOrPanList().toString().replace("[", "").replace("]", "")
                        .replace("{", "").replace("}", "").replace(" ", "");
        String vendorGstinList = vendorInvoiceSyncReq.getVendorGstin().toString().replace("[", "").replace("]", "")
                        .replace("{", "").replace("}", "").replace(" ", "");
        String yearOrMonthList = vendorInvoiceSyncReq.getYearOrMonthList().toString().replace("[", "").replace("]", "")
                        .replace("{", "").replace("}", "").replace(" ", "");
        String category = vendorInvoiceSyncReq.getCategory().toString().replace("[", "").replace("]", "")
                        .replace("{", "").replace("}", "").replace(" ", "");

        Map<String, Object> dataAndCount = reportsVendorInvoiceRepo.getSyncDataList(vendorInvoiceSyncReq,
                        taxPayerGstinList, vendorGstinList, yearOrMonthList, category);
        @SuppressWarnings("unchecked")
        List<VendorInvoiceSyncResDTO> data = (List<VendorInvoiceSyncResDTO>) dataAndCount
                        .get("syncTabVendorInvoceReportData");
        Timestamp timeStamp = new Timestamp(System.currentTimeMillis());
        String containerName = reportModuleCommonRepo.getContainerName(vendorInvoiceSyncReq.getEntityId());
        int pldTemplateId = 5;
        int summaryType = 0;
        String fileName = "";
        try {
            fileName = reportModuleCommonRepo.getFileName(vendorInvoiceSyncReq.getReportId());
        } catch (Exception e) {
            log.error("error in getting file name from database", e);
        }

        Map<String, Object> dataAndColumns = new HashMap<>();
        if (ReportsConstants.VIEW.equals(vendorInvoiceSyncReq.getButtonType())) {

            List<ReportsCustomColumnsDTO> columnsData = reportModuleCommonRepo.getCustomizeColumnsForView(pldTemplateId,
                            vendorInvoiceSyncReq.getReportId(), vendorInvoiceSyncReq.getUserId(),
                            vendorInvoiceSyncReq.getCustomTemplateId(), summaryType);

            dataAndColumns.put(ReportsConstants.DATA, data);
            dataAndColumns.put(ReportsConstants.COLUMN_DATA, columnsData);
            dataAndColumns.put(ReportsConstants.TOTAL_PAGE_ELEMENTS, dataAndCount.get(ReportsConstants.TOTALCOUNT));
            dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                            fileName + ReportsConstants.SUCCESS_MESSAGE_VIEW_DESCRIPTION);
            return dataAndColumns;

        } else if (ReportsConstants.DOWNLOAD.equals(vendorInvoiceSyncReq.getButtonType())) {
            dataAndColumns = reportsVendorInvoiceRepo.getGenerateExcelOrCsvFileofVendorInvoiceSyncReports(
                            vendorInvoiceSyncReq, taxPayerGstinList, vendorGstinList, yearOrMonthList, category,
                            timeStamp, containerName, fileName);
            dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                            fileName + ReportsConstants.SUCCESS_MESSAGE_EXPORT_DESCRIPTION);

            return dataAndColumns;

        } else if (ReportsConstants.BACKGROUND.equals(vendorInvoiceSyncReq.getButtonType())) {
            BigInteger id = reportModuleCommonRepo.insertBackGroundDetails(vendorInvoiceSyncReq.getReportId(),
                            ReportsConstants.IN_PROGRESS, timeStamp, vendorInvoiceSyncReq.getUserId(), timeStamp,
                            fileName);

            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORINVOICEMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_IN_PROGRESS,
                            Integer.valueOf(vendorInvoiceSyncReq.getUserId()),
                            Integer.valueOf(vendorInvoiceSyncReq.getUserId()),
                            Integer.valueOf(vendorInvoiceSyncReq.getUserId()), ReportsConstants.NOTIFICATION_INITIATED);
            reportsVendorInvoiceRepo.getGenerateBackgroundExcelOrCsvFileofVendorInvoiceSyncReports(vendorInvoiceSyncReq,
                            taxPayerGstinList, vendorGstinList, yearOrMonthList, category, timeStamp, containerName,
                            fileName, (Long) dataAndCount.get(ReportsConstants.TOTALCOUNT), id);
            dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                            ReportsConstants.SUCCESS_MESSAGE_BACKGROUND_DESCRIPTION + fileName + "'");
            return dataAndColumns;

        }

        return new HashMap<>();
    }

}
