package com.bdo.bvms.common.service.impl;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.DownloadFileDTO;
import com.bdo.bvms.common.exceptions.BVMSException;
import com.bdo.bvms.common.service.CommonEmptyTemplateService;
import com.bdo.bvms.common.service.CommonMasterService;

@Service

public class CommonEmptyTemplateServiceImpl implements CommonEmptyTemplateService {

    @Autowired
    CommonMasterService commonMasterService;

    @Autowired
    private ResourceLoader resourceLoader;

    @Override
    public Map<String, Object> getHeaderAndFile(DownloadFileDTO downloadFileBytestreamDto)
                    throws BVMSException, IOException {

        Map<String, Object> headerAndFile = new HashMap<>();
        ByteArrayInputStream streamByte;
        ByteArrayInputStream byteArray = null;

        if (!downloadFileBytestreamDto.getCustomtemplateID().isBlank()) {
            AzureConnectionCredentialsDTO azureConnectionCredentialsDTO = commonMasterService
                            .getAzureCredentialFromDB(downloadFileBytestreamDto.getEntityId(), "blob");
            streamByte = commonMasterService.downloadFileByteStream(downloadFileBytestreamDto,
                            azureConnectionCredentialsDTO);
            String fileName = commonMasterService.getFileName(downloadFileBytestreamDto);
            InputStreamResource inputStream = new InputStreamResource(streamByte);
            HttpHeaders headers = new HttpHeaders();
            headers.add(Constants.HEADERS_FILENAME, fileName);
            headers.add(Constants.ACCESS_CONTROL_EXPOSE_HEADERS, Constants.HEADERS_FILENAME);
            headerAndFile.put(Constants.FILE, inputStream);
            headerAndFile.put(Constants.HEADERS, headers);
            return headerAndFile;
        } else if (downloadFileBytestreamDto.getBatchNo().isBlank()
                        && downloadFileBytestreamDto.getDownloadFile().isBlank()) {

            File file = null;
            String fileName = "";
            if (Constants.EINVOICE_TEMPLATE_CODE_ID == downloadFileBytestreamDto.getTemplatetypepldCode()) {
                file = resourceLoader.getResource("classpath:" + "/e-Invoice Template.xlsx").getFile();
            } else if (Constants.EWAYBILL_TEMPLATE_CODE_ID == downloadFileBytestreamDto.getTemplatetypepldCode()) {
                file = resourceLoader.getResource("classpath:" + "/E-Way Bill Template.xlsx").getFile();
            }
            if (file != null) {
                fileName = file.getName();
                byteArray = new ByteArrayInputStream(Files.readAllBytes(file.toPath()));
            }

            InputStreamResource inputstream = new InputStreamResource(byteArray);

            HttpHeaders headers = new HttpHeaders();
            headers.add(Constants.HEADERS_FILENAME, fileName);
            headers.add(Constants.ACCESS_CONTROL_EXPOSE_HEADERS, Constants.HEADERS_FILENAME);
            headerAndFile.put(Constants.FILE, inputstream);
            headerAndFile.put(Constants.HEADERS, headers);

            return headerAndFile;
        }

        else {
            return Collections.emptyMap();
        }

    }

}
