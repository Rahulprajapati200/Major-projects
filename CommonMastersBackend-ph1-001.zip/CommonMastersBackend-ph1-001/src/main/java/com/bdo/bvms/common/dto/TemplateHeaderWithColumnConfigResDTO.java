package com.bdo.bvms.common.dto;

import java.util.List;
import java.util.Set;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TemplateHeaderWithColumnConfigResDTO {

	List<TemplateColumnConfigResDTO> templateColumnConfig;
	
	Set<Integer> conditionalMandatoryGrouping;
	
	List<String> templateColumnHeaders;
	
	String templateUrl;
	
	String templateName;
	
}
