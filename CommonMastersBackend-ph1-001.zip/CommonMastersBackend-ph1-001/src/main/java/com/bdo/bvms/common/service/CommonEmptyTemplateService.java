package com.bdo.bvms.common.service;

import java.io.IOException;
import java.util.Map;

import com.bdo.bvms.common.dto.DownloadFileDTO;
import com.bdo.bvms.common.exceptions.BVMSException;

public interface CommonEmptyTemplateService {

    Map<String, Object> getHeaderAndFile(DownloadFileDTO downloadFileBytestreamDto)
                    throws BVMSException, IOException;

}
