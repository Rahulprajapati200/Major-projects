package com.bdo.bvms.common.repository.impl;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dto.DisableCustomTemplateDTO;
import com.bdo.bvms.common.dto.MailConcatDto;
import com.bdo.bvms.common.dto.ModuleCodeAndNameDTO;
import com.bdo.bvms.common.dto.PanDto;
import com.bdo.bvms.common.dto.SearchCustomEmailDetailsReqDTO;
import com.bdo.bvms.common.model.CustomEmailTemplateCategory;
import com.bdo.bvms.common.model.CustomEmailTemplatePlaceholderDictionary;
import com.bdo.bvms.common.model.CustomTemplateColumnMapping;
import com.bdo.bvms.common.model.CustomTemplateColumnValueMapping;
import com.bdo.bvms.common.model.CustomTemplateDetails;
import com.bdo.bvms.common.model.CustomTemplateEmail;
import com.bdo.bvms.common.model.CustomTemplateEmailArchived;
import com.bdo.bvms.common.model.CustomTemplateName;
import com.bdo.bvms.common.model.CustomTemplateOptionValueDetails;
import com.bdo.bvms.common.model.CustomTemplateOptions;
import com.bdo.bvms.common.model.TemplateColumnConfig;
import com.bdo.bvms.common.model.TemplateModule;
import com.bdo.bvms.common.model.TemplateSampleData;
import com.bdo.bvms.common.model.TemplateType;
import com.bdo.bvms.common.reports.constants.ReportsConstants;
import com.bdo.bvms.common.reports.sql.ReportsCommonSql;
import com.bdo.bvms.common.repository.ICustomTemplateRepository;
import com.bdo.bvms.common.sql.CommonMstSQL;
import com.bdo.bvms.common.util.EncryptionUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class CustomTemplateRepositoryImpl implements ICustomTemplateRepository {

    @Autowired
    private JdbcTemplate jdbcTemplateMst;

    @Value("${mst.database-name}")
    private String mstDatabaseName;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    String loginId;

    @Override
    public List<TemplateColumnConfig> getCustomTemplateColumnConfig(TemplateColumnConfig customTemplateColumnConfig) {
        return jdbcTemplateMst.query(CommonMstSQL.GET_CUSTOM_TEMPLATE_COLUMN_CONFIG_SQL,
                        new RowMapper<TemplateColumnConfig>() {

                            public TemplateColumnConfig mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return TemplateColumnConfig.builder().createdAt(rs.getDate(Constants.CREATED_AT))
                                                .createdBy(rs.getInt("created_by")).id(rs.getInt("id"))
                                                .columnName(rs.getString(Constants.COLUMNNAME))
                                                .dataType(rs.getString("data_type"))
                                                .isMandatory(rs.getObject(Constants.IS_MANDATORY) == null ? null
                                                                : rs.getBoolean(Constants.IS_MANDATORY))
                                                .pldTemplateId(rs.getInt("pld_template_id")).size(rs.getInt("size"))
                                                .conditionalMandatoryGrouping(rs
                                                                .getObject(Constants.CONDITIONMANDATORYGROPING) == null
                                                                                ? null
                                                                                : rs.getInt(Constants.CONDITIONMANDATORYGROPING))
                                                .build();
                            }
                        }, customTemplateColumnConfig.getPldTemplateId());
    }

    @Override
    public void insertCustomTemplateColumnValueMapping(
                    List<CustomTemplateColumnValueMapping> customTemplateColumnValueMappingList) {
        jdbcTemplateMst.batchUpdate(CommonMstSQL.INSERT_CUSTOM_TEMPLATE_COLUMN_VALUE_MAPPING_SQL,
                        new BatchPreparedStatementSetter() {

                            @Override
                            public void setValues(PreparedStatement ps, int i) throws SQLException {
                                CustomTemplateColumnValueMapping customTemplateColumnValueMapping = customTemplateColumnValueMappingList
                                                .get(i);
                                ps.setObject(1, customTemplateColumnValueMapping.getCustomTemplateMappingId());
                                ps.setObject(2, customTemplateColumnValueMapping.getOptionId());
                                ps.setString(3, customTemplateColumnValueMapping.getValues());
                                ps.setObject(4, customTemplateColumnValueMapping.getEntityId());
                                ps.setObject(5, customTemplateColumnValueMapping.getCreatedBy());
                            }

                            @Override
                            public int getBatchSize() {
                                return customTemplateColumnValueMappingList.size();
                            }
                        });
    }

    @Override
    public Integer insertCustomTemplateColumnMapping(CustomTemplateColumnMapping customTemplateColumnMapping) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplateMst.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(CommonMstSQL.INSERT_CUSTOM_TEMPLATE_COLUMN_MAPPING_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, customTemplateColumnMapping.getTemplateColumn());
            ps.setObject(2, customTemplateColumnMapping.getPldTemplateId());
            ps.setString(3, customTemplateColumnMapping.getPan());
            ps.setObject(4, customTemplateColumnMapping.getEntityId());
            ps.setObject(5, customTemplateColumnMapping.getAmTemplateColumnConfigurationId());
            ps.setObject(6, customTemplateColumnMapping.getIsAutoMap());
            ps.setObject(7, customTemplateColumnMapping.getCreatedBy());
            ps.setObject(8, customTemplateColumnMapping.getAmCustomTemplateNameId());
            ps.setObject(9, customTemplateColumnMapping.getStatus());
            return ps;
        }, keyHolder);
        if (keyHolder.getKey() == null) {
            return null;
        } else {
            Number key = keyHolder.getKey();
            return key == null ? null : key.intValue();
        }
    }

    @Override
    public Integer insertCustomTemplateName(CustomTemplateName customTemplateName) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplateMst.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(CommonMstSQL.INSERT_CUSTOM_TEMPLATE_NAME_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1, customTemplateName.getPldTemplateId());
            ps.setString(2, customTemplateName.getPan());
            ps.setObject(3, customTemplateName.getEntityId());
            ps.setString(4, customTemplateName.getName());
            ps.setObject(5, customTemplateName.getCreatedBy());
            ps.setObject(6, customTemplateName.getPldStatus());
            ps.setObject(7, customTemplateName.getIsEmailTemplate());
            return ps;
        }, keyHolder);
        if (keyHolder.getKey() == null) {
            return null;
        } else {
            Number key = keyHolder.getKey();
            return key == null ? null : key.intValue();
        }
    }

    @Override
    public List<CustomTemplateOptions> getCustomTemplateOptions(CustomTemplateOptions customTemplateOptions) {

        return jdbcTemplateMst.query(CommonMstSQL.GET_CUSTOM_TEMPLATE_OPTIONS_SQL,
                        new RowMapper<CustomTemplateOptions>() {

                            public CustomTemplateOptions mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return CustomTemplateOptions.builder().id(rs.getInt("id"))
                                                .templateColumnConfigId(rs.getInt("template_column_config_id"))
                                                .name(rs.getString("name")).build();
                            }
                        }, customTemplateOptions.getTemplateColumnConfigId());
    }

    @Override
    public PageImpl<CustomTemplateName> getCustomTemplatesName(CustomTemplateName customTemplateNameReq,
                    Integer templatePickupMasterId, String pickKey, Integer moduleMasterId, Pageable page,
                    String reportId) {
        String condition = "";
        int pldTemplateId = 0;
        if (!reportId.isBlank()) {

            try {
                pldTemplateId = jdbcTemplateMst.queryForObject(CommonMstSQL.GET_PLD_TEMPLATE_ID_BY_REPORT_CODE,
                                Integer.class, reportId);
            } catch (DataAccessException e) {
                log.error("Error coming at the time of getting pldTemplate id related to a custom report Id", e);
            }
            if (pldTemplateId != 0) {

                condition = " and ctn.pld_template_id=" + pldTemplateId + " ";

            }

        }
        StringBuilder sql = new StringBuilder(CommonMstSQL.GET_CUSTOM_TEMPLATE_TYPE_BY_MODULE_SQL);
        sql.append(" and  ctn.pan IN (" + customTemplateNameReq.getPan() + ") ");
        sql.append(condition);
        if (StringUtils.isNotBlank(customTemplateNameReq.getName())) {
            sql.append("  and ctn.name like '%").append(customTemplateNameReq.getName()).append(
                            "%' order by GREATEST(COALESCE(ctn.modified_at, ctn.created_at), ctn.created_at) DESC  LIMIT ? OFFSET ? ");
        } else {
            sql.append(" order by GREATEST(COALESCE(ctn.modified_at, ctn.created_at), ctn.created_at) DESC  LIMIT ? OFFSET ? ");
        }

        Integer count = countCustomTemplateType(customTemplateNameReq, templatePickupMasterId, pickKey, moduleMasterId,
                        condition);

        if (count > 0) {
            return new PageImpl<>(jdbcTemplateMst.query(sql.toString(), new RowMapper<CustomTemplateName>() {

                public CustomTemplateName mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return CustomTemplateName.builder().id(rs.getInt("id")).userName(rs.getString("user_Name"))
                                    .name(rs.getString("name")).module(rs.getString("module"))
                                    .pldStatus(rs.getInt("pld_status")).createdAt(rs.getTimestamp(Constants.CREATED_AT))
                                    .build();
                }
            }, templatePickupMasterId, pickKey, moduleMasterId, page.getPageSize(), page.getOffset()), page, count);
        }
        return null;
    }

    private Integer countCustomTemplateType(CustomTemplateName customTemplateNameReq, Integer templatePickupMasterId,
                    String pickKey, Integer moduleMasterId, String condition) {
        StringBuilder sql = new StringBuilder(CommonMstSQL.GET_CUSTOM_TEMPLATE_TYPE_BY_MODULE_COUNT_SQL);
        sql.append("   and  ctn.pan IN (" + customTemplateNameReq.getPan() + ") ");
        sql.append(condition);
        if (StringUtils.isNotBlank(customTemplateNameReq.getName())) {
            sql.append(" and  ctn.name like  '%").append(customTemplateNameReq.getName()).append("%' ");
        }
        return jdbcTemplateMst.queryForObject(sql.toString(), Integer.class, templatePickupMasterId, pickKey,
                        moduleMasterId);

    }

    @Override
    public List<CustomTemplateName> getCustomTemplateNames(CustomTemplateName customTemplateNameReq) {

        return jdbcTemplateMst.query(CommonMstSQL.GET_CUSTOM_TEMPLATE_TYPE_SQL, new RowMapper<CustomTemplateName>() {

            public CustomTemplateName mapRow(ResultSet rs, int rowNum) throws SQLException {
                return CustomTemplateName.builder().id(rs.getInt("id")).userName(rs.getString("user_Name"))
                                .name(rs.getString("name")).createdAt(rs.getDate(Constants.CREATED_AT)).build();
            }
        }, customTemplateNameReq.getPldStatus(), customTemplateNameReq.getPan());

    }

    @Override
    public int updateCustomTemplateStatus(CustomTemplateName customTemplateName) {
        return jdbcTemplateMst.update(CommonMstSQL.UPDATE_CUSTOM_TEMPLATE_PLD_STATUS, customTemplateName.getPldStatus(),
                        customTemplateName.getModifiedBy(), customTemplateName.getId());
    }

    @Override
    public CustomTemplateName getCustomTemplateName(CustomTemplateName customTemplateName) {
        return jdbcTemplateMst.queryForObject(CommonMstSQL.GET_CUSTOM_TEMPLATE_NAME_SQL,
                        BeanPropertyRowMapper.newInstance(CustomTemplateName.class),
                        customTemplateName.getIsEmailTemplate(), customTemplateName.getPan(),
                        customTemplateName.getName(), customTemplateName.getPldTemplateId(),
                        Constants.PLD_STATUS_DELETED);
    }

    @Override
    public CustomTemplateName getCustomTemplateNameById(CustomTemplateName customTemplateName) {
        return jdbcTemplateMst.queryForObject(CommonMstSQL.GET_CUSTOM_TEMPLATE_NAME_BY_ID_SQL,
                        BeanPropertyRowMapper.newInstance(CustomTemplateName.class), customTemplateName.getId());
    }

    // By Akshay
    @Override
    public Map<String, Object> searchCustomTemplateOptionsMappings(int customTemplateId, String primaryContactLkUpName,
                    String defaultAddressLkUpName, String primaryBankLkUpName, String addressTypeLkUpName) {
        return jdbcTemplateMst.query(CommonMstSQL.GET_CUSTOM_TEMPLATE_MAPPING_OPTIONS_MAPPINGS_SQL,
                        new ResultSetExtractor<Map<String, Object>>() {

                            @Override
                            public Map<String, Object> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                Map<String, Object> opMapRet = new HashMap<>();

                                Map<String, Map<String, Integer>> mapRet = new HashMap<>();
                                Map<String, Map<String, String>> standarCustomMapRet = new HashMap<>();
                                while (rs.next()) {

                                    if (mapRet.get(rs.getString("name")) == null) {
                                        Map<String, Integer> pldMap = new HashMap<>();
                                        pldMap.put(rs.getString(Constants.VALUE), rs.getInt("code"));
                                        mapRet.put(rs.getString("name"), pldMap);
                                    } else {
                                        mapRet.get(rs.getString("name")).put(rs.getString(Constants.VALUE),
                                                        rs.getInt("code"));
                                    }

                                    if (standarCustomMapRet.get(rs.getString("name")) == null) {
                                        Map<String, String> pldMap = new HashMap<>();
                                        pldMap.put(rs.getString("standardOption"), rs.getString("value"));
                                        standarCustomMapRet.put(rs.getString("name"), pldMap);
                                    } else {
                                        standarCustomMapRet.get(rs.getString("name"))
                                                        .put(rs.getString("standardOption"), rs.getString("value"));
                                    }

                                }

                                opMapRet.put("customMap", mapRet);
                                opMapRet.put("standardCustomMap", standarCustomMapRet);

                                return opMapRet;
                            }
                        }, customTemplateId, primaryContactLkUpName, defaultAddressLkUpName, primaryBankLkUpName,
                        addressTypeLkUpName);

    }

    // By Akshay
    @Override
    public Map<String, String> searchCustomTemplateHeaderMappings(int customTemplateId) {
        return jdbcTemplateMst.query(CommonMstSQL.GET_CUSTOM_TEMPLATE_HEADER_MAPPING_SQL,
                        new ResultSetExtractor<Map<String, String>>() {

                            @Override
                            public Map<String, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                Map<String, String> mapRet = new HashMap<>();
                                while (rs.next()) {
                                    mapRet.put(rs.getString("standardHeader"), rs.getString("customHeader"));
                                }
                                return mapRet;
                            }
                        }, customTemplateId);
    }

    @Override
    public void insertTemplateSampleData(TemplateSampleData templateSampleData) {

        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplateMst.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(CommonMstSQL.INSERT_TEMPLATE_SAMPLE_DATA_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1, templateSampleData.getAmCustomTemplateColumnMappingId()); // column
            // mapping
            // id
            // need
            // to
            // be
            // changed
            // to
            // name
            // id
            ps.setObject(2, templateSampleData.getColumnName());
            ps.setString(3, templateSampleData.getColumnValue());
            ps.setObject(4, templateSampleData.getCreatedBy());
            return ps;
        }, keyHolder);

    }

    @Override
    public List<CustomTemplateDetails> getCustomTemplateMappingDetails(
                    CustomTemplateColumnMapping customTemplateColumnMapping) {
        return jdbcTemplateMst.query(CommonMstSQL.GET_CUSTOM_TEMPLATE_DETAILS_SQL,
                        new RowMapper<CustomTemplateDetails>() {

                            public CustomTemplateDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return CustomTemplateDetails.builder().columnName(rs.getString(Constants.COLUMNNAME))
                                                .customTemplateColumnMappingId(
                                                                rs.getInt("customTemplateColumnMappingId"))
                                                .dataType(rs.getString("data_type"))
                                                .isAutoMap(rs.getBoolean("is_auto_map"))
                                                .isMandatory(rs.getBoolean(Constants.IS_MANDATORY))
                                                .size(rs.getInt("size")).templateColumn(rs.getString("template_column"))
                                                .pldTemplateId(rs.getInt("pld_template_id")).id(rs.getInt("id"))
                                                .conditionalMandatoryGrouping(
                                                                rs.getObject("conditional_mandatory_grouping") == null
                                                                                ? null
                                                                                : rs.getInt("conditional_mandatory_grouping"))
                                                .build();
                            }
                        }, customTemplateColumnMapping.getAmCustomTemplateNameId(),
                        customTemplateColumnMapping.getStatus());
    }

    @Override
    public List<CustomTemplateOptionValueDetails> getCustomTemplateOptionsValueMapping(
                    CustomTemplateColumnMapping customTemplateColumnMapping) {
        return jdbcTemplateMst.query(CommonMstSQL.GET_CUSTOM_TEMPLATE_OPTIONS_VALUE_MAPPING_SQL,
                        new RowMapper<CustomTemplateOptionValueDetails>() {

                            public CustomTemplateOptionValueDetails mapRow(ResultSet rs, int rowNum)
                                            throws SQLException {
                                return CustomTemplateOptionValueDetails.builder()
                                                .optionId(rs.getObject("option_id") == null ? null
                                                                : rs.getInt("option_id"))
                                                .customTemplateColumnValueMappingId(
                                                                rs.getObject("id") == null ? null : rs.getInt("id"))
                                                .name(rs.getString("name")).values(rs.getString("values")).build();
                            }
                        }, customTemplateColumnMapping.getId(),
                        customTemplateColumnMapping.getAmTemplateColumnConfigurationId());
    }

    @Override
    public CustomTemplateColumnMapping checkIfCustomTemplateColumnMappingExists(
                    CustomTemplateColumnMapping customTemplateColumnMapping) {
        return jdbcTemplateMst.queryForObject(CommonMstSQL.GET_CUSTOM_TEMPLATE_COLUMN_MAPPING_BY_ID_SQL,
                        BeanPropertyRowMapper.newInstance(CustomTemplateColumnMapping.class),
                        customTemplateColumnMapping.getId());
    }

    @Override
    public int updateCustomTemplateMapping(CustomTemplateColumnMapping customTemplateColumnMapping) {
        return jdbcTemplateMst.update(CommonMstSQL.UPDATE_CUSTOM_TEMPLATE_MAPPING,
                        customTemplateColumnMapping.getTemplateColumn(), customTemplateColumnMapping.getIsAutoMap(),
                        customTemplateColumnMapping.getModifiedBy(), customTemplateColumnMapping.getStatus(),
                        customTemplateColumnMapping.getId());
    }

    @Override
    public CustomTemplateColumnValueMapping checkIfCustomTemplateColumnValueMappingExistsById(
                    CustomTemplateColumnValueMapping customTemplateColumnValueMapping) {
        return jdbcTemplateMst.queryForObject(CommonMstSQL.GET_CUSTOM_TEMPLATE_COLUMN_VALUE_MAPPING_BY_ID_SQL,
                        BeanPropertyRowMapper.newInstance(CustomTemplateColumnValueMapping.class),
                        customTemplateColumnValueMapping.getId());
    }

    @Override
    public int updateCustomTemplateColumnValueMapping(
                    CustomTemplateColumnValueMapping customTemplateColumnValueMapping) {
        return jdbcTemplateMst.update(CommonMstSQL.UPDATE_CUSTOM_TEMPLATE_COLUMN_VALUE_MAPPING_SQL,
                        customTemplateColumnValueMapping.getValues(), customTemplateColumnValueMapping.getId());
    }

    @Override
    public CustomTemplateColumnValueMapping checkIfCustomTemplateColumnValueMappingExists(
                    CustomTemplateColumnValueMapping customTemplateColumnValueMapping) {
        return jdbcTemplateMst.queryForObject(CommonMstSQL.GET_CUSTOM_TEMPLATE_COLUMN_VALUE_MAPPING_SQL,
                        BeanPropertyRowMapper.newInstance(CustomTemplateColumnValueMapping.class),
                        customTemplateColumnValueMapping.getCustomTemplateMappingId(),
                        customTemplateColumnValueMapping.getOptionId());
    }

    @Override
    public List<TemplateSampleData> getCustomTemplateSampleData(TemplateSampleData templateSampleData) {

        return jdbcTemplateMst.query(CommonMstSQL.GET_CUSTOM_TEMPLATE_SAMPLE_DATA, new RowMapper<TemplateSampleData>() {

            public TemplateSampleData mapRow(ResultSet rs, int rowNum) throws SQLException {
                return TemplateSampleData.builder()
                                .columnName(rs.getObject("column_name") == null ? null : rs.getString("column_name"))
                                .columnValue(rs.getObject("column_value") == null ? null : rs.getString("column_value"))
                                .build();
            }
        }, templateSampleData.getAmCustomTemplateNameId());
    }

    @Override
    public List<TemplateModule> getCustomModuleList(CustomTemplateName customTemplateNameReq,
                    Integer templateTypePickupMasterId, Integer modulePickupMasterId) {

        StringBuilder sql = new StringBuilder(CommonMstSQL.GET_CUSTOM_TEMPLATE_MODULE_LIST_SQL);
        if (StringUtils.isNotBlank(customTemplateNameReq.getName())) {
            sql.append("  and ctn.name like  '%").append(customTemplateNameReq.getName()).append("%' ");
        }

        sql.append("group by modulepld.code,modulepld.name ) moduledata");

        return jdbcTemplateMst.query(sql.toString(), new RowMapper<TemplateModule>() {

            public TemplateModule mapRow(ResultSet rs, int rowNum) throws SQLException {
                return TemplateModule.builder().id(rs.getInt("moduleid")).moduleName(rs.getString("modulename"))
                                .count(rs.getInt("count")).build();
            }
        }, templateTypePickupMasterId, customTemplateNameReq.getPan(), modulePickupMasterId);

    }

    @Override
    public List<TemplateModule> getDefaultModuleList(Integer templateTypePickupMasterId, Integer modulePickupMasterId) {

        StringBuilder sql = new StringBuilder(CommonMstSQL.getDefalutTemplateList(mstDatabaseName));

        return jdbcTemplateMst.query(sql.toString(), new RowMapper<TemplateModule>() {

            public TemplateModule mapRow(ResultSet rs, int rowNum) throws SQLException {
                return TemplateModule.builder().id(rs.getInt("moduleid")).moduleName(rs.getString("modulename"))
                                .count(rs.getInt("count")).build();
            }
        }, templateTypePickupMasterId, modulePickupMasterId);
    }

    @Override
    public List<ModuleCodeAndNameDTO> getModuleNameAndCode(int pickupMasterId, int pickKey) {
        String sql = "";
        if (pickKey == 110) {
            sql = CommonMstSQL.getModuleWiseCustomTemplateListSql(mstDatabaseName);
        } else {
            sql = CommonMstSQL.getModuleWiseCustomTemplateListModuleWiseSql(mstDatabaseName);
        }

        return jdbcTemplateMst.query(sql, new RowMapper<ModuleCodeAndNameDTO>() {

            public ModuleCodeAndNameDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
                return ModuleCodeAndNameDTO.builder().moduleName(rs.getString("name")).moduleCode(rs.getString("code"))
                                .build();

            }
        }, pickupMasterId, pickKey);

    }

    @Override
    public List<CustomEmailTemplatePlaceholderDictionary> searchCustomEmailPlaceHolders(
                    CustomEmailTemplatePlaceholderDictionary customEmailTemplatePlaceholderDictionary) {
        return jdbcTemplateMst.query(CommonMstSQL.GET_CUSTOM_EMAIL_TEMPLATE_PLACEHOLDERS_DICTIONARY_SQL,
                        new RowMapper<CustomEmailTemplatePlaceholderDictionary>() {

                            public CustomEmailTemplatePlaceholderDictionary mapRow(ResultSet rs, int rowNum)
                                            throws SQLException {
                                return CustomEmailTemplatePlaceholderDictionary.builder()
                                                .createdAt(rs.getDate(Constants.CREATED_AT))
                                                .createdBy(rs.getInt("created_by")).id(rs.getInt("id"))
                                                .description(rs.getString("description"))
                                                .mapValue(rs.getString("map_value")).name(rs.getString("name"))
                                                .pldModuleId(rs.getInt("pld_module_id"))
                                                .refTemplateId(rs.getInt("ref_template_id")).status(rs.getInt("status"))
                                                .build();
                            }
                        }, customEmailTemplatePlaceholderDictionary.getPldModuleId(),
                        customEmailTemplatePlaceholderDictionary.getRefTemplateId());
    }

    @Override
    public CustomTemplateName getCustomEmailTemplateName(CustomTemplateName customTemplateName) {
        return jdbcTemplateMst.queryForObject(CommonMstSQL.GET_CUSTOM_TEMPLATE_NAME_SQL,
                        BeanPropertyRowMapper.newInstance(CustomTemplateName.class), customTemplateName.getPan(),
                        customTemplateName.getName(), customTemplateName.getPldTemplateId());
    }

    @Override
    public Integer insertCustomTemplateEmail(CustomTemplateEmail customTemplateEmail) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplateMst.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(CommonMstSQL.INSERT_CUSTOM_TEMPLATE_EMAIL_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1, customTemplateEmail.getCustomTemplateNameId());
            ps.setString(2, customTemplateEmail.getPan());
            ps.setObject(3, customTemplateEmail.getEntityId());
            ps.setString(4, customTemplateEmail.getMailSubject());
            ps.setString(5, customTemplateEmail.getMailBody());
            ps.setString(6, customTemplateEmail.getMailFooter());
            ps.setString(7, customTemplateEmail.getDefaultCcReceipentsEmail());
            ps.setObject(8, customTemplateEmail.getDisclaimer());
            ps.setObject(9, customTemplateEmail.getIsHighImportance());
            ps.setObject(10, customTemplateEmail.getEnableNotificationQueue());
            ps.setObject(11, customTemplateEmail.getRefTemplateId());
            ps.setBoolean(12, customTemplateEmail.getIsDefaultTemplate());
            ps.setObject(13, customTemplateEmail.getSignatureLogoSizeKb());
            ps.setObject(14, customTemplateEmail.getSignatureLogoFileExt());
            ps.setObject(15, customTemplateEmail.getSignatureLogoImage());
            ps.setObject(16, customTemplateEmail.getCompanyLogoSizeKb());
            ps.setObject(17, customTemplateEmail.getCompanyLogoFileExt());
            ps.setObject(18, customTemplateEmail.getCompanyLogoImage());
            ps.setObject(19, customTemplateEmail.getSignatureText());
            return ps;
        }, keyHolder);
        if (keyHolder.getKey() == null) {
            return null;
        } else {
            Number key = keyHolder.getKey();
            return key == null ? null : key.intValue();
        }
    }

    @Override
    public int updateCustomTemplateEmail(CustomTemplateEmail customTemplateEmail) {
        return jdbcTemplateMst.update(CommonMstSQL.UPDATE_CUSTOM_TEMPLATE_EMAIL_SQL,
                        customTemplateEmail.getMailSubject(), customTemplateEmail.getMailBody(),
                        customTemplateEmail.getMailFooter(), customTemplateEmail.getSignatureLogoSizeKb(),
                        customTemplateEmail.getSignatureLogoFileExt(), customTemplateEmail.getSignatureLogoImage(),
                        customTemplateEmail.getCompanyLogoSizeKb(), customTemplateEmail.getCompanyLogoFileExt(),
                        customTemplateEmail.getCompanyLogoImage(), customTemplateEmail.getSignatureText(),
                        customTemplateEmail.getCustomTemplateNameId());
    }

    @Override
    public Integer insertCustomTemplateEmailArchived(CustomTemplateEmailArchived customTemplateEmailArchived) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplateMst.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(CommonMstSQL.INSERT_CUSTOM_TEMPLATE_EMAIL_ARCHIVED_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1, customTemplateEmailArchived.getCustomTemplateEmailid());
            ps.setString(2, customTemplateEmailArchived.getPan());
            ps.setObject(3, customTemplateEmailArchived.getEntityId());
            ps.setString(4, customTemplateEmailArchived.getMailSubject());
            ps.setString(5, customTemplateEmailArchived.getMailBody());
            ps.setString(6, customTemplateEmailArchived.getMailFooter());
            ps.setString(7, customTemplateEmailArchived.getDefaultCcReceipentsEmail());
            ps.setObject(8, customTemplateEmailArchived.getDisclaimer());
            ps.setObject(9, customTemplateEmailArchived.getIsHighImportance());
            ps.setObject(10, customTemplateEmailArchived.getEnableNotificationQueue());
            ps.setObject(11, customTemplateEmailArchived.getRefTemplateId());
            ps.setObject(12, customTemplateEmailArchived.getIsDefaultTemplate());
            ps.setObject(13, customTemplateEmailArchived.getSignatureLogoSizeKb());
            ps.setObject(14, customTemplateEmailArchived.getSignatureLogoFileExt());
            ps.setObject(15, customTemplateEmailArchived.getSignatureLogoImage());
            ps.setObject(16, customTemplateEmailArchived.getCompanyLogoSizeKb());
            ps.setObject(17, customTemplateEmailArchived.getCompanyLogoFileExt());
            ps.setObject(18, customTemplateEmailArchived.getCompanyLogoImage());
            return ps;
        }, keyHolder);
        if (keyHolder.getKey() == null) {
            return null;
        } else {
            Number key = keyHolder.getKey();
            return key == null ? null : key.intValue();
        }
    }

    @Override
    public int updateCustomTemplateEmailModifiedaAt(CustomTemplateEmail customTemplateEmail, String customTemplateName,
                    String userId) {
        return jdbcTemplateMst.update(CommonMstSQL.UPDATE_CUSTOM_TEMPLATE_EMAIL_MODIFIED_AT_SQL, userId,
                        customTemplateName, customTemplateEmail.getCustomTemplateNameId());

    }

    @Override
    public CustomTemplateEmail checkIfCustomTemplateEmailExists(CustomTemplateEmail customTemplateEmail) {
        return jdbcTemplateMst.queryForObject(CommonMstSQL.GET_CUSTOM_TEMPLATE_EMAIL_BY_NAME_ID_SQL,
                        new RowMapper<CustomTemplateEmail>() {

                            public CustomTemplateEmail mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return CustomTemplateEmail.builder()
                                                .customTemplateNameId(rs.getInt("custom_template_name_id"))
                                                .defaultCcReceipentsEmail(rs.getString("default_cc_receipents_email"))
                                                .mailBody(rs.getString("mail_body")).pan(rs.getString("PAN"))
                                                .mailFooter(rs.getString("mail_footer"))
                                                .mailSubject(rs.getString("mail_subject")).id(rs.getInt("id"))
                                                .entityId(rs.getInt("entity_id"))
                                                .refTemplateId(rs.getInt("ref_template_id"))
                                                .isDefaultTemplate(rs.getBoolean("is_default_template"))
                                                .signatureLogoFileExt(rs.getString("signature_logo_file_ext"))
                                                .signatureLogoImage(rs.getBlob("signature_logo_image"))
                                                .signatureLogoSizeKb(rs.getLong("signature_logo_size_kb"))
                                                .companyLogoFileExt(rs.getString("company_logo_file_ext"))
                                                .companyLogoImage(rs.getBlob("company_logo_image"))
                                                .companyLogoSizeKb(rs.getLong("company_logo_size_kb")).build();
                            }
                        }, customTemplateEmail.getCustomTemplateNameId());
    }

    @Override
    public List<TemplateModule> getCustomEmailModuleList(CustomTemplateName customTemplateNameReq,
                    Integer modulePickupMasterId, Integer isDefaultTemplate) {

        StringBuilder sql = new StringBuilder(CommonMstSQL.GET_CUSTOM_TEMPLATE_EMAIL_MODULE_LIST_SQL);
        if (StringUtils.isNotBlank(customTemplateNameReq.getName())) {
            sql.append(" and tempname.name like  '%").append(customTemplateNameReq.getName()).append("%' ");
        }

        sql.append("group by modulepld.code,modulepld.name ) moduledata");

        return jdbcTemplateMst.query(sql.toString(), new RowMapper<TemplateModule>() {

            public TemplateModule mapRow(ResultSet rs, int rowNum) throws SQLException {
                return TemplateModule.builder().id(rs.getInt("moduleid")).moduleName(rs.getString("modulename"))
                                .count(rs.getInt("count")).build();
            }
        }, Constants.CUSTOM_EMAIL_TEMPLATE_CATEGORY_IS_ACTIVE_YES, isDefaultTemplate, customTemplateNameReq.getPan(),
                        Constants.PLD_STATUS_ACTIVE, Constants.PLD_STATUS_INACTIVE, modulePickupMasterId);
    }

    @Override
    public List<TemplateModule> getDefaultEmailModuleList(CustomTemplateName customTemplateNameReq,
                    Integer modulePickupMasterId, Integer isDefaultTemplate) {

        StringBuilder sql = new StringBuilder(CommonMstSQL.GET_DEFAULT_TEMPLATE_EMAIL_MODULE_LIST_SQL);
        if (StringUtils.isNotBlank(customTemplateNameReq.getName())) {
            sql.append(" and tempname.name like  '%").append(customTemplateNameReq.getName()).append("%' ");
        }

        sql.append("group by modulepld.code,modulepld.name ) moduledata");

        return jdbcTemplateMst.query(sql.toString(), new RowMapper<TemplateModule>() {

            public TemplateModule mapRow(ResultSet rs, int rowNum) throws SQLException {
                return TemplateModule.builder().id(rs.getInt("moduleid")).moduleName(rs.getString("modulename"))
                                .count(rs.getInt("count")).build();
            }
        }, Constants.CUSTOM_EMAIL_TEMPLATE_CATEGORY_IS_ACTIVE_YES, isDefaultTemplate, Constants.PLD_STATUS_ACTIVE,
                        Constants.PLD_STATUS_INACTIVE, modulePickupMasterId);
    }

    @Override
    public PageImpl<CustomTemplateName> getCustomEmailTemplatesName(CustomTemplateName customTemplateNameReq,
                    Pageable page, Boolean isDefaultTemplate) {
        StringBuilder sql = new StringBuilder(CommonMstSQL.GET_CUSTOM_EMAIL_TEMPLATE_TYPE_BY_MODULE_SQL);
        sql.append("   and ctn.pan   IN (" + customTemplateNameReq.getPan() + ") ");
        if (StringUtils.isNotBlank(customTemplateNameReq.getName())) {
            sql.append(" and   ctn.name like '%").append(customTemplateNameReq.getName())
                            .append("%' order by     ctn.modified_at desc ,ctn.created_at desc  LIMIT ? OFFSET ? ");
        } else {
            sql.append(" order by COALESCE(ctn.modified_at,ctn.created_at) desc  LIMIT ? OFFSET ? ");
        }

        Integer count = countCustomEmailTemplateType(customTemplateNameReq, isDefaultTemplate);

        if (count > 0) {
            return new PageImpl<>(jdbcTemplateMst.query(sql.toString(), new RowMapper<CustomTemplateName>() {

                public CustomTemplateName mapRow(ResultSet rs, int rowNum) throws SQLException {
                    LocalDateTime localDateTime = rs.getObject(Constants.CREATED_AT, LocalDateTime.class);
                    Date date = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
                    return CustomTemplateName.builder().id(rs.getInt("id")).userName(rs.getString("user_Name"))
                                    .name(rs.getString("name")).module(rs.getString("module"))
                                    .pldStatus(rs.getInt("pld_status")).pldModuleId(rs.getInt("pldModuleId"))
                                    .createdAt(date).refId(rs.getString("ref_template_id")).build();
                }
            }, Constants.PLD_STATUS_ACTIVE, Constants.PLD_STATUS_INACTIVE, Constants.IS_EMAIL_TEMPLATE_YES,
                            Constants.CUSTOM_EMAIL_TEMPLATE_CATEGORY_IS_ACTIVE_YES, isDefaultTemplate,
                            customTemplateNameReq.getPldTemplateId(), page.getPageSize(), page.getOffset()), page,
                            count);
        }
        return null;
    }

    private Integer countCustomEmailTemplateType(CustomTemplateName customTemplateNameReq, Boolean isDefaultTemplate) {
        StringBuilder sql = new StringBuilder(CommonMstSQL.GET_CUSTOM_EMAIL_TEMPLATE_BY_MODULE_COUNT_SQL);
        sql.append("   and   ctn.pan    IN (" + customTemplateNameReq.getPan() + ") ");
        if (StringUtils.isNotBlank(customTemplateNameReq.getName())) {
            sql.append(" and ctn.name   like  '%").append(customTemplateNameReq.getName()).append("%' ");
        }
        sql.append("  ) count ");
        return jdbcTemplateMst.queryForObject(sql.toString(), Integer.class, Constants.PLD_STATUS_ACTIVE,
                        Constants.PLD_STATUS_INACTIVE, Constants.IS_EMAIL_TEMPLATE_YES,
                        Constants.CUSTOM_EMAIL_TEMPLATE_CATEGORY_IS_ACTIVE_YES, isDefaultTemplate,
                        customTemplateNameReq.getPldTemplateId());

    }

    @Override
    public void disableCustomTemplate(DisableCustomTemplateDTO disableCustomTemplateDTO) {

//        int templateId = 20;
//
//        if ("1".equals(disableCustomTemplateDTO.getIsDisabled())) {
//            templateId = 10;
//        }

        String query = CommonMstSQL.UPDATE_PLD_STATUS_CUSTOM_TEMPLATE;

        jdbcTemplateMst.update(query, disableCustomTemplateDTO.getIsDisabled(),
                        disableCustomTemplateDTO.getCustomTemplateId());

    }

    @Override
    public CustomTemplateEmail searchDefaultEmailDetails(CustomTemplateEmail customTemplateEmail, Integer moduleId) {
        return jdbcTemplateMst.queryForObject(CommonMstSQL.GET_DEFAULT_EMAIL_TEMPLATE_SQL,
                        new RowMapper<CustomTemplateEmail>() {

                            public CustomTemplateEmail mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return CustomTemplateEmail.builder().mailBody(rs.getString("mail_body"))
                                                .customTemplateName(rs.getString("name"))
                                                .mailSubject(rs.getString("mail_subject")).build();
                            }
                        }, moduleId, customTemplateEmail.getRefTemplateId(),
                        customTemplateEmail.getIsDefaultTemplate());
    }

    @Override
    public List<CustomEmailTemplateCategory> getCustomEmailTemplateCategory(
                    CustomEmailTemplateCategory customEmailTemplateCategory) {
        return jdbcTemplateMst.query(CommonMstSQL.GET_CUSTOM_EMAIL_TEMPLATE_CATEGORY_SQL,
                        new RowMapper<CustomEmailTemplateCategory>() {

                            public CustomEmailTemplateCategory mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return CustomEmailTemplateCategory.builder().id(rs.getInt("id"))
                                                .pldModuleId(rs.getInt("pld_module_id"))
                                                .subCategory(rs.getString("sub_category")).build();
                            }
                        }, customEmailTemplateCategory.getIsActive(), customEmailTemplateCategory.getPldModuleId());
    }

    @Override
    public List<CustomEmailTemplateCategory> getCustomEmailModuleList() {
        return jdbcTemplateMst.query(CommonMstSQL.GET_CUSTOM_EMAIL_TEMPLATE_MODULES_SQL,
                        new RowMapper<CustomEmailTemplateCategory>() {

                            public CustomEmailTemplateCategory mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return CustomEmailTemplateCategory.builder().pldModuleId(rs.getInt("pld_module_id"))
                                                .name(rs.getString("name")).build();
                            }
                        }, Constants.PICKUP_MASTER_MODULES);
    }

    @Override
    public CustomTemplateEmail getCustomEmailTemplateDetails(CustomTemplateEmail customTemplateEmail) {
        if (log.isDebugEnabled()) {
            log.debug("Custom Template Email Query", CommonMstSQL.GET_CUSTOM_EMAIL_TEMPLATE_DETAILS_SQL);
        }
        return jdbcTemplateMst.queryForObject(CommonMstSQL.GET_CUSTOM_EMAIL_TEMPLATE_DETAILS_SQL,
                        new RowMapper<CustomTemplateEmail>() {

                            public CustomTemplateEmail mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return CustomTemplateEmail.builder().mailBody(rs.getString("mail_body"))
                                                .moduleName(rs.getString("module_name"))
                                                .mailBody(rs.getString("mail_body"))
                                                .customTemplateName(rs.getString("name"))
                                                .refTemplateName(rs.getString("sub_category"))
                                                .customTemplateNameId(rs.getInt("custom_template_name_id"))
                                                .refTemplateId(rs.getInt("ref_template_id"))
                                                .pldTemplateId(rs.getInt("pld_template_id"))
                                                .mailSubject(rs.getString("mail_subject"))
                                                .signatureLogoSizeKb(rs.getLong("signature_logo_size_kb"))
                                                .signatureLogoFileExt(rs.getString("signature_logo_file_ext"))
                                                .signatureLogoImage(rs.getBlob("signature_logo_image"))
                                                .companyLogoFileExt(rs.getString("company_logo_file_ext"))
                                                .companyLogoImage(rs.getBlob("company_logo_image"))
                                                .signatureText(rs.getString("signature_body"))
                                                .companyLogoSizeKb(rs.getLong("company_logo_size_kb")).build();
                            }
                        }, customTemplateEmail.getCustomTemplateNameId());
    }

    @Override
    public PageImpl<CustomTemplateName> getDefaultEmailTemplatesName(CustomTemplateName customTemplateNameReq,
                    Pageable page, Boolean isDefaultTemplate) {
        StringBuilder sql = new StringBuilder(CommonMstSQL.GET_DEFAULT_EMAIL_TEMPLATE_TYPE_BY_MODULE_SQL);
        if (customTemplateNameReq.getName() != null && StringUtils.isNotBlank(customTemplateNameReq.getName())) {
            sql.append(" and ctn.name   like '%").append(customTemplateNameReq.getName())
                            .append("%' order by ctn.modified_at desc ,ctn.created_at    desc  LIMIT ? OFFSET ? ");
        } else {
            sql.append(" order by ctn.modified_at desc ,ctn.created_at desc  LIMIT ? OFFSET ? ");
        }

        Integer count = countDefaultEmailTemplateType(customTemplateNameReq, isDefaultTemplate);

        if (count > 0) {
            return new PageImpl<>(jdbcTemplateMst.query(sql.toString(), new RowMapper<CustomTemplateName>() {

                public CustomTemplateName mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return CustomTemplateName.builder().id(rs.getInt("id")).userName(rs.getString("user_Name"))
                                    .name(rs.getString("name")).module(rs.getString("module"))
                                    .pldStatus(rs.getInt("pld_status")).createdAt(rs.getTimestamp(Constants.CREATED_AT))
                                    .build();
                }
            }, Constants.PLD_STATUS_ACTIVE, Constants.PLD_STATUS_INACTIVE, Constants.IS_EMAIL_TEMPLATE_YES,
                            Constants.CUSTOM_EMAIL_TEMPLATE_CATEGORY_IS_ACTIVE_YES, isDefaultTemplate,
                            customTemplateNameReq.getPldTemplateId(), page.getPageSize(), page.getOffset()), page,
                            count);
        }
        return new PageImpl<>(new ArrayList<>());
    }

    private Integer countDefaultEmailTemplateType(CustomTemplateName customTemplateNameReq, Boolean isDefaultTemplate) {
        StringBuilder sql = new StringBuilder(CommonMstSQL.GET_CUSTOM_EMAIL_TEMPLATE_BY_MODULE_COUNT_SQL);
        if (StringUtils.isNotBlank(customTemplateNameReq.getName())) {
            sql.append(" and ctn.name like  '%").append(customTemplateNameReq.getName()).append("%' ");
        }
        sql.append("  ) count ");
        return jdbcTemplateMst.queryForObject(sql.toString(), Integer.class, Constants.PLD_STATUS_ACTIVE,
                        Constants.PLD_STATUS_INACTIVE, Constants.IS_EMAIL_TEMPLATE_YES,
                        Constants.CUSTOM_EMAIL_TEMPLATE_CATEGORY_IS_ACTIVE_YES, isDefaultTemplate,
                        customTemplateNameReq.getPldTemplateId());

    }

    @Override
    public PageImpl<CustomTemplateName> getCustomTemplatesListName(CustomTemplateName customTemplateNameReq,
                    Integer templatePickupMasterId, String pickKey, Integer moduleMasterId, Pageable page,
                    String reportId) {

        String condition = "";
        int pldTemplateId = 0;
        if (!StringUtils.isBlank(reportId)) {

            try {
                pldTemplateId = jdbcTemplateMst.queryForObject(CommonMstSQL.GET_PLD_TEMPLATE_ID_BY_REPORT_CODE,
                                Integer.class, reportId);
            } catch (DataAccessException e) {
                log.error("Error coming at the time of getting pldTemplate id related to a custom report Id", e);
            }
            if (pldTemplateId != 0) {

                condition = " and ctn.pld_template_id=" + pldTemplateId + " ";

            }

        }
        StringBuilder sql = new StringBuilder(CommonMstSQL.GET_CUSTOM_TEMPLATE_LIST_TYPE_BY_MODULE_SQL);
        sql.append("and    ctn.pan IN (" + customTemplateNameReq.getPan() + ") ");

        sql.append(condition);
        if (StringUtils.isNotBlank(customTemplateNameReq.getName())) {
            sql.append(" and ctn.name like '%").append(customTemplateNameReq.getName())
                            .append("%' order by ctn.modified_at desc ,ctn.created_at desc  LIMIT ? OFFSET ? ");
        } else {
            sql.append(" order    by ctn.modified_at desc ,ctn.created_at desc  LIMIT ? OFFSET ? ");
        }

        Integer count = countCustomTemplateType(customTemplateNameReq, templatePickupMasterId, pickKey, moduleMasterId,
                        condition);

        if (count > 0) {
            return new PageImpl<>(jdbcTemplateMst.query(sql.toString(), new RowMapper<CustomTemplateName>() {

                public CustomTemplateName mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return CustomTemplateName.builder().id(rs.getInt("id")).userName(rs.getString("user_Name"))
                                    .name(rs.getString("name")).module(rs.getString("module"))
                                    .pldStatus(rs.getInt("pld_status")).createdAt(rs.getTimestamp(Constants.CREATED_AT))
                                    .build();
                }
            }, templatePickupMasterId, pickKey, moduleMasterId, page.getPageSize(), page.getOffset()), page, count);
        }
        return new PageImpl<>(new ArrayList<>());
    }

    @Override
    public void getFromAndTo(SearchCustomEmailDetailsReqDTO searchCustomEmailDetailsReqDTO,
                    CustomTemplateEmail customTemplateEmail) {
        StringBuilder getFromUserSql = new StringBuilder(CommonMstSQL.getUserForm(mstDatabaseName));
        StringBuilder getToPan = new StringBuilder(CommonMstSQL.getPan(mstDatabaseName));

        CustomTemplateEmail customTemplateEmail1 = jdbcTemplateMst
                        .query(getFromUserSql.toString(), new RowMapper<CustomTemplateEmail>() {

                            public CustomTemplateEmail mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return CustomTemplateEmail.builder().from(rs.getString("login_id")).build();
                            }
                        }, searchCustomEmailDetailsReqDTO.getUserId()).get(0);
        String appKey = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_APP_KEY, String.class,
                        ReportsConstants.ENCRYPTION_APP_KEY);

        try {
            loginId = EncryptionUtils.decrypt(appKey, customTemplateEmail1.getFrom());
        } catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException | NoSuchPaddingException
                        | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException
                        | DecoderException e) {
            log.error("error coming at the time of decripting login ID.");
        }
        customTemplateEmail.setFrom(loginId);

        PanDto panNo = jdbcTemplateMst.query(getToPan.toString(), new RowMapper<PanDto>() {

            public PanDto mapRow(ResultSet rs, int rowNum) throws SQLException {
                return PanDto.builder().panNo(rs.getString("PAN")).build();
            }
        }, searchCustomEmailDetailsReqDTO.getCustomTemplateId()).get(0);

        StringBuilder getDistinctEmailSql = new StringBuilder(CommonMstSQL.getDistinctMail(panNo.getPanNo()));
        List<MailConcatDto> mailLis = jdbcTemplateTrn.query(getDistinctEmailSql.toString(),
                        new RowMapper<MailConcatDto>() {

                            public MailConcatDto mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return MailConcatDto.builder().mailConcated(rs.getString("email")).build();
                            }
                        });

        String mailconcat = "";
        for (MailConcatDto mails : mailLis) {
            mailconcat = mailconcat + mails.getMailConcated() + ";";
        }
        customTemplateEmail.setTo(mailconcat);
    }

    @Override
    public List<TemplateType> getTemplateType() {
        return jdbcTemplateMst.query(CommonMstSQL.GET_TEMPLATE_TYPE_SQL, new RowMapper<TemplateType>() {

            public TemplateType mapRow(ResultSet rs, int rowNum) throws SQLException {
                return TemplateType.builder().createdAt(rs.getDate(Constants.CREATED_AT))
                                .createdBy(rs.getInt(Constants.CREATEDBY)).id(rs.getInt("id"))
                                .name(rs.getString("name")).shortDesc(rs.getString(Constants.SHORTDESC))
                                .code(rs.getInt("code")).userName(rs.getString(Constants.USERNAME))
                                .mandatoryColumns(rs.getString("mandatoryColumns")).build();
            }
        }, Constants.IS_MANDATORY_YES, Constants.PICKUP_MASTER_TEMPLATE_TYPE_ID);

    }

    @Override
    public int getTemplateStatus(String customTemplateId) {

        return jdbcTemplateMst.queryForObject(CommonMstSQL.GET_CUSTOM_TEMPLATE_NAME_ID, Integer.class,
                        customTemplateId);

    }

}
