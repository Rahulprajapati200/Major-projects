package com.bdo.bvms.common.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomTemplateDetails {

	Integer id; // Column mapping id 
	Integer customTemplateColumnMappingId;
	String columnName ;
	String templateColumn ;
	Boolean isAutoMap ;
	Boolean isMandatory ;
	String dataType ;
	Integer size;
	Integer pldTemplateId;
	Integer conditionalMandatoryGrouping;
	
}
