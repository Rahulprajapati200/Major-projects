package com.bdo.bvms.common.dto;

import java.util.Date;

import org.springframework.data.relational.core.mapping.Column;



import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class TaxpayerVendorContactMapping {

    Integer id;
    
    @Column(value="contact_id")
    Integer contactId;
    
    @Column(value="tvcr_id")
    Integer tvcrId;

    @Column(value="gstin_taxpayer")
    String gstinTaxpayer;
    
    @Column(value="gstin_vendor")
    String gstinVendor;
    
    @Column(value="first_name")
    String firstName;
    
    @Column(value="last_name")
    String lastName;
    
    String email;
    
    Long mobile;
    
    @Column(value="is_primary_contact")
    Integer isPrimaryContact;
    
    @Column(value="primary_contact")
    String primaryContact;

    @Column(value="aadhar_vendor")
    String aadharVendor ;
    
    @Column(value="is_draft")
    Integer isDraft;
    
    @Column(value="created_by")
    Integer createdBy;
    
    @Column(value="modified_by")
    Integer modifiedBy;
    
    @Column(value="modified_at")
    Date modifiedAt;
    
    @Column(value="created_at")
    Date createdAt;
    
    

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TaxpayerVendorContactMapping)) {
            return false;
        }
        TaxpayerVendorContactMapping other = (TaxpayerVendorContactMapping) obj;
        if (aadharVendor == null) {
            if (other.aadharVendor != null) {
                return false;
            }
        } else if (!aadharVendor.equalsIgnoreCase(other.aadharVendor)) {
            return false;
        }
        if (contactId == null) {
            if (other.contactId != null) {
                return false;
            }
        } else if (!contactId.equals(other.contactId)) {
            return false;
        }
        if (email == null) {
            if (other.email != null) {
                return false;
            }
        } else if (!email.equalsIgnoreCase(other.email)) {
            return false;
        }
        if (firstName == null) {
            if (other.firstName != null) {
                return false;
            }
        } else if (!firstName.equalsIgnoreCase(other.firstName)) {
            return false;
        }
        if (gstinTaxpayer == null) {
            if (other.gstinTaxpayer != null) {
                return false;
            }
        } else if (!gstinTaxpayer.equalsIgnoreCase(other.gstinTaxpayer)) {
            return false;
        }
        if (gstinVendor == null) {
            if (other.gstinVendor != null) {
                return false;
            }
        } else if (!gstinVendor.equalsIgnoreCase(other.gstinVendor)) {
            return false;
        }
        if (isPrimaryContact == null) {
            if (other.isPrimaryContact != null) {
                return false;
            }
        } else if (!isPrimaryContact.equals(other.isPrimaryContact)) {
            return false;
        }
        if (lastName == null) {
            if (other.lastName != null) {
                return false;
            }
        } else if (!lastName.equalsIgnoreCase(other.lastName)) {
            return false;
        }
        if (mobile == null) {
            if (other.mobile != null) {
                return false;
            }
        } else if (!mobile.equals(other.mobile)) {
            return false;
        }
        if (tvcrId == null) {
            if (other.tvcrId != null) {
                return false;
            }
        } else if (!tvcrId.equals(other.tvcrId)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((aadharVendor == null) ? 0 : aadharVendor.hashCode());
        result = prime * result + ((contactId == null) ? 0 : contactId.hashCode());
        result = prime * result + ((email == null) ? 0 : email.hashCode());
        result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
        result = prime * result + ((gstinTaxpayer == null) ? 0 : gstinTaxpayer.hashCode());
        result = prime * result + ((gstinVendor == null) ? 0 : gstinVendor.hashCode());
        result = prime * result + ((isPrimaryContact == null) ? 0 : isPrimaryContact.hashCode());
        result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
        result = prime * result + ((mobile == null) ? 0 : mobile.hashCode());
        result = prime * result + ((tvcrId == null) ? 0 : tvcrId.hashCode());
        return result;
    }
    
    
    
    
    }
