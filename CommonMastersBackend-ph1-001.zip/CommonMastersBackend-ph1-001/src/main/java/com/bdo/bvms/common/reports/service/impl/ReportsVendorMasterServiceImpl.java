package com.bdo.bvms.common.reports.service.impl;

import java.io.IOException;
import java.math.BigInteger;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.config.AzureClientProvider;
import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dto.BaseReqDTO;
import com.bdo.bvms.common.dto.FilingVeiwReportsReqDTO;
import com.bdo.bvms.common.dto.FilingVeiwReportsResDTO;
import com.bdo.bvms.common.dto.GetCustomizedColumnListResDTO;
import com.bdo.bvms.common.dto.GetReportsCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.GetReportsSavedCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.PinnedAndUnpinnedReportsReqDTO;
import com.bdo.bvms.common.dto.ReportsCustomColumnsDTO;
import com.bdo.bvms.common.dto.ReportsSubModuleReqDTO;
import com.bdo.bvms.common.dto.ReportsSubModuleResDTO;
import com.bdo.bvms.common.dto.ReportsVendorMasterReqDTO;
import com.bdo.bvms.common.dto.SearchReportReqDTO;
import com.bdo.bvms.common.dto.SendInvitesViewReportsReqDTO;
import com.bdo.bvms.common.dto.SendInvitesViewReportsResDTO;
import com.bdo.bvms.common.dto.SubModuleWiseReportsListReqDTO;
import com.bdo.bvms.common.dto.SubModuleWiseReportsListResDTO;
import com.bdo.bvms.common.exceptions.AppBusinessException;
import com.bdo.bvms.common.exceptions.BDOException;
import com.bdo.bvms.common.reports.constants.ReportsConstants;
import com.bdo.bvms.common.reports.dao.ReportModuleCommonRepo;
import com.bdo.bvms.common.reports.dao.ReportsVendorMasterRepo;
import com.bdo.bvms.common.reports.service.ReportsModuleHelperService;
import com.bdo.bvms.common.reports.service.ReportsVendorMasterService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ReportsVendorMasterServiceImpl implements ReportsVendorMasterService {

    @Autowired
    ReportsVendorMasterRepo reportsVendorMasterRepo;
    @Autowired
    ReportModuleCommonRepo reportModuleCommonRepo;

    @Autowired
    public AzureClientProvider client;
    @Autowired
    ReportsModuleHelperService reportsModuleHelperService;

    @Value("${bvms.cloud.temp.file.download.path}")
    String tempFolder;

    String gstinList;

    @Override
    public Map<String, Object> getReportsVendorMaster(ReportsVendorMasterReqDTO reportsVendorMasterReq)
                    throws AppBusinessException, SQLException {

        reportModuleCommonRepo.updateAccessLogTable(LocalDateTime.now(), reportsVendorMasterReq.getReportId(),
                        reportsVendorMasterReq.getUserId(), reportsVendorMasterReq.getEntityId(),
                        reportsVendorMasterReq.getUserTypeId());

        Map<String, Object> data = new HashMap<>();
        String taxpayergstinList = reportsVendorMasterReq.getGstinOrPanList().toString().replace("[", "")
                        .replace("]", "").replace("{", "").replace("}", "").replace(" ", "");
        String vendorGstinList = reportsVendorMasterReq.getVendorGstin().toString().replace("[", "").replace("]", "")
                        .replace("{", "").replace("}", "").replace(" ", "");
        int pldTemplateId = 6;
        int summaryType = 0;
        String fileName = "";
        try {
            fileName = reportModuleCommonRepo.getFileName(reportsVendorMasterReq.getReportId());
        } catch (Exception e) {
            log.error("error in getting file name from database", e);
        }
        List<ReportsCustomColumnsDTO> columnsdata = reportModuleCommonRepo.getCustomizeColumnsForView(pldTemplateId,
                        reportsVendorMasterReq.getReportId(), reportsVendorMasterReq.getUserId(),
                        reportsVendorMasterReq.getCustomTemplateId(), summaryType);

        Map<String, Object> dataAndCount = reportsVendorMasterRepo.getReportsVendorMaster(reportsVendorMasterReq,
                        taxpayergstinList, vendorGstinList);
        data.put(ReportsConstants.COLUMN_DATA, columnsdata);
        data.put(ReportsConstants.DATA, dataAndCount.get("data"));
        data.put(ReportsConstants.TOTAL_PAGE_ELEMENTS, dataAndCount.get("count"));
        data.put(ReportsConstants.SUCCESS_MESSAGE_KEY, fileName + ReportsConstants.SUCCESS_MESSAGE_VIEW_DESCRIPTION);

        return data;

    }

    @Override
    public Map<String, Object> getPinnedReportsDetails(BaseReqDTO baseReqDTO) throws AppBusinessException {

        return reportsVendorMasterRepo.getPinnedReportsDetail(baseReqDTO);
    }

    @Override
    public Map<String, Object> getSuggestedReportsDetail(BaseReqDTO baseReqDTO) throws AppBusinessException {

        return reportsVendorMasterRepo.getSuggestedReportsDetail(baseReqDTO);
    }

    @Override
    public Map<String, Object> getRecentReportsDetail(BaseReqDTO baseReqDTO) throws AppBusinessException {

        return reportsVendorMasterRepo.getRecentReportsDetail(baseReqDTO);

    }

    @Override
    public List<ReportsSubModuleResDTO> getReportsSubModuleList(ReportsSubModuleReqDTO reportsSubModuleReqDTO)
                    throws AppBusinessException {

        return reportsVendorMasterRepo.getReportsSubModuleList(reportsSubModuleReqDTO);

    }

    @Override
    public List<SubModuleWiseReportsListResDTO> getSubModuleWiseReportList(
                    SubModuleWiseReportsListReqDTO subModuleWiseReportsListReqDTO) throws AppBusinessException {

        return reportsVendorMasterRepo.getSubModuleWiseReportList(subModuleWiseReportsListReqDTO);
    }

    @Override
    public void setPinnedAndUnpinnedReports(PinnedAndUnpinnedReportsReqDTO pinnedAndUnpinnedReportsReq)
                    throws AppBusinessException {

        reportsVendorMasterRepo.setPinnedAndUnpinnedReports(pinnedAndUnpinnedReportsReq);
    }

    @Override
    public Map<String, Object> getSendInvitesViewReports(SendInvitesViewReportsReqDTO sendInvitesViewReportsReqDTO)
                    throws AppBusinessException {

        String taxpayergstinList = sendInvitesViewReportsReqDTO.getGstinOrPanList().toString().replace("[", "")
                        .replace("]", "").replace("{", "").replace("}", "").replace(" ", "");
        String vendorGstinList = sendInvitesViewReportsReqDTO.getVendorGstin().toString().replace("[", "")
                        .replace("]", "").replace("{", "").replace("}", "").replace(" ", "");
        int pldTemplateId = 6;
        int summaryType = 0;
        String fileName = "";
        try {
            fileName = reportModuleCommonRepo.getFileName(sendInvitesViewReportsReqDTO.getReportId());
        } catch (Exception e) {
            log.error("error in getting VendorCommunicationInwarReports file name from database", e);
        }
        Map<String, Object> headersAndData = reportsVendorMasterRepo
                        .getSendInvitesViewReports(sendInvitesViewReportsReqDTO, taxpayergstinList, vendorGstinList);
        List<ReportsCustomColumnsDTO> columnsdata = reportModuleCommonRepo.getCustomizeColumnsForView(pldTemplateId,
                        sendInvitesViewReportsReqDTO.getReportId(), sendInvitesViewReportsReqDTO.getUserId(),
                        sendInvitesViewReportsReqDTO.getCustomTemplateId(), summaryType);
        headersAndData.put(ReportsConstants.COLUMN_DATA, columnsdata);
        headersAndData.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                        fileName + ReportsConstants.SUCCESS_MESSAGE_VIEW_DESCRIPTION);

        return headersAndData;
    }

    @Override
    public Map<String, Object> getFilingViewReportsList(FilingVeiwReportsReqDTO filingVeiwReportsReqDTO)
                    throws AppBusinessException {

        String taxpayergstinList = filingVeiwReportsReqDTO.getGstinOrPanList().toString().replace("[", "")
                        .replace("]", "").replace("{", "").replace("}", "").replace(" ", "");
        String vendorGstinList = filingVeiwReportsReqDTO.getVendorGstin().toString().replace("[", "").replace("]", "")
                        .replace("{", "").replace("}", "").replace(" ", "");
        int pldTemplateId = 6;
        int summaryType = 0;
        String fileName = "";
        try {
            fileName = reportModuleCommonRepo.getFileName(filingVeiwReportsReqDTO.getReportId());
        } catch (Exception e) {
            log.error("error in getting VendorCommunicationInwarReports file name from database", e);
        }
        Map<String, Object> headersAndData = reportsVendorMasterRepo.getFilingViewReports(filingVeiwReportsReqDTO,
                        taxpayergstinList, vendorGstinList);
        List<ReportsCustomColumnsDTO> columnsdata = reportModuleCommonRepo.getCustomizeColumnsForView(pldTemplateId,
                        filingVeiwReportsReqDTO.getReportId(), filingVeiwReportsReqDTO.getUserId(),
                        filingVeiwReportsReqDTO.getCustomTemplateId(), summaryType);
        headersAndData.put(ReportsConstants.COLUMN_DATA, columnsdata);
        headersAndData.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                        fileName + ReportsConstants.SUCCESS_MESSAGE_VIEW_DESCRIPTION);

        return headersAndData;
    }

    @Override
    public List<GetCustomizedColumnListResDTO> getCustomizedColumnListFromService(
                    GetReportsCustomizeColumnListReqDTO getCustomizedColumnListReqDTO) throws AppBusinessException {

        return reportsVendorMasterRepo.getCustomizedColumnListFromRepo(getCustomizedColumnListReqDTO);
    }

    @Override
    public void getSavedCustomizedColumnListFromService(
                    GetReportsSavedCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO)
                    throws AppBusinessException {
        if (saveCustomizeColumnListReqDTO.getSaveOrDefault() == Constants.DEFAULT) {

            reportsVendorMasterRepo.deleteThePreviousRecord(saveCustomizeColumnListReqDTO);
        } else if (saveCustomizeColumnListReqDTO.getSaveOrDefault() == Constants.SAVE) {
            reportsVendorMasterRepo.deleteThePreviousRecord(saveCustomizeColumnListReqDTO);
            reportsVendorMasterRepo.enterTheNewRecord(saveCustomizeColumnListReqDTO);
        }

    }

    @Async
    @Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
    @Override
    public void backgroundReportsGenerationProccess(ReportsVendorMasterReqDTO generateBackgroundReports)
                    throws AppBusinessException {

        String fileName = "";
        generateBackgroundReports.setDownloadType("");
        try {
            fileName = reportModuleCommonRepo.getFileName(generateBackgroundReports.getReportId());
        } catch (Exception e) {
            log.error("error in getting file name from database", e);
        }
        reportModuleCommonRepo.updateAccessLogTable(LocalDateTime.now(), generateBackgroundReports.getReportId(),
                        generateBackgroundReports.getUserId(), generateBackgroundReports.getEntityId(),
                        generateBackgroundReports.getUserTypeId());
        Timestamp currentTimeStamp = new Timestamp(System.currentTimeMillis());
        BigInteger id = reportModuleCommonRepo.insertBackGroundDetails(generateBackgroundReports.getReportId(),
                        ReportsConstants.IN_PROGRESS, currentTimeStamp, generateBackgroundReports.getUserId(),
                        currentTimeStamp, fileName);

        reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORMASTERMODULEID,
                        fileName + ReportsConstants.BACKGROUNG_IN_PROGRESS,
                        Integer.valueOf(generateBackgroundReports.getUserId()),
                        Integer.valueOf(generateBackgroundReports.getUserId()),
                        Integer.valueOf(generateBackgroundReports.getUserId()),
                        ReportsConstants.NOTIFICATION_INITIATED);

        String taxpayergstinList = generateBackgroundReports.getGstinOrPanList().toString().replace("[", "")
                        .replace("]", "").replace("{", "").replace("}", "").replace(" ", "");
        String vendorGstinList = generateBackgroundReports.getVendorGstin().toString().replace("[", "").replace("]", "")
                        .replace("{", "").replace("}", "").replace(" ", "");

        String containerName = reportModuleCommonRepo.getContainerName(generateBackgroundReports.getEntityId());

        if (ReportsConstants.VENDOR_MASTER_TAXPAYER_REGISTER_REPORT.equals(generateBackgroundReports.getReportId())
                        || ReportsConstants.VENDOR_MASTER_GSTIN_REGISTER_REPORT
                                        .equals(generateBackgroundReports.getReportId())
                        || ReportsConstants.VENDOR_MASTER_COMBINED_REGISTER_REPORT
                                        .equals(generateBackgroundReports.getReportId())
                        || ReportsConstants.VENDOR_MASTER_AS_PER_VENDOR_REGISTER_REPORT
                                        .equals(generateBackgroundReports.getReportId())
                        || ReportsConstants.CUSTOM_VENDOR_MASTER_AS_PER_VENDOR_ERROR_REPORT
                                        .equals(generateBackgroundReports.getReportId())
                        || ReportsConstants.CUSTOM_VENDOR_MASTER_COMBINED_ERROR_REPORT
                                        .equals(generateBackgroundReports.getReportId())
                        || ReportsConstants.CUSTOM_VENDOR_MASTER_TAXPAYER_ERROR_REPORT
                                        .equals(generateBackgroundReports.getReportId())
                        || ReportsConstants.CUSTOM_VENDOR_MASTER_TAXPAYER_REGISTER_REPORT
                                        .equals(generateBackgroundReports.getReportId())
                        || ReportsConstants.CUSTOM_VENDOR_MASTER_AS_PER_VENDOR_REGISTER_REPORT
                                        .equals(generateBackgroundReports.getReportId())
                        || ReportsConstants.CUSTOM_VENDOR_MASTER_COMBINED_REGISTER_REPORT
                                        .equals(generateBackgroundReports.getReportId())) {
            try {

                reportsVendorMasterRepo.generateBackGroundReportsVendorMaster(currentTimeStamp, fileName, containerName,
                                generateBackgroundReports.getEntityId(), generateBackgroundReports, taxpayergstinList,
                                vendorGstinList, id);
                reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORMASTERMODULEID,
                                fileName + ReportsConstants.BACKGROUNG_COMPLETE,
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                ReportsConstants.NOTIFICATION_SUCCESS);

            } catch (Exception e) {
                log.error("error in generating excel  file of vendor master Report", e);
                reportModuleCommonRepo.updateBackGroundDetails(
                                reportModuleCommonRepo.getReportsExcelFileName(fileName, currentTimeStamp), (long) 0,
                                ReportsConstants.ERROR, fileName, generateBackgroundReports.getUserId(),
                                currentTimeStamp, id);
                reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORMASTERMODULEID,
                                fileName + ReportsConstants.BACKGROUNG_ERROR,
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                ReportsConstants.NOTIFICATION_ERROR);
            }

        } else if (ReportsConstants.VENDOR_FILING_DETAILS_REPORT.equals(generateBackgroundReports.getReportId())) {

            try {
                List<FilingVeiwReportsResDTO> filingViewReportsList = new ArrayList<>();

                reportsVendorMasterRepo.getGenerateExcelOrCsvOfxVendorMasterFillingDetailsReport(
                                generateBackgroundReports, taxpayergstinList, vendorGstinList, currentTimeStamp,
                                fileName, containerName);
                reportModuleCommonRepo.updateBackGroundDetails(
                                reportModuleCommonRepo.getReportsExcelFileName(fileName, currentTimeStamp),
                                (long) filingViewReportsList.size(), ReportsConstants.COMPLETED, fileName,
                                generateBackgroundReports.getUserId(), currentTimeStamp, id);
                reportModuleCommonRepo.insertDetailsIntoMailBox1(generateBackgroundReports.getUserId(), fileName,
                                currentTimeStamp);
                reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORMASTERMODULEID,
                                fileName + ReportsConstants.BACKGROUNG_COMPLETE,
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                ReportsConstants.NOTIFICATION_SUCCESS);
            } catch (Exception e) {
                log.error("error in generating excel  file of filling details Report", e);
                reportModuleCommonRepo.updateBackGroundDetails(
                                reportModuleCommonRepo.getReportsExcelFileName(fileName, currentTimeStamp), (long) 0,
                                ReportsConstants.ERROR, fileName, generateBackgroundReports.getUserId(),
                                currentTimeStamp, id);
                reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORMASTERMODULEID,
                                fileName + ReportsConstants.BACKGROUNG_ERROR,
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                ReportsConstants.NOTIFICATION_ERROR);
            }

        } else if (ReportsConstants.SEND_INVITES_LIST_REPORT.equals(generateBackgroundReports.getReportId())) {

            List<SendInvitesViewReportsResDTO> sendInvitesViewReportsList = new ArrayList<>();
            try {

                reportsVendorMasterRepo.getGenerateExcelOrCsvOfxVendorMasterSendInviteReport(generateBackgroundReports,
                                taxpayergstinList, vendorGstinList, currentTimeStamp, fileName, containerName);

                reportModuleCommonRepo.updateBackGroundDetails(
                                reportModuleCommonRepo.getReportsExcelFileName(fileName, currentTimeStamp),
                                (long) sendInvitesViewReportsList.size(), ReportsConstants.COMPLETED, fileName,
                                generateBackgroundReports.getUserId(), currentTimeStamp, id);
                reportModuleCommonRepo.insertDetailsIntoMailBox1(generateBackgroundReports.getUserId(), fileName,
                                currentTimeStamp);
                reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORMASTERMODULEID,
                                fileName + ReportsConstants.BACKGROUNG_COMPLETE,
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                ReportsConstants.NOTIFICATION_SUCCESS);
            } catch (Exception e) {
                log.error("error in generating excel  file of send invites Report", e);
                reportModuleCommonRepo.updateBackGroundDetails(
                                reportModuleCommonRepo.getReportsExcelFileName(fileName, currentTimeStamp), (long) 0,
                                ReportsConstants.ERROR, fileName, generateBackgroundReports.getUserId(),
                                currentTimeStamp, id);
                reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORMASTERMODULEID,
                                fileName + ReportsConstants.BACKGROUNG_ERROR,
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                Integer.valueOf(generateBackgroundReports.getUserId()),
                                ReportsConstants.NOTIFICATION_ERROR);
            }

        }

    }

    @Override
    public Map<String, Object> getBackgroundReportsData(BaseReqDTO requestDTO) throws AppBusinessException {

        return reportsVendorMasterRepo.getBackgroundReportsData(requestDTO);

    }

    @Override
    public Map<String, Object> downloadVendorMasterReportsCustom(ReportsVendorMasterReqDTO reportsVendorMasterReq)
                    throws BDOException {

        reportModuleCommonRepo.updateAccessLogTable(LocalDateTime.now(), reportsVendorMasterReq.getReportId(),
                        reportsVendorMasterReq.getUserId(), reportsVendorMasterReq.getEntityId(),
                        reportsVendorMasterReq.getUserTypeId());
        String taxpayergstinList = reportsVendorMasterReq.getGstinOrPanList().toString().replace("[", "")
                        .replace("]", "").replace("{", "").replace("}", "").replace(" ", "");
        String vendorGstinList = reportsVendorMasterReq.getVendorGstin().toString().replace("[", "").replace("]", "")
                        .replace("{", "").replace("}", "").replace(" ", "");

        Timestamp timeStamp = new Timestamp(System.currentTimeMillis());
        String containerName = reportModuleCommonRepo.getContainerName(reportsVendorMasterReq.getEntityId());
        String fileName = "";
        try {
            fileName = reportModuleCommonRepo.getFileName(reportsVendorMasterReq.getReportId());
        } catch (Exception e) {
            log.error("error in getting file name from database", e);
        }

        Map<String, Object> dataAndColumns = new HashMap<>();
        if (ReportsConstants.VENDOR_MASTER_TAXPAYER_REGISTER_REPORT.equals(reportsVendorMasterReq.getReportId())
                        || ReportsConstants.VENDOR_MASTER_GSTIN_REGISTER_REPORT
                                        .equals(reportsVendorMasterReq.getReportId())
                        || ReportsConstants.VENDOR_MASTER_COMBINED_REGISTER_REPORT
                                        .equals(reportsVendorMasterReq.getReportId())
                        || ReportsConstants.VENDOR_MASTER_AS_PER_VENDOR_REGISTER_REPORT
                                        .equals(reportsVendorMasterReq.getReportId())
                        || ReportsConstants.CUSTOM_VENDOR_MASTER_AS_PER_VENDOR_ERROR_REPORT
                                        .equals(reportsVendorMasterReq.getReportId())
                        || ReportsConstants.CUSTOM_VENDOR_MASTER_COMBINED_ERROR_REPORT
                                        .equals(reportsVendorMasterReq.getReportId())
                        || ReportsConstants.CUSTOM_VENDOR_MASTER_TAXPAYER_ERROR_REPORT
                                        .equals(reportsVendorMasterReq.getReportId())
                        || ReportsConstants.CUSTOM_VENDOR_MASTER_TAXPAYER_REGISTER_REPORT
                                        .equals(reportsVendorMasterReq.getReportId())
                        || ReportsConstants.CUSTOM_VENDOR_MASTER_AS_PER_VENDOR_REGISTER_REPORT
                                        .equals(reportsVendorMasterReq.getReportId())
                        || ReportsConstants.CUSTOM_VENDOR_MASTER_COMBINED_REGISTER_REPORT
                                        .equals(reportsVendorMasterReq.getReportId())) {

            try {
                dataAndColumns = reportsVendorMasterRepo.getDownloadReportsVendorMasterNew(timeStamp, fileName,
                                containerName, reportsVendorMasterReq.getEntityId(), reportsVendorMasterReq,
                                taxpayergstinList, vendorGstinList);
                dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                                fileName + ReportsConstants.SUCCESS_MESSAGE_EXPORT_DESCRIPTION);

                return dataAndColumns;
            } catch (IOException | BDOException e) {
                log.error("Error coming while genertaing excel or csv file", e);
                throw new BDOException(e);
            }
        }

        else if (ReportsConstants.VENDOR_FILING_DETAILS_REPORT.equals(reportsVendorMasterReq.getReportId())) {

            dataAndColumns = reportsVendorMasterRepo.getGenerateExcelOrCsvOfxVendorMasterFillingDetailsReport(
                            reportsVendorMasterReq, taxpayergstinList, vendorGstinList, timeStamp, fileName,
                            containerName);
            dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                            fileName + ReportsConstants.SUCCESS_MESSAGE_EXPORT_DESCRIPTION);

            return dataAndColumns;

        } else if (ReportsConstants.SEND_INVITES_LIST_REPORT.equals(reportsVendorMasterReq.getReportId())) {

            dataAndColumns = reportsVendorMasterRepo.getGenerateExcelOrCsvOfxVendorMasterSendInviteReport(
                            reportsVendorMasterReq, taxpayergstinList, vendorGstinList, timeStamp, fileName,
                            containerName);
            dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY,
                            fileName + ReportsConstants.SUCCESS_MESSAGE_EXPORT_DESCRIPTION);

            return dataAndColumns;

        }

        return new HashMap<>();
    }

    @Override
    public Map<String, Object> getSearchReporst(SearchReportReqDTO searchReportReq) {

        return reportsVendorMasterRepo.getSearchReports(searchReportReq);
    }

}
