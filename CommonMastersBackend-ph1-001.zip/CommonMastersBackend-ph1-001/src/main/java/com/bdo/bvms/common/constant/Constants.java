package com.bdo.bvms.common.constant;

public class Constants {

    private Constants() {
        super();
    }

    public static final String E_INVOICE = "e-Invoice";
    public static final String E_WAY_BILL = "e-Way Bill";
    public static final String INVOICE = "Invoice";
    public static final String INVOICE_MAPPING = "Invoice & PO Mapping";

    public static final String DATEFORMATE1 = "dd-MM-yyyy";

    public static final String DATEFORMATE2 = "dd/MM/yyyy";
    public static final String FILESEPERATOR = "file.separator";
    public static final String ROWVERSION_DATEFORMATE = "dd-M-yyyy hh:mm:ss";
    public static final int E_INVOICE_TEMPLATE_COLUMN_COUNT = 21;
    public static final String DATA_ROW = "coumnsDataRow";

    public static final String XLSX = "xlsx";
    public static final String XLS = "xls";
    public static final String CSV = "csv";
    public static final String PDF = "pdf";
    public static final String JPG = "jpg";
    public static final String JPEG = "jpeg";
    public static final String PNG = "png";

    public static final Object DOTSEPERATOR = ".";

    public static final String FILENOTFOUNTONBLOB = "File is not Available on Blob";

    public static final String DATANOTFOUND = "No further Data is available in DB";
    public static final String VALIDATIONERROR = "Validation error";

    public static final int PLD_STATUS_ACTIVE = 10;

    public static final int PLD_STATUS_INACTIVE = 20;

    public static final int PLD_STATUS_DELETED = 30;

    public static final int COLUMN_AUTOMAP_CHAR_START_INDEX = 0;

    public static final String PICKUP_MASTER_ADDRESS_TYPE = "address_type";

    public static final String PICKUP_MASTER_DEFAULT_ADDRESS_TYPE = "default_address";

    public static final String PICKUP_MASTER_PRIMARY_CONTACT = "primary_contact";

    public static final String PICKUP_MASTER_PRIMARY_BANK = "primary_bank";

    public static final int COLUMN_AUTOMAP_CHAR_END_INDEX = 30;

    public static final int COLUMN_AUTOMAP_CHAR_LENGTH = 20;

    public static final String PLD_UPLOAD_TEMPLATE_TYPE = "upload_template_type";

    public static final String PLD_TEMPLATE_TYPE = "template_type";

    public static final String CUSTOM_TEMPLATE_TYPE_MODULE = "Vendor Master";

    public static final int SMPICKTEMPLATEID = 8;
    public static final String VENDOR_MASTER = "vendor_master";

    public static final int VENDOR_DETAILS_EXCEL_HEADER_ROW_NO = 1;

    public static final int CUSTOM_VENDOR_DETAILS_EXCEL_HEADER_ROW_NO = 0;

    public static final String VENODR_DETAIL_TEMPLATE_FILE_TYPE_XLSX = "xlsx";
    public static final String VENODR_DETAIL_TEMPLATE_FILE_TYPE_XLS = "xls";
    public static final int VENDOR_MASTER_TEMPLATE_SHEET_NO = 0;
    public static final String VENDOR_MASTER_TEMPLATE_ROW_SKIP = "0,1";
    public static final String UNDERSCORE = "_";

    public static final String FILE = "file";
    public static final String HEADERS = "headers";
    public static final int EINVOICE_TEMPLATE_CODE_ID = 1;
    public static final int EWAYBILL_TEMPLATE_CODE_ID = 2;
    public static final int INVOICE_TEMPLATE_CODE_ID = 5;
    public static final int VENDOR_DETAILS_TEMPLATE_CODE_ID = 6;
    public static final int COMUNICATION_TEMPLATE_CODE_ID = 7;
    public static final int COMUNICATION_PAYMENT_TEMPLATE_CODE_ID = 331;
    public static final int COMUNICATION_TDS_TEMPLATE_CODE_ID = 8;
    public static final int COMUNICATION_ITC_TEMPLATE_CODE_ID = 9;

    public static final String PAN = "0";
    public static final String GSTIN = "1";

    public static final String VENDOR_ENTITY_TYPE = "VENDOR";
    public static final String GSTIN_OR_PAN_LIST = "GstinOrPanList";

    public static final String ACCESS_CONTROL_EXPOSE_HEADERS = "Access-Control-Expose-Headers";

    public static final String HEADERS_FILENAME = "fileName";

    public static final String PICKUP_MASTER_MODULES = "modules";

    public static final int PICKUP_MASTER_MODULES_ID = 45;

    public static final int PLD_MODULES_VENDOR_MASTER_CODE = 63;

    public static final int PICKUP_MASTER_TEMPLATE_TYPE_ID = 8;

    public static final String FILE_EXTENSION = "fileExtension";

    public static final String CREATED_AT = "created_at";

    public static final String IS_MANDATORY = "is_mandatory";

    public static final String FROM_PLD = " from sm_pickup_list_details pld\r\n";

    public static final String JOIN_USERMASTER_PLD = "  join am_user_master um on pld.created_by=um.user_id  ";

    public static final String JOIN_PICKUP_MASTER_PLD = " INNER JOIN sm_pickup_master pm ON pm.pickup_master_id = pld.sm_pick_mst_id  ";

    public static final String SELECT_PLD_COLUMNS = "Select pld.id,sm_pick_mst_id, pld.name, code, short_desc, long_desc,pick_key, sort_order,pld.status, pld.created_at, pld.created_by,from_base64(first_name) userName \r\n";

    public static final String INNER_JOIN = "        INNER JOIN\n";

    public static final String OFFSET = " OFFSET ";

    public static final String LIMIT = " LIMIT ";
    public static final String NEW = "new";
    public static final Object SENT = "sent";
    public static final String FAILED = "failed";
    public static final String HTMLHARDCODE = "";
    public static final char DELIMITER_COMMA = ',';

    public static final String EXCEL_SHEET_NAME = "custom template";

    public static final String PICKUP_MASTER_NAME_MODULES = "modules";

    public static final String VENDOR_UPLOAD_DEFAULT_TEMPLATE_PATH = "VendorDetails.xlsx";

    public static final int SAVE = 1;
    public static final int DEFAULT = 0;
    public static final int SELECTED = 1;
    public static final String VALUE = "value";
    public static final String USERNAME = "userName";
    public static final String SHORTDESC = "short_desc";
    public static final String CREATEDBY = "created_by";
    public static final String CONDITIONMANDATORYGROPING = "conditional_mandatory_grouping";
    public static final String COLUMNNAME = "column_name";
    public static final String ENTITYNOTFOUNDFORTHE = "Entity not found for the ";
    public static final String INVOICEDATEREGEX = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";
    public static final String WITHVALUES = " with values ";
    public static final String PODATEREGEX = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";

    public static final int IS_EMAIL_TEMPLATE_YES = 1;

    public static final int CUSTOM_EMAIL_TEMPLATE_CATEGORY_IS_ACTIVE_YES = 1;

    public static final int CUSTOM_EMAIL_TEMPLATE_IS_DEFAULT_TEMPLATE_NO = 0;

    public static final int CUSTOM_EMAIL_TEMPLATE_IS_DEFAULT_TEMPLATE_YES = 1;

    public static final int GSTIN_MIN_SIZE = 15;

    public static final int GSTIN_MAX_SIZE = 15;
    public static final int PLD_DATA_VERSION_TAXPAYER = 1;
    public static final int CONTACT_MAPPING_IS_PRIMARY_CONTACT_YES = 1;
    public static final String CONTACT_MAPPING_IS_PRIMARY_CONTACT = "is_primary_contact";
    public static final String MODIFIEDAT = "modified_at";
    public static final String CREATEDAT = "created_at";
    public static final String CONTACT_MAPPING_CONTACT_ID = "contact_id";
    public static final String WORKFLOW_COMMUNICATION_COLUMN_IS_NEW_COMMUNICATION = "is_new_communication";

    public static final String WORKFLOW_COMMUNICATION_COLUMN_SUBJECT = "subject";
    public static final int PLD_DATA_VERSION_VENDOR = 2;
    public static final String TAXPAYER_GSTIN = "taxpayerGstin";

    public static final String VENDOR_GSTIN = "vendorGstin";
    public static final Boolean VENDOR_UPLOAD_CUSTOM_TEMPLATE_NO = false;

    public static final Boolean VENDOR_UPLOAD_CUSTOM_TEMPLATE_YES = true;
    public static final int WORKFLOW_COMMUNICATION_IS_NEW_COMMUNICATION_YES = 1;

    public static final int WORKFLOW_COMMUNICATION_IS_NEW_COMMUNICATION_NO = 0;
    public static final int WORKFLOW_COMMUNICATION_IS_VENDOR_NO = 1;

    public static final int INVITES_TRACKING_TAXPAYER_MODULE_ID = 64;
    public static final int INVITES_TRACKING_VENDOR_MODULE_ID = 164;

    public static final int DOCUMENT_UPLOAD_TAXPAYER_MODULE_ID = 65;
    public static final int DOCUMENT_UPLOAD_VENDOR_MODULE_ID = 165;

    public static final int COMMUNICATION_TAXPAYER_MODULE_ID = 66;
    public static final int COMMUNICATION_VENDOR_MODULE_ID = 166;

    public static final String EXCEL = "excel";

    public static final long EMAIL_TEMPLATE_LOGO_MAX_SIZE = 300l;

    public static final String SIGNATURE_LOGO_FILE_NAME = "signature_logo";
    public static final String COMPANY_LOGO_FILE_NAME = "company_logo";

    public static final int SIGNATURE_LOGO_TYPE = 1;
    public static final int COMPANY_LOGO_TYPE = 2;

    public static final String WITH_VALUES_EXCEPTION_MSG = " with values ";

    public static final String ENTITY_NOT_FOUND_EXCEPTION_MSG = "Entity not found for the ";

    public static final String ERROR_WHILE_DELETING_FILE_EXCEPTION_MSG = "Error while deleting file ";
    public static final String ERRORCODE = "error_code";
    public static final String SUBSTRINGREGEX = "[\n\r]";

    public static final Integer IS_MANDATORY_YES = 1;
    public static final int INVITETRACKINGMODULEID = 2;
    public static final int VENDORCOMMUNICATIOID = 10;
    public static final int DOCUMENTUPLOADID = 5;
}
