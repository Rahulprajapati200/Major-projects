package com.bdo.bvms.common.dto;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.bdo.bvms.common.constant.Constants;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SearchTemplateDetailsReqDTO extends BaseReqDTO {

    @Pattern(regexp = Constants.PAN + "|" + Constants.GSTIN, message = "GstinOrPan must be equal to " + Constants.PAN
                    + " or " + Constants.GSTIN)
    @NotEmpty(message = "{gstinOrPan.notempty}")
    private String gstinOrPan;

    @NotEmpty(message = "{gstinOrPanList.notempty}")
    private List<String> gstinOrPanList;

    private String templateName;

    @NotEmpty(message = "{moduleId.notNull}")
    private String moduleId;

    @NotNull(message = "{isCustomTemplate.notNull}")
    private Boolean isCustomTemplate;

    private String reportId;

}
