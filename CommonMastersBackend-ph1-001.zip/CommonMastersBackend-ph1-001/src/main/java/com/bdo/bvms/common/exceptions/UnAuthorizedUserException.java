package com.bdo.bvms.common.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.UNAUTHORIZED)
public class UnAuthorizedUserException  extends RuntimeException{

	private static final long serialVersionUID = -7361014613093833867L;

	public UnAuthorizedUserException(String message) {
		super(message);
	}
	
}
