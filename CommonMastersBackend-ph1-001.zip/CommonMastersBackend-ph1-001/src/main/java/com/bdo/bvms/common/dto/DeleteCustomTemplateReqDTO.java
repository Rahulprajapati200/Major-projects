package com.bdo.bvms.common.dto;

import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeleteCustomTemplateReqDTO  extends BaseReqDTO {

	@NotNull(message = "{customTemplateId.notnull}")
	private Integer customTemplateId;
}
