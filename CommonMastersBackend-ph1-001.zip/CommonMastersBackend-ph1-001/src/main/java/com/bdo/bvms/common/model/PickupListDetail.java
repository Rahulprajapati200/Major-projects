package com.bdo.bvms.common.model;

import java.util.Date;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PickupListDetail {

    Integer id;

    Integer smPickMstId;

    String name;
    Integer code;

    String shortDesc;

    String longDesc;

    String pickKey;

    Integer sortOrder;

    Integer status;

    Integer createdBy;

    Date createdAt;

    Integer modifiedBy;

    Date modifiedAt;

    // User name added
    String userName;

    String moduleName;
    Integer pldStatus;
    String pickupMasterName;

}
