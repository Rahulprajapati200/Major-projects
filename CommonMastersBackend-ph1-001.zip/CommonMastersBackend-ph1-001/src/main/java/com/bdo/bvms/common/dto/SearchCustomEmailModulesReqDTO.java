package com.bdo.bvms.common.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class SearchCustomEmailModulesReqDTO extends BaseReqDTO{

}
