package com.bdo.bvms.common.service;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.exceptions.BVMSException;
import com.bdo.bvms.common.exceptions.CommonMasterBusinessException;

public interface ICommonExcelService {

    List<String> getExcelTemplateHeaderList(File file, int headerRowNo) throws BVMSException;

    Map<String, List<String>> readCustomTemplateSampleData(File file)
                    throws CommonMasterBusinessException, BVMSException;

    File writeExcelWithHeader(String fileName, char delimiter, List<String> headerList);

}
