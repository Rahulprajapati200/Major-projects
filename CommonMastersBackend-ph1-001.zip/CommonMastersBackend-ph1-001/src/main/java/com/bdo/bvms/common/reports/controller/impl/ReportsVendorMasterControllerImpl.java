package com.bdo.bvms.common.reports.controller.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.bvms.common.dto.APIResponseDTO;
import com.bdo.bvms.common.dto.BaseReqDTO;
import com.bdo.bvms.common.dto.FilingVeiwReportsReqDTO;
import com.bdo.bvms.common.dto.GetReportsCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.GetReportsSavedCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.ModuleIdAndNameDTO;
import com.bdo.bvms.common.dto.PinnedAndUnpinnedReportsReqDTO;
import com.bdo.bvms.common.dto.ReportsSubModuleReqDTO;
import com.bdo.bvms.common.dto.ReportsSubModuleResDTO;
import com.bdo.bvms.common.dto.ReportsVendorMasterReqDTO;
import com.bdo.bvms.common.dto.SearchReportReqDTO;
import com.bdo.bvms.common.dto.SendInvitesViewReportsReqDTO;
import com.bdo.bvms.common.dto.SubModuleWiseReportsListReqDTO;
import com.bdo.bvms.common.dto.SubModuleWiseReportsListResDTO;
import com.bdo.bvms.common.dto.VendorCommunicationEmailStatusReqDTO;
import com.bdo.bvms.common.dto.VendorCommunicationInwardReqDTO;
import com.bdo.bvms.common.dto.VendorCommunicationReconciliationReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceGetReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceInputReportsReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceSyncReqDTO;
import com.bdo.bvms.common.exceptions.AppBusinessException;
import com.bdo.bvms.common.exceptions.BDOException;
import com.bdo.bvms.common.reports.constants.ReportsConstants;
import com.bdo.bvms.common.reports.controller.ReportsVendorMasterController;
import com.bdo.bvms.common.reports.service.ReportsModuleHelperService;
import com.bdo.bvms.common.reports.service.ReportsVendorCommunicationService;
import com.bdo.bvms.common.reports.service.ReportsVendorInvoiceService;
import com.bdo.bvms.common.reports.service.ReportsVendorMasterService;

@RestController
@RequestMapping("/common/reports")

public class ReportsVendorMasterControllerImpl implements ReportsVendorMasterController {

    @Autowired
    ReportsVendorMasterService reportsVendorMasterService;

    @Autowired
    ReportsVendorInvoiceService reportsVendorInvoiceService;

    @Autowired
    ReportsVendorCommunicationService reportsVendorCommunicationService;

    @Autowired
    ReportsModuleHelperService reportsModuleHelperService;

    @PostMapping(value = "/vendormaster-viewreports", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Override
    public ResponseEntity<APIResponseDTO> getReportsVendorMaster(HttpServletRequest httpServletRequest,
                    @RequestBody ReportsVendorMasterReqDTO reportsVendorMasterReqDTO)
                    throws AppBusinessException, SQLException {

        Map<String, Object> reportsVendorMasterResList = reportsVendorMasterService
                        .getReportsVendorMaster(reportsVendorMasterReqDTO);

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(reportsVendorMasterResList)
                        .message((String) reportsVendorMasterResList.get(ReportsConstants.SUCCESS_MESSAGE_KEY))
                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/reportlist-pinned", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Override
    public ResponseEntity<APIResponseDTO> getPinnedReports(HttpServletRequest httpServletRequest,
                    @RequestBody BaseReqDTO baseReqDTO) throws AppBusinessException {

        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1)
                                        .data(reportsVendorMasterService.getPinnedReportsDetails(baseReqDTO))
                                        .message("Vendor pinned Reports details are displayed successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/pin-unpin-reportlist", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Override
    public ResponseEntity<APIResponseDTO> insertPinnedAndUnpinnedReports(HttpServletRequest httpServletRequest,
                    @RequestBody PinnedAndUnpinnedReportsReqDTO pinnedAndUnpinnedReportsReq)
                    throws AppBusinessException {

        reportsVendorMasterService.setPinnedAndUnpinnedReports(pinnedAndUnpinnedReportsReq);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(null)
                                        .message("pin and unpin reports are stored successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/reportlist-suggested", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Override
    public ResponseEntity<APIResponseDTO> getSuggestedReports(HttpServletRequest httpServletRequest,
                    @RequestBody BaseReqDTO baseReqDTO) throws AppBusinessException {

        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1)
                                        .data(reportsVendorMasterService.getSuggestedReportsDetail(baseReqDTO))
                                        .message("Vendor Suggested Reports details are displayed successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/reportlist-recent", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Override
    public ResponseEntity<APIResponseDTO> getRecentReports(HttpServletRequest httpServletRequest,
                    @RequestBody BaseReqDTO baseReqDTO) throws AppBusinessException {

        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1)
                                        .data(reportsVendorMasterService.getRecentReportsDetail(baseReqDTO))
                                        .message("Vendor Recent Reports details are displayed successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/report-submodulelist", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Override
    public ResponseEntity<APIResponseDTO> getReportSubmoduleList(HttpServletRequest httpServletRequest,
                    @RequestBody ReportsSubModuleReqDTO reportsSubModuleReqDTO) throws AppBusinessException {

        List<ReportsSubModuleResDTO> reportsSubModuleList = reportsVendorMasterService
                        .getReportsSubModuleList(reportsSubModuleReqDTO);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(reportsSubModuleList)
                                        .message("Vendor Sub Module List is displayed successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/report-name-list-submodulewise", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Override
    public ResponseEntity<APIResponseDTO> getSubMduleWiseReportLIst(HttpServletRequest httpServletRequest,
                    @RequestBody SubModuleWiseReportsListReqDTO subModuleWiseReportsListReqDTO)
                    throws AppBusinessException {

        List<SubModuleWiseReportsListResDTO> reportsSubModuleList = reportsVendorMasterService
                        .getSubModuleWiseReportList(subModuleWiseReportsListReqDTO);
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(reportsSubModuleList)
                        .message("Module list fetched successfully").tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/vendormaster-downloadreports", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Override
    public ResponseEntity<APIResponseDTO> downloadVendorMasterReports(HttpServletRequest httpServletRequest,
                    @RequestBody ReportsVendorMasterReqDTO reportsVendorMasterReqDTO) throws BDOException {

        Map<String, Object> headerAndFile = reportsVendorMasterService
                        .downloadVendorMasterReportsCustom(reportsVendorMasterReqDTO);

        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(headerAndFile)
                                        .message((String) headerAndFile.get(ReportsConstants.SUCCESS_MESSAGE_KEY))
                                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/filing-viewreports", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Override
    public ResponseEntity<APIResponseDTO> getFilingViewReportsList(HttpServletRequest httpServletRequest,
                    @RequestBody FilingVeiwReportsReqDTO filingVeiwReportsReqDTO) throws AppBusinessException {

        Map<String, Object> filingViewReportsData = reportsVendorMasterService
                        .getFilingViewReportsList(filingVeiwReportsReqDTO);
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(filingViewReportsData)
                        .message((String) filingViewReportsData.get(ReportsConstants.SUCCESS_MESSAGE_KEY))
                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/sendinvites-viewreports", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Override
    public ResponseEntity<APIResponseDTO> getSendInvitesViewReports(HttpServletRequest httpServletRequest,
                    @RequestBody SendInvitesViewReportsReqDTO sendInvitesViewReportsReqDTO)
                    throws AppBusinessException {

        Map<String, Object> sendInvitesViewReportsData = reportsVendorMasterService
                        .getSendInvitesViewReports(sendInvitesViewReportsReqDTO);
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(sendInvitesViewReportsData)
                        .message((String) sendInvitesViewReportsData.get(ReportsConstants.SUCCESS_MESSAGE_KEY))
                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/get-report-customized-column-list")
    @Override
    public ResponseEntity<APIResponseDTO> getReportsCustomizedColumnList(HttpServletRequest httpServletRequest,
                    @RequestBody GetReportsCustomizeColumnListReqDTO getSaveCustomizedColumnListReqDTO)
                    throws AppBusinessException {

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(reportsVendorMasterService
                                        .getCustomizedColumnListFromService(getSaveCustomizedColumnListReqDTO))
                        .message(" Get Reports customized column list is uploaded successfully")
                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/save-report-customized-column-list")
    @Override
    public ResponseEntity<APIResponseDTO> getReportsSavedCustomizedColumnList(HttpServletRequest httpServletRequest,
                    @RequestBody GetReportsSavedCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO)
                    throws AppBusinessException {

        reportsVendorMasterService.getSavedCustomizedColumnListFromService(saveCustomizeColumnListReqDTO);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(null)
                                        .message("Reports Customized column list saved successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/vendormaster-background-report")
    @Override
    public ResponseEntity<APIResponseDTO> vendorMasterBackGroundReports(HttpServletRequest httpServletRequest,
                    @RequestBody ReportsVendorMasterReqDTO generateBackgroundReports) throws AppBusinessException {

        String filename = reportsModuleHelperService.getFileName(generateBackgroundReports.getReportId());
        reportsVendorMasterService.backgroundReportsGenerationProccess(generateBackgroundReports);
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(null)
                        .message(ReportsConstants.SUCCESS_MESSAGE_BACKGROUND_DESCRIPTION + filename + "'")
                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/background-report-list")
    @Override
    public ResponseEntity<APIResponseDTO> getBackgroungReports(HttpServletRequest httpServletRequest,
                    @RequestBody BaseReqDTO requestDTO) throws AppBusinessException {

        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1)
                                        .data(reportsVendorMasterService.getBackgroundReportsData(requestDTO))
                                        .message(" Background reports Data is Getting  successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/vendorinvoice-inputreport")
    @Override
    public ResponseEntity<APIResponseDTO> getVendorInvoiceInputReports(HttpServletRequest httpServletRequest,
                    @RequestBody VendorInvoiceInputReportsReqDTO vendorInvoiceInputReportsReq)
                    throws AppBusinessException, SQLException {

        Map<String, Object> vendorInvoiceInputReportsRes = reportsVendorInvoiceService
                        .getVendorInvoiceInputReports(vendorInvoiceInputReportsReq);// dataAndColumns.put(ReportsConstants.SUCCESS_MESSAGE_KEY

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(vendorInvoiceInputReportsRes)
                        .message((String) vendorInvoiceInputReportsRes.get(ReportsConstants.SUCCESS_MESSAGE_KEY))
                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/vendorinvoice-getreport")
    @Override
    public ResponseEntity<APIResponseDTO> getVendorInvoiceGetReports(HttpServletRequest httpServletRequest,
                    @RequestBody VendorInvoiceGetReqDTO vendorInvoiceGetReportsReq)
                    throws AppBusinessException, SQLException {

        Map<String, Object> vendorInvoiceGetReportsRes = reportsVendorInvoiceService
                        .getVendorInvoiceGETReports(vendorInvoiceGetReportsReq);

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(vendorInvoiceGetReportsRes)
                        .message((String) vendorInvoiceGetReportsRes.get(ReportsConstants.SUCCESS_MESSAGE_KEY))
                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/vendorinvoice-syncreport")
    @Override
    public ResponseEntity<APIResponseDTO> getVendorInvoiceSyncReports(HttpServletRequest httpServletRequest,
                    @RequestBody VendorInvoiceSyncReqDTO vendorInvoiceSyncReq)
                    throws AppBusinessException, SQLException {

        Map<String, Object> vendorInvoiceGetReportsRes = reportsVendorInvoiceService
                        .getVendorInvoiceSyncReports(vendorInvoiceSyncReq);

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(vendorInvoiceGetReportsRes)
                        .message((String) vendorInvoiceGetReportsRes.get(ReportsConstants.SUCCESS_MESSAGE_KEY))
                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/inward-registerreport")
    @Override
    public ResponseEntity<APIResponseDTO> getVendorCommunicationInwardReports(HttpServletRequest httpServletRequest,
                    @RequestBody VendorCommunicationInwardReqDTO vendorCommunicationInwardReq)
                    throws AppBusinessException, SQLException {

        Map<String, Object> vendorCommunicationInwarReportsRes = reportsVendorCommunicationService
                        .getVendorCommunicationInwarReports(vendorCommunicationInwardReq);

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(vendorCommunicationInwarReportsRes)
                        .message((String) vendorCommunicationInwarReportsRes.get(ReportsConstants.SUCCESS_MESSAGE_KEY))
                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/inward-gstr2aor2brecoreport")
    @Override
    public ResponseEntity<APIResponseDTO> getVendorCommunicationReconciliationReports(
                    HttpServletRequest httpServletRequest,
                    @RequestBody VendorCommunicationReconciliationReqDTO vendorCommunicationReconciliationReq)
                    throws AppBusinessException, SQLException {

        Map<String, Object> vendorCommunicationReconciliationReportsRes = reportsVendorCommunicationService
                        .getVendorCommunicationReconciliationReports(vendorCommunicationReconciliationReq);

        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(vendorCommunicationReconciliationReportsRes)
                                        .message((String) vendorCommunicationReconciliationReportsRes
                                                        .get(ReportsConstants.SUCCESS_MESSAGE_KEY))
                                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/vendor-emailstatusreport")
    @Override
    public ResponseEntity<APIResponseDTO> getVendorCommunicationEmailStatusReports(
                    HttpServletRequest httpServletRequest,
                    @RequestBody VendorCommunicationEmailStatusReqDTO vendorCommunicationEmailStatusReq)
                    throws AppBusinessException, SQLException {

        Map<String, Object> vendorCommunicationEmailStatusReportsRes = reportsVendorCommunicationService
                        .getVendorCommunicationEmailStatusReports(vendorCommunicationEmailStatusReq);

        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(vendorCommunicationEmailStatusReportsRes)
                                        .message((String) vendorCommunicationEmailStatusReportsRes
                                                        .get(ReportsConstants.SUCCESS_MESSAGE_KEY))
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

    @PostMapping(value = "/custom-modulelist")
    @Override
    public ResponseEntity<APIResponseDTO> getCustomModuleList(HttpServletRequest httpServletRequest,
                    @RequestBody BaseReqDTO baseReqDTO) throws AppBusinessException {

        List<ModuleIdAndNameDTO> moduleCodeAndNameList = reportsModuleHelperService.getModuleCodeAndName(baseReqDTO);

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(moduleCodeAndNameList)
                        .message("Module list get sucessfully.").tag(httpServletRequest.getRequestURI()).build());
    }

    @PostMapping(value = "/reportlist-search", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Override
    public ResponseEntity<APIResponseDTO> getSearchReports(HttpServletRequest httpServletRequest,
                    @RequestBody SearchReportReqDTO searchReportReq) throws AppBusinessException {

        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1)
                                        .data(reportsVendorMasterService.getSearchReporst(searchReportReq))
                                        .message("Search Reports are displayed successfully.")
                                        .tag(httpServletRequest.getRequestURI()).build());

    }
}
