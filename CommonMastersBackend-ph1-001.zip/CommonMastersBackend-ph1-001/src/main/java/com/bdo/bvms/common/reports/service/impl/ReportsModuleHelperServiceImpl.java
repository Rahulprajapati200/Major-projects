package com.bdo.bvms.common.reports.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.config.AzureClientProvider;
import com.bdo.bvms.common.dto.BaseReqDTO;
import com.bdo.bvms.common.dto.ModuleIdAndNameDTO;
import com.bdo.bvms.common.exceptions.AppBusinessException;
import com.bdo.bvms.common.reports.dao.ReportModuleCommonRepo;
import com.bdo.bvms.common.reports.dao.ReportsVendorMasterRepo;
import com.bdo.bvms.common.reports.service.ReportsModuleHelperService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ReportsModuleHelperServiceImpl implements ReportsModuleHelperService {

    @Value("${bvms.cloud.temp.file.download.path}")
    String tempFolder;

    @Autowired
    ReportsVendorMasterRepo reportsVendorMasterRepo;
    @Autowired
    ReportModuleCommonRepo reportModuleCommonRepo;

    @Autowired
    public AzureClientProvider client;

    @Override
    public List<ModuleIdAndNameDTO> getModuleCodeAndName(BaseReqDTO baseReqDTO) throws AppBusinessException {

        return reportModuleCommonRepo.getModuleCodeAndName(baseReqDTO);
    }

    @Override
    public String getFileName(String reportId) {
        String fileName = "";
        try {
            fileName = reportModuleCommonRepo.getFileName(reportId);
        } catch (Exception e) {
            log.error("error in getting  file name from database", e);
        }
        return fileName;
    }

//    public void sendMailToUser(BigInteger id) throws MessagingException {
//
//        //MailTemplateDTO mailDetails = reportModuleCommonRepo.sendMailDetails(id);
//
//        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
//
//        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
//
//        helper.setTo(mailDetails.getMailTo());
//
//        helper.setFrom(mailDetails.getMailFrom());
//        helper.setSubject(mailDetails.getMailSubject());
//
//        helper.setText(mailDetails.getMailBody(), true);
//
////        ClassPathResource classPathResource = new ClassPathResource("VendoeInvoice_question.txt");
////        helper.addAttachment(classPathResource.getFilename(), classPathResource);
//        helper.addInline("myLogo", new ClassPathResource("BDO_logo.jpg"));
//
//        javaMailSender.send(mimeMessage);

    // }

}
