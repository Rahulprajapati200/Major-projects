package com.bdo.bvms.common.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;


public class AppUtil {

	private AppUtil()
	{
		super();
	}
	
	public static String getCellValue(Cell cell) {
		String strCellValue = null;
		
		try {
		
		if (cell != null) {
		
				switch (cell.getCellType()) {
					case STRING:
						strCellValue = cell.getStringCellValue().replaceAll("[\n\r\t]", " ");
						break;
					case FORMULA:
					    switch (cell.getCachedFormulaResultType()) {
					        case BOOLEAN:
					        	strCellValue=Boolean.toString(cell.getBooleanCellValue());
					            break;
					        case NUMERIC:
					        	strCellValue = NumberToTextConverter.toText(cell.getNumericCellValue());
					            break;
					        case STRING:
					           
					            strCellValue = cell.getRichStringCellValue().getString().replaceAll("[\n\r\t]", " ");
					            break;
					        default:    
					    }
					
						break;
					case NUMERIC:
						if (DateUtil.isCellDateFormatted(cell)) {
							SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
							strCellValue = dateFormat.format(cell.getDateCellValue());

						} else {
							strCellValue = NumberToTextConverter.toText(cell.getNumericCellValue());
						}
						break;
					case BOOLEAN:
						strCellValue = Boolean.toString(cell.getBooleanCellValue());
						break;
					case BLANK:
						strCellValue = "";
						break;
					default:
						
				}
			}
		
		if (strCellValue != null) {
			strCellValue = strCellValue.trim();
		} else {
			strCellValue = "";
		}
		
		}catch(Exception ex) {
			
			switch (cell.getCellType()) {
				case STRING:
					strCellValue = "";
					break;
				case FORMULA:
				    switch (cell.getCachedFormulaResultType()) {
				        case BOOLEAN:
				        	strCellValue="false";
				            break;
				        case NUMERIC:
				        	strCellValue = "0";
				            break;
				        case STRING:
				           
				            strCellValue = "";
				            break;
				        default:    
				    }
				
					break;
				case NUMERIC:
					if (DateUtil.isCellDateFormatted(cell)) {
						strCellValue = "";

					} else {
						strCellValue = "0";
					}
					break;
				case BOOLEAN:
					strCellValue = "false";
					break;
				case BLANK:
					strCellValue = "";
					break;
				default:
					
		}
		}
		return strCellValue;
	}
	public static Map<String, Integer> getColumnNameIndexMap(Row coumnsDataRow) {

		Map<String, Integer> colNameIndexMap = new java.util.HashMap<>(); // Create map
		int minColIx = coumnsDataRow.getFirstCellNum(); // get the first column
		// index for a row
		int maxColIx = coumnsDataRow.getLastCellNum(); // get the last column
		// index for a row
		Cell cell;
		for (int colIx = minColIx; colIx < maxColIx; colIx++) { // loop from
			// first to last
			// index
			cell = coumnsDataRow.getCell(colIx); // get the cell
			
			if(cell.getCellType()==CellType.NUMERIC) {
				colNameIndexMap.put(String.valueOf(cell.getNumericCellValue()), cell.getColumnIndex()); // add the cell contents (name of column) and cell index to the map
			}else {
				colNameIndexMap.put(cell.getStringCellValue(), cell.getColumnIndex()); // add the cell contents (name of column) and cell index to the map
			}
			
			
		}
		return colNameIndexMap;
	}
	
	public static Boolean isNotBlank(Row row) {
		int cellCount;
		Cell cell;
		for (cellCount = row.getFirstCellNum(); cellCount <= row.getLastCellNum(); cellCount++) {
			cell = row.getCell(cellCount);
			if (cell != null && row.getCell(cellCount).getCellType() != CellType.BLANK) {
				return true;
			}
		}
		return false;
	}
	
	public static List<String> getColumnNameList(Row coumnsDataRow) {

        List<String> headerList = new ArrayList<>();
        int minColIx = coumnsDataRow.getFirstCellNum(); // get the first column
        // index for a row
        int maxColIx = coumnsDataRow.getLastCellNum(); // get the last column
        // index for a row
        Cell cell;
        for (int colIx = minColIx; colIx < maxColIx; colIx++) { // loop from
            // first to last
            // index
            cell = coumnsDataRow.getCell(colIx); // get the cell

            if (cell.getCellType() == CellType.NUMERIC) {
                headerList.add(String.valueOf(cell.getNumericCellValue())); 
            } else {
                headerList.add(cell.getStringCellValue()); 
            }
        }
        return headerList;
    }
	
}
