package com.bdo.bvms.common.dto;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class SearchModuleListReqDTO extends BaseReqDTO{

	@NotEmpty(message= "{gstinOrPan.notempty}")
    String gstinOrPan;

    @NotEmpty(message= "{gstinOrPanList.notempty}")
    List<String> gstinOrPanList;
	
	private String templateName;
	
	@NotNull(message = "{isCustomTemplate.notNull}")
	private Boolean isCustomTemplate;

	
}

