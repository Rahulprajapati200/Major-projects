package com.bdo.bvms.common.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomEmailTemplateDetailsResDTO {

	private String moduleName;
	
	private String refTemplateName;
	
	private String body;
	
	private String subject;
	
	private String templateName;
	
	private Integer customTemplateNameId;
	
	private Integer pldTemplateId;
	
	private Integer refTemplateId;
	
	private String to;
	
	private String from;
	
	private String signatureLogoExt;
	
	private String companyLogoExt;
	
	private String signatureText;
	
}
