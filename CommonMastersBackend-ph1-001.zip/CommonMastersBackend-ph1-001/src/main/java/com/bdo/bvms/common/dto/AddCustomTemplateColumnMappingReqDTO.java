package com.bdo.bvms.common.dto;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class AddCustomTemplateColumnMappingReqDTO extends BaseReqDTO {

	//@NotBlank(message = "Request parameter templateColumn must not be null or empty")
	String templateColumn;
	
	@NotNull(message = "Request parameter templateColumnConfigurationId must not be null")
	Integer templateColumnConfigurationId;
	
	@NotNull(message = "Request parameter isAutoMap must not be null")
	Boolean isAutoMap;
	
	List<@Valid AddCustomTemplateColumnValueMappingReqDTO> addCustomTemplateColumnValueMapping ;
	
}
