package com.bdo.bvms.common.repository;

import java.util.List;

import org.springframework.data.domain.PageImpl;

import com.bdo.bvms.common.model.PickupListDetail;

public interface IPickupMasterRepository {

    List<PickupListDetail> searchPickupMaster(String lkupcode);

	PickupListDetail searchPickupDetailByNameAndCode(PickupListDetail pickupListDetail);

	PageImpl<PickupListDetail> searchModulesPickupMasterByNamePickKey(PickupListDetail pickupListDetail);

	List<PickupListDetail> searchPickupMasterByNamePickKey(PickupListDetail pickupListDetail);

}
