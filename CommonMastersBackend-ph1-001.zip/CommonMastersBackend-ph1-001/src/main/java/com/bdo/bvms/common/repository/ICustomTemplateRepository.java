package com.bdo.bvms.common.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import com.bdo.bvms.common.dto.DisableCustomTemplateDTO;
import com.bdo.bvms.common.dto.ModuleCodeAndNameDTO;
import com.bdo.bvms.common.dto.SearchCustomEmailDetailsReqDTO;
import com.bdo.bvms.common.model.CustomEmailTemplateCategory;
import com.bdo.bvms.common.model.CustomEmailTemplatePlaceholderDictionary;
import com.bdo.bvms.common.model.CustomTemplateColumnMapping;
import com.bdo.bvms.common.model.CustomTemplateColumnValueMapping;
import com.bdo.bvms.common.model.CustomTemplateDetails;
import com.bdo.bvms.common.model.CustomTemplateEmail;
import com.bdo.bvms.common.model.CustomTemplateEmailArchived;
import com.bdo.bvms.common.model.CustomTemplateName;
import com.bdo.bvms.common.model.CustomTemplateOptionValueDetails;
import com.bdo.bvms.common.model.CustomTemplateOptions;
import com.bdo.bvms.common.model.TemplateColumnConfig;
import com.bdo.bvms.common.model.TemplateModule;
import com.bdo.bvms.common.model.TemplateSampleData;
import com.bdo.bvms.common.model.TemplateType;

public interface ICustomTemplateRepository {

    List<TemplateColumnConfig> getCustomTemplateColumnConfig(TemplateColumnConfig customTemplateColumnConfig);

    void insertCustomTemplateColumnValueMapping(
                    List<CustomTemplateColumnValueMapping> customTemplateColumnValueMappingList);

    Integer insertCustomTemplateColumnMapping(CustomTemplateColumnMapping customTemplateColumnMapping);

    Integer insertCustomTemplateName(CustomTemplateName customTemplateName);

    List<CustomTemplateOptions> getCustomTemplateOptions(CustomTemplateOptions customTemplateOptions);

    PageImpl<CustomTemplateName> getCustomTemplatesName(CustomTemplateName customTemplateNameReq,
                    Integer pickupMasterId, String pickKey, Integer moduleMasterId, Pageable paging, String reportId);

    List<CustomTemplateName> getCustomTemplateNames(CustomTemplateName customTemplateNameReq);

    int updateCustomTemplateStatus(CustomTemplateName customTemplateName);

    CustomTemplateName getCustomTemplateName(CustomTemplateName customTemplateName);

    Map<String, Object> searchCustomTemplateOptionsMappings(int customTemplateId, String primaryContactLkUpName,
                    String defaultAddressLkUpName, String primaryBankLkUpName, String addressTypeLkUpName);

    Map<String, String> searchCustomTemplateHeaderMappings(int customTemplateId);

    void insertTemplateSampleData(TemplateSampleData templateSampleData);

    List<CustomTemplateDetails> getCustomTemplateMappingDetails(
                    CustomTemplateColumnMapping customTemplateColumnMapping);

    List<CustomTemplateOptionValueDetails> getCustomTemplateOptionsValueMapping(
                    CustomTemplateColumnMapping customTemplateColumnMapping);

    CustomTemplateColumnMapping checkIfCustomTemplateColumnMappingExists(
                    CustomTemplateColumnMapping customTemplateColumnMapping);

    int updateCustomTemplateMapping(CustomTemplateColumnMapping customTemplateColumnMapping);

    CustomTemplateColumnValueMapping checkIfCustomTemplateColumnValueMappingExistsById(
                    CustomTemplateColumnValueMapping customTemplateColumnValueMapping);

    int updateCustomTemplateColumnValueMapping(CustomTemplateColumnValueMapping customTemplateColumnValueMapping);

    CustomTemplateColumnValueMapping checkIfCustomTemplateColumnValueMappingExists(
                    CustomTemplateColumnValueMapping customTemplateColumnValueMapping);

    CustomTemplateName getCustomTemplateNameById(CustomTemplateName customTemplateName);

    List<TemplateSampleData> getCustomTemplateSampleData(TemplateSampleData templateSampleData);

    List<TemplateModule> getCustomModuleList(CustomTemplateName customTemplateNameReq,
                    Integer templateTypePickupMasterId, Integer modulePickupMasterId);

    List<TemplateModule> getDefaultModuleList(Integer templateTypePickupMasterId, Integer modulePickupMasterId);

    List<ModuleCodeAndNameDTO> getModuleNameAndCode(int pickupMasterId, int pickKey);

    List<CustomEmailTemplatePlaceholderDictionary> searchCustomEmailPlaceHolders(
                    CustomEmailTemplatePlaceholderDictionary build);

    CustomTemplateName getCustomEmailTemplateName(CustomTemplateName customTemplateName);

    Integer insertCustomTemplateEmail(CustomTemplateEmail customTemplateEmail);

    int updateCustomTemplateEmail(CustomTemplateEmail customTemplateEmail);

    CustomTemplateEmail checkIfCustomTemplateEmailExists(CustomTemplateEmail customTemplateEmail);

    void disableCustomTemplate(DisableCustomTemplateDTO disableCustomTemplateDTO);

    List<TemplateModule> getCustomEmailModuleList(CustomTemplateName customTemplateNameReq,
                    Integer modulePickupMasterId, Integer isDefaultTemplate);

    PageImpl<CustomTemplateName> getCustomEmailTemplatesName(CustomTemplateName customTemplateNameReq, Pageable paging,
                    Boolean isDefaultTemplate);

    CustomTemplateEmail searchDefaultEmailDetails(CustomTemplateEmail customTemplateEmail, Integer moduleId);

    List<CustomEmailTemplateCategory> getCustomEmailTemplateCategory(
                    CustomEmailTemplateCategory customEmailTemplateCategory);

    List<CustomEmailTemplateCategory> getCustomEmailModuleList();

    CustomTemplateEmail getCustomEmailTemplateDetails(CustomTemplateEmail customTemplateEmail);

    List<TemplateModule> getDefaultEmailModuleList(CustomTemplateName customTemplateNameReq,
                    Integer modulePickupMasterId, Integer isDefaultTemplate);

    PageImpl<CustomTemplateName> getDefaultEmailTemplatesName(CustomTemplateName customTemplateNameReq, Pageable page,
                    Boolean isDefaultTemplate);

    PageImpl<CustomTemplateName> getCustomTemplatesListName(CustomTemplateName customTemplateNameReq,
                    Integer templatePickupMasterId, String pickKey, Integer moduleMasterId, Pageable page,
                    String reportId);

    void getFromAndTo(SearchCustomEmailDetailsReqDTO searchCustomEmailDetailsReqDTO,
                    CustomTemplateEmail customTemplateEmail);

    int updateCustomTemplateEmailModifiedaAt(CustomTemplateEmail customTemplateEmail, String customTemplateName,
                    String userId);

    Integer insertCustomTemplateEmailArchived(CustomTemplateEmailArchived customTemplateEmailArchived);

    List<TemplateType> getTemplateType();

    int getTemplateStatus(String customTemplateId);

}
