package com.bdo.bvms.common.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DownloadFileInfo {
	
	String fileUrl;
	String basefileName;
	String errorfileName;
	String containerName;
	
	
	

}
