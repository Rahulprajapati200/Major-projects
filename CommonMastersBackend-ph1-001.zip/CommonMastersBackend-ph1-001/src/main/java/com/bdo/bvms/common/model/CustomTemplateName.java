package com.bdo.bvms.common.model;

import java.util.Date;

import com.bdo.bvms.common.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomTemplateName {

    Integer id;
    Integer pldTemplateId;
    String pan;
    Integer entityId;
    String name;
    String freeSearch;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI)
    Date createdAt;

    Integer createdBy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI)
    Date modifiedAt;

    Integer modifiedBy;
    Integer pldStatus;
    Boolean isEmailTemplate;
    Integer pldModuleId;

    // Added for user detail on custom template mapping
    String userName;

    String module;
    String refId;

}
