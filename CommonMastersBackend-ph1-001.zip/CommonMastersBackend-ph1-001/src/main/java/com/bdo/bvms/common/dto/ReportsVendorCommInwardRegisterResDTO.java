package com.bdo.bvms.common.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ReportsVendorCommInwardRegisterResDTO {

    String gstinUinOfRecipient;
    String docType;
    String supplyType;
    String docNo;
    String docDate;
    String orgInvoiceNo;
    String orgInvoiceDate;
    String gstinOfSupplier;
    String supplierName;
    String supplierStateCode;
    String inwardNo;
    String inwardDate;
    String itemDescription;
    String hsnCode;
    String uom;
    String quantity;
    String itemRate;
    String assAmt;
    String sgstRate;
    String sgstAmt;
    String cgstRate;
    String cgstAmt;
    String igstRate;
    String igstAmt;
    String cessRate;
    String cessAmount;
    String diffPercent;
    String inwardGrossTotalAmount;
    String totalInvoiceAmt;
    String inputType;
    String itcIneligibleReversalIndicator;
    String itcIneligibleReversalPerc;
    String placeOfSupply;
    String reverseCharge;
    String tdsSection;
    String tdsRate;
    String tdsTaxAmount;
    String grossAmount;
    String challanNumber;
    String challanDate;
    String challanAmount;
    String periodOfFiling;
    String invoiceAgainstProvAdv;
    String inwardNoProvAdv;
    String amountOfProvAdv;
    String balOutstanding;
    String port;
    String importBillOfEntryNo;
    String importBillOfEntryDate;
    String importBillOfEntryAmt;
    String dateOfPayment;
    String irn;
    String ackDate;
    String ackNo;
    String debitGlId;
    String debitGlName;
    String creditGlId;
    String creditGlName;
    String subLocation;
    String udf1;
    String udf2;
    String udf3;
    String udf4;
    String udf5;
    String udf6;
    String udf7;
    String udf8;
    String udf9;
    String udf10;
    String udf11;
    String udf12;
    String udf13;
    String udf14;
    String udf15;
    String udf16;
    String udf17;
    String udf18;
    String udf19;
    String udf20;
    String fp;
    String sumTaxableAmount;
    String sumSgstAmt;
    String sumCgstAmt;
    String sumIgstAmt;
    String sumTotalTaxAmount;
    String sumGrossTotalAmount;
    String errorCode;
    String errorMessage;

}
