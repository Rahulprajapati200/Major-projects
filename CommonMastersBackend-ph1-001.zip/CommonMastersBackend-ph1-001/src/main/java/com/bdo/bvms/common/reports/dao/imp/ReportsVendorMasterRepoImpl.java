package com.bdo.bvms.common.reports.dao.imp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.config.AzureClientProvider;
import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.BaseReqDTO;
import com.bdo.bvms.common.dto.FilingVeiwReportsReqDTO;
import com.bdo.bvms.common.dto.FilingVeiwReportsResDTO;
import com.bdo.bvms.common.dto.GetBackGroundReportsDetailResDTO;
import com.bdo.bvms.common.dto.GetCustomizedColumnListResDTO;
import com.bdo.bvms.common.dto.GetReportsCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.GetReportsSavedCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.PinnedAndUnpinnedReportsReqDTO;
import com.bdo.bvms.common.dto.ReportDetailsResDTO;
import com.bdo.bvms.common.dto.ReportsSubModuleReqDTO;
import com.bdo.bvms.common.dto.ReportsSubModuleResDTO;
import com.bdo.bvms.common.dto.ReportsVendorMasterReqDTO;
import com.bdo.bvms.common.dto.ReportsVendorMasterResDTO;
import com.bdo.bvms.common.dto.SearchReportReqDTO;
import com.bdo.bvms.common.dto.SendInvitesViewReportsReqDTO;
import com.bdo.bvms.common.dto.SendInvitesViewReportsResDTO;
import com.bdo.bvms.common.dto.SubModuleWiseReportsListReqDTO;
import com.bdo.bvms.common.dto.SubModuleWiseReportsListResDTO;
import com.bdo.bvms.common.dto.UserCustomizeColumnDTO;
import com.bdo.bvms.common.exceptions.BDOException;
import com.bdo.bvms.common.reports.constants.ReportsConstants;
import com.bdo.bvms.common.reports.dao.ReportModuleCommonRepo;
import com.bdo.bvms.common.reports.dao.ReportsVendorMasterRepo;
import com.bdo.bvms.common.reports.sql.ReportsCommonSql;
import com.bdo.bvms.common.util.DateUtil;
import com.microsoft.azure.storage.core.Base64;

import lombok.Synchronized;
import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class ReportsVendorMasterRepoImpl implements ReportsVendorMasterRepo {

    String gstinList;

    /** The jdbc template trn. */
    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Autowired
    public AzureClientProvider client;

    @Value("${bvms.cloud.temp.file.download.path}")
    String tempFolder;

    @Value("${txn.database-name}")
    private String transDatabaseName;

    @Autowired
    ReportModuleCommonRepo reportModuleCommonRepo;

    long key;

    CallableStatement cs = null;

    String callStatement;

    String year = "";
    String year1 = "";

    ResourceBundle messages = ResourceBundle.getBundle("messages");
    String errorInGeneratingCSVFile = messages.getString("errorInGeneratingCSVFile");
    String errorInGeneratingExcelWorkbook = messages.getString("errorInGeneratingExcelWorkbook");
    String greeting = messages.getString("searchParameters");

    @Override
    @Synchronized
    public Map<String, Object> getReportsVendorMaster(ReportsVendorMasterReqDTO reportsVendorMasterReq,
                    String taxpayergstinList, String vendorGstinList) throws SQLException {

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        int templateTypeId = 6;
        String actionType = "view";
        String isCustom = reportModuleCommonRepo.getCustomOrDefault(reportsVendorMasterReq.getReportId());

        Map<String, Object> results;
        key = reportModuleCommonRepo.getKeyFromKeyHolder();

        try {
            results = jdbcTemplateTrn.call(new CallableStatementCreator() {

                @Override
                public CallableStatement createCallableStatement(Connection con) throws SQLException {
                    try {
                        if (ReportsConstants.CUSTOM_VENDOR_MASTER_AS_PER_VENDOR_ERROR_REPORT
                                        .equals(reportsVendorMasterReq.getReportId())
                                        || ReportsConstants.CUSTOM_VENDOR_MASTER_COMBINED_ERROR_REPORT
                                                        .equals(reportsVendorMasterReq.getReportId())
                                        || ReportsConstants.CUSTOM_VENDOR_MASTER_TAXPAYER_ERROR_REPORT
                                                        .equals(reportsVendorMasterReq.getReportId())) {

                            cs = con.prepareCall(ReportsConstants.REPORT_MASTER_TP_VENDOR_GSTIN_COMBINED_ERROR);
                        } else {
                            cs = con.prepareCall(ReportsConstants.REPORT_MASTER_TP_VENDOR_GSTIN_COMBINED);
                        }

                        cs.setLong(1, Integer.valueOf(reportsVendorMasterReq.getGstinOrPan()));
                        cs.setString(2, taxpayergstinList);
                        cs.setString(3, vendorGstinList);
                        cs.setString(4, reportsVendorMasterReq.getReportId());
                        cs.setString(5, mstDatabseName);
                        cs.setString(6, isCustom);
                        cs.setInt(7, templateTypeId);
                        cs.setInt(8, reportsVendorMasterReq.getCustomTemplateId());
                        cs.setString(9, reportsVendorMasterReq.getUserId());
                        cs.setString(10, actionType);
                        cs.setLong(11, reportsVendorMasterReq.getSize());
                        cs.setLong(12, (reportsVendorMasterReq.getPage() * reportsVendorMasterReq.getSize()));
                        callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                        reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                        return cs;
                    } catch (SQLException e) {
                        if (cs != null) {
                            cs.close();
                        }
                        throw e;
                    }
                }
            }, parameters);

        } finally {
            if (cs != null) {
                cs.close();
            }
        }

        List<ReportsVendorMasterResDTO> reportsVendorMasterResList = new ArrayList<>();
        Map<String, Object> dataAndCount = new HashMap<>();
        if (!results.isEmpty()) {

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> dataList = (List<Map<String, Object>>) results.get(ReportsConstants.RESULT_SET_1);
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> countValue = (List<Map<String, Object>>) results
                            .get(ReportsConstants.RESULT_SET_2);
            Map<String, Object> count11 = countValue.get(0);
            long totalCount = (long) count11.get("total_count");

            if (dataList != null) {
                dataList.stream().forEach(dataObject -> {

                    ReportsVendorMasterResDTO dataRes = new ReportsVendorMasterResDTO();

                    dataRes.setAadharVendor(checkNullValue((String) dataObject.get("aadhar_vendor")));
                    dataRes.setAccountHolderName(checkNullValue((String) dataObject.get("account_holder_name")));
                    dataRes.setAccountNumber(checkNullValue((String) dataObject.get("account_number")));
                    dataRes.setAddress1(checkNullValue((String) dataObject.get("address1")));
                    dataRes.setAddress2(checkNullValue((String) dataObject.get("address2")));
                    dataRes.setAddressType(checkNullValue((String) dataObject.get("pld_address_type")));
                    dataRes.setBankAddress(checkNullValue((String) dataObject.get("bank_address")));
                    dataRes.setBankName(checkNullValue((String) dataObject.get("bank_name")));
                    dataRes.setCompanyLegalName(checkNullValue((String) dataObject.get("company_legal_name")));
                    dataRes.setCompanyTradeName(checkNullValue((String) dataObject.get("company_trade_name")));
                    dataRes.setEmail(checkNullValue((String) dataObject.get("email")));
                    dataRes.setField1(checkNullValue((String) dataObject.get("field1")));
                    dataRes.setField2(checkNullValue((String) dataObject.get("field2")));
                    dataRes.setField3(checkNullValue((String) dataObject.get("field3")));
                    dataRes.setField4(checkNullValue((String) dataObject.get("field4")));
                    dataRes.setField5(checkNullValue((String) dataObject.get("field5")));
                    dataRes.setField6(checkNullValue((String) dataObject.get("field6")));
                    dataRes.setField7(checkNullValue((String) dataObject.get("field7")));
                    dataRes.setField8(checkNullValue((String) dataObject.get("field8")));
                    dataRes.setField9(checkNullValue((String) dataObject.get("field9")));
                    dataRes.setField10(checkNullValue((String) dataObject.get("field10")));
                    dataRes.setField11(checkNullValue((String) dataObject.get("field11")));
                    dataRes.setField12(checkNullValue((String) dataObject.get("field12")));
                    dataRes.setField13(checkNullValue((String) dataObject.get("field13")));
                    dataRes.setField14(checkNullValue((String) dataObject.get("field14")));
                    dataRes.setField15(checkNullValue((String) dataObject.get("field15")));
                    dataRes.setField16(checkNullValue((String) dataObject.get("field16")));
                    dataRes.setField17(checkNullValue((String) dataObject.get("field17")));
                    dataRes.setField18(checkNullValue((String) dataObject.get("field18")));
                    dataRes.setField19(checkNullValue((String) dataObject.get("field19")));
                    dataRes.setField20(checkNullValue((String) dataObject.get("field20")));
                    dataRes.setFirstName(checkNullValue((String) dataObject.get("first_name")));
                    dataRes.setGstinTaxpayer(checkNullValue((String) dataObject.get("gstin_taxpayer")));
                    dataRes.setGstinVendor(checkNullValue((String) dataObject.get("gstin_vendor")));
                    dataRes.setIfscCode(checkNullValue((String) dataObject.get("ifsc_code")));
                    dataRes.setIsDefaultAddress(checkNullValue((String) dataObject.get("is_default_address")));
                    dataRes.setIsPrimaryBank(checkNullValue((String) dataObject.get("is_primary_bank")));
                    dataRes.setIsPrimaryContact(checkNullValue((String) dataObject.get("is_primary_contact")));
                    dataRes.setLastName(checkNullValue((String) dataObject.get("last_name")));
                    dataRes.setMobile(checkNullValue((String) dataObject.get("mobile")));
                    dataRes.setModifiedAt(checkNullValue((String) dataObject.get("modified_at")));
                    dataRes.setPanVendor(checkNullValue((String) dataObject.get("pan_vendor")));
                    dataRes.setPinCode(checkNullValue((String) dataObject.get("pin_code")));
                    dataRes.setPlace(checkNullValue((String) dataObject.get("place")));
                    dataRes.setPrimaryUpi(checkNullValue((String) dataObject.get("primary_upi")));
                    dataRes.setSecondaryUpi(checkNullValue((String) dataObject.get("secondary_upi")));
                    dataRes.setVendorCodeErp(checkNullValue((String) dataObject.get("vendor_code_erp")));
                    dataRes.setVendorType(checkNullValue((String) dataObject.get("vendor_type")));
                    dataRes.setVendorStatus(checkNullValue((String) dataObject.get("vendor_status")));
                    dataRes.setGstinStatus(checkNullValue((String) dataObject.get("pld_gstin_status")));
                    dataRes.setDateOfRegistration(checkNullValue((String) dataObject.get("gstin_registration_date")));
                    dataRes.setDateOfCancellationOrSuspension(
                                    checkNullValue((String) dataObject.get("cancellation_date")));
                    dataRes.setStateJurisdiction(checkNullValue((String) dataObject.get("state_jurisdiction")));
                    dataRes.setCenterJurisdiction(checkNullValue((String) dataObject.get("center_jurisdiction")));
                    dataRes.setAddressStatus(checkNullValue((String) dataObject.get("address_status")));
                    dataRes.setReturnPeriod(checkNullValue((String) dataObject.get("ret_prd")));
                    dataRes.setReturnType(checkNullValue((String) dataObject.get("return_type")));
                    dataRes.setDateOfFiling(checkNullValue((String) dataObject.get("date_of_filing")));
                    dataRes.setAcknoledgementNumber(checkNullValue((String) dataObject.get("acknowledge_no")));
                    dataRes.setReturnFilingStatus(checkNullValue((String) dataObject.get("return_filing_status")));
                    dataRes.setConstitutionOfBusiness(
                                    checkNullValue((String) dataObject.get("constitution_of_business")));
                    dataRes.setSource(checkNullValue((String) dataObject.get("pld_data_version")));
                    dataRes.setNatureOfBusinessActivity(
                                    checkNullValue((String) dataObject.get("nature_of_business_activity")));

                    if (ReportsConstants.CUSTOM_VENDOR_MASTER_AS_PER_VENDOR_ERROR_REPORT
                                    .equals(reportsVendorMasterReq.getReportId())
                                    || ReportsConstants.CUSTOM_VENDOR_MASTER_COMBINED_ERROR_REPORT
                                                    .equals(reportsVendorMasterReq.getReportId())
                                    || ReportsConstants.CUSTOM_VENDOR_MASTER_TAXPAYER_ERROR_REPORT
                                                    .equals(reportsVendorMasterReq.getReportId())) {
                        dataRes.setErrorCode(checkNullValue((String) dataObject.get("error_code")));
                        dataRes.setErrorMessage(checkNullValue((String) dataObject.get("error_message")));

                    }
                    reportsVendorMasterResList.add(dataRes);

                });
            }

            dataAndCount.put("data", reportsVendorMasterResList);
            dataAndCount.put("count", totalCount);
        }

        return dataAndCount;

    }

    @Override
    public String[] getGstinFromDB(String pan) {
        return jdbcTemplateTrn.queryForList(ReportsCommonSql.getTaxpayerGstinFromDbSql(mstDatabseName), String.class,
                        Base64.encode(pan.getBytes())).toArray(new String[0]);
    }

    private static String checkNullValue(String value) {
        if (StringUtils.isEmpty(value)) {
            return "-";
        } else {
            return value;
        }
    }

    @Override
    public Map<String, Object> getPinnedReportsDetail(BaseReqDTO baseReqDTO) {

        Map<String, Object> reportsCountAndReportsList = new HashMap<>();
        int reportsTotalCount = jdbcTemplateTrn.queryForObject(
                        ReportsCommonSql.getPinnedReportsTotalCount(mstDatabseName), Integer.class,
                        baseReqDTO.getUserId(), baseReqDTO.getEntityId());
        List<ReportDetailsResDTO> reportList = jdbcTemplateTrn.query(
                        ReportsCommonSql.getPinnedReportsDetails(mstDatabseName),
                        new ResultSetExtractor<List<ReportDetailsResDTO>>() {

                            public List<ReportDetailsResDTO> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                List<ReportDetailsResDTO> pinnedReportsList = new ArrayList<>();
                                while (rs.next()) {

                                    ReportDetailsResDTO reportDetailsResDTO = new ReportDetailsResDTO();
                                    LocalDateTime pinnedDateTime = rs.getObject("pinned_at", LocalDateTime.class);
                                    String reportCode = rs.getString(ReportsConstants.REPORT_CODE);
                                    String isCustom = reportModuleCommonRepo.getCustomOrDefaultValue(reportCode);

                                    reportDetailsResDTO
                                                    .setId(checkNullValue(rs.getString(ReportsConstants.REPORT_CODE)));
                                    reportDetailsResDTO.setReportname(checkNullValue(rs.getString("name")));
                                    reportDetailsResDTO.setModuleName(checkNullValue(rs.getString("module_Name")));
                                    reportDetailsResDTO.setReportDesc(checkNullValue(rs.getString("description")));
                                    reportDetailsResDTO.setCreatedOn(
                                                    DateUtil.convertLocalDateTimeIntoStringFormat(pinnedDateTime));
                                    reportDetailsResDTO.setCreatedBy(checkNullValue(rs.getString("pinned_by")));
                                    reportDetailsResDTO.setModuleId(checkNullValue(rs.getString("pld_module_id")));
                                    if (isCustom == null || isCustom.equals(ReportsConstants.DEFAULT)
                                                    || isCustom.equals("")) {
                                        reportDetailsResDTO
                                                        .setSubModuleId(checkNullValue(rs.getString("submodule_id")));
                                    } else {
                                        reportDetailsResDTO.setSubModuleId("");
                                    }
                                    pinnedReportsList.add(reportDetailsResDTO);
                                }
                                return pinnedReportsList;
                            }

                        }, baseReqDTO.getUserId(), baseReqDTO.getEntityId(), baseReqDTO.getSize());
        reportsCountAndReportsList.put(ReportsConstants.REPORTTOTALCOUNT, reportsTotalCount);
        reportsCountAndReportsList.put(ReportsConstants.REPORTSLIST, reportList);

        return reportsCountAndReportsList;

    }

    @Override
    public Map<String, Object> getSuggestedReportsDetail(BaseReqDTO baseReqDTO) {

        Map<String, Object> reportsCountAndReportsList = new HashMap<>();
        int reportsTotalCount = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_SUGGESTED_REPORTS_TOTAL_COUNT,
                        Integer.class);
        List<ReportDetailsResDTO> reportList = jdbcTemplateMst.query(ReportsCommonSql.GET_SUGGESTED_REPORTS_DETAILS,
                        new ResultSetExtractor<List<ReportDetailsResDTO>>() {

                            public List<ReportDetailsResDTO> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                List<ReportDetailsResDTO> pinnedReportsList = new ArrayList<>();
                                while (rs.next()) {
                                    ReportDetailsResDTO reportDetailsResDTO = new ReportDetailsResDTO();
                                    reportDetailsResDTO
                                                    .setId(checkNullValue(rs.getString(ReportsConstants.REPORT_CODE)));
                                    reportDetailsResDTO.setReportname(checkNullValue(rs.getString("name")));
                                    reportDetailsResDTO.setModuleName(checkNullValue(rs.getString("moduleName")));
                                    reportDetailsResDTO.setReportDesc(checkNullValue(rs.getString("description")));
                                    pinnedReportsList.add(reportDetailsResDTO);
                                }
                                return pinnedReportsList;
                            }

                        }, baseReqDTO.getSize());

        reportsCountAndReportsList.put(ReportsConstants.REPORTTOTALCOUNT, reportsTotalCount);
        reportsCountAndReportsList.put(ReportsConstants.REPORTSLIST, reportList);

        return reportsCountAndReportsList;

    }

    @Override
    public Map<String, Object> getRecentReportsDetail(BaseReqDTO baseReqDTO) {

        Map<String, Object> reportsCountAndReportsList = new HashMap<>();
        int reportsTotalCount = jdbcTemplateTrn.queryForObject(
                        ReportsCommonSql.getRecentReportsTotalCount(mstDatabseName), Integer.class,
                        baseReqDTO.getEntityId());
        List<ReportDetailsResDTO> reportList = jdbcTemplateTrn.query(
                        ReportsCommonSql.getRecentReportsDetails(mstDatabseName),
                        new ResultSetExtractor<List<ReportDetailsResDTO>>() {

                            public List<ReportDetailsResDTO> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                List<ReportDetailsResDTO> pinnedReportsList = new ArrayList<>();
                                while (rs.next()) {
                                    ReportDetailsResDTO reportDetailsResDTO = new ReportDetailsResDTO();
                                    LocalDateTime accessAtDateTime = rs.getObject("access_at", LocalDateTime.class);
                                    String reportCode = rs.getString(ReportsConstants.REPORT_CODE);
                                    String isCustom = reportModuleCommonRepo.getCustomOrDefaultValue(reportCode);
                                    reportDetailsResDTO
                                                    .setId(checkNullValue(rs.getString(ReportsConstants.REPORT_CODE)));
                                    reportDetailsResDTO.setReportname(checkNullValue(rs.getString("name")));
                                    reportDetailsResDTO.setModuleName(checkNullValue(rs.getString("module_name")));
                                    reportDetailsResDTO.setReportDesc(checkNullValue(rs.getString("description")));
                                    reportDetailsResDTO.setCreatedOn(
                                                    DateUtil.convertLocalDateTimeIntoStringFormat(accessAtDateTime));
                                    reportDetailsResDTO.setCreatedBy(checkNullValue(rs.getString("access_by")));
                                    reportDetailsResDTO.setModuleId(checkNullValue(rs.getString("pld_module_id")));
                                    if (isCustom == null || isCustom.equals(ReportsConstants.DEFAULT)
                                                    || isCustom.equals("")) {
                                        reportDetailsResDTO
                                                        .setSubModuleId(checkNullValue(rs.getString("submodule_id")));
                                    } else {
                                        reportDetailsResDTO.setSubModuleId("");
                                    }
                                    pinnedReportsList.add(reportDetailsResDTO);
                                }
                                return pinnedReportsList;
                            }

                        }, baseReqDTO.getEntityId(), baseReqDTO.getSize());
        reportsCountAndReportsList.put(ReportsConstants.REPORTTOTALCOUNT, reportsTotalCount);
        reportsCountAndReportsList.put(ReportsConstants.REPORTSLIST, reportList);

        return reportsCountAndReportsList;
    }

    @Override
    public List<ReportsSubModuleResDTO> getReportsSubModuleList(ReportsSubModuleReqDTO reportsSubModuleReqDTO) {

        return jdbcTemplateTrn.query(ReportsCommonSql.getReportsSubmoduleList(mstDatabseName),
                        new ResultSetExtractor<List<ReportsSubModuleResDTO>>() {

                            public List<ReportsSubModuleResDTO> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                List<ReportsSubModuleResDTO> reportsSubModuleList = new ArrayList<>();
                                while (rs.next()) {
                                    ReportsSubModuleResDTO reportsSubModuleResDTO = new ReportsSubModuleResDTO();
                                    reportsSubModuleResDTO.setSubModuleId(
                                                    checkNullValue(rs.getString(ReportsConstants.REPORT_CODE)));
                                    reportsSubModuleResDTO.setSubModuleName(checkNullValue(rs.getString("name")));

                                    reportsSubModuleList.add(reportsSubModuleResDTO);
                                }
                                return reportsSubModuleList;
                            }

                        }, reportsSubModuleReqDTO.getModuleId());
    }

    @Override
    public List<SubModuleWiseReportsListResDTO> getSubModuleWiseReportList(
                    SubModuleWiseReportsListReqDTO subModuleWiseReportsListReqDTO) {
        int reportPerentId = 0;

        if (subModuleWiseReportsListReqDTO.getIsCustomReport().equals("0")) {
            reportPerentId = jdbcTemplateMst.queryForObject("select id from am_report_config where report_code=? ",
                            Integer.class, subModuleWiseReportsListReqDTO.getSubmoduleId());
        }

        return jdbcTemplateTrn.query(
                        ReportsCommonSql.getSubmodulewiseReportList(mstDatabseName, reportPerentId,
                                        subModuleWiseReportsListReqDTO.getIsCustomReport()),
                        new ResultSetExtractor<List<SubModuleWiseReportsListResDTO>>() {

                            public List<SubModuleWiseReportsListResDTO> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                List<SubModuleWiseReportsListResDTO> subModuleWiseReportsList = new ArrayList<>();
                                while (rs.next()) {
                                    SubModuleWiseReportsListResDTO subModuleWiseReportsListResDTO = new SubModuleWiseReportsListResDTO();
                                    subModuleWiseReportsListResDTO.setReportId(
                                                    checkNullValue(rs.getString(ReportsConstants.REPORT_CODE)));
                                    subModuleWiseReportsListResDTO.setReportName(checkNullValue(rs.getString("name")));

                                    subModuleWiseReportsList.add(subModuleWiseReportsListResDTO);
                                }
                                return subModuleWiseReportsList;
                            }

                        }, subModuleWiseReportsListReqDTO.getModuleId());
    }

    @Override
    public void setPinnedAndUnpinnedReports(PinnedAndUnpinnedReportsReqDTO pinnedAndUnpinnedReportsReq) {

        int reportId = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_PARENT_ID_OF_A_REPORT, Integer.class,
                        pinnedAndUnpinnedReportsReq.getReportId());
        int count = jdbcTemplateTrn.queryForObject(ReportsCommonSql.COUNT_OF_PINNED_AND_UNPINNED_REPORTS, Integer.class,
                        reportId, pinnedAndUnpinnedReportsReq.getUserId());
        String query = ReportsCommonSql.SET_PINNED_AND_UNPINNED_REPORTS;

        if (count > 0) {
            query = ReportsCommonSql.UPDATE_PINNED_AND_UNPINNED_REPORTS;
        }
        jdbcTemplateTrn.update(query, pinnedAndUnpinnedReportsReq.getStatus(), LocalDateTime.now(), reportId,
                        pinnedAndUnpinnedReportsReq.getUserId());

    }

    @Override
    @Synchronized
    public Map<String, Object> getSendInvitesViewReports(SendInvitesViewReportsReqDTO sendInvitesViewReportsReqDTO,
                    String taxpayergstinList, String vendorGstinList) {

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));
        key = reportModuleCommonRepo.getKeyFromKeyHolder();
        String isCustom = reportModuleCommonRepo.getCustomOrDefault(sendInvitesViewReportsReqDTO.getReportId());
        String actionType = "view";

        Map<String, Object> results = jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                cs = con.prepareCall(ReportsConstants.REPORT_MASTER_SEND_INVITES_LIST);
                cs.setLong(1, Integer.valueOf(sendInvitesViewReportsReqDTO.getGstinOrPan()));
                cs.setString(2, taxpayergstinList);
                cs.setString(3, vendorGstinList);
                cs.setString(4, mstDatabseName);
                cs.setString(5, sendInvitesViewReportsReqDTO.getReportId());
                cs.setString(6, isCustom);
                cs.setString(7, sendInvitesViewReportsReqDTO.getUserId());
                cs.setString(8, actionType);
                cs.setLong(9, sendInvitesViewReportsReqDTO.getSize());
                cs.setLong(10, (sendInvitesViewReportsReqDTO.getPage() * sendInvitesViewReportsReqDTO.getSize()));
                callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                return cs;
            }
        }, parameters);

        List<SendInvitesViewReportsResDTO> sendInvitesViewReportsResList = new ArrayList<>();
        if (!results.isEmpty()) {

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> dataList = (List<Map<String, Object>>) results.get(ReportsConstants.RESULT_SET_1);
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> countValue = (List<Map<String, Object>>) results
                            .get(ReportsConstants.RESULT_SET_2);
            Map<String, Object> count11 = countValue.get(0);
            long totalCount = (long) count11.get(ReportsConstants.TOTAL_COUNT);
            dataList.stream().forEach(dataObject -> {

                SendInvitesViewReportsResDTO dataRes = new SendInvitesViewReportsResDTO();
                dataRes.setCompanyLegalName(checkNullValue((String) dataObject.get("company_legal_name")));
                dataRes.setDateInviteSent(DateUtil.convertLocalDateTimeIntoStringFormat(
                                (LocalDateTime) dataObject.get("date_invite_sent")));
                dataRes.setGstinTaxpayer(checkNullValue((String) dataObject.get("gstin_taxpayer")));
                dataRes.setGstinVendor(checkNullValue((String) dataObject.get("gstin_vendor")));
                dataRes.setInviteSentByUser(checkNullValue((String) dataObject.get("invite_sent_by_user")));
                dataRes.setVendorCodeErp(checkNullValue((String) dataObject.get("vendor_code_erp")));
                dataRes.setVendorContactEmail(checkNullValue((String) dataObject.get("vendor_contact_email")));
                dataRes.setVendorContactName(checkNullValue((String) dataObject.get("vendor_contact_name")));
                dataRes.setVendorInviteStatus(checkNullValue((String) dataObject.get("vendor_invite_status")));
                sendInvitesViewReportsResList.add(dataRes);

            });
            Map<String, Object> sendInvitesViewReportsResult = new HashMap<>();
            sendInvitesViewReportsResult.put("page", sendInvitesViewReportsReqDTO.getPage() + 1);
            sendInvitesViewReportsResult.put("totalPageElements", totalCount);
            sendInvitesViewReportsResult.put("Data", sendInvitesViewReportsResList);
            return sendInvitesViewReportsResult;

        }
        return new HashMap<>();
    }

    @Override
    @Synchronized
    public Map<String, Object> getFilingViewReports(FilingVeiwReportsReqDTO filingVeiwReportsReqDTO,
                    String taxpayergstinList, String vendorGstinList) {

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));
        String actionType = "view";
        String customOrDefault = reportModuleCommonRepo.getCustomOrDefault(filingVeiwReportsReqDTO.getReportId());

        key = reportModuleCommonRepo.getKeyFromKeyHolder();

        Map<String, Object> results = jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                cs = con.prepareCall(ReportsConstants.REPORT_MASTER_GSTR_FILING_DETAILS);
                cs.setLong(1, Integer.valueOf(filingVeiwReportsReqDTO.getGstinOrPan()));
                cs.setString(2, taxpayergstinList);
                cs.setString(3, vendorGstinList);
                cs.setInt(4, filingVeiwReportsReqDTO.getYearId());
                cs.setString(5, filingVeiwReportsReqDTO.getGstinStatus().toString().replace("[", "").replace("]", "")
                                .replace("{", "").replace("}", "").replace(" ", ""));
                cs.setString(6, filingVeiwReportsReqDTO.getFilingtype().toString().replace("[", "").replace("]", "")
                                .replace("{", "").replace("}", "").replace(" ", ""));
                cs.setString(7, mstDatabseName);
                cs.setString(8, filingVeiwReportsReqDTO.getReportId());
                cs.setString(9, customOrDefault);
                cs.setString(10, filingVeiwReportsReqDTO.getUserId());
                cs.setString(11, actionType);
                cs.setLong(12, filingVeiwReportsReqDTO.getSize());
                cs.setLong(13, (filingVeiwReportsReqDTO.getPage() * filingVeiwReportsReqDTO.getSize()));
                callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                return cs;
            }
        }, parameters);

        List<FilingVeiwReportsResDTO> filingVeiwReportsResList = new ArrayList<>();

        if (filingVeiwReportsReqDTO.getYearId() == ReportsCommonSql.YEAR1718) {
            year = "2017";
            year1 = "2018";
        } else if (filingVeiwReportsReqDTO.getYearId() == ReportsCommonSql.YEAR1819) {
            year = "2018";
            year1 = "2019";
        } else if (filingVeiwReportsReqDTO.getYearId() == ReportsCommonSql.YEAR1920) {
            year = "2019";
            year1 = "2020";
        } else if (filingVeiwReportsReqDTO.getYearId() == ReportsCommonSql.YEAR2021) {
            year = "2020";
            year1 = "2021";
        } else if (filingVeiwReportsReqDTO.getYearId() == ReportsCommonSql.YEAR2122) {
            year = "2021";
            year1 = "2022";
        } else if (filingVeiwReportsReqDTO.getYearId() == ReportsCommonSql.YEAR2223) {
            year = "2022";
            year1 = "2023";
        } else if (filingVeiwReportsReqDTO.getYearId() == ReportsCommonSql.YEAR2324) {
            year = "2023";
            year1 = "2024";
        }

        if (!results.isEmpty()) {

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> dataList = (List<Map<String, Object>>) results.get(ReportsConstants.RESULT_SET_1);
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> countValue = (List<Map<String, Object>>) results
                            .get(ReportsConstants.RESULT_SET_2);
            Map<String, Object> count11 = countValue.get(0);
            long totalCount = (long) count11.get(ReportsConstants.TOTAL_COUNT);
            dataList.stream().forEach(dataObject -> {

                FilingVeiwReportsResDTO dataRes = new FilingVeiwReportsResDTO();
                dataRes.setGstinTaxpayer(checkNullValue((String) dataObject.get("gstin_taxpayer")));
                dataRes.setGstinVendor(checkNullValue((String) dataObject.get("gstin_vendor")));
                dataRes.setPldGstinStatus(checkNullValue((String) dataObject.get("pld_gstin_status")));
                dataRes.setReturnType(checkNullValue((String) dataObject.get("return_type")));
                dataRes.setInviteSentByUser(checkNullValue((String) dataObject.get("invite_sent_by_user")));
                dataRes.setApril(checkNullValue((String) dataObject.get("April " + year)));
                dataRes.setMay(checkNullValue((String) dataObject.get("May " + year)));
                dataRes.setJune(checkNullValue((String) dataObject.get("June " + year)));
                dataRes.setJuly(checkNullValue((String) dataObject.get("July " + year)));
                dataRes.setAugust(checkNullValue((String) dataObject.get("August " + year)));
                dataRes.setSeptember(checkNullValue((String) dataObject.get("September " + year)));
                dataRes.setOctober(checkNullValue((String) dataObject.get("October " + year)));
                dataRes.setNovember(checkNullValue((String) dataObject.get("November " + year)));
                dataRes.setDecember(checkNullValue((String) dataObject.get("December " + year)));
                dataRes.setJanuary(checkNullValue((String) dataObject.get("January " + year1)));
                dataRes.setFebruary(checkNullValue((String) dataObject.get("February " + year1)));
                dataRes.setMarch(checkNullValue((String) dataObject.get("March " + year1)));
                filingVeiwReportsResList.add(dataRes);

            });
            Map<String, Object> sendInvitesViewReportsResult = new HashMap<>();
            sendInvitesViewReportsResult.put("page", filingVeiwReportsReqDTO.getPage() + 1);
            sendInvitesViewReportsResult.put("totalPageElements", totalCount);
            sendInvitesViewReportsResult.put("Data", filingVeiwReportsResList);
            return sendInvitesViewReportsResult;

        }
        return new HashMap<>();

    }

    @Override
    public List<GetCustomizedColumnListResDTO> getCustomizedColumnListFromRepo(
                    GetReportsCustomizeColumnListReqDTO getSaveCustomizedColumnListReqDTO) {

        int count = jdbcTemplateTrn.queryForObject(ReportsCommonSql.getCustomizeColumnCount(), Integer.class,
                        getSaveCustomizedColumnListReqDTO.getUserId(), getSaveCustomizedColumnListReqDTO.getReportId());
        String isCustom = reportModuleCommonRepo
                        .getCustomOrDefaultValue(getSaveCustomizedColumnListReqDTO.getReportId());

        if (count > 0) {
            String sql = ReportsCommonSql.getSavedCustomizeColumnList(mstDatabseName);

            return jdbcTemplateTrn.query(sql, new ResultSetExtractor<List<GetCustomizedColumnListResDTO>>() {

                public List<GetCustomizedColumnListResDTO> extractData(ResultSet rs)
                                throws SQLException, DataAccessException {
                    List<GetCustomizedColumnListResDTO> getCustomizedColumnListResDTOList = new ArrayList<>();
                    while (rs.next()) {
                        GetCustomizedColumnListResDTO getCustomizedColumnListResDTO = new GetCustomizedColumnListResDTO();
                        getCustomizedColumnListResDTO.setColumnId(rs.getInt("column_id"));
                        getCustomizedColumnListResDTO.setName(checkNullValue(rs.getString("column_name")));
                        getCustomizedColumnListResDTO.setIsSelected(checkNullValue(rs.getString("is_Selected")));
                        getCustomizedColumnListResDTO.setIsMandatory(checkNullValue(rs.getString("is_mandatory")));
                        getCustomizedColumnListResDTO.setSortOrder(rs.getInt("sort_order"));
                        getCustomizedColumnListResDTOList.add(getCustomizedColumnListResDTO);
                    }
                    return getCustomizedColumnListResDTOList;
                }

            }, getSaveCustomizedColumnListReqDTO.getUserId(), getSaveCustomizedColumnListReqDTO.getReportId(),
                            getSaveCustomizedColumnListReqDTO.getSummaryType());
        } else {

            if (isCustom == null || isCustom.equals(ReportsConstants.DEFAULT) || isCustom.equals("")) {
                String sql = ReportsCommonSql.getDefaultCustomizeColumns();

                return jdbcTemplateMst.query(sql, new ResultSetExtractor<List<GetCustomizedColumnListResDTO>>() {

                    public List<GetCustomizedColumnListResDTO> extractData(ResultSet rs)
                                    throws SQLException, DataAccessException {
                        List<GetCustomizedColumnListResDTO> getCustomizedColumnListResDTOList = new ArrayList<>();
                        while (rs.next()) {
                            GetCustomizedColumnListResDTO getCustomizedColumnListResDTO = new GetCustomizedColumnListResDTO();
                            getCustomizedColumnListResDTO.setColumnId(rs.getInt("column_key"));
                            getCustomizedColumnListResDTO.setName(checkNullValue(rs.getString("column_name")));
                            getCustomizedColumnListResDTO.setIsSelected(checkNullValue(rs.getString("is_Selected")));
                            getCustomizedColumnListResDTO.setIsMandatory(checkNullValue(rs.getString("is_mandatory")));
                            getCustomizedColumnListResDTO.setSortOrder(rs.getInt("sort_order"));
                            getCustomizedColumnListResDTOList.add(getCustomizedColumnListResDTO);
                        }
                        return getCustomizedColumnListResDTOList;
                    }

                }, getSaveCustomizedColumnListReqDTO.getReportId(), getSaveCustomizedColumnListReqDTO.getSummaryType());

            } else {
                return jdbcTemplateMst.query(ReportsCommonSql.getCustomDefaultHeaders(),
                                new ResultSetExtractor<List<GetCustomizedColumnListResDTO>>() {

                                    public List<GetCustomizedColumnListResDTO> extractData(ResultSet rs)
                                                    throws SQLException, DataAccessException {
                                        List<GetCustomizedColumnListResDTO> getCustomizedColumnListResDTOList = new ArrayList<>();
                                        while (rs.next()) {
                                            GetCustomizedColumnListResDTO getCustomizedColumnListResDTO = new GetCustomizedColumnListResDTO();
                                            getCustomizedColumnListResDTO.setColumnId(rs.getInt("column_key"));
                                            getCustomizedColumnListResDTO
                                                            .setName(checkNullValue(rs.getString("column_name")));
                                            getCustomizedColumnListResDTO
                                                            .setIsSelected(checkNullValue(rs.getString("is_Selected")));
                                            getCustomizedColumnListResDTO.setIsMandatory(
                                                            checkNullValue(rs.getString("is_mandatory")));
                                            getCustomizedColumnListResDTO.setSortOrder(rs.getInt("sort_order"));
                                            getCustomizedColumnListResDTOList.add(getCustomizedColumnListResDTO);
                                        }
                                        return getCustomizedColumnListResDTOList;
                                    }

                                }, 0, getSaveCustomizedColumnListReqDTO.getCustomTemplateId(),
                                getSaveCustomizedColumnListReqDTO.getReportId(),
                                getSaveCustomizedColumnListReqDTO.getReportId(),
                                getSaveCustomizedColumnListReqDTO.getSummaryType());

            }

        }

    }

    @Override
    public void deleteThePreviousRecord(GetReportsSavedCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO) {
        String deleteQuery = ReportsCommonSql.deletePreviousRecords();
        jdbcTemplateTrn.update(deleteQuery, saveCustomizeColumnListReqDTO.getReportId(),
                        saveCustomizeColumnListReqDTO.getUserId());

    }

    @Override
    public void enterTheNewRecord(GetReportsSavedCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO) {
        List<UserCustomizeColumnDTO> userCustomizeColumnDTOList = new ArrayList<>();
        for (int size = 0; saveCustomizeColumnListReqDTO.getCustomizeColumnList().size() > size; size++) {
            UserCustomizeColumnDTO userCustomizeColumnDTO = new UserCustomizeColumnDTO();

            if (saveCustomizeColumnListReqDTO.getCustomizeColumnList().get(size)
                            .getIsSelected() == Constants.SELECTED) {
                userCustomizeColumnDTO.setUserId(saveCustomizeColumnListReqDTO.getUserId());
                userCustomizeColumnDTO.setColumnId(
                                saveCustomizeColumnListReqDTO.getCustomizeColumnList().get(size).getColumnId());
                userCustomizeColumnDTO.setSortOrder(
                                saveCustomizeColumnListReqDTO.getCustomizeColumnList().get(size).getSortOrder());
                userCustomizeColumnDTO.setReportsCode(saveCustomizeColumnListReqDTO.getReportId());
                userCustomizeColumnDTO.setCreatedat(LocalDateTime.now());
                userCustomizeColumnDTO.setCreatedBy(saveCustomizeColumnListReqDTO.getUserId());

                userCustomizeColumnDTOList.add(userCustomizeColumnDTO);
            }
        }
        insertMultipleColumnRecords(userCustomizeColumnDTOList);

    }

    public void insertMultipleColumnRecords(List<UserCustomizeColumnDTO> userCustomizeColumnDTOList) {
        String insertQuery = ReportsCommonSql.insertNewCustomizeColumnRecord();
        jdbcTemplateTrn.batchUpdate(insertQuery, new BatchPreparedStatementSetter() {

            @Override
            public void setValues(PreparedStatement pStmt, int j) throws SQLException {
                UserCustomizeColumnDTO userCustomizeColumnDTO = userCustomizeColumnDTOList.get(j);
                pStmt.setString(1, userCustomizeColumnDTO.getUserId());
                pStmt.setLong(2, userCustomizeColumnDTO.getColumnId());
                pStmt.setString(3, userCustomizeColumnDTO.getReportsCode());
                pStmt.setTimestamp(4, Timestamp.valueOf(userCustomizeColumnDTO.getCreatedat()));
                pStmt.setString(5, userCustomizeColumnDTO.getCreatedBy());
                pStmt.setLong(6, userCustomizeColumnDTO.getSortOrder());

            }

            @Override
            public int getBatchSize() {
                return userCustomizeColumnDTOList.size();
            }
        });
    }

    @Override
    public Map<String, Object> getBackgroundReportsData(BaseReqDTO requestDTO) {
        String fileUrl = reportModuleCommonRepo.getFileUrl();
        String containerName = reportModuleCommonRepo.getContainerName(requestDTO.getEntityId());

        Map<String, Object> backgroundReportsCountAndData = new HashMap<>();

        int totalCount = jdbcTemplateTrn.queryForObject(ReportsCommonSql.getBackgroudReportsTotalCount(mstDatabseName),
                        Integer.class, requestDTO.getEntityId());

        List<GetBackGroundReportsDetailResDTO> backGroundReportsdata = jdbcTemplateTrn.query(
                        ReportsCommonSql.getBackgroudReportsDataQuery(mstDatabseName),
                        new ResultSetExtractor<List<GetBackGroundReportsDetailResDTO>>() {

                            public List<GetBackGroundReportsDetailResDTO> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                List<GetBackGroundReportsDetailResDTO> getCustomizedColumnListResDTOList = new ArrayList<>();
                                while (rs.next()) {
                                    GetBackGroundReportsDetailResDTO getCustomizedColumnListResDTO = new GetBackGroundReportsDetailResDTO();
                                    getCustomizedColumnListResDTO
                                                    .setFilePath(checkNullValue(rs.getString("file_path")));
                                    getCustomizedColumnListResDTO
                                                    .setReportName(checkNullValue(rs.getString("file_name")));
                                    getCustomizedColumnListResDTO
                                                    .setModuleName(checkNullValue(rs.getString("module_name")));
                                    getCustomizedColumnListResDTO.setStatus(checkNullValue(rs.getString("status")));
                                    getCustomizedColumnListResDTO
                                                    .setCreatedBy(checkNullValue(rs.getString("requested_by")));
                                    getCustomizedColumnListResDTO
                                                    .setCreatedOn(DateUtil.convertTimestampIntoStringFormat(
                                                                    rs.getObject("requested_at", Timestamp.class)));
                                    getCustomizedColumnListResDTO.setFileUrl(fileUrl + "/" + containerName);
                                    getCustomizedColumnListResDTOList.add(getCustomizedColumnListResDTO);
                                }
                                return getCustomizedColumnListResDTOList;
                            }

                        }, requestDTO.getEntityId(), requestDTO.getSize());

        backgroundReportsCountAndData.put("BackGroundReportsdataList", backGroundReportsdata);
        backgroundReportsCountAndData.put("BackGroundReportsCount", totalCount);

        return backgroundReportsCountAndData;
    }

    @Override
    public Map<String, Object> getDownloadReportsVendorMasterNew(Timestamp timeStamp, String fileName,
                    String containerName, String entityId, ReportsVendorMasterReqDTO reportsVendorMasterReq,
                    String taxpayergstinList, String vendorGstinList) throws IOException, BDOException {

        AzureConnectionCredentialsDTO storageCredentials = reportModuleCommonRepo.getAzureCredentialFromDB(entityId,
                        "blob");
        String fileUrl = reportModuleCommonRepo.getFileUrl();

        int templateTypeId = 6;
        String actionType = ReportsConstants.EXPORT;
        String isCustom = reportModuleCommonRepo.getCustomOrDefault(reportsVendorMasterReq.getReportId());
        key = reportModuleCommonRepo.getKeyFromKeyHolder();

        return jdbcTemplateTrn.execute(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                Long pageSize = (long) (reportsVendorMasterReq.getSize() * reportsVendorMasterReq.getPage());

                cs = null;

                if (ReportsConstants.CUSTOM_VENDOR_MASTER_AS_PER_VENDOR_ERROR_REPORT
                                .equals(reportsVendorMasterReq.getReportId())
                                || ReportsConstants.CUSTOM_VENDOR_MASTER_COMBINED_ERROR_REPORT
                                                .equals(reportsVendorMasterReq.getReportId())
                                || ReportsConstants.CUSTOM_VENDOR_MASTER_TAXPAYER_ERROR_REPORT
                                                .equals(reportsVendorMasterReq.getReportId())) {

                    cs = con.prepareCall(ReportsConstants.REPORT_MASTER_TP_VENDOR_GSTIN_COMBINED_ERROR);
                } else {
                    cs = con.prepareCall(ReportsConstants.REPORT_MASTER_TP_VENDOR_GSTIN_COMBINED);
                }
                cs.setLong(1, Integer.valueOf(reportsVendorMasterReq.getGstinOrPan()));
                cs.setString(2, taxpayergstinList);
                cs.setString(3, vendorGstinList);
                cs.setString(4, reportsVendorMasterReq.getReportId());
                cs.setString(5, mstDatabseName);
                cs.setString(6, isCustom);
                cs.setInt(7, templateTypeId);
                cs.setInt(8, reportsVendorMasterReq.getCustomTemplateId());
                cs.setString(9, reportsVendorMasterReq.getUserId());
                cs.setString(10, actionType);
                cs.setLong(11, reportsVendorMasterReq.getSize());
                cs.setLong(12, pageSize);
                callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                return cs;

            }
        }, new CallableStatementCallback<Map<String, Object>>() {

            @Override
            public Map<String, Object> doInCallableStatement(CallableStatement cs) throws SQLException {
                // Execute the stored procedure call
                boolean hasResults = cs.execute();
                ResultSet rs = null;
                ResultSet rs1 = null;
                Map<String, Object> nameAndFile = new HashMap<>();

                if (reportsVendorMasterReq.getDownloadType() == null) {
                    reportsVendorMasterReq.setDownloadType("xlsx");
                }

                if (hasResults) {

                    rs1 = cs.getResultSet();
                    List<String> reportDetails = new ArrayList<>();

                    while (rs1.next()) {
                        String detail1 = rs1.getString(1);
                        reportDetails.add(detail1);

                    }
                    hasResults = cs.getMoreResults();

                    if (ReportsConstants.EXCEL.equals(reportsVendorMasterReq.getDownloadType())) {

                        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
                            // Create Excel workbook and sheet
                            if (ReportsConstants.CUSTOM_VENDOR_MASTER_COMBINED_REGISTER_REPORT
                                            .equals(reportsVendorMasterReq.getReportId())
                                            || ReportsConstants.VENDOR_MASTER_COMBINED_REGISTER_REPORT
                                                            .equals(reportsVendorMasterReq.getReportId())) {
                                List<String> sheetNames = Arrays.asList("Masters", "Contact", "Address", "Bank Details",
                                                "Filing");
                                int sheetIndex = 0;
                                while (hasResults) {
                                    rs = cs.getResultSet();

                                    // Get the metadata for the result set
                                    ResultSetMetaData metadata = rs.getMetaData();
                                    int columnCount = metadata.getColumnCount();

                                    // Create sheet for each result set
                                    XSSFSheet sheet = workbook.createSheet(sheetNames.get(sheetIndex));
                                    reportModuleCommonRepo.setFilterAndFredgeHeader(sheet,
                                                    new CellRangeAddress(4, 4, 0, columnCount - 1));
                                    sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, columnCount - 1));
                                    sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, reportDetails.size() - 1));
                                    Map<String, Object> bothHeadersStyles = reportModuleCommonRepo
                                                    .getHeadersStyles(workbook, sheet);
                                    CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles
                                                    .get(ReportsConstants.HEADERCELLSTYLE1);
                                    CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles
                                                    .get(ReportsConstants.HEADERCELLSTYLE2);
                                    CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles
                                                    .get(ReportsConstants.HEADERCELLSTYLE3);

                                    Row topheader = sheet.createRow(3);
                                    Cell cell1 = topheader.createCell(0);
                                    cell1.setCellValue(fileName);
                                    cell1.setCellStyle(headerCellStyle1);

                                    // Create header row
                                    Row headerRow = sheet.createRow(4);
                                    for (int i = 1; i <= columnCount; i++) {
                                        String columnName = metadata.getColumnLabel(i);
                                        Cell cell = headerRow.createCell(i - 1);
                                        cell.setCellValue(columnName);
                                        cell.setCellStyle(headerCellStyle2);
                                    }

                                    // Process and write rows
                                    int rowNum = 5;
                                    while (rs.next()) {
                                        Row row = sheet.createRow(rowNum);
                                        for (int i = 1; i <= columnCount; i++) {
                                            String cellValue = rs.getString(i);
                                            Cell cell = row.createCell(i - 1);
                                            cell.setCellValue(cellValue);
                                            cell.setCellStyle(headerCellStyle3);
                                        }
                                        rowNum++;
                                    }
                                    for (int i = 0; i <= columnCount; i++) {
                                        sheet.autoSizeColumn(i);
                                    }

                                    Row searchParameter = sheet.createRow(0);
                                    Cell searchParametercell = searchParameter.createCell(0);
                                    searchParametercell.setCellValue(greeting);
                                    searchParametercell.setCellStyle(headerCellStyle2);
                                    Row deatails = sheet.createRow(1);
                                    for (int i = 0; i < reportDetails.size(); i++) {

                                        Cell cell = deatails.createCell(i);
                                        cell.setCellValue(reportDetails.get(i));
                                        cell.setCellStyle(headerCellStyle3);

                                    }

                                    hasResults = cs.getMoreResults();
                                    sheetIndex++;
                                }
                            } else {
                                rs = cs.getResultSet();

                                // Get the metadata for the result set
                                ResultSetMetaData metadata = rs.getMetaData();
                                int columnCount = metadata.getColumnCount();

                                XSSFSheet sheet = workbook.createSheet(fileName);
                                reportModuleCommonRepo.setFilterAndFredgeHeader(sheet,
                                                new CellRangeAddress(4, 4, 0, columnCount - 1));
                                sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, columnCount - 1));
                                sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, reportDetails.size() - 1));
                                Map<String, Object> bothHeadersStyles = reportModuleCommonRepo
                                                .getHeadersStyles(workbook, sheet);
                                CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles
                                                .get(ReportsConstants.HEADERCELLSTYLE1);
                                CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles
                                                .get(ReportsConstants.HEADERCELLSTYLE2);
                                CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles
                                                .get(ReportsConstants.HEADERCELLSTYLE3);

                                Row topheader = sheet.createRow(3);
                                Cell cell1 = topheader.createCell(0);
                                cell1.setCellValue(fileName);
                                cell1.setCellStyle(headerCellStyle1);

                                // Create header row
                                Row headerRow = sheet.createRow(4);
                                for (int i = 1; i <= columnCount; i++) {
                                    String columnName = metadata.getColumnLabel(i);
                                    Cell cell = headerRow.createCell(i - 1);
                                    cell.setCellValue(columnName);
                                    cell.setCellStyle(headerCellStyle2);
                                }

                                // Process and write rows
                                int rowNum = 5;
                                while (rs.next()) {
                                    Row row = sheet.createRow(rowNum);
                                    for (int i = 1; i <= columnCount; i++) {
                                        String cellValue = rs.getString(i);
                                        Cell cell = row.createCell(i - 1);
                                        cell.setCellValue(cellValue);
                                        cell.setCellStyle(headerCellStyle3);
                                    }
                                    rowNum++;
                                }
                                for (int i = 0; i <= columnCount; i++) {
                                    sheet.autoSizeColumn(i);
                                }

                                Row searchParameter = sheet.createRow(0);
                                Cell searchParametercell = searchParameter.createCell(0);
                                searchParametercell.setCellValue(greeting);
                                searchParametercell.setCellStyle(headerCellStyle2);
                                Row deatails = sheet.createRow(1);
                                for (int i = 0; i < reportDetails.size(); i++) {

                                    Cell cell = deatails.createCell(i);
                                    cell.setCellValue(reportDetails.get(i));
                                    cell.setCellStyle(headerCellStyle3);

                                }
                            }

                            // Write workbook to file
                            try (FileOutputStream out = new FileOutputStream(new File(tempFolder
                                            + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp)))) {
                                workbook.write(out);

                                File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                                + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp));

                                try (InputStream fis = new FileInputStream(file)) {
                                    client.getClient(storageCredentials)
                                                    .blobName(reportModuleCommonRepo.getReportsExcelFileName(fileName,
                                                                    timeStamp))
                                                    .buildClient().upload(fis, file.length());
                                    nameAndFile.put(ReportsConstants.FILENAME, reportModuleCommonRepo
                                                    .getReportsExcelFileName(fileName, timeStamp));
                                    nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                    reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                    return nameAndFile;
                                }

                            }
                        } catch (IOException e) {
                            log.error(errorInGeneratingExcelWorkbook, e);

                        }
                    } else {
                        rs = cs.getResultSet();

                        // Get the metadata for the result set
                        ResultSetMetaData metadata = rs.getMetaData();
                        int columnCount = metadata.getColumnCount();

                        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        try (CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format)) {

                            csvPrinter.printRecord(greeting);
                            csvPrinter.printRecord(reportDetails.toArray());
                            csvPrinter.printRecord();
                            // Create header row
                            String[] headerRow = new String[columnCount];
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                headerRow[i - 1] = columnName;
                            }
                            csvPrinter.printRecord((Object[]) headerRow);

                            while (rs.next()) {
                                String[] rowData = new String[columnCount];
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    rowData[i - 1] = cellValue;
                                }
                                csvPrinter.printRecord((Object[]) rowData);
                            }

                            csvPrinter.flush();

                            InputStream inputStream = new ByteArrayInputStream(out.toByteArray());

                            Files.copy(inputStream, Paths.get(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp)));

                            File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));

                            try (InputStream fis = new FileInputStream(file)) {
                                client.getClient(storageCredentials).blobName(
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp))
                                                .buildClient().upload(fis, file.length());
                                nameAndFile.put(ReportsConstants.FILENAME,
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));
                                nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                return nameAndFile;
                            }
                        } catch (IOException e1) {
                            log.error(errorInGeneratingCSVFile, e1);

                        }
                    }
                }

                return nameAndFile;
            }
        });

    }

    @Override
    public void generateBackGroundReportsVendorMaster(Timestamp currentTimeStamp, String fileName, String containerName,
                    String entityId, ReportsVendorMasterReqDTO generateBackgroundReports, String taxpayergstinList,
                    String vendorGstinList, BigInteger id) {

        AzureConnectionCredentialsDTO storageCredentials = reportModuleCommonRepo.getAzureCredentialFromDB(entityId,
                        "blob");

        int templateTypeId = 6;
        String actionType = ReportsConstants.EXPORT;
        String isCustom = reportModuleCommonRepo.getCustomOrDefault(generateBackgroundReports.getReportId());
        key = reportModuleCommonRepo.getKeyFromKeyHolder();

        jdbcTemplateTrn.execute(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {

                if (ReportsConstants.CUSTOM_VENDOR_MASTER_AS_PER_VENDOR_ERROR_REPORT
                                .equals(generateBackgroundReports.getReportId())
                                || ReportsConstants.CUSTOM_VENDOR_MASTER_COMBINED_ERROR_REPORT
                                                .equals(generateBackgroundReports.getReportId())
                                || ReportsConstants.CUSTOM_VENDOR_MASTER_TAXPAYER_ERROR_REPORT
                                                .equals(generateBackgroundReports.getReportId())) {

                    cs = con.prepareCall(ReportsConstants.REPORT_MASTER_TP_VENDOR_GSTIN_COMBINED_ERROR);
                } else {
                    cs = con.prepareCall(ReportsConstants.REPORT_MASTER_TP_VENDOR_GSTIN_COMBINED);
                }

                cs.setLong(1, Integer.valueOf(generateBackgroundReports.getGstinOrPan()));
                cs.setString(2, taxpayergstinList);
                cs.setString(3, vendorGstinList);
                cs.setString(4, generateBackgroundReports.getReportId());
                cs.setString(5, mstDatabseName);
                cs.setString(6, isCustom);
                cs.setInt(7, templateTypeId);
                cs.setInt(8, generateBackgroundReports.getCustomTemplateId());
                cs.setString(9, generateBackgroundReports.getUserId());
                cs.setString(10, actionType);
                cs.setLong(11, generateBackgroundReports.getSize());
                cs.setLong(12, generateBackgroundReports.getPage());
                callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                return cs;

            }
        }, new CallableStatementCallback<Map<String, Object>>() {

            @Override
            public Map<String, Object> doInCallableStatement(CallableStatement cs) throws SQLException {
                // Execute the stored procedure call
                boolean hasResults = cs.execute();
                ResultSet rs = null;
                ResultSet rs1 = null;
                Map<String, Object> nameAndFile = new HashMap<>();

                if (generateBackgroundReports.getDownloadType() == null) {
                    generateBackgroundReports.setDownloadType("xlsx");
                }

                if (hasResults) {

                    rs1 = cs.getResultSet();
                    List<String> reportDetails = new ArrayList<>();

                    while (rs1.next()) {
                        String detail1 = rs1.getString(1);
                        reportDetails.add(detail1);

                    }
                    hasResults = cs.getMoreResults();

                    try (XSSFWorkbook workbook = new XSSFWorkbook()) {

                        int columnCount = 0;
                        // Create Excel workbook and sheet
                        if (ReportsConstants.CUSTOM_VENDOR_MASTER_COMBINED_REGISTER_REPORT
                                        .equals(generateBackgroundReports.getReportId())
                                        || ReportsConstants.VENDOR_MASTER_COMBINED_REGISTER_REPORT
                                                        .equals(generateBackgroundReports.getReportId())) {
                            List<String> sheetNames = Arrays.asList("Masters", "Contact", "Address", "Bank Details",
                                            "Filing");
                            int sheetIndex = 0;
                            while (hasResults) {
                                rs = cs.getResultSet();

                                // Get the metadata for the result set
                                ResultSetMetaData metadata = rs.getMetaData();
                                columnCount = metadata.getColumnCount();

                                // Create sheet for each result set
                                XSSFSheet sheet = workbook.createSheet(sheetNames.get(sheetIndex));
                                reportModuleCommonRepo.setFilterAndFredgeHeader(sheet,
                                                new CellRangeAddress(4, 4, 0, columnCount - 1));
                                sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, columnCount - 1));
                                sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, reportDetails.size() - 1));
                                Map<String, Object> bothHeadersStyles = reportModuleCommonRepo
                                                .getHeadersStyles(workbook, sheet);
                                CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles
                                                .get(ReportsConstants.HEADERCELLSTYLE1);
                                CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles
                                                .get(ReportsConstants.HEADERCELLSTYLE2);
                                CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles
                                                .get(ReportsConstants.HEADERCELLSTYLE3);

                                Row topheader = sheet.createRow(3);
                                Cell cell1 = topheader.createCell(0);
                                cell1.setCellValue(fileName);
                                cell1.setCellStyle(headerCellStyle1);

                                // Create header row
                                Row headerRow = sheet.createRow(4);
                                for (int i = 1; i <= columnCount; i++) {
                                    String columnName = metadata.getColumnLabel(i);
                                    Cell cell = headerRow.createCell(i - 1);
                                    cell.setCellValue(columnName);
                                    cell.setCellStyle(headerCellStyle2);
                                }

                                // Process and write rows
                                int rowNum = 5;
                                while (rs.next()) {
                                    Row row = sheet.createRow(rowNum);
                                    for (int i = 1; i <= columnCount; i++) {
                                        String cellValue = rs.getString(i);
                                        Cell cell = row.createCell(i - 1);
                                        cell.setCellValue(cellValue);
                                        cell.setCellStyle(headerCellStyle3);
                                    }
                                    rowNum++;
                                }
                                for (int i = 0; i <= columnCount; i++) {
                                    sheet.autoSizeColumn(i);
                                }

                                Row searchParameter = sheet.createRow(0);
                                Cell searchParametercell = searchParameter.createCell(0);
                                searchParametercell.setCellValue(greeting);
                                searchParametercell.setCellStyle(headerCellStyle2);
                                Row deatails = sheet.createRow(1);
                                for (int i = 0; i < reportDetails.size(); i++) {

                                    Cell cell = deatails.createCell(i);
                                    cell.setCellValue(reportDetails.get(i));
                                    cell.setCellStyle(headerCellStyle3);

                                }

                                hasResults = cs.getMoreResults();
                                sheetIndex++;
                            }
                        } else {
                            rs = cs.getResultSet();

                            // Get the metadata for the result set
                            ResultSetMetaData metadata = rs.getMetaData();
                            columnCount = metadata.getColumnCount();

                            XSSFSheet sheet = workbook.createSheet(fileName);
                            reportModuleCommonRepo.setFilterAndFredgeHeader(sheet,
                                            new CellRangeAddress(4, 4, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, reportDetails.size() - 1));
                            Map<String, Object> bothHeadersStyles = reportModuleCommonRepo.getHeadersStyles(workbook,
                                            sheet);
                            CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE1);
                            CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE2);
                            CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE3);

                            Row topheader = sheet.createRow(3);
                            Cell cell1 = topheader.createCell(0);
                            cell1.setCellValue(fileName);
                            cell1.setCellStyle(headerCellStyle1);

                            // Create header row
                            Row headerRow = sheet.createRow(4);
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                Cell cell = headerRow.createCell(i - 1);
                                cell.setCellValue(columnName);
                                cell.setCellStyle(headerCellStyle2);
                            }

                            // Process and write rows
                            int rowNum = 5;
                            while (rs.next()) {
                                Row row = sheet.createRow(rowNum);
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    Cell cell = row.createCell(i - 1);
                                    cell.setCellValue(cellValue);
                                    cell.setCellStyle(headerCellStyle3);
                                }
                                rowNum++;
                            }
                            for (int i = 0; i <= columnCount; i++) {
                                sheet.autoSizeColumn(i);
                            }

                            Row searchParameter = sheet.createRow(0);
                            Cell searchParametercell = searchParameter.createCell(0);
                            searchParametercell.setCellValue(greeting);
                            searchParametercell.setCellStyle(headerCellStyle2);
                            Row deatails = sheet.createRow(1);
                            for (int i = 0; i < reportDetails.size(); i++) {

                                Cell cell = deatails.createCell(i);
                                cell.setCellValue(reportDetails.get(i));
                                cell.setCellStyle(headerCellStyle3);

                            }

                        }

                        // Write workbook to file
                        try (FileOutputStream out = new FileOutputStream(new File(tempFolder
                                        + System.getProperty(Constants.FILESEPERATOR) + reportModuleCommonRepo
                                                        .getReportsExcelFileName(fileName, currentTimeStamp)))) {
                            workbook.write(out);

                            File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsExcelFileName(fileName,
                                                            currentTimeStamp));

                            try (InputStream fis = new FileInputStream(file)) {
                                client.getClient(storageCredentials)
                                                .blobName(reportModuleCommonRepo.getReportsExcelFileName(fileName,
                                                                currentTimeStamp))
                                                .buildClient().upload(fis, file.length());

                                reportModuleCommonRepo.updateBackGroundDetails(
                                                reportModuleCommonRepo.getReportsExcelFileName(fileName,
                                                                currentTimeStamp),
                                                (long) columnCount, ReportsConstants.COMPLETED, fileName,
                                                generateBackgroundReports.getUserId(), currentTimeStamp, id);
                                reportModuleCommonRepo.insertDetailsIntoMailBox1(generateBackgroundReports.getUserId(),
                                                fileName, currentTimeStamp);
                                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);

                            }

                        }
                    } catch (IOException e) {

                        log.error(errorInGeneratingExcelWorkbook, e);

                    }

                }
                return nameAndFile;
            }
        });

    }

    @Override
    public Map<String, Object> getGenerateExcelOrCsvOfxVendorMasterSendInviteReport(
                    ReportsVendorMasterReqDTO reportsVendorMasterReq, String taxpayergstinList, String vendorGstinList,
                    Timestamp timeStamp, String fileName, String containerName) {

        AzureConnectionCredentialsDTO storageCredentials = reportModuleCommonRepo
                        .getAzureCredentialFromDB(reportsVendorMasterReq.getEntityId(), "blob");

        String fileUrl = reportModuleCommonRepo.getFileUrl();

        String actionType = ReportsConstants.EXPORT;
        String customOrDefault = reportModuleCommonRepo.getCustomOrDefault(reportsVendorMasterReq.getReportId());
        key = reportModuleCommonRepo.getKeyFromKeyHolder();
        Long totalCount = (long) reportsVendorMasterReq.getSize() * reportsVendorMasterReq.getPage();

        return jdbcTemplateTrn.execute(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {

                cs = con.prepareCall(ReportsConstants.REPORT_MASTER_SEND_INVITES_LIST);
                cs.setLong(1, Integer.valueOf(reportsVendorMasterReq.getGstinOrPan()));
                cs.setString(2, taxpayergstinList);
                cs.setString(3, vendorGstinList);
                cs.setString(4, mstDatabseName);
                cs.setString(5, reportsVendorMasterReq.getReportId());
                cs.setString(6, customOrDefault);
                cs.setString(7, reportsVendorMasterReq.getUserId());
                cs.setString(8, actionType);
                cs.setLong(9, reportsVendorMasterReq.getSize());
                cs.setLong(10, totalCount);
                callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                return cs;
            }

        }, new CallableStatementCallback<Map<String, Object>>() {

            @Override
            public Map<String, Object> doInCallableStatement(CallableStatement cs) throws SQLException {
                // Execute the stored procedure call
                boolean hasResults = cs.execute();
                ResultSet rs = null;
                ResultSet rs1 = null;
                Map<String, Object> nameAndFile = new HashMap<>();

                if (reportsVendorMasterReq.getDownloadType().isBlank()) {
                    reportsVendorMasterReq.setDownloadType("xlsx");
                }

                if (hasResults) {

                    rs1 = cs.getResultSet();
                    List<String> reportDetails = new ArrayList<>();

                    while (rs1.next()) {
                        String detail1 = rs1.getString(1);
                        reportDetails.add(detail1);

                    }
                    hasResults = cs.getMoreResults();

                    if (ReportsConstants.EXCEL.equals(reportsVendorMasterReq.getDownloadType())) {
                        try (XSSFWorkbook workbook = new XSSFWorkbook()) {

                            rs = cs.getResultSet();

                            // Get the metadata for the result set
                            ResultSetMetaData metadata = rs.getMetaData();
                            int columnCount = metadata.getColumnCount();

                            XSSFSheet sheet = workbook.createSheet(fileName);
                            reportModuleCommonRepo.setFilterAndFredgeHeader(sheet,
                                            new CellRangeAddress(4, 4, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, reportDetails.size() - 1));
                            Map<String, Object> bothHeadersStyles = reportModuleCommonRepo.getHeadersStyles(workbook,
                                            sheet);
                            CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE1);
                            CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE2);
                            CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE3);

                            Row topheader = sheet.createRow(3);
                            Cell cell1 = topheader.createCell(0);
                            cell1.setCellValue(fileName);
                            cell1.setCellStyle(headerCellStyle1);

                            // Create header row
                            Row headerRow = sheet.createRow(4);
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                Cell cell = headerRow.createCell(i - 1);
                                cell.setCellValue(columnName);
                                cell.setCellStyle(headerCellStyle2);
                            }

                            // Process and write rows
                            int rowNum = 5;
                            while (rs.next()) {
                                Row row = sheet.createRow(rowNum);
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    Cell cell = row.createCell(i - 1);
                                    cell.setCellValue(cellValue);
                                    cell.setCellStyle(headerCellStyle3);
                                }
                                rowNum++;
                            }
                            for (int i = 0; i <= columnCount; i++) {
                                sheet.autoSizeColumn(i);
                            }

                            Row searchParameter = sheet.createRow(0);
                            Cell searchParametercell = searchParameter.createCell(0);
                            searchParametercell.setCellValue(greeting);
                            searchParametercell.setCellStyle(headerCellStyle2);
                            Row deatails = sheet.createRow(1);
                            for (int i = 0; i < reportDetails.size(); i++) {

                                Cell cell = deatails.createCell(i);
                                cell.setCellValue(reportDetails.get(i));
                                cell.setCellStyle(headerCellStyle3);

                            }

                            // Write workbook to file
                            try (FileOutputStream out = new FileOutputStream(new File(tempFolder
                                            + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp)))) {
                                workbook.write(out);

                                File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                                + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp));

                                try (InputStream fis = new FileInputStream(file)) {
                                    client.getClient(storageCredentials)
                                                    .blobName(reportModuleCommonRepo.getReportsExcelFileName(fileName,
                                                                    timeStamp))
                                                    .buildClient().upload(fis, file.length());
                                    nameAndFile.put(ReportsConstants.FILENAME, reportModuleCommonRepo
                                                    .getReportsExcelFileName(fileName, timeStamp));
                                    nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                    reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                    return nameAndFile;
                                }

                            }
                        } catch (IOException e) {
                            log.error(errorInGeneratingExcelWorkbook, e);
                        }
                    } else {
                        rs = cs.getResultSet();

                        // Get the metadata for the result set
                        ResultSetMetaData metadata = rs.getMetaData();
                        int columnCount = metadata.getColumnCount();

                        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        try (CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format)) {
                            csvPrinter.printRecord(greeting);
                            csvPrinter.printRecord(reportDetails.toArray());
                            csvPrinter.printRecord();

                            // Create header row
                            String[] headerRow = new String[columnCount];
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                headerRow[i - 1] = columnName;
                            }
                            csvPrinter.printRecord((Object[]) headerRow);

                            while (rs.next()) {
                                String[] rowData = new String[columnCount];
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    rowData[i - 1] = cellValue;
                                }
                                csvPrinter.printRecord((Object[]) rowData);
                            }

                            csvPrinter.flush();

                            InputStream inputStream = new ByteArrayInputStream(out.toByteArray());

                            Files.copy(inputStream, Paths.get(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp)));

                            File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));

                            try (InputStream fis = new FileInputStream(file)) {
                                client.getClient(storageCredentials).blobName(
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp))
                                                .buildClient().upload(fis, file.length());
                                nameAndFile.put(ReportsConstants.FILENAME,
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));
                                nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                return nameAndFile;
                            }
                        } catch (IOException e1) {
                            log.error(errorInGeneratingCSVFile, e1);

                        }
                    }
                }
                return nameAndFile;
            }
        });

    }

    @Override
    public Map<String, Object> getGenerateExcelOrCsvOfxVendorMasterFillingDetailsReport(
                    ReportsVendorMasterReqDTO reportsVendorMasterReq, String taxpayergstinList, String vendorGstinList,
                    Timestamp timeStamp, String fileName, String containerName) {
        AzureConnectionCredentialsDTO storageCredentials = reportModuleCommonRepo
                        .getAzureCredentialFromDB(reportsVendorMasterReq.getEntityId(), "blob");

        String fileUrl = reportModuleCommonRepo.getFileUrl();

        String actionType = ReportsConstants.EXPORT;
        String customOrDefault = reportModuleCommonRepo.getCustomOrDefault(reportsVendorMasterReq.getReportId());
        key = reportModuleCommonRepo.getKeyFromKeyHolder();
        Long totalCount = (long) reportsVendorMasterReq.getSize() * reportsVendorMasterReq.getPage();

        return jdbcTemplateTrn.execute(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {

                cs = con.prepareCall(ReportsConstants.REPORT_MASTER_GSTR_FILING_DETAILS);
                cs.setLong(1, Integer.valueOf(reportsVendorMasterReq.getGstinOrPan()));
                cs.setString(2, taxpayergstinList);
                cs.setString(3, vendorGstinList);
                cs.setInt(4, reportsVendorMasterReq.getYearId());
                cs.setString(5, reportsVendorMasterReq.getGstinStatus().toString().replace("[", "").replace("]", "")
                                .replace("{", "").replace("}", "").replace(" ", ""));
                cs.setString(6, reportsVendorMasterReq.getFilingtype().toString().replace("[", "").replace("]", "")
                                .replace("{", "").replace("}", "").replace(" ", ""));
                cs.setString(7, mstDatabseName);
                cs.setString(8, reportsVendorMasterReq.getReportId());
                cs.setString(9, customOrDefault);
                cs.setString(10, reportsVendorMasterReq.getUserId());
                cs.setString(11, actionType);
                cs.setLong(12, reportsVendorMasterReq.getSize());
                cs.setLong(13, totalCount);

                callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                return cs;
            }

        }, new CallableStatementCallback<Map<String, Object>>() {

            @Override
            public Map<String, Object> doInCallableStatement(CallableStatement cs) throws SQLException {
                // Execute the stored procedure call
                boolean hasResults = cs.execute();
                ResultSet rs = null;
                ResultSet rs1 = null;
                Map<String, Object> nameAndFile = new HashMap<>();

                if (reportsVendorMasterReq.getDownloadType().isBlank()) {
                    reportsVendorMasterReq.setDownloadType("xlsx");
                }

                if (hasResults) {

                    rs1 = cs.getResultSet();
                    List<String> reportDetails = new ArrayList<>();

                    while (rs1.next()) {
                        String detail1 = rs1.getString(1);
                        reportDetails.add(detail1);

                    }
                    hasResults = cs.getMoreResults();

                    if (ReportsConstants.EXCEL.equals(reportsVendorMasterReq.getDownloadType())) {
                        try (XSSFWorkbook workbook = new XSSFWorkbook()) {

                            rs = cs.getResultSet();

                            // Get the metadata for the result set
                            ResultSetMetaData metadata = rs.getMetaData();
                            int columnCount = metadata.getColumnCount();

                            XSSFSheet sheet = workbook.createSheet(fileName);
                            reportModuleCommonRepo.setFilterAndFredgeHeader(sheet,
                                            new CellRangeAddress(4, 4, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, reportDetails.size() - 1));
                            Map<String, Object> bothHeadersStyles = reportModuleCommonRepo.getHeadersStyles(workbook,
                                            sheet);
                            CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE1);
                            CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE2);
                            CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE3);

                            Row topheader = sheet.createRow(3);
                            Cell cell1 = topheader.createCell(0);
                            cell1.setCellValue(fileName);
                            cell1.setCellStyle(headerCellStyle1);

                            // Create header row
                            Row headerRow = sheet.createRow(4);
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                Cell cell = headerRow.createCell(i - 1);
                                cell.setCellValue(columnName);
                                cell.setCellStyle(headerCellStyle2);
                            }

                            // Process and write rows
                            int rowNum = 5;
                            while (rs.next()) {
                                Row row = sheet.createRow(rowNum);
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    Cell cell = row.createCell(i - 1);
                                    cell.setCellValue(cellValue);
                                    cell.setCellStyle(headerCellStyle3);
                                }
                                rowNum++;
                            }
                            for (int i = 0; i <= columnCount; i++) {
                                sheet.autoSizeColumn(i);
                            }

                            Row searchParameter = sheet.createRow(0);
                            Cell searchParametercell = searchParameter.createCell(0);
                            searchParametercell.setCellValue(greeting);
                            searchParametercell.setCellStyle(headerCellStyle2);
                            Row deatails = sheet.createRow(1);
                            for (int i = 0; i < reportDetails.size(); i++) {

                                Cell cell = deatails.createCell(i);
                                cell.setCellValue(reportDetails.get(i));
                                cell.setCellStyle(headerCellStyle3);

                            }

                            // Write workbook to file
                            try (FileOutputStream out = new FileOutputStream(new File(tempFolder
                                            + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp)))) {
                                workbook.write(out);

                                File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                                + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp));

                                try (InputStream fis = new FileInputStream(file)) {
                                    client.getClient(storageCredentials)
                                                    .blobName(reportModuleCommonRepo.getReportsExcelFileName(fileName,
                                                                    timeStamp))
                                                    .buildClient().upload(fis, file.length());
                                    nameAndFile.put(ReportsConstants.FILENAME, reportModuleCommonRepo
                                                    .getReportsExcelFileName(fileName, timeStamp));
                                    nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                    reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                    return nameAndFile;
                                }

                            }
                        } catch (IOException e) {
                            log.error(errorInGeneratingExcelWorkbook, e);
                        }
                    } else {
                        rs = cs.getResultSet();

                        // Get the metadata for the result set
                        ResultSetMetaData metadata = rs.getMetaData();
                        int columnCount = metadata.getColumnCount();

                        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        try (CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format)) {
                            csvPrinter.printRecord(greeting);
                            csvPrinter.printRecord(reportDetails.toArray());
                            csvPrinter.printRecord();

                            // Create header row
                            String[] headerRow = new String[columnCount];
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                headerRow[i - 1] = columnName;
                            }
                            csvPrinter.printRecord((Object[]) headerRow);

                            while (rs.next()) {
                                String[] rowData = new String[columnCount];
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    rowData[i - 1] = cellValue;
                                }
                                csvPrinter.printRecord((Object[]) rowData);
                            }

                            csvPrinter.flush();

                            InputStream inputStream = new ByteArrayInputStream(out.toByteArray());

                            Files.copy(inputStream, Paths.get(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp)));

                            File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));

                            try (InputStream fis = new FileInputStream(file)) {
                                client.getClient(storageCredentials).blobName(
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp))
                                                .buildClient().upload(fis, file.length());
                                nameAndFile.put(ReportsConstants.FILENAME,
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));
                                nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                return nameAndFile;
                            }
                        } catch (IOException e1) {
                            log.error(errorInGeneratingCSVFile, e1);

                        }
                    }
                }
                return nameAndFile;
            }
        });

    }

    @Override
    public Map<String, Object> getSearchReports(SearchReportReqDTO searchReportReq) {
        Map<String, Object> reportsCountAndReportsList = new HashMap<>();
        int reportsTotalCount = jdbcTemplateTrn.queryForObject(
                        ReportsCommonSql.getSearchReportsTotalCount(mstDatabseName, searchReportReq.getSearchValue()),
                        Integer.class);
        List<ReportDetailsResDTO> reportList = jdbcTemplateTrn.query(
                        ReportsCommonSql.getSearchReportsDetails(mstDatabseName, searchReportReq.getSearchValue()),
                        new ResultSetExtractor<List<ReportDetailsResDTO>>() {

                            public List<ReportDetailsResDTO> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                List<ReportDetailsResDTO> pinnedReportsList = new ArrayList<>();
                                while (rs.next()) {

                                    ReportDetailsResDTO reportDetailsResDTO = new ReportDetailsResDTO();

                                    String reportCode = rs.getString(ReportsConstants.REPORT_CODE);
                                    String isCustom = reportModuleCommonRepo.getCustomOrDefaultValue(reportCode);

                                    reportDetailsResDTO
                                                    .setId(checkNullValue(rs.getString(ReportsConstants.REPORT_CODE)));
                                    reportDetailsResDTO.setReportname(checkNullValue(rs.getString("name")));
                                    reportDetailsResDTO.setModuleName(checkNullValue(rs.getString("module_Name")));
                                    reportDetailsResDTO.setReportDesc(checkNullValue(rs.getString("description")));

                                    reportDetailsResDTO.setModuleId(checkNullValue(rs.getString("pld_module_id")));
                                    if (isCustom == null || isCustom.equals(ReportsConstants.DEFAULT)
                                                    || isCustom.equals("")) {
                                        reportDetailsResDTO
                                                        .setSubModuleId(checkNullValue(rs.getString("submodule_id")));
                                    } else {
                                        reportDetailsResDTO.setSubModuleId("");
                                    }
                                    pinnedReportsList.add(reportDetailsResDTO);
                                }
                                return pinnedReportsList;
                            }

                        }, searchReportReq.getSize());
        reportsCountAndReportsList.put(ReportsConstants.REPORTTOTALCOUNT, reportsTotalCount);
        reportsCountAndReportsList.put(ReportsConstants.REPORTSLIST, reportList);

        return reportsCountAndReportsList;

    }

}
