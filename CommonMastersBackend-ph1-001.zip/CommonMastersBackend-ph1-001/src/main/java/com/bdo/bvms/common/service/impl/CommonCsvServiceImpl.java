package com.bdo.bvms.common.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.exceptions.CommonMasterBusinessException;
import com.bdo.bvms.common.service.ICommonCsvService;

@Service
public class CommonCsvServiceImpl implements ICommonCsvService {

    @Value("${bvms.cloud.temp.file.download.path}")
    private String tempFolderPath;

    @Override
    public List<String> readVendorMasterDetailsTemplateFile(File file, char delimiter) {
        Path path = file.toPath();
        Iterable<CSVRecord> records = null;
        List<String> headerList = new ArrayList<>();
        Set<String> headers = null;
        try (BufferedReader reader = Files.newBufferedReader(path)) {

            records = CSVFormat.DEFAULT.withDelimiter(delimiter).withFirstRecordAsHeader()
                            .withAllowMissingColumnNames(true).parse(reader);

            headers = records.iterator().next().toMap().keySet();

            headerList.addAll(headers);
        } catch (Exception e) {
            throw new CommonMasterBusinessException("Error while reading custom template ", e);
        } finally {
            records = null;
        }
        return headerList;
    }

    @Override
    public Map<String, List<String>> readCustomTemplateSampleData(File file) {
        Map<String, List<String>> resultMap = new LinkedHashMap<>();
        String filePath = file.getAbsolutePath();
        try (Reader reader = new FileReader(filePath);
                        CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader()
                                        .withAllowMissingColumnNames().withAllowDuplicateHeaderNames())) {

            // Get the header names
            List<String> headers = csvParser.getHeaderNames();
            // Remove empty headers
            List<String> nonEmptyHeaders = new ArrayList<>();
            for (String header : headers) {
                if (!header.trim().isEmpty()) {
                    nonEmptyHeaders.add(header);
                }
            }
            // Initialize the result map
            for (String header : nonEmptyHeaders) {
                resultMap.put(header, new ArrayList<>());
            }

            // Read the first five records and extract values
            int recordCount = 0;
            for (CSVRecord csvRecord : csvParser) {
                if (recordCount >= 5) {
                    break; // Stop after reading five records
                }
                for (String header : nonEmptyHeaders) {
                    String value = csvRecord.get(header);
                    resultMap.get(header).add(value);
                }
                recordCount++;
            }
        } catch (Exception e) {
            throw new CommonMasterBusinessException("Error while reading custom template ", e);
        }

        return resultMap;
    }

}