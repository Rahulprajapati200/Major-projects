package com.bdo.bvms.common.service;

import java.io.File;

import com.bdo.bvms.common.model.EntityCloudCredentials;

public interface IAzureBlobService {

    String getAzureBlobUrl(String fileName, EntityCloudCredentials entityCloudCredentials) ;

	String uploadToAzureBlob(File file, EntityCloudCredentials entityCloudCredentials);

}
