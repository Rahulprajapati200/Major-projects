package com.bdo.bvms.common.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class CustomEmailTemplateModulesResDTO {

	private Integer moduleId;
	private String moduleName;
	
}
