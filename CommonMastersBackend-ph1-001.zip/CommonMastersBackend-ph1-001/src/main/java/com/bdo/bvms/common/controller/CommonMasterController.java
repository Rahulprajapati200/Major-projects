package com.bdo.bvms.common.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import com.bdo.bvms.common.dto.DownloadFileDTO;
import com.bdo.bvms.common.exceptions.BVMSException;

public interface CommonMasterController {

	ResponseEntity<Resource> downloadFileByteStream(HttpServletRequest httpServletRequest,
            @RequestBody DownloadFileDTO downloadFileBytestreamDto) throws BVMSException, IOException;
}
