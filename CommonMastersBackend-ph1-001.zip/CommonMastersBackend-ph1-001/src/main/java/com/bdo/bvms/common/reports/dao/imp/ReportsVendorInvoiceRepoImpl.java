package com.bdo.bvms.common.reports.dao.imp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.config.AzureClientProvider;
import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.EInvoiceRegisterReportsResDTO;
import com.bdo.bvms.common.dto.EWayBillRegisterReportRes;
import com.bdo.bvms.common.dto.GSTR2AReportsResDTO;
import com.bdo.bvms.common.dto.GSTR2BReportsResDTO;
import com.bdo.bvms.common.dto.GetEWayBillRegisterReportRes;
import com.bdo.bvms.common.dto.ReportsCustomColumnsDTO;
import com.bdo.bvms.common.dto.VendorInvoiceGetReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceInputReportsReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceSyncReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceSyncResDTO;
import com.bdo.bvms.common.reports.constants.ReportsConstants;
import com.bdo.bvms.common.reports.dao.ReportModuleCommonRepo;
import com.bdo.bvms.common.reports.dao.ReportsVendorInvoiceRepo;
import com.bdo.bvms.common.reports.sql.ReportsCommonSql;

import lombok.Synchronized;
import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class ReportsVendorInvoiceRepoImpl implements ReportsVendorInvoiceRepo {

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Value("${txn.database-name}")
    private String transDatabaseName;

    @Value("${bvms.cloud.temp.file.download.path}")
    String tempFolder;

    @Autowired
    public AzureClientProvider client;

    @Autowired
    ReportModuleCommonRepo reportModuleCommonRepo;

    CallableStatement cs = null;
    long key;
    String callStatement;

    ResourceBundle messages = ResourceBundle.getBundle("messages");
    String errorInGeneratingCSVFile = messages.getString("errorInGeneratingCSVFile");
    String errorInGeneratingExcelWorkbook = messages.getString("errorInGeneratingExcelWorkbook");
    String greeting = messages.getString("searchParameters");

    @Override
    @Synchronized
    public Map<String, Object> getInputReportsResList(VendorInvoiceInputReportsReqDTO vendorInvoiceInputReportsReqDTO,
                    String gstinList, String pan, String yearOrMonthList) throws SQLException {

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));
        String exportType = "view";
        String customOrDefault = reportModuleCommonRepo
                        .getCustomOrDefault(vendorInvoiceInputReportsReqDTO.getReportId());
        if (vendorInvoiceInputReportsReqDTO.getPeriodTypeCD().isBlank()) {
            vendorInvoiceInputReportsReqDTO.setPeriodTypeCD("0");
        }

        key = reportModuleCommonRepo.getKeyFromKeyHolder();

        Map<String, Object> results;
        try {
            results = jdbcTemplateTrn.call(new CallableStatementCreator() {

                @Override
                public CallableStatement createCallableStatement(Connection con) throws SQLException {

                    if (ReportsConstants.E_INVOICE_REGISTER_REPORT.equals(vendorInvoiceInputReportsReqDTO.getReportId())
                                    || ReportsConstants.CUSTOM_E_INVOICE_REGISTER_REPORT
                                                    .equals(vendorInvoiceInputReportsReqDTO.getReportId())) {

                        cs = con.prepareCall(
                                        "{call report_invoice_input_einvoice_register(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                        cs.setLong(1, Integer.valueOf(vendorInvoiceInputReportsReqDTO.getGstinOrPan()));
                        cs.setString(2, gstinList);
                        cs.setString(3, pan);
                        cs.setString(4, vendorInvoiceInputReportsReqDTO.getYearOrMonth());
                        if (vendorInvoiceInputReportsReqDTO.getYearOrMonth().equals(ReportsConstants.YEAR)) {
                            cs.setString(5, yearOrMonthList);
                            cs.setString(6, "");
                        } else {
                            cs.setString(5, "");
                            cs.setString(6, yearOrMonthList);
                        }

                        cs.setString(7, vendorInvoiceInputReportsReqDTO.getReportId());
                        cs.setString(8, mstDatabseName);
                        cs.setString(9, customOrDefault);
                        cs.setString(10, ReportsConstants.INVOICE_TEMPLATE_ID);
                        cs.setInt(11, vendorInvoiceInputReportsReqDTO.getCustomTemplateId());
                        cs.setString(12, vendorInvoiceInputReportsReqDTO.getUserTypeId());
                        cs.setString(13, vendorInvoiceInputReportsReqDTO.getEntityId());
                        cs.setString(14, vendorInvoiceInputReportsReqDTO.getUserId());
                        cs.setString(15, exportType);
                        cs.setString(16, vendorInvoiceInputReportsReqDTO.getPeriodTypeCD());
                        cs.setInt(17, vendorInvoiceInputReportsReqDTO.getSize());
                        cs.setInt(18, vendorInvoiceInputReportsReqDTO.getPage()
                                        * vendorInvoiceInputReportsReqDTO.getSize());

                    } else if (ReportsConstants.E_WAY_BILL_REGISTER_REPORT
                                    .equals(vendorInvoiceInputReportsReqDTO.getReportId())
                                    || ReportsConstants.CUSTOM_E_WAY_BILL_REGISTER_REPORT
                                                    .equals(vendorInvoiceInputReportsReqDTO.getReportId())) {
                        cs = con.prepareCall(
                                        "{call report_invoice_input_ewaybill_register(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                        cs.setLong(1, Integer.valueOf(vendorInvoiceInputReportsReqDTO.getGstinOrPan()));
                        cs.setString(2, gstinList);
                        cs.setString(3, pan);
                        cs.setString(4, vendorInvoiceInputReportsReqDTO.getYearOrMonth());
                        if (vendorInvoiceInputReportsReqDTO.getYearOrMonth().equals(ReportsConstants.YEAR)) {
                            cs.setString(5, yearOrMonthList);
                            cs.setString(6, "");
                        } else {
                            cs.setString(5, "");
                            cs.setString(6, yearOrMonthList);
                        }

                        cs.setString(7, vendorInvoiceInputReportsReqDTO.getReportId());
                        cs.setString(8, mstDatabseName);
                        cs.setString(9, customOrDefault);
                        cs.setString(10, ReportsConstants.E_WAY_BILL_TEMPLATE_ID);
                        cs.setInt(11, vendorInvoiceInputReportsReqDTO.getCustomTemplateId());
                        cs.setString(12, vendorInvoiceInputReportsReqDTO.getUserTypeId());
                        cs.setString(13, vendorInvoiceInputReportsReqDTO.getEntityId());
                        cs.setString(14, vendorInvoiceInputReportsReqDTO.getUserId());
                        cs.setString(15, exportType);
                        cs.setString(16, vendorInvoiceInputReportsReqDTO.getPeriodTypeCD());
                        cs.setInt(17, vendorInvoiceInputReportsReqDTO.getSize());
                        cs.setInt(18, vendorInvoiceInputReportsReqDTO.getPage()
                                        * vendorInvoiceInputReportsReqDTO.getSize());

                    } else if (ReportsConstants.CUSTOM_E_INVOICE_ERROR_REPORT
                                    .equals(vendorInvoiceInputReportsReqDTO.getReportId())) {
                        cs = con.prepareCall(
                                        "{call report_custom_invoice_einvoice_register_error(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                        cs.setLong(1, Integer.valueOf(vendorInvoiceInputReportsReqDTO.getGstinOrPan()));
                        cs.setString(2, gstinList);
                        cs.setString(3, pan);
                        cs.setString(4, vendorInvoiceInputReportsReqDTO.getYearOrMonth());
                        cs.setString(5, yearOrMonthList);
                        cs.setString(6, mstDatabseName);
                        cs.setString(7, vendorInvoiceInputReportsReqDTO.getReportId());
                        cs.setString(8, customOrDefault);
                        cs.setString(9, exportType);
                        // pld_template_id for e_invoice
                        cs.setInt(10, 1);
                        cs.setInt(11, vendorInvoiceInputReportsReqDTO.getCustomTemplateId());
                        cs.setString(12, vendorInvoiceInputReportsReqDTO.getUserId());
                        cs.setString(13, vendorInvoiceInputReportsReqDTO.getDateFrom());
                        cs.setString(14, vendorInvoiceInputReportsReqDTO.getDateTo());
                        cs.setInt(15, vendorInvoiceInputReportsReqDTO.getSize());
                        cs.setInt(16, vendorInvoiceInputReportsReqDTO.getPage()
                                        * vendorInvoiceInputReportsReqDTO.getSize());
                    } else if (ReportsConstants.CUSTOM_E_WAY_BILL_ERROR_REPORT
                                    .equals(vendorInvoiceInputReportsReqDTO.getReportId())) {
                        cs = con.prepareCall(
                                        "{call report_custom_invoice_input_ewaybill_register_error(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                        cs.setLong(1, Integer.valueOf(vendorInvoiceInputReportsReqDTO.getGstinOrPan()));
                        cs.setString(2, gstinList);
                        cs.setString(3, pan);
                        cs.setString(4, vendorInvoiceInputReportsReqDTO.getYearOrMonth());
                        cs.setString(5, yearOrMonthList);
                        cs.setString(6, mstDatabseName);
                        cs.setString(7, vendorInvoiceInputReportsReqDTO.getReportId());
                        cs.setString(8, customOrDefault);
                        cs.setString(9, exportType);
                        // pld_template_id for e_way_bill
                        cs.setInt(10, 2);
                        cs.setInt(11, vendorInvoiceInputReportsReqDTO.getCustomTemplateId());
                        cs.setString(12, vendorInvoiceInputReportsReqDTO.getUserId());
                        cs.setInt(13, vendorInvoiceInputReportsReqDTO.getSize());
                        cs.setInt(14, vendorInvoiceInputReportsReqDTO.getPage()
                                        * vendorInvoiceInputReportsReqDTO.getSize());
                    }

                    callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                    reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                    return cs;

                }
            }, parameters);

            // Process the results object here

        } finally {
            if (cs != null) {
                cs.close();
            }
        }

        Map<String, Object> inputTabVendorInvoceReportData = new HashMap<>();
        // #update-count-1

        if (!results.isEmpty()) {

            if (ReportsConstants.E_INVOICE_REGISTER_REPORT.equals(vendorInvoiceInputReportsReqDTO.getReportId())
                            || ReportsConstants.CUSTOM_E_INVOICE_ERROR_REPORT
                                            .equals(vendorInvoiceInputReportsReqDTO.getReportId())
                            || ReportsConstants.CUSTOM_E_INVOICE_REGISTER_REPORT
                                            .equals(vendorInvoiceInputReportsReqDTO.getReportId())) {
                List<EInvoiceRegisterReportsResDTO> inputTabReportsList = new ArrayList<>();
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> dataList = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_1);
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> countValue = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_2);
                Map<String, Object> count11 = countValue.get(0);
                long totalCount = (long) count11.get(ReportsConstants.TOTAL_NUMBER_OF_RECORDS);

                dataList.stream().forEach(dataObject -> {

                    EInvoiceRegisterReportsResDTO dataRes = new EInvoiceRegisterReportsResDTO();

                    dataRes.setDocType(checkNullValue((String) dataObject.get("doc_type")));
                    dataRes.setGstinOfSupplier(checkNullValue((String) dataObject.get("vendor_gstin")));
                    dataRes.setGstinUinOfRecipient(checkNullValue((String) dataObject.get("taxpayer_gstin")));
                    dataRes.setHsnCode(checkNullValue((String) dataObject.get("hsn_code")));
                    dataRes.setInwardDate(checkNullValue((String) dataObject.get("invoice_date")));
                    dataRes.setInwardNo(checkNullValue((String) dataObject.get("invoice_no")));
                    dataRes.setIrn(checkNullValue((String) dataObject.get("irn")));
                    dataRes.setIrnDate(checkNullValue((String) dataObject.get("irn_date")));
                    dataRes.setPurchaseOrderDate(checkNullValue((String) dataObject.get("po_date")));
                    dataRes.setPurchaseOrderNo(checkNullValue((String) dataObject.get("po_no")));
                    dataRes.setRowVersion((Timestamp) dataObject.get("row_version"));
                    if (ReportsConstants.E_INVOICE_REGISTER_REPORT.equals(vendorInvoiceInputReportsReqDTO.getReportId())
                                    || ReportsConstants.CUSTOM_E_INVOICE_REGISTER_REPORT
                                                    .equals(vendorInvoiceInputReportsReqDTO.getReportId())) {
                        dataRes.setTemplateType(checkNullValue((Long) dataObject.get("pld_upload_type")));
                    }

                    dataRes.setUdf1(checkNullValue((String) dataObject.get(ReportsConstants.UDF1)));
                    dataRes.setUdf2(checkNullValue((String) dataObject.get(ReportsConstants.UDF2)));
                    dataRes.setUdf3(checkNullValue((String) dataObject.get(ReportsConstants.UDF3)));
                    dataRes.setUdf4(checkNullValue((String) dataObject.get(ReportsConstants.UDF4)));
                    dataRes.setUdf5(checkNullValue((String) dataObject.get(ReportsConstants.UDF5)));
                    dataRes.setUdf6(checkNullValue((String) dataObject.get(ReportsConstants.UDF6)));
                    dataRes.setUdf7(checkNullValue((String) dataObject.get(ReportsConstants.UDF7)));
                    dataRes.setUdf8(checkNullValue((String) dataObject.get(ReportsConstants.UDF8)));
                    dataRes.setUdf9(checkNullValue((String) dataObject.get(ReportsConstants.UDF9)));
                    dataRes.setUdf10(checkNullValue((String) dataObject.get(ReportsConstants.UDF10)));
                    dataRes.setUdf11(checkNullValue((String) dataObject.get(ReportsConstants.UDF11)));
                    dataRes.setUdf12(checkNullValue((String) dataObject.get(ReportsConstants.UDF12)));
                    dataRes.setUdf13(checkNullValue((String) dataObject.get(ReportsConstants.UDF13)));
                    dataRes.setUdf14(checkNullValue((String) dataObject.get(ReportsConstants.UDF14)));
                    dataRes.setUdf15(checkNullValue((String) dataObject.get(ReportsConstants.UDF15)));
                    dataRes.setUdf16(checkNullValue((String) dataObject.get(ReportsConstants.UDF16)));
                    dataRes.setUdf17(checkNullValue((String) dataObject.get(ReportsConstants.UDF17)));
                    dataRes.setUdf18(checkNullValue((String) dataObject.get(ReportsConstants.UDF18)));
                    dataRes.setUdf19(checkNullValue((String) dataObject.get(ReportsConstants.UDF19)));
                    dataRes.setUdf20(checkNullValue((String) dataObject.get(ReportsConstants.UDF20)));
                    if (ReportsConstants.CUSTOM_E_INVOICE_ERROR_REPORT
                                    .equals(vendorInvoiceInputReportsReqDTO.getReportId())) {
                        dataRes.setTotalInvoiceAmount(checkNullValue((String) dataObject.get("total_invoice_amt")));
                        dataRes.setErrorCode(checkNullValue((String) dataObject.get("error_code")));
                        dataRes.setErrorMessage(checkNullValue((String) dataObject.get("error_message")));

                    } else {
                        dataRes.setTotalInvoiceAmount(checkNullValue((BigDecimal) dataObject.get("total_invoice_amt")));
                    }

                    inputTabReportsList.add(dataRes);

                });
                inputTabVendorInvoceReportData.put("inputTabVendorInvoceReportData", inputTabReportsList);
                inputTabVendorInvoceReportData.put(ReportsConstants.TOTALCOUNT, totalCount);
            } else if (ReportsConstants.E_WAY_BILL_REGISTER_REPORT.equals(vendorInvoiceInputReportsReqDTO.getReportId())
                            || ReportsConstants.CUSTOM_E_WAY_BILL_ERROR_REPORT
                                            .equals(vendorInvoiceInputReportsReqDTO.getReportId())
                            || ReportsConstants.CUSTOM_E_WAY_BILL_REGISTER_REPORT
                                            .equals(vendorInvoiceInputReportsReqDTO.getReportId())) {

                List<EWayBillRegisterReportRes> inputTabReportsList = new ArrayList<>();
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> dataList = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_1);
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> countValue = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_2);
                Map<String, Object> count11 = countValue.get(0);
                long totalCount = (long) count11.get(ReportsConstants.TOTAL_COUNT);

                dataList.stream().forEach(dataObject -> {

                    EWayBillRegisterReportRes dataRes = new EWayBillRegisterReportRes();
                    dataRes.setGstinUinOfRecipient(checkNullValue((String) dataObject.get("taxpayer_gstin")));
                    dataRes.setEwayBillNo(checkNullValue((String) dataObject.get("eway_bill_no")));
                    dataRes.setEwayBillDate(checkNullValue((String) dataObject.get("eway_bill_date")));
                    dataRes.setValidUpto(checkNullValue((String) dataObject.get("ewb_validity_date")));
                    dataRes.setGstinOfSupplier(checkNullValue((String) dataObject.get("vendor_gstin")));
                    dataRes.setPurchaseOrderNo(checkNullValue((String) dataObject.get("po_no")));
                    dataRes.setPurchaseOrderDate(checkNullValue((String) dataObject.get("po_date")));
                    dataRes.setUdf1(checkNullValue((String) dataObject.get(ReportsConstants.UDF1)));
                    dataRes.setUdf2(checkNullValue((String) dataObject.get(ReportsConstants.UDF2)));
                    dataRes.setUdf3(checkNullValue((String) dataObject.get(ReportsConstants.UDF3)));
                    dataRes.setUdf4(checkNullValue((String) dataObject.get(ReportsConstants.UDF4)));
                    dataRes.setUdf5(checkNullValue((String) dataObject.get(ReportsConstants.UDF5)));
                    dataRes.setUdf6(checkNullValue((String) dataObject.get(ReportsConstants.UDF6)));
                    dataRes.setUdf7(checkNullValue((String) dataObject.get(ReportsConstants.UDF7)));
                    dataRes.setUdf8(checkNullValue((String) dataObject.get(ReportsConstants.UDF8)));
                    dataRes.setUdf9(checkNullValue((String) dataObject.get(ReportsConstants.UDF9)));
                    dataRes.setUdf10(checkNullValue((String) dataObject.get(ReportsConstants.UDF10)));
                    dataRes.setUdf11(checkNullValue((String) dataObject.get(ReportsConstants.UDF11)));
                    dataRes.setUdf12(checkNullValue((String) dataObject.get(ReportsConstants.UDF12)));
                    dataRes.setUdf13(checkNullValue((String) dataObject.get(ReportsConstants.UDF13)));
                    dataRes.setUdf14(checkNullValue((String) dataObject.get(ReportsConstants.UDF14)));
                    dataRes.setUdf15(checkNullValue((String) dataObject.get(ReportsConstants.UDF15)));
                    dataRes.setUdf16(checkNullValue((String) dataObject.get(ReportsConstants.UDF16)));
                    dataRes.setUdf17(checkNullValue((String) dataObject.get(ReportsConstants.UDF17)));
                    dataRes.setUdf18(checkNullValue((String) dataObject.get(ReportsConstants.UDF18)));
                    dataRes.setUdf19(checkNullValue((String) dataObject.get(ReportsConstants.UDF19)));
                    dataRes.setUdf20(checkNullValue((String) dataObject.get(ReportsConstants.UDF20)));
                    if (ReportsConstants.CUSTOM_E_WAY_BILL_ERROR_REPORT
                                    .equals(vendorInvoiceInputReportsReqDTO.getReportId())) {
                        dataRes.setErrorCode(checkNullValue((String) dataObject.get("error_code")));
                        dataRes.setErrorMessage(checkNullValue((String) dataObject.get("error_message")));
                    }
                    inputTabReportsList.add(dataRes);
                });

                inputTabVendorInvoceReportData.put("inputTabVendorInvoceReportData", inputTabReportsList);
                inputTabVendorInvoceReportData.put(ReportsConstants.TOTALCOUNT, totalCount);
            }

        }

        return inputTabVendorInvoceReportData;

    }

    private static String checkNullValue(String value) {
        if (StringUtils.isEmpty(value)) {
            return "-";
        } else {
            return value;
        }
    }

    private static String checkNullValue(BigDecimal value) {
        if (value == null) {
            return "0";
        } else {
            return value.toString();
        }
    }

    private static Long checkNullValue(Long value) {
        return value != null ? value : (long) 0;
    }

    @Override
    public List<ReportsCustomColumnsDTO> getCustomizeColumns(String reportId, String userId) {

        int count = jdbcTemplateTrn.queryForObject(ReportsCommonSql.getDynamicHeadersCount(mstDatabseName),
                        Integer.class, userId, reportId);
        String isCustom = jdbcTemplateMst.queryForObject(ReportsCommonSql.QUERY_FOR_ISCUSTOM_TEMPLATE, String.class,
                        reportId);

        String sql = "";
        if (count > 0) {
            sql = ReportsCommonSql.getDynamicHeaders(mstDatabseName);
            return jdbcTemplateTrn.query(sql, new ResultSetExtractor<List<ReportsCustomColumnsDTO>>() {

                public List<ReportsCustomColumnsDTO> extractData(ResultSet rs)
                                throws SQLException, DataAccessException {
                    List<ReportsCustomColumnsDTO> reportsCustomColumnsList = new ArrayList<>();
                    while (rs.next()) {
                        ReportsCustomColumnsDTO reportsCustomColumns = new ReportsCustomColumnsDTO();
                        reportsCustomColumns.setColumnWidth(rs.getLong(ReportsConstants.COLUMN_WIDTH));
                        reportsCustomColumns.setField(checkNullValue(rs.getString(ReportsConstants.FIELD_NAME)));
                        reportsCustomColumns
                                        .setKey(checkNullValue(rs.getString(ReportsConstants.CUSTOMIZE_COLUMN_NAME)));
                        reportsCustomColumns.setName(checkNullValue(rs.getString(ReportsConstants.COLUMN_NAME)));

                        reportsCustomColumnsList.add(reportsCustomColumns);
                    }
                    return reportsCustomColumnsList;
                }

            }, userId, reportId);
        }

        if (isCustom == null || isCustom.equals(ReportsConstants.DEFAULT) || isCustom.equals("")) {

            return jdbcTemplateMst.query(ReportsCommonSql.getDefaultHeaders(),
                            new ResultSetExtractor<List<ReportsCustomColumnsDTO>>() {

                                public List<ReportsCustomColumnsDTO> extractData(ResultSet rs)
                                                throws SQLException, DataAccessException {
                                    List<ReportsCustomColumnsDTO> reportsCustomColumnsList = new ArrayList<>();
                                    while (rs.next()) {
                                        ReportsCustomColumnsDTO reportsCustomColumns = new ReportsCustomColumnsDTO();
                                        reportsCustomColumns.setColumnWidth(rs.getLong("column_width"));
                                        reportsCustomColumns.setField(checkNullValue(rs.getString("field_name")));
                                        reportsCustomColumns
                                                        .setKey(checkNullValue(rs.getString("customize_column_name")));
                                        reportsCustomColumns.setName(checkNullValue(rs.getString("column_name")));

                                        reportsCustomColumnsList.add(reportsCustomColumns);
                                    }
                                    return reportsCustomColumnsList;
                                }

                            }, reportId);

        } else {
            return jdbcTemplateMst.query(ReportsCommonSql.getCustomDefaultHeaders(),
                            new ResultSetExtractor<List<ReportsCustomColumnsDTO>>() {

                                public List<ReportsCustomColumnsDTO> extractData(ResultSet rs)
                                                throws SQLException, DataAccessException {
                                    List<ReportsCustomColumnsDTO> reportsCustomColumnsList = new ArrayList<>();
                                    while (rs.next()) {
                                        ReportsCustomColumnsDTO reportsCustomColumns = new ReportsCustomColumnsDTO();
                                        reportsCustomColumns.setColumnWidth(rs.getLong("column_width"));
                                        reportsCustomColumns.setField(checkNullValue(rs.getString("field_name")));
                                        reportsCustomColumns
                                                        .setKey(checkNullValue(rs.getString("customize_column_name")));
                                        reportsCustomColumns.setName(checkNullValue(rs.getString("column_name")));

                                        reportsCustomColumnsList.add(reportsCustomColumns);
                                    }
                                    return reportsCustomColumnsList;
                                }

                            }, 7, reportId, reportId);

        }

    }

    @Override
    @Synchronized
    public Map<String, Object> getVendorInvoiceGETReportsResList(String gstinOrPan, String gstinList,
                    String yearOrMonth, String yearOrMonthList, String reportId, String category, String summaryType,
                    int size, int page, String userId) throws SQLException {

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));
        key = reportModuleCommonRepo.getKeyFromKeyHolder();
        String exportType = "view";
        String isCustom = reportModuleCommonRepo.getCustomOrDefault(reportId);

        Map<String, Object> results;
        try {
            results = jdbcTemplateTrn.call(new CallableStatementCreator() {

                @Override
                public CallableStatement createCallableStatement(Connection con) throws SQLException {

                    try {
                        if (ReportsConstants.GSTR2A_REPORT.equals(reportId)) {
                            cs = con.prepareCall("{call report_invoice_get_gstr2a (?,?,?,?,?,?,?,?,?,?,?,?)}");
                            cs.setString(1, gstinList);
                            cs.setString(2, yearOrMonth);
                            if (yearOrMonth.equals(ReportsConstants.YEAR)) {
                                cs.setString(3, yearOrMonthList);
                                cs.setString(4, "");
                            } else {
                                cs.setString(3, "");
                                cs.setString(4, yearOrMonthList);
                            }
                            cs.setString(5, reportId);
                            cs.setString(6, mstDatabseName);
                            cs.setString(7, isCustom);
                            cs.setString(8, userId);
                            cs.setString(9, exportType);
                            cs.setString(10, category);
                            cs.setInt(11, size);
                            cs.setInt(12, page * size);

                        } else if (ReportsConstants.GSTR2B_REPORT.equals(reportId)) {

                            cs = con.prepareCall("{call report_invoice_get_gstr2b (?,?,?,?,?,?,?,?,?,?,?,?)}");
                            cs.setString(1, gstinList);
                            cs.setString(2, yearOrMonth);
                            if (yearOrMonth.equals(ReportsConstants.YEAR)) {
                                cs.setString(3, yearOrMonthList);
                                cs.setString(4, "");
                            } else {
                                cs.setString(3, "");
                                cs.setString(4, yearOrMonthList);
                            }
                            cs.setString(5, reportId);
                            cs.setString(6, mstDatabseName);
                            cs.setString(7, isCustom);
                            cs.setString(8, userId);
                            cs.setString(9, exportType);
                            cs.setString(10, category);
                            cs.setInt(11, size);
                            cs.setInt(12, page * size);

                        } else if (ReportsConstants.GET_E_WAY_BILL_REPORT.equals(reportId)) {
                            cs = con.prepareCall("{call report_invoice_get_ewaybill(?,?,?,?,?,?,?,?,?,?,?,?)}");

                            cs.setString(1, gstinList);
                            cs.setString(2, yearOrMonth);
                            if (yearOrMonth.equals(ReportsConstants.YEAR)) {
                                cs.setString(3, yearOrMonthList);
                                cs.setString(4, "");
                            } else {
                                cs.setString(3, "");
                                cs.setString(4, yearOrMonthList);
                            }
                            cs.setString(5, reportId);
                            cs.setString(6, mstDatabseName);
                            cs.setString(7, isCustom);
                            cs.setString(8, userId);
                            cs.setString(9, exportType);
                            cs.setString(10, summaryType);

                            cs.setInt(11, size);
                            cs.setInt(12, page * size);
                        }
                        callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                        reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                        return cs;
                    } catch (SQLException e) {
                        if (cs != null) {
                            cs.close();
                        }
                        throw e;
                    }
                }
            }, parameters);

            // Process the results object here

        } finally {
            if (cs != null) {
                cs.close();
            }
        }

        Map<String, Object> inputTabVendorInvoceReportData = new HashMap<>();

        if (!results.isEmpty()) {

            if (ReportsConstants.GSTR2A_REPORT.equals(reportId)) {
                List<GSTR2AReportsResDTO> getGetTabReportsList = new ArrayList<>();
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> dataList = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_1);
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> countValue = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_2);
                Map<String, Object> count11 = countValue.get(0);
                long totalCount = (long) count11.get(ReportsConstants.TOTAL_COUNT);

                dataList.stream().forEach(dataObject -> {

                    GSTR2AReportsResDTO dataRes = new GSTR2AReportsResDTO();

                    dataRes.setGstin(checkNullValue((String) dataObject.get("gstin")));
                    dataRes.setCategory(checkNullValue((String) dataObject.get("category")));
                    dataRes.setInvoiceType(checkNullValue((String) dataObject.get("invoiceType")));
                    dataRes.setNoteType(checkNullValue((String) dataObject.get("noteType")));
                    dataRes.setEtin(checkNullValue((String) dataObject.get("etin")));
                    dataRes.setCtin(checkNullValue((String) dataObject.get("ctin")));
                    dataRes.setCompanyTradeName(checkNullValue((String) dataObject.get("companyTradeName")));
                    dataRes.setSupplierStateCode(checkNullValue((String) dataObject.get("supplierStateCode")));
                    dataRes.setOrgInvoiceNo(checkNullValue((String) dataObject.get("orgInvoiceNo")));
                    dataRes.setOrgInvoiceDate(checkNullValue((String) dataObject.get("orgInvoiceDate")));
                    dataRes.setInvoiceNo(checkNullValue((String) dataObject.get("invoiceNo")));
                    dataRes.setInvoiceDate(checkNullValue((String) dataObject.get("invoiceDate")));
                    dataRes.setOrgNoteNo(checkNullValue((String) dataObject.get("orgNoteNo")));
                    dataRes.setOrgNoteDate(checkNullValue((String) dataObject.get("orgNoteDate")));
                    dataRes.setNoteNo(checkNullValue((String) dataObject.get("noteNo")));
                    dataRes.setNoteDate(checkNullValue((String) dataObject.get("noteDate")));
                    dataRes.setPortCode(checkNullValue((String) dataObject.get("portCode")));
                    dataRes.setImportBillNo(checkNullValue((String) dataObject.get("importBillNo")));
                    dataRes.setImportBillDate(checkNullValue((String) dataObject.get("importBillDate")));
                    dataRes.setItcEligibility(checkNullValue((String) dataObject.get("itcEligibility")));
                    dataRes.setTaxableAmount((BigDecimal) dataObject.get("taxableAmount"));
                    dataRes.setSgstRate((BigDecimal) dataObject.get("sgstRate"));
                    dataRes.setSgstAmount(checkNullValue(dataObject.get("cgstAmount").toString()));
                    dataRes.setCgstRate((BigDecimal) dataObject.get("cgstRate"));
                    dataRes.setCgstAmount((BigDecimal) dataObject.get("cgstAmount"));
                    dataRes.setIgstRate((BigDecimal) dataObject.get("igstRate"));
                    dataRes.setIgstAmount((BigDecimal) dataObject.get("igstAmount"));
                    dataRes.setCessRate(checkNullValue((String) dataObject.get("cessRate")));
                    dataRes.setCessAmount((BigDecimal) dataObject.get("cessAmount"));
                    dataRes.setDiffPercent((BigDecimal) dataObject.get("diffPercent"));
                    dataRes.setTotalTaxAmount((BigDecimal) dataObject.get("totalTaxAmount"));
                    dataRes.setSumGrossTotalAmount((BigDecimal) dataObject.get("sumGrossTotalAmount"));
                    dataRes.setPos(checkNullValue((String) dataObject.get("pos")));
                    dataRes.setReverseCharge(checkNullValue((String) dataObject.get("reverseCharge")));
                    dataRes.setFp(checkNullValue((String) dataObject.get("fp")));
                    dataRes.setCfs(checkNullValue((String) dataObject.get("cfs")));
                    dataRes.setCfsGstr3b(checkNullValue((String) dataObject.get("cfsGstr3b")));
                    dataRes.setDateOfCancellation(checkNullValue((String) dataObject.get("dateOfCancellation")));
                    dataRes.setDateOfFilingGstr15(checkNullValue((String) dataObject.get("dateOfFilingGstr15")));
                    dataRes.setFilingPeriodGstr15(checkNullValue((String) dataObject.get("filingPeriodGstr15")));
                    dataRes.setDelinkFlag(checkNullValue((String) dataObject.get("delinkFlag")));
                    dataRes.setAmendmentFp(checkNullValue((String) dataObject.get("amendmentFp")));
                    dataRes.setAmendmentType(checkNullValue((String) dataObject.get("amendmentType")));
                    dataRes.setSrctyp(checkNullValue((String) dataObject.get("srctyp")));
                    dataRes.setIrn(checkNullValue((String) dataObject.get("irn")));
                    dataRes.setIrngendate(checkNullValue((String) dataObject.get("irngendate")));
                    dataRes.setPreGst(checkNullValue((String) dataObject.get("preGst")));

                    getGetTabReportsList.add(dataRes);

                });
                inputTabVendorInvoceReportData.put(ReportsConstants.GETTABVENDORINVOCEREPORTDATA, getGetTabReportsList);
                inputTabVendorInvoceReportData.put(ReportsConstants.TOTALCOUNT, totalCount);
            } else if (ReportsConstants.GSTR2B_REPORT.equals(reportId)) {

                List<GSTR2BReportsResDTO> getGetTabReportsList = new ArrayList<>();
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> dataList = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_1);
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> countValue = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_2);
                Map<String, Object> count11 = countValue.get(0);
                long totalCount = (long) count11.get(ReportsConstants.TOTAL_COUNT);

                dataList.stream().forEach(dataObject -> {

                    GSTR2BReportsResDTO dataRes = new GSTR2BReportsResDTO();
                    dataRes.setGstin(checkNullValue((String) dataObject.get("gstin")));
                    dataRes.setCategory(checkNullValue((String) dataObject.get("category")));
                    dataRes.setCtin(checkNullValue((String) dataObject.get("ctin")));
                    dataRes.setCompanyTradeName(checkNullValue((String) dataObject.get("companyTradeName")));
                    dataRes.setFilingPeriodGstr15(checkNullValue((String) dataObject.get("filingPeriodGstr15")));
                    dataRes.setInvoiceType(checkNullValue((String) dataObject.get("invoiceType")));
                    dataRes.setNoteType(checkNullValue((String) dataObject.get("noteType")));
                    dataRes.setNoteSupplyType(checkNullValue((String) dataObject.get("noteSupplyType")));
                    dataRes.setISDDocType(checkNullValue((String) dataObject.get("iSDDocType")));
                    dataRes.setOrgNoteType(checkNullValue((String) dataObject.get("orgNoteType")));
                    dataRes.setDocNo(checkNullValue((String) dataObject.get("docNo")));
                    dataRes.setDocDate(checkNullValue((String) dataObject.get("docDate")));
                    dataRes.setOrgInvoiceNo(checkNullValue((String) dataObject.get("orgInvoiceNo")));
                    dataRes.setOrgInvoiceDate(checkNullValue((String) dataObject.get("orgInvoiceDate")));
                    dataRes.setPos(checkNullValue((String) dataObject.get("pos")));
                    dataRes.setTaxableAmount(checkNullValue((BigDecimal) dataObject.get("taxableAmount")));
                    dataRes.setRate(checkNullValue((BigDecimal) dataObject.get("rate")));
                    dataRes.setDiffPercent(checkNullValue((BigDecimal) dataObject.get("diffPercent")));
                    dataRes.setIgstAmount(checkNullValue((BigDecimal) dataObject.get("igstAmount")));
                    dataRes.setCgstAmount(checkNullValue((BigDecimal) dataObject.get("cgstAmount")));
                    dataRes.setSgstAmount(checkNullValue((BigDecimal) dataObject.get("sgstAmount")));
                    dataRes.setCessAmount(checkNullValue((BigDecimal) dataObject.get("cessAmount")));
                    dataRes.setSumGrossTotalAmount(checkNullValue((BigDecimal) dataObject.get("sumGrossTotalAmount")));
                    dataRes.setReverseCharge(checkNullValue((String) dataObject.get("reverseCharge")));
                    dataRes.setItcEligibility(checkNullValue((String) dataObject.get("itcEligibility")));
                    dataRes.setItcEligibilityReason(checkNullValue((String) dataObject.get("itcEligibilityReason")));
                    dataRes.setDateOfFilingGstr15(checkNullValue((String) dataObject.get("dateOfFilingGstr15")));
                    dataRes.setSourceType(checkNullValue((String) dataObject.get("sourceType")));
                    dataRes.setIrn(checkNullValue((String) dataObject.get("irn")));
                    dataRes.setIrngendate(checkNullValue((String) dataObject.get("irngendate")));
                    dataRes.setFp(checkNullValue((String) dataObject.get("fp")));
                    dataRes.setPortCode(checkNullValue((String) dataObject.get("portCode")));
                    dataRes.setAmendmentType(checkNullValue((String) dataObject.get("amendmentType")));
                    dataRes.setImportBillNo(checkNullValue((String) dataObject.get("importBillNo")));
                    dataRes.setImportBillDate(checkNullValue((String) dataObject.get("importBillDate")));
                    dataRes.setIcegateRefDate(checkNullValue((String) dataObject.get("icegateRefDate")));
                    dataRes.setRcvdDateGst(checkNullValue((String) dataObject.get("rcvdDateGst")));

                    getGetTabReportsList.add(dataRes);
                });

                inputTabVendorInvoceReportData.put(ReportsConstants.GETTABVENDORINVOCEREPORTDATA, getGetTabReportsList);
                inputTabVendorInvoceReportData.put(ReportsConstants.TOTALCOUNT, totalCount);
            } else if (ReportsConstants.GET_E_WAY_BILL_REPORT.equals(reportId)) {

                List<GetEWayBillRegisterReportRes> getGetTabReportsList = new ArrayList<>();
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> dataList = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_1);
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> countValue = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_2);
                Map<String, Object> count11 = countValue.get(0);
                long totalCount = (long) count11.get(ReportsConstants.TOTAL_COUNT);

                dataList.stream().forEach(dataObject -> {

                    GetEWayBillRegisterReportRes dataRes = new GetEWayBillRegisterReportRes();
                    dataRes.setTaxpayerGstin(checkNullValue((String) dataObject.get("taxpayerGstin")));
                    dataRes.setUserGstin(checkNullValue((String) dataObject.get("userGstin")));
                    dataRes.setEwbNo(checkNullValue((String) dataObject.get("ewbNo")));
                    dataRes.setEwbDate(checkNullValue((String) dataObject.get("ewbDate")));
                    dataRes.setGenMode(checkNullValue((String) dataObject.get("genMode")));
                    dataRes.setSupplyType(checkNullValue((String) dataObject.get("supplyType")));
                    dataRes.setSubSupplyType(checkNullValue((String) dataObject.get("subSupplyType")));
                    dataRes.setDocType(checkNullValue((String) dataObject.get("docType")));
                    dataRes.setDocNo(checkNullValue((String) dataObject.get("docNo")));
                    dataRes.setDocDate(checkNullValue((String) dataObject.get("docDate")));
                    dataRes.setFromGstin(checkNullValue((String) dataObject.get("fromGstin")));
                    dataRes.setFromTradeName(checkNullValue((String) dataObject.get("fromTradeName")));
                    dataRes.setFromAddr1(checkNullValue((String) dataObject.get("fromAddr1")));
                    dataRes.setFromAddr2(checkNullValue((String) dataObject.get("fromAddr2")));
                    dataRes.setFromPlace(checkNullValue((String) dataObject.get("fromPlace")));
                    dataRes.setFromPincode(checkNullValue((String) dataObject.get("fromPincode")));
                    dataRes.setFromStateCode(checkNullValue((String) dataObject.get("fromStateCode")));
                    dataRes.setToGstin(checkNullValue((String) dataObject.get("toGstin")));
                    dataRes.setToTrdName(checkNullValue((String) dataObject.get("toTrdName")));
                    dataRes.setToAddr1(checkNullValue((String) dataObject.get("toAddr1")));
                    dataRes.setToAddr2(checkNullValue((String) dataObject.get("toAddr2")));
                    dataRes.setToPlace(checkNullValue((String) dataObject.get("toPlace")));
                    dataRes.setToPincode(checkNullValue((String) dataObject.get("toPincode")));
                    dataRes.setToStateCode(checkNullValue((String) dataObject.get("toStateCode")));
                    dataRes.setTotalValue(checkNullValue((String) dataObject.get("totalValue")));
                    dataRes.setTotInvValue(checkNullValue((String) dataObject.get("totInvValue")));
                    dataRes.setCgstValue(checkNullValue((String) dataObject.get("cgstValue")));
                    dataRes.setSgstValue(checkNullValue((String) dataObject.get("sgstValue")));
                    dataRes.setIgstValue(checkNullValue((String) dataObject.get("igstValue")));
                    dataRes.setCessValue(checkNullValue((String) dataObject.get("cessValue")));
                    dataRes.setTransporterId(checkNullValue((String) dataObject.get("transporterId")));
                    dataRes.setTransporterName(checkNullValue((String) dataObject.get("transporterName")));
                    dataRes.setStatus(checkNullValue((String) dataObject.get("status")));
                    dataRes.setActualDist(checkNullValue((String) dataObject.get("actualDist")));
                    dataRes.setNoValidDays(checkNullValue((String) dataObject.get("noValidDays")));
                    dataRes.setValidUpto(checkNullValue((String) dataObject.get("validUpto")));
                    dataRes.setExtendedTimes(checkNullValue((String) dataObject.get("extendedTimes")));
                    dataRes.setRejectStatus(checkNullValue((String) dataObject.get("rejectStatus")));
                    dataRes.setActFromStateCode(checkNullValue((String) dataObject.get("actFromStateCode")));
                    dataRes.setActToStateCode(checkNullValue((String) dataObject.get("actToStateCode")));
                    dataRes.setVehicleType(checkNullValue((String) dataObject.get("vehicleType")));
                    dataRes.setTransactionType(checkNullValue((String) dataObject.get("transactionType")));
                    dataRes.setOtherValue(checkNullValue((String) dataObject.get("otherValue")));
                    dataRes.setCessNonAdvolValue(checkNullValue((String) dataObject.get("cessNonAdvolValue")));
                    dataRes.setProductId((Long) dataObject.get("productId"));
                    dataRes.setProductName(checkNullValue((String) dataObject.get("productName")));
                    dataRes.setProductDesc(checkNullValue((String) dataObject.get("productDesc")));
                    dataRes.setHsnCode(checkNullValue((String) dataObject.get("hsnCode")));
                    dataRes.setQuantity(checkNullValue((String) dataObject.get("quantity")));
                    dataRes.setQtyUnit(checkNullValue((String) dataObject.get("qtyUnit")));
                    dataRes.setCgstRate(checkNullValue((String) dataObject.get("cgstRate")));
                    dataRes.setSgstRate(checkNullValue((String) dataObject.get("sgstRate")));
                    dataRes.setIgstRate(checkNullValue((String) dataObject.get("igstRate")));
                    dataRes.setCessRate(checkNullValue((String) dataObject.get("cessRate")));
                    dataRes.setCessNonAdvol(checkNullValue((String) dataObject.get("cessNonAdvol")));
                    dataRes.setTaxableAmount(checkNullValue((String) dataObject.get("taxableAmount")));
                    dataRes.setUpdMode(checkNullValue((String) dataObject.get("updMode")));
                    dataRes.setVehicleNo(checkNullValue((String) dataObject.get("vehicleNo")));
                    dataRes.setFromState(checkNullValue((String) dataObject.get("fromState")));
                    dataRes.setTripshtNo(checkNullValue((String) dataObject.get("tripshtNo")));
                    dataRes.setUserGstinTransin(checkNullValue((String) dataObject.get("userGstinTransin")));
                    dataRes.setEnteredDate(checkNullValue((String) dataObject.get("enteredDate")));
                    dataRes.setTransMode(checkNullValue((String) dataObject.get("transMode")));
                    dataRes.setTransDocno(checkNullValue((String) dataObject.get("transDocno")));
                    dataRes.setTransDocdate(checkNullValue((String) dataObject.get("transDocdate")));
                    dataRes.setGroupNo(checkNullValue((String) dataObject.get("groupNo")));

                    getGetTabReportsList.add(dataRes);
                });

                inputTabVendorInvoceReportData.put(ReportsConstants.GETTABVENDORINVOCEREPORTDATA, getGetTabReportsList);
                inputTabVendorInvoceReportData.put(ReportsConstants.TOTALCOUNT, totalCount);
            }

        }

        return inputTabVendorInvoceReportData;

    }

    @Override
    @Synchronized
    public Map<String, Object> getSyncDataList(VendorInvoiceSyncReqDTO vendorInvoiceSyncReq, String gstinList,
                    String vendorGstinList, String yearOrMonthList, String category) throws SQLException {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        key = reportModuleCommonRepo.getKeyFromKeyHolder();
        String exportType = "view";
        String isCustom = reportModuleCommonRepo.getCustomOrDefault(vendorInvoiceSyncReq.getReportId());

        Map<String, Object> results;
        try {
            results = jdbcTemplateTrn.call(new CallableStatementCreator() {

                @Override
                public CallableStatement createCallableStatement(Connection con) throws SQLException {

                    try {
                        if (ReportsConstants.MAPPED_WITH_GSTR2A_BUT_NOT_MAPPED_WITH_GET_E_WAY_BILL_AND_GSTR2B
                                        .equals(vendorInvoiceSyncReq.getReportId())) {
                            cs = con.prepareCall("{call report_invoice_sync_gstr2a (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                        } else if (ReportsConstants.MAPPED_WITH_GSTR2A_AND_GSTR2B_BUT_NOT_MAPPED_WITH_GET_E_WAY_BILL
                                        .equals(vendorInvoiceSyncReq.getReportId())) {
                            cs = con.prepareCall(
                                            "{call report_invoice_sync_gstr2a_gstr2b(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                        } else if (ReportsConstants.MAPPED_WITH_GET_E_WAY_BILL_BUT_NOT_MAPPED_WITH_GSTR2A_AND_GSTR2B
                                        .equals(vendorInvoiceSyncReq.getReportId())) {
                            cs = con.prepareCall("{call report_invoice_sync_ewaybill (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                        } else if (ReportsConstants.MAPPED_WITH_GSTR2B_BUT_NOT_MAPPED_WITH_GSTR2A_AND_GET_E_WAY_BILL
                                        .equals(vendorInvoiceSyncReq.getReportId())) {
                            cs = con.prepareCall("{call report_invoice_sync_gstr2b (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                        } else if (ReportsConstants.MAPPED_WITH_GET_E_WAY_BILL_AND_GSTR2B_BUT_NOT_MAPPED_WITH_GSTR2A
                                        .equals(vendorInvoiceSyncReq.getReportId())) {
                            cs = con.prepareCall(
                                            "{call report_invoice_sync_gstr2b_ewaybill(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                        } else if (ReportsConstants.MAPPED_WITH_GET_E_WAY_BILL_AND_GSTR2A_BUT_NOT_MAPPED_WITH_GSTR2B
                                        .equals(vendorInvoiceSyncReq.getReportId())) {
                            cs = con.prepareCall(
                                            "{call report_invoice_sync_gstr2a_ewaybill (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                        } else if (ReportsConstants.MAPPED_WITH_GET_E_WAY_BILL_AND_GSTR2A_AND_GSTR2B
                                        .equals(vendorInvoiceSyncReq.getReportId())) {
                            cs = con.prepareCall(
                                            "{call report_invoice_sync_gstr2a_gstr2b_ewaybill(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                        }

                        cs.setString(1, gstinList);
                        cs.setString(2, vendorGstinList);
                        cs.setString(3, vendorInvoiceSyncReq.getYearOrMonth());
                        if (vendorInvoiceSyncReq.getYearOrMonth().equals(ReportsConstants.YEAR)) {
                            cs.setString(4, yearOrMonthList);
                            cs.setString(5, "");
                        } else {
                            cs.setString(4, "");
                            cs.setString(5, yearOrMonthList);
                        }
                        cs.setString(6, vendorInvoiceSyncReq.getReportId());
                        cs.setString(7, mstDatabseName);
                        cs.setString(8, isCustom);
                        cs.setString(9, vendorInvoiceSyncReq.getUserId());
                        cs.setString(10, exportType);
                        cs.setString(11, category);
                        cs.setString(12, vendorInvoiceSyncReq.getSummaryType());
                        cs.setString(13, vendorInvoiceSyncReq.getPeriodTypeCD());
                        cs.setInt(14, vendorInvoiceSyncReq.getSize());
                        cs.setInt(15, vendorInvoiceSyncReq.getPage() * vendorInvoiceSyncReq.getSize());

                        callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                        reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                        return cs;
                    } catch (SQLException e) {
                        if (cs != null) {
                            cs.close();
                        }
                        throw e;
                    }
                }
            }, parameters);

            // Process the results object here

        } finally {
            if (cs != null) {
                cs.close();
            }
        }

        Map<String, Object> syncTabVendorInvoceReportData = new HashMap<>();

        List<VendorInvoiceSyncResDTO> getSyncReportsList = new ArrayList<>();

        if (!results.isEmpty()) {

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> dataList = (List<Map<String, Object>>) results.get(ReportsConstants.RESULT_SET_1);
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> countValue = (List<Map<String, Object>>) results
                            .get(ReportsConstants.RESULT_SET_2);
            Map<String, Object> count11 = countValue.get(0);
            long totalCount = (long) count11.get(ReportsConstants.TOTAL_COUNT);

            dataList.stream().forEach(dataObject -> {

                VendorInvoiceSyncResDTO dataRes = new VendorInvoiceSyncResDTO();

                dataRes.setTaxpayerGstin(checkNullValue((String) dataObject.get("taxpayer_gstin")));
                dataRes.setSyncWithGstr2a((Boolean) dataObject.get("sync_with_gstr2a"));
                dataRes.setSyncWithGstr2b((Boolean) dataObject.get("sync_with_gstr2b"));
                dataRes.setSyncWithEwayBill((Boolean) dataObject.get("sync_with_eway_bill"));
                dataRes.setVendorGstin(checkNullValue((String) dataObject.get("vendor_gstin")));
                dataRes.setDocType(checkNullValue((String) dataObject.get("doc_type")));
                dataRes.setHsnCode(checkNullValue((String) dataObject.get("hsn_code")));
                dataRes.setInvoiceNo(checkNullValue((String) dataObject.get("invoice_no")));
                dataRes.setInvoiceDate(checkNullValue((String) dataObject.get("invoice_date")));
                dataRes.setTotalInvoiceAmt(checkNullValue((BigDecimal) dataObject.get("total_invoice_amt")));
                dataRes.setIrn(checkNullValue((String) dataObject.get("irn")));
                dataRes.setIrnDate(checkNullValue((String) dataObject.get("irn_date")));
                dataRes.setEwayBillNo(checkNullValue((String) dataObject.get("eway_bill_no")));
                dataRes.setEwayBillDate(checkNullValue((String) dataObject.get("eway_bill_date")));
                dataRes.setBillValidDate(checkNullValue((String) dataObject.get("bill_valid_date")));
                dataRes.setPoNo(checkNullValue((String) dataObject.get("po_no")));
                dataRes.setPoDate(checkNullValue((String) dataObject.get("po_date")));
                dataRes.setUdf1(checkNullValue((String) dataObject.get(ReportsConstants.UDF1)));
                dataRes.setUdf2(checkNullValue((String) dataObject.get(ReportsConstants.UDF2)));
                dataRes.setUdf3(checkNullValue((String) dataObject.get(ReportsConstants.UDF3)));
                dataRes.setUdf4(checkNullValue((String) dataObject.get(ReportsConstants.UDF4)));
                dataRes.setUdf5(checkNullValue((String) dataObject.get(ReportsConstants.UDF5)));
                dataRes.setUdf6(checkNullValue((String) dataObject.get(ReportsConstants.UDF6)));
                dataRes.setUdf7(checkNullValue((String) dataObject.get(ReportsConstants.UDF7)));
                dataRes.setUdf8(checkNullValue((String) dataObject.get(ReportsConstants.UDF8)));
                dataRes.setUdf9(checkNullValue((String) dataObject.get(ReportsConstants.UDF9)));
                dataRes.setUdf10(checkNullValue((String) dataObject.get(ReportsConstants.UDF10)));
                getSyncReportsList.add(dataRes);
            });

            syncTabVendorInvoceReportData.put("syncTabVendorInvoceReportData", getSyncReportsList);
            syncTabVendorInvoceReportData.put(ReportsConstants.TOTALCOUNT, totalCount);

        }
        return syncTabVendorInvoceReportData;
    }

    @Override
    public Map<String, Object> getGenerateExcelOrCsvFileofEInvoiceInputReports(
                    VendorInvoiceInputReportsReqDTO vendorInvoiceInputReportsReq, String gstinList, String pan,
                    String yearOrMonthList, Timestamp timeStamp, String containerName, String fileName) {

        AzureConnectionCredentialsDTO storageCredentials = reportModuleCommonRepo
                        .getAzureCredentialFromDB(vendorInvoiceInputReportsReq.getEntityId(), "blob");

        String fileUrl = reportModuleCommonRepo.getFileUrl();

        String exportType = ReportsConstants.EXPORT;
        String customOrDefault = reportModuleCommonRepo.getCustomOrDefault(vendorInvoiceInputReportsReq.getReportId());
        key = reportModuleCommonRepo.getKeyFromKeyHolder();

        return jdbcTemplateTrn.execute(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {

                if (ReportsConstants.E_INVOICE_REGISTER_REPORT.equals(vendorInvoiceInputReportsReq.getReportId())
                                || ReportsConstants.CUSTOM_E_INVOICE_REGISTER_REPORT
                                                .equals(vendorInvoiceInputReportsReq.getReportId())) {
                    cs = con.prepareCall(
                                    "{call report_invoice_input_einvoice_register(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                    cs.setLong(1, Integer.valueOf(vendorInvoiceInputReportsReq.getGstinOrPan()));
                    cs.setString(2, gstinList);
                    cs.setString(3, pan);
                    cs.setString(4, vendorInvoiceInputReportsReq.getYearOrMonth());
                    if (vendorInvoiceInputReportsReq.getYearOrMonth().equals(ReportsConstants.YEAR)) {
                        cs.setString(5, yearOrMonthList);
                        cs.setString(6, "");
                    } else {
                        cs.setString(5, "");
                        cs.setString(6, yearOrMonthList);
                    }

                    cs.setString(7, vendorInvoiceInputReportsReq.getReportId());
                    cs.setString(8, mstDatabseName);
                    cs.setString(9, customOrDefault);
                    cs.setString(10, ReportsConstants.INVOICE_TEMPLATE_ID);
                    cs.setInt(11, vendorInvoiceInputReportsReq.getCustomTemplateId());
                    cs.setString(12, vendorInvoiceInputReportsReq.getUserTypeId());
                    cs.setString(13, vendorInvoiceInputReportsReq.getEntityId());
                    cs.setString(14, vendorInvoiceInputReportsReq.getUserId());
                    cs.setString(15, exportType);
                    cs.setString(16, vendorInvoiceInputReportsReq.getPeriodTypeCD());
                    cs.setInt(17, vendorInvoiceInputReportsReq.getSize());
                    cs.setInt(18, vendorInvoiceInputReportsReq.getPage() * vendorInvoiceInputReportsReq.getSize());

                } else if (ReportsConstants.E_WAY_BILL_REGISTER_REPORT
                                .equals(vendorInvoiceInputReportsReq.getReportId())
                                || ReportsConstants.CUSTOM_E_WAY_BILL_REGISTER_REPORT
                                                .equals(vendorInvoiceInputReportsReq.getReportId())) {
                    cs = con.prepareCall(
                                    "{call report_invoice_input_ewaybill_register(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                    cs.setLong(1, Integer.valueOf(vendorInvoiceInputReportsReq.getGstinOrPan()));
                    cs.setString(2, gstinList);
                    cs.setString(3, pan);
                    cs.setString(4, vendorInvoiceInputReportsReq.getYearOrMonth());
                    if (vendorInvoiceInputReportsReq.getYearOrMonth().equals(ReportsConstants.YEAR)) {
                        cs.setString(5, yearOrMonthList);
                        cs.setString(6, "");
                    } else {
                        cs.setString(5, "");
                        cs.setString(6, yearOrMonthList);
                    }

                    cs.setString(7, vendorInvoiceInputReportsReq.getReportId());
                    cs.setString(8, mstDatabseName);
                    cs.setString(9, customOrDefault);
                    cs.setString(10, ReportsConstants.E_WAY_BILL_TEMPLATE_ID);
                    cs.setInt(11, vendorInvoiceInputReportsReq.getCustomTemplateId());
                    cs.setString(12, vendorInvoiceInputReportsReq.getUserTypeId());
                    cs.setString(13, vendorInvoiceInputReportsReq.getEntityId());
                    cs.setString(14, vendorInvoiceInputReportsReq.getUserId());
                    cs.setString(15, exportType);
                    cs.setString(16, vendorInvoiceInputReportsReq.getPeriodTypeCD());
                    cs.setInt(17, vendorInvoiceInputReportsReq.getSize());
                    cs.setInt(18, vendorInvoiceInputReportsReq.getPage() * vendorInvoiceInputReportsReq.getSize());

                } else if (ReportsConstants.CUSTOM_E_INVOICE_ERROR_REPORT
                                .equals(vendorInvoiceInputReportsReq.getReportId())) {
                    cs = con.prepareCall(
                                    "{call report_custom_invoice_einvoice_register_error(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                    cs.setLong(1, Integer.valueOf(vendorInvoiceInputReportsReq.getGstinOrPan()));
                    cs.setString(2, gstinList);
                    cs.setString(3, pan);
                    cs.setString(4, vendorInvoiceInputReportsReq.getYearOrMonth());
                    cs.setString(5, yearOrMonthList);
                    cs.setString(6, mstDatabseName);
                    cs.setString(7, vendorInvoiceInputReportsReq.getReportId());
                    cs.setString(8, customOrDefault);
                    cs.setString(9, exportType);
                    // pld_template_id for e_invoice
                    cs.setInt(10, 1);
                    cs.setInt(11, vendorInvoiceInputReportsReq.getCustomTemplateId());
                    cs.setString(12, vendorInvoiceInputReportsReq.getUserId());
                    cs.setString(13, vendorInvoiceInputReportsReq.getDateFrom());
                    cs.setString(14, vendorInvoiceInputReportsReq.getDateTo());
                    cs.setInt(15, vendorInvoiceInputReportsReq.getSize());
                    cs.setInt(16, vendorInvoiceInputReportsReq.getPage() * vendorInvoiceInputReportsReq.getSize());
                } else if (ReportsConstants.CUSTOM_E_WAY_BILL_ERROR_REPORT
                                .equals(vendorInvoiceInputReportsReq.getReportId())) {
                    cs = con.prepareCall(
                                    "{call report_custom_invoice_input_ewaybill_register_error(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                    cs.setLong(1, Integer.valueOf(vendorInvoiceInputReportsReq.getGstinOrPan()));
                    cs.setString(2, gstinList);
                    cs.setString(3, pan);
                    cs.setString(4, vendorInvoiceInputReportsReq.getYearOrMonth());
                    cs.setString(5, yearOrMonthList);
                    cs.setString(6, mstDatabseName);
                    cs.setString(7, vendorInvoiceInputReportsReq.getReportId());
                    cs.setString(8, customOrDefault);
                    cs.setString(9, exportType);
                    // pld_template_id for e_way_bill
                    cs.setInt(10, 2);
                    cs.setInt(11, vendorInvoiceInputReportsReq.getCustomTemplateId());
                    cs.setString(12, vendorInvoiceInputReportsReq.getUserId());
                    cs.setInt(13, vendorInvoiceInputReportsReq.getSize());
                    cs.setInt(14, vendorInvoiceInputReportsReq.getPage() * vendorInvoiceInputReportsReq.getSize());
                }
                callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                return cs;
            }

        }, new CallableStatementCallback<Map<String, Object>>() {

            @Override
            public Map<String, Object> doInCallableStatement(CallableStatement cs) throws SQLException {
                // Execute the stored procedure call
                boolean hasResults = cs.execute();
                ResultSet rs = null;
                ResultSet rs1 = null;
                Map<String, Object> nameAndFile = new HashMap<>();

                if (vendorInvoiceInputReportsReq.getDownloadType().isBlank()) {
                    vendorInvoiceInputReportsReq.setDownloadType("xlsx");
                }

                if (hasResults) {

                    rs1 = cs.getResultSet();
                    List<String> reportDetails = new ArrayList<>();

                    while (rs1.next()) {
                        String detail1 = rs1.getString(1);
                        reportDetails.add(detail1);

                    }
                    hasResults = cs.getMoreResults();

                    if (ReportsConstants.EXCEL.equals(vendorInvoiceInputReportsReq.getDownloadType())) {
                        try (XSSFWorkbook workbook = new XSSFWorkbook()) {

                            rs = cs.getResultSet();

                            // Get the metadata for the result set
                            ResultSetMetaData metadata = rs.getMetaData();
                            int columnCount = metadata.getColumnCount();

                            XSSFSheet sheet = workbook.createSheet(fileName);
                            reportModuleCommonRepo.setFilterAndFredgeHeader(sheet,
                                            new CellRangeAddress(4, 4, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, reportDetails.size() - 1));
                            Map<String, Object> bothHeadersStyles = reportModuleCommonRepo.getHeadersStyles(workbook,
                                            sheet);
                            CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE1);
                            CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE2);
                            CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE3);

                            Row topheader = sheet.createRow(3);
                            Cell cell1 = topheader.createCell(0);
                            cell1.setCellValue(fileName);
                            cell1.setCellStyle(headerCellStyle1);

                            // Create header row
                            Row headerRow = sheet.createRow(4);
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                Cell cell = headerRow.createCell(i - 1);
                                cell.setCellValue(columnName);
                                cell.setCellStyle(headerCellStyle2);
                            }

                            // Process and write rows
                            int rowNum = 5;
                            while (rs.next()) {
                                Row row = sheet.createRow(rowNum);
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    Cell cell = row.createCell(i - 1);
                                    cell.setCellValue(cellValue);
                                    cell.setCellStyle(headerCellStyle3);
                                }
                                rowNum++;
                            }
                            for (int i = 0; i <= columnCount; i++) {
                                sheet.autoSizeColumn(i);
                            }
                            Row searchParameter = sheet.createRow(0);
                            Cell searchParametercell = searchParameter.createCell(0);
                            searchParametercell.setCellValue(greeting);
                            searchParametercell.setCellStyle(headerCellStyle2);
                            Row deatails = sheet.createRow(1);
                            for (int i = 0; i < reportDetails.size(); i++) {

                                Cell cell = deatails.createCell(i);
                                cell.setCellValue(reportDetails.get(i));
                                cell.setCellStyle(headerCellStyle3);

                            }

                            // Write workbook to file
                            try (FileOutputStream out = new FileOutputStream(new File(tempFolder
                                            + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp)))) {
                                workbook.write(out);

                                File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                                + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp));

                                try (InputStream fis = new FileInputStream(file)) {
                                    client.getClient(storageCredentials)
                                                    .blobName(reportModuleCommonRepo.getReportsExcelFileName(fileName,
                                                                    timeStamp))
                                                    .buildClient().upload(fis, file.length());
                                    nameAndFile.put(ReportsConstants.FILENAME, reportModuleCommonRepo
                                                    .getReportsExcelFileName(fileName, timeStamp));
                                    nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                    reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                    return nameAndFile;
                                }

                            }
                        } catch (IOException e) {
                            log.error(errorInGeneratingExcelWorkbook, e);
                        }
                    } else {
                        rs = cs.getResultSet();

                        // Get the metadata for the result set
                        ResultSetMetaData metadata = rs.getMetaData();
                        int columnCount = metadata.getColumnCount();

                        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        try (CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format)) {
                            csvPrinter.printRecord(greeting);
                            csvPrinter.printRecord(reportDetails.toArray());
                            csvPrinter.printRecord();

                            // Create header row
                            String[] headerRow = new String[columnCount];
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                headerRow[i - 1] = columnName;
                            }
                            csvPrinter.printRecord((Object[]) headerRow);

                            while (rs.next()) {
                                String[] rowData = new String[columnCount];
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    rowData[i - 1] = cellValue;
                                }
                                csvPrinter.printRecord((Object[]) rowData);
                            }

                            csvPrinter.flush();

                            InputStream inputStream = new ByteArrayInputStream(out.toByteArray());

                            Files.copy(inputStream, Paths.get(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp)));

                            File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));

                            try (InputStream fis = new FileInputStream(file)) {
                                client.getClient(storageCredentials).blobName(
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp))
                                                .buildClient().upload(fis, file.length());
                                nameAndFile.put(ReportsConstants.FILENAME,
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));
                                nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                return nameAndFile;
                            }
                        } catch (IOException e1) {
                            log.error(errorInGeneratingCSVFile, e1);

                        }
                    }
                }
                return nameAndFile;
            }
        });

    }

    @Override
    @Async
    @Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
    public void getGenerateBackgroundVendorInvoiceInputReports(
                    VendorInvoiceInputReportsReqDTO vendorInvoiceInputReportsReq, String gstinList, String pan,
                    String monthList, Timestamp timeStamp, String containerName, String fileName, Long totalcount,
                    BigInteger id) {
        try {

            getGenerateExcelOrCsvFileofEInvoiceInputReports(vendorInvoiceInputReportsReq, gstinList, pan, monthList,
                            timeStamp, containerName, fileName);
            reportModuleCommonRepo.updateBackGroundDetails(
                            reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp), totalcount,
                            ReportsConstants.COMPLETED, fileName, vendorInvoiceInputReportsReq.getUserId(), timeStamp,
                            id);
            reportModuleCommonRepo.insertDetailsIntoMailBox1(vendorInvoiceInputReportsReq.getUserId(), fileName,
                            timeStamp);
            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORINVOICEMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_COMPLETE,
                            Integer.valueOf(vendorInvoiceInputReportsReq.getUserId()),
                            Integer.valueOf(vendorInvoiceInputReportsReq.getUserId()),
                            Integer.valueOf(vendorInvoiceInputReportsReq.getUserId()),
                            ReportsConstants.NOTIFICATION_SUCCESS);
        } catch (Exception e) {
            reportModuleCommonRepo.updateBackGroundDetails(
                            reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp), totalcount,
                            ReportsConstants.ERROR, fileName, vendorInvoiceInputReportsReq.getUserId(), timeStamp, id);
            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORINVOICEMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_ERROR,
                            Integer.valueOf(vendorInvoiceInputReportsReq.getUserId()),
                            Integer.valueOf(vendorInvoiceInputReportsReq.getUserId()),
                            Integer.valueOf(vendorInvoiceInputReportsReq.getUserId()),
                            ReportsConstants.NOTIFICATION_ERROR);
        }

    }

    @Override
    public Map<String, Object> getGenerateExcelOrCsvFileofVendorInvoiceGetReports(
                    VendorInvoiceGetReqDTO vendorInvoiceGETReportsReq, String gstinList1, String yearOrMonthList,
                    String category, Timestamp timeStamp, String containerName, String fileName) {
        AzureConnectionCredentialsDTO storageCredentials = reportModuleCommonRepo
                        .getAzureCredentialFromDB(vendorInvoiceGETReportsReq.getEntityId(), "blob");

        String fileUrl = reportModuleCommonRepo.getFileUrl();

        String exportType = ReportsConstants.EXPORT;
        String customOrDefault = reportModuleCommonRepo.getCustomOrDefault(vendorInvoiceGETReportsReq.getReportId());
        key = reportModuleCommonRepo.getKeyFromKeyHolder();

        return jdbcTemplateTrn.execute(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {

                if (ReportsConstants.GSTR2A_REPORT.equals(vendorInvoiceGETReportsReq.getReportId())) {
                    cs = con.prepareCall("{call report_invoice_get_gstr2a (?,?,?,?,?,?,?,?,?,?,?,?)}");
                    cs.setString(1, gstinList1);
                    cs.setString(2, vendorInvoiceGETReportsReq.getYearOrMonth());
                    if (vendorInvoiceGETReportsReq.getYearOrMonth().equals(ReportsConstants.YEAR)) {
                        cs.setString(3, yearOrMonthList);
                        cs.setString(4, "");
                    } else {
                        cs.setString(3, "");
                        cs.setString(4, yearOrMonthList);
                    }
                    cs.setString(5, vendorInvoiceGETReportsReq.getReportId());
                    cs.setString(6, mstDatabseName);
                    cs.setString(7, customOrDefault);
                    cs.setString(8, vendorInvoiceGETReportsReq.getUserId());
                    cs.setString(9, exportType);
                    cs.setString(10, category);
                    cs.setInt(11, vendorInvoiceGETReportsReq.getSize());
                    cs.setInt(12, vendorInvoiceGETReportsReq.getPage() * vendorInvoiceGETReportsReq.getSize());

                } else if (ReportsConstants.GSTR2B_REPORT.equals(vendorInvoiceGETReportsReq.getReportId())) {

                    cs = con.prepareCall("{call report_invoice_get_gstr2b (?,?,?,?,?,?,?,?,?,?,?,?)}");
                    cs.setString(1, gstinList1);
                    cs.setString(2, vendorInvoiceGETReportsReq.getYearOrMonth());
                    if (vendorInvoiceGETReportsReq.getYearOrMonth().equals(ReportsConstants.YEAR)) {
                        cs.setString(3, yearOrMonthList);
                        cs.setString(4, "");
                    } else {
                        cs.setString(3, "");
                        cs.setString(4, yearOrMonthList);
                    }
                    cs.setString(5, vendorInvoiceGETReportsReq.getReportId());
                    cs.setString(6, mstDatabseName);
                    cs.setString(7, customOrDefault);
                    cs.setString(8, vendorInvoiceGETReportsReq.getUserId());
                    cs.setString(9, exportType);
                    cs.setString(10, category);
                    cs.setInt(11, vendorInvoiceGETReportsReq.getSize());
                    cs.setInt(12, vendorInvoiceGETReportsReq.getPage() * vendorInvoiceGETReportsReq.getSize());

                } else if (ReportsConstants.GET_E_WAY_BILL_REPORT.equals(vendorInvoiceGETReportsReq.getReportId())) {
                    cs = con.prepareCall("{call report_invoice_get_ewaybill(?,?,?,?,?,?,?,?,?,?,?,?)}");

                    cs.setString(1, gstinList1);
                    cs.setString(2, vendorInvoiceGETReportsReq.getYearOrMonth());
                    if (vendorInvoiceGETReportsReq.getYearOrMonth().equals(ReportsConstants.YEAR)) {
                        cs.setString(3, yearOrMonthList);
                        cs.setString(4, "");
                    } else {
                        cs.setString(3, "");
                        cs.setString(4, yearOrMonthList);
                    }
                    cs.setString(5, vendorInvoiceGETReportsReq.getReportId());
                    cs.setString(6, mstDatabseName);
                    cs.setString(7, customOrDefault);
                    cs.setString(8, vendorInvoiceGETReportsReq.getUserId());
                    cs.setString(9, exportType);
                    cs.setString(10, vendorInvoiceGETReportsReq.getSummaryType());

                    cs.setInt(11, vendorInvoiceGETReportsReq.getSize());
                    cs.setInt(12, vendorInvoiceGETReportsReq.getPage() * vendorInvoiceGETReportsReq.getSize());
                }
                callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                return cs;

            }

        }, new CallableStatementCallback<Map<String, Object>>() {

            @Override
            public Map<String, Object> doInCallableStatement(CallableStatement cs) throws SQLException {
                // Execute the stored procedure call
                boolean hasResults = cs.execute();
                ResultSet rs = null;
                ResultSet rs1 = null;
                Map<String, Object> nameAndFile = new HashMap<>();

                if (vendorInvoiceGETReportsReq.getDownloadType().isBlank()) {
                    vendorInvoiceGETReportsReq.setDownloadType("xlsx");
                }

                if (hasResults) {

                    rs1 = cs.getResultSet();
                    List<String> reportDetails = new ArrayList<>();

                    while (rs1.next()) {
                        String detail1 = rs1.getString(1);
                        reportDetails.add(detail1);

                    }
                    hasResults = cs.getMoreResults();

                    if (ReportsConstants.EXCEL.equals(vendorInvoiceGETReportsReq.getDownloadType())) {
                        try (XSSFWorkbook workbook = new XSSFWorkbook()) {

                            rs = cs.getResultSet();

                            // Get the metadata for the result set
                            ResultSetMetaData metadata = rs.getMetaData();
                            int columnCount = metadata.getColumnCount();

                            XSSFSheet sheet = workbook.createSheet(fileName);
                            reportModuleCommonRepo.setFilterAndFredgeHeader(sheet,
                                            new CellRangeAddress(4, 4, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, reportDetails.size() - 1));
                            Map<String, Object> bothHeadersStyles = reportModuleCommonRepo.getHeadersStyles(workbook,
                                            sheet);
                            CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE1);
                            CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE2);
                            CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE3);

                            Row topheader = sheet.createRow(3);
                            Cell cell1 = topheader.createCell(0);
                            cell1.setCellValue(fileName);
                            cell1.setCellStyle(headerCellStyle1);

                            // Create header row
                            Row headerRow = sheet.createRow(4);
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                Cell cell = headerRow.createCell(i - 1);
                                cell.setCellValue(columnName);
                                cell.setCellStyle(headerCellStyle2);
                            }

                            // Process and write rows
                            int rowNum = 5;
                            while (rs.next()) {
                                Row row = sheet.createRow(rowNum);
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    Cell cell = row.createCell(i - 1);
                                    cell.setCellValue(cellValue);
                                    cell.setCellStyle(headerCellStyle3);
                                }
                                rowNum++;
                            }
                            for (int i = 0; i <= columnCount; i++) {
                                sheet.autoSizeColumn(i);
                            }

                            Row searchParameter = sheet.createRow(0);
                            Cell searchParametercell = searchParameter.createCell(0);
                            searchParametercell.setCellValue(greeting);
                            searchParametercell.setCellStyle(headerCellStyle2);
                            Row deatails = sheet.createRow(1);
                            for (int i = 0; i < reportDetails.size(); i++) {

                                Cell cell = deatails.createCell(i);
                                cell.setCellValue(reportDetails.get(i));
                                cell.setCellStyle(headerCellStyle3);

                            }

                            // Write workbook to file
                            try (FileOutputStream out = new FileOutputStream(new File(tempFolder
                                            + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp)))) {
                                workbook.write(out);

                                File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                                + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp));

                                try (InputStream fis = new FileInputStream(file)) {
                                    client.getClient(storageCredentials)
                                                    .blobName(reportModuleCommonRepo.getReportsExcelFileName(fileName,
                                                                    timeStamp))
                                                    .buildClient().upload(fis, file.length());
                                    nameAndFile.put(ReportsConstants.FILENAME, reportModuleCommonRepo
                                                    .getReportsExcelFileName(fileName, timeStamp));
                                    nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                    reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                    return nameAndFile;
                                }

                            }
                        } catch (IOException e) {
                            log.error(errorInGeneratingExcelWorkbook, e);
                        }
                    } else {
                        rs = cs.getResultSet();

                        // Get the metadata for the result set
                        ResultSetMetaData metadata = rs.getMetaData();
                        int columnCount = metadata.getColumnCount();

                        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        try (CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format)) {
                            csvPrinter.printRecord(greeting);
                            csvPrinter.printRecord(reportDetails.toArray());
                            csvPrinter.printRecord();

                            // Create header row
                            String[] headerRow = new String[columnCount];
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                headerRow[i - 1] = columnName;
                            }
                            csvPrinter.printRecord((Object[]) headerRow);

                            while (rs.next()) {
                                String[] rowData = new String[columnCount];
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    rowData[i - 1] = cellValue;
                                }
                                csvPrinter.printRecord((Object[]) rowData);
                            }

                            csvPrinter.flush();

                            InputStream inputStream = new ByteArrayInputStream(out.toByteArray());

                            Files.copy(inputStream, Paths.get(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp)));

                            File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));

                            try (InputStream fis = new FileInputStream(file)) {
                                client.getClient(storageCredentials).blobName(
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp))
                                                .buildClient().upload(fis, file.length());
                                nameAndFile.put(ReportsConstants.FILENAME,
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));
                                nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                return nameAndFile;
                            }
                        } catch (IOException e1) {
                            log.error(errorInGeneratingCSVFile, e1);

                        }
                    }
                }
                return nameAndFile;
            }
        });

    }

    @Override
    @Async
    @Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
    public void getGenerateBackgroundVendorInvoiceGetReports(VendorInvoiceGetReqDTO vendorInvoiceGETReportsReq,
                    String gstinList1, String yearOrMonthList, String category, Timestamp timeStamp,
                    String containerName, String fileName, Long totalcount, BigInteger id) {

        try {

            getGenerateExcelOrCsvFileofVendorInvoiceGetReports(vendorInvoiceGETReportsReq, gstinList1, yearOrMonthList,
                            category, timeStamp, containerName, fileName);
            reportModuleCommonRepo.updateBackGroundDetails(
                            reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp), totalcount,
                            ReportsConstants.COMPLETED, fileName, vendorInvoiceGETReportsReq.getUserId(), timeStamp,
                            id);
            reportModuleCommonRepo.insertDetailsIntoMailBox1(vendorInvoiceGETReportsReq.getUserId(), fileName,
                            timeStamp);
            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORINVOICEMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_COMPLETE,
                            Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                            Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                            Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                            ReportsConstants.NOTIFICATION_SUCCESS);
        } catch (Exception e) {
            reportModuleCommonRepo.updateBackGroundDetails(
                            reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp), totalcount,
                            ReportsConstants.ERROR, fileName, vendorInvoiceGETReportsReq.getUserId(), timeStamp, id);
            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORINVOICEMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_ERROR,
                            Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                            Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                            Integer.valueOf(vendorInvoiceGETReportsReq.getUserId()),
                            ReportsConstants.NOTIFICATION_ERROR);
        }

    }

    @Override
    public Map<String, Object> getGenerateExcelOrCsvFileofVendorInvoiceSyncReports(
                    VendorInvoiceSyncReqDTO vendorInvoiceSyncReq, String taxPayerGstinList, String vendorGstinList,
                    String yearOrMonthList, String category, Timestamp timeStamp, String containerName,
                    String fileName) {
        AzureConnectionCredentialsDTO storageCredentials = reportModuleCommonRepo
                        .getAzureCredentialFromDB(vendorInvoiceSyncReq.getEntityId(), "blob");

        String fileUrl = reportModuleCommonRepo.getFileUrl();

        String exportType = ReportsConstants.EXPORT;
        String customOrDefault = reportModuleCommonRepo.getCustomOrDefault(vendorInvoiceSyncReq.getReportId());
        key = reportModuleCommonRepo.getKeyFromKeyHolder();

        return jdbcTemplateTrn.execute(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {

                if (ReportsConstants.MAPPED_WITH_GSTR2A_BUT_NOT_MAPPED_WITH_GET_E_WAY_BILL_AND_GSTR2B
                                .equals(vendorInvoiceSyncReq.getReportId())) {
                    cs = con.prepareCall("{call report_invoice_sync_gstr2a (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                } else if (ReportsConstants.MAPPED_WITH_GSTR2A_AND_GSTR2B_BUT_NOT_MAPPED_WITH_GET_E_WAY_BILL
                                .equals(vendorInvoiceSyncReq.getReportId())) {
                    cs = con.prepareCall("{call report_invoice_sync_gstr2a_gstr2b(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                } else if (ReportsConstants.MAPPED_WITH_GET_E_WAY_BILL_BUT_NOT_MAPPED_WITH_GSTR2A_AND_GSTR2B
                                .equals(vendorInvoiceSyncReq.getReportId())) {
                    cs = con.prepareCall("{call report_invoice_sync_ewaybill (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                } else if (ReportsConstants.MAPPED_WITH_GSTR2B_BUT_NOT_MAPPED_WITH_GSTR2A_AND_GET_E_WAY_BILL
                                .equals(vendorInvoiceSyncReq.getReportId())) {
                    cs = con.prepareCall("{call report_invoice_sync_gstr2b (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                } else if (ReportsConstants.MAPPED_WITH_GET_E_WAY_BILL_AND_GSTR2B_BUT_NOT_MAPPED_WITH_GSTR2A
                                .equals(vendorInvoiceSyncReq.getReportId())) {
                    cs = con.prepareCall("{call report_invoice_sync_gstr2b_ewaybill(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                } else if (ReportsConstants.MAPPED_WITH_GET_E_WAY_BILL_AND_GSTR2A_BUT_NOT_MAPPED_WITH_GSTR2B
                                .equals(vendorInvoiceSyncReq.getReportId())) {
                    cs = con.prepareCall("{call report_invoice_sync_gstr2a_ewaybill (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                } else if (ReportsConstants.MAPPED_WITH_GET_E_WAY_BILL_AND_GSTR2A_AND_GSTR2B
                                .equals(vendorInvoiceSyncReq.getReportId())) {
                    cs = con.prepareCall(
                                    "{call report_invoice_sync_gstr2a_gstr2b_ewaybill(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                }

                cs.setString(1, taxPayerGstinList);
                cs.setString(2, vendorGstinList);
                cs.setString(3, vendorInvoiceSyncReq.getYearOrMonth());
                if (vendorInvoiceSyncReq.getYearOrMonth().equals(ReportsConstants.YEAR)) {
                    cs.setString(4, yearOrMonthList);
                    cs.setString(5, "");
                } else {
                    cs.setString(4, "");
                    cs.setString(5, yearOrMonthList);
                }
                cs.setString(6, vendorInvoiceSyncReq.getReportId());
                cs.setString(7, mstDatabseName);
                cs.setString(8, customOrDefault);
                cs.setString(9, vendorInvoiceSyncReq.getUserId());
                cs.setString(10, exportType);
                cs.setString(11, category);
                cs.setString(12, vendorInvoiceSyncReq.getSummaryType());
                cs.setString(13, vendorInvoiceSyncReq.getPeriodTypeCD());
                cs.setInt(14, vendorInvoiceSyncReq.getSize());
                cs.setInt(15, vendorInvoiceSyncReq.getPage() * vendorInvoiceSyncReq.getSize());

                callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                return cs;
            }

        }, new CallableStatementCallback<Map<String, Object>>() {

            @Override
            public Map<String, Object> doInCallableStatement(CallableStatement cs) throws SQLException {
                // Execute the stored procedure call
                boolean hasResults = cs.execute();
                ResultSet rs = null;
                ResultSet rs1 = null;
                Map<String, Object> nameAndFile = new HashMap<>();

                if (vendorInvoiceSyncReq.getDownloadType().isBlank()) {
                    vendorInvoiceSyncReq.setDownloadType("xlsx");
                }

                if (hasResults) {

                    rs1 = cs.getResultSet();
                    List<String> reportDetails = new ArrayList<>();

                    while (rs1.next()) {
                        String detail1 = rs1.getString(1);
                        reportDetails.add(detail1);

                    }
                    hasResults = cs.getMoreResults();

                    if (ReportsConstants.EXCEL.equals(vendorInvoiceSyncReq.getDownloadType())) {
                        try (XSSFWorkbook workbook = new XSSFWorkbook()) {

                            rs = cs.getResultSet();

                            // Get the metadata for the result set
                            ResultSetMetaData metadata = rs.getMetaData();
                            int columnCount = metadata.getColumnCount();

                            XSSFSheet sheet = workbook.createSheet(fileName);
                            reportModuleCommonRepo.setFilterAndFredgeHeader(sheet,
                                            new CellRangeAddress(4, 4, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, reportDetails.size() - 1));
                            Map<String, Object> bothHeadersStyles = reportModuleCommonRepo.getHeadersStyles(workbook,
                                            sheet);
                            CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE1);
                            CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE2);
                            CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE3);

                            Row topheader = sheet.createRow(3);
                            Cell cell1 = topheader.createCell(0);
                            cell1.setCellValue(fileName);
                            cell1.setCellStyle(headerCellStyle1);

                            // Create header row
                            Row headerRow = sheet.createRow(4);
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                Cell cell = headerRow.createCell(i - 1);
                                cell.setCellValue(columnName);
                                cell.setCellStyle(headerCellStyle2);
                            }

                            // Process and write rows
                            int rowNum = 5;
                            while (rs.next()) {
                                Row row = sheet.createRow(rowNum);
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    Cell cell = row.createCell(i - 1);
                                    cell.setCellValue(cellValue);
                                    cell.setCellStyle(headerCellStyle3);
                                }
                                rowNum++;
                            }
                            for (int i = 0; i <= columnCount; i++) {
                                sheet.autoSizeColumn(i);
                            }

                            Row searchParameter = sheet.createRow(0);
                            Cell searchParametercell = searchParameter.createCell(0);
                            searchParametercell.setCellValue(greeting);
                            searchParametercell.setCellStyle(headerCellStyle2);
                            Row deatails = sheet.createRow(1);
                            for (int i = 0; i < reportDetails.size(); i++) {

                                Cell cell = deatails.createCell(i);
                                cell.setCellValue(reportDetails.get(i));
                                cell.setCellStyle(headerCellStyle3);

                            }

                            // Write workbook to file
                            try (FileOutputStream out = new FileOutputStream(new File(tempFolder
                                            + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp)))) {
                                workbook.write(out);

                                File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                                + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp));

                                try (InputStream fis = new FileInputStream(file)) {
                                    client.getClient(storageCredentials)
                                                    .blobName(reportModuleCommonRepo.getReportsExcelFileName(fileName,
                                                                    timeStamp))
                                                    .buildClient().upload(fis, file.length());
                                    nameAndFile.put(ReportsConstants.FILENAME, reportModuleCommonRepo
                                                    .getReportsExcelFileName(fileName, timeStamp));
                                    nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                    reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                    return nameAndFile;
                                }

                            }
                        } catch (IOException e) {
                            log.error(errorInGeneratingExcelWorkbook, e);
                        }
                    } else {
                        rs = cs.getResultSet();

                        // Get the metadata for the result set
                        ResultSetMetaData metadata = rs.getMetaData();
                        int columnCount = metadata.getColumnCount();

                        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        try (CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format)) {
                            csvPrinter.printRecord(greeting);
                            csvPrinter.printRecord(reportDetails.toArray());
                            csvPrinter.printRecord();

                            // Create header row
                            String[] headerRow = new String[columnCount];
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                headerRow[i - 1] = columnName;
                            }
                            csvPrinter.printRecord((Object[]) headerRow);

                            while (rs.next()) {
                                String[] rowData = new String[columnCount];
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    rowData[i - 1] = cellValue;
                                }
                                csvPrinter.printRecord((Object[]) rowData);
                            }

                            csvPrinter.flush();

                            InputStream inputStream = new ByteArrayInputStream(out.toByteArray());

                            Files.copy(inputStream, Paths.get(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp)));

                            File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));

                            try (InputStream fis = new FileInputStream(file)) {
                                client.getClient(storageCredentials).blobName(
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp))
                                                .buildClient().upload(fis, file.length());
                                nameAndFile.put(ReportsConstants.FILENAME,
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));
                                nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                return nameAndFile;
                            }
                        } catch (IOException e1) {
                            log.error(errorInGeneratingCSVFile, e1);

                        }
                    }
                }
                return nameAndFile;
            }
        });

    }

    @Override
    @Async
    @Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
    public void getGenerateBackgroundExcelOrCsvFileofVendorInvoiceSyncReports(
                    VendorInvoiceSyncReqDTO vendorInvoiceSyncReq, String taxPayerGstinList, String vendorGstinList,
                    String yearOrMonthList, String category, Timestamp timeStamp, String containerName, String fileName,
                    Long totalcount, BigInteger id) {

        try {

            getGenerateExcelOrCsvFileofVendorInvoiceSyncReports(vendorInvoiceSyncReq, taxPayerGstinList,
                            vendorGstinList, yearOrMonthList, category, timeStamp, containerName, fileName);
            reportModuleCommonRepo.updateBackGroundDetails(
                            reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp), totalcount,
                            ReportsConstants.COMPLETED, fileName, vendorInvoiceSyncReq.getUserId(), timeStamp, id);
            reportModuleCommonRepo.insertDetailsIntoMailBox1(vendorInvoiceSyncReq.getUserId(), fileName, timeStamp);
            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORINVOICEMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_COMPLETE,
                            Integer.valueOf(vendorInvoiceSyncReq.getUserId()),
                            Integer.valueOf(vendorInvoiceSyncReq.getUserId()),
                            Integer.valueOf(vendorInvoiceSyncReq.getUserId()), ReportsConstants.NOTIFICATION_SUCCESS);
        } catch (Exception e) {
            reportModuleCommonRepo.updateBackGroundDetails(
                            reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp), totalcount,
                            ReportsConstants.ERROR, fileName, vendorInvoiceSyncReq.getUserId(), timeStamp, id);
            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORINVOICEMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_ERROR,
                            Integer.valueOf(vendorInvoiceSyncReq.getUserId()),
                            Integer.valueOf(vendorInvoiceSyncReq.getUserId()),
                            Integer.valueOf(vendorInvoiceSyncReq.getUserId()), ReportsConstants.NOTIFICATION_ERROR);
        }

    }

}
