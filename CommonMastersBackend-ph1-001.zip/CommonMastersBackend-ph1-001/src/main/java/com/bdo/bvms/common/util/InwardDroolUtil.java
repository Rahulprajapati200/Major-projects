package com.bdo.bvms.common.util;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.common.constant.StringConstant;

public class InwardDroolUtil {

    // "check if the gstin is in correct format"
    // Customer GSTIN validate
    public boolean validGSTIN(String gstin) {

        try {

            if (!"0".equals(gstin)) {

                String gstinformatRegex = StringConstant.GSTINFORMAT_REGEX;
                
                String tdsREGEX = StringConstant.TDSREGEX;

                boolean isValidFormat = false;

                if (gstin.length() < 15) {
                    return isValidFormat;
                }

                if (checkPattern(gstin, gstinformatRegex) || checkPattern(gstin, tdsREGEX)) {
                    isValidFormat = verifyCheckDigit(gstin);
                } 
                return isValidFormat;

            }

        } catch (Exception ex) {
            return false;
        }

        return true;
    }

    public boolean checkPattern(String inputval, String regxpatrn) {
        boolean result = false;
        if ((inputval.trim()).matches(regxpatrn)) {
            result = true;
        }
        return result;
    }

    public boolean verifyCheckDigit(String gstinWCheckDigit) {
        Boolean isCDValid = false;
        String newGstninWCheckDigit = getGSTINWithCheckDigit(
                        gstinWCheckDigit.substring(0, gstinWCheckDigit.length() - 1));
        if (gstinWCheckDigit.trim().equals(newGstninWCheckDigit)) {
            isCDValid = true;
        } 

        return isCDValid;
    }

    public String getGSTINWithCheckDigit(String gstinWOCheckDigit) {

        String gstnCodepointChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        int factor = 2;
        int sum = 0;
        int checkCodePoint = 0;
        char[] cpChars;
        char[] inputChars;

        if (gstinWOCheckDigit == null) {

            return "";
        }
        cpChars = gstnCodepointChars.toCharArray();
        inputChars = gstinWOCheckDigit.trim().toUpperCase().toCharArray();

        int mod = cpChars.length;
        for (int i = inputChars.length - 1; i >= 0; i--) {
            int codePoint = -1;

            for (int j = 0; j < cpChars.length; j++) {
                if (cpChars[j] == inputChars[i]) {
                    codePoint = j;
                }
            }
            int digit = factor * codePoint;
            factor = (factor == 2) ? 1 : 2;
            digit = (digit / mod) + (digit % mod);
            sum += digit;
        }
        checkCodePoint = (mod - (sum % mod)) % mod;

        return gstinWOCheckDigit + cpChars[checkCodePoint];

    }

    public boolean isAlphanumeric(String s) {

        boolean validInvoice = true;
        if (StringUtils.isBlank(s)) {
            validInvoice = false;
        }

        if (validInvoice) {

            Pattern p = Pattern.compile("[^0-9A-Za-z]");
            Matcher m = p.matcher(s);
            if (m.find()) {
                validInvoice = false;
            }
        }
        return validInvoice;
    }

    public boolean checkLength12G(String value) {
        boolean isValid = true;
        DecimalFormat df2 = new DecimalFormat(".##");
        boolean result = onlyNumeric(value);

        try {
            if (result && df2.format(Double.parseDouble(value)).length() > 12) {

                isValid = false;

            }
        } catch (Exception ex) {
            isValid = false;
        }

        return isValid;
    }

//E-way bill Number should be 12 digits numeric

    public boolean onlyNumeric(String value) {
        boolean isValid = true;
        if (StringUtils.isBlank(value)) {
            isValid = false;
        } else {
            Pattern p = Pattern.compile(StringConstant.ONLYNUMERIC);
            Matcher m = p.matcher(value);

            if (m.find()) {
                isValid = false;
            }

        }

        return isValid;
    }

//E-way bill Number field is blank or more than 12 digits 

    public boolean checklenth12ebNo(String value) {
        boolean isvalid = true;
        if (value != null && value.length() > 12) {
            isvalid = false;
        }

        return isvalid;
    }

// date should not be empty or should not contain any character value or special
// character except -,/

    public boolean isDateEmpty(String value) {
        boolean isValid = Boolean.TRUE;

        try {
            if (value.equals("-")) {
                isValid = Boolean.FALSE;
            }
            if (StringUtils.isBlank(value)) {
                isValid = Boolean.FALSE;
            }

            return isValid;
        } catch (Exception e) {
            return Boolean.FALSE;
        }

    }
//18AABCU9603R1ZM
//e Way bill valid till can contain only the special character - / :

    public boolean ifeWayBillValidTillIsValid(String value) {
        boolean valid = Boolean.TRUE;
        if (value.matches(StringConstant.SPECIALCHARACTERS)) {
            valid = Boolean.FALSE;
        }
        return valid;

    }

//"doc date should be in DD-MM-YYYY format"

    public boolean isValidDocDate(String value) {

        if (value.matches(StringConstant.NONVALIDDATEFORMAT) || "-".equals(value)) {
            return false;
        } else {
            try {
                if (value.indexOf("-") > -1) {
                    String[] parts = value.trim().split("-");
                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        int date = Integer.parseInt(parts[0]);
                        int month = Integer.parseInt(parts[1]);
                        int year = Integer.parseInt(parts[2]);
                        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                            Calendar c = Calendar.getInstance();
                            c.set(Calendar.DAY_OF_MONTH, date);
                            c.set(Calendar.MONTH, month - 1);
                            c.set(Calendar.YEAR, year);

                            SimpleDateFormat formatter = new SimpleDateFormat(StringConstant.VALIDDATEFORMAT);
                            formatter.setLenient(false);
                            formatter.parse(value);
                            return true;

                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                } else {
                    String[] parts = value.trim().split("/");
                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        int date = Integer.parseInt(parts[0]);
                        int month = Integer.parseInt(parts[1]);
                        int year = Integer.parseInt(parts[2]);
                        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                            Calendar c = Calendar.getInstance();
                            c.set(Calendar.DAY_OF_MONTH, date);
                            c.set(Calendar.MONTH, month - 1);
                            c.set(Calendar.YEAR, year);

                            SimpleDateFormat formatter = new SimpleDateFormat(StringConstant.SIMPLEDATEFORMAT1);
                            formatter.setLenient(false);
                            formatter.parse(value);
                            return true;

                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                }

            } catch (Exception ex) {
                return false;
            }
        }

    }

    // "check if the gstin is blank"
    public boolean isGstinBlank(String gstinNo) {
        boolean valid = Boolean.TRUE;
        if ("".equals(gstinNo) || "0".equals(gstinNo)) {
            valid = Boolean.FALSE;
        }
        return valid;

    }

    // E-way bill Date cannot be before 1st July 2017

    public boolean isValidDateRange(String geteWayBillDate) {
        SimpleDateFormat sdformat = new SimpleDateFormat(StringConstant.VALIDDATEFORMAT);
        try {
            if (StringUtils.isBlank(geteWayBillDate)) {
                return false;
            }
            Date d1 = sdformat.parse("01-07-2017");
            Date d2 = sdformat.parse(geteWayBillDate);

            if (d1.compareTo(d2) > 0) {

                return false;
            }

        } catch (ParseException e) {

            return false;
        }
        return true;
    }

//E-way bill Date cannot be future date

    public boolean ifFutureDate(String geteWayBillDate) throws ParseException {
        boolean valid = Boolean.TRUE;
        SimpleDateFormat sdformat = new SimpleDateFormat(StringConstant.VALIDDATEFORMAT);

        Date currentDate = new Date();
        Date localDate = null;

        if (StringUtils.isNotBlank(geteWayBillDate)) {
            try {
                localDate = sdformat.parse(geteWayBillDate);
            } catch (ParseException e) {
                return Boolean.FALSE;
            }

            if (localDate.compareTo(currentDate) > 0) {
                valid = Boolean.FALSE;
            }
        }

        return valid;

    }

    // Purchase Order Date cannot exceed E-way bill Date

    public boolean ifExceedDate(String poDate, String geteWayBillDate) {
        SimpleDateFormat sdformat = new SimpleDateFormat(StringConstant.VALIDDATEFORMAT);
        try {
            if (StringUtils.isBlank(geteWayBillDate)) {
                return false;
            }
            if (StringUtils.isBlank(poDate)) {
                return false;
            }
            Date d1 = sdformat.parse(poDate);
            Date d2 = sdformat.parse(geteWayBillDate);

            if (d1.compareTo(d2) > 0) {

                return false;
            }

        } catch (ParseException e) {

            return false;
        }
        return true;
    }
}
