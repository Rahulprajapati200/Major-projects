package com.bdo.bvms.common.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Data
public class SaveCustomizeColumnListReqDTO extends BaseReqDTO {

    int screenId;
    int moduleId;
    List<FrontendCustomizeColumnListDTO> customizeColumnList = new ArrayList<>();
    int saveOrDefault;

}
