package com.bdo.bvms.common.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FinancialYearReqDTO extends BaseReqDTO {

    String financialYear;
    String defPageRecords="10";
    String searchFilterValues;    
}
