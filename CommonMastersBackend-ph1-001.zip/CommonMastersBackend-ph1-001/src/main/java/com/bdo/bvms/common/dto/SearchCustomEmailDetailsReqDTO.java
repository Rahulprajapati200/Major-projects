package com.bdo.bvms.common.dto;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SearchCustomEmailDetailsReqDTO extends BaseReqDTO {

	@NotNull(message = "{customTemplateId.notNull}")
	private Integer customTemplateId;
	

	//@NotNull(message = "{logoType.notNull}")
	private Integer logoType;
	
}
