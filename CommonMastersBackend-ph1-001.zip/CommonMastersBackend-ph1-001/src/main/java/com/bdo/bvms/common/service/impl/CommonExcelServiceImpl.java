package com.bdo.bvms.common.service.impl;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.exceptions.BVMSException;
import com.bdo.bvms.common.exceptions.CommonMasterBusinessException;
import com.bdo.bvms.common.service.ICommonExcelService;
import com.bdo.bvms.common.util.ExcelUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j

public class CommonExcelServiceImpl implements ICommonExcelService {

    @Value("${bvms.cloud.temp.file.download.path}")
    private String tempFolderPath;

    @SuppressWarnings("resource")
    @Override
    public List<String> getExcelTemplateHeaderList(File file, int headerRowNo) {
        List<String> headersList = new ArrayList<>();
        try {
            XSSFWorkbook wb = null;
            try (FileInputStream fis = new FileInputStream(file)) {
                wb = new XSSFWorkbook(fis);
            } // obtaining bytes from the file

            XSSFSheet sheet = wb.getSheetAt(0); // creating a Sheet object to
                                                // retrieve object
            List<Row> list = new ArrayList<>();
            Iterator<Row> rowIterator = sheet.rowIterator();
            rowIterator.forEachRemaining(list::add);
            if (!list.isEmpty()) {
                Row row = list.get(headerRowNo);
                Iterator<Cell> cellIterator = row.cellIterator();
                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();
                    String key = getCellValue(cell);
                    headersList.add(key);
                }
            }
            wb.close();
        } catch (Exception e) {
            throw new CommonMasterBusinessException("Error while reading headers from the file " + file.getName(), e);
        }
        return headersList;
    }

    public static String getCellValue(Cell cell) {
        switch (cell.getCellType()) {
        case STRING: // field that represents string cell type
            return cell.getStringCellValue();
        case NUMERIC: // field that represents number cell type
            return (BigDecimal.valueOf(cell.getNumericCellValue())).toString();
        case BOOLEAN:
            return String.valueOf(cell.getBooleanCellValue());
        default:
            return "";
        }
    }

    @SuppressWarnings("resource")
    @Override
    public Map<String, List<String>> readCustomTemplateSampleData(File file) throws BVMSException {
        Workbook workbook = null;
        Map<String, List<String>> previewMap = new LinkedHashMap<>();
        try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file))) {

            if (FilenameUtils.getExtension(file.getName()).endsWith(Constants.VENODR_DETAIL_TEMPLATE_FILE_TYPE_XLSX)) {
                workbook = new XSSFWorkbook(bis);
            } else {
                workbook = new HSSFWorkbook(bis);
            }

            Sheet sheet = workbook.getSheetAt(Constants.VENDOR_MASTER_TEMPLATE_SHEET_NO);
            DataFormatter dataFormatter = new DataFormatter();

            Map<String, Integer> map = new HashMap<>(); // Create map

            Row rowH = sheet.getRow(Constants.CUSTOM_VENDOR_DETAILS_EXCEL_HEADER_ROW_NO);
            int totalNonEmptyRow = ExcelUtils.getExcelNonEmptyRows(sheet);
            short minColIx = 0;
            short maxColIx = 0;

            minColIx = rowH.getFirstCellNum();
            // get the first column
            // index for a row
            maxColIx = rowH.getLastCellNum(); // get the last column index
                                              // for a row

            for (short colIx = minColIx; colIx < maxColIx; colIx++) {
                Cell cell = rowH.getCell(colIx); // get the cell
                map.put(dataFormatter.formatCellValue(cell), cell.getColumnIndex());
                previewMap.put(getCellValue(cell), new ArrayList<>());
            }
            Iterator<List<String>> columnsIterator;
            for (int i = 1; i < Math.min(totalNonEmptyRow, 6); i++) {
                Row row = sheet.getRow(i);
                columnsIterator = previewMap.values().iterator();
                for (int j = 0; j < maxColIx; j++) {
                    columnsIterator.next().add(row.getCell(j) == null ? "" : getCellValue(row.getCell(j)));
                }
            }

            return previewMap;
        } catch (Exception e) {
            log.error("Error while reading vendor master details template data");
            throw new BVMSException(e);
        } finally {
            if (workbook != null) {
                try {
                    workbook.close();
                } catch (IOException e) {
                    log.error("Error while colsing ");
                }
            }
        }

    }

    @Override
    public File writeExcelWithHeader(String fileName, char delimiter, List<String> headerList) {

        if (log.isDebugEnabled()) {

            log.debug("Reached to method writeExcelWithHeader ::" + fileName);

        }

        File file = new File(tempFolderPath);

        if (!file.exists()) {
            file.mkdir();
        }
        String tempFileName = "";

        if (StringUtils.isBlank(tempFolderPath)) {
            tempFileName = fileName;
        } else {

            tempFileName = new StringBuilder().append(tempFolderPath).append(File.separator).append(fileName)
                            .toString();

        }

        if (log.isDebugEnabled()) {
            log.debug("tempFileName file name ::" + tempFileName);
        }

        file = new File(tempFileName);
        // Create blank workbook
        XSSFWorkbook workbook = new XSSFWorkbook();

        // Create a blank sheet
        XSSFSheet spreadsheet = workbook.createSheet(Constants.EXCEL_SHEET_NAME);

        // Create row object

        XSSFRow row;

        // Iterate over data and write to sheet
        row = spreadsheet.createRow(0);

        int cellid = 0;

        for (String header : headerList) {
            Cell cell = row.createCell(cellid++);
            cell.setCellValue(header);
        }
        try (FileOutputStream out = new FileOutputStream(file)) {
            workbook.write(out);
        } catch (IOException e) {
            log.error("Generated Error:::" + e);
            throw new CommonMasterBusinessException("Error while writing custom template", e);
        } finally {
            try {
                workbook.close();
            } catch (IOException e) {
                log.error("Generated Error while closing workbook:::" + e);
            }
        }

        return file;

    }

}
