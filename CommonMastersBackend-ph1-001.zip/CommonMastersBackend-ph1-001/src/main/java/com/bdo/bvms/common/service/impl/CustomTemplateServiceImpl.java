package com.bdo.bvms.common.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.constant.StringConstant;
import com.bdo.bvms.common.dto.AddCustomTemplateColumnMappingReqDTO;
import com.bdo.bvms.common.dto.AddCustomTemplateColumnValueMappingReqDTO;
import com.bdo.bvms.common.dto.AddCustomTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.CustomEmailPlaceHoldersResDTO;
import com.bdo.bvms.common.dto.CustomEmailRefTemplateResDTO;
import com.bdo.bvms.common.dto.CustomEmailTemplateDetailsResDTO;
import com.bdo.bvms.common.dto.CustomEmailTemplateModulesResDTO;
import com.bdo.bvms.common.dto.CustomTemplateNameResDTO;
import com.bdo.bvms.common.dto.CustomTemplateOptionsResDTO;
import com.bdo.bvms.common.dto.DefaultEmailTemplateResDTO;
import com.bdo.bvms.common.dto.DeleteCustomTemplateReqDTO;
import com.bdo.bvms.common.dto.DisableCustomTemplateDTO;
import com.bdo.bvms.common.dto.DownloadCustomTemplateReqDTO;
import com.bdo.bvms.common.dto.EntityMasterResDTO;
import com.bdo.bvms.common.dto.GetModuleWiseTemplateDTO;
import com.bdo.bvms.common.dto.ModuleCodeAndNameDTO;
import com.bdo.bvms.common.dto.PaginationResDTO;
import com.bdo.bvms.common.dto.PickupDetailListResDTO;
import com.bdo.bvms.common.dto.PickupListDetailReqDTO;
import com.bdo.bvms.common.dto.PreviewCustomTemplateSampleDataReqDTO;
import com.bdo.bvms.common.dto.SearchByLkupcodeReqDTO;
import com.bdo.bvms.common.dto.SearchCustomEmailDetailsReqDTO;
import com.bdo.bvms.common.dto.SearchCustomEmailModulesReqDTO;
import com.bdo.bvms.common.dto.SearchCustomEmailPlaceHoldersReqDTO;
import com.bdo.bvms.common.dto.SearchCustomEmailRefTemplateReqDTO;
import com.bdo.bvms.common.dto.SearchCustomTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.SearchDefaultEmailTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.SearchModuleListReqDTO;
import com.bdo.bvms.common.dto.SearchModuleListResDTO;
import com.bdo.bvms.common.dto.SearchTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.SearchTemplateListResDTO;
import com.bdo.bvms.common.dto.SearchTemplateTypeResDTO;
import com.bdo.bvms.common.dto.TemplateColumnConfigResDTO;
import com.bdo.bvms.common.dto.TemplateHeaderWithColumnConfigResDTO;
import com.bdo.bvms.common.dto.TemplateTypeDetailsResDTO;
import com.bdo.bvms.common.dto.UpdateCustomEmailTemplateReqDTO;
import com.bdo.bvms.common.dto.UpdateCustomTemplateDetailsReqDTO;
import com.bdo.bvms.common.exception.apierror.CustomValidationError;
import com.bdo.bvms.common.exceptions.AppBusinessException;
import com.bdo.bvms.common.exceptions.BDOException;
import com.bdo.bvms.common.exceptions.BVMSException;
import com.bdo.bvms.common.exceptions.CommonMasterBusinessException;
import com.bdo.bvms.common.exceptions.CustomValidationViolationException;
import com.bdo.bvms.common.exceptions.InvalidTemplateHeaderException;
import com.bdo.bvms.common.exceptions.ResourceNotFoundException;
import com.bdo.bvms.common.model.CustomEmailTemplateCategory;
import com.bdo.bvms.common.model.CustomEmailTemplatePlaceholderDictionary;
import com.bdo.bvms.common.model.CustomTemplateColumnMapping;
import com.bdo.bvms.common.model.CustomTemplateColumnValueMapping;
import com.bdo.bvms.common.model.CustomTemplateDetails;
import com.bdo.bvms.common.model.CustomTemplateEmail;
import com.bdo.bvms.common.model.CustomTemplateEmailArchived;
import com.bdo.bvms.common.model.CustomTemplateName;
import com.bdo.bvms.common.model.CustomTemplateOptionValueDetails;
import com.bdo.bvms.common.model.CustomTemplateOptions;
import com.bdo.bvms.common.model.EntityCloudCredentials;
import com.bdo.bvms.common.model.PickupListDetail;
import com.bdo.bvms.common.model.TemplateColumnConfig;
import com.bdo.bvms.common.model.TemplateModule;
import com.bdo.bvms.common.model.TemplateSampleData;
import com.bdo.bvms.common.model.TemplateType;
import com.bdo.bvms.common.repository.ICustomTemplateRepository;
import com.bdo.bvms.common.repository.IPickupMasterRepository;
import com.bdo.bvms.common.service.CommonMasterService;
import com.bdo.bvms.common.service.IAzureBlobService;
import com.bdo.bvms.common.service.ICommonCsvService;
import com.bdo.bvms.common.service.ICommonExcelService;
import com.bdo.bvms.common.service.ICustomTemplateService;
import com.bdo.bvms.common.service.IEntityCloudCredentialsService;
import com.bdo.bvms.common.service.IEntityMasterService;
import com.bdo.bvms.common.service.IFileService;
import com.bdo.bvms.common.util.DateUtil;
import com.bdo.bvms.common.util.ValidateBeanUtil;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/** The Constant log. */
@Slf4j
@Service

public class CustomTemplateServiceImpl implements ICustomTemplateService {

    /** The file service impl. */
    @Autowired
    private IFileService fileServiceImpl;

    /** The custom template reporitory impl. */
    @Autowired
    private ICustomTemplateRepository customTemplateReporitoryImpl;

    /** The common excel service impl. */
    @Autowired
    private ICommonExcelService commonExcelServiceImpl;

    /** The common master service impl. */
    @Autowired
    private CommonMasterService commonMasterServiceImpl;

    /** The entity master service impl. */
    @Autowired
    private IEntityMasterService entityMasterServiceImpl;

    /** The entity cloud credentials service impl. */
    @Autowired
    private IEntityCloudCredentialsService entityCloudCredentialsServiceImpl;

    /** The azure blob service impl. */
    @Autowired
    private IAzureBlobService azureBlobServiceImpl;

    /** The temp folder path. */
    @Value("${bvms.cloud.temp.file.download.path}")
    private String tempFolderPath;

    /** The pickup master repository impl. */
    @Autowired
    private IPickupMasterRepository pickupMasterRepositoryImpl;

    @Autowired
    private ICommonCsvService commonCsvServiceImpl;

    /**
     * Adds the custom template details.
     *
     * @param addCustomTemplateDetailsReqDTO
     *            the add custom template details req DTO
     * @throws BDOException
     */
    @Override
    public void addCustomTemplateDetails(AddCustomTemplateDetailsReqDTO addCustomTemplateDetailsReqDTO)
                    throws BDOException {
        CustomTemplateName customTemplateName = CustomTemplateName.builder()
                        .createdBy(Integer.parseInt(addCustomTemplateDetailsReqDTO.getUserId()))
                        .entityId(Integer.parseInt(addCustomTemplateDetailsReqDTO.getEntityId()))
                        .name(addCustomTemplateDetailsReqDTO.getName()).pan(addCustomTemplateDetailsReqDTO.getPan())
                        .pldTemplateId(addCustomTemplateDetailsReqDTO.getPldTemplateId())
                        .pldStatus(Constants.PLD_STATUS_ACTIVE).isEmailTemplate(Boolean.FALSE).build();

        CustomTemplateName customTemplateNameExists = null;
        try {
            customTemplateNameExists = customTemplateReporitoryImpl.getCustomTemplateName(customTemplateName);
        } catch (EmptyResultDataAccessException e) {
            log.info("No template exists with name " + customTemplateName.getName());
        }

        if (customTemplateNameExists != null) {
            List<CustomValidationError> customValidationErrorList = new ArrayList<>();
            CustomValidationError customValidationError = new CustomValidationError(
                            AddCustomTemplateColumnMappingReqDTO.class.getName(), "name",
                            addCustomTemplateDetailsReqDTO.getName() + "",
                            "Custom template with same name " + "" + " already exists ");
            customValidationErrorList.add(customValidationError);
            throw new BDOException(customValidationError.getMessage());
        }

        final LinkedHashMap<String, List<String>> previewSampleData = addCustomTemplateDetailsReqDTO
                        .getPreviewSampleData();
        int customTemplateNameId = customTemplateReporitoryImpl.insertCustomTemplateName(customTemplateName);
        customTemplateName.setId(customTemplateNameId);
        addCustomTemplateDetailsReqDTO.getAddCustomTemplateColumnMapping().stream()
                        .forEach(addCustomTemplateColumnMappingReqDTO -> {
                            if (addCustomTemplateColumnMappingReqDTO.getTemplateColumn() == null
                                            || addCustomTemplateColumnMappingReqDTO.getTemplateColumn().trim()
                                                            .isEmpty()) {
                                return;
                            }
                            int customTemplateColumnMappingID = customTemplateReporitoryImpl
                                            .insertCustomTemplateColumnMapping(CustomTemplateColumnMapping.builder()
                                                            .createdBy(Integer.parseInt(
                                                                            addCustomTemplateDetailsReqDTO.getUserId()))
                                                            .entityId(Integer.parseInt(addCustomTemplateDetailsReqDTO
                                                                            .getEntityId()))
                                                            .isAutoMap(addCustomTemplateColumnMappingReqDTO
                                                                            .getIsAutoMap())
                                                            .pan(addCustomTemplateDetailsReqDTO.getPan())
                                                            .pldTemplateId(addCustomTemplateDetailsReqDTO
                                                                            .getPldTemplateId())
                                                            .amCustomTemplateNameId(customTemplateNameId)
                                                            .amTemplateColumnConfigurationId(
                                                                            addCustomTemplateColumnMappingReqDTO
                                                                                            .getTemplateColumnConfigurationId())
                                                            .status(Constants.PLD_STATUS_ACTIVE)
                                                            .templateColumn(addCustomTemplateColumnMappingReqDTO
                                                                            .getTemplateColumn())
                                                            .build());
                            customTemplateReporitoryImpl.insertTemplateSampleData(TemplateSampleData.builder()
                                            .columnName(addCustomTemplateColumnMappingReqDTO.getTemplateColumn())
                                            .columnValue(addCustomTemplateColumnMappingReqDTO
                                                            .getTemplateColumn() != null
                                                                            ? StringConstant.join(previewSampleData.get(
                                                                                            addCustomTemplateColumnMappingReqDTO
                                                                                                            .getTemplateColumn()),
                                                                                            StringConstant.PIPE_SPACE)
                                                                            : "")
                                            .createdBy(Integer.parseInt(addCustomTemplateDetailsReqDTO.getUserId()))
                                            .amCustomTemplateColumnMappingId(customTemplateColumnMappingID).build());

                            if (addCustomTemplateColumnMappingReqDTO.getAddCustomTemplateColumnValueMapping() == null
                                            || addCustomTemplateColumnMappingReqDTO
                                                            .getAddCustomTemplateColumnValueMapping().isEmpty()) {
                                return;
                            }
                            List<AddCustomTemplateColumnValueMappingReqDTO> addCustomTemplateColumnValueMappingReqDTOList = addCustomTemplateColumnMappingReqDTO
                                            .getAddCustomTemplateColumnValueMapping();

                            List<CustomTemplateColumnValueMapping> customTemplateColumnValueMappingList = new ArrayList<>();
                            for (AddCustomTemplateColumnValueMappingReqDTO addCustomTemplateColumnValueMappingReqDTO : addCustomTemplateColumnValueMappingReqDTOList) {
                                CustomTemplateColumnValueMapping customTemplateColumnValueMapping = CustomTemplateColumnValueMapping
                                                .builder()
                                                .createdBy(Integer.parseInt(addCustomTemplateDetailsReqDTO.getUserId()))
                                                .customTemplateMappingId(customTemplateColumnMappingID)
                                                .optionId(addCustomTemplateColumnValueMappingReqDTO.getOptionId())
                                                .entityId(Integer
                                                                .parseInt(addCustomTemplateDetailsReqDTO.getEntityId()))
                                                .values(String.join(",",
                                                                addCustomTemplateColumnValueMappingReqDTO.getValues()))
                                                .build();
                                customTemplateColumnValueMappingList.add(customTemplateColumnValueMapping);
                            }
                            customTemplateReporitoryImpl.insertCustomTemplateColumnValueMapping(
                                            customTemplateColumnValueMappingList);
                            addCustomTemplateColumnValueMappingReqDTOList.clear();
                        });

        List<CustomTemplateDetails> customTemplateDetailsList = customTemplateReporitoryImpl
                        .getCustomTemplateMappingDetails(CustomTemplateColumnMapping.builder()
                                        .amCustomTemplateNameId(customTemplateName.getId())
                                        .status(Constants.PLD_STATUS_ACTIVE).build());
        List<String> templateColumnList = customTemplateDetailsList.stream()
                        .map(CustomTemplateDetails::getTemplateColumn).collect(Collectors.toList());

        String fileName = addCustomTemplateDetailsReqDTO.getName() + Constants.UNDERSCORE
                        + addCustomTemplateDetailsReqDTO.getPan() + Constants.DOTSEPERATOR + Constants.XLSX;
        File convFile = commonExcelServiceImpl.writeExcelWithHeader(fileName, Constants.DELIMITER_COMMA,
                        templateColumnList);
        EntityCloudCredentials entityCloudCredentials = entityCloudCredentialsServiceImpl
                        .getEntityCloudCredentials(Integer.parseInt(addCustomTemplateDetailsReqDTO.getEntityId()));
        try {
            azureBlobServiceImpl.uploadToAzureBlob(convFile, entityCloudCredentials);
        } finally {
            if (convFile.exists()) {
                try {
                    Files.deleteIfExists(convFile.toPath());
                } catch (IOException e) {
                    log.error(Constants.ERROR_WHILE_DELETING_FILE_EXCEPTION_MSG + convFile.getAbsolutePath());
                }
            }
        }
        addCustomTemplateDetailsReqDTO.getAddCustomTemplateColumnMapping().clear();
    }

    /**
     * Validate file.
     *
     * @param file
     *            the file
     * @param customValidationErrorList
     *            the custom validation error list
     */
    private void validateFile(MultipartFile file, List<CustomValidationError> customValidationErrorList) {
        if (file == null) {
            CustomValidationError customValidationError = new CustomValidationError("file", "file", file,
                            "Request parameter file must not be null");
            customValidationErrorList.add(customValidationError);
        }
        String fileExtension = null;
        if (file != null) {
            fileExtension = FilenameUtils.getExtension(file.getOriginalFilename());
        }
        if (file != null && (!(fileExtension).equals(Constants.VENODR_DETAIL_TEMPLATE_FILE_TYPE_XLSX)
                        && !fileExtension.equals(Constants.VENODR_DETAIL_TEMPLATE_FILE_TYPE_XLS)
                        && !fileExtension.equals(Constants.CSV))) {
            CustomValidationError customValidationError = new CustomValidationError(Constants.FILE_EXTENSION,
                            Constants.FILE_EXTENSION, fileExtension,
                            "File with extension " + fileExtension + " are not allowed. ");
            customValidationErrorList.add(customValidationError);
        }

    }

    /**
     * Gets the custom template name.
     *
     * @param entityId
     *            the entity id
     * @return the custom template name
     */
    public List<CustomTemplateNameResDTO> getCustomTemplateName(int entityId) {
        CustomTemplateName customTemplateNameReq = CustomTemplateName.builder().entityId(entityId).build();

        List<CustomTemplateName> customTemplateNameList = customTemplateReporitoryImpl
                        .getCustomTemplateNames(customTemplateNameReq);
        return customTemplateNameList
                        .stream().map(customTemplateName -> CustomTemplateNameResDTO.builder()
                                        .name(customTemplateName.getName()).id(customTemplateName.getId()).build())
                        .collect(Collectors.toList());
    }

    /**
     * Search template header with auto mapped column.
     *
     * @param inputMultipartFile
     *            the input multipart file
     * @param pldTemplateId
     *            the pld template id
     * @return the template header with column config res DTO
     * @throws BVMSException
     */
    @SuppressWarnings("unlikely-arg-type")
    @Override
    public TemplateHeaderWithColumnConfigResDTO searchTemplateHeaderWithAutoMappedColumn(
                    MultipartFile inputMultipartFile, Integer pldTemplateId)
                    throws BVMSException, InvalidTemplateHeaderException {
        List<TemplateColumnConfig> templateColumnConfigList = null;
        File convFile = null;
        List<TemplateColumnConfigResDTO> templateColumnConfigResDTOList = null;
        TemplateHeaderWithColumnConfigResDTO templateHeaderWithColumnConfigResDTO = new TemplateHeaderWithColumnConfigResDTO();
        int mandatoryColCount = 0;
        List<String> headerList = new ArrayList<>();
        try {

            // get the template configuration details from db
            templateColumnConfigList = customTemplateReporitoryImpl.getCustomTemplateColumnConfig(
                            TemplateColumnConfig.builder().pldTemplateId(pldTemplateId).build());

            // find count of mandatory columns
            for (TemplateColumnConfig col : templateColumnConfigList) {
                if (Boolean.TRUE.equals(col.getIsMandatory())) {
                    mandatoryColCount++;
                }
            }

            // Change multipart to file
            convFile = new File(fileServiceImpl.saveFileInLocalStorage(inputMultipartFile,
                            inputMultipartFile.getOriginalFilename()));

            String fileExtension = null;
            fileExtension = FilenameUtils.getExtension(inputMultipartFile.getOriginalFilename());
            List<CustomValidationError> customValidationErrorList = new ArrayList<>();
            validateFileExtension(fileExtension, customValidationErrorList);

            // Read excel and get headers from the file
            List<String> templateheadersList = getListofHeaders(convFile);
            templateheadersList.removeAll(Arrays.asList("", null));
            headerList.addAll(templateheadersList);
            templateheadersList.clear();
            if (headerList.size() < mandatoryColCount) {
                log.error("please upload template with atleast " + mandatoryColCount + " columns");
                throw new InvalidTemplateHeaderException(
                                "please upload template with atleast " + mandatoryColCount + " columns");
            }
            Collections.sort(headerList);
            templateHeaderWithColumnConfigResDTO.setTemplateColumnHeaders(headerList);
            // create response of the API
            templateColumnConfigResDTOList = templateColumnConfigList.stream().map(templateColumnConfig -> {

                // get column name from template column config to match with the
                // headers from
                // the excel
                String columnNameToCheckMapping = templateColumnConfig.getColumnName()
                                .length() > Constants.COLUMN_AUTOMAP_CHAR_END_INDEX
                                                ? StringUtils.substring(templateColumnConfig.getColumnName(),
                                                                Constants.COLUMN_AUTOMAP_CHAR_START_INDEX,
                                                                Constants.COLUMN_AUTOMAP_CHAR_END_INDEX)
                                                : templateColumnConfig.getColumnName();

                // get the matched headers from the excel with the config column
                String matchedColumnName = headerList.stream()
                                .filter(header -> (header.length() > Constants.COLUMN_AUTOMAP_CHAR_END_INDEX
                                                ? StringUtils.substring(header,
                                                                Constants.COLUMN_AUTOMAP_CHAR_START_INDEX,
                                                                Constants.COLUMN_AUTOMAP_CHAR_END_INDEX)
                                                : header).equalsIgnoreCase(columnNameToCheckMapping))
                                .findAny().orElse(null);

                TemplateColumnConfigResDTO templateColumnConfigResDTO = TemplateColumnConfigResDTO.builder()
                                .customAutoMappedSource(matchedColumnName)
                                .columnName(templateColumnConfig.getColumnName())
                                .isAutoMapped(StringUtils.isBlank(matchedColumnName) ? Boolean.FALSE : Boolean.TRUE)
                                .pldTemplateId(templateColumnConfig.getPldTemplateId())
                                .dataType(templateColumnConfig.getDataType()).id(templateColumnConfig.getId())
                                .size(templateColumnConfig.getSize()).isMandatory(templateColumnConfig.getIsMandatory())
                                .conditionalMandatoryGrouping(templateColumnConfig.getConditionalMandatoryGrouping())
                                .build();

                List<CustomTemplateOptions> customTemplateOptionsList = customTemplateReporitoryImpl
                                .getCustomTemplateOptions(CustomTemplateOptions.builder()
                                                .templateColumnConfigId(templateColumnConfigResDTO.getId()).build());
                List<CustomTemplateOptionsResDTO> customTemplateOptionsResDTOList = customTemplateOptionsList.stream()
                                .map(customTemplateOptions -> CustomTemplateOptionsResDTO.builder()
                                                .name(customTemplateOptions.getName()).id(customTemplateOptions.getId())
                                                .build())
                                .collect(Collectors.toList());

                templateColumnConfigResDTO.setCustomTemplateOptions(customTemplateOptionsResDTOList);

                customTemplateOptionsList.clear();

                return templateColumnConfigResDTO;
            }).collect(Collectors.toList());
            templateColumnConfigList.clear();
        } finally {
            try {
                if (convFile != null && convFile.exists())
                    Files.deleteIfExists(convFile.toPath());
            } catch (IOException e) {
                log.error(Constants.ERROR_WHILE_DELETING_FILE_EXCEPTION_MSG + convFile.getAbsolutePath());
            }
        }
        if (templateColumnConfigResDTOList != null) {
            Set<Integer> set = templateColumnConfigResDTOList.stream()
                            .map(TemplateColumnConfigResDTO::getConditionalMandatoryGrouping)
                            .collect(Collectors.toSet());
            set.removeAll(Arrays.asList("", null));
            templateHeaderWithColumnConfigResDTO.setConditionalMandatoryGrouping(set);
        }
        templateHeaderWithColumnConfigResDTO.setTemplateColumnConfig(templateColumnConfigResDTOList);

        return templateHeaderWithColumnConfigResDTO;
    }

    private List<String> getListofHeaders(File convFile) throws BVMSException {
        List<String> templateheadersList = new ArrayList<>();
        if (FilenameUtils.getExtension(convFile.getName()).equals(Constants.XLSX)
                        || FilenameUtils.getExtension(convFile.getName()).equals(Constants.XLS)) {
            templateheadersList = commonExcelServiceImpl.getExcelTemplateHeaderList(convFile,
                            Constants.CUSTOM_VENDOR_DETAILS_EXCEL_HEADER_ROW_NO);
        } else if (FilenameUtils.getExtension(convFile.getName()).equals(Constants.CSV)) {
            templateheadersList = commonCsvServiceImpl.readVendorMasterDetailsTemplateFile(convFile,
                            Constants.DELIMITER_COMMA);
        }
        return templateheadersList;
    }

    private void validateFileExtension(String fileExtension, List<CustomValidationError> customValidationErrorList) {
        if (!(fileExtension).equals(Constants.VENODR_DETAIL_TEMPLATE_FILE_TYPE_XLSX)
                        && !fileExtension.equals(Constants.VENODR_DETAIL_TEMPLATE_FILE_TYPE_XLS)
                        && !fileExtension.equals(Constants.CSV)) {

            CustomValidationError customValidationError = new CustomValidationError(Constants.FILE_EXTENSION,
                            Constants.FILE_EXTENSION, fileExtension,
                            "File with extension " + fileExtension + " are not allowed. ");
            customValidationErrorList.add(customValidationError);
            throw new CustomValidationViolationException(customValidationErrorList);
        }
    }

    /**
     * Search template list.
     *
     * @param searchTemplateDetailsReqDTO
     *            the search template details req DTO
     * @return the pagination res DTO
     */
    @Override
    public PaginationResDTO searchTemplateList(SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO) {
        CustomTemplateName customTemplateNameReq = null;
        List<SearchTemplateListResDTO> searchTemplateListResDTOList = null;
        Pageable paging = PageRequest.of(searchTemplateDetailsReqDTO.getPage(), searchTemplateDetailsReqDTO.getSize());

        if (searchTemplateDetailsReqDTO.getIsCustomTemplate() != null
                        && searchTemplateDetailsReqDTO.getIsCustomTemplate()) {
            List<EntityMasterResDTO> entityMasterList = entityMasterServiceImpl.getEntityMasterList(
                            searchTemplateDetailsReqDTO.getGstinOrPanList(),
                            searchTemplateDetailsReqDTO.getGstinOrPan(),
                            Integer.valueOf(searchTemplateDetailsReqDTO.getEntityTypeId()));

            if (entityMasterList == null || entityMasterList.isEmpty()) {
                List<CustomValidationError> customValidationErrorList = new ArrayList<>();
                CustomValidationError customValidationError = new CustomValidationError(
                                SearchTemplateDetailsReqDTO.class.getName(), Constants.GSTIN_OR_PAN_LIST,
                                searchTemplateDetailsReqDTO.getGstinOrPanList(),
                                Constants.ENTITYNOTFOUNDFORTHE + searchTemplateDetailsReqDTO.getGstinOrPan()
                                                + Constants.WITHVALUES
                                                + searchTemplateDetailsReqDTO.getGstinOrPanList());
                customValidationErrorList.add(customValidationError);
                throw new CustomValidationViolationException(customValidationErrorList);
            }

            String taxpayerPans = null;
            if (searchTemplateDetailsReqDTO.getGstinOrPan().equals(Constants.GSTIN)) {
                List<String> panList = entityMasterList.stream().map(EntityMasterResDTO::getPan)
                                .collect(Collectors.toList());
                Set<String> uniquetPans = new HashSet<>(panList);
                List<String> pans = new ArrayList<>(uniquetPans);

                taxpayerPans = String.join(",",
                                panList.stream().map(name -> ("'" + name + "'")).collect(Collectors.toList()));
                panList.clear();
                uniquetPans.clear();
                pans.clear();
            } else if (searchTemplateDetailsReqDTO.getGstinOrPan().equals(Constants.PAN)) {

                taxpayerPans = "'" + StringConstant.joinString(searchTemplateDetailsReqDTO.getGstinOrPanList()) + "'";
            }

            customTemplateNameReq = CustomTemplateName.builder().pan(taxpayerPans)
                            .name(searchTemplateDetailsReqDTO.getTemplateName()).pldStatus(Constants.PLD_STATUS_ACTIVE)
                            .build();

            PageImpl<CustomTemplateName> pagedResult = customTemplateReporitoryImpl.getCustomTemplatesName(
                            customTemplateNameReq, Constants.SMPICKTEMPLATEID,
                            searchTemplateDetailsReqDTO.getModuleId(), Constants.PICKUP_MASTER_MODULES_ID, paging,
                            searchTemplateDetailsReqDTO.getReportId());
            searchTemplateListResDTOList = pagedResult.getContent().stream()
                            .map(customTemplateName -> SearchTemplateListResDTO.builder()
                                            .name(customTemplateName.getName()).id(customTemplateName.getId())
                                            .uploadedBy(customTemplateName.getUserName())
                                            .uploadedOn(DateUtil.convertDateToString(customTemplateName.getCreatedAt(),
                                                            DateUtil.DATETIMEFORMATTERFORUI))
                                            .baseTemplate(customTemplateName.getModule()).build())
                            .collect(Collectors.toList());
            return PaginationResDTO.builder().totalElements(pagedResult.getTotalElements())

                            .searchElements(searchTemplateListResDTOList).build();
        } else {

            PageImpl<PickupListDetail> pagedResult = pickupMasterRepositoryImpl.searchModulesPickupMasterByNamePickKey(
                            PickupListDetail.builder().pickKey(searchTemplateDetailsReqDTO.getModuleId())
                                            .name(Constants.PLD_TEMPLATE_TYPE).build());

            searchTemplateListResDTOList = pagedResult.getContent().stream()
                            .map(pickupListDetail -> SearchTemplateListResDTO.builder().name(pickupListDetail.getName())
                                            .id(pickupListDetail.getId()).uploadedBy(pickupListDetail.getUserName())
                                            .uploadedOn(DateUtil.convertDateToString(pickupListDetail.getCreatedAt(),
                                                            DateUtil.DATETIMEFORMATTERFORUI))
                                            .baseTemplate(pickupListDetail.getModuleName()).build())
                            .collect(Collectors.toList());
            return PaginationResDTO.builder().totalElements(pagedResult.getTotalElements())

                            .searchElements(searchTemplateListResDTOList).build();
        }

    }

    /**
     * Search default templates.
     *
     * @return the list
     */
    @Override
    public List<TemplateTypeDetailsResDTO> searchDefaultTemplates() {
        PickupDetailListResDTO pickupDetailListResDTO = null;
        try {
            pickupDetailListResDTO = commonMasterServiceImpl.searchPickupListDetailByNameAndCode(
                            PickupListDetailReqDTO.builder().name(Constants.PICKUP_MASTER_MODULES)
                                            .code(Constants.PLD_MODULES_VENDOR_MASTER_CODE).build());
        } catch (EmptyResultDataAccessException e) {
            pickupDetailListResDTO = null;
        }

        final String module = pickupDetailListResDTO == null || pickupDetailListResDTO.getName() == null
                        ? Constants.CUSTOM_TEMPLATE_TYPE_MODULE
                        : pickupDetailListResDTO.getName();

        List<PickupDetailListResDTO> pickupDetailList = commonMasterServiceImpl.searchPickupListDetail(
                        SearchByLkupcodeReqDTO.builder().lkupcode(Constants.PLD_UPLOAD_TEMPLATE_TYPE).build());
        List<TemplateTypeDetailsResDTO> templateTypeDetailsResDTOList = pickupDetailList.stream().map(pickupDetail -> {
            return TemplateTypeDetailsResDTO.builder().name(pickupDetail.getName()).id(pickupDetail.getCode()) // code
                                                                                                               // for
                                                                                                               // default
                                                                                                               // templates
                            .uploadedBy(pickupDetail.getUploadedBy()).uploadedOn(pickupDetail.getUploadedOn())
                            .module(module).build();
        }).collect(Collectors.toList());
        pickupDetailList.clear();

        return templateTypeDetailsResDTOList;
    }

    /**
     * Delete custom template.
     *
     * @param deleteCustomTemplateReqDTO
     *            the delete custom template req DTO
     */
    @Override
    public void deleteCustomTemplate(DeleteCustomTemplateReqDTO deleteCustomTemplateReqDTO) {
        customTemplateReporitoryImpl.updateCustomTemplateStatus(CustomTemplateName.builder()
                        .id(deleteCustomTemplateReqDTO.getCustomTemplateId()).pldStatus(Constants.PLD_STATUS_DELETED)
                        .modifiedBy(Integer.parseInt(deleteCustomTemplateReqDTO.getUserId())).build());
    }

    /**
     * Search custom template details.
     *
     * @param searchCustomTemplateDetailsReqDTO
     *            the search custom template details req DTO
     * @return the template header with column config res DTO
     */
    @SuppressWarnings("unlikely-arg-type")
    @Override
    public TemplateHeaderWithColumnConfigResDTO searchCustomTemplateDetails(
                    SearchCustomTemplateDetailsReqDTO searchCustomTemplateDetailsReqDTO) {
        CustomTemplateName customTemplateName = CustomTemplateName.builder()
                        .id(searchCustomTemplateDetailsReqDTO.getCustomTemplateId()).build();
        customTemplateName = customTemplateReporitoryImpl.getCustomTemplateNameById(customTemplateName);
        TemplateHeaderWithColumnConfigResDTO templateHeaderWithColumnConfigResDTO = new TemplateHeaderWithColumnConfigResDTO();
        templateHeaderWithColumnConfigResDTO.setTemplateName(customTemplateName.getName());
        List<CustomTemplateDetails> customTemplateDetailsList = customTemplateReporitoryImpl
                        .getCustomTemplateMappingDetails(CustomTemplateColumnMapping.builder()
                                        .amCustomTemplateNameId(customTemplateName.getId())
                                        .status(Constants.PLD_STATUS_ACTIVE).build());
        List<TemplateColumnConfigResDTO> templateColumnConfigResDTOList = customTemplateDetailsList.stream()
                        .map(customTemplateDetails -> {

                            TemplateColumnConfigResDTO templateColumnConfigResDTO = TemplateColumnConfigResDTO.builder()
                                            .customAutoMappedSource(customTemplateDetails.getTemplateColumn())
                                            .columnName(customTemplateDetails.getColumnName())
                                            .isAutoMapped(customTemplateDetails.getIsAutoMap())
                                            .pldTemplateId(customTemplateDetails.getPldTemplateId())
                                            .dataType(customTemplateDetails.getDataType())
                                            .id(customTemplateDetails.getId())
                                            .customColumnMappingId(
                                                            customTemplateDetails.getCustomTemplateColumnMappingId())
                                            .size(customTemplateDetails.getSize())
                                            .isMandatory(customTemplateDetails.getIsMandatory())
                                            .conditionalMandatoryGrouping(
                                                            customTemplateDetails.getConditionalMandatoryGrouping())
                                            .build();

                            List<CustomTemplateOptionValueDetails> customTemplateOptionValueDetailsList = customTemplateReporitoryImpl
                                            .getCustomTemplateOptionsValueMapping(CustomTemplateColumnMapping.builder()
                                                            .amTemplateColumnConfigurationId(
                                                                            customTemplateDetails.getId())
                                                            .id(customTemplateDetails
                                                                            .getCustomTemplateColumnMappingId())
                                                            .build());

                            List<CustomTemplateOptionsResDTO> customTemplateOptionsDetailsResDTOList = customTemplateOptionValueDetailsList
                                            .stream()
                                            .map(customTemplateOptions -> CustomTemplateOptionsResDTO.builder()
                                                            .name(customTemplateOptions.getName())
                                                            .id(customTemplateOptions.getOptionId())
                                                            .customTemplateColumnValueMappingId(customTemplateOptions
                                                                            .getCustomTemplateColumnValueMappingId())
                                                            .customTemplateColumnValues(
                                                                            customTemplateOptions.getValues())
                                                            .build())
                                            .collect(Collectors.toList());

                            templateColumnConfigResDTO.setCustomTemplateOptions(customTemplateOptionsDetailsResDTOList);

                            customTemplateOptionValueDetailsList.clear();

                            return templateColumnConfigResDTO;
                        }).collect(Collectors.toList());
        List<String> templateColumnList = customTemplateDetailsList.stream()
                        .map(CustomTemplateDetails::getTemplateColumn).collect(Collectors.toList());
        Collections.sort(templateColumnList);
        templateHeaderWithColumnConfigResDTO.setTemplateColumnConfig(templateColumnConfigResDTOList);
        templateHeaderWithColumnConfigResDTO.setTemplateColumnHeaders(templateColumnList);

        if (templateColumnConfigResDTOList != null) {
            Set<Integer> set = templateColumnConfigResDTOList.stream()
                            .map(TemplateColumnConfigResDTO::getConditionalMandatoryGrouping)
                            .collect(Collectors.toSet());
            set.removeAll(Arrays.asList("", null));
            templateHeaderWithColumnConfigResDTO.setConditionalMandatoryGrouping(set);
        }

        return templateHeaderWithColumnConfigResDTO;

    }

    /**
     * Update custom template details.
     *
     * @param updateCustomTemplateDetailsReqDTO
     *            the update custom template details req DTO
     */
    @Override
    public void updateCustomTemplateDetails(UpdateCustomTemplateDetailsReqDTO updateCustomTemplateDetailsReqDTO) {
        Integer customTemplateNameId = updateCustomTemplateDetailsReqDTO.getCustomTemplateId();
        updateCustomTemplateDetailsReqDTO.getUpdateCustomTemplateColumnMapping()
                        .forEach(updateCustomTemplateColumnMappingReqDTO -> {

                            CustomTemplateColumnMapping customTemplateColumnMapping = CustomTemplateColumnMapping
                                            .builder()
                                            .id(updateCustomTemplateColumnMappingReqDTO
                                                            .getCustomTemplateColumnMappingId())
                                            .isAutoMap(updateCustomTemplateColumnMappingReqDTO.getIsAutoMap())
                                            .modifiedBy(Integer.parseInt(updateCustomTemplateDetailsReqDTO.getUserId()))
                                            .templateColumn(updateCustomTemplateColumnMappingReqDTO.getTemplateColumn())
                                            .build();

                            // update custom template column mapping
                            updateCustomTemplateColumnMappingExists(customTemplateColumnMapping);

                            // check if the value mapping is provided
                            if (updateCustomTemplateColumnMappingReqDTO
                                            .getUpdateCustomTemplateColumnValueMapping() != null
                                            && !updateCustomTemplateColumnMappingReqDTO
                                                            .getUpdateCustomTemplateColumnValueMapping().isEmpty()) {
                                updateCustomTemplateColumnMappingReqDTO.getUpdateCustomTemplateColumnValueMapping()
                                                .stream().forEach(customTemplateColumnValueMappingReq -> {
                                                    CustomTemplateColumnValueMapping customTemplateColumnValueMapping = CustomTemplateColumnValueMapping
                                                                    .builder()
                                                                    .createdBy(Integer.parseInt(
                                                                                    updateCustomTemplateDetailsReqDTO
                                                                                                    .getUserId()))
                                                                    .customTemplateMappingId(
                                                                                    customTemplateColumnMapping.getId())
                                                                    .id(customTemplateColumnValueMappingReq
                                                                                    .getCustomTemplateColumnValueMappingId())
                                                                    .optionId(customTemplateColumnValueMappingReq
                                                                                    .getOptionId())
                                                                    .entityId(Integer.parseInt(
                                                                                    updateCustomTemplateDetailsReqDTO
                                                                                                    .getEntityId()))
                                                                    .modifiedBy(Integer.parseInt(
                                                                                    updateCustomTemplateDetailsReqDTO
                                                                                                    .getUserId()))
                                                                    .values(String.join(",",
                                                                                    customTemplateColumnValueMappingReq
                                                                                                    .getValues()))
                                                                    .build();

                                                    // update custom template
                                                    // column value mapping
                                                    // after comparing with the
                                                    // existing one
                                                    updateCustomTemplateColumnValueMapping(
                                                                    customTemplateColumnValueMapping);
                                                });
                            }
                        });

        CustomTemplateName customTemplateName = null;
        try {
            customTemplateName = customTemplateReporitoryImpl
                            .getCustomTemplateNameById(CustomTemplateName.builder().id(customTemplateNameId).build());
        } catch (EmptyResultDataAccessException e) {
            throw new ResourceNotFoundException(DownloadCustomTemplateReqDTO.class, "customTemplateNameId",
                            customTemplateNameId + "");
        }

        List<CustomTemplateDetails> customTemplateDetailsList = customTemplateReporitoryImpl
                        .getCustomTemplateMappingDetails(CustomTemplateColumnMapping.builder()
                                        .amCustomTemplateNameId(customTemplateName.getId())
                                        .status(Constants.PLD_STATUS_ACTIVE).build());
        List<String> templateColumnList = customTemplateDetailsList.stream()
                        .map(CustomTemplateDetails::getTemplateColumn).collect(Collectors.toList());

        customTemplateName.setModifiedBy(Integer.parseInt(updateCustomTemplateDetailsReqDTO.getUserId()));
        customTemplateReporitoryImpl.updateCustomTemplateStatus(customTemplateName);
        String fileName = customTemplateName.getName() + Constants.UNDERSCORE + customTemplateName.getPan()
                        + Constants.DOTSEPERATOR + Constants.XLSX;
        File convFile = commonExcelServiceImpl.writeExcelWithHeader(fileName, Constants.DELIMITER_COMMA,
                        templateColumnList);
        EntityCloudCredentials entityCloudCredentials = entityCloudCredentialsServiceImpl
                        .getEntityCloudCredentials(customTemplateName.getEntityId());
        try {
            azureBlobServiceImpl.uploadToAzureBlob(convFile, entityCloudCredentials);
        } finally {
            if (convFile.exists()) {
                try {
                    Files.deleteIfExists(convFile.toPath());
                } catch (IOException e) {
                    log.error(Constants.ERROR_WHILE_DELETING_FILE_EXCEPTION_MSG + convFile.getAbsolutePath());
                }
            }
        }
    }

    /**
     * Update custom template column mapping exists.
     *
     * @param customTemplateColumnMapping
     *            the custom template column mapping
     */
    private void updateCustomTemplateColumnMappingExists(CustomTemplateColumnMapping customTemplateColumnMapping) {
        CustomTemplateColumnMapping customTemplateColumnMappingExists = null;
        try {
            customTemplateColumnMappingExists = customTemplateReporitoryImpl
                            .checkIfCustomTemplateColumnMappingExists(customTemplateColumnMapping);
        } catch (EmptyResultDataAccessException e) {
            throw new ResourceNotFoundException(CustomTemplateColumnMapping.class, "id",
                            customTemplateColumnMapping.getId() + "");
        }
        if (customTemplateColumnMapping.getTemplateColumn() == null
                        || customTemplateColumnMapping.getTemplateColumn().trim().equals("")) {
            customTemplateColumnMappingExists.setStatus(Constants.PLD_STATUS_DELETED);
            customTemplateReporitoryImpl.updateCustomTemplateMapping(customTemplateColumnMappingExists);
        } else if (!customTemplateColumnMappingExists.equals(customTemplateColumnMapping)) { // compare
                                                                                             // existing
                                                                                             // details
                                                                                             // with
                                                                                             // the
                                                                                             // provided
            customTemplateColumnMapping.setStatus(customTemplateColumnMappingExists.getStatus());
            customTemplateReporitoryImpl.updateCustomTemplateMapping(customTemplateColumnMapping);
        }
    }

    /**
     * Update custom template column value mapping.
     *
     * @param customTemplateColumnValueMapping
     *            the custom template column value mapping
     */
    private void updateCustomTemplateColumnValueMapping(
                    CustomTemplateColumnValueMapping customTemplateColumnValueMapping) {
        CustomTemplateColumnValueMapping customTemplateColumnValueMappingExists = null;
        // check of the customTemplateColumnValueMappingid is provided, id not
        // then
        // insert else update
        if (customTemplateColumnValueMapping.getId() == null) {
            try {
                customTemplateColumnValueMappingExists = customTemplateReporitoryImpl
                                .checkIfCustomTemplateColumnValueMappingExists(customTemplateColumnValueMapping);
            } catch (EmptyResultDataAccessException e) {
                customTemplateColumnValueMappingExists = null;
            }
            if (customTemplateColumnValueMappingExists != null) {
                List<CustomValidationError> customValidationErrorList = new ArrayList<>();
                CustomValidationError customValidationError = new CustomValidationError(
                                "CustomTemplateColumnValueMapping", "id", customTemplateColumnValueMapping.getId(),
                                "Request parameter customTemplateColumnValueMappingId should not be null if the data is available");
                customValidationErrorList.add(customValidationError);
                throw new CustomValidationViolationException(customValidationErrorList);
            }
            List<CustomTemplateColumnValueMapping> customTemplateColumnValueMappingList = new ArrayList<>();
            customTemplateColumnValueMappingList.add(customTemplateColumnValueMapping);
            customTemplateReporitoryImpl.insertCustomTemplateColumnValueMapping(customTemplateColumnValueMappingList);
        } else {
            try {
                customTemplateColumnValueMappingExists = customTemplateReporitoryImpl
                                .checkIfCustomTemplateColumnValueMappingExistsById(customTemplateColumnValueMapping);
            } catch (EmptyResultDataAccessException e) {
                throw new ResourceNotFoundException(CustomTemplateColumnValueMapping.class, "id",
                                customTemplateColumnValueMapping.getId() + "");
            }
            if (!customTemplateColumnValueMappingExists.equals(customTemplateColumnValueMapping)) {
                customTemplateReporitoryImpl.updateCustomTemplateColumnValueMapping(customTemplateColumnValueMapping);
            }
        }
    }

    /**
     * Search custom template options mappings.
     *
     * @param customTemplateId
     *            the custom template id
     * @return the map
     */
    @Override
    @SuppressWarnings("unchecked")
    public Map<String, Object> searchCustomTemplateOptionsMappings(int customTemplateId) {
        Map<String, Object> optionsMappings = customTemplateReporitoryImpl.searchCustomTemplateOptionsMappings(
                        customTemplateId, Constants.PICKUP_MASTER_PRIMARY_CONTACT,
                        Constants.PICKUP_MASTER_DEFAULT_ADDRESS_TYPE, Constants.PICKUP_MASTER_PRIMARY_BANK,
                        Constants.PICKUP_MASTER_ADDRESS_TYPE);

        Map<String, Map<String, Integer>> splitOptionsMappings = new HashMap<>();

        Map<String, Map<String, Integer>> customOptionsMappings = (Map<String, Map<String, Integer>>) optionsMappings
                        .get("customMap");

        Map<String, Integer> primaryContactMap = customOptionsMappings.get(Constants.PICKUP_MASTER_PRIMARY_CONTACT);
        if (primaryContactMap != null) {
            Map<String, Integer> splitPrimaryContactMap = convertOptionsMappingsToSplitOptionsMappings(
                            primaryContactMap);
            splitOptionsMappings.put(Constants.PICKUP_MASTER_PRIMARY_CONTACT, splitPrimaryContactMap);
            primaryContactMap.clear();
        }

        Map<String, Integer> defaultAddressMap = customOptionsMappings
                        .get(Constants.PICKUP_MASTER_DEFAULT_ADDRESS_TYPE);
        if (defaultAddressMap != null) {
            Map<String, Integer> splitDefaultAddressMap = convertOptionsMappingsToSplitOptionsMappings(
                            defaultAddressMap);
            splitOptionsMappings.put(Constants.PICKUP_MASTER_DEFAULT_ADDRESS_TYPE, splitDefaultAddressMap);
            defaultAddressMap.clear();
        }

        Map<String, Integer> primaryBankMap = customOptionsMappings.get(Constants.PICKUP_MASTER_PRIMARY_BANK);
        if (primaryBankMap != null) {
            Map<String, Integer> splitDefaultAddressMap = convertOptionsMappingsToSplitOptionsMappings(primaryBankMap);
            splitOptionsMappings.put(Constants.PICKUP_MASTER_PRIMARY_BANK, splitDefaultAddressMap);
            primaryBankMap.clear();
        }

        Map<String, Integer> addressMap = customOptionsMappings.get(Constants.PICKUP_MASTER_ADDRESS_TYPE);
        if (addressMap != null) {
            Map<String, Integer> splitAddressMap = convertOptionsMappingsToSplitOptionsMappings(addressMap);
            splitOptionsMappings.put(Constants.PICKUP_MASTER_ADDRESS_TYPE, splitAddressMap);
            addressMap.clear();
        }

        customOptionsMappings.clear();

        optionsMappings.put("customMap", splitOptionsMappings);
        return optionsMappings;
    }

    /**
     * Search custom template header mappings.
     *
     * @param customTemplateId
     *            the custom template id
     * @return the map
     */
    @Override
    public Map<String, String> searchCustomTemplateHeaderMappings(int customTemplateId) {
        return customTemplateReporitoryImpl.searchCustomTemplateHeaderMappings(customTemplateId);
    }

    /**
     * Convert options mappings to split options mappings.
     *
     * @param optionsMap
     *            the options map
     * @return the map
     */
    private Map<String, Integer> convertOptionsMappingsToSplitOptionsMappings(Map<String, Integer> optionsMap) {
        Map<String, Integer> splitOptionsMap = new HashMap<>();
        for (Map.Entry<String, Integer> entry : optionsMap.entrySet()) {
            String[] keys = entry.getKey().split(",");
            for (int i = 0; i < keys.length; i++) {
                splitOptionsMap.put(keys[i], entry.getValue());
            }
        }
        return splitOptionsMap;
    }

    /**
     * Download custom template.
     *
     * @param downloadCustomTemplateReqDTO
     *            the download custom template req DTO
     * @return the file
     */
    @Override
    public File downloadCustomTemplate(DownloadCustomTemplateReqDTO downloadCustomTemplateReqDTO) {

        CustomTemplateName customTemplateName = null;
        String blobName = "";
        EntityCloudCredentials entityCloudCredential = null;
        try {

            if (downloadCustomTemplateReqDTO.getTemplateType() == 0) {

                if (Constants.EINVOICE_TEMPLATE_CODE_ID == downloadCustomTemplateReqDTO.getTemplateId()) {
                    blobName = "e-Invoice_Invoice Template_v1.xlsx";
                } else if (Constants.EWAYBILL_TEMPLATE_CODE_ID == downloadCustomTemplateReqDTO.getTemplateId()) {
                    blobName = "e-Way bill Template_v1.xlsx";
                } else if (Constants.INVOICE_TEMPLATE_CODE_ID == downloadCustomTemplateReqDTO.getTemplateId()) {
                    blobName = "Invoice Template_v1.xlsx";
                } else if (Constants.VENDOR_DETAILS_TEMPLATE_CODE_ID == downloadCustomTemplateReqDTO.getTemplateId()) {
                    blobName = "Vendor Details Template_v1.xlsx";
                } else if (Constants.COMUNICATION_TEMPLATE_CODE_ID == downloadCustomTemplateReqDTO.getTemplateId()) {
                    blobName = "Inward Register Template_v1.xlsx";
                } else if (Constants.COMUNICATION_PAYMENT_TEMPLATE_CODE_ID == downloadCustomTemplateReqDTO
                                .getTemplateId()) {
                    blobName = "Payment details Template_v1.xlsx";
                } else if (Constants.COMUNICATION_TDS_TEMPLATE_CODE_ID == downloadCustomTemplateReqDTO
                                .getTemplateId()) {
                    blobName = "TDS_Template_v1.xlsx";
                } else if (Constants.COMUNICATION_ITC_TEMPLATE_CODE_ID == downloadCustomTemplateReqDTO
                                .getTemplateId()) {
                    blobName = "ITC Template_v1.xlsx";
                }

                entityCloudCredential = entityCloudCredentialsServiceImpl
                                .getEntityCloudCredentials(Integer.valueOf(downloadCustomTemplateReqDTO.getEntityId()));
            } else {
                customTemplateName = customTemplateReporitoryImpl.getCustomTemplateNameById(
                                CustomTemplateName.builder().id(downloadCustomTemplateReqDTO.getTemplateId()).build());
                blobName = customTemplateName.getName() + Constants.UNDERSCORE + customTemplateName.getPan()
                                + Constants.DOTSEPERATOR + Constants.VENODR_DETAIL_TEMPLATE_FILE_TYPE_XLSX;
                entityCloudCredential = entityCloudCredentialsServiceImpl
                                .getEntityCloudCredentials(customTemplateName.getEntityId());

            }

        } catch (EmptyResultDataAccessException e) {
            throw new ResourceNotFoundException(DownloadCustomTemplateReqDTO.class, "customTemplateId",
                            downloadCustomTemplateReqDTO.getTemplateId() + "");
        }

        String tempFileName = "";

        File file = new File(tempFolderPath);

        if (!file.exists()) {
            file.mkdir();
        }

        if (StringUtils.isNotBlank(tempFolderPath)) {
            tempFileName = new StringBuilder().append(tempFolderPath + File.separator + blobName).toString();
        } else {

            tempFileName = blobName;
        }
        String downloadUrl = "";
        try {
            downloadUrl = azureBlobServiceImpl.getAzureBlobUrl(blobName, entityCloudCredential);
        } catch (Exception e) {
            throw new CommonMasterBusinessException("File not found,please contact to administrator");
        }

        return fileServiceImpl.createFileWithURL(downloadUrl, tempFileName);

    }

    /**
     * Preview template sample data.
     *
     * @param file
     *            the file
     * @param previewCustomTemplateSampleDataReq
     *            the preview custom template sample data req
     * @return the map
     * @throws BVMSException
     */
    @Override
    public Map<String, List<String>> previewTemplateSampleData(MultipartFile file,
                    String previewCustomTemplateSampleDataReq) throws BVMSException {
        List<CustomValidationError> customValidationErrorList = new ArrayList<>();
        Map<String, List<String>> resMap = new LinkedHashMap<>();
        if (file != null) {
            validateFile(file, customValidationErrorList);

            if (!customValidationErrorList.isEmpty()) {
                throw new CustomValidationViolationException(customValidationErrorList);
            }
            String filepath = fileServiceImpl.saveFileInLocalStorage(file, file.getOriginalFilename());
            File convFile = null;
            try {
                convFile = new File(filepath);
                return readSampleDataFromFile(convFile);
            } catch (BVMSException e1) {
                throw new BVMSException(e1);

            } finally {
                try {
                    if (convFile.exists())
                        Files.deleteIfExists(convFile.toPath());
                } catch (IOException e) {
                    log.error("Error in reading file", e);
                }
            }

        } else {
            PreviewCustomTemplateSampleDataReqDTO previewCustomTemplateSampleData = convertPreviewCustomTemplateSampleDataReqDTO(
                            previewCustomTemplateSampleDataReq);

            validatePreviewCustomTemplateSampleData(previewCustomTemplateSampleData, customValidationErrorList);

            if (!customValidationErrorList.isEmpty()) {
                throw new CustomValidationViolationException(customValidationErrorList);
            }
            List<TemplateSampleData> templateSampleDataList = customTemplateReporitoryImpl
                            .getCustomTemplateSampleData(TemplateSampleData.builder()
                                            .amCustomTemplateNameId(
                                                            previewCustomTemplateSampleData.getCustomTemplateId())
                                            .build());

            for (TemplateSampleData templateSampleData : templateSampleDataList) {
                List<String> valueList = null;
                if (templateSampleData.getColumnValue() != null) {
                    String[] valueArray = templateSampleData.getColumnValue().split(StringConstant.PIPE);
                    valueList = Arrays.asList(valueArray);
                }
                resMap.put(templateSampleData.getColumnName(), valueList);
            }

            templateSampleDataList.clear();
            return resMap;
        }
    }

    private Map<String, List<String>> readSampleDataFromFile(File convFile) throws BVMSException {
        Map<String, List<String>> resMap = new LinkedHashMap<>();

        try {
            if (FilenameUtils.getExtension(convFile.getName()).equals(Constants.XLSX)
                            || FilenameUtils.getExtension(convFile.getName()).equals(Constants.XLS)) {
                resMap = commonExcelServiceImpl.readCustomTemplateSampleData(convFile);
            } else if (FilenameUtils.getExtension(convFile.getName()).equals(Constants.CSV)) {
                resMap = commonCsvServiceImpl.readCustomTemplateSampleData(convFile);
            }
            return resMap;
        } catch (BVMSException e) {
            throw new BVMSException(e);
        }
    }

    /**
     * Convert preview custom template sample data req DTO.
     *
     * @param previewCustomTemplateSampleDataReq
     *            the preview custom template sample data req
     * @return the preview custom template sample data req DTO
     */
    private PreviewCustomTemplateSampleDataReqDTO convertPreviewCustomTemplateSampleDataReqDTO(
                    String previewCustomTemplateSampleDataReq) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        List<CustomValidationError> customValidationErrorList = new ArrayList<>();

        try {
            return mapper.readValue(previewCustomTemplateSampleDataReq, PreviewCustomTemplateSampleDataReqDTO.class);

        } catch (Exception ex) {
            log.error("Error in previewTemplateSampleData", ex);
            CustomValidationError customValidationError = new CustomValidationError(
                            PreviewCustomTemplateSampleDataReqDTO.class.getName(), "previewCustomTemplateSampleDataReq",
                            previewCustomTemplateSampleDataReq,
                            "Unable to parse request parameter - previewCustomTemplateSampleDataReq data in json object");
            customValidationErrorList.add(customValidationError);
            throw new CustomValidationViolationException(customValidationErrorList);
        }
    }

    /**
     * Validate preview custom template sample data.
     *
     * @param previewCustomTemplateSampleDataReqDTO
     *            the preview custom template sample data req DTO
     * @param customValidationErrorList
     *            the custom validation error list
     */
    private void validatePreviewCustomTemplateSampleData(
                    PreviewCustomTemplateSampleDataReqDTO previewCustomTemplateSampleDataReqDTO,
                    List<CustomValidationError> customValidationErrorList) {
        Set<ConstraintViolation<Object>> constraintViolationList = ValidateBeanUtil
                        .validateBean(previewCustomTemplateSampleDataReqDTO);
        if (constraintViolationList != null && !constraintViolationList.isEmpty()) {
            for (ConstraintViolation<?> constraint : constraintViolationList) {
                CustomValidationError customValidationError = new CustomValidationError(
                                AddCustomTemplateDetailsReqDTO.class.getName(), constraint.getPropertyPath().toString(),
                                constraint.getInvalidValue(), constraint.getMessage());
                customValidationErrorList.add(customValidationError);
            }
        }
    }

    /**
     * Search module list.
     *
     * @param searchModuleListReqDTO
     *            the search module list req DTO
     * @return the list
     */
    @Override
    public List<SearchModuleListResDTO> searchModuleList(SearchModuleListReqDTO searchModuleListReqDTO) {
        List<TemplateModule> templateModuleList = null;
        if (searchModuleListReqDTO.getIsCustomTemplate() != null && searchModuleListReqDTO.getIsCustomTemplate()) {

            List<CustomValidationError> customValidationErrorList = new ArrayList<>();

            validateSearchModuleListReqDTO(searchModuleListReqDTO, customValidationErrorList);

            if (!customValidationErrorList.isEmpty()) {
                throw new CustomValidationViolationException(customValidationErrorList);
            }

            List<EntityMasterResDTO> entityMasterList = validateEntityMaster(searchModuleListReqDTO.getGstinOrPan(),
                            searchModuleListReqDTO.getGstinOrPanList(), customValidationErrorList,
                            searchModuleListReqDTO);

            String taxpayerPans = null;
            if (searchModuleListReqDTO.getGstinOrPan().equals(Constants.GSTIN)) {
                List<String> panList = entityMasterList.stream().map(EntityMasterResDTO::getPan)
                                .collect(Collectors.toList());
                Set<String> uniquetPans = new HashSet<>(panList);
                List<String> pans = new ArrayList<>(uniquetPans);
                taxpayerPans = StringConstant.joinString(pans);
                panList.clear();
                uniquetPans.clear();
                pans.clear();
            } else if (searchModuleListReqDTO.getGstinOrPan().equals(Constants.PAN)) {
                taxpayerPans = StringConstant.joinString(searchModuleListReqDTO.getGstinOrPanList());
            }

            templateModuleList = customTemplateReporitoryImpl.getCustomModuleList(
                            CustomTemplateName.builder().name(searchModuleListReqDTO.getTemplateName())
                                            .pldStatus(Constants.PLD_STATUS_ACTIVE).pan(taxpayerPans).build(),
                            Constants.PICKUP_MASTER_TEMPLATE_TYPE_ID, Constants.PICKUP_MASTER_MODULES_ID);

        } else {
            templateModuleList = customTemplateReporitoryImpl.getDefaultModuleList(
                            Constants.PICKUP_MASTER_TEMPLATE_TYPE_ID, Constants.PICKUP_MASTER_MODULES_ID);
        }

        return templateModuleList.stream()
                        .map(customTemplateModule -> SearchModuleListResDTO.builder()
                                        .count(customTemplateModule.getCount()).id(customTemplateModule.getId())
                                        .name(customTemplateModule.getModuleName()).build())
                        .collect(Collectors.toList());
    }

    /**
     * Validate search module list req DTO.
     *
     * @param searchModuleListReqDTO
     *            the search module list req DTO
     * @param customValidationErrorList
     *            the custom validation error list
     */
    private void validateSearchModuleListReqDTO(SearchModuleListReqDTO searchModuleListReqDTO,
                    List<CustomValidationError> customValidationErrorList) {

        Set<ConstraintViolation<Object>> constraintViolationList = ValidateBeanUtil
                        .validateBean(searchModuleListReqDTO);
        if (constraintViolationList != null && !constraintViolationList.isEmpty()) {
            for (ConstraintViolation<?> constraint : constraintViolationList) {
                CustomValidationError customValidationError = new CustomValidationError(
                                SearchModuleListReqDTO.class.getName(), constraint.getPropertyPath().toString(),
                                constraint.getInvalidValue(), constraint.getMessage());
                customValidationErrorList.add(customValidationError);
            }
        }
    }

    /**
     * Validate entity master.
     *
     * @param gstinOrPan
     *            the gstin or pan
     * @param gstinOrPanList
     *            the gstin or pan list
     * @param customValidationErrorList
     *            the custom validation error list
     * @param searchModuleListReqDTO
     *            the search module list req DTO
     * @return the list
     */
    private List<EntityMasterResDTO> validateEntityMaster(String gstinOrPan, List<String> gstinOrPanList,
                    List<CustomValidationError> customValidationErrorList,
                    SearchModuleListReqDTO searchModuleListReqDTO) {
        List<EntityMasterResDTO> entityMasterList = entityMasterServiceImpl.getEntityMasterList(gstinOrPanList,
                        gstinOrPan, Integer.valueOf(searchModuleListReqDTO.getEntityTypeId()));

        if (entityMasterList == null || entityMasterList.isEmpty()) {
            CustomValidationError customValidationError = new CustomValidationError(
                            SearchTemplateDetailsReqDTO.class.getName(), Constants.GSTIN_OR_PAN_LIST, gstinOrPanList,
                            Constants.ENTITY_NOT_FOUND_EXCEPTION_MSG + gstinOrPan + Constants.WITH_VALUES_EXCEPTION_MSG
                                            + gstinOrPanList);
            customValidationErrorList.add(customValidationError);
            throw new CustomValidationViolationException(customValidationErrorList);
        }
        return entityMasterList;
    }

    /**
     * Search module wise template list.
     *
     * @param searchTemplateDetailsReqDTO
     *            the search template details req DTO
     * @return the gets the module wise template DTO
     */
    @Override
    public GetModuleWiseTemplateDTO searchModuleWiseTemplateList(
                    SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO) {
        CustomTemplateName customTemplateNameReq = null;

        List<PaginationResDTO> paginationResDTOList = new ArrayList<>();
        List<SearchTemplateListResDTO> searchTemplateListResDTOList = null;

        Pageable paging = PageRequest.of(searchTemplateDetailsReqDTO.getPage(), searchTemplateDetailsReqDTO.getSize());

        List<ModuleCodeAndNameDTO> moduleCodeAndNameDTOList = customTemplateReporitoryImpl.getModuleNameAndCode(45,
                        Integer.valueOf(searchTemplateDetailsReqDTO.getModuleId()));

        for (int i = 0; i < moduleCodeAndNameDTOList.size(); i++) {

            moduleCodeAndNameDTOList.get(i).getModuleCode();

            if (searchTemplateDetailsReqDTO.getIsCustomTemplate() != null
                            && searchTemplateDetailsReqDTO.getIsCustomTemplate()) {
                List<EntityMasterResDTO> entityMasterList = entityMasterServiceImpl.getEntityMasterList(
                                searchTemplateDetailsReqDTO.getGstinOrPanList(),
                                searchTemplateDetailsReqDTO.getGstinOrPan(),
                                Integer.valueOf(searchTemplateDetailsReqDTO.getEntityTypeId()));

                if (entityMasterList == null || entityMasterList.isEmpty()) {
                    List<CustomValidationError> customValidationErrorList = new ArrayList<>();
                    CustomValidationError customValidationError = new CustomValidationError(
                                    SearchTemplateDetailsReqDTO.class.getName(), Constants.GSTIN_OR_PAN_LIST,
                                    searchTemplateDetailsReqDTO.getGstinOrPanList(),
                                    Constants.ENTITY_NOT_FOUND_EXCEPTION_MSG
                                                    + searchTemplateDetailsReqDTO.getGstinOrPan()
                                                    + Constants.WITH_VALUES_EXCEPTION_MSG
                                                    + searchTemplateDetailsReqDTO.getGstinOrPanList());
                    customValidationErrorList.add(customValidationError);
                    throw new CustomValidationViolationException(customValidationErrorList);
                }

                String taxpayerPans = getEntityPan(searchTemplateDetailsReqDTO, entityMasterList);

                customTemplateNameReq = CustomTemplateName.builder().pan(taxpayerPans)
                                .name(searchTemplateDetailsReqDTO.getTemplateName())
                                .pldStatus(Constants.PLD_STATUS_ACTIVE).build();

                PageImpl<CustomTemplateName> pagedResult = customTemplateReporitoryImpl.getCustomTemplatesName(
                                customTemplateNameReq, Constants.SMPICKTEMPLATEID,
                                moduleCodeAndNameDTOList.get(i).getModuleCode(), Constants.PICKUP_MASTER_MODULES_ID,
                                paging, searchTemplateDetailsReqDTO.getReportId());

                if (pagedResult != null) {
                    searchTemplateListResDTOList = pagedResult.getContent().stream()
                                    .map(customTemplateName -> SearchTemplateListResDTO.builder()
                                                    .name(customTemplateName.getName()).id(customTemplateName.getId())
                                                    .isDisabled(customTemplateName.getPldStatus())
                                                    .uploadedBy(customTemplateName.getUserName())
                                                    .uploadedOn(DateUtil.convertDateToString(
                                                                    customTemplateName.getCreatedAt(),
                                                                    DateUtil.DATETIMEFORMATTERFORUI))
                                                    .baseTemplate(customTemplateName.getModule()).build())
                                    .collect(Collectors.toList());

                    PaginationResDTO paginationResDTO = PaginationResDTO.builder()
                                    .totalElements(pagedResult.getTotalElements())
                                    .name(moduleCodeAndNameDTOList.get(i).getModuleName())
                                    .moduleId(moduleCodeAndNameDTOList.get(i).getModuleCode())
                                    .searchElements(searchTemplateListResDTOList).build();

                    paginationResDTOList.add(paginationResDTO);
                }

            } else {

                PageImpl<PickupListDetail> pagedResult = pickupMasterRepositoryImpl
                                .searchModulesPickupMasterByNamePickKey(PickupListDetail.builder()
                                                .pickKey(moduleCodeAndNameDTOList.get(i).getModuleCode())
                                                .name(Constants.PLD_TEMPLATE_TYPE).build());

                searchTemplateListResDTOList = pagedResult.getContent().stream()
                                .map(pickupListDetail -> SearchTemplateListResDTO.builder()
                                                .name(pickupListDetail.getName()).id(pickupListDetail.getId())
                                                .code(pickupListDetail.getCode())
                                                .isDisabled(pickupListDetail.getPldStatus())
                                                .uploadedBy(pickupListDetail.getUserName())
                                                .uploadedOn(DateUtil.convertDateToString(
                                                                pickupListDetail.getCreatedAt(),
                                                                DateUtil.DATETIMEFORMATTERFORUI))
                                                .baseTemplate(pickupListDetail.getModuleName()).build())
                                .collect(Collectors.toList());
                PaginationResDTO paginationResDTO = PaginationResDTO.builder()
                                .totalElements(pagedResult.getTotalElements())
                                .name(moduleCodeAndNameDTOList.get(i).getModuleName())
                                .moduleId(moduleCodeAndNameDTOList.get(i).getModuleCode())
                                .searchElements(searchTemplateListResDTOList).build();

                paginationResDTOList.add(paginationResDTO);

            }
        }
        return new GetModuleWiseTemplateDTO(paginationResDTOList);

    }

    private String getEntityPan(SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO,
                    List<EntityMasterResDTO> entityMasterList) {
        String taxpayerPans = null;
        if (searchTemplateDetailsReqDTO.getGstinOrPan().equals(Constants.GSTIN)) {
            List<String> panList = entityMasterList.stream().map(EntityMasterResDTO::getPan)
                            .collect(Collectors.toList());
            Set<String> uniquetPans = new HashSet<>(panList);
            List<String> pans = new ArrayList<>(uniquetPans);
            taxpayerPans = String.join(",",
                            panList.stream().map(name -> ("'" + name + "'")).collect(Collectors.toList()));
            panList.clear();
            uniquetPans.clear();
            pans.clear();
        } else if (searchTemplateDetailsReqDTO.getGstinOrPan().equals(Constants.PAN)) {

            taxpayerPans = "'" + StringConstant.joinString(searchTemplateDetailsReqDTO.getGstinOrPanList()) + "'";
        }
        return taxpayerPans;
    }

    /**
     * Search custom email place holders.
     *
     * @param searchCustomEmailPlaceHoldersReqDTO
     *            the search custom email place holders req DTO
     * @return the list
     */
    @Override
    public List<CustomEmailPlaceHoldersResDTO> searchCustomEmailPlaceHolders(
                    SearchCustomEmailPlaceHoldersReqDTO searchCustomEmailPlaceHoldersReqDTO) {
        List<CustomEmailTemplatePlaceholderDictionary> customEmailTemplatePlaceholderDictionaryList = customTemplateReporitoryImpl
                        .searchCustomEmailPlaceHolders(CustomEmailTemplatePlaceholderDictionary.builder()
                                        .pldModuleId(searchCustomEmailPlaceHoldersReqDTO.getModuleId())
                                        .refTemplateId(searchCustomEmailPlaceHoldersReqDTO.getRefTemplateId()).build());
        return customEmailTemplatePlaceholderDictionaryList.stream()
                        .map(customEmailTemplatePlaceholderDictionary -> CustomEmailPlaceHoldersResDTO.builder()
                                        .description(customEmailTemplatePlaceholderDictionary.getDescription())
                                        .name(customEmailTemplatePlaceholderDictionary.getName()).build())
                        .collect(Collectors.toList());
    }

    /**
     * Update custom email template.
     *
     * @param updateCustomEmailTemplateReqDTO
     *            the update custom email template req DTO
     * @return the integer
     */
    @Override
    public Integer updateCustomEmailTemplate(MultipartFile signatureLogoFile, MultipartFile companyLogoFile,
                    UpdateCustomEmailTemplateReqDTO updateCustomEmailTemplateReqDTO) throws BDOException {
        String signatureLogoFileExtension = null;
        String companyLogoFileExtension = null;
        Blob signatureLogoBlob = null;
        Blob companyLogoBlob = null;

        if (signatureLogoFile != null) {
            signatureLogoFileExtension = FilenameUtils.getExtension(signatureLogoFile.getOriginalFilename());
            signatureLogoBlob = convertFileToBlob(signatureLogoFile);
        }
        if (companyLogoFile != null) {
            companyLogoFileExtension = FilenameUtils.getExtension(companyLogoFile.getOriginalFilename());
            companyLogoBlob = convertFileToBlob(companyLogoFile);
        }

        if (updateCustomEmailTemplateReqDTO.getCustomTemplateNameId() == null) {
            CustomTemplateName customTemplateName = CustomTemplateName.builder()
                            .createdBy(Integer.parseInt(updateCustomEmailTemplateReqDTO.getUserId()))
                            .entityId(Integer.parseInt(updateCustomEmailTemplateReqDTO.getEntityId()))
                            .name(updateCustomEmailTemplateReqDTO.getName())
                            .pan(updateCustomEmailTemplateReqDTO.getPan())
                            .pldTemplateId(updateCustomEmailTemplateReqDTO.getPldTemplateId())
                            .pldStatus(Constants.PLD_STATUS_ACTIVE).isEmailTemplate(Boolean.TRUE).build();

            checkIfCustomTemplateNameExists(customTemplateName);

            int customTemplateNameId = customTemplateReporitoryImpl.insertCustomTemplateName(customTemplateName);
            customTemplateName.setId(customTemplateNameId);
            customTemplateReporitoryImpl.insertCustomTemplateEmail(CustomTemplateEmail.builder()
                            .customTemplateNameId(customTemplateNameId)
                            .entityId(Integer.parseInt(updateCustomEmailTemplateReqDTO.getEntityId()))
                            .mailBody(updateCustomEmailTemplateReqDTO.getMailBody())
                            .mailSubject(updateCustomEmailTemplateReqDTO.getMailSubject())
                            .isDefaultTemplate(Boolean.FALSE)
                            .refTemplateId(updateCustomEmailTemplateReqDTO.getRefTemplateId())
                            .pan(updateCustomEmailTemplateReqDTO.getPan())
                            .signatureLogoFileExt(signatureLogoFileExtension)
                            .signatureLogoSizeKb(signatureLogoFile != null ? signatureLogoFile.getSize() / 1000 : null)
                            .signatureLogoImage(signatureLogoBlob).companyLogoFileExt(companyLogoFileExtension)
                            .companyLogoImage(companyLogoBlob)
                            .companyLogoSizeKb(companyLogoFile != null ? companyLogoFile.getSize() / 1000 : null)
                            .signatureText(updateCustomEmailTemplateReqDTO.getSignatureText()).build());
            return customTemplateNameId;
        } else {

            CustomTemplateEmail customTemplateEmail = CustomTemplateEmail.builder()
                            .customTemplateNameId(updateCustomEmailTemplateReqDTO.getCustomTemplateNameId())
                            .entityId(Integer.parseInt(updateCustomEmailTemplateReqDTO.getEntityId()))
                            .mailBody(updateCustomEmailTemplateReqDTO.getMailBody())
                            .mailSubject(updateCustomEmailTemplateReqDTO.getMailSubject())
                            .pan(updateCustomEmailTemplateReqDTO.getPan())
                            .signatureLogoFileExt(signatureLogoFileExtension)
                            .signatureLogoSizeKb(signatureLogoFile != null ? signatureLogoFile.getSize() / 1000 : null)
                            .signatureLogoImage(signatureLogoBlob).companyLogoFileExt(companyLogoFileExtension)
                            .companyLogoImage(companyLogoBlob)
                            .companyLogoSizeKb(companyLogoFile != null ? companyLogoFile.getSize() / 1000 : null)
                            .signatureText(updateCustomEmailTemplateReqDTO.getSignatureText()).build();

            CustomTemplateEmail customTemplateEmailExists = checkIfcustomTemplateEmailExists(customTemplateEmail);

            customTemplateReporitoryImpl.updateCustomTemplateEmail(customTemplateEmail);
            customTemplateReporitoryImpl.updateCustomTemplateEmailModifiedaAt(customTemplateEmail,
                            updateCustomEmailTemplateReqDTO.getName(), updateCustomEmailTemplateReqDTO.getUserId());
            customTemplateReporitoryImpl.insertCustomTemplateEmailArchived(CustomTemplateEmailArchived.builder()
                            .customTemplateEmailid(customTemplateEmailExists.getId())
                            .pan(customTemplateEmailExists.getPan()).entityId(customTemplateEmailExists.getEntityId())
                            .mailSubject(customTemplateEmailExists.getMailSubject())
                            .mailBody(customTemplateEmailExists.getMailBody())
                            .mailFooter(customTemplateEmailExists.getMailFooter())
                            .defaultCcReceipentsEmail(customTemplateEmailExists.getDefaultCcReceipentsEmail())
                            .disclaimer(customTemplateEmailExists.getDisclaimer())
                            .isHighImportance(customTemplateEmailExists.getIsHighImportance())
                            .enableNotificationQueue(customTemplateEmailExists.getEnableNotificationQueue())
                            .refTemplateId(customTemplateEmailExists.getRefTemplateId())
                            .isDefaultTemplate(customTemplateEmailExists.getIsDefaultTemplate())
                            .signatureLogoSizeKb(customTemplateEmailExists.getSignatureLogoSizeKb())
                            .signatureLogoFileExt(customTemplateEmailExists.getSignatureLogoFileExt())
                            .signatureLogoImage(customTemplateEmailExists.getSignatureLogoImage())
                            .companyLogoFileExt(customTemplateEmailExists.getCompanyLogoFileExt())
                            .companyLogoImage(customTemplateEmailExists.getCompanyLogoImage())
                            .companyLogoSizeKb(customTemplateEmailExists.getCompanyLogoSizeKb()).build());
            return updateCustomEmailTemplateReqDTO.getCustomTemplateNameId();
        }
    }

    private CustomTemplateName checkIfCustomTemplateNameExists(CustomTemplateName customTemplateName) {
        CustomTemplateName customTemplateNameExists = null;
        try {
            customTemplateNameExists = customTemplateReporitoryImpl.getCustomTemplateName(customTemplateName);
        } catch (EmptyResultDataAccessException e) {
            log.info("No template exists with name " + customTemplateName.getName());
        }
        if (customTemplateNameExists != null) {
            List<CustomValidationError> customValidationErrorList = new ArrayList<>();
            CustomValidationError customValidationError = new CustomValidationError(
                            AddCustomTemplateColumnMappingReqDTO.class.getName(), "name",
                            customTemplateName.getName() + "",
                            "Custom template with name " + customTemplateName.getName() + " already exists ");
            customValidationErrorList.add(customValidationError);
            throw new CustomValidationViolationException(customValidationErrorList);
        }
        return customTemplateName;
    }

    private CustomTemplateEmail checkIfcustomTemplateEmailExists(CustomTemplateEmail customTemplateEmail) {
        CustomTemplateEmail customTemplateEmailExists = null;
        try {
            customTemplateEmailExists = customTemplateReporitoryImpl
                            .checkIfCustomTemplateEmailExists(customTemplateEmail);
        } catch (EmptyResultDataAccessException e) {
            customTemplateEmailExists = null;
        }

        if (customTemplateEmailExists == null) {
            throw new ResourceNotFoundException(CustomTemplateEmail.class, "custom_template_name_id",
                            customTemplateEmail.getCustomTemplateNameId() + "");
        }
        return customTemplateEmailExists;
    }

    /**
     * Disable custom template.
     *
     * @param disableCustomTemplateDTO
     *            the disable custom template DTO
     * @throws AppBusinessException
     */
    @Override
    public void disableCustomTemplate(DisableCustomTemplateDTO disableCustomTemplateDTO) throws AppBusinessException {
        int reportStatus = 0;
        if (disableCustomTemplateDTO.getIsDisabled().equals("20")) {
            reportStatus = customTemplateReporitoryImpl
                            .getTemplateStatus(disableCustomTemplateDTO.getCustomTemplateId());
        }
        if (reportStatus == 0) {
            customTemplateReporitoryImpl.disableCustomTemplate(disableCustomTemplateDTO);
        } else {
            throw new AppBusinessException("This Template is already in use, can't be deactivated.");
        }

    }

    /**
     * Search email module list.
     *
     * @param searchModuleListReqDTO
     *            the search module list req DTO
     * @return the list
     */
    @Override
    public List<SearchModuleListResDTO> searchEmailModuleList(SearchModuleListReqDTO searchModuleListReqDTO) {
        List<TemplateModule> templateModuleList = null;
        String taxpayerPans = null;
        if (searchModuleListReqDTO.getIsCustomTemplate() != null && searchModuleListReqDTO.getIsCustomTemplate()) {

            List<CustomValidationError> customValidationErrorList = new ArrayList<>();

            validateSearchModuleListReqDTO(searchModuleListReqDTO, customValidationErrorList);

            if (!customValidationErrorList.isEmpty()) {
                throw new CustomValidationViolationException(customValidationErrorList);
            }

            List<EntityMasterResDTO> entityMasterList = validateEntityMaster(searchModuleListReqDTO.getGstinOrPan(),
                            searchModuleListReqDTO.getGstinOrPanList(), customValidationErrorList,
                            searchModuleListReqDTO);

            if (searchModuleListReqDTO.getGstinOrPan().equals(Constants.GSTIN)) {
                List<String> panList = entityMasterList.stream().map(EntityMasterResDTO::getPan)
                                .collect(Collectors.toList());
                Set<String> uniquetPans = new HashSet<>(panList);
                List<String> pans = new ArrayList<>(uniquetPans);
                taxpayerPans = StringConstant.joinString(pans);
                panList.clear();
                uniquetPans.clear();
                pans.clear();
            } else if (searchModuleListReqDTO.getGstinOrPan().equals(Constants.PAN)) {
                taxpayerPans = StringConstant.joinString(searchModuleListReqDTO.getGstinOrPanList());
            }

            templateModuleList = customTemplateReporitoryImpl.getCustomEmailModuleList(
                            CustomTemplateName.builder().name(searchModuleListReqDTO.getTemplateName())
                                            .pldStatus(Constants.PLD_STATUS_ACTIVE)
                                            .pldStatus(Constants.PLD_STATUS_INACTIVE).pan(taxpayerPans).build(),
                            Constants.PICKUP_MASTER_MODULES_ID, Constants.CUSTOM_EMAIL_TEMPLATE_IS_DEFAULT_TEMPLATE_NO);

        } else {
            templateModuleList = customTemplateReporitoryImpl.getDefaultEmailModuleList(
                            CustomTemplateName.builder().name(searchModuleListReqDTO.getTemplateName())
                                            .pldStatus(Constants.PLD_STATUS_ACTIVE)
                                            .pldStatus(Constants.PLD_STATUS_INACTIVE).pan(taxpayerPans).build(),
                            Constants.PICKUP_MASTER_MODULES_ID,
                            Constants.CUSTOM_EMAIL_TEMPLATE_IS_DEFAULT_TEMPLATE_YES);
        }

        return templateModuleList.stream()
                        .map(customTemplateModule -> SearchModuleListResDTO.builder()
                                        .count(customTemplateModule.getCount()).id(customTemplateModule.getId())
                                        .name(customTemplateModule.getModuleName()).build())
                        .collect(Collectors.toList());
    }

    /**
     * Search email module wise template list.
     *
     * @param searchTemplateDetailsReqDTO
     *            the search template details req DTO
     * @return the gets the module wise template DTO
     */
    @Override
    public GetModuleWiseTemplateDTO searchEmailModuleWiseTemplateList(
                    SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO) {
        CustomTemplateName customTemplateNameReq = null;
        PageImpl<CustomTemplateName> pagedResult = null;
        List<PaginationResDTO> paginationResDTOList = new ArrayList<>();
        List<SearchTemplateListResDTO> searchTemplateListResDTOList = null;

        Pageable paging = PageRequest.of(searchTemplateDetailsReqDTO.getPage(), searchTemplateDetailsReqDTO.getSize());

        if (searchTemplateDetailsReqDTO.getIsCustomTemplate() != null
                        && searchTemplateDetailsReqDTO.getIsCustomTemplate()) {
            List<EntityMasterResDTO> entityMasterList = entityMasterServiceImpl.getEntityMasterList(
                            searchTemplateDetailsReqDTO.getGstinOrPanList(),
                            searchTemplateDetailsReqDTO.getGstinOrPan(),
                            Integer.valueOf(searchTemplateDetailsReqDTO.getEntityTypeId()));

            if (entityMasterList == null || entityMasterList.isEmpty()) {
                List<CustomValidationError> customValidationErrorList = new ArrayList<>();
                CustomValidationError customValidationError = new CustomValidationError(
                                SearchTemplateDetailsReqDTO.class.getName(), Constants.GSTIN_OR_PAN_LIST,
                                searchTemplateDetailsReqDTO.getGstinOrPanList(),
                                Constants.ENTITY_NOT_FOUND_EXCEPTION_MSG + searchTemplateDetailsReqDTO.getGstinOrPan()
                                                + Constants.WITH_VALUES_EXCEPTION_MSG
                                                + searchTemplateDetailsReqDTO.getGstinOrPanList());
                customValidationErrorList.add(customValidationError);
                throw new CustomValidationViolationException(customValidationErrorList);
            }

            String taxpayerPans = null;
            if (searchTemplateDetailsReqDTO.getGstinOrPan().equals(Constants.GSTIN)) {
                List<String> panList = entityMasterList.stream().map(EntityMasterResDTO::getPan)
                                .collect(Collectors.toList());
                Set<String> uniquetPans = new HashSet<>(panList);
                List<String> pans = new ArrayList<>(uniquetPans);
                taxpayerPans = String.join(",",
                                panList.stream().map(name -> ("'" + name + "'")).collect(Collectors.toList()));
                panList.clear();
                uniquetPans.clear();
                pans.clear();
            } else if (searchTemplateDetailsReqDTO.getGstinOrPan().equals(Constants.PAN)) {

                taxpayerPans = "'" + StringConstant.joinString(searchTemplateDetailsReqDTO.getGstinOrPanList()) + "'";
            }

            customTemplateNameReq = CustomTemplateName.builder().pan(taxpayerPans)
                            .pldTemplateId(Integer.parseInt(searchTemplateDetailsReqDTO.getModuleId()))
                            .name(searchTemplateDetailsReqDTO.getTemplateName()).build();

            pagedResult = customTemplateReporitoryImpl.getCustomEmailTemplatesName(customTemplateNameReq, paging,
                            !searchTemplateDetailsReqDTO.getIsCustomTemplate());
        } else {
            customTemplateNameReq = CustomTemplateName.builder()
                            .pldTemplateId(Integer.parseInt(searchTemplateDetailsReqDTO.getModuleId()))
                            .name(searchTemplateDetailsReqDTO.getTemplateName()).build();
            pagedResult = customTemplateReporitoryImpl.getDefaultEmailTemplatesName(customTemplateNameReq, paging,
                            !searchTemplateDetailsReqDTO.getIsCustomTemplate());
        }

        if (pagedResult == null) {
            paginationResDTOList.add(defaultPaginationResponse());
            return new GetModuleWiseTemplateDTO(paginationResDTOList);
        } else {
            searchTemplateListResDTOList = pagedResult.getContent().stream()
                            .map(customTemplateName -> SearchTemplateListResDTO.builder()
                                            .name(customTemplateName.getName()).id(customTemplateName.getId())
                                            .isDisabled(customTemplateName.getPldStatus())
                                            .uploadedBy(customTemplateName.getUserName())
                                            .uploadedOn(DateUtil.convertDateToString(customTemplateName.getCreatedAt(),
                                                            DateUtil.DATETIMEFORMATTERFORUI))
                                            .pldModuleId(customTemplateName.getPldModuleId())
                                            .baseTemplate(customTemplateName.getModule())
                                            .refId(customTemplateName.getRefId()).build())
                            .collect(Collectors.toList());
            PaginationResDTO paginationResDTO = PaginationResDTO.builder().totalElements(pagedResult.getTotalElements())
//				.name(moduleCodeAndNameDTOList.get(i).getModuleName())
//				.moduleId(moduleCodeAndNameDTOList.get(i).getModuleCode())
                            .searchElements(searchTemplateListResDTOList).build();

            paginationResDTOList.add(paginationResDTO);

            return new GetModuleWiseTemplateDTO(paginationResDTOList);
        }

    }

    /**
     * Search default email template details.
     *
     * @param searchDefaultEmailDetailsReqDTO
     *            the search default email details req DTO
     * @return the default email template res DTO
     */
    @Override
    public DefaultEmailTemplateResDTO searchDefaultEmailTemplateDetails(
                    SearchDefaultEmailTemplateDetailsReqDTO searchDefaultEmailDetailsReqDTO) {
        CustomTemplateEmail customTemplateEmail = null;
        try {
            customTemplateEmail = customTemplateReporitoryImpl
                            .searchDefaultEmailDetails(
                                            CustomTemplateEmail.builder()
                                                            .refTemplateId(searchDefaultEmailDetailsReqDTO
                                                                            .getRefTemplateId())
                                                            .isDefaultTemplate(Boolean.TRUE).build(),
                                            searchDefaultEmailDetailsReqDTO.getModuleId());
        } catch (EmptyResultDataAccessException e) {
            throw new ResourceNotFoundException(CustomTemplateEmail.class, "moduleId",
                            searchDefaultEmailDetailsReqDTO.getModuleId() + "", "refTemplateId",
                            searchDefaultEmailDetailsReqDTO.getRefTemplateId() + "");
        }
        return DefaultEmailTemplateResDTO.builder().mailBody(customTemplateEmail.getMailBody())
                        .templateName(customTemplateEmail.getCustomTemplateName())
                        .subject(customTemplateEmail.getMailSubject()).build();
    }

    /**
     * Seach custom email ref template.
     *
     * @param searchCustomEmailRefTemplateReqDTO
     *            the search custom email ref template req DTO
     * @return the list
     */
    @Override
    public List<CustomEmailRefTemplateResDTO> seachCustomEmailRefTemplate(
                    SearchCustomEmailRefTemplateReqDTO searchCustomEmailRefTemplateReqDTO) {
        List<CustomEmailTemplateCategory> customEmailTemplateCategoryList = customTemplateReporitoryImpl
                        .getCustomEmailTemplateCategory(CustomEmailTemplateCategory.builder()
                                        .pldModuleId(searchCustomEmailRefTemplateReqDTO.getModuleId())
                                        .isActive(Constants.CUSTOM_EMAIL_TEMPLATE_CATEGORY_IS_ACTIVE_YES).build());
        return customEmailTemplateCategoryList.stream()
                        .map(customEmailTemplateCategory -> CustomEmailRefTemplateResDTO.builder()
                                        .id(customEmailTemplateCategory.getId())
                                        .refTemplate(customEmailTemplateCategory.getSubCategory()).build())
                        .collect(Collectors.toList());
    }

    /**
     * Seach custom email modules.
     *
     * @param searchCustomEmailModulesReqDTO
     *            the search custom email modules req DTO
     * @return the list
     */
    @Override
    public List<CustomEmailTemplateModulesResDTO> seachCustomEmailModules(
                    SearchCustomEmailModulesReqDTO searchCustomEmailModulesReqDTO) {
        List<CustomEmailTemplateCategory> customEmailTemplateCategoryList = customTemplateReporitoryImpl
                        .getCustomEmailModuleList();
        return customEmailTemplateCategoryList.stream()
                        .map(customEmailTemplateCategory -> CustomEmailTemplateModulesResDTO.builder()
                                        .moduleId(customEmailTemplateCategory.getPldModuleId())
                                        .moduleName(customEmailTemplateCategory.getName()).build())
                        .collect(Collectors.toList());
    }

    /**
     * Search custom email details.
     *
     * @param searchCustomEmailDetailsReqDTO
     *            the search custom email details req DTO
     * @return the custom email template details res DTO
     */
    @Override
    public CustomEmailTemplateDetailsResDTO searchCustomEmailDetails(
                    SearchCustomEmailDetailsReqDTO searchCustomEmailDetailsReqDTO) {
        CustomTemplateEmail customTemplateEmail = null;
        try {
            customTemplateEmail = customTemplateReporitoryImpl.getCustomEmailTemplateDetails(CustomTemplateEmail
                            .builder().customTemplateNameId(searchCustomEmailDetailsReqDTO.getCustomTemplateId())
                            .build());
            customTemplateReporitoryImpl.getFromAndTo(searchCustomEmailDetailsReqDTO, customTemplateEmail);
        } catch (EmptyResultDataAccessException e) {
            throw new ResourceNotFoundException(CustomTemplateEmail.class, "id",
                            searchCustomEmailDetailsReqDTO.getCustomTemplateId() + "");
        }
        return CustomEmailTemplateDetailsResDTO.builder().body(customTemplateEmail.getMailBody())
                        .customTemplateNameId(customTemplateEmail.getCustomTemplateNameId())
                        .moduleName(customTemplateEmail.getModuleName())
                        .refTemplateName(customTemplateEmail.getRefTemplateName())
                        .subject(customTemplateEmail.getMailSubject())
                        .refTemplateId(customTemplateEmail.getRefTemplateId())
                        .pldTemplateId(customTemplateEmail.getPldTemplateId())
                        .templateName(customTemplateEmail.getCustomTemplateName()).to(customTemplateEmail.getTo())
                        .from(customTemplateEmail.getFrom()).companyLogoExt(customTemplateEmail.getCompanyLogoFileExt())
                        .signatureLogoExt(customTemplateEmail.getSignatureLogoFileExt())
                        .signatureText(customTemplateEmail.getSignatureText()).build();
    }

    @Override
    public File searchCustomEmailLogo(SearchCustomEmailDetailsReqDTO searchCustomEmailDetailsReqDTO) {
        CustomTemplateEmail customTemplateEmail = null;
        try {
            customTemplateEmail = customTemplateReporitoryImpl.getCustomEmailTemplateDetails(CustomTemplateEmail
                            .builder().customTemplateNameId(searchCustomEmailDetailsReqDTO.getCustomTemplateId())
                            .build());
        } catch (EmptyResultDataAccessException e) {
            throw new ResourceNotFoundException(CustomTemplateEmail.class, "id",
                            searchCustomEmailDetailsReqDTO.getCustomTemplateId() + "");
        }
        if (log.isDebugEnabled()) {
            log.info("Custom Email Template data :", customTemplateEmail.toString());
        }
        File file = null;
        Blob blob = null;
        try {
            if (searchCustomEmailDetailsReqDTO.getLogoType().equals(Constants.SIGNATURE_LOGO_TYPE)
                            && customTemplateEmail.getSignatureLogoImage() != null) {
                file = new File(tempFolderPath + File.separator + Constants.SIGNATURE_LOGO_FILE_NAME + "."
                                + customTemplateEmail.getSignatureLogoFileExt());
                blob = customTemplateEmail.getSignatureLogoImage();
            } else if (searchCustomEmailDetailsReqDTO.getLogoType().equals(Constants.SIGNATURE_LOGO_TYPE)
                            && customTemplateEmail.getSignatureLogoImage() == null) {
                return null;
            }

            if (searchCustomEmailDetailsReqDTO.getLogoType().equals(Constants.COMPANY_LOGO_TYPE)
                            && customTemplateEmail.getCompanyLogoImage() != null) {
                file = new File(tempFolderPath + File.separator + Constants.COMPANY_LOGO_FILE_NAME + "."
                                + customTemplateEmail.getCompanyLogoFileExt());
                blob = customTemplateEmail.getCompanyLogoImage();
            } else if (searchCustomEmailDetailsReqDTO.getLogoType().equals(Constants.COMPANY_LOGO_TYPE)
                            && customTemplateEmail.getCompanyLogoImage() == null) {
                return null;
            }

            if (blob != null) {
                InputStream in = blob.getBinaryStream();
                byte[] buff = new byte[4096];
                int len = 0;
                try (FileOutputStream out = new FileOutputStream(file)) {
                    while ((len = in.read(buff)) != -1) {
                        out.write(buff, 0, len);
                    }
                }
                in.close();
            }
        } catch (Exception e) {
            throw new CommonMasterBusinessException("Error while writing custom template", e);
        }
        return file;
    }

    /**
     * Default pagination response.
     *
     * @return the pagination res DTO
     */
    public static PaginationResDTO defaultPaginationResponse() {
        return PaginationResDTO.builder().totalElements(0).searchElements(Collections.emptyList()).build();
    }

    @Override
    public PaginationResDTO searchCustomeTemplateList(SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO) {
        CustomTemplateName customTemplateNameReq = null;
        List<SearchTemplateListResDTO> searchTemplateListResDTOList = null;
        Pageable paging = PageRequest.of(searchTemplateDetailsReqDTO.getPage(), searchTemplateDetailsReqDTO.getSize());

        if (searchTemplateDetailsReqDTO.getIsCustomTemplate() != null
                        && searchTemplateDetailsReqDTO.getIsCustomTemplate()) {
            List<EntityMasterResDTO> entityMasterList = entityMasterServiceImpl.getEntityMasterList(
                            searchTemplateDetailsReqDTO.getGstinOrPanList(),
                            searchTemplateDetailsReqDTO.getGstinOrPan(),
                            Integer.valueOf(searchTemplateDetailsReqDTO.getEntityTypeId()));

            if (entityMasterList == null || entityMasterList.isEmpty()) {
                List<CustomValidationError> customValidationErrorList = new ArrayList<>();
                CustomValidationError customValidationError = new CustomValidationError(
                                SearchTemplateDetailsReqDTO.class.getName(), Constants.GSTIN_OR_PAN_LIST,
                                searchTemplateDetailsReqDTO.getGstinOrPanList(),
                                Constants.ENTITYNOTFOUNDFORTHE + searchTemplateDetailsReqDTO.getGstinOrPan()
                                                + Constants.WITHVALUES
                                                + searchTemplateDetailsReqDTO.getGstinOrPanList());
                customValidationErrorList.add(customValidationError);
                throw new CustomValidationViolationException(customValidationErrorList);
            }

            String taxpayerPans = null;
            if (searchTemplateDetailsReqDTO.getGstinOrPan().equals(Constants.GSTIN)) {
                List<String> panList = entityMasterList.stream().map(EntityMasterResDTO::getPan)
                                .collect(Collectors.toList());
                Set<String> uniquetPans = new HashSet<>(panList);
                List<String> pans = new ArrayList<>(uniquetPans);

                taxpayerPans = String.join(",",
                                panList.stream().map(name -> ("'" + name + "'")).collect(Collectors.toList()));
                panList.clear();
                uniquetPans.clear();
                pans.clear();
            } else if (searchTemplateDetailsReqDTO.getGstinOrPan().equals(Constants.PAN)) {

                taxpayerPans = "'" + StringConstant.joinString(searchTemplateDetailsReqDTO.getGstinOrPanList()) + "'";
            }

            customTemplateNameReq = CustomTemplateName.builder().pan(taxpayerPans)
                            .name(searchTemplateDetailsReqDTO.getTemplateName()).pldStatus(Constants.PLD_STATUS_ACTIVE)
                            .build();

            PageImpl<CustomTemplateName> pagedResult = customTemplateReporitoryImpl.getCustomTemplatesListName(
                            customTemplateNameReq, Constants.SMPICKTEMPLATEID,
                            searchTemplateDetailsReqDTO.getModuleId(), Constants.PICKUP_MASTER_MODULES_ID, paging,
                            searchTemplateDetailsReqDTO.getReportId());
            searchTemplateListResDTOList = pagedResult.getContent().stream()
                            .map(customTemplateName -> SearchTemplateListResDTO.builder()
                                            .name(customTemplateName.getName()).id(customTemplateName.getId())
                                            .uploadedBy(customTemplateName.getUserName())
                                            .uploadedOn(DateUtil.convertDateToString(customTemplateName.getCreatedAt(),
                                                            DateUtil.DATETIMEFORMATTERFORUI))
                                            .baseTemplate(customTemplateName.getModule()).build())
                            .collect(Collectors.toList());
            return PaginationResDTO.builder().totalElements(pagedResult.getTotalElements())

                            .searchElements(searchTemplateListResDTOList).build();
        } else {

            PageImpl<PickupListDetail> pagedResult = pickupMasterRepositoryImpl.searchModulesPickupMasterByNamePickKey(
                            PickupListDetail.builder().pickKey(searchTemplateDetailsReqDTO.getModuleId())
                                            .name(Constants.PLD_TEMPLATE_TYPE).build());

            searchTemplateListResDTOList = pagedResult.getContent().stream()
                            .map(pickupListDetail -> SearchTemplateListResDTO.builder().name(pickupListDetail.getName())
                                            .id(pickupListDetail.getId()).uploadedBy(pickupListDetail.getUserName())
                                            .uploadedOn(DateUtil.convertDateToString(pickupListDetail.getCreatedAt(),
                                                            DateUtil.DATETIMEFORMATTERFORUI))
                                            .baseTemplate(pickupListDetail.getModuleName()).build())
                            .collect(Collectors.toList());
            return PaginationResDTO.builder().totalElements(pagedResult.getTotalElements())

                            .searchElements(searchTemplateListResDTOList).build();
        }

    }

    private Blob convertFileToBlob(MultipartFile file) throws BDOException {
        if (file != null) {
            try {
                return new javax.sql.rowset.serial.SerialBlob(file.getBytes());
            } catch (IOException | SQLException e1) {
                throw new BDOException("Error while getting bytes from the file ", e1);
            }
        }
        return null;

    }

    @Override
    public List<SearchTemplateTypeResDTO> searchTemplateType() {
        List<TemplateType> templateTypeList = customTemplateReporitoryImpl.getTemplateType();
        return templateTypeList.stream().map(templateType -> {
            return SearchTemplateTypeResDTO.builder().name(templateType.getName()).code(templateType.getCode())
                            .shortDesc(templateType.getShortDesc()).id(templateType.getId())
                            .uploadedBy(templateType.getUserName()).uploadedOn(templateType.getCreatedAt())
                            .mandatoryColumns(templateType.getMandatoryColumns()).build();
        }).collect(Collectors.toList());
    }

}
