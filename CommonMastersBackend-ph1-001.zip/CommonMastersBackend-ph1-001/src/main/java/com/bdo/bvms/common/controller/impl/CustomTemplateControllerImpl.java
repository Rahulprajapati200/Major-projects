package com.bdo.bvms.common.controller.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;
import javax.validation.Valid;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dto.APIResponseDTO;
import com.bdo.bvms.common.dto.AddCustomTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.CustomEmailPlaceHoldersResDTO;
import com.bdo.bvms.common.dto.DeleteCustomTemplateReqDTO;
import com.bdo.bvms.common.dto.DisableCustomTemplateDTO;
import com.bdo.bvms.common.dto.DownloadCustomTemplateReqDTO;
import com.bdo.bvms.common.dto.SearchByIdReqDTO;
import com.bdo.bvms.common.dto.SearchCustomEmailDetailsReqDTO;
import com.bdo.bvms.common.dto.SearchCustomEmailModulesReqDTO;
import com.bdo.bvms.common.dto.SearchCustomEmailPlaceHoldersReqDTO;
import com.bdo.bvms.common.dto.SearchCustomEmailRefTemplateReqDTO;
import com.bdo.bvms.common.dto.SearchCustomTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.SearchDefaultEmailTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.SearchModuleListReqDTO;
import com.bdo.bvms.common.dto.SearchModuleListResDTO;
import com.bdo.bvms.common.dto.SearchTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.SearchTemplateTypeResDTO;
import com.bdo.bvms.common.dto.UpdateCustomEmailTemplateReqDTO;
import com.bdo.bvms.common.dto.UpdateCustomTemplateDetailsReqDTO;
import com.bdo.bvms.common.exception.apierror.CustomValidationError;
import com.bdo.bvms.common.exceptions.AppBusinessException;
import com.bdo.bvms.common.exceptions.BDOException;
import com.bdo.bvms.common.exceptions.BVMSException;
import com.bdo.bvms.common.exceptions.CustomValidationViolationException;
import com.bdo.bvms.common.service.ICustomTemplateService;
import com.bdo.bvms.common.util.ValidateBeanUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Class CustomTemplateControllerImpl.
 */

@RestController
@RequestMapping("/common")

/** The Constant log. */

public class CustomTemplateControllerImpl {

    /** The custom template service impl. */
    @Autowired
    private ICustomTemplateService customTemplateServiceImpl;

    /**
     * Search template header with auto mapped column.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param file
     *            the file
     * @param pldTemplateId
     *            the pld template id
     * @return the response entity
     * @throws BVMSException
     */
    @PostMapping(value = "/searchTemplateHeaderWithAutoMappedColumn")
    public ResponseEntity<APIResponseDTO> searchTemplateHeaderWithAutoMappedColumn(
                    HttpServletRequest httpServletRequest, @RequestParam(required = true) MultipartFile file,
                    @RequestParam(required = true) Integer pldTemplateId) throws BVMSException {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(customTemplateServiceImpl.searchTemplateHeaderWithAutoMappedColumn(file, pldTemplateId))
                        .message("Template headers received successfully").tag(httpServletRequest.getRequestURI())
                        .build());
    }

    /**
     * Adds the custom template details.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param addCustomTemplateDetailsReqDTO
     *            the add custom template details req DTO
     * @return the response entity
     * @throws BDOException
     */
    @PostMapping(value = "/addCustomTemplateDetails")
    public ResponseEntity<APIResponseDTO> addCustomTemplateDetails(HttpServletRequest httpServletRequest,
                    @RequestBody AddCustomTemplateDetailsReqDTO addCustomTemplateDetailsReqDTO) throws BDOException {

        customTemplateServiceImpl.addCustomTemplateDetails(addCustomTemplateDetailsReqDTO);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(null)
                                        .message("Custom template details added successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());

    }

    /**
     * Search default templates.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @return the response entity
     */
    @PostMapping(value = "/searchDefaultTemplates", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> searchDefaultTemplates(HttpServletRequest httpServletRequest) {
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1)
                                        .data(customTemplateServiceImpl.searchDefaultTemplates())
                                        .message("Searched default template type successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * Search template list.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param searchTemplateDetailsReqDTO
     *            the search template details req DTO
     * @return the response entity
     */
    @PostMapping(value = "/searchCustomTemplates", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> searchTemplateList(HttpServletRequest httpServletRequest,
                    @RequestBody SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO) {
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1)
                                        .data(customTemplateServiceImpl.searchTemplateList(searchTemplateDetailsReqDTO))
                                        .message("Searched vendor upload template type successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * Delete custom template.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param deleteCustomTemplateReqDTO
     *            the delete custom template req DTO
     * @return the response entity
     */
    @PostMapping(value = "/deleteCustomTemplate", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> deleteCustomTemplate(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid DeleteCustomTemplateReqDTO deleteCustomTemplateReqDTO) {
        customTemplateServiceImpl.deleteCustomTemplate(deleteCustomTemplateReqDTO);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(null)
                                        .message("Custom template deleted successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * Search custom template details.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param searchCustomTemplateDetailsReqDTO
     *            the search custom template details req DTO
     * @return the response entity
     */
    @PostMapping(value = "/searchCustomTemplateDetails", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> searchCustomTemplateDetails(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid SearchCustomTemplateDetailsReqDTO searchCustomTemplateDetailsReqDTO) {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(customTemplateServiceImpl.searchCustomTemplateDetails(searchCustomTemplateDetailsReqDTO))
                        .message("Searched custom template details successfully")
                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * Updatesearch custom template details.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param updateCustomTemplateDetailsReqDTO
     *            the update custom template details req DTO
     * @return the response entity
     */
    @PostMapping(value = "/updateCustomTemplateDetails", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> updatesearchCustomTemplateDetails(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid UpdateCustomTemplateDetailsReqDTO updateCustomTemplateDetailsReqDTO) {
        customTemplateServiceImpl.updateCustomTemplateDetails(updateCustomTemplateDetailsReqDTO);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(null)
                                        .message("Custom template details updated successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * Search custom template options mappings.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param searchByIdReqDTO
     *            the search by id req DTO
     * @return the response entity
     */
    @PostMapping(value = "/searchCustomTemplateOptionsMappings", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> searchCustomTemplateOptionsMappings(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid SearchByIdReqDTO searchByIdReqDTO) {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(Stream
                        .of(customTemplateServiceImpl.searchCustomTemplateOptionsMappings(searchByIdReqDTO.getId()))
                        .collect(Collectors.toList())).message("Searched custom template options mappings successfully")
                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * Search custom template header mappings.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param searchByIdReqDTO
     *            the search by id req DTO
     * @return the response entity
     */
    @PostMapping(value = "/searchCustomTemplateHeaderMappings", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> searchCustomTemplateHeaderMappings(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid SearchByIdReqDTO searchByIdReqDTO) {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(Stream
                        .of(customTemplateServiceImpl.searchCustomTemplateHeaderMappings(searchByIdReqDTO.getId()))
                        .collect(Collectors.toList())).message("Searched custom template options mappings successfully")
                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * Download custom template.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param downloadCustomTemplateReqDTO
     *            the download custom template req DTO
     * @param response
     *            the response
     * @return the response entity
     * @throws IOException
     */
    @PostMapping(value = "/downloadCustomTemplate")
    public ResponseEntity<Resource> downloadCustomTemplate(HttpServletRequest httpServletRequest,
                    @RequestBody DownloadCustomTemplateReqDTO downloadCustomTemplateReqDTO,
                    HttpServletResponse response) throws IOException {

        File file = customTemplateServiceImpl.downloadCustomTemplate(downloadCustomTemplateReqDTO);

        Long length = file.length();
        String fileName = file.getName();
        ByteArrayResource resource = null;

        resource = new ByteArrayResource(Files.readAllBytes(file.toPath()));

        Files.deleteIfExists(file.toPath());

        HttpHeaders headers = new HttpHeaders();
        headers.add(Constants.HEADERS_FILENAME, fileName);
        headers.add(Constants.ACCESS_CONTROL_EXPOSE_HEADERS, Constants.HEADERS_FILENAME);
        return ResponseEntity.ok().headers(headers).contentLength(length)
                        .contentType(MediaType.APPLICATION_OCTET_STREAM).body(resource);
    }

    /**
     * Preview template sample data.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param file
     *            the file
     * @param previewCustomTemplateSampleData
     *            the preview custom template sample data
     * @return the response entity
     * @throws BVMSException
     */
    @PostMapping(value = "/previewTemplateSampleData")
    public ResponseEntity<APIResponseDTO> previewTemplateSampleData(HttpServletRequest httpServletRequest,
                    @RequestParam(required = false) MultipartFile file,
                    @RequestParam(required = false) String previewCustomTemplateSampleData) throws BVMSException {
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1)
                                        .data(customTemplateServiceImpl.previewTemplateSampleData(file,
                                                        previewCustomTemplateSampleData))
                                        .message("Template sample data received successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * Search module list.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param searchModuleListReqDTO
     *            the search module list req DTO
     * @return the response entity
     */
    @PostMapping(value = "/searchModuleList")
    public ResponseEntity<APIResponseDTO> searchModuleList(HttpServletRequest httpServletRequest,
                    @RequestBody SearchModuleListReqDTO searchModuleListReqDTO) {
        List<SearchModuleListResDTO> searchModuleListResDTOList = customTemplateServiceImpl
                        .searchModuleList(searchModuleListReqDTO);
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(searchModuleListResDTOList)
                        .message("Got module list successfully").tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * Search module wise template list.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param searchTemplateDetailsReqDTO
     *            the search template details req DTO
     * @return the response entity
     */
    @PostMapping(value = "/searchModuleWiseTemplateList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> searchModuleWiseTemplateList(HttpServletRequest httpServletRequest,
                    @RequestBody SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO) {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(customTemplateServiceImpl.searchModuleWiseTemplateList(searchTemplateDetailsReqDTO))
                        .message("Searched Module Wise vendor upload template type successfully")
                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * Search custom email place holders.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param searchCustomEmailPlaceHoldersReqDTO
     *            the search custom email place holders req DTO
     * @return the response entity
     */
    @PostMapping(value = "/searchCustomEmailPlaceHolders")
    public ResponseEntity<APIResponseDTO> searchCustomEmailPlaceHolders(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid SearchCustomEmailPlaceHoldersReqDTO searchCustomEmailPlaceHoldersReqDTO) {
        List<CustomEmailPlaceHoldersResDTO> customEmailPlaceHoldersResDTOList = customTemplateServiceImpl
                        .searchCustomEmailPlaceHolders(searchCustomEmailPlaceHoldersReqDTO);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(customEmailPlaceHoldersResDTOList)
                                        .message("Got custom email place holders successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * Adds and updates the custom email template.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param updateCustomEmailTemplateReqDTO
     *            the add custom email template req DTO
     * @return the response entity
     * @throws BDOException
     * @throws JsonProcessingException
     * @throws JsonMappingException
     */

    @PostMapping(value = "/updateCustomEmailTemplate")
    public ResponseEntity<APIResponseDTO> updateCustomEmailTemplate(HttpServletRequest httpServletRequest,
                    @RequestParam(required = true) String updateCustomEmailTemplateReq,
                    @RequestParam(name = "signatureLogo", required = false) MultipartFile signatureLogo,
                    @RequestParam(name = "companyLogo", required = false) MultipartFile companyLogo)
                    throws BDOException, JsonProcessingException {

        UpdateCustomEmailTemplateReqDTO updateCustomEmailTemplateReqDTO = null;
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        List<CustomValidationError> customValidationErrorList = new ArrayList<>();

        updateCustomEmailTemplateReqDTO = mapper.readValue(updateCustomEmailTemplateReq,
                        UpdateCustomEmailTemplateReqDTO.class);

        validateUpdateCustomEmailTemplateReq(updateCustomEmailTemplateReqDTO, customValidationErrorList);
        if (signatureLogo != null) {
            validateFile(signatureLogo, customValidationErrorList);
        }
        if (companyLogo != null) {
            validateFile(companyLogo, customValidationErrorList);
        }
        if (!customValidationErrorList.isEmpty()) {
            throw new CustomValidationViolationException(customValidationErrorList);
        }

        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1)
                                        .data(customTemplateServiceImpl.updateCustomEmailTemplate(signatureLogo,
                                                        companyLogo, updateCustomEmailTemplateReqDTO))
                                        .message("Custom email template details updated successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

    @PostMapping(value = "/disableEnableCustomTemplate")
    public ResponseEntity<APIResponseDTO> disableCustomTemplate(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid DisableCustomTemplateDTO disableCustomTemplateDTO) throws AppBusinessException {
        customTemplateServiceImpl.disableCustomTemplate(disableCustomTemplateDTO);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(null)
                                        .message("Custom template disabled/enabled successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * Search email module list.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param searchModuleListReqDTO
     *            the search module list req DTO
     * @return the response entity
     */
    @PostMapping(value = "/searchEmailModuleList")
    public ResponseEntity<APIResponseDTO> searchEmailModuleList(HttpServletRequest httpServletRequest,
                    @RequestBody SearchModuleListReqDTO searchModuleListReqDTO) {
        List<SearchModuleListResDTO> searchModuleListResDTOList = customTemplateServiceImpl
                        .searchEmailModuleList(searchModuleListReqDTO);
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(searchModuleListResDTOList)
                        .message("Got email module list successfully").tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * v Search email module wise template list.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param searchTemplateDetailsReqDTO
     *            the search template details req DTO
     * @return the response entity
     */
    @PostMapping(value = "/searchEmailModuleWiseTemplateList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> searchEmailModuleWiseTemplateList(HttpServletRequest httpServletRequest,
                    @RequestBody SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO) {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(customTemplateServiceImpl.searchEmailModuleWiseTemplateList(searchTemplateDetailsReqDTO))
                        .message("Searched Email Module Wise vendor upload template type successfully")
                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * @param httpServletRequest
     * @param searchDefaultEmailDetailsReqDTO
     * @return
     */
    @PostMapping(value = "/searchDefaultEmailTemplateDetails", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> seachDefaultEmailTemplateDetails(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid SearchDefaultEmailTemplateDetailsReqDTO searchDefaultEmailDetailsReqDTO) {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(customTemplateServiceImpl
                                        .searchDefaultEmailTemplateDetails(searchDefaultEmailDetailsReqDTO))
                        .message("Searched Default email template details successfully")
                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * @param httpServletRequest
     * @param searchCustomEmailRefTemplateReqDTO
     * @return
     */
    @PostMapping(value = "/searchCustomEmailRefTemplate", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> seachCustomEmailRefTemplate(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid SearchCustomEmailRefTemplateReqDTO searchCustomEmailRefTemplateReqDTO) {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(customTemplateServiceImpl.seachCustomEmailRefTemplate(searchCustomEmailRefTemplateReqDTO))
                        .message("Searched custom email reference template successfully")
                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * @param httpServletRequest
     * @param searchCustomEmailModulesReqDTO
     * @return
     */
    @PostMapping(value = "/searchCustomEmailModules", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> seachCustomEmailRefTemplate(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid SearchCustomEmailModulesReqDTO searchCustomEmailModulesReqDTO) {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(customTemplateServiceImpl.seachCustomEmailModules(searchCustomEmailModulesReqDTO))
                        .message("Searched custom email modules successfully").tag(httpServletRequest.getRequestURI())
                        .build());
    }

    /**
     * @param httpServletRequest
     * @param searchCustomEmailDetailsReqDTO
     * @return
     */
    @PostMapping(value = "/searchCustomEmailDetails", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> searchCustomEmailDetails(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid SearchCustomEmailDetailsReqDTO searchCustomEmailDetailsReqDTO) {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(customTemplateServiceImpl.searchCustomEmailDetails(searchCustomEmailDetailsReqDTO))
                        .message("Searched custom email details successfully").tag(httpServletRequest.getRequestURI())
                        .build());
    }

    @PostMapping(value = "/searchCustomEmailLogo", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Resource> searchCustomEmailLogo(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid SearchCustomEmailDetailsReqDTO searchCustomEmailDetailsReqDTO)
                    throws IOException {
        File file = customTemplateServiceImpl.searchCustomEmailLogo(searchCustomEmailDetailsReqDTO);

        Long length = file.length();
        String fileName = file.getName();
        ByteArrayResource resource = null;

        resource = new ByteArrayResource(Files.readAllBytes(file.toPath()));

        Files.deleteIfExists(file.toPath());

        HttpHeaders headers = new HttpHeaders();
        headers.add(Constants.HEADERS_FILENAME, fileName);
        headers.add(Constants.ACCESS_CONTROL_EXPOSE_HEADERS, Constants.HEADERS_FILENAME);
        return ResponseEntity.ok().headers(headers).contentLength(length)
                        .contentType(MediaType.APPLICATION_OCTET_STREAM).body(resource);
    }

    @PostMapping(value = "/searchCustomTemplatesList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> searchCustomTemplateList(HttpServletRequest httpServletRequest,
                    @RequestBody SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO) {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(customTemplateServiceImpl.searchCustomeTemplateList(searchTemplateDetailsReqDTO))
                        .message("Searched custom template list successfully").tag(httpServletRequest.getRequestURI())
                        .build());
    }

    private void validateUpdateCustomEmailTemplateReq(UpdateCustomEmailTemplateReqDTO updateCustomEmailTemplateReqDTO,
                    List<CustomValidationError> customValidationErrorList) {

        Set<ConstraintViolation<Object>> constraintViolationList = ValidateBeanUtil
                        .validateBean(updateCustomEmailTemplateReqDTO);
        if (constraintViolationList != null && !constraintViolationList.isEmpty()) {
            for (ConstraintViolation<?> constraint : constraintViolationList) {
                CustomValidationError customValidationError = new CustomValidationError(
                                UpdateCustomEmailTemplateReqDTO.class.getName(),
                                constraint.getPropertyPath().toString(), constraint.getInvalidValue(),
                                constraint.getMessage());
                customValidationErrorList.add(customValidationError);
            }
        }

    }

    private void validateFile(MultipartFile file, List<CustomValidationError> customValidationErrorList) {
        if (file == null) {
            CustomValidationError customValidationError = new CustomValidationError("file", "file", file,
                            "Request parameter file must not be null");
            customValidationErrorList.add(customValidationError);
        }
        String fileExtension = null;
        if (file != null) {
            fileExtension = FilenameUtils.getExtension(file.getOriginalFilename());
        }
        if (file != null && !((fileExtension).equals(Constants.JPG) || fileExtension.equals(Constants.JPEG)
                        || fileExtension.equals(Constants.PNG))) {

            CustomValidationError customValidationError = new CustomValidationError("fileExtension", "fileExtension",
                            fileExtension, "File with extension " + fileExtension + " are not allowed. ");
            customValidationErrorList.add(customValidationError);
        }
        if (file != null && file.getSize() / 1000 > Constants.EMAIL_TEMPLATE_LOGO_MAX_SIZE) {
            CustomValidationError customValidationError = new CustomValidationError("fileSize", "fileSize",
                            file.getSize() / 1000, "File with size more than " + Constants.EMAIL_TEMPLATE_LOGO_MAX_SIZE
                                            + " KB are not allowed. ");
            customValidationErrorList.add(customValidationError);
        }

    }

    @PostMapping(value = "/searchTemplateType")
    public ResponseEntity<APIResponseDTO> searchTemplateType(HttpServletRequest httpServletRequest) {
        List<SearchTemplateTypeResDTO> searchTemplateTypeResDTOList = customTemplateServiceImpl.searchTemplateType();
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(searchTemplateTypeResDTOList)
                                        .message("Got template type list successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

}
