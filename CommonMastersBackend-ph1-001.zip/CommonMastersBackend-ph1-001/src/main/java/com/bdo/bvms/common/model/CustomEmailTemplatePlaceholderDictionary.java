package com.bdo.bvms.common.model;

import java.util.Date;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class CustomEmailTemplatePlaceholderDictionary {

	Integer id;
	Integer entityId;
	Integer pldModuleId;
	Integer refTemplateId;
	Integer subRefTemplateId;
	String name;
	String mapValue;
	String description;
	Integer status;
	Integer createdBy;
	Date createdAt;
	
}
