package com.bdo.bvms.common.service;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import com.bdo.bvms.common.dto.AddWorkflowCommunicationReqDTO;
import com.bdo.bvms.common.dto.AdvanceSearchReqDto;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.DownloadFileDTO;
import com.bdo.bvms.common.dto.DownloadFileInfo;
import com.bdo.bvms.common.dto.ErrorCodeDescriptionResponseDTO;
import com.bdo.bvms.common.dto.ErrorMessageListDto;
import com.bdo.bvms.common.dto.FieldNameResponseDto;
import com.bdo.bvms.common.dto.FinancialYearReqDTO;
import com.bdo.bvms.common.dto.GetCustomizedColumnListReqDTO;
import com.bdo.bvms.common.dto.GetCustomizedColumnListResDTO;
import com.bdo.bvms.common.dto.GetDefaultUploadTemplateReqDTO;
import com.bdo.bvms.common.dto.GetDefaultUploadTemplateResDTO;
import com.bdo.bvms.common.dto.GetFpByYearIdReqDTO;
import com.bdo.bvms.common.dto.GetFpByYearIdResDTO;
import com.bdo.bvms.common.dto.PaginationResDTO;
import com.bdo.bvms.common.dto.PaginationSearchResponseDTO;
import com.bdo.bvms.common.dto.PickupDetailListResDTO;
import com.bdo.bvms.common.dto.PickupListDetailReqDTO;
import com.bdo.bvms.common.dto.PreviewInvoiceUploadDTO;
import com.bdo.bvms.common.dto.SaveCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.SearchByLkupcodeReqDTO;
import com.bdo.bvms.common.dto.SearchPLDByPickKey;
import com.bdo.bvms.common.dto.SearchWorkflowCommunicationReqDTO;
import com.bdo.bvms.common.exceptions.BVMSException;

public interface CommonMasterService {

    PaginationSearchResponseDTO getFpMonths(FinancialYearReqDTO financialYearReqDTO) throws BVMSException;

    PaginationSearchResponseDTO getFpYear(FinancialYearReqDTO financialYearReqDTO) throws BVMSException;

    ByteArrayInputStream downloadFileByteStream(DownloadFileDTO downloadFileBytestreamDto,
                    AzureConnectionCredentialsDTO azureConnectionCredentialsDTO) throws BVMSException;

    List<PickupDetailListResDTO> searchPickupListDetail(SearchByLkupcodeReqDTO searchByLkupcode);

    AzureConnectionCredentialsDTO getAzureCredentialFromDB(String entityId, String type);

    List<GetDefaultUploadTemplateResDTO> getDefaultUploadTemplate(
                    GetDefaultUploadTemplateReqDTO getDefaultUploadTemplateReqDTO);

    String getFileName(DownloadFileDTO downloadFileBytestreamDto) throws BVMSException;

    PickupDetailListResDTO searchPickupListDetailByNameAndCode(PickupListDetailReqDTO pickupListDetailReqDTO);

    Map<String, String> searchBvmsErrorMappings();

    DownloadFileInfo getFileInfo(PreviewInvoiceUploadDTO previewInvoiceUploadDTO);

    List<GetFpByYearIdResDTO> getFpByYearId(GetFpByYearIdReqDTO getFpByYearIdReqDTO);

    String getFileType(DownloadFileDTO downloadFileBytestreamDto);

    List<GetCustomizedColumnListResDTO> getCustomizedColumnListFromService(
                    GetCustomizedColumnListReqDTO getCustomizedColumnListReqDTO);

    public void getSavedCustomizedColumnListFromService(SaveCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO);

    List<PickupDetailListResDTO> searchPickupListDetailByPickKey(@Valid SearchPLDByPickKey searchPLDByPickKey);

    void addWorkflowCommunication(AddWorkflowCommunicationReqDTO addWorkflowCommunicationReqDTO) throws BVMSException;

    PaginationResDTO searchWorkflowCommunication(SearchWorkflowCommunicationReqDTO searchWorkflowCommunicationReqDTO);

	List<ErrorCodeDescriptionResponseDTO> getErrorDescriptionList(ErrorMessageListDto errorMessageListDto);

	List<FieldNameResponseDto> getFieldNames(AdvanceSearchReqDto advanceSearchReqDto);



}
