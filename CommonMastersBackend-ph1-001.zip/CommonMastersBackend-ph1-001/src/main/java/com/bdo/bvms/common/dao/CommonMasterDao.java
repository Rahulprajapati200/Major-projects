package com.bdo.bvms.common.dao;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bdo.bvms.common.dto.AddWorkflowCommunicationReqDTO;
import com.bdo.bvms.common.dto.AdvanceSearchReqDto;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.DownloadFileDTO;
import com.bdo.bvms.common.dto.DownloadFileInfo;
import com.bdo.bvms.common.dto.ErrorCodeDescriptionResponseDTO;
import com.bdo.bvms.common.dto.ErrorMessageListDto;
import com.bdo.bvms.common.dto.ExceptionLogDTO;
import com.bdo.bvms.common.dto.FieldNameResponseDto;
import com.bdo.bvms.common.dto.FinancialPeriodMonthResDTO;
import com.bdo.bvms.common.dto.FinancialYearResDTO;
import com.bdo.bvms.common.dto.GetCustomizedColumnListReqDTO;
import com.bdo.bvms.common.dto.GetCustomizedColumnListResDTO;
import com.bdo.bvms.common.dto.GetDefaultUploadTemplateReqDTO;
import com.bdo.bvms.common.dto.GetDefaultUploadTemplateResDTO;
import com.bdo.bvms.common.dto.GetFpByYearIdReqDTO;
import com.bdo.bvms.common.dto.GetFpByYearIdResDTO;
import com.bdo.bvms.common.dto.PreviewInvoiceUploadDTO;
import com.bdo.bvms.common.dto.SaveCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.SmMailBoxDTO;
import com.bdo.bvms.common.dto.TaxpayerMultilevelDetailsDTO;
import com.bdo.bvms.common.dto.TaxpayerVendor;
import com.bdo.bvms.common.dto.TaxpayerVendorContactMapping;
import com.bdo.bvms.common.dto.WorkflowCommunication;
import com.bdo.bvms.common.exceptions.BDOException;
import com.bdo.bvms.common.exceptions.BVMSException;

public interface CommonMasterDao {

    Page<FinancialYearResDTO> getFpYear(Pageable paging, String financialYearId, String filteerSearchValue)
                    throws BVMSException;

    Page<FinancialPeriodMonthResDTO> getFpMonths(Pageable paging, String financialYearId) throws BVMSException;

    int countFpMonths(String financialYearId, Pageable page);

    String getFilename(DownloadFileDTO downloadFileBytestreamDto) throws BVMSException;

    AzureConnectionCredentialsDTO getAzureCredentialFromDB(String entityId, String type);

    List<GetDefaultUploadTemplateResDTO> getPldDetailsByMstIdNKey(
                    GetDefaultUploadTemplateReqDTO getDefaultUploadTemplateReqDTO);

    void updateExceptionLogTable(ExceptionLogDTO exceptionLogDTO);

    String getModuleName(DownloadFileDTO downloadFileBytestreamDto);

    List<SmMailBoxDTO> getListOfMailDataToSend(String pending) throws BDOException;

    void setSent(int trials, String pending);

    void setFailed(int trials, String pending);

    Map<String, String> searchBvmsErrorMappings();

    DownloadFileInfo getFileInfo(PreviewInvoiceUploadDTO previewInvoiceUploadDTO);

    List<GetFpByYearIdResDTO> getFpListByYearId(GetFpByYearIdReqDTO getFpByYearIdReqDTO);

    String getFileType(DownloadFileDTO downloadFileBytestreamDto);

    List<GetCustomizedColumnListResDTO> getCustomizedColumnListFromRepo(
                    GetCustomizedColumnListReqDTO getSaveCustomizedColumnListReqDTO);

    void deleteThePreviousRecord(SaveCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO);

    void enterTheNewRecord(SaveCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO);

    TaxpayerVendor checkIfTaxpayerVendorExists(TaxpayerVendor taxpayerVendor);

    TaxpayerVendorContactMapping getTaxpayerVendorPrimaryContactByContactIdAndTvcrId(
                    TaxpayerVendorContactMapping taxpayerVendorContactMapping, int moduleId);

    Integer insertWorkflowCommunication(WorkflowCommunication workflowCommunication);

    List<TaxpayerVendorContactMapping> getTaxpayerVendorPrimaryContacts(
                    TaxpayerVendorContactMapping taxpayerVendorContactMapping);

    WorkflowCommunication getWorkflowCommunicationById(WorkflowCommunication workflowCommunication);

    Page<WorkflowCommunication> searchParentWorkflowCommunication(Pageable paging,
                    WorkflowCommunication workflowCommunication);

    Page<WorkflowCommunication> searchChildWorkflowCommunication(Pageable paging,
                    WorkflowCommunication workflowCommunication);

    String getTaxpayerLoginId(String userId);

    String getFileUrl();

    List<ErrorCodeDescriptionResponseDTO> getErrorCode(ErrorMessageListDto errorMessageListDto);

    Map<String, String> setErrorDiscriptionForErrorList();

    List<ErrorCodeDescriptionResponseDTO> getErrorCodeEway(ErrorMessageListDto errorMessageListDto);

    List<ErrorCodeDescriptionResponseDTO> getErrorCodeVendor(ErrorMessageListDto errorMessageListDto);

    List<ErrorCodeDescriptionResponseDTO> getErrorCodeInvoiceVendor(ErrorMessageListDto errorMessageListDto);

    List<FieldNameResponseDto> getFieldName(AdvanceSearchReqDto advanceSearchReqDto);

    String getEmailIdOfVendor(Integer integer);

    String getVendorEmailEmail(AddWorkflowCommunicationReqDTO addWorkflowCommunicationReqDTO);

    String getTaxpayerSingleEmailId(String taxpayerGstin);

    Map<String, Object> commonPostNotification(int vendoruploadmstid, String string, int userId, int userId2,
                    int userId3, String notificationCode);

    int getUserIdBasedOnVendorGstin(String vendorGstin, String taxpayerGstin);

    int getUserIdBasedOnTaxpayerGstin(String taxpayerGstin, int moduleId);

    String getVendorName(String vendorUserId);

    String getTaxpayerName(int taxpayerUserId);

    void insertIntoMailBox(String taxpayerMailId, String vendorMailId, String vendorGstin, String string);

    String getVendorAllPrimaryMailId(String taxpayerGstin, String vendorGstin);

    String getSingleMailId(String userId);

    List<TaxpayerMultilevelDetailsDTO> getTaxpayerMultiLevelDetails(int i, String taxpayerGstin, int vendorModuleId);

    String getTaxpayerAllLevelMailIds(List<TaxpayerMultilevelDetailsDTO> taxpayerMultilevelDetails);

    List<String> getVendorAllPrimaryUserId(String taxpayerGstin, String vendorGstin);

}
