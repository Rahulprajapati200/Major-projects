package com.bdo.bvms.common.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class GSTR2BReportsResDTO {

    String gstin;
    String category;
    String ctin;
    String companyTradeName;
    String filingPeriodGstr15;

    String invoiceType;
    String noteType;
    String noteSupplyType;
    String iSDDocType;
    String orgNoteType;
    String docNo;
    String docDate;
    String orgInvoiceNo;
    String orgInvoiceDate;
    String pos;
    String taxableAmount;
    String rate;
    String diffPercent;
    String igstAmount;
    String cgstAmount;
    String sgstAmount;
    String cessAmount;
    String sumGrossTotalAmount;
    String reverseCharge;
    String itcEligibility;
    String itcEligibilityReason;
    String dateOfFilingGstr15;
    String sourceType;
    String irn;
    String irngendate;
    String fp;
    String portCode;
    String amendmentType;
    String importBillNo;
    String importBillDate;
    String icegateRefDate;
    String rcvdDateGst;

}
