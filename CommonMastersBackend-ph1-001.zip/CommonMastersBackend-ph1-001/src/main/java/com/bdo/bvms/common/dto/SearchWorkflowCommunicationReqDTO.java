package com.bdo.bvms.common.dto;

import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class SearchWorkflowCommunicationReqDTO extends PageReqDTO {

    @NotNull(message = "{workflowMasterId.notNull}")
    Integer workflowMasterId;

    Integer parentId;
}
