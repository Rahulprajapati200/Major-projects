package com.bdo.bvms.common.dto;

import java.util.Date;

import org.springframework.data.relational.core.mapping.Column;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class TaxpayerVendor {
    
    Integer id;

    @Column(value="pld_data_version")
    Integer pldDataVersion;

    @Column(value="entity_id")
    Integer entityId;

    @Column(value="pan_taxpayer")
    String panTaxpayer;

    @Column(value="pan_vendor")
    String panVendor;

    @Column(value="gstin_taxpayer")
    String gstinTaxpayer;

    @Column(value="gstin_vendor")
    String gstinVendor;

    @Column(value="company_trade_name")
    String companyTradeName;

    @Column(value="vendor_code_erp")
    String vendorCodeErp;

    @Column(value="pld_taxpayer_type")
    String pldTaxpayerType;

    @Column(value="company_legal_name")
    String companyLegalName;

    @Column(value="pld_gstin_status")
    String pldGstinStatus;
    
    @Column(value="gstin_registration_date")
    String gstinRegistrationDate;
    
    @Column(value="cancellation_date")
    String cancellationDate;
    
    @Column(value="gstnSha")
    String gstnSha;
    
    @Column(value="centerJurisdiction")
    String centerJurisdiction;
    
    @Column(value="state_jurisdiction")
    String stateJurisdiction;
    
    @Column(value="business_constitution")
    String businessConstitution;
    
    @Column(value="business_nature")
    String businessNature;
    
    @Column(value="pld_source")
    Integer pldSource;
    
    @Column(value="free_search")
    String freeSearch;
    
    @Column(value="parent_id")
    Integer parentId;

    @Column(value="created_at")
    Date createdAt;
    
    @Column(value="created_by")
    Integer createdBy;

    @Column(value="child_relation_id")
    Integer childRelationId;
    
       
    Integer isGetOnly;
    
    Integer isUpdateOnly;
    
    @Column(value="is_draft")
    Integer isDraft;

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TaxpayerVendor)) {
            return false;
        }
        TaxpayerVendor other = (TaxpayerVendor) obj;
        if (companyLegalName == null) {
            if (other.companyLegalName != null) {
                return false;
            }
        } else if (!companyLegalName.equalsIgnoreCase(other.companyLegalName)) {
            return false;
        }
        if (companyTradeName == null) {
            if (other.companyTradeName != null) {
                return false;
            }
        } else if (!companyTradeName.equalsIgnoreCase(other.companyTradeName)) {
            return false;
        }
        if (gstinTaxpayer == null) {
            if (other.gstinTaxpayer != null) {
                return false;
            }
        } else if (!gstinTaxpayer.equalsIgnoreCase(other.gstinTaxpayer)) {
            return false;
        }
        if (gstinVendor == null) {
            if (other.gstinVendor != null) {
                return false;
            }
        } else if (!gstinVendor.equalsIgnoreCase(other.gstinVendor)) {
            return false;
        }
        if (panVendor == null) {
            if (other.panVendor != null) {
                return false;
            }
        } else if (!panVendor.equalsIgnoreCase(other.panVendor)) {
            return false;
        }
        if (pldDataVersion == null) {
            if (other.pldDataVersion != null) {
                return false;
            }
        } else if (!pldDataVersion.equals(other.pldDataVersion)) {
            return false;
        }
        if (vendorCodeErp == null) {
            if (other.vendorCodeErp != null) {
                return false;
            }
        } else if (!vendorCodeErp.equalsIgnoreCase(other.vendorCodeErp)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((companyLegalName == null) ? 0 : companyLegalName.hashCode());
        result = prime * result + ((companyTradeName == null) ? 0 : companyTradeName.hashCode());
        result = prime * result + ((gstinTaxpayer == null) ? 0 : gstinTaxpayer.hashCode());
        result = prime * result + ((gstinVendor == null) ? 0 : gstinVendor.hashCode());
        result = prime * result + ((panVendor == null) ? 0 : panVendor.hashCode());
        result = prime * result + ((pldDataVersion == null) ? 0 : pldDataVersion.hashCode());
        result = prime * result + ((vendorCodeErp == null) ? 0 : vendorCodeErp.hashCode());
        return result;
    }
    
    
    


}


