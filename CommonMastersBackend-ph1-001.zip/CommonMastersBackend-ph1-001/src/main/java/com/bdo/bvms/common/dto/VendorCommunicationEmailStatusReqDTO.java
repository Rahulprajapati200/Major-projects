package com.bdo.bvms.common.dto;

import java.util.List;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VendorCommunicationEmailStatusReqDTO extends BaseReqDTO {

    String gstinOrPan;
    List<String> gstinOrPanList;
    List<String> vendorGstin;
    String periodTypeCD;
    String yearOrMonth;
    List<String> yearOrMonthList;
    String recoType;
    List<String> recoStatus;
    String reportId;
    String buttonType;
    String downloadType;
    int customTemplateId;

}
