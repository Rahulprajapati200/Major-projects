package com.bdo.bvms.common.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ReportsVendorMasterResDTO {

    String gstinTaxpayer;
    String vendorCodeErp;
    String gstinVendor;
    String companyLegalName;
    String companyTradeName;
    String panVendor;
    String aadharVendor;
    String firstName;
    String lastName;
    String mobile;
    String email;
    String isPrimaryContact;
    String addressType;
    String isDefaultAddress;
    String address1;
    String address2;
    String place;
    String pinCode;
    String bankName;
    String bankAddress;
    String accountHolderName;
    String accountNumber;
    String ifscCode;
    String isPrimaryBank;
    String primaryUpi;
    String secondaryUpi;
    String modifiedAt;
    String field1;
    String field2;
    String field3;
    String field4;
    String field5;
    String field6;
    String field7;
    String field8;
    String field9;
    String field10;
    String field11;
    String field12;
    String field13;
    String field14;
    String field15;
    String field16;
    String field17;
    String field18;
    String field19;
    String field20;
    String source;
    String vendorType;
    String gstinStatus;
    String dateOfRegistration;
    String dateOfCancellationOrSuspension;
    String vendorStatus;
    String stateJurisdiction;
    String centerJurisdiction;
    String returnPeriod;
    String taxPeriod;
    String dateOfFiling;
    String acknoledgementNumber;
    String addressStatus;
    String returnType;
    String returnFilingStatus;
    String constitutionOfBusiness;
    String natureOfBusinessActivity;
    String errorCode;
    String errorMessage;

}
