package com.bdo.bvms.common.dto;

import java.math.BigDecimal;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ReportsVendorCommInwardVsGSTR2AResDTO {

    String recoStatus;
    String reason;
    String gstin;
    String documentNo;
    String docDate;
    String vendorGSTIN;
    String vendorName;
    String recordType;
    String invoiceNo;
    String invoiceDate;
    String noteNo;
    String noteDate;
    String orgInvNo;
    String orgInvDate;
    String invoiceReference;
    String invoiceDateReference;
    String category;
    String noteType;
    String financialPeriod;
    String importRefDate;
    String portCode;
    String billOfEntryNumber;
    String billOfEntryDate;
    String posCode;
    String cfsGSTR1;
    String cfsGSTR3B;
    String reverseCharge;
    BigDecimal invoiceValue;
    BigDecimal taxableValue;
    BigDecimal taxRate;
    BigDecimal igstAmt;
    BigDecimal cgstAmt;
    BigDecimal sgstAmt;
    BigDecimal cessAmt;
    String tolerance;
    String itcEligibleIneligible;
    String dateOfFilingGSTR1;
    String dateOfFilingGSTR3B;
    String dateOfCancellation;
    String sublocation;
    String remarks;
    String multiLinkUniqueKey;
    String udf1;
    String udf2;
    String udf3;
    String udf4;
    String udf5;
    String udf6;
    String udf7;
    String udf8;
    String udf9;
    String udf10;

}
