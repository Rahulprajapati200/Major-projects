package com.bdo.bvms.common.reports.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.BaseReqDTO;
import com.bdo.bvms.common.dto.FilingVeiwReportsReqDTO;
import com.bdo.bvms.common.dto.GetCustomizedColumnListResDTO;
import com.bdo.bvms.common.dto.GetReportsCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.GetReportsSavedCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.PinnedAndUnpinnedReportsReqDTO;
import com.bdo.bvms.common.dto.ReportsSubModuleReqDTO;
import com.bdo.bvms.common.dto.ReportsSubModuleResDTO;
import com.bdo.bvms.common.dto.ReportsVendorMasterReqDTO;
import com.bdo.bvms.common.dto.SearchReportReqDTO;
import com.bdo.bvms.common.dto.SendInvitesViewReportsReqDTO;
import com.bdo.bvms.common.dto.SubModuleWiseReportsListReqDTO;
import com.bdo.bvms.common.dto.SubModuleWiseReportsListResDTO;
import com.bdo.bvms.common.exceptions.AppBusinessException;
import com.bdo.bvms.common.exceptions.BDOException;

public interface ReportsVendorMasterService {

    Map<String, Object> getReportsVendorMaster(ReportsVendorMasterReqDTO reportsVendorMasterReq)
                    throws AppBusinessException, SQLException;

    Map<String, Object> getSuggestedReportsDetail(BaseReqDTO baseReqDTO) throws AppBusinessException;

    Map<String, Object> getPinnedReportsDetails(BaseReqDTO baseReqDTO) throws AppBusinessException;

    Map<String, Object> getRecentReportsDetail(BaseReqDTO baseReqDTO) throws AppBusinessException;

    List<ReportsSubModuleResDTO> getReportsSubModuleList(ReportsSubModuleReqDTO reportsSubModuleReqDTO)
                    throws AppBusinessException;

    List<SubModuleWiseReportsListResDTO> getSubModuleWiseReportList(
                    SubModuleWiseReportsListReqDTO subModuleWiseReportsListReqDTO) throws AppBusinessException;

    void setPinnedAndUnpinnedReports(PinnedAndUnpinnedReportsReqDTO pinnedAndUnpinnedReportsReq)
                    throws AppBusinessException;

    Map<String, Object> getSendInvitesViewReports(SendInvitesViewReportsReqDTO sendInvitesViewReportsReqDTO)
                    throws AppBusinessException;

    Map<String, Object> getFilingViewReportsList(FilingVeiwReportsReqDTO filingVeiwReportsReqDTO)
                    throws AppBusinessException;

    List<GetCustomizedColumnListResDTO> getCustomizedColumnListFromService(
                    GetReportsCustomizeColumnListReqDTO getCustomizedColumnListReqDTO) throws AppBusinessException;

    void getSavedCustomizedColumnListFromService(GetReportsSavedCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO)
                    throws AppBusinessException;

    Map<String, Object> getBackgroundReportsData(BaseReqDTO requestDTO) throws AppBusinessException;

    Map<String, Object> downloadVendorMasterReportsCustom(ReportsVendorMasterReqDTO reportsVendorMasterReq)
                    throws BDOException;

    Map<String, Object> getSearchReporst(SearchReportReqDTO searchReportReq);

    void backgroundReportsGenerationProccess(ReportsVendorMasterReqDTO generateBackgroundReports)
                    throws AppBusinessException;

}
