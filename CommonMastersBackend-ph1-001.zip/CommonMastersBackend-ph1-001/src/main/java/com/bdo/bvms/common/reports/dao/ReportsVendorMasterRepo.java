package com.bdo.bvms.common.reports.dao;

import java.io.IOException;
import java.math.BigInteger;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.BaseReqDTO;
import com.bdo.bvms.common.dto.FilingVeiwReportsReqDTO;
import com.bdo.bvms.common.dto.GetCustomizedColumnListResDTO;
import com.bdo.bvms.common.dto.GetReportsCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.GetReportsSavedCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.PinnedAndUnpinnedReportsReqDTO;
import com.bdo.bvms.common.dto.ReportsSubModuleReqDTO;
import com.bdo.bvms.common.dto.ReportsSubModuleResDTO;
import com.bdo.bvms.common.dto.ReportsVendorMasterReqDTO;
import com.bdo.bvms.common.dto.SearchReportReqDTO;
import com.bdo.bvms.common.dto.SendInvitesViewReportsReqDTO;
import com.bdo.bvms.common.dto.SubModuleWiseReportsListReqDTO;
import com.bdo.bvms.common.dto.SubModuleWiseReportsListResDTO;
import com.bdo.bvms.common.exceptions.BDOException;

public interface ReportsVendorMasterRepo {

    Map<String, Object> getReportsVendorMaster(ReportsVendorMasterReqDTO reportsVendorMasterReq,
                    String taxpayergstinList, String vendorGstinList) throws SQLException;

    String[] getGstinFromDB(String string);

    Map<String, Object> getPinnedReportsDetail(BaseReqDTO baseReqDTO);

    Map<String, Object> getSuggestedReportsDetail(BaseReqDTO baseReqDTO);

    Map<String, Object> getRecentReportsDetail(BaseReqDTO baseReqDTO);

    List<ReportsSubModuleResDTO> getReportsSubModuleList(ReportsSubModuleReqDTO reportsSubModuleReqDTO);

    List<SubModuleWiseReportsListResDTO> getSubModuleWiseReportList(
                    SubModuleWiseReportsListReqDTO subModuleWiseReportsListReqDTO);

    void setPinnedAndUnpinnedReports(PinnedAndUnpinnedReportsReqDTO pinnedAndUnpinnedReportsReq);

    Map<String, Object> getSendInvitesViewReports(SendInvitesViewReportsReqDTO sendInvitesViewReportsReqDTO,
                    String taxpayergstinList, String vendorGstinList);

    Map<String, Object> getFilingViewReports(FilingVeiwReportsReqDTO filingVeiwReportsReqDTO, String taxpayergstinList,
                    String vendorGstinList);

    List<GetCustomizedColumnListResDTO> getCustomizedColumnListFromRepo(
                    GetReportsCustomizeColumnListReqDTO getSaveCustomizedColumnListReqDTO);

    void deleteThePreviousRecord(GetReportsSavedCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO);

    void enterTheNewRecord(GetReportsSavedCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO);

    Map<String, Object> getBackgroundReportsData(BaseReqDTO requestDTO);

    Map<String, Object> getDownloadReportsVendorMasterNew(Timestamp timeStamp, String fileName, String containerName,
                    String entityId, ReportsVendorMasterReqDTO reportsVendorMasterReq, String taxpayergstinList,
                    String vendorGstinList) throws IOException, BDOException;

    void generateBackGroundReportsVendorMaster(Timestamp currentTimeStamp, String fileName, String containerName,
                    String entityId, ReportsVendorMasterReqDTO generateBackgroundReports, String taxpayergstinList,
                    String vendorGstinList, BigInteger id);

    Map<String, Object> getGenerateExcelOrCsvOfxVendorMasterSendInviteReport(
                    ReportsVendorMasterReqDTO reportsVendorMasterReq, String taxpayergstinList, String vendorGstinList,
                    Timestamp timeStamp, String fileName, String containerName);

    Map<String, Object> getGenerateExcelOrCsvOfxVendorMasterFillingDetailsReport(
                    ReportsVendorMasterReqDTO reportsVendorMasterReq, String taxpayergstinList, String vendorGstinList,
                    Timestamp timeStamp, String fileName, String containerName);

    Map<String, Object> getSearchReports(SearchReportReqDTO searchReportReq);

}
