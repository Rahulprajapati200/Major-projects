package com.bdo.bvms.common.constant;

public final class EntityTypeConstant {

	EntityTypeConstant(){

	}

	


}
