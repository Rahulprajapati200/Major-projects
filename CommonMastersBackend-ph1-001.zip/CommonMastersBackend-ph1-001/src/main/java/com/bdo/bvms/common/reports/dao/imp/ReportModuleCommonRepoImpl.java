package com.bdo.bvms.common.reports.dao.imp;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.mail.MessagingException;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.impl.UploadSQL;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.BaseReqDTO;
import com.bdo.bvms.common.dto.ModuleIdAndNameDTO;
import com.bdo.bvms.common.dto.ReportsCustomColumnsDTO;
import com.bdo.bvms.common.reports.constants.ReportsConstants;
import com.bdo.bvms.common.reports.dao.ReportModuleCommonRepo;
import com.bdo.bvms.common.reports.sql.ReportsCommonSql;
import com.bdo.bvms.common.util.EncryptionUtils;
import com.microsoft.azure.storage.core.Base64;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class ReportModuleCommonRepoImpl implements ReportModuleCommonRepo {

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Value("${txn.database-name}")
    private String transDatabaseName;

    long key;

    String mailto;

    /*
     * The Spring Framework provides an easy abstraction for sending email by
     * using the JavaMailSender interface, and Spring Boot provides
     * auto-configuration for it as well as a starter module.
     */

    // private JavaMailSender javaMailSender;

    @Override
    public String getContainerName(String entityId) {

        String containerName = "";

        try {
            containerName = jdbcTemplateMst.queryForObject(ReportsCommonSql.QUERY_FOR_GETTING_CONTAINER_NAME,
                            String.class, entityId);
        } catch (DataAccessException e) {
            log.error("Error coming at the time of getting container name from the table sm_entity_cloud_credentials of entity id="
                            + entityId, e);
        }

        if ("".equals(containerName) || containerName.isEmpty()) {

            containerName = jdbcTemplateMst.queryForObject(
                            ReportsCommonSql.QUERY_FOR_GETTING_CONTAINER_NAME_FROM_SYSTEM_PARAMETER, String.class,
                            ReportsConstants.CONTAINER_NAME);
        }

        return containerName;
    }

    @Override
    public String getFileUrl() {

        return jdbcTemplateMst.queryForObject(ReportsCommonSql.QUERY_FOR_GETTING_FILE_URL, String.class);
    }

    @Override
    public String getFileName(String reportCode) {
        List<String> fileName = jdbcTemplateMst.queryForList("select name from am_report_config where report_code=? ",
                        String.class, reportCode);
        return fileName.get(0);
    }

    /**
     * Gets the azure credential from DB.
     *
     * @param entityId
     *            the entity id
     * @param blob
     *            the blob
     * @return the azure credential from DB
     */

    @Override
    public AzureConnectionCredentialsDTO getAzureCredentialFromDB(String entityId, String blob) {

        Integer count = jdbcTemplateMst.queryForObject(UploadSQL.GET_COUNT_OF_AZURE_CREDENTIAL_FROM_DB, Integer.class,
                        entityId, blob);
        if (count > 0) {
            return jdbcTemplateMst.queryForObject(UploadSQL.GET_AZURE_CREDENTIAL_FROM_DB,
                            new BeanPropertyRowMapper<AzureConnectionCredentialsDTO>(
                                            AzureConnectionCredentialsDTO.class),
                            entityId, blob);
        }

        AzureConnectionCredentialsDTO azureConnectionCredentials = new AzureConnectionCredentialsDTO();

        String url = jdbcTemplateMst.queryForObject(UploadSQL.GET_URL_FROM_AZURE_CREDENTIAL_FROM_DB, String.class);
        azureConnectionCredentials.setUrl(url);
        String containerName = jdbcTemplateMst.queryForObject(UploadSQL.GET_CONTAINER_NAME_AZURE_CREDENTIAL_FROM_DB,
                        String.class);
        azureConnectionCredentials.setContainerName(containerName);
        return azureConnectionCredentials;
    }

    @Override
    public void updateBackGroundDetails(String filePath, Long recordCount, String pldStatus, String filename,
                    String modifiedBy, Timestamp modifiedAt, BigInteger id) {

        jdbcTemplateTrn.update(ReportsCommonSql.UPDATE_BACKGROUNG_REPORTS_DETAILS, pldStatus, filename, recordCount,
                        filePath, modifiedBy, id);

    }

    @Override
    public void updateAccessLogTable(LocalDateTime localDateTime, String reportId, String userId, String entityId,
                    String userTypeId) {

        int reportConfigId = jdbcTemplateMst.queryForObject("select id from am_report_config where report_code=? ",
                        Integer.class, reportId);
        int count = jdbcTemplateTrn.queryForObject(ReportsCommonSql.GET_COUNT_OF_ACCESS_LOG, Integer.class,
                        reportConfigId, userId, entityId, userTypeId);

        String query = "";
        if (count > 0) {
            query = ReportsCommonSql.UPDATE_ACCESS_LOG;
        } else {
            query = ReportsCommonSql.INSERT_INTO_ACCESS_LOG;
        }
        jdbcTemplateTrn.update(query, localDateTime, reportConfigId, userId, entityId, userTypeId);
    }

    /**
     * Insert back ground details.
     *
     * @param reportCode
     *            the report code
     * @param pldStatus
     *            the pld status
     * @param reportGeneratedAt
     *            the report generated at
     * @param modifiedBy
     *            the modified by
     * @param modifiedAt
     *            the modified at
     * @return the long
     */
    @Override
    public BigInteger insertBackGroundDetails(String reportCode, String pldStatus, Timestamp reportGeneratedAt,
                    String modifiedBy, Timestamp modifiedAt, String fileName) {
        BigInteger id;
        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplateTrn.update(con -> {
            PreparedStatement ps = con.prepareStatement(ReportsCommonSql.INSERT_BACKGROUNG_REPORTS_DETAILS,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, reportCode);
            ps.setString(2, pldStatus);
            ps.setTimestamp(3, reportGeneratedAt);
            ps.setString(4, modifiedBy);
            ps.setTimestamp(5, modifiedAt);
            ps.setString(6, fileName);
            return ps;
        }, keyHolder);
        id = (BigInteger) keyHolder.getKey();
        return id;

    }

    @Override
    public String[] getGstinFromDB(String pan) {
        return jdbcTemplateTrn.queryForList(ReportsCommonSql.getTaxpayerGstinFromDbSql(mstDatabseName), String.class,
                        Base64.encode(pan.getBytes())).toArray(new String[0]);
    }

    @Override
    public String[] getMonthFromDB(String yearId) {
        return jdbcTemplateMst.queryForList(ReportsCommonSql.GET_MONTH_LIST_FROM_DB_SQL, String.class, yearId)
                        .toArray(new String[0]);
    }

    @Override
    public List<ModuleIdAndNameDTO> getModuleCodeAndName(BaseReqDTO baseReqDTO) {

        return jdbcTemplateMst.query(ReportsCommonSql.GET_MODULE_NAME_AND_CODE,
                        new ResultSetExtractor<List<ModuleIdAndNameDTO>>() {

                            public List<ModuleIdAndNameDTO> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                List<ModuleIdAndNameDTO> moduleCodeAndNameList = new ArrayList<>();
                                while (rs.next()) {
                                    ModuleIdAndNameDTO moduleCodeAndNameDTO = new ModuleIdAndNameDTO();
                                    moduleCodeAndNameDTO.setModuleId(checkNullValue(rs.getString("pld_module_id")));
                                    moduleCodeAndNameDTO.setModuleName(checkNullValue(rs.getString("name")));

                                    moduleCodeAndNameList.add(moduleCodeAndNameDTO);
                                }
                                return moduleCodeAndNameList;
                            }

                        });
    }

    private static String checkNullValue(String value) {
        if (StringUtils.isEmpty(value)) {
            return "-";
        } else {
            return value;
        }
    }

    @Override
    public String[] getColumnNamesAccToRepoCode(String reportCode) {
        return jdbcTemplateMst.queryForList(ReportsCommonSql.GET_COLUMN_NAME_FROM_DB_SQL, String.class, reportCode, 0)
                        .toArray(new String[0]);
    }

    @Override
    public List<ReportsCustomColumnsDTO> getCustomizeColumns(int pldTemplateId, String reportId, String userId,
                    int customTemplateId, int summaryType) {

        int count = jdbcTemplateTrn.queryForObject(ReportsCommonSql.getDynamicHeadersCount(mstDatabseName),
                        Integer.class, userId, reportId);
        String isCustom = getCustomOrDefaultValue(reportId);
        String sql = "";
        if (count > 0) {
            sql = ReportsCommonSql.getDynamicHeaders(mstDatabseName);
            return jdbcTemplateTrn.query(sql, new ResultSetExtractor<List<ReportsCustomColumnsDTO>>() {

                public List<ReportsCustomColumnsDTO> extractData(ResultSet rs)
                                throws SQLException, DataAccessException {
                    List<ReportsCustomColumnsDTO> reportsCustomColumnsList = new ArrayList<>();
                    while (rs.next()) {
                        ReportsCustomColumnsDTO reportsCustomColumns = new ReportsCustomColumnsDTO();
                        reportsCustomColumns.setColumnWidth(rs.getLong(ReportsConstants.COLUMN_WIDTH));
                        reportsCustomColumns.setField(checkNullValue(rs.getString(ReportsConstants.FIELD_NAME)));

                        reportsCustomColumns
                                        .setKey(checkNullValue(rs.getString(ReportsConstants.CUSTOMIZE_COLUMN_NAME)));
                        reportsCustomColumns.setName(checkNullValue(rs.getString(ReportsConstants.COLUMN_NAME)));

                        reportsCustomColumnsList.add(reportsCustomColumns);
                    } // COLUMN_NAME
                    return reportsCustomColumnsList;
                }

            }, userId, reportId);
        }

        if (isCustom == null || isCustom.equals(ReportsConstants.DEFAULT) || isCustom.equals("")) {

            return jdbcTemplateMst.query(ReportsCommonSql.getDefaultHeaders(),
                            new ResultSetExtractor<List<ReportsCustomColumnsDTO>>() {

                                public List<ReportsCustomColumnsDTO> extractData(ResultSet rs)
                                                throws SQLException, DataAccessException {
                                    List<ReportsCustomColumnsDTO> reportsCustomColumnsList = new ArrayList<>();
                                    while (rs.next()) {
                                        ReportsCustomColumnsDTO reportsCustomColumns = new ReportsCustomColumnsDTO();
                                        reportsCustomColumns.setColumnWidth(rs.getLong(ReportsConstants.COLUMN_WIDTH));
                                        reportsCustomColumns.setField(
                                                        checkNullValue(rs.getString(ReportsConstants.FIELD_NAME)));
                                        reportsCustomColumns.setKey(checkNullValue(
                                                        rs.getString(ReportsConstants.CUSTOMIZE_COLUMN_NAME)));
                                        reportsCustomColumns.setName(
                                                        checkNullValue(rs.getString(ReportsConstants.COLUMN_NAME)));

                                        reportsCustomColumnsList.add(reportsCustomColumns);
                                    }
                                    return reportsCustomColumnsList;
                                }

                            }, reportId);

        } else {
            return jdbcTemplateMst.query(ReportsCommonSql.getCustomDefaultHeaders(),
                            new ResultSetExtractor<List<ReportsCustomColumnsDTO>>() {

                                public List<ReportsCustomColumnsDTO> extractData(ResultSet rs)
                                                throws SQLException, DataAccessException {
                                    List<ReportsCustomColumnsDTO> reportsCustomColumnsList = new ArrayList<>();
                                    while (rs.next()) {
                                        ReportsCustomColumnsDTO reportsCustomColumns = new ReportsCustomColumnsDTO();
                                        reportsCustomColumns.setColumnWidth(rs.getLong(ReportsConstants.COLUMN_WIDTH));
                                        reportsCustomColumns.setField(
                                                        checkNullValue(rs.getString(ReportsConstants.FIELD_NAME)));

                                        reportsCustomColumns.setKey(checkNullValue(
                                                        rs.getString(ReportsConstants.CUSTOMIZE_COLUMN_NAME)));
                                        reportsCustomColumns.setName(
                                                        checkNullValue(rs.getString(ReportsConstants.COLUMN_NAME)));

                                        reportsCustomColumnsList.add(reportsCustomColumns);
                                    }
                                    return reportsCustomColumnsList;
                                }

                            }, pldTemplateId, customTemplateId, reportId, reportId, summaryType);

        }

    }

    @Override
    public String getCustomOrDefault(String reportId) {
        String isCustom = "";
        try {
            isCustom = jdbcTemplateMst.queryForObject(ReportsCommonSql.QUERY_FOR_ISCUSTOM_TEMPLATE, String.class,
                            reportId);
            if (isCustom == null || isCustom.equals(ReportsConstants.DEFAULT) || isCustom.equals("")) {
                isCustom = "default";
            } else {
                isCustom = "custom";
            }
        } catch (DataAccessException e) {
            log.error("error to find if report is custom or default", e);

        }
        return isCustom;
    }

    @Override
    public String getCustomOrDefaultValue(String reportId) {
        String isCustom = "";
        try {
            isCustom = jdbcTemplateMst.queryForObject(ReportsCommonSql.QUERY_FOR_ISCUSTOM_TEMPLATE, String.class,
                            reportId);

        } catch (DataAccessException e) {
            log.error("error to find if report is custom or default", e);

        }
        return isCustom;
    }

    @Override
    public List<ReportsCustomColumnsDTO> getCustomizeColumnsForView(int pldTemplateId, String reportId, String userId,
                    int customTemplateId, int summaryType) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));
        String isCustom = getCustomOrDefault(reportId);

        Map<String, Object> results = jdbcTemplateMst.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall("{call utility_get_custom_columns_for_view (?,?,?,?,?,?,?,?)}");

                cs.setString(1, isCustom);
                cs.setInt(2, pldTemplateId);
                cs.setInt(3, customTemplateId);
                cs.setString(4, reportId);
                cs.setString(5, userId);
                cs.setInt(6, summaryType);
                cs.setInt(7, 0);
                cs.setString(8, transDatabaseName);
                return cs;
            }
        }, parameters);

        List<ReportsCustomColumnsDTO> reportsCustomColumnsList1 = new ArrayList<>();
        if (!results.isEmpty()) {

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> dataList = (List<Map<String, Object>>) results.get("#result-set-1");
            dataList.stream().forEach(dataObject -> {

                ReportsCustomColumnsDTO dataRes = new ReportsCustomColumnsDTO();

                dataRes.setColumnWidth((Long) dataObject.get(ReportsConstants.COLUMN_WIDTH));
                dataRes.setField(checkNullValue((String) dataObject.get(ReportsConstants.FIELD_NAME)));
                dataRes.setKey(checkNullValue((String) dataObject.get(ReportsConstants.CUSTOMIZE_COLUMN_NAME)));
                dataRes.setName(checkNullValue((String) dataObject.get(ReportsConstants.COLUMN_NAME)));

                reportsCustomColumnsList1.add(dataRes);
            });
            return reportsCustomColumnsList1;
        }

        return reportsCustomColumnsList1;
    }

    @Override
    public Map<String, Object> getHeadersStyles(XSSFWorkbook workbook, XSSFSheet sheet) {

        Map<String, Object> headersStyles = new HashMap<>();

        @SuppressWarnings("deprecation")
        XSSFColor blueColor = new XSSFColor(new java.awt.Color(2, 165, 226));
        @SuppressWarnings("deprecation")
        XSSFColor greyColor = new XSSFColor(new java.awt.Color(242, 242, 242));
        @SuppressWarnings("deprecation")
        XSSFColor borderColor = new XSSFColor(new java.awt.Color(192, 192, 192));

        ///////////////////////////////////////////////////// Upper Header
        ///////////////////////////////////////////////////// Styles//////////////////////////////////////////////////////////////////

        Font headerFont1 = workbook.createFont();
        headerFont1.setColor(IndexedColors.WHITE.index);
        ((XSSFFont) headerFont1).setBold(true);
        headerFont1.setFontHeightInPoints((short) 14);
        XSSFCellStyle headerCellStyle1 = workbook.createCellStyle();
        headerCellStyle1.setFillForegroundColor(blueColor);
        headerCellStyle1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerCellStyle1.setAlignment(HorizontalAlignment.LEFT);

        headerCellStyle1.setFont(headerFont1);

        //////////////////////////////// Lower Header
        //////////////////////////////// Styles///////////////////////////////////////////////////

        Font headerFont2 = workbook.createFont();
        headerFont2.setColor(IndexedColors.BLACK.index);
        ((XSSFFont) headerFont2).setBold(true);
        headerFont2.setFontHeightInPoints((short) 12);
        XSSFCellStyle headerCellStyle2 = workbook.createCellStyle();
        headerCellStyle2.setFillForegroundColor(greyColor);
        headerCellStyle2.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerCellStyle2.setAlignment(HorizontalAlignment.LEFT);

        headerCellStyle2.setBorderTop(BorderStyle.THIN);
        headerCellStyle2.setTopBorderColor(borderColor);
        headerCellStyle2.setBorderBottom(BorderStyle.THIN);
        headerCellStyle2.setBottomBorderColor(borderColor);
        headerCellStyle2.setBorderLeft(BorderStyle.THIN);
        headerCellStyle2.setLeftBorderColor(borderColor);
        headerCellStyle2.setBorderRight(BorderStyle.THIN);
        headerCellStyle2.setRightBorderColor(borderColor);
        headerCellStyle2.setFont(headerFont2);

        ///////////////////////////// Remaining Columns
        ///////////////////////////// Styles//////////////////////////////////

        Font headerFont3 = workbook.createFont();
        headerFont3.setFontHeightInPoints((short) 11);
        XSSFCellStyle headerCellStyle3 = workbook.createCellStyle();
        headerCellStyle3.setFillForegroundColor(IndexedColors.WHITE.index);

        headerCellStyle3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerCellStyle3.setAlignment(HorizontalAlignment.LEFT);
        headerCellStyle3.setBorderTop(BorderStyle.THIN);
        headerCellStyle3.setTopBorderColor(borderColor);
        headerCellStyle3.setBorderBottom(BorderStyle.THIN);
        headerCellStyle3.setBottomBorderColor(borderColor);
        headerCellStyle3.setBorderLeft(BorderStyle.THIN);
        headerCellStyle3.setLeftBorderColor(borderColor);
        headerCellStyle3.setBorderRight(BorderStyle.THIN);
        headerCellStyle3.setRightBorderColor(borderColor);
        headerCellStyle3.setFont(headerFont3);

        headersStyles.put(ReportsConstants.HEADERCELLSTYLE1, headerCellStyle1);
        headersStyles.put(ReportsConstants.HEADERCELLSTYLE2, headerCellStyle2);
        headersStyles.put(ReportsConstants.HEADERCELLSTYLE3, headerCellStyle3);

        return headersStyles;
    }

    @Override
    public void setFilterAndFredgeHeader(XSSFSheet sheet, CellRangeAddress range) {
        sheet.setDisplayGridlines(false);
        sheet.createFreezePane(0, 5);
        sheet.setAutoFilter(range);
    }

    @Override
    public void setFilterAndFredgeHeader1(XSSFSheet sheet, CellRangeAddress range, int detalsCount) {
        sheet.setDisplayGridlines(false);
        sheet.createFreezePane(0, detalsCount + 2);
        sheet.setAutoFilter(range);
    }

    @Override
    public String getReportsExcelFileName(String reportName, Timestamp timeStamp) {
        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        String newTimeStamp = dateFormat.format(timeStamp).replace(":", "").replace("-", "").replace(" ", "");
        String newReportName = reportName.replace(" ", "_");

        return new StringBuilder(newReportName).append("_").append(newTimeStamp).append(ReportsConstants.DOT_XLSX)
                        .toString();
    }

    @Override
    public String getReportsCsvFileName(String reportName, Timestamp timeStamp) {

        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        String newTimeStamp = dateFormat.format(timeStamp).replace(":", "").replace("-", "").replace(" ", "");
        String newReportName = reportName.replace(" ", "_");

        return new StringBuilder(newReportName).append("_").append(newTimeStamp).append(ReportsConstants.DOT_CSV)
                        .toString();
    }

    @Override
    public long getKeyFromKeyHolder() {

        try {
            KeyHolder keyHolder = new GeneratedKeyHolder(); // Create a
                                                            // KeyHolder object
            jdbcTemplateTrn.update(con -> {
                PreparedStatement ps = con.prepareStatement(ReportsCommonSql.GET_INSERT_INTO_LOGPROCEXECUTION,
                                Statement.RETURN_GENERATED_KEYS);
                ps.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
                return ps;
            }, keyHolder); // Pass the KeyHolder object to the update method

            // Retrieve the generated key
            Number generatedKey = keyHolder.getKey();
            if (generatedKey != null) {
                key = generatedKey.longValue();

            }
        } catch (Exception e) {
            log.error("Error occurred while inserting data of procedures details into table", e);
        }
        return key;

    }

    @Override
    public void getUpdateLogProcExecution(String callStatement, long key) {

        // Convert the callStatement to lowercase for case-insensitive matching
        callStatement = callStatement.toLowerCase();

        // Find the starting index of the procedure name
        int startIndex = callStatement.indexOf("call ") + "call ".length();

        // Find the ending index of the procedure name (before the opening
        // parenthesis)
        int endIndex = callStatement.indexOf("(", startIndex);
        String procedureName = "";

        if (startIndex != -1 && endIndex != -1) {
            // Extract the procedure name using substring
            procedureName = callStatement.substring(startIndex, endIndex);

        }

        try {
            jdbcTemplateTrn.update(ReportsCommonSql.GET_UPDATE_INTO_LOGPROCEXECUTION,
                            new Timestamp(System.currentTimeMillis()), callStatement, procedureName, key);
        } catch (DataAccessException e) {
            log.error("error coming at the time of updating procedure details");
        }

    }

    @Override
    public BigInteger insertDetailsIntoMailBox1(String userId, String reportName, Timestamp timeStamp) {

        DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm");
        String triggeredOn = dateFormat.format(timeStamp);
        String generatedOn = dateFormat.format(new Timestamp(System.currentTimeMillis()));
        String mailStatus = Constants.NEW;
        String mailFrom = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_SYSTEM_MAIL, String.class);
        String encryptedMailto = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_MAIL_BY_USER_ID, String.class,
                        userId);
        String appKey = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_APP_KEY, String.class,
                        ReportsConstants.ENCRYPTION_APP_KEY);

        try {
            mailto = EncryptionUtils.decrypt(appKey, encryptedMailto);
        } catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException | NoSuchPaddingException
                        | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException
                        | DecoderException e) {
            log.error("error coming at the time of decripting login ID.");
        }

        String firstName = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_FIRSTNAME_BY_USER_ID, String.class,
                        userId);
        String lastName = jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_LASTNAME_BY_USER_ID, String.class,
                        userId);
        String mailBody = "<p>Dear " + firstName + " " + lastName + ",</p>\r\n"
                        + "<p>We would like to inform you that, Background report <b> " + reportName
                        + "</b> has been generated, Please visit the Report section and download the report information</p>\r\n"
                        + "<p><p>Report Triggered on:" + triggeredOn + "<p>  <p>Report Generated on:" + generatedOn
                        + "<p></p>\r\n" + "<p>Best Regards,</p>" + "<p><b> Vendor Compliance & AP Automation </b></p>";

        String mailBody2 = "<table > " + "<tr align= \"left\"> <th>From:</th><td>" + mailFrom + "</td></tr>"
                        + "<tr align= \"left\"> <th>Sent:</th><td>" + generatedOn + "</td>  </tr>"
                        + "<tr align= \"left\"> <th>To:</th><td>" + mailto + "</td> </tr>"
                        + "<tr align= \"left\"> <th>Subject:</th><td>" + "Background report of " + reportName
                        + "</td></tr>" + "</table> " + "<p>Dear " + firstName + " " + lastName + "," + " </p>"
                        + "<p>Your request of generating <strong>" + reportName
                        + "</strong> is completed for following parameters.</p> " + "<p>Tradename: -</p>"
                        + "<p>Status: -</p>" + "<p>Financial Year: -</p>" + "<p>File Size: -</p>"
                        + "<p>Records Found : -</p>" + " Best Regards,<br> "
                        + "<strong>BDO Vendor Management Solution Support</strong> "
                        + "<p>The information contained in this communication is intended solely for the"
                        + " use of the individual or entity to whom it is addressed and others authorized to"
                        + " receive it. This communication may contain confidential or legally privileged information."
                        + " If you are not the intended recipient please notify us, preferably by e-mail, and do not"
                        + " read, copy or disclose the contents of this message to anyone. No liability is accepted "
                        + "for any harm that may be caused to your systems or data by this message.</p> ";

        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplateTrn.update(connection -> {
            // Assuming 'id' is the generated key column
            PreparedStatement ps = connection.prepareStatement(ReportsCommonSql.UPDATE_MAIL_BOX, new String[] { "id" });
            ps.setString(1, mailto);
            ps.setString(2, mailFrom);
            ps.setString(3, "Background report of " + reportName);
            ps.setString(4, mailBody);
            ps.setString(5, firstName);
            ps.setString(6, lastName);
            ps.setString(7, mailStatus);
            return ps;
        }, keyHolder);

        // Retrieve the generated key
        return (BigInteger) keyHolder.getKey();

    }

    @Override
    public void sendMailDetails(BigInteger id) throws MessagingException {

//        MailTemplateDTO mailDetails = new MailTemplateDTO();
//        try {
//            mailDetails = jdbcTemplateTrn.queryForObject(ReportsCommonSql.getMailDetails(id),
//                            BeanPropertyRowMapper.newInstance(MailTemplateDTO.class));
//        } catch (DataAccessException e) {
//            log.error("Error coming while getting maildetails from database.");
//        }
//        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
//
//        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
//
//        helper.setTo(mailDetails.getMailTo());
//
//        helper.setFrom(mailDetails.getMailFrom());
//        helper.setSubject(mailDetails.getMailSubject());
//
//        helper.setText(mailDetails.getMailBody(), true);
//
////        ClassPathResource classPathResource = new ClassPathResource("VendoeInvoice_question.txt");
////        helper.addAttachment(classPathResource.getFilename(), classPathResource);
//        helper.addInline("myLogo", new ClassPathResource("BDO_logo.jpg"));
//
//        javaMailSender.send(mimeMessage);

    }

    @Override
    public Map<String, Object> commonPostNotification(int vendoruploadmstid, String string, int userId, int userId2,
                    int userId3, String notificationCode) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall("{call common_post_notification(?,?,?,?,?,?,?)}");
                if (cs != null) {
                    cs.setInt(1, vendoruploadmstid);
                    cs.setString(2, string);
                    cs.setInt(3, userId);
                    cs.setInt(4, userId2);
                    cs.setInt(5, userId3);
                    cs.setString(6, mstDatabseName);
                    cs.setString(7, notificationCode);

                }
                return cs;
            }
        }, parameters);

    }
}
