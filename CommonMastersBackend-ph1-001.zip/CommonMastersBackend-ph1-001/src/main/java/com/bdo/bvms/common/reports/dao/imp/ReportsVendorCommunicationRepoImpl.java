package com.bdo.bvms.common.reports.dao.imp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.config.AzureClientProvider;
import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.ReportsVendorCommInwardRegisterResDTO;
import com.bdo.bvms.common.dto.ReportsVendorCommInwardVsGSTR2AResDTO;
import com.bdo.bvms.common.dto.ReportsVendorCommInwardVsGSTR2BResDTO;
import com.bdo.bvms.common.dto.ReportsVendorCommVendorEmailStatusResDTO;
import com.bdo.bvms.common.dto.VendorCommunicationEmailStatusReqDTO;
import com.bdo.bvms.common.dto.VendorCommunicationInwardReqDTO;
import com.bdo.bvms.common.dto.VendorCommunicationReconciliationReqDTO;
import com.bdo.bvms.common.reports.constants.ReportsConstants;
import com.bdo.bvms.common.reports.dao.ReportModuleCommonRepo;
import com.bdo.bvms.common.reports.dao.ReportsVendorCommunicationRepo;
import com.bdo.bvms.common.reports.sql.ReportsCommonSql;

import lombok.Synchronized;
import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class ReportsVendorCommunicationRepoImpl implements ReportsVendorCommunicationRepo {

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Value("${txn.database-name}")
    private String transDatabaseName;

    @Value("${bvms.cloud.temp.file.download.path}")
    String tempFolder;

    @Autowired
    public AzureClientProvider client;

    CallableStatement cs = null;
    long key;
    String callStatement;

    ResourceBundle messages = ResourceBundle.getBundle("messages");
    String errorInGeneratingCSVFile = messages.getString("errorInGeneratingCSVFile");
    String errorInGeneratingExcelWorkbook = messages.getString("errorInGeneratingExcelWorkbook");
    String greeting = messages.getString("searchParameters");

    @Autowired
    ReportModuleCommonRepo reportModuleCommonRepo;

    private static String checkNullValue(String value) {
        if (StringUtils.isEmpty(value)) {
            return "-";
        } else {
            return value;
        }
    }

    private static String checkNullValue(BigDecimal value) {
        if (value == null) {
            return "0";
        } else {
            return value.toString();
        }
    }

    @Override
    @Synchronized
    public Map<String, Object> getInwardDataList(VendorCommunicationInwardReqDTO vendorCommunicationInwardReq,
                    String monthList, String gstinList) throws SQLException {
        // vendorCommunicationInwardReq

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));
        String docType = vendorCommunicationInwardReq.getDocType().toString().replace("[", "").replace("]", "")
                        .replace("{", "").replace("}", "").replace(" ", "");
        String supplyType = vendorCommunicationInwardReq.getSupplyType().toString().replace("[", "").replace("]", "")
                        .replace("{", "").replace("}", "").replace(" ", "");
        String isCustom = reportModuleCommonRepo.getCustomOrDefault(vendorCommunicationInwardReq.getReportId());
        int templateTypeId = 7;
        String actionType = "view";
        key = reportModuleCommonRepo.getKeyFromKeyHolder();

        Map<String, Object> results;
        try {
            results = jdbcTemplateTrn.call(new CallableStatementCreator() {

                @Override
                public CallableStatement createCallableStatement(Connection con) throws SQLException {

                    try {
                        if (ReportsConstants.INWARD_REGISTER_REPORT.equals(vendorCommunicationInwardReq.getReportId())
                                        || ReportsConstants.CUSTOM_INWARD_REGISTER_REPORT
                                                        .equals(vendorCommunicationInwardReq.getReportId())) {
                            cs = con.prepareCall(
                                            "{call report_communication_inward_register(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

                        } else if (ReportsConstants.CUSTOM_INWARD_ERROR_REPORT
                                        .equals(vendorCommunicationInwardReq.getReportId())) {
                            cs = con.prepareCall(
                                            "{ call report_communication_inward_register_error(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                            vendorCommunicationInwardReq.setSummaryType("Line-level");
                        }

                        cs.setString(1, gstinList);
                        cs.setString(2, monthList);
                        cs.setString(3, docType);
                        cs.setString(4, supplyType);
                        cs.setString(5, vendorCommunicationInwardReq.getSummaryType());
                        cs.setString(6, vendorCommunicationInwardReq.getReportId());
                        cs.setString(7, mstDatabseName);
                        cs.setString(8, isCustom);
                        cs.setInt(9, templateTypeId);
                        cs.setInt(10, vendorCommunicationInwardReq.getCustomTemplateId());
                        cs.setString(11, vendorCommunicationInwardReq.getUserId());
                        cs.setString(12, actionType);
                        cs.setInt(13, vendorCommunicationInwardReq.getSize());
                        cs.setInt(14, vendorCommunicationInwardReq.getPage() * vendorCommunicationInwardReq.getSize());
                        callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                        reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                        return cs;
                    } catch (SQLException e) {
                        if (cs != null) {
                            cs.close();
                        }
                        throw e;
                    } // TOTAL_COUNT
                }
            }, parameters);

            // Process the results object here

        } finally {
            if (cs != null) {
                cs.close();
            }
        }

        Map<String, Object> syncTabVendorInvoceReportData = new HashMap<>();

        List<ReportsVendorCommInwardRegisterResDTO> getInwardReportsList = new ArrayList<>();

        if (!results.isEmpty()) {// RESULT_SET_1

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> dataList = (List<Map<String, Object>>) results.get(ReportsConstants.RESULT_SET_1);
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> countValue = (List<Map<String, Object>>) results
                            .get(ReportsConstants.RESULT_SET_2);
            Map<String, Object> count11 = countValue.get(0);
            long totalCount = (long) count11.get(ReportsConstants.TOTAL_COUNT);

            dataList.stream().forEach(dataObject -> {

                ReportsVendorCommInwardRegisterResDTO dataRes = new ReportsVendorCommInwardRegisterResDTO();

                if (vendorCommunicationInwardReq.getSummaryType().equals(ReportsConstants.LINE_LEVEL)
                                && (ReportsConstants.INWARD_REGISTER_REPORT
                                                .equals(vendorCommunicationInwardReq.getReportId())
                                                || ReportsConstants.CUSTOM_INWARD_REGISTER_REPORT
                                                                .equals(vendorCommunicationInwardReq.getReportId()))) {

                    dataRes.setGstinUinOfRecipient(checkNullValue((String) dataObject.get("gstin_uin_of_recipient")));
                    dataRes.setDocType(checkNullValue((String) dataObject.get("doc_type")));
                    dataRes.setSupplyType(checkNullValue((String) dataObject.get("supply_type")));
                    dataRes.setDocNo(checkNullValue((String) dataObject.get("doc_no")));
                    dataRes.setDocDate(checkNullValue((String) dataObject.get("doc_date")));
                    dataRes.setOrgInvoiceNo(checkNullValue((String) dataObject.get("org_invoice_no")));
                    dataRes.setOrgInvoiceDate(checkNullValue((String) dataObject.get("org_invoice_date")));
                    dataRes.setGstinOfSupplier(checkNullValue((String) dataObject.get("gstin_of_supplier")));
                    dataRes.setSupplierName(checkNullValue((String) dataObject.get("supplier_name")));
                    dataRes.setSupplierStateCode(checkNullValue((String) dataObject.get("supplier_state_code")));
                    dataRes.setInwardNo(checkNullValue((String) dataObject.get("inward_no")));
                    dataRes.setInwardDate(checkNullValue((String) dataObject.get("inward_date")));
                    dataRes.setItemDescription(checkNullValue((String) dataObject.get("item_description")));
                    dataRes.setHsnCode(checkNullValue((String) dataObject.get("hsn_code")));
                    dataRes.setUom(checkNullValue((String) dataObject.get("uom")));
                    dataRes.setFp(checkNullValue((String) dataObject.get("fp")));
                    dataRes.setQuantity(checkNullValue((String) dataObject.get("quantity")));
                    dataRes.setItemRate(checkNullValue((BigDecimal) dataObject.get("item_rate")));
                    dataRes.setAssAmt(checkNullValue((BigDecimal) dataObject.get("ass_amt")));
                    dataRes.setSgstRate(checkNullValue((BigDecimal) dataObject.get("sgst_rate")));
                    dataRes.setSgstAmt(checkNullValue((BigDecimal) dataObject.get("sgst_amt")));
                    dataRes.setCgstRate(checkNullValue((BigDecimal) dataObject.get("cgst_rate")));
                    dataRes.setCgstAmt(checkNullValue((BigDecimal) dataObject.get("cgst_amt")));
                    dataRes.setIgstRate(checkNullValue((BigDecimal) dataObject.get("igst_rate")));
                    dataRes.setIgstAmt(checkNullValue((BigDecimal) dataObject.get("igst_amt")));
                    dataRes.setCessRate(checkNullValue((BigDecimal) dataObject.get("cess_rate")));
                    dataRes.setCessAmount(checkNullValue((BigDecimal) dataObject.get("cess_amount")));
                    dataRes.setDiffPercent(checkNullValue((BigDecimal) dataObject.get("diff_percent")));
                    dataRes.setInwardGrossTotalAmount(
                                    checkNullValue((BigDecimal) dataObject.get("inward_gross_total_amount")));
                    dataRes.setTotalInvoiceAmt(checkNullValue((BigDecimal) dataObject.get("total_invoice_amt")));
                    dataRes.setInputType(checkNullValue((String) dataObject.get("input_type")));
                    dataRes.setItcIneligibleReversalIndicator(
                                    checkNullValue((String) dataObject.get("itc_ineligible_reversal_indicator")));
                    dataRes.setItcIneligibleReversalPerc(
                                    checkNullValue((BigDecimal) dataObject.get("itc_ineligible_reversal_percentage")));
                    dataRes.setPlaceOfSupply(checkNullValue((String) dataObject.get("place_of_supply")));
                    dataRes.setReverseCharge(checkNullValue((String) dataObject.get("reverse_charge")));
                    dataRes.setTdsSection(checkNullValue((String) dataObject.get("tds_section")));
                    dataRes.setTdsRate(checkNullValue((BigDecimal) dataObject.get("tds_rate")));
                    dataRes.setTdsTaxAmount(checkNullValue((BigDecimal) dataObject.get("tds_tax_amount")));
                    dataRes.setGrossAmount(checkNullValue((BigDecimal) dataObject.get("gross_amount")));
                    dataRes.setChallanNumber(checkNullValue((String) dataObject.get("challan_number")));
                    dataRes.setChallanDate(checkNullValue((String) dataObject.get("challan_date")));
                    dataRes.setChallanAmount(checkNullValue((BigDecimal) dataObject.get("challan_amount")));
                    dataRes.setPeriodOfFiling(checkNullValue((String) dataObject.get("period_of_filing")));

                    dataRes.setInvoiceAgainstProvAdv(
                                    checkNullValue((String) dataObject.get("invoice_against_prov_adv")));

                    dataRes.setInwardNoProvAdv(checkNullValue((String) dataObject.get("inward_no_prov_adv")));
                    dataRes.setAmountOfProvAdv(checkNullValue((BigDecimal) dataObject.get("amount_of_prov_adv")));
                    dataRes.setBalOutstanding(checkNullValue((BigDecimal) dataObject.get("bal_outstanding")));
                    dataRes.setPort(checkNullValue((String) dataObject.get("port")));
                    dataRes.setImportBillOfEntryNo(checkNullValue((String) dataObject.get("import_bill_of_entry_no")));
                    dataRes.setImportBillOfEntryDate(
                                    checkNullValue((String) dataObject.get("import_bill_of_entry_date")));
                    dataRes.setImportBillOfEntryAmt(
                                    checkNullValue((BigDecimal) dataObject.get("import_bill_of_entry_amt")));
                    dataRes.setDateOfPayment(checkNullValue((String) dataObject.get("date_of_payment")));
                    dataRes.setIrn(checkNullValue((String) dataObject.get("irn")));
                    dataRes.setAckDate(checkNullValue((String) dataObject.get("ack_date")));
                    dataRes.setAckNo(checkNullValue((String) dataObject.get("ack_no")));
                    dataRes.setDebitGlId(checkNullValue((String) dataObject.get("debit_gl_id")));
                    dataRes.setDebitGlName(checkNullValue((String) dataObject.get("debit_gl_name")));
                    dataRes.setCreditGlId(checkNullValue((String) dataObject.get("credit_gl_id")));
                    dataRes.setCreditGlName(checkNullValue((String) dataObject.get("credit_gl_name")));
                    dataRes.setSubLocation(checkNullValue((String) dataObject.get("sub_location")));
                    dataRes.setUdf1(checkNullValue((String) dataObject.get("udf_1")));
                    dataRes.setUdf2(checkNullValue((String) dataObject.get("udf_2")));
                    dataRes.setUdf3(checkNullValue((String) dataObject.get("udf_3")));
                    dataRes.setUdf4(checkNullValue((String) dataObject.get("udf_4")));
                    dataRes.setUdf5(checkNullValue((String) dataObject.get("udf_5")));
                    dataRes.setUdf6(checkNullValue((String) dataObject.get("udf_6")));
                    dataRes.setUdf7(checkNullValue((String) dataObject.get("udf_7")));
                    dataRes.setUdf8(checkNullValue((String) dataObject.get("udf_8")));
                    dataRes.setUdf9(checkNullValue((String) dataObject.get("udf_9")));
                    dataRes.setUdf10(checkNullValue((String) dataObject.get("udf_10")));
                    dataRes.setUdf11(checkNullValue((String) dataObject.get("udf_11")));
                    dataRes.setUdf12(checkNullValue((String) dataObject.get("udf_12")));
                    dataRes.setUdf13(checkNullValue((String) dataObject.get("udf_13")));
                    dataRes.setUdf14(checkNullValue((String) dataObject.get("udf_14")));
                    dataRes.setUdf15(checkNullValue((String) dataObject.get("udf_15")));
                    dataRes.setUdf16(checkNullValue((String) dataObject.get("udf_16")));
                    dataRes.setUdf17(checkNullValue((String) dataObject.get("udf_17")));
                    dataRes.setUdf18(checkNullValue((String) dataObject.get("udf_18")));
                    dataRes.setUdf19(checkNullValue((String) dataObject.get("udf_19")));
                    dataRes.setUdf20(checkNullValue((String) dataObject.get("udf_20")));

                } else if (vendorCommunicationInwardReq.getSummaryType().equals(ReportsConstants.LINE_LEVEL)
                                && ReportsConstants.CUSTOM_INWARD_ERROR_REPORT
                                                .equals(vendorCommunicationInwardReq.getReportId())) {

                    dataRes.setGstinUinOfRecipient(checkNullValue((String) dataObject.get("gstin_uin_of_recipient")));
                    dataRes.setDocType(checkNullValue((String) dataObject.get("doc_type")));
                    dataRes.setSupplyType(checkNullValue((String) dataObject.get("supply_type")));
                    dataRes.setDocNo(checkNullValue((String) dataObject.get("doc_no")));
                    dataRes.setDocDate(checkNullValue((String) dataObject.get("doc_date")));
                    dataRes.setOrgInvoiceNo(checkNullValue((String) dataObject.get("org_invoice_no")));
                    dataRes.setOrgInvoiceDate(checkNullValue((String) dataObject.get("org_invoice_date")));
                    dataRes.setGstinOfSupplier(checkNullValue((String) dataObject.get("gstin_of_supplier")));
                    dataRes.setSupplierName(checkNullValue((String) dataObject.get("supplier_name")));
                    dataRes.setSupplierStateCode(checkNullValue((String) dataObject.get("supplier_state_code")));
                    dataRes.setInwardNo(checkNullValue((String) dataObject.get("inward_no")));
                    dataRes.setInwardDate(checkNullValue((String) dataObject.get("inward_date")));
                    dataRes.setItemDescription(checkNullValue((String) dataObject.get("item_description")));
                    dataRes.setHsnCode(checkNullValue((String) dataObject.get("hsn_code")));
                    dataRes.setUom(checkNullValue((String) dataObject.get("uom")));

                    dataRes.setQuantity(checkNullValue((String) dataObject.get("quantity")));
                    dataRes.setItemRate(checkNullValue((String) dataObject.get("item_rate")));
                    dataRes.setAssAmt(checkNullValue((String) dataObject.get("ass_amt")));
                    dataRes.setSgstRate(checkNullValue((String) dataObject.get("sgst_rate")));
                    dataRes.setSgstAmt(checkNullValue((String) dataObject.get("sgst_amt")));
                    dataRes.setCgstRate(checkNullValue((String) dataObject.get("cgst_rate")));
                    dataRes.setCgstAmt(checkNullValue((String) dataObject.get("cgst_amt")));
                    dataRes.setIgstRate(checkNullValue((String) dataObject.get("igst_rate")));
                    dataRes.setIgstAmt(checkNullValue((String) dataObject.get("igst_amt")));
                    dataRes.setCessRate(checkNullValue((String) dataObject.get("cess_rate")));
                    dataRes.setCessAmount(checkNullValue((String) dataObject.get("cess_amount")));
                    dataRes.setDiffPercent(checkNullValue((String) dataObject.get("diff_percent")));
                    dataRes.setInwardGrossTotalAmount(
                                    checkNullValue((String) dataObject.get("inward_gross_total_amount")));
                    dataRes.setTotalInvoiceAmt(checkNullValue((String) dataObject.get("total_invoice_amt")));
                    dataRes.setInputType(checkNullValue((String) dataObject.get("input_type")));
                    dataRes.setItcIneligibleReversalIndicator(
                                    checkNullValue((String) dataObject.get("itc_ineligible_reversal_indicator")));
                    dataRes.setItcIneligibleReversalPerc(
                                    checkNullValue((String) dataObject.get("itc_ineligible_reversal_percentage")));
                    dataRes.setPlaceOfSupply(checkNullValue((String) dataObject.get("place_of_supply")));
                    dataRes.setReverseCharge(checkNullValue((String) dataObject.get("reverse_charge")));
                    dataRes.setTdsSection(checkNullValue((String) dataObject.get("tds_section")));
                    dataRes.setTdsRate(checkNullValue((BigDecimal) dataObject.get("tds_rate")));
                    dataRes.setTdsTaxAmount(checkNullValue((BigDecimal) dataObject.get("tds_tax_amount")));
                    dataRes.setGrossAmount(checkNullValue((String) dataObject.get("gross_amount")));
                    dataRes.setChallanNumber(checkNullValue((String) dataObject.get("challan_number")));
                    dataRes.setChallanDate(checkNullValue((String) dataObject.get("challan_date")));
                    dataRes.setChallanAmount(checkNullValue((BigDecimal) dataObject.get("challan_amount")));
                    dataRes.setPeriodOfFiling(checkNullValue((String) dataObject.get("period_of_filing")));
                    dataRes.setOrgInvoiceDate(checkNullValue((String) dataObject.get("invoice_against_prov_adv")));
                    dataRes.setInwardNoProvAdv(checkNullValue((String) dataObject.get("inward_no_prov_adv")));
                    dataRes.setAmountOfProvAdv(checkNullValue((BigDecimal) dataObject.get("amount_of_prov_adv")));
                    dataRes.setBalOutstanding(checkNullValue((BigDecimal) dataObject.get("bal_outstanding")));
                    dataRes.setPort(checkNullValue((String) dataObject.get("port")));
                    dataRes.setImportBillOfEntryNo(checkNullValue((String) dataObject.get("import_bill_of_entry_no")));
                    dataRes.setImportBillOfEntryDate(
                                    checkNullValue((String) dataObject.get("import_bill_of_entry_date")));
                    dataRes.setImportBillOfEntryAmt(
                                    checkNullValue((String) dataObject.get("import_bill_of_entry_amt")));
                    dataRes.setDateOfPayment(checkNullValue((String) dataObject.get("date_of_payment")));
                    dataRes.setIrn(checkNullValue((String) dataObject.get("irn")));
                    dataRes.setAckDate(checkNullValue((String) dataObject.get("ack_date")));
                    dataRes.setAckNo(checkNullValue((String) dataObject.get("ack_no")));
                    dataRes.setDebitGlId(checkNullValue((String) dataObject.get("debit_gl_id")));
                    dataRes.setDebitGlName(checkNullValue((String) dataObject.get("debit_gl_name")));
                    dataRes.setCreditGlId(checkNullValue((String) dataObject.get("credit_gl_id")));
                    dataRes.setCreditGlName(checkNullValue((String) dataObject.get("credit_gl_name")));
                    dataRes.setSubLocation(checkNullValue((String) dataObject.get("sub_location")));
                    dataRes.setUdf1(checkNullValue((String) dataObject.get("udf_1")));
                    dataRes.setUdf2(checkNullValue((String) dataObject.get("udf_2")));
                    dataRes.setUdf3(checkNullValue((String) dataObject.get("udf_3")));
                    dataRes.setUdf4(checkNullValue((String) dataObject.get("udf_4")));
                    dataRes.setUdf5(checkNullValue((String) dataObject.get("udf_5")));
                    dataRes.setUdf6(checkNullValue((String) dataObject.get("udf_6")));
                    dataRes.setUdf7(checkNullValue((String) dataObject.get("udf_7")));
                    dataRes.setUdf8(checkNullValue((String) dataObject.get("udf_8")));
                    dataRes.setUdf9(checkNullValue((String) dataObject.get("udf_9")));
                    dataRes.setUdf10(checkNullValue((String) dataObject.get("udf_10")));
                    dataRes.setUdf11(checkNullValue((String) dataObject.get("udf_11")));
                    dataRes.setUdf12(checkNullValue((String) dataObject.get("udf_12")));
                    dataRes.setUdf13(checkNullValue((String) dataObject.get("udf_13")));
                    dataRes.setUdf14(checkNullValue((String) dataObject.get("udf_14")));
                    dataRes.setUdf15(checkNullValue((String) dataObject.get("udf_15")));
                    dataRes.setUdf16(checkNullValue((String) dataObject.get("udf_16")));
                    dataRes.setUdf17(checkNullValue((String) dataObject.get("udf_17")));
                    dataRes.setUdf18(checkNullValue((String) dataObject.get("udf_18")));
                    dataRes.setUdf19(checkNullValue((String) dataObject.get("udf_19")));
                    dataRes.setUdf20(checkNullValue((String) dataObject.get("udf_20")));

                    dataRes.setErrorCode(checkNullValue((String) dataObject.get("error_code")));
                    dataRes.setErrorMessage(checkNullValue((String) dataObject.get("error_message")));

                }

                else if (vendorCommunicationInwardReq.getSummaryType().equals(ReportsConstants.INVOICE_LEVEL)) {

                    dataRes.setGstinUinOfRecipient(checkNullValue((String) dataObject.get("gstin_uin_of_recipient")));
                    dataRes.setDocType(checkNullValue((String) dataObject.get("doc_type")));
                    dataRes.setDocNo(checkNullValue((String) dataObject.get("doc_no")));
                    dataRes.setDocDate(checkNullValue((String) dataObject.get("doc_date")));
                    dataRes.setGstinOfSupplier(checkNullValue((String) dataObject.get("gstin_of_supplier")));
                    dataRes.setSupplierName(checkNullValue((String) dataObject.get("supplier_name")));
                    dataRes.setSupplierStateCode(checkNullValue((String) dataObject.get("supplier_state_code")));
                    dataRes.setInwardNo(checkNullValue((String) dataObject.get("inward_no")));
                    dataRes.setInwardDate(checkNullValue((String) dataObject.get("inward_date")));
                    dataRes.setFp(checkNullValue((String) dataObject.get("fp")));
                    dataRes.setSumTaxableAmount(checkNullValue((BigDecimal) dataObject.get("sum_taxable_amt")));
                    dataRes.setSumSgstAmt(checkNullValue((BigDecimal) dataObject.get("sum_sgst_amt")));
                    dataRes.setSumCgstAmt(checkNullValue((BigDecimal) dataObject.get("sum_cgst_amt")));
                    dataRes.setSumIgstAmt(checkNullValue((BigDecimal) dataObject.get("sum_igst_amt")));
                    dataRes.setSumTotalTaxAmount(checkNullValue((BigDecimal) dataObject.get("sum_total_tax_amount")));
                    dataRes.setSumGrossTotalAmount(
                                    checkNullValue((BigDecimal) dataObject.get("sum_gross_total_amount")));
                    if (ReportsConstants.CUSTOM_INWARD_ERROR_REPORT
                                    .equals(vendorCommunicationInwardReq.getReportId())) {
                        dataRes.setErrorCode(checkNullValue((String) dataObject.get("error_code")));
                        dataRes.setErrorMessage(checkNullValue((String) dataObject.get("error_message")));
                    }

                }

                getInwardReportsList.add(dataRes);
            });

            syncTabVendorInvoceReportData.put("InwardTabVendorCommunicationReportData", getInwardReportsList);
            syncTabVendorInvoceReportData.put("totalCount", totalCount);

        }
        return syncTabVendorInvoceReportData;

    }

    @Override
    @Synchronized
    public Map<String, Object> getVendorCommunicationReconciliationReportsResList(String taxpayerGstin, String yearId,
                    String recoStatus, String vendorGstin,
                    VendorCommunicationReconciliationReqDTO vendorCommunicationReconciliationReq, String pan)
                    throws SQLException {

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));
        String isCustom = reportModuleCommonRepo.getCustomOrDefault(vendorCommunicationReconciliationReq.getReportId());
        int templateTypeId = 7;
        String actionType = "view";

        key = reportModuleCommonRepo.getKeyFromKeyHolder();
        Map<String, Object> results;
        try {
            results = jdbcTemplateTrn.call(new CallableStatementCreator() {

                @Override
                public CallableStatement createCallableStatement(Connection con) throws SQLException {

                    try {
                        if (ReportsConstants.INWARD_VS_GSTR2A_RECO_REPORT
                                        .equals(vendorCommunicationReconciliationReq.getReportId())
                                        || ReportsConstants.CUSTOM_INWARD_VS_GSTR2A_RECO_REPORT
                                                        .equals(vendorCommunicationReconciliationReq.getReportId())) {
                            cs = con.prepareCall(
                                            "{call report_communication_reco_inward_gstr2a (?,?,?,?,?,?,?,?,?,?,?,?,?)}");

                        } else if (ReportsConstants.INWARD_VS_GSTR2B_RECO_REPORT
                                        .equals(vendorCommunicationReconciliationReq.getReportId())
                                        || ReportsConstants.CUSTOM_INWARD_VS_GSTR2B_RECO_REPORT
                                                        .equals(vendorCommunicationReconciliationReq.getReportId())) {
                            cs = con.prepareCall(
                                            "{call report_communication_reco_inward_gstr2b (?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                        }

                        cs.setString(1, pan);
                        cs.setString(2, taxpayerGstin);
                        cs.setString(3, yearId);
                        cs.setString(4, recoStatus);
                        cs.setString(5, vendorGstin);
                        cs.setString(6, mstDatabseName);
                        cs.setString(7, isCustom);
                        cs.setInt(8, templateTypeId);
                        cs.setInt(9, vendorCommunicationReconciliationReq.getCustomTemplateId());
                        cs.setString(10, vendorCommunicationReconciliationReq.getUserId());
                        cs.setString(11, actionType);
                        cs.setInt(12, vendorCommunicationReconciliationReq.getSize());
                        cs.setInt(13, vendorCommunicationReconciliationReq.getPage()
                                        * vendorCommunicationReconciliationReq.getSize());
                        callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                        reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                        return cs;
                    } catch (SQLException e) {
                        if (cs != null) {
                            cs.close();
                        }
                        throw e;
                    }
                }
            }, parameters);

            // Process the results object here

        } finally {
            if (cs != null) {
                cs.close();
            }
        }

        Map<String, Object> inwardTabVendorCommunicationReportData = new HashMap<>();

        if (!results.isEmpty()) {

            if (ReportsConstants.INWARD_VS_GSTR2A_RECO_REPORT.equals(vendorCommunicationReconciliationReq.getReportId())
                            || ReportsConstants.CUSTOM_INWARD_VS_GSTR2A_RECO_REPORT
                                            .equals(vendorCommunicationReconciliationReq.getReportId())) {
                List<ReportsVendorCommInwardVsGSTR2AResDTO> getReconciliationTabReportsList = new ArrayList<>();

                @SuppressWarnings("unchecked")
                List<Map<String, Object>> dataList = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_1);
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> countValue = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_2);
                Map<String, Object> count11 = countValue.get(0);
                long totalCount = (long) count11.get(ReportsConstants.TOTAL_COUNT);

                dataList.stream().forEach(dataObject -> {

                    ReportsVendorCommInwardVsGSTR2AResDTO dataRes = new ReportsVendorCommInwardVsGSTR2AResDTO();

                    dataRes.setRecoStatus(checkNullValue((String) dataObject.get("Reco Status")));
                    dataRes.setReason(checkNullValue((String) dataObject.get("Reason")));
                    dataRes.setGstin(checkNullValue((String) dataObject.get("GSTIN")));
                    dataRes.setDocumentNo(checkNullValue((String) dataObject.get("Document No.")));
                    dataRes.setDocDate(checkNullValue((String) dataObject.get("DOC Date")));
                    dataRes.setVendorGSTIN(checkNullValue((String) dataObject.get("Vendor (Supplier) GSTIN")));
                    dataRes.setVendorName(checkNullValue((String) dataObject.get("Vendor Name")));
                    dataRes.setRecordType(checkNullValue((String) dataObject.get("Record Type")));
                    dataRes.setInvoiceNo(checkNullValue((String) dataObject.get("Invoice No.")));
                    dataRes.setInvoiceDate(checkNullValue((String) dataObject.get("Invoice Date")));
                    dataRes.setNoteNo(checkNullValue((String) dataObject.get("Note No.")));
                    dataRes.setNoteDate(checkNullValue((String) dataObject.get("Note Date")));
                    dataRes.setOrgInvNo(checkNullValue((String) dataObject.get("Org. Inv. No.")));
                    dataRes.setOrgInvDate(checkNullValue((String) dataObject.get("Org. Inv. Date")));
                    dataRes.setInvoiceReference(checkNullValue((String) dataObject.get("Invoice Reference")));
                    dataRes.setInvoiceDateReference(checkNullValue((String) dataObject.get("Invoice Date Reference")));
                    dataRes.setCategory(checkNullValue((String) dataObject.get("Category")));
                    dataRes.setNoteType(checkNullValue((String) dataObject.get("Note Type")));
                    dataRes.setFinancialPeriod(checkNullValue((String) dataObject.get("Financial Period")));
                    dataRes.setImportRefDate(checkNullValue((String) dataObject.get("Import Ref. Date")));
                    dataRes.setPortCode(checkNullValue((String) dataObject.get("Port Code")));
                    dataRes.setBillOfEntryNumber(checkNullValue((String) dataObject.get("Bill of Entry Number")));
                    dataRes.setBillOfEntryDate(checkNullValue((String) dataObject.get("Bill of Entry Date")));
                    dataRes.setPosCode(checkNullValue((String) dataObject.get("POS Code")));
                    dataRes.setCfsGSTR1(checkNullValue((String) dataObject.get("CFS - GSTR1")));
                    dataRes.setCfsGSTR3B(checkNullValue((String) dataObject.get("CFS - GSTR3B")));
                    dataRes.setReverseCharge(checkNullValue((String) dataObject.get("Reverse Charge")));
                    dataRes.setInvoiceValue((BigDecimal) dataObject.get("Invoice Value"));
                    dataRes.setTaxableValue((BigDecimal) dataObject.get("Taxable Value"));
                    dataRes.setTaxRate((BigDecimal) dataObject.get("Tax Rate"));
                    dataRes.setIgstAmt((BigDecimal) dataObject.get("IGST Amt"));
                    dataRes.setCgstAmt((BigDecimal) dataObject.get("CGST Amt"));
                    dataRes.setSgstAmt((BigDecimal) dataObject.get("SGST Amt"));
                    dataRes.setCessAmt((BigDecimal) dataObject.get("CESS Amt"));
                    dataRes.setTolerance(checkNullValue((String) dataObject.get("Tolerance")));
                    dataRes.setItcEligibleIneligible(
                                    checkNullValue((String) dataObject.get("ITC Eligible / Ineligible")));
                    dataRes.setDateOfFilingGSTR1(checkNullValue((String) dataObject.get("Date of Filing - GSTR1")));
                    dataRes.setDateOfFilingGSTR3B(checkNullValue((String) dataObject.get("Date of Filing - GSTR3B")));
                    dataRes.setDateOfCancellation(checkNullValue((String) dataObject.get("Date Of Cancellation")));
                    dataRes.setSublocation(checkNullValue((String) dataObject.get("Sublocation")));
                    dataRes.setMultiLinkUniqueKey(checkNullValue((String) dataObject.get("Multi-Link Unique key")));

                    getReconciliationTabReportsList.add(dataRes);

                });
                inwardTabVendorCommunicationReportData.put("ReconciliationTabVendorCommunicationReportData",
                                getReconciliationTabReportsList);
                inwardTabVendorCommunicationReportData.put("totalCount", totalCount);
            } else if (ReportsConstants.INWARD_VS_GSTR2B_RECO_REPORT
                            .equals(vendorCommunicationReconciliationReq.getReportId())
                            || ReportsConstants.CUSTOM_INWARD_VS_GSTR2B_RECO_REPORT
                                            .equals(vendorCommunicationReconciliationReq.getReportId())) {

                List<ReportsVendorCommInwardVsGSTR2BResDTO> getReconciliationTabReportsList = new ArrayList<>();
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> dataList = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_1);
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> countValue = (List<Map<String, Object>>) results
                                .get(ReportsConstants.RESULT_SET_2);
                Map<String, Object> count11 = countValue.get(0);
                long totalCount = (long) count11.get(ReportsConstants.TOTAL_COUNT);

                dataList.stream().forEach(dataObject -> {

                    ReportsVendorCommInwardVsGSTR2BResDTO dataRes = new ReportsVendorCommInwardVsGSTR2BResDTO();
                    dataRes.setRecoStatus(checkNullValue((String) dataObject.get("Reco Status")));
                    dataRes.setReason(checkNullValue((String) dataObject.get("Reason")));
                    dataRes.setGstin(checkNullValue((String) dataObject.get("GSTIN")));
                    dataRes.setDocumentNo(checkNullValue((String) dataObject.get("Document No.")));
                    dataRes.setDocDate(checkNullValue((String) dataObject.get("DOC Date")));
                    dataRes.setVendorSupplierGstin(checkNullValue((String) dataObject.get("Vendor (Supplier) GSTIN")));
                    dataRes.setVendorName(checkNullValue((String) dataObject.get("Vendor Name")));
                    dataRes.setRecordType(checkNullValue((String) dataObject.get("Record Type")));
                    dataRes.setInvoiceNo(checkNullValue((String) dataObject.get("Invoice No.")));
                    dataRes.setInvoiceDate(checkNullValue((String) dataObject.get("Invoice Date")));
                    dataRes.setNoteNo(checkNullValue((String) dataObject.get("Note No.")));
                    dataRes.setNoteDate(checkNullValue((String) dataObject.get("Note Date")));
                    dataRes.setOrgInvNo(checkNullValue((String) dataObject.get("Org. Inv. No.")));
                    dataRes.setOrgInvDate(checkNullValue((String) dataObject.get("Org. Inv. Date")));
                    dataRes.setInvoiceReference(checkNullValue((String) dataObject.get("Invoice Reference")));
                    dataRes.setInvoiceDateReference(checkNullValue((String) dataObject.get("Invoice Date Reference")));
                    dataRes.setCategory(checkNullValue((String) dataObject.get("Category")));
                    dataRes.setNoteType(checkNullValue((String) dataObject.get("Note Type")));
                    dataRes.setFinancialPeriod(checkNullValue((String) dataObject.get("Financial Period")));
                    dataRes.setImportRefDate(checkNullValue((String) dataObject.get("Import Ref. Date")));
                    dataRes.setPortCode(checkNullValue((String) dataObject.get("Port Code")));
                    dataRes.setBillOfEntryNumber(checkNullValue((String) dataObject.get("Bill of Entry Number")));
                    dataRes.setBillOfEntryDate(checkNullValue((String) dataObject.get("Bill of Entry Date")));
                    dataRes.setPosCode(checkNullValue((String) dataObject.get("POS Code")));
                    dataRes.setCfsGstr3b(checkNullValue((String) dataObject.get("CFS - GSTR3B")));
                    dataRes.setReverseCharge(checkNullValue((String) dataObject.get("Reverse Charge")));
                    dataRes.setInvoiceValue((BigDecimal) dataObject.get("Invoice Value"));
                    dataRes.setTaxableValue((BigDecimal) dataObject.get("Taxable Value"));
                    dataRes.setTaxRate((BigDecimal) dataObject.get("Tax Rate"));
                    dataRes.setIgstAmt((BigDecimal) dataObject.get("IGST Amt"));
                    dataRes.setCgstAmt((BigDecimal) dataObject.get("CGST Amt"));
                    dataRes.setSgstAmt((BigDecimal) dataObject.get("SGST Amt"));
                    dataRes.setCessAmt((BigDecimal) dataObject.get("CESS Amt"));
                    dataRes.setTolerance(checkNullValue((String) dataObject.get("Tolerance")));
                    dataRes.setItcEligibleIneligible(
                                    checkNullValue((String) dataObject.get("ITC Eligible / Ineligible")));
                    dataRes.setGstr1FilingPeriod(checkNullValue((String) dataObject.get("GSTR1 Filing Period")));
                    dataRes.setDateOfFilingGSTR1(checkNullValue((String) dataObject.get("Date of Filing - GSTR1")));
                    dataRes.setDateOfFilingGSTR3B(checkNullValue((String) dataObject.get("Date of Filing - GSTR3B")));
                    dataRes.setDateOfCancellation(checkNullValue((String) dataObject.get("Date Of Cancellation")));
                    dataRes.setItcAvailability(checkNullValue((String) dataObject.get("ITC Availability")));
                    dataRes.setReasonForITCUnavailability(
                                    checkNullValue((String) dataObject.get("Reason for ITC Unavailability")));
                    dataRes.setSourceType(checkNullValue((String) dataObject.get("Source Type")));
                    dataRes.setIrn(checkNullValue((String) dataObject.get("IRN")));
                    dataRes.setIrnGenerationDate(checkNullValue((String) dataObject.get("IRN Generation Date")));
                    dataRes.setSublocation(checkNullValue((String) dataObject.get("Sublocation")));
                    dataRes.setMultiLinkUniqueKey(checkNullValue((String) dataObject.get("Multi-Link Unique key")));

                    getReconciliationTabReportsList.add(dataRes);
                });

                inwardTabVendorCommunicationReportData.put("ReconciliationTabVendorCommunicationReportData",
                                getReconciliationTabReportsList);
                inwardTabVendorCommunicationReportData.put("totalCount", totalCount);
            }

        }

        return inwardTabVendorCommunicationReportData;

    }

    @Override
    @Synchronized
    public Map<String, Object> getEmailStatusDataList(
                    VendorCommunicationEmailStatusReqDTO vendorCommunicationEmailStatusReq, String gstinList,
                    String yearId, String vendorGstin) throws SQLException {
        // vendorCommunicationInwardReq

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        key = reportModuleCommonRepo.getKeyFromKeyHolder();
        String isCustom = reportModuleCommonRepo.getCustomOrDefault(vendorCommunicationEmailStatusReq.getReportId());
        String actionType = "view";

        Map<String, Object> results;
        try {
            results = jdbcTemplateTrn.call(new CallableStatementCreator() {

                @Override
                public CallableStatement createCallableStatement(Connection con) throws SQLException {
                    try {
                        cs = con.prepareCall("{call report_communication_vendor_email_status (?,?,?,?,?,?,?,?,?,?,?)}");

                        cs.setString(1, gstinList);
                        cs.setString(2, yearId);
                        cs.setString(3, vendorCommunicationEmailStatusReq.getRecoType());
                        cs.setString(4, vendorGstin);
                        cs.setString(5, mstDatabseName);
                        cs.setString(6, vendorCommunicationEmailStatusReq.getReportId());
                        cs.setString(7, isCustom);
                        cs.setString(8, vendorCommunicationEmailStatusReq.getUserId());
                        cs.setString(9, actionType);
                        cs.setInt(10, vendorCommunicationEmailStatusReq.getSize());
                        cs.setInt(11, vendorCommunicationEmailStatusReq.getPage()
                                        * vendorCommunicationEmailStatusReq.getSize());
                        callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                        reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                        return cs;
                    } catch (SQLException e) {
                        if (cs != null) {
                            cs.close();
                        }
                        throw e;
                    }
                }
            }, parameters);

            // Process the results object here

        } finally {
            if (cs != null) {
                cs.close();
            }
        }

        Map<String, Object> syncTabVendorInvoceReportData = new HashMap<>();

        List<ReportsVendorCommVendorEmailStatusResDTO> getVendorGstinStatusReportsList = new ArrayList<>();

        if (!results.isEmpty()) {

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> dataList = (List<Map<String, Object>>) results.get(ReportsConstants.RESULT_SET_1);

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> countValue = (List<Map<String, Object>>) results
                            .get(ReportsConstants.RESULT_SET_2);
            Map<String, Object> count11 = countValue.get(0);
            long totalCount = (long) count11.get(ReportsConstants.TOTAL_COUNT);

            dataList.stream().forEach(dataObject -> {

                ReportsVendorCommVendorEmailStatusResDTO dataRes = new ReportsVendorCommVendorEmailStatusResDTO();

                String sentBy = getFirstAndLastName((String) dataObject.get("sentBy"));

                dataRes.setTaxpayerGSTIN(checkNullValue((String) dataObject.get("taxpayerGSTIN")));
                dataRes.setVendorGSTIN(checkNullValue((String) dataObject.get("vendorGSTIN")));
                dataRes.setSentBy(checkNullValue(sentBy));
                dataRes.setSentTo(checkNullValue((String) dataObject.get("sentTo")));
                dataRes.setCcRecipient(checkNullValue((String) dataObject.get("ccRecipient")));
                dataRes.setMailInitiatedTime(checkNullValue((String) dataObject.get("mailInitiatedTime")));
                dataRes.setRecoStatus(checkNullValue((String) dataObject.get("recoStatus")));
                dataRes.setMailStatus(checkNullValue((String) dataObject.get("mailStatus")));

                getVendorGstinStatusReportsList.add(dataRes);
            });

            syncTabVendorInvoceReportData.put("InwardTabVendorCommunicationReportData",
                            getVendorGstinStatusReportsList);
            syncTabVendorInvoceReportData.put("totalCount", totalCount);

        }
        return syncTabVendorInvoceReportData;

    }

    private String getFirstAndLastName(String sentBy) {

        return jdbcTemplateMst.queryForObject(ReportsCommonSql.GET_FIRST_AND_LAST_NAME, String.class, sentBy);

    }

    @Override
    @Async
    @Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
    public void getGenerateBackgroundVendorCommunicationInwardReports(
                    VendorCommunicationInwardReqDTO vendorCommunicationInwardReq, String monthList, String gstinList,
                    Timestamp timeStamp, String containerName, String fileName, Long totalcount, BigInteger id) {
        try {

            getDownloadVendorCommunicationInwardReports(vendorCommunicationInwardReq, monthList, gstinList, timeStamp,
                            containerName, fileName);
            reportModuleCommonRepo.updateBackGroundDetails(
                            reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp), totalcount,
                            ReportsConstants.COMPLETED, fileName, vendorCommunicationInwardReq.getUserId(), timeStamp,
                            id);
            reportModuleCommonRepo.insertDetailsIntoMailBox1(vendorCommunicationInwardReq.getUserId(), fileName,
                            timeStamp);

            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORCOMMUNICATIONMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_COMPLETE,
                            Integer.valueOf(vendorCommunicationInwardReq.getUserId()),
                            Integer.valueOf(vendorCommunicationInwardReq.getUserId()),
                            Integer.valueOf(vendorCommunicationInwardReq.getUserId()),
                            ReportsConstants.NOTIFICATION_SUCCESS);
        } catch (Exception e) {
            reportModuleCommonRepo.updateBackGroundDetails(
                            reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp), totalcount,
                            ReportsConstants.ERROR, fileName, vendorCommunicationInwardReq.getUserId(), timeStamp, id);

            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORCOMMUNICATIONMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_ERROR,
                            Integer.valueOf(vendorCommunicationInwardReq.getUserId()),
                            Integer.valueOf(vendorCommunicationInwardReq.getUserId()),
                            Integer.valueOf(vendorCommunicationInwardReq.getUserId()),
                            ReportsConstants.NOTIFICATION_ERROR);
        }
    }

    @Override
    public Map<String, Object> getDownloadVendorCommunicationInwardReports(
                    VendorCommunicationInwardReqDTO vendorCommunicationInwardReq, String monthList, String gstinList,
                    Timestamp timeStamp, String containerName, String fileName) {

        AzureConnectionCredentialsDTO storageCredentials = reportModuleCommonRepo
                        .getAzureCredentialFromDB(vendorCommunicationInwardReq.getEntityId(), "blob");

        String fileUrl = reportModuleCommonRepo.getFileUrl();

        int templateTypeId = 7;
        String actionType = "export";
        String isCustom = reportModuleCommonRepo.getCustomOrDefault(vendorCommunicationInwardReq.getReportId());
        key = reportModuleCommonRepo.getKeyFromKeyHolder();

        return jdbcTemplateTrn.execute(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {

                if (ReportsConstants.INWARD_REGISTER_REPORT.equals(vendorCommunicationInwardReq.getReportId())
                                || ReportsConstants.CUSTOM_INWARD_REGISTER_REPORT
                                                .equals(vendorCommunicationInwardReq.getReportId())) {
                    cs = con.prepareCall("{call report_communication_inward_register (?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

                } else if (ReportsConstants.CUSTOM_INWARD_ERROR_REPORT
                                .equals(vendorCommunicationInwardReq.getReportId())) {
                    cs = con.prepareCall(
                                    "{ call report_communication_inward_register_error(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                }
                cs.setString(1, gstinList);
                cs.setString(2, monthList);
                cs.setString(3, vendorCommunicationInwardReq.getDocType().toString().replace("[", "").replace("]", "")
                                .replace("{", "").replace("}", "").replace(" ", ""));
                cs.setString(4, vendorCommunicationInwardReq.getSupplyType().toString().replace("[", "")
                                .replace("]", "").replace("{", "").replace("}", "").replace(" ", ""));
                cs.setString(5, vendorCommunicationInwardReq.getSummaryType());
                cs.setString(6, vendorCommunicationInwardReq.getReportId());
                cs.setString(7, mstDatabseName);
                cs.setString(8, isCustom);
                cs.setInt(9, templateTypeId);
                cs.setInt(10, vendorCommunicationInwardReq.getCustomTemplateId());
                cs.setString(11, vendorCommunicationInwardReq.getUserId());
                cs.setString(12, actionType);
                cs.setInt(13, vendorCommunicationInwardReq.getSize());
                cs.setInt(14, vendorCommunicationInwardReq.getSize() * vendorCommunicationInwardReq.getPage());
                callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                return cs;

            }
        }, new CallableStatementCallback<Map<String, Object>>() {

            @Override
            public Map<String, Object> doInCallableStatement(CallableStatement cs) throws SQLException {
                // Execute the stored procedure call
                boolean hasResults = cs.execute();
                ResultSet rs = null;
                ResultSet rs1 = null;
                Map<String, Object> nameAndFile = new HashMap<>();

                if (vendorCommunicationInwardReq.getDownloadType().isBlank()) {
                    vendorCommunicationInwardReq.setDownloadType("xlsx");
                }

                if (hasResults) {

                    rs1 = cs.getResultSet();
                    List<String> reportDetails = new ArrayList<>();

                    while (rs1.next()) {
                        String detail1 = rs1.getString(1);
                        reportDetails.add(detail1);

                    }
                    hasResults = cs.getMoreResults();

                    if (ReportsConstants.EXCEL.equals(vendorCommunicationInwardReq.getDownloadType())) {
                        try (XSSFWorkbook workbook = new XSSFWorkbook()) {

                            rs = cs.getResultSet();

                            // Get the metadata for the result set
                            ResultSetMetaData metadata = rs.getMetaData();
                            int columnCount = metadata.getColumnCount();

                            XSSFSheet sheet = workbook.createSheet(fileName);
                            reportModuleCommonRepo.setFilterAndFredgeHeader(sheet,
                                            new CellRangeAddress(4, 4, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, reportDetails.size() - 1));
                            Map<String, Object> bothHeadersStyles = reportModuleCommonRepo.getHeadersStyles(workbook,
                                            sheet);
                            CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE1);
                            CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE2);
                            CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE3);

                            Row topheader = sheet.createRow(3);
                            Cell cell1 = topheader.createCell(0);
                            cell1.setCellValue(fileName);
                            cell1.setCellStyle(headerCellStyle1);

                            // Create header row
                            Row headerRow = sheet.createRow(4);
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                Cell cell = headerRow.createCell(i - 1);
                                cell.setCellValue(columnName);
                                cell.setCellStyle(headerCellStyle2);
                            }

                            // Process and write rows
                            int rowNum = 5;
                            while (rs.next()) {
                                Row row = sheet.createRow(rowNum);
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    Cell cell = row.createCell(i - 1);
                                    cell.setCellValue(cellValue);
                                    cell.setCellStyle(headerCellStyle3);
                                }
                                rowNum++;
                            }
                            for (int i = 0; i <= columnCount; i++) {
                                sheet.autoSizeColumn(i);
                            }

                            Row searchParameter = sheet.createRow(0);
                            Cell searchParametercell = searchParameter.createCell(0);
                            searchParametercell.setCellValue(greeting);
                            searchParametercell.setCellStyle(headerCellStyle2);
                            Row deatails = sheet.createRow(1);
                            for (int i = 0; i < reportDetails.size(); i++) {

                                Cell cell = deatails.createCell(i);
                                cell.setCellValue(reportDetails.get(i));
                                cell.setCellStyle(headerCellStyle3);

                            }

                            // Write workbook to file
                            try (FileOutputStream out = new FileOutputStream(new File(tempFolder
                                            + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp)))) {
                                workbook.write(out);

                                File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                                + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp));

                                try (InputStream fis = new FileInputStream(file)) {
                                    client.getClient(storageCredentials)
                                                    .blobName(reportModuleCommonRepo.getReportsExcelFileName(fileName,
                                                                    timeStamp))
                                                    .buildClient().upload(fis, file.length());
                                    nameAndFile.put(ReportsConstants.FILENAME, reportModuleCommonRepo
                                                    .getReportsExcelFileName(fileName, timeStamp));
                                    nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                    reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                    return nameAndFile;
                                }

                            }
                        } catch (IOException e) {
                            log.error(errorInGeneratingExcelWorkbook, e);
                        }
                    } else {
                        rs = cs.getResultSet();

                        // Get the metadata for the result set
                        ResultSetMetaData metadata = rs.getMetaData();
                        int columnCount = metadata.getColumnCount();

                        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        try (CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format)) {
                            csvPrinter.printRecord(greeting);
                            csvPrinter.printRecord(reportDetails.toArray());
                            csvPrinter.printRecord();

                            // Create header row
                            String[] headerRow = new String[columnCount];
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                headerRow[i - 1] = columnName;
                            }
                            csvPrinter.printRecord((Object[]) headerRow);

                            while (rs.next()) {
                                String[] rowData = new String[columnCount];
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    rowData[i - 1] = cellValue;
                                }
                                csvPrinter.printRecord((Object[]) rowData);
                            }

                            csvPrinter.flush();

                            InputStream inputStream = new ByteArrayInputStream(out.toByteArray());

                            Files.copy(inputStream, Paths.get(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp)));

                            File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));

                            try (InputStream fis = new FileInputStream(file)) {
                                client.getClient(storageCredentials).blobName(
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp))
                                                .buildClient().upload(fis, file.length());
                                nameAndFile.put(ReportsConstants.FILENAME,
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));
                                nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                return nameAndFile;
                            }
                        } catch (IOException e1) {
                            log.error(errorInGeneratingCSVFile, e1);

                        }
                    }
                }
                return nameAndFile;
            }
        });

    }

    @Override
    @Async
    @Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
    public void getDownloadBackgroundVendorCommReconcilationReport(
                    VendorCommunicationReconciliationReqDTO vendorCommunicationReconciliationReq, String taxpayerGstin,
                    String yearId, String recoStatus, String vendorGstin, Timestamp timeStamp, String containerName,
                    String fileName, String pan, Long totalCount, BigInteger id) {
        try {

            getDownloadVendorCommunicationReconcilationReports(vendorCommunicationReconciliationReq, taxpayerGstin,
                            yearId, recoStatus, vendorGstin, timeStamp, containerName, fileName, pan);
            reportModuleCommonRepo.updateBackGroundDetails(
                            reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp), totalCount,
                            ReportsConstants.COMPLETED, fileName, vendorCommunicationReconciliationReq.getUserId(),
                            timeStamp, id);
            reportModuleCommonRepo.insertDetailsIntoMailBox1(vendorCommunicationReconciliationReq.getUserId(), fileName,
                            timeStamp);

            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORCOMMUNICATIONMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_COMPLETE,
                            Integer.valueOf(vendorCommunicationReconciliationReq.getUserId()),
                            Integer.valueOf(vendorCommunicationReconciliationReq.getUserId()),
                            Integer.valueOf(vendorCommunicationReconciliationReq.getUserId()),
                            ReportsConstants.NOTIFICATION_SUCCESS);

        } catch (Exception e) {
            reportModuleCommonRepo.updateBackGroundDetails(
                            reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp), totalCount,
                            ReportsConstants.ERROR, fileName, vendorCommunicationReconciliationReq.getUserId(),
                            timeStamp, id);
            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORCOMMUNICATIONMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_ERROR,
                            Integer.valueOf(vendorCommunicationReconciliationReq.getUserId()),
                            Integer.valueOf(vendorCommunicationReconciliationReq.getUserId()),
                            Integer.valueOf(vendorCommunicationReconciliationReq.getUserId()),
                            ReportsConstants.NOTIFICATION_ERROR);
        }

    }

    @Override
    public Map<String, Object> getDownloadVendorCommunicationReconcilationReports(
                    VendorCommunicationReconciliationReqDTO vendorCommunicationReconciliationReq, String taxpayerGstin,
                    String yearId, String recoStatus, String vendorGstin, Timestamp timeStamp, String containerName,
                    String fileName, String pan) {

        AzureConnectionCredentialsDTO storageCredentials = reportModuleCommonRepo
                        .getAzureCredentialFromDB(vendorCommunicationReconciliationReq.getEntityId(), "blob");

        String fileUrl = reportModuleCommonRepo.getFileUrl();

        int templateTypeId = 7;
        String actionType = "export";
        String isCustom = reportModuleCommonRepo.getCustomOrDefault(vendorCommunicationReconciliationReq.getReportId());
        key = reportModuleCommonRepo.getKeyFromKeyHolder();

        return jdbcTemplateTrn.execute(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {

                if (ReportsConstants.INWARD_VS_GSTR2A_RECO_REPORT
                                .equals(vendorCommunicationReconciliationReq.getReportId())
                                || ReportsConstants.CUSTOM_INWARD_VS_GSTR2A_RECO_REPORT
                                                .equals(vendorCommunicationReconciliationReq.getReportId())) {
                    cs = con.prepareCall("{call report_communication_reco_inward_gstr2a (?,?,?,?,?,?,?,?,?,?,?,?,?)}");

                } else if (ReportsConstants.INWARD_VS_GSTR2B_RECO_REPORT
                                .equals(vendorCommunicationReconciliationReq.getReportId())
                                || ReportsConstants.CUSTOM_INWARD_VS_GSTR2B_RECO_REPORT
                                                .equals(vendorCommunicationReconciliationReq.getReportId())) {
                    cs = con.prepareCall("{call report_communication_reco_inward_gstr2b (?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                }

                cs.setString(1, pan);
                cs.setString(2, taxpayerGstin);
                cs.setString(3, yearId);
                cs.setString(4, recoStatus);
                cs.setString(5, vendorGstin);
                cs.setString(6, mstDatabseName);
                cs.setString(7, isCustom);
                cs.setInt(8, templateTypeId);
                cs.setInt(9, vendorCommunicationReconciliationReq.getCustomTemplateId());
                cs.setString(10, vendorCommunicationReconciliationReq.getUserId());
                cs.setString(11, actionType);
                cs.setInt(12, vendorCommunicationReconciliationReq.getSize());
                cs.setInt(13, vendorCommunicationReconciliationReq.getPage()
                                * vendorCommunicationReconciliationReq.getSize());
                callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                return cs;

            }
        }, new CallableStatementCallback<Map<String, Object>>() {

            @Override
            public Map<String, Object> doInCallableStatement(CallableStatement cs) throws SQLException {
                // Execute the stored procedure call
                boolean hasResults = cs.execute();
                ResultSet rs = null;
                ResultSet rs1 = null;
                Map<String, Object> nameAndFile = new HashMap<>();

                if (vendorCommunicationReconciliationReq.getDownloadType().isBlank()) {
                    vendorCommunicationReconciliationReq.setDownloadType("xlsx");
                }

                if (hasResults) {

                    rs1 = cs.getResultSet();
                    List<String> reportDetails = new ArrayList<>();

                    while (rs1.next()) {
                        String detail1 = rs1.getString(1);
                        reportDetails.add(detail1);

                    }
                    hasResults = cs.getMoreResults();

                    if (ReportsConstants.EXCEL.equals(vendorCommunicationReconciliationReq.getDownloadType())) {
                        try (XSSFWorkbook workbook = new XSSFWorkbook()) {

                            rs = cs.getResultSet();

                            // Get the metadata for the result set
                            ResultSetMetaData metadata = rs.getMetaData();
                            int columnCount = metadata.getColumnCount();

                            XSSFSheet sheet = workbook.createSheet(fileName);
                            reportModuleCommonRepo.setFilterAndFredgeHeader(sheet,
                                            new CellRangeAddress(4, 4, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, reportDetails.size() - 1));
                            Map<String, Object> bothHeadersStyles = reportModuleCommonRepo.getHeadersStyles(workbook,
                                            sheet);
                            CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE1);
                            CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE2);
                            CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE3);

                            Row topheader = sheet.createRow(3);
                            Cell cell1 = topheader.createCell(0);
                            cell1.setCellValue(fileName);
                            cell1.setCellStyle(headerCellStyle1);

                            // Create header row
                            Row headerRow = sheet.createRow(4);
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                Cell cell = headerRow.createCell(i - 1);
                                cell.setCellValue(columnName);
                                cell.setCellStyle(headerCellStyle2);
                            }

                            // Process and write rows
                            int rowNum = 5;
                            while (rs.next()) {
                                Row row = sheet.createRow(rowNum);
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    Cell cell = row.createCell(i - 1);
                                    cell.setCellValue(cellValue);
                                    cell.setCellStyle(headerCellStyle3);
                                }
                                rowNum++;
                            }
                            for (int i = 0; i <= columnCount; i++) {
                                sheet.autoSizeColumn(i);
                            }

                            Row searchParameter = sheet.createRow(0);
                            Cell searchParametercell = searchParameter.createCell(0);
                            searchParametercell.setCellValue(greeting);
                            searchParametercell.setCellStyle(headerCellStyle2);
                            Row deatails = sheet.createRow(1);
                            for (int i = 0; i < reportDetails.size(); i++) {

                                Cell cell = deatails.createCell(i);
                                cell.setCellValue(reportDetails.get(i));
                                cell.setCellStyle(headerCellStyle3);

                            }

                            // Write workbook to file
                            try (FileOutputStream out = new FileOutputStream(new File(tempFolder
                                            + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp)))) {
                                workbook.write(out);

                                File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                                + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp));

                                try (InputStream fis = new FileInputStream(file)) {
                                    client.getClient(storageCredentials)
                                                    .blobName(reportModuleCommonRepo.getReportsExcelFileName(fileName,
                                                                    timeStamp))
                                                    .buildClient().upload(fis, file.length());
                                    nameAndFile.put(ReportsConstants.FILENAME, reportModuleCommonRepo
                                                    .getReportsExcelFileName(fileName, timeStamp));
                                    nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                    reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                    return nameAndFile;
                                }

                            }
                        } catch (IOException e) {
                            log.error(errorInGeneratingExcelWorkbook, e);
                        }
                    } else {
                        rs = cs.getResultSet();

                        // Get the metadata for the result set
                        ResultSetMetaData metadata = rs.getMetaData();
                        int columnCount = metadata.getColumnCount();

                        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        try (CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format)) {
                            csvPrinter.printRecord(greeting);
                            csvPrinter.printRecord(reportDetails.toArray());
                            csvPrinter.printRecord();

                            // Create header row
                            String[] headerRow = new String[columnCount];
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                headerRow[i - 1] = columnName;
                            }
                            csvPrinter.printRecord((Object[]) headerRow);

                            while (rs.next()) {
                                String[] rowData = new String[columnCount];
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    rowData[i - 1] = cellValue;
                                }
                                csvPrinter.printRecord((Object[]) rowData);
                            }

                            csvPrinter.flush();

                            InputStream inputStream = new ByteArrayInputStream(out.toByteArray());

                            Files.copy(inputStream, Paths.get(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp)));

                            File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));

                            try (InputStream fis = new FileInputStream(file)) {
                                client.getClient(storageCredentials).blobName(
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp))
                                                .buildClient().upload(fis, file.length());
                                nameAndFile.put(ReportsConstants.FILENAME,
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));
                                nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                return nameAndFile;
                            }
                        } catch (IOException e1) {
                            log.error(errorInGeneratingCSVFile, e1);

                        }
                    }
                }
                return nameAndFile;
            }
        });
    }

    @Override
    public Map<String, Object> getDownloadEmailStatusReports(
                    VendorCommunicationEmailStatusReqDTO vendorCommunicationEmailStatusReq, String gstinList,
                    String yearId, String vendorGstin, Timestamp timeStamp, String containerName, String fileName) {

        AzureConnectionCredentialsDTO storageCredentials = reportModuleCommonRepo
                        .getAzureCredentialFromDB(vendorCommunicationEmailStatusReq.getEntityId(), "blob");

        String fileUrl = reportModuleCommonRepo.getFileUrl();

        String actionType = "export";
        String isCustom = reportModuleCommonRepo.getCustomOrDefault(vendorCommunicationEmailStatusReq.getReportId());
        key = reportModuleCommonRepo.getKeyFromKeyHolder();

        return jdbcTemplateTrn.execute(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {

                cs = con.prepareCall("{call report_communication_vendor_email_status (?,?,?,?,?,?,?,?,?,?,?)}");

                cs.setString(1, gstinList);
                cs.setString(2, yearId);
                cs.setString(3, vendorCommunicationEmailStatusReq.getRecoType());
                cs.setString(4, vendorGstin);
                cs.setString(5, mstDatabseName);
                cs.setString(6, vendorCommunicationEmailStatusReq.getReportId());
                cs.setString(7, isCustom);
                cs.setString(8, vendorCommunicationEmailStatusReq.getUserId());
                cs.setString(9, actionType);
                cs.setInt(10, vendorCommunicationEmailStatusReq.getSize());
                cs.setInt(11, vendorCommunicationEmailStatusReq.getPage()
                                * vendorCommunicationEmailStatusReq.getSize());
                callStatement = cs.toString().replaceFirst(ReportsConstants.CALLSTATEMENT_REGEX, "");
                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                return cs;

            }
        }, new CallableStatementCallback<Map<String, Object>>() {

            @Override
            public Map<String, Object> doInCallableStatement(CallableStatement cs) throws SQLException {
                // Execute the stored procedure call
                boolean hasResults = cs.execute();
                ResultSet rs = null;
                ResultSet rs1 = null;
                Map<String, Object> nameAndFile = new HashMap<>();

                if (vendorCommunicationEmailStatusReq.getDownloadType().isBlank()) {
                    vendorCommunicationEmailStatusReq.setDownloadType("xlsx");
                }

                if (hasResults) {

                    rs1 = cs.getResultSet();
                    List<String> reportDetails = new ArrayList<>();

                    while (rs1.next()) {
                        String detail1 = rs1.getString(1);
                        reportDetails.add(detail1);

                    }
                    hasResults = cs.getMoreResults();

                    if (ReportsConstants.EXCEL.equals(vendorCommunicationEmailStatusReq.getDownloadType())) {
                        try (XSSFWorkbook workbook = new XSSFWorkbook()) {

                            rs = cs.getResultSet();

                            // Get the metadata for the result set
                            ResultSetMetaData metadata = rs.getMetaData();
                            int columnCount = metadata.getColumnCount();

                            XSSFSheet sheet = workbook.createSheet(fileName);
                            reportModuleCommonRepo.setFilterAndFredgeHeader(sheet,
                                            new CellRangeAddress(4, 4, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, columnCount - 1));
                            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, reportDetails.size() - 1));
                            Map<String, Object> bothHeadersStyles = reportModuleCommonRepo.getHeadersStyles(workbook,
                                            sheet);
                            CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE1);
                            CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE2);
                            CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles
                                            .get(ReportsConstants.HEADERCELLSTYLE3);

                            Row topheader = sheet.createRow(3);
                            Cell cell1 = topheader.createCell(0);
                            cell1.setCellValue(fileName);
                            cell1.setCellStyle(headerCellStyle1);

                            // Create header row
                            Row headerRow = sheet.createRow(4);
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                Cell cell = headerRow.createCell(i - 1);
                                cell.setCellValue(columnName);
                                cell.setCellStyle(headerCellStyle2);
                            }

                            // Process and write rows
                            int rowNum = 5;
                            while (rs.next()) {
                                Row row = sheet.createRow(rowNum);
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    Cell cell = row.createCell(i - 1);
                                    cell.setCellValue(cellValue);
                                    cell.setCellStyle(headerCellStyle3);
                                }
                                rowNum++;
                            }
                            for (int i = 0; i <= columnCount; i++) {
                                sheet.autoSizeColumn(i);
                            }

                            Row searchParameter = sheet.createRow(0);
                            Cell searchParametercell = searchParameter.createCell(0);
                            searchParametercell.setCellValue(greeting);
                            searchParametercell.setCellStyle(headerCellStyle2);
                            Row deatails = sheet.createRow(1);
                            for (int i = 0; i < reportDetails.size(); i++) {

                                Cell cell = deatails.createCell(i);
                                cell.setCellValue(reportDetails.get(i));
                                cell.setCellStyle(headerCellStyle3);

                            }

                            // Write workbook to file
                            try (FileOutputStream out = new FileOutputStream(new File(tempFolder
                                            + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp)))) {
                                workbook.write(out);

                                File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                                + reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp));

                                try (InputStream fis = new FileInputStream(file)) {
                                    client.getClient(storageCredentials)
                                                    .blobName(reportModuleCommonRepo.getReportsExcelFileName(fileName,
                                                                    timeStamp))
                                                    .buildClient().upload(fis, file.length());
                                    nameAndFile.put(ReportsConstants.FILENAME, reportModuleCommonRepo
                                                    .getReportsExcelFileName(fileName, timeStamp));
                                    nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                    reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                    return nameAndFile;
                                }

                            }
                        } catch (IOException e) {
                            log.error(errorInGeneratingExcelWorkbook, e);
                        }
                    } else {
                        rs = cs.getResultSet();

                        // Get the metadata for the result set
                        ResultSetMetaData metadata = rs.getMetaData();
                        int columnCount = metadata.getColumnCount();

                        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        try (CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format)) {
                            csvPrinter.printRecord(greeting);
                            csvPrinter.printRecord(reportDetails.toArray());
                            csvPrinter.printRecord();

                            // Create header row
                            String[] headerRow = new String[columnCount];
                            for (int i = 1; i <= columnCount; i++) {
                                String columnName = metadata.getColumnLabel(i);
                                headerRow[i - 1] = columnName;
                            }
                            csvPrinter.printRecord((Object[]) headerRow);

                            while (rs.next()) {
                                String[] rowData = new String[columnCount];
                                for (int i = 1; i <= columnCount; i++) {
                                    String cellValue = rs.getString(i);
                                    rowData[i - 1] = cellValue;
                                }
                                csvPrinter.printRecord((Object[]) rowData);
                            }

                            csvPrinter.flush();

                            InputStream inputStream = new ByteArrayInputStream(out.toByteArray());

                            Files.copy(inputStream, Paths.get(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp)));

                            File file = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                            + reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));

                            try (InputStream fis = new FileInputStream(file)) {
                                client.getClient(storageCredentials).blobName(
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp))
                                                .buildClient().upload(fis, file.length());
                                nameAndFile.put(ReportsConstants.FILENAME,
                                                reportModuleCommonRepo.getReportsCsvFileName(fileName, timeStamp));
                                nameAndFile.put(ReportsConstants.FILEURL, fileUrl + "/" + containerName);
                                reportModuleCommonRepo.getUpdateLogProcExecution(callStatement, key);
                                return nameAndFile;
                            }
                        } catch (IOException e1) {
                            log.error(errorInGeneratingCSVFile, e1);

                        }
                    }
                }
                return nameAndFile;
            }
        });

    }

    @Override
    @Async
    @Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
    public void getDownloadBackgroundEmailStatusReport(
                    VendorCommunicationEmailStatusReqDTO vendorCommunicationEmailStatusReq, String gstinList,
                    String yearId, String vendorGstin, Timestamp timeStamp, String containerName, String fileName,
                    Long totalCount, BigInteger id) {
        try {

            getDownloadEmailStatusReports(vendorCommunicationEmailStatusReq, gstinList, yearId, vendorGstin, timeStamp,
                            containerName, fileName);
            reportModuleCommonRepo.updateBackGroundDetails(
                            reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp), totalCount,
                            ReportsConstants.COMPLETED, fileName, vendorCommunicationEmailStatusReq.getUserId(),
                            timeStamp, id);
            reportModuleCommonRepo.insertDetailsIntoMailBox1(vendorCommunicationEmailStatusReq.getUserId(), fileName,
                            timeStamp);
            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORCOMMUNICATIONMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_COMPLETE,
                            Integer.valueOf(vendorCommunicationEmailStatusReq.getUserId()),
                            Integer.valueOf(vendorCommunicationEmailStatusReq.getUserId()),
                            Integer.valueOf(vendorCommunicationEmailStatusReq.getUserId()),
                            ReportsConstants.NOTIFICATION_SUCCESS);

        } catch (Exception e) {
            reportModuleCommonRepo.updateBackGroundDetails(
                            reportModuleCommonRepo.getReportsExcelFileName(fileName, timeStamp), totalCount,
                            ReportsConstants.ERROR, fileName, vendorCommunicationEmailStatusReq.getUserId(), timeStamp,
                            id);
            reportModuleCommonRepo.commonPostNotification(ReportsConstants.VENDORCOMMUNICATIONMODULEID,
                            fileName + ReportsConstants.BACKGROUNG_ERROR,
                            Integer.valueOf(vendorCommunicationEmailStatusReq.getUserId()),
                            Integer.valueOf(vendorCommunicationEmailStatusReq.getUserId()),
                            Integer.valueOf(vendorCommunicationEmailStatusReq.getUserId()),
                            ReportsConstants.NOTIFICATION_ERROR);
        }
    }

}
