package com.bdo.bvms.common.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DefaultEmailTemplateResDTO {

	private String subject;
	private String mailBody;
	private String templateName;
	
}
