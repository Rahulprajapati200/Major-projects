package com.bdo.bvms.common.reports.dao;

import java.math.BigInteger;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.ReportsCustomColumnsDTO;
import com.bdo.bvms.common.dto.VendorInvoiceGetReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceInputReportsReqDTO;
import com.bdo.bvms.common.dto.VendorInvoiceSyncReqDTO;

public interface ReportsVendorInvoiceRepo {

    Map<String, Object> getInputReportsResList(VendorInvoiceInputReportsReqDTO vendorInvoiceInputReportsReqDTO,
                    String gstinList, String pan, String yearOrMonthList) throws SQLException;

    List<ReportsCustomColumnsDTO> getCustomizeColumns(String reportId, String userId);

    Map<String, Object> getVendorInvoiceGETReportsResList(String gstinOrPan, String gstinList, String yearId,
                    String monthList, String reportId, String category, String summaryType, int size, int page,
                    String userId) throws SQLException;

    Map<String, Object> getSyncDataList(VendorInvoiceSyncReqDTO vendorInvoiceSyncReq, String gstinList,
                    String vendorGstinList, String yearOrMonthList, String category) throws SQLException;

    Map<String, Object> getGenerateExcelOrCsvFileofEInvoiceInputReports(
                    VendorInvoiceInputReportsReqDTO vendorInvoiceInputReportsReq, String string, String pan,
                    String yearOrMonthList, Timestamp timeStamp, String containerName, String fileName);

    void getGenerateBackgroundVendorInvoiceInputReports(VendorInvoiceInputReportsReqDTO vendorInvoiceInputReportsReq,
                    String gstinList, String pan, String yearOrMonthList, Timestamp timeStamp, String containerName,
                    String fileName, Long totalCount, BigInteger id);

    Map<String, Object> getGenerateExcelOrCsvFileofVendorInvoiceGetReports(
                    VendorInvoiceGetReqDTO vendorInvoiceGETReportsReq, String gstinList1, String yearOrMonthList,
                    String category, Timestamp timeStamp, String containerName, String fileName);

    void getGenerateBackgroundVendorInvoiceGetReports(VendorInvoiceGetReqDTO vendorInvoiceGETReportsReq,
                    String gstinList1, String yearOrMonthList, String category, Timestamp timeStamp,
                    String containerName, String fileName, Long long1, BigInteger id);

    Map<String, Object> getGenerateExcelOrCsvFileofVendorInvoiceSyncReports(
                    VendorInvoiceSyncReqDTO vendorInvoiceSyncReq, String taxPayerGstinList, String vendorGstinList,
                    String yearOrMonthList, String category, Timestamp timeStamp, String containerName,
                    String fileName);

    void getGenerateBackgroundExcelOrCsvFileofVendorInvoiceSyncReports(VendorInvoiceSyncReqDTO vendorInvoiceSyncReq,
                    String taxPayerGstinList, String vendorGstinList, String yearOrMonthList, String category,
                    Timestamp timeStamp, String containerName, String fileName, Long long1, BigInteger id);

}
