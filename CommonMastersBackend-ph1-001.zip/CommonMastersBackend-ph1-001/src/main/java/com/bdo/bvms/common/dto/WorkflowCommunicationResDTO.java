package com.bdo.bvms.common.dto;

import com.bdo.bvms.common.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class WorkflowCommunicationResDTO {

    Integer id;
    Integer isVendor;
    String subject;
    String body;
    Integer isNewCommunication;
    String postFrom;
    Integer parentId;
    Integer workflowMstId;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI)
    String createdAt;
    String postTo;
    Integer totalComments;
    String commentType;

}
