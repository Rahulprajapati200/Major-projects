package com.bdo.bvms.common.controller.impl;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.controller.CommonMasterController;
import com.bdo.bvms.common.dto.APIResponseDTO;
import com.bdo.bvms.common.dto.AddWorkflowCommunicationReqDTO;
import com.bdo.bvms.common.dto.AdvanceSearchReqDto;
import com.bdo.bvms.common.dto.DownloadFileDTO;
import com.bdo.bvms.common.dto.ErrorMessageListDto;
import com.bdo.bvms.common.dto.FinancialYearReqDTO;
import com.bdo.bvms.common.dto.GetCustomizedColumnListReqDTO;
import com.bdo.bvms.common.dto.GetDefaultUploadTemplateReqDTO;
import com.bdo.bvms.common.dto.GetDefaultUploadTemplateResDTO;
import com.bdo.bvms.common.dto.GetFpByYearIdReqDTO;
import com.bdo.bvms.common.dto.GetFpByYearIdResDTO;
import com.bdo.bvms.common.dto.PaginationResDTO;
import com.bdo.bvms.common.dto.PaginationSearchResponseDTO;
import com.bdo.bvms.common.dto.PickupDetailListResDTO;
import com.bdo.bvms.common.dto.PreviewInvoiceUploadDTO;
import com.bdo.bvms.common.dto.SaveCustomizeColumnListReqDTO;
import com.bdo.bvms.common.dto.SearchByLkupcodeReqDTO;
import com.bdo.bvms.common.dto.SearchPLDByPickKey;
import com.bdo.bvms.common.dto.SearchWorkflowCommunicationReqDTO;
import com.bdo.bvms.common.exceptions.BVMSException;
import com.bdo.bvms.common.service.CommonEmptyTemplateService;
import com.bdo.bvms.common.service.CommonMasterService;

/**
 * The Class CommonMasterControllerImpl.
 */

@RestController
@RequestMapping("/common")

/** The Constant log. */

public class CommonMasterControllerImpl implements CommonMasterController {

    /** The common master service. */
    @Autowired
    CommonMasterService commonMasterService;

    /** The common empty template service. */
    @Autowired
    CommonEmptyTemplateService commonEmptyTemplateService;

    /**
     * Gets the FP months.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param financialYearReqDTO
     *            the financial year req DTO
     * @return the FP months
     * @throws BVMSException
     */
    @PostMapping(value = "/get-fp-months", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> getFPMonths(HttpServletRequest httpServletRequest,
                    @RequestBody FinancialYearReqDTO financialYearReqDTO) throws BVMSException {

        PaginationSearchResponseDTO paginationSearchResponseDTO = commonMasterService.getFpMonths(financialYearReqDTO);

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(paginationSearchResponseDTO)
                        .message("Search fp months successfully").tag(httpServletRequest.getRequestURI()).build());

    }

    /**
     * Gets the FP year.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param financialYearReqDTO
     *            the financial year req DTO
     * @return the FP year
     * @throws BVMSException
     */
    @PostMapping(value = "/get-fp-year", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> getFPYear(HttpServletRequest httpServletRequest,
                    @RequestBody FinancialYearReqDTO financialYearReqDTO) throws BVMSException {

        PaginationSearchResponseDTO paginationSearchResponseDTO = commonMasterService.getFpYear(financialYearReqDTO);

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(paginationSearchResponseDTO)
                        .message("Search fp year successfully").tag(httpServletRequest.getRequestURI()).build());

    }

    /**
     * Download file byte stream.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param downloadFileBytestreamDto
     *            the download file bytestream dto
     * @return the response entity
     * @throws IOException
     * @throws BVMSException
     */
    @Override
    @PostMapping("/download-template")
    public ResponseEntity<Resource> downloadFileByteStream(HttpServletRequest httpServletRequest,
                    @RequestBody DownloadFileDTO downloadFileBytestreamDto) throws BVMSException, IOException {

        Map<String, Object> headerAndFile = commonEmptyTemplateService.getHeaderAndFile(downloadFileBytestreamDto);

        return ResponseEntity.ok().headers((HttpHeaders) headerAndFile.get(Constants.HEADERS))
                        .contentType(MediaType.parseMediaType(
                                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                        .body((InputStreamResource) headerAndFile.get(Constants.FILE));

    }

    /**
     * Search pickup list detail.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param searchByLkupcode
     *            the search by lkupcode
     * @return the response entity
     */
    @PostMapping(value = "/searchPickupListDetail")
    public ResponseEntity<APIResponseDTO> searchPickupListDetail(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid SearchByLkupcodeReqDTO searchByLkupcode) {
        List<PickupDetailListResDTO> pickupMasterResDTOList = commonMasterService
                        .searchPickupListDetail(searchByLkupcode);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(pickupMasterResDTOList)
                                        .message("Got pickup master data successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

    /**
     * Gets the default upload template.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param getDefaultUploadTemplateReqDTO
     *            the get default upload template req DTO
     * @return the default upload template
     */
    @PostMapping(value = "/getDefaultUploadTemplate")
    public ResponseEntity<APIResponseDTO> getDefaultUploadTemplate(HttpServletRequest httpServletRequest,
                    @RequestBody GetDefaultUploadTemplateReqDTO getDefaultUploadTemplateReqDTO) {
        List<GetDefaultUploadTemplateResDTO> getDefaultUploadTemplateResDTO = commonMasterService
                        .getDefaultUploadTemplate(getDefaultUploadTemplateReqDTO);
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(getDefaultUploadTemplateResDTO)
                        .message("Search fp year successfully").tag(httpServletRequest.getRequestURI()).build());

    }

    /**
     * Search BVMS error mappings.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param searchByLkupcode
     *            the search by lkupcode
     * @return the response entity
     */
    @PostMapping(value = "/searchBvmsErrorMappings")
    public ResponseEntity<APIResponseDTO> searchBvmsErrorMappings(HttpServletRequest httpServletRequest,
                    @RequestBody SearchByLkupcodeReqDTO searchByLkupcode) {
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1)
                                        .data(Stream.of(commonMasterService.searchBvmsErrorMappings()))
                                        .message("Search bvms error code mappings successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());

    }

    /**
     * Preview invoice upload.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param previewInvoiceUploadDTO
     *            the preview invoice upload DTO
     * @return the response entity
     */
    @PostMapping(value = "/previewInvoiceUpload")
    public ResponseEntity<APIResponseDTO> previewInvoiceUpload(HttpServletRequest httpServletRequest,
                    @RequestBody PreviewInvoiceUploadDTO previewInvoiceUploadDTO) {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(Stream.of(commonMasterService.getFileInfo(previewInvoiceUploadDTO)))
                        .message("Response received successfully").tag(httpServletRequest.getRequestURI()).build());

    }

    /**
     * Gets the fp by year id.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param fpByYearIdReqDTO
     *            the fp by year id req DTO
     * @return the fp by year id
     */
    @PostMapping(value = "/get-fp-by-yearid")
    public ResponseEntity<APIResponseDTO> getFpByYearId(HttpServletRequest httpServletRequest,
                    @RequestBody GetFpByYearIdReqDTO fpByYearIdReqDTO) {
        List<GetFpByYearIdResDTO> getFpByYearIdResDTOList = commonMasterService.getFpByYearId(fpByYearIdReqDTO);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(getFpByYearIdResDTOList)
                                        .message("fp list by year Id is uploaded successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/get-customized-column-list")
    public ResponseEntity<APIResponseDTO> getCustomizedColumnList(HttpServletRequest httpServletRequest,
                    @RequestBody GetCustomizedColumnListReqDTO getSaveCustomizedColumnListReqDTO) {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(commonMasterService.getCustomizedColumnListFromService(getSaveCustomizedColumnListReqDTO))
                        .message(" Get customized column list is uploaded successfully")
                        .tag(httpServletRequest.getRequestURI()).build());
    }

    @PostMapping(value = "/save-customized-column-list")
    public ResponseEntity<APIResponseDTO> getSavedCustomizedColumnList(HttpServletRequest httpServletRequest,
                    @RequestBody SaveCustomizeColumnListReqDTO saveCustomizeColumnListReqDTO) {
        commonMasterService.getSavedCustomizedColumnListFromService(saveCustomizeColumnListReqDTO);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(null)
                                        .message("  Customized column list saved successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

    @PostMapping(value = "/searchPickupListDetailByPickKey")
    public ResponseEntity<APIResponseDTO> searchPickupListDetailByPickKey(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid SearchPLDByPickKey searchPLDByPickKey) {
        List<PickupDetailListResDTO> pickupMasterResDTOList = commonMasterService
                        .searchPickupListDetailByPickKey(searchPLDByPickKey);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(pickupMasterResDTOList)
                                        .message("Got pickup master data successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

    @PostMapping(value = "/addWorkflowCommunication")
    public ResponseEntity<APIResponseDTO> addWorkflowCommunication(HttpServletRequest httpServletRequest,
                    @RequestBody AddWorkflowCommunicationReqDTO addWorkflowCommunicationReqDTO) throws BVMSException {

        commonMasterService.addWorkflowCommunication(addWorkflowCommunicationReqDTO);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1).data(Collections.emptyList())
                                        .message("Comment added successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());

    }

    @PostMapping(value = "/searchWorkflowCommunication")
    public ResponseEntity<APIResponseDTO> searchWorkflowCommunication(HttpServletRequest httpServletRequest,
                    @RequestBody SearchWorkflowCommunicationReqDTO searchWorkflowCommunicationReqDTO) {

        PaginationResDTO paginationResDTO = commonMasterService
                        .searchWorkflowCommunication(searchWorkflowCommunicationReqDTO);
        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1)
                                        .data(Stream.of(paginationResDTO).collect(Collectors.toList()))
                                        .message("Got workflow communication successfully")
                                        .tag(httpServletRequest.getRequestURI()).build());
    }

    @PostMapping(value = "/upload-error-messagelist")
    public ResponseEntity<APIResponseDTO> getUploadMessageList(HttpServletRequest httpServletRequest,
                    @RequestBody ErrorMessageListDto errorMessageListDto) {

        return ResponseEntity.ok()
                        .body(APIResponseDTO.builder().status(1)
                                        .data((commonMasterService.getErrorDescriptionList(errorMessageListDto)))
                                        .message("Got Error Message successfully").build());

    }
    
    @PostMapping(value="/get-field-names")
    public ResponseEntity<APIResponseDTO> getFieldName(@RequestBody AdvanceSearchReqDto advanceSearchReqDto)
    {
		return ResponseEntity.ok()
				.body(APIResponseDTO.builder().data(commonMasterService.getFieldNames(advanceSearchReqDto)).message("Got Data Successfully").status(1).build());
    	
    }

}
