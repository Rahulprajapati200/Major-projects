package com.bdo.bvms.common.dto;


import java.io.Serializable;
import java.util.Date;

import com.bdo.bvms.common.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level=AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL) 	//  ignore all null fields
public class SearchTemplateTypeResDTO implements Serializable {

    private static final long serialVersionUID = 1L;
   
    Integer id;
    String uploadedBy;
    String name;    
    Integer code;        
    String shortDesc;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI)
    Date uploadedOn;
    String mandatoryColumns;
}
