package com.bdo.bvms.common.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DateUtil {

    public DateUtil() {
        super();
    }

    public static final String DATEFORMATTERFORUI = "dd-MM-yyyy";
    public static final String DATETIMEFORMATTERFORUI = "dd-MM-yyyy HH:mm:ss";

    public static final String DATETIMEFORMATTERFORDB = "yyyy-MM-dd HH:mm:ss";
    public static final String DATEFORMATTERFORDB = "yyyy-MM-dd";

    public static String convertDateToString(Date date, String formatter) {
        if (date == null || StringUtils.isAllBlank(formatter)) {
            return null;
        }

        // Converts the string
        // format to date object
        DateFormat df = new SimpleDateFormat(formatter);

        // Convert the date into a
        // string using format() method
        String dateToString = df.format(date);

        // Return the result
        return (dateToString);
    }

    public static String convertDBtoScreen(String strdate) {
        if (strdate == null) {
            return "-";
        }
        if (StringUtils.isNoneBlank(strdate)) {
            SimpleDateFormat fromFormatter = new SimpleDateFormat(DATETIMEFORMATTERFORDB);
            SimpleDateFormat toFormatter = new SimpleDateFormat(DATETIMEFORMATTERFORUI);
            try {
                Date date = fromFormatter.parse(strdate);
                return toFormatter.format(date);
            } catch (ParseException ex) {
                log.error("Error occured while execute convertDBtoScreen function:", ex);
                return strdate;
            }
        } else {
            return strdate;
        }

    }

    public static String convertLocalDateTimeIntoStringFormat(LocalDateTime strdate1) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATETIMEFORMATTERFORDB);
        if (strdate1 == null) {
            return "-";
        }

        String strdate = strdate1.format(formatter);
        if (StringUtils.isNoneBlank(strdate)) {
            SimpleDateFormat fromFormatter = new SimpleDateFormat(DATETIMEFORMATTERFORDB);
            SimpleDateFormat toFormatter = new SimpleDateFormat(DATETIMEFORMATTERFORUI);
            try {
                Date date = fromFormatter.parse(strdate);
                return toFormatter.format(date);
            } catch (ParseException ex) {
                log.error("Error occured while execute convertDBtoScreen function:", ex);
                return strdate;
            }
        } else {
            return strdate;
        }
    }

    public static String convertTimestampIntoStringFormat(Timestamp timestamp) {

        if (timestamp == null) {
            return "-";
        }

        SimpleDateFormat toFormatter = new SimpleDateFormat(DATETIMEFORMATTERFORUI);
        return toFormatter.format(timestamp);
    }

}