package com.bdo.bvms.common.constant;


public final class ValidationConstant {
	
	ValidationConstant(){
		
	}
	
    public static final String GSTIN_PATTERN = "^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$";
    
    public static final String EMAIL_ID_PATTERN = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}";
    
    public static final String PAN_PATTERN = "[A-Z]{5}[0-9]{4}[A-Z]{1}";

    public static final String MOBILE_PATTERN ="[0-9]{10}";

    public static final String EMAIL_PATTERN = "^(.+)@(\\S+)$";

    public static final String BANK_IFSC_PATTERN = "^[A-Z]{4}0[A-Z0-9]{6}$";


    public static final String PINCODE_PATTERN = "[0-9]{6}";

    public static final int GSTIN_MIN_SIZE = 15;

    public static final int GSTIN_MAX_SIZE = 15;

    public static final int PAN_MIN_SIZE = 10;

    public static final int PAN_MAX_SIZE = 10;

    public static final int MOBILE_MIN_SIZE = 10;

    public static final int MOBILE_MAX_SIZE = 10;

    public static final int AADHAR_MIN_SIZE = 12;

    public static final int AADHAR_MAX_SIZE = 12;

    public static final int PINCODE_MIN_SIZE = 0;

    public static final int PINCODE_MAX_SIZE = 999999;


    // ***********************BANK DETAILS LENGTH VALIDATION


    public static final int BANKNAME_MIN_SIZE = 1;

    public static final int BANKNAME_MAX_SIZE = 50;

    public static final int BANK_ACCOUNT_HOLDER_NAME_MIN_SIZE = 1;

    public static final int BANK_ACCOUNT_HOLDER_NAME_MAX_SIZE = 50;

    public static final int BANK_ACCOUNT_NO_MIN_SIZE = 9;

    public static final int BANK_ACCOUNT_NO_MAX_SIZE = 18;

    public static final int BANK_IFSC_MIN_SIZE = 11;

    public static final int BANK_IFSC_MAX_SIZE = 11;

    public static final int BANK_ADDRESS_MIN_SIZE = 1;

    public static final int BANK_ADDRESS_MAX_SIZE = 50;


    //********************************ADDRESS LENGTH VALIDATIONS*****************


    public static final int ADDRESS_TYPE_MAX_SIZE = 5;

    public static final int ADDRESS_TYPE_MIN_SIZE = 1;

    public static final int ADDRESS_LINE1_MAX_SIZE = 100;

    public static final int ADDRESS_LINE1_MIN_SIZE = 1;

    public static final int PLACE_MAX_SIZE = 100;

    public static final int PLACE_MIN_SIZE = 1;


    //********************************CONTACT LENGTH VALIDATIONS******************

    public static final int FIRST_NAME_MIN_SIZE = 1;

    public static final int FIRST_NAME_MAX_SIZE = 25;

    public static final int LAST_NAME_MIN_SIZE = 1;

    public static final int LAST_NAME_MAX_SIZE = 25;
    
    public static final int EMAIL_COND_MIN_SIZE = 0;

    public static final int EMAIL_MIN_SIZE = 1;

    public static final int EMAIL_MAX_SIZE = 320;


    //********************************MASTER UPDATE VALIDATIONS******************

    public static final int LEGAL_NAME_OF_BUSINESS_MIN_SIZE = 1;

    public static final int LEGAL_NAME_OF_BUSINESS_MAX_SIZE = 200;

    public static final int TRADE_NAME_OF_BUSINESS_MIN_SIZE = 1;

    public static final int TRADE_NAME_OF_BUSINESS_MAX_SIZE = 200;

    public static final int VENDOR_CODE_MIN_SIZE = 1;

    public static final int VENDOR_CODE_MAX_SIZE = 40;

    public static final Long VENDOR_UPLOAD_FILE_MIN_SIZE = 10000l;


    public static String generateNullOrEmptyMsg(String fieldName) {
        return fieldName;
    }
    
    public static final int UPLOAD_LOG_FILE_TYPE_MIN = 0;
    
    public static final int UPLOAD_LOG_FILE_TYPE_MAX = 1;
    
    public static final int CUSTOM_TEMPLATE_NAME_MIN = 1;
    
    public static final int CUSTOM_TEMPLATE_NAME_MAX = 100;

}
