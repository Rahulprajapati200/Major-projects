package com.bdo.bvms.common.reports.constants;

public class ReportsConstants {

    public static final String PAN = "0";
    public static final String GSTIN = "1";
    public static final String YEAR = "0";
    public static final String MONTH = "1";

    public static final String VENDOR_CODE_ERP = "Vendor Code Erp";
    public static final String GSTIN_VENDOR = "Vendor GSTIN";
    public static final String COMPANY_LEGAL_NAME = "Company Legal Name";
    public static final String COMPANY_TRADE_NAME = "Company Trade Name";
    public static final String PAN_VENDOR = "Pan Vendor";
    public static final String AADHAR_VENDOR = "Aadhar Vendor";
    public static final String FIRST_NAME = "First Name";
    public static final String LAST_NAME = "Last Name";
    public static final String MOBILE = "Mobile";
    public static final String EMAIL = "E-mail";
    public static final String IS_PRIMARY_CONTACT = "Is Primary Contact";
    public static final String ADDRESS_TYPE = "Address Type";
    public static final String IS_DEFAULT_ADDRESS = "Is Default Address";
    public static final String ADDRESS1 = "Address1";
    public static final String ADDRESS2 = "Address2";
    public static final String PLACE = "Place";
    public static final String PIN_CODE = "Pin Code";
    public static final String BANK_NAME = "Bank Name";
    public static final String BANK_ADDRESS = "Bank Address";
    public static final String ACCOUNT_HOLDER_NAME = "Account Holder Name";
    public static final String ACCOUNT_NUMBER = "Account Number";
    public static final String IFSC_CODE = "IFSC Code";
    public static final String IS_PRIMARY_BANK = "Is Primary Bank";
    public static final String PRIMARY_UPI = "Primary Upi";
    public static final String SECONDARY_UPI = "Secondary Upi";
    public static final String MODIFIED_AT = "Modified At";
    public static final String FIELD1 = "Field1";
    public static final String FIELD2 = "Field2";
    public static final String FIELD3 = "Field3";
    public static final String FIELD4 = "Field4";
    public static final String FIELD5 = "Field5";
    public static final String FIELD6 = "Field6";
    public static final String FIELD7 = "Field7";
    public static final String FIELD8 = "Field8";
    public static final String FIELD9 = "Field9";
    public static final String FIELD10 = "Field10";

    public static final String VENDOR_MASTER_TAXPAYER_REGISTER_REPORT = "VM101";
    public static final String VENDOR_MASTER_GSTIN_REGISTER_REPORT = "VM102";
    public static final String VENDOR_MASTER_AS_PER_VENDOR_REGISTER_REPORT = "VM103";
    public static final String VENDOR_MASTER_COMBINED_REGISTER_REPORT = "VM104";
    public static final String VENDOR_FILING_DETAILS_REPORT = "VM105";
    public static final String SEND_INVITES_LIST_REPORT = "VM106";
    public static final String EXCEL = "xlsx";
    public static final String CSV = "csv";
    public static final String DATE_INVITE_SEND = "Date Invite Send";
    public static final String INVITE_SEND_BY_USER = "Invite Send By User";
    public static final String VENDOR_CONTACT_EMAIL = "Vendor Contact E-mail";
    public static final String VENDOR_CONTACT_NAME = "Vendor Contact Name";
    public static final String VENDOR_INVITE_STATUS = "Vendor Invite Status";
    public static final String GSTIN_STATUS = "GSTIN Status";
    public static final String FILLING_TYPE = "Filing type";
    public static final String APRIL = "April";
    public static final String MAY = "May";
    public static final String JUNE = "June";
    public static final String JULY = "July";
    public static final String AUGUST = "August";
    public static final String SEPTEMBER = "September";
    public static final String OCTOBER = "October";
    public static final String NOVEMBER = "November";
    public static final String DECEMBER = "December";
    public static final String JANUARY = "January";
    public static final String FEBRUARY = "February";
    public static final String MARCH = "March";
    public static final String IN_PROGRESS = "80";
    public static final String COMPLETED = "81";
    public static final String ERROR = "82";
    public static final String E_INVOICE_REGISTER_REPORT = "VI201";
    public static final String E_WAY_BILL_REGISTER_REPORT = "VI202";
    public static final String PURCHASE_ORDER_REGISTER_REPORT = "VI203";
    public static final String GOODS_RECEIPT_NOTE_REGISTER_REPORT = "VI204";
    public static final String INVOICE_AND_PO_MAPPING_REGISTER_REPORT = "VI205";
    public static final String GSTR2A_REPORT = "VI206";
    public static final String GSTR2B_REPORT = "VI207";
    public static final String GET_E_WAY_BILL_REPORT = "VI208";
    public static final String MAPPED_WITH_GSTR2A_BUT_NOT_MAPPED_WITH_GET_E_WAY_BILL_AND_GSTR2B = "VI209";
    public static final String MAPPED_WITH_GSTR2A_AND_GSTR2B_BUT_NOT_MAPPED_WITH_GET_E_WAY_BILL = "VI210";
    public static final String MAPPED_WITH_GET_E_WAY_BILL_BUT_NOT_MAPPED_WITH_GSTR2A_AND_GSTR2B = "VI211";
    public static final String MAPPED_WITH_GSTR2B_BUT_NOT_MAPPED_WITH_GSTR2A_AND_GET_E_WAY_BILL = "VI212";
    public static final String MAPPED_WITH_GET_E_WAY_BILL_AND_GSTR2B_BUT_NOT_MAPPED_WITH_GSTR2A = "VI213";
    public static final String MAPPED_WITH_GET_E_WAY_BILL_AND_GSTR2A_BUT_NOT_MAPPED_WITH_GSTR2B = "VI214";
    public static final String MAPPED_WITH_GET_E_WAY_BILL_AND_GSTR2A_AND_GSTR2B = "VI215";
    public static final String INWARD_REGISTER_REPORT = "VC301";
    public static final String INWARD_VS_GSTR2A_RECO_REPORT = "VC302";
    public static final String INWARD_VS_GSTR2B_RECO_REPORT = "VC303";
    public static final String VENDOR_EMAIL_STATUS_REPORT = "VC304";
    public static final String CUSTOM_VENDOR_MASTER_TAXPAYER_REGISTER_REPORT = "VM107";
    public static final String CUSTOM_VENDOR_MASTER_TAXPAYER_ERROR_REPORT = "VM108";
    public static final String CUSTOM_VENDOR_MASTER_AS_PER_VENDOR_REGISTER_REPORT = "VM109";
    public static final String CUSTOM_VENDOR_MASTER_AS_PER_VENDOR_ERROR_REPORT = "VM110";
    public static final String CUSTOM_VENDOR_MASTER_COMBINED_REGISTER_REPORT = "VM111";
    public static final String CUSTOM_VENDOR_MASTER_COMBINED_ERROR_REPORT = "VM112";
    public static final String CUSTOM_INWARD_REGISTER_REPORT = "VC305";
    public static final String CUSTOM_INWARD_ERROR_REPORT = "VC306";
    public static final String CUSTOM_INWARD_VS_GSTR2A_RECO_REPORT = "VC307";
    public static final String CUSTOM_INWARD_VS_GSTR2B_RECO_REPORT = "VC308";
    public static final String CUSTOM_E_INVOICE_REGISTER_REPORT = "VI216";
    public static final String CUSTOM_E_INVOICE_ERROR_REPORT = "VI217";
    public static final String CUSTOM_E_WAY_BILL_REGISTER_REPORT = "VI218";
    public static final String CUSTOM_E_WAY_BILL_ERROR_REPORT = "VI219";

    public static final String VIEW = "view";
    public static final String DOWNLOAD = "download";
    public static final String BACKGROUND = "background";
    public static final String ROW_VERSION = "Row Version";
    public static final String DOC_TYPE = "Doc Type";
    public static final String INWARD_DATE = "Inward Date";
    public static final String PURCHASE_ORDER_NO = "Purchase Order No";
    public static final String PURCHASE_ORDER_DATE = "Purchase Order Date";
    public static final String TOTAL_INVOICE_AMT = "Total Invoice Amt";
    public static final String HSN_CODE = "Hsn Code";
    public static final String IRN = "Irn";
    public static final String IRN_DATE = "Irn Date";
    public static final String TEMPLATE_TYPE = "Template Type";
    public static final String UDF_1 = "Udf 1";
    public static final String UDF_2 = "Udf 2";
    public static final String UDF_3 = "Udf 3";
    public static final String UDF_4 = "Udf 4";
    public static final String UDF_5 = "Udf 5";
    public static final String UDF_6 = "Udf 6";
    public static final String UDF_7 = "Udf 7";
    public static final String UDF_8 = "Udf 8";
    public static final String UDF_9 = "Udf 9";
    public static final String UDF_10 = "Udf 10";
    public static final String INWARD_NO = "Inward No";
    public static final String E_WAY_BILL_NO = "E Way Bill No";
    public static final String E_WAY_BILL_DATE = "E Way Bill Date";
    public static final String VALID_UPTO = "Valid Upto";
    public static final String GSTINCOLUMN = "Gstin";
    public static final String CATEGORY = "Category";
    public static final String CTIN = "Ctin";
    public static final String FILING_PERIOD_GSTR1_5 = "Filing Period Gstr1 5";
    public static final String INVOICE_TYPE = "Invoice Type";
    public static final String NOTE_TYPE = "Note Type";
    public static final String NOTE_SUPPLY_TYPE = "Note Supply Type";
    public static final String ISD_DOC_TYPE = "Isd Doc Type";
    public static final String ORG_NOTE_TYPE = "Org Note Type";
    public static final String DOC_NO = "Doc No";
    public static final String DOC_DATE = "Doc Date";
    public static final String ORG_INVOICE_NO = "Org Invoice No";
    public static final String ORG_INVOICE_DATE = "Org Invoice Date";
    public static final String POS = "POS";
    public static final String TAXABLE_AMOUNT = "Taxable Amount";
    public static final String RATE = "Rate";
    public static final String DIFF_PERCENT = "Diff Percent";
    public static final String IGST_AMOUNT = "Igst Amount";
    public static final String CGST_AMOUNT = "Cgst Amount";
    public static final String SGST_AMOUNT = "Sgst Amount";
    public static final String CESS_AMOUNT = "Cess Amount";
    public static final String GROSS_TOTAL_AMOUNT = "Gross Total Amount";
    public static final String REVERSE_CHARGE = "Reverse Charge";
    public static final String ITC_ELIGIBILITY = "Itc Eligibility";
    public static final String ITC_ELIGIBILITY_REASON = "Itc Eligibility Reason";
    public static final String DATE_OF_FILING_GSTR1_5 = "Date Of Filing Gstr1_5";
    public static final String SRCTYP = "Srctyp";

    public static final String IRNGENDATE = "Irngendate";
    public static final String FP = "Fp";
    public static final String PORT_CODE = "Port Code";
    public static final String AMENDMENT_TYPE = "Amendment Type";
    public static final String IMPORT_BILL_NO = "Import Bill No";
    public static final String IMPORT_BILL_DATE = "Import Bill Date";
    public static final String ICEGATE_REF_DATE = "Icegate Ref Date";
    public static final String RCVD_DATE_GST = "Rcvd Date Gst";
    public static final String ETIN = "Etin";
    public static final String SUPPLIER_STATE_CODE = "Supplier State Code";
    public static final String INVOICE_NO = "Invoice No";
    public static final String INVOICE_DATE = "Invoice Date";
    public static final String ORG_NOTE_NO = "Org Note No";
    public static final String ORG_NOTE_DATE = "Org Note Date";
    public static final String NOTE_NO = "Note No";
    public static final String NOTE_DATE = "Note Date";
    public static final String SGST_RATE = "Sgst Rate";
    public static final String CGST_RATE = "Cgst Rate";
    public static final String IGST_RATE = "Igst Rate";
    public static final String CESS_RATE = "Cess Rate";
    public static final String TOTAL_TAX_AMOUNT = "Total Tax Amount";
    public static final String SUM_GROSS_TOTAL_AMOUNT = "Sum Gross Total Amount";
    public static final String CFS = "Cfs";
    public static final String CFS_GSTR3B = "Cfs Gstr3b";
    public static final String DATE_OF_CANCELLATION = "Date Of Cancellation";
    public static final String DELINK_FLAG = "Delink Flag";
    public static final String AMENDMENT_FP = "Amendment Fp";
    public static final String PRE_GST = "Pre Gst";

    public static final String TAXPAYER_GSTIN = "Taxpayer GSTIN";
    public static final String SYNC_WITH_GSTR2A = "Sync With Gstr2a";
    public static final String SYNC_WITH_GSTR2B = "Sync With Gstr2b";
    public static final String SYNC_WITH_EWAY_BILL = "Sync With Eway Bill";
    public static final String VENDOR_GSTIN = "Vendor GSTIN";

    public static final String EWAY_BILL_NO = "Eway Bill No";
    public static final String EWAY_BILL_DATE = "Eway Bill Date";
    public static final String BILL_VALID_DATE = "Bill Valid Date";
    public static final String PO_NO = "Po No";
    public static final String PO_DATE = "Po Date";

    public static final String SENT_BY = "Sent By (Taxpayer login user)";
    public static final String SENT_TO = "Sent To (Vendor contact email id)";
    public static final String CC_RECIPIENT = "CC Recipient";
    public static final String MAIL_INITIATED_TIME = "Mail Initiated time";
    public static final String RECO_STATUS = "Reco status";
    public static final String MAIL_STATUS = "Mail Status";
    public static final String PAN_OR_GSTIN = "PAN/GSTIN";
    public static final String SUPPLY_TYPE = "Supply Type";
    public static final String DOC_NUMBER = "Doc Number";
    public static final String ORG_INVOICE_NUMBER = "Org Invoice Number";
    public static final String VENDOR_NAME = "Vendor Name";
    public static final String VENDOR_STATE_CODE = "Vendor State Code";
    public static final String INVOICE_NUMBER = "Invoice Number";
    public static final String ITEM_DESCRIPTION = "Item Description";
    public static final String UOM = "UOM";
    public static final String QUANTITY = "Quantity";
    public static final String ITEM_RATE = "Item Rate";
    public static final String ASSESSMENT_AMOUNT = "Assessment Amount";
    public static final String DIFF_PERCENTAGE = "Diff Percent";
    public static final String TOTAL_INVOICE_AMOUNT = "Total Invoice Amount";
    public static final String INPUT_TYPE = "Input Type";
    public static final String ITC_INELIGIBLE_REVERSAL_INDICATOR = "ITC Ineligible Reversal Indicator";
    public static final String ITC_INELIGIBLE_REVERSAL_PERCENTAGE = "ITC Ineligible Reversal Percentage";
    public static final String TDS_SECTION = "TDS Section";
    public static final String TDS_RATE = "TDS Rate";
    public static final String TDS_TAX_AMOUNT = "TDS Tax Amount";
    public static final String GROSS_AMOUNT = "Gross Amount";
    public static final String CHALLAN_NUMBER = "Challan  Number";
    public static final String CHALLAN_DATE = "Challan Date";
    public static final String CHALLAN_AMOUNT = "Challan Amount";
    public static final String FINANCIAL_PERIOD = "Financial Period";
    public static final String INVOICE_AGAINST_PROV_ADV = "Invoice against prov adv";
    public static final String INWARD_NUMBER_PROV_ADVANCE = "Inward number prov advance";
    public static final String AMOUNT_OF_PROV_ADVANCE = "Amount of prov advance";
    public static final String BALANCE_OUTSTANDING = "Balance outstanding";

    public static final String IMPORT_BILL_OF_ENTRY_NUMBER = "Import bill of entry number";
    public static final String IMPORT_BILL_OF_ENTRY_DATE = "Import bill of entry date";
    public static final String IMPORT_BILL_OF_ENTRY_AMOUNT = "Import bill of entry amount";
    public static final String DATE_OF_PAYMENT = "Date of Payment";
    public static final String ACKNOWLEDGEMENT_DATE = "Acknowledgement date";
    public static final String NUMBER = "number";
    public static final String DEBIT_GL_ID = "Debit gl id";
    public static final String DEBIT_GL_NAME = "Debit gl name";
    public static final String SUB_LOCATION = "Sub-location";
    public static final String CREDIT_GL_ID = "Credit gl id";
    public static final String CREDIT_GL_NAME = "Credit gl name";
    public static final String REASON = "Reason";
    public static final String INVOICE_REFERENCE = "Invoice Reference";
    public static final String INVOICE_DATE_REFERENCE = "Invoice Date Reference";
    public static final String IMPORT_REF_DATE = "Import Ref. Date";
    public static final String BILL_OF_ENTRY_NUMBER = "Bill of Entry Number";
    public static final String BILL_OF_ENTRY_DATE = "Bill of Entry Date";
    public static final String POS_CODE = "POS Code";
    public static final String INVOICE_VALUE = "Invoice Value";
    public static final String TAXABLE_VALUE = "Taxable Value";
    public static final String TAX_RATE = "Tax Rate";
    public static final String IGST_AMT = "IGST Amt";
    public static final String CGST_AMT = "CGST Amt";
    public static final String SGST_AMT = "SGST Amt";
    public static final String CESS_AMT = "CESS Amt";
    public static final String TOLERANCE = "Tolerance";
    public static final String ITC_ELIGIBLE_OR_INELIGIBLE = "ITC Eligible / Ineligible";
    public static final String DATE_OF_FILING_GSTR1 = "Date of Filing - GSTR1";
    public static final String DATE_OF_FILING_GSTR3B = "Date of Filing - GSTR3B";
    public static final String SUBLOCATION = "Sublocation";
    public static final String REMARKS = "Remarks";
    public static final String MULTI_LINK_UNIQUE_KEY = "Multi-Link Unique key";
    public static final String CFS_GSTR1 = "CFS - GSTR1";
    public static final String ITC_AVAILABILITY = "ITC Availability";
    public static final String REASON_FOR_ITC_UNAVAILABILITY = "Reason for ITC Unavailability";
    public static final String SOURCE_TYPE = "Source Type";
    public static final String SOURCE = "Source";
    public static final String VENDOR_PAN = "Vendor Pan";
    public static final String IRN_GENERATION_DATE = "IRN Generation Date";

    public static final String RECORD_TYPE = "Record Type";
    public static final String GSTR1_FILING_PERIOD = "GSTR1 Filing Period";
    public static final String LINE_LEVEL = "Line-level";
    public static final String INVOICE_LEVEL = "Invoice-level";

    public static final String SUM_TAXABLE_AMT = "Sum Taxable Amount";
    public static final String SUM_SGST_AMT = "Sum Sgst Amount";
    public static final String SUM_CGST_AMT = "Sum Cgst Amount";
    public static final String SUM_IGST_AMT = "Sum Igst Amount";
    public static final String SUM_TOTAL_TAX_AMOUNT = "Sum Total Tax Amount";
    public static final String HEADERCELLSTYLE3 = "headerCellStyle3";
    public static final String HEADERCELLSTYLE2 = "headerCellStyle2";
    public static final String HEADERCELLSTYLE1 = "headerCellStyle1";
    public static final String FILENAME = "fileName";
    public static final String FILEURL = "fileUrl";
    public static final String DOT_XLSX = ".xlsx";
    public static final String DOT_CSV = ".csv";
    public static final String COLUMN_DATA = "ColumnData";
    public static final String DATA = "Data";
    public static final String TOTAL_PAGE_ELEMENTS = "totalPageElements";

    public static final String VENDOR_CODE_IN_ERP = "Vendor Code In ERP";

    public static final String VENDOR_LEGAL_NAME1 = "Vendor Legal Name";

    public static final String VENDOR_TRADE_NAME1 = "Vendor Trade Name";

    public static final String MOBILE_NO = " Mobile No.";

    public static final String EMAIL_ID = "Email ID";
    public static final String PRIMARY_CONTACT = "Primary Contact";

    public static final String ADDRESS_LINE_1 = "Address Line 1";

    public static final String ADDRESS_LINE_2 = "Address Line 2";

    public static final String STATUS = "Status";

    public static final String DEFAULT_ADDRESS = "Default Address";

    public static final String ACCOUNT_NO = "Account No.";

    public static final String PRIMARY_BANK_HEADING = "Primary Bank";

    public static final String PRIMARY_UPI_ID_HEADING = "Primary UPI ID ";

    public static final String SECONDARY_UPI_ID_HEADING = "Secondary UPI ID";

    public static final String VENDOR_AADHAAR_NO = "Vendor Aadhaar No.";

    public static final String VENDOR_TYPE = "Vendor Type";

    public static final String GSTIN_STATUS_HEADING = "GSTIN Status";

    public static final String DATE_OF_REGISTRATION_HEADING = "Date of Registration";

    public static final String DATE_OF_CANCELLATION_OR_SUSPENSION = "Date of Cancellation/ Suspension";

    public static final String VENDOR_STATUS_HEADING = "Vendor Status";

    public static final String STATE_JURISDICTION = "State Jurisdiction";

    public static final String RETURN_PERIOD = "Return Period";

    public static final String FILING_TYPE = "Filing Type";

    public static final String TAX_PERIOD = "Tax Period";

    public static final String DATE_OF_FILING = "Date Of Filing";

    public static final String ACKNOLEDGEMENT_NUMBER = "Acknoledgement Number";
    public static final String DEFAULT = "0";
    public static final String CUSTOM = "1";
    public static final String NIC_IRP = "NIC-IRP";
    public static final String E_WAY_BILL_TEMPLATE_ID = "2";
    public static final String INVOICE_TEMPLATE_ID = "1";

    public static final String COLUMN_WIDTH = "column_width";
    public static final String FIELD_NAME = "field_name";
    public static final String CUSTOMIZE_COLUMN_NAME = "customize_column_name";
    public static final String COLUMN_NAME = "column_name";
    public static final String CALLSTATEMENT_REGEX = "^.*?:";
    public static final String RESULT_SET_1 = "#result-set-1";
    public static final String RESULT_SET_2 = "#result-set-2";
    public static final String TOTAL_COUNT = "total_count";
    public static final String TOTAL_NUMBER_OF_RECORDS = "Total number of records";
    public static final String NOTIFICATION_SUCCESS = "220";
    public static final String NOTIFICATION_ERROR = "221";
    public static final String NOTIFICATION_INITIATED = "340";
    public static final String NOTIFICATION_INFORMATION = "223";
    public static final String NOTIFICATION_IN_PROGRESS = "222";
    public static final int VENDORMASTERMODULEID = 5;
    public static final int VENDORINVOICEMODULEID = 4;
    public static final int VENDORCOMMUNICATIONMODULEID = 10;
    public static final String BACKGROUNG_IN_PROGRESS = "  initiated in background.";
    public static final String BACKGROUNG_COMPLETE = " completed in background.";
    public static final String BACKGROUNG_ERROR = "  error come in background.";

    public static final String REPORT_MASTER_TP_VENDOR_GSTIN_COMBINED_ERROR = "{call report_master_tp_vendor_gstin_combined_error(?,?,?,?,?,?,?,?,?,?,?,?)}";
    public static final String REPORT_MASTER_TP_VENDOR_GSTIN_COMBINED = "{call report_master_tp_vendor_gstin_combined(?,?,?,?,?,?,?,?,?,?,?,?)}";
    public static final String REPORT_MASTER_GSTR_FILING_DETAILS = "{call report_master_gstr_filing_details(?,?,?,?,?,?,?,?,?,?,?,?,?)}";
    public static final String REPORT_MASTER_SEND_INVITES_LIST = "{call report_master_send_invites_list(?,?,?,?,?,?,?,?,?,?)}";
    public static final String UDF1 = "udf_1";
    public static final String UDF2 = "udf_2";
    public static final String UDF3 = "udf_3";
    public static final String UDF4 = "udf_4";
    public static final String UDF5 = "udf_5";
    public static final String UDF6 = "udf_6";
    public static final String UDF7 = "udf_7";
    public static final String UDF8 = "udf_8";
    public static final String UDF9 = "udf_9";
    public static final String UDF10 = "udf_10";
    public static final String UDF11 = "udf_11";
    public static final String UDF12 = "udf_12";
    public static final String UDF13 = "udf_13";
    public static final String UDF14 = "udf_14";
    public static final String UDF15 = "udf_15";
    public static final String UDF16 = "udf_16";
    public static final String UDF17 = "udf_17";
    public static final String UDF18 = "udf_18";
    public static final String UDF19 = "udf_19";
    public static final String UDF20 = "udf_20";
    public static final String REPORT_CODE = "report_code";
    public static final String TOTALCOUNT = "totalCount";
    public static final String EXPORT = "export";
    public static final String CREATED_BY = "created_by";
    public static final String CREATED_AT = "created_at";
    public static final String GETTABVENDORINVOCEREPORTDATA = "GETTabVendorInvoceReportData";
    public static final String REPORTTOTALCOUNT = "ReportTotalCount";
    public static final String REPORTSLIST = "ReportsList";
    public static final String ENCRYPTION_APP_KEY = "encrypt-app-key";
    public static final String SUCCESS_MESSAGE_KEY = "successMessage";
    public static final String SUCCESS_MESSAGE_VIEW_DESCRIPTION = " displayed sucessfully.";
    public static final String SUCCESS_MESSAGE_EXPORT_DESCRIPTION = " exported sucessfully.";
    public static final String SUCCESS_MESSAGE_BACKGROUND_DESCRIPTION = "Background report request initiated for '";
    public static final String CONTAINER_NAME = "container name";
    public static final String BASE_URL = "BaseURL";

}
