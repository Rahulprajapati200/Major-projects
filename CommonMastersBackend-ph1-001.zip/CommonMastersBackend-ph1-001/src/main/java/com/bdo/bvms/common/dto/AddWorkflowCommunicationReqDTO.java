package com.bdo.bvms.common.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.bdo.bvms.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AddWorkflowCommunicationReqDTO extends BaseReqDTO {

    private Integer parentId;

    @NotEmpty(message = "{taxpayerGstin.notempty}")
    @Size(min = Constants.GSTIN_MIN_SIZE, max = Constants.GSTIN_MAX_SIZE, message = "Request parameter taxpayerGstin size must be between "
                    + Constants.GSTIN_MIN_SIZE + " and " + Constants.GSTIN_MAX_SIZE)
    private String taxpayerGstin;

    @NotEmpty(message = "{vendorGstin.notempty}")
    @Size(min = Constants.GSTIN_MIN_SIZE, max = Constants.GSTIN_MAX_SIZE, message = "Request parameter vendorGstin size must be between "
                    + Constants.GSTIN_MIN_SIZE + " and " + Constants.GSTIN_MAX_SIZE)
    private String vendorGstin;

    @NotNull(message = "{workflowMstId.notNull}")
    private Integer workflowMstId;

    private String subject;

    @NotBlank(message = "{body.notBlank}")
    private String body;

    @NotNull(message = "{isNewCommunication.notNull}")
    private Integer isNewCommunication;

    @NotNull(message = "{isVendor.notNull}")
    private Integer isVendor;

    private int moduleId;

    private int commentType;

}
