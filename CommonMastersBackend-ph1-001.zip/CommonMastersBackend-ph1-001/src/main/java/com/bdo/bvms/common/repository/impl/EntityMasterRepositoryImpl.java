package com.bdo.bvms.common.repository.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.constant.StringConstant;
import com.bdo.bvms.common.model.EntityMaster;
import com.bdo.bvms.common.repository.IEntityMasterRepository;
import com.bdo.bvms.common.sql.CommonMstSQL;

@Repository
public class EntityMasterRepositoryImpl implements  IEntityMasterRepository {

    @Autowired
    private JdbcTemplate jdbcTemplateMst;


    @Override
    public EntityMaster getEntityMaster(Integer userId) {
        return jdbcTemplateMst.queryForObject(
                        CommonMstSQL.GET_ENTITY_MASTER_SQL,
                        BeanPropertyRowMapper.newInstance(EntityMaster.class),userId, Constants.VENDOR_ENTITY_TYPE);

    }

    @Override
    public List<EntityMaster> getEntityMasterList(List<String> searchList, String panOrGstin, Integer entityTypeId){
        StringBuilder sql = new StringBuilder(CommonMstSQL.GET_ENTITY_MASTER_LIST_SQL);
        if(panOrGstin.equals(Constants.GSTIN)  ) {
            sql.append("  gstin IN (" +  (searchList.isEmpty() ? "''" :  StringConstant.joinStringWithBase64(searchList)) + ")") ;            
        }else if(panOrGstin.equals(Constants.PAN)  ) {
            sql.append("  pan IN (" + (searchList.isEmpty() ? "''" :  StringConstant.joinStringWithBase64(searchList))  + ")") ;           
        }
        return jdbcTemplateMst.query(sql.toString(), BeanPropertyRowMapper.newInstance(EntityMaster.class));
    }

}
