package com.bdo.bvms.common.global.exception.handler;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.validation.FieldError;

import com.bdo.bvms.common.exception.apierror.CustomValidationError;


public class CustomValidationViolationException extends RuntimeException {


    private static final long serialVersionUID = 1L;
    
    private transient List<CustomValidationError> customValidationErrorList = new ArrayList<>();	

    public CustomValidationViolationException(List<CustomValidationError> customValidationErrorList) {
        super(CustomValidationViolationException.generateMessage(customValidationErrorList));
        this.customValidationErrorList = customValidationErrorList;
    }

    private static String generateMessage(List<CustomValidationError> customValidationErrorList) {
        return "Operation could not succeed due to invalid input " + customValidationErrorList;
    }

    public List<FieldError> getFieldErrors() {
    	return customValidationErrorList.stream().map(this::convertCustomValidationErrorToFieldError).collect(Collectors.toList());
    }

    private FieldError convertCustomValidationErrorToFieldError(CustomValidationError customValidationError) {
        String objectName = customValidationError.getObject();
        String field = customValidationError.getField();
        Object rejectedValue = customValidationError.getRejectedValue();
        String defaultMessage = customValidationError.getMessage();
        return new FieldError(objectName, field, rejectedValue, false, null, null, defaultMessage);
    }

}
