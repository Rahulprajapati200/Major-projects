package com.bdo.bvms.common.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.UploadTransDao;
import com.bdo.bvms.common.dto.InvoiceDetailsDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNReqDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.PaymentResponseBean;
import com.bdo.bvms.common.dto.ResponseBean;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadLogDto;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.dto.UploadStageLogDto;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.sql.CommunicationSQL;

@Repository
public class UploadTransDaoImpl implements UploadTransDao {

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Value("${txn.database-name}")
    String tranDb;

    @Value("${mst.database-name}")
    String mstDb;

    @Override
    public void uploadTxLogDetails(UploadLogDto txUploadLog) throws VendorInvoiceServerException {
        jdbcTemplateTrn.update(CommunicationSQL.INSERT_INTO_UPLOAD_LOG, txUploadLog.getUploadSource(),txUploadLog.getEntityId(),
                        txUploadLog.getBatchNo(), txUploadLog.getTemplateType(), txUploadLog.getTaxpayerPan(),
                        txUploadLog.getTaxpayerGstin(), txUploadLog.getFileName(), txUploadLog.getFp(),
                        txUploadLog.getFileType(), txUploadLog.getUploadStartTime(), txUploadLog.getFileSize(),
                        txUploadLog.getBaseFileLocation(), txUploadLog.getIsCustomTemplate(),
                        txUploadLog.getCustomTemplateId(), txUploadLog.getPldUploadStatus(),
                        txUploadLog.getPldUploadSource(), txUploadLog.getCreatedBy());
    }

    @Override
    public void insertUploadStageLog(UploadStageLogDto uploadStageLogDto) {

        jdbcTemplateTrn.update(CommunicationSQL.INSERT_INTO_UPLOAD_STAGE_LOG, uploadStageLogDto.getUploadLogId(),
                        uploadStageLogDto.getProcessStage(), uploadStageLogDto.getProcessState(),
                        uploadStageLogDto.getCreatedAt(), uploadStageLogDto.getCreatedBy(),
                        uploadStageLogDto.getBatchNo());

    }

    @Override
    public int getUploadIdFromDB(String batchNo) {

        return jdbcTemplateTrn.queryForObject(CommunicationSQL.GET_UPLOAD_LOG_ID, Integer.class, batchNo);
    }

    @Override
    public void updateProcessStatus(String batchNo, String pldUploadStatus) {

        jdbcTemplateTrn.update(CommunicationSQL.UPDATE_PLD_UPLOAD_STATUS, pldUploadStatus, batchNo);

    }

    @Override
    public void updateTimeStamp(String query, UploadReqDTO uploadDTO) {
        // Timestamp instant = new Timestamp(System.currentTimeMillis());

        jdbcTemplateTrn.update(query, Timestamp.from(Instant.now()), uploadDTO.getBatchNo());
    }

    @Override
    public void updateUploadStageNState(String stage, String state, int uploadLogId) {
        jdbcTemplateTrn.update(CommunicationSQL.UPDATE_STAGE_STATE, stage, state, uploadLogId);
    }

    @Override
    public void updateErrorNSuccessCountAndTotalCount(ResponseBean responseBean,
                    List<InwardInvoiceCDNTemplateDTO> updateErrorNSuccessCountAndTotalCount, String batchNo) {
        jdbcTemplateTrn.update(CommunicationSQL.UPDATE_SUCESSNERROR_COUNT, responseBean.getErrorCount(),
                        responseBean.getCdvSuccessCount() + responseBean.getInvSuccessCount(), batchNo);

    }

    @Override
    public void updateErrorFileName(String batchNo, String csvSuccessFilePath) {

        jdbcTemplateTrn.update(CommunicationSQL.UPDAT_ERROR_FILE_NAME, csvSuccessFilePath, batchNo);

    }

    @Override
    public void updateTotalCountAndDocErrorCount(int totalCount, int docErrorCount, UploadReqDTO uploadRequestDTO) {
        jdbcTemplateTrn.update(CommunicationSQL.UPDATE_TOTAL_COUNT, totalCount, docErrorCount,
                        uploadRequestDTO.getBatchNo());

    }

    public Map<String, Object> commonPostNotification(int communicationmstid, String string, int userId, int userId2,
                    int userId3, String schemaname, String notificationCode) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall("{call common_post_notification(?,?,?,?,?,?,?)}");
                if (cs != null) {
                    cs.setInt(1, communicationmstid);
                    cs.setString(2, string);
                    cs.setInt(3, userId);
                    cs.setInt(4, userId2);
                    cs.setInt(5, userId3);
                    cs.setString(6, schemaname);
                    cs.setString(7, notificationCode);
                }
                return cs;
            }
        }, parameters);

    }

    @Override
    public int updatePldCode(String customtemplateID) {

        return jdbcTemplateMst.queryForObject(CommunicationSQL.getUPDATEPLDCODEQUERY(mstDb), Integer.class,
                        customtemplateID, Constants.SMPICKMSTPICKID, Constants.VENDOR_INVOICE_PICK_KEY);
    }

    @Override
    public void updateProcessStatusWithRemarks(String batchNo, String pldUploadStatus,String remarks) {

        jdbcTemplateTrn.update(CommunicationSQL.UPDATE_ERROR_REMARKS, pldUploadStatus,remarks, batchNo);

    }

	@Override
	public void updateFpLog(List<String> month, UploadReqDTO uploadRequestDTO) {
		String fp = "";
        fp = month.toString().replace("[", "").replace("]", "").replace("{", "").replace("}", "")
                        .replace(" ", "");
		jdbcTemplateTrn.update(CommunicationSQL.UPDATEFPLOG,fp,uploadRequestDTO.getBatchNo());
		
	}

	
	@Override
	public void insertUploadStageNState(String processStageDataValidation, String processFileUploadStatusStart,
			UploadReqDTO uploadDTO) {
		jdbcTemplateTrn.update(CommunicationSQL.INSERTINTOSTAGELOG,uploadDTO.getBatchNo(),processStageDataValidation,processFileUploadStatusStart,
				LocalDateTime.now(),uploadDTO.getUserId());
	}

	@Override
	public void insertStageNState(String processStageDataValidation, String processFileUploadStatusStart,
			InwardInvoiceCDNReqDTO uploadRequestDTO,String batchNo) {
		jdbcTemplateTrn.update(CommunicationSQL.INSERTINTOSTAGELOG,batchNo,processStageDataValidation,processFileUploadStatusStart,
				LocalDateTime.now(),uploadRequestDTO.getUserId());
	}
	
	@Override
	public void vendorCommunicationArchiveInwardUploadData(UploadReqDTO reqDto) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));
         jdbcTemplateTrn.call(new CallableStatementCreator() {
            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall("{call vendor_communication_archive_inward_upload_data(?,?,?)}");
                if (cs != null) {
                    cs.setString(1, reqDto.getBatchNo());
                    cs.setInt(2, reqDto.getUserId());
                    cs.setString(3, mstDb);
                }
                return cs;
            }
        }, parameters);

	}

	@Override
	public void vendorCommunicationArchiveInwardUploadData(InvoiceDetailsDTO reqDto) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));
         jdbcTemplateTrn.call(new CallableStatementCreator() {
            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall("{call vendor_communication_archive_inward_upload_data(?,?,?)}");
                if (cs != null) {
                    cs.setString(1, reqDto.getBatchNo());
                    cs.setInt(2, reqDto.getUserId());
                    cs.setString(3, mstDb);
                }
                return cs;
            }
        }, parameters);

	}
	
	@Override
	public void updateErrorNSuccessCountAndTotalCount(PaymentResponseBean responseBean,
			List<PaymentDetails> rowDocErrorPojoList, String batchNo) {
        jdbcTemplateTrn.update(CommunicationSQL.UPDATE_SUCESSNERROR_COUNT, responseBean.getErrorCount(),
                responseBean.getPaymentSuccessCount(), batchNo);

}

	@Override
	public void updateTdsErrorNSuccessCountAndTotalCount(PaymentResponseBean responseBean,
			List<TdsDetails> rowDocErrorPojoList, String batchNo) {
        jdbcTemplateTrn.update(CommunicationSQL.UPDATE_SUCESSNERROR_COUNT, responseBean.getErrorCount(),
                responseBean.getPaymentSuccessCount(), batchNo);

}

	@Override
	public void updateItcErrorNSuccessCountAndTotalCount(PaymentResponseBean responseBean,
			List<ItcDto> rowDocErrorPojoList, String batchNo) {
        jdbcTemplateTrn.update(CommunicationSQL.UPDATE_SUCESSNERROR_COUNT, responseBean.getErrorCount(),
                responseBean.getPaymentSuccessCount(), batchNo);

}

}
