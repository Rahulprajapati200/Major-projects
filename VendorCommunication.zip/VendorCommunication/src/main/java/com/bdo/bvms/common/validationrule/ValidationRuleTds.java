package com.bdo.bvms.common.validationrule;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dto.TdsDetails;

public class ValidationRuleTds {

	public void validateTds(TdsDetails rowData,List<String>tdsSection)
	{
		InwardDroolUtil ruleMethods = new InwardDroolUtil();

		// Customer GSTIN validate
        validGstinCheck(rowData, ruleMethods);

        validGSTINTaxpayer(rowData, ruleMethods);
        
        validateDocType(rowData);
        
        validateTdsSection(rowData,tdsSection);
        
        validateTdsTaxAmount(rowData,ruleMethods);
        
        validateTdsRate(rowData,ruleMethods);
        
    	validateTdsRate3Digit2Decimal(rowData,ruleMethods);
    	
    	validateChallanNumber(rowData,ruleMethods);

        validateChallanDate(rowData,ruleMethods);
        
        challanNumberLengthValidation(rowData);
        
        validateChallanAmount(rowData,ruleMethods);
        
        validateFillingPeriod(rowData,ruleMethods);
	}
	private void validGstinCheck(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.validGSTIN(rowdata.getGstinOfSupplier())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00519, "");
        }
	}
	private void validateDocType(TdsDetails rowdata) {
		if (StringUtils.isNotBlank(rowdata.getInvoiceAgainstProvAdv())) {
			List<String> docTypeList = new ArrayList<>(Arrays.asList("INV", "CRN","DBN"));
			if (!docTypeList.contains(rowdata.getDocType())) {
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00257, "");
			}
		}
	}
	
	private void markErrorNAddErrorCode(TdsDetails rowdata, String errorCode, String errorMsg) {
        rowdata.setErrorCodeList(rowdata.getErrorCodeList().append(errorCode));
        rowdata.setErrorDescriptionList(rowdata.getErrorDescriptionList().append(errorMsg));
        rowdata.setValid(false);
    }
	
	private void validGSTINTaxpayer(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.validGSTIN(rowdata.getGstinUinOfRecipient())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00517, "");
        }
	}
	private void validateTdsSection(TdsDetails rowData,List<String> tdsSections)
	{
		if (StringUtils.isNotBlank(rowData.getTdsSection()) && !tdsSections.contains(rowData.getTdsSection())) {
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00527, "");
		}
	}
	
	private void validateTdsTaxAmount(TdsDetails rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getTdsTaxAmount()) && !ruleMethods.checkLength12(rawData.getTdsTaxAmount(), rawData.isValid()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00528, "");
		}
	}
	
	private void validateTdsRate(TdsDetails rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getTdsRate()) && !ruleMethods.twoDecimalHsnCheckBlank(rawData.getDocType(), rawData.getTdsRate()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00563, "");
		}
	}
	
	private void validateTdsRate3Digit2Decimal(TdsDetails rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getTdsRate()) && !ruleMethods.checkLength3LenTds(rawData.getTdsRate()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00563, "");
		}
	}
	
	private void validateChallanNumber(TdsDetails rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getChallanNo()) && !ruleMethods.onlyNumericAckNo(rawData.getChallanNo()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00557, "");
		}
	}
	
	private void validateChallanDate(TdsDetails rowData,InwardDroolUtil rulesMethod)
	{
		if(StringUtils.isNotBlank(rowData.getChallanDate()) && !rulesMethod.isValidInvoiceDate(rowData.getChallanDate()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00529, "");
		}
	}

	private void challanNumberLengthValidation(TdsDetails rowdata) {
		if(StringUtils.isNotBlank(rowdata.getChallanNo()) && rowdata.getChallanNo().length()>6)
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00530, "");
		}
	}
	private void validateChallanAmount(TdsDetails rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getChallanAmount()) && !ruleMethods.checkLength12(rawData.getChallanAmount(), rawData.isValid()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00531, "");
		}
	}
	private void validateFillingPeriod(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
         if(StringUtils.isNotBlank(rowdata.getPeriodFilingTdsReturn()) && !ruleMethods.validatePeriodOfFillingTds(rowdata))
         {
        	 markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00532, "");
         }
	}

	
}
