package com.bdo.bvms.common.service;

import com.bdo.bvms.common.dto.InwardInvoiceCDNReqDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface UploadLogService {

	void saveInUploadLog(InwardInvoiceCDNReqDTO uploadRequestDTO, String batchNo,UploadReqDTO uploadReqDTO) throws VendorInvoiceServerException;

	int getUploadLogId(String batchNo) throws VendorInvoiceServerException;

	void saveInUploadStageLog(InwardInvoiceCDNReqDTO uploadRequestDTO, UploadReqDTO uploadReqDTO);

}
