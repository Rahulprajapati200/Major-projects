package com.bdo.bvms.common.tds.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.BDOException;

public interface WriteTdsErrorAndSuccessCsv {

	void writeSuccessNErrorDataInCSVFile(UploadReqDTO uploadReqDTO, List<TdsDetails> errorTdsDetailsTemplateDTOsList,
			List<TdsDetails> sucessTdsDetailsTemplateDTOsList) throws IOException, BDOException;

	void writeAzureErrorDataInCSVFile(List<TdsDetails> errorDataListWithErrorCode, UploadReqDTO uploadReqDTO,
			Map<String, String> codesMap) throws IOException, BDOException;

}
