package com.bdo.bvms.common.dto;

import java.io.Serializable;
/**
 *FileType: java
 *Author : anka
 *Created On : 02/11/2017 6:56:39 PM
 *Copy Rights : Anka Technology Solutions Pvt. Ltd.
 */

public class ReturnPeriods implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String yearId;
	private String fp;

	public ReturnPeriods() {
		//
	}

	public ReturnPeriods(Integer id, String yearId, String fp) {
		this.id = id;
		this.yearId = yearId;
		this.fp = fp;
	}
	
	public String getyearId() {
		return yearId;
	}

	public void setyearId(String yearId) {
		this.yearId = yearId;
	}

	public String getfp() {
		return fp;
	}

	public void setfp(String fp) {
		this.fp = fp;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return   fp;
	}
}
