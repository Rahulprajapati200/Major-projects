package com.bdo.bvms.common.payment.serviceimpl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dao.InwardRegisterDao;

import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.payment.dao.PaymentDao;
import com.bdo.bvms.common.payment.service.PaymentDetailValidation;
import com.bdo.bvms.common.payment.validation.ValidatePaymentDetails;

import com.google.common.collect.Lists;
import com.ibm.icu.text.DecimalFormat;
@Service
public class ValidatePaymentDetailsDataImpl implements PaymentDetailValidation{

	@Value("${mst.database-name}")
    private String mstDatabaseName;
	
	Map<String,String> purchageDnrInvoiceMap=new HashMap<>();
	
	Map<String,Set<String>>paymentDataInPaymentTableMap=new HashMap<>();
	
	Map<String,Set<String>>paymentExcelDataInPaymentTableMap=new HashMap<>();
	Map<String, Map<String, String>> suppGSTNWiseMap = new HashMap<>();
    Map<String, String> yearIdMap = new HashMap<>();
	@Autowired
	InwardRegisterDao commonCommunicationDao;
	
	@Autowired
	PaymentDao paymentDao;
	
	@Override
	public void validatePaymentDetails(List<PaymentDetails> paymentDetailsTemplateDTOList, UploadReqDTO uploadReqDTO,List<PaymentDetails> errorPaymentDetailsTemplateDTOsList,List<PaymentDetails> sucessPaymentDetailsTemplateDTOsList,Map<String,String> yearIdMap) {
		
		List<List<PaymentDetails>> partList = Lists.partition(paymentDetailsTemplateDTOList, Constants.THREADCOUNT);
		
		 String userGSTN[] = null;

	        if (Constants.PAN.equals(uploadReqDTO.getPanOrGstn())) {
	            userGSTN = commonCommunicationDao.getGstinFromDB(uploadReqDTO.getGstinOrPanList().get(0),
	            		mstDatabaseName);
	        } else if (Constants.GSTIN.equals(uploadReqDTO.getPanOrGstn())) {
	            userGSTN = uploadReqDTO.getGstinOrPanList()
	                            .toArray(new String[uploadReqDTO.getGstinOrPanList().size()]);

	        }
	        
	        String[] fpList = uploadReqDTO.getMonth().toArray(new String[uploadReqDTO.getMonth().size()]);
	        
	        for (List<PaymentDetails> sublist : partList) {
	           
	              runParallalProcessingValidations(paymentDetailsTemplateDTOList,sublist,
	            		uploadReqDTO, userGSTN, fpList,errorPaymentDetailsTemplateDTOsList,sucessPaymentDetailsTemplateDTOsList,yearIdMap);
	        }
	        
	}

	private void runParallalProcessingValidations(List<PaymentDetails> finalListData,List<PaymentDetails> sublist, UploadReqDTO uploadReqDTO,
			String[] userGSTN, String[] fpList, List<PaymentDetails> errorPaymentDetailsTemplateDTOsList2, List<PaymentDetails> sucessPaymentDetailsTemplateDTOsList2,Map<String,String> yearIdMap) {
		
		
		sublist.forEach(rowData->{
			if (StringUtils.isBlank(rowData.getGstinUinOfRecipient())
					|| !Arrays.stream(userGSTN).anyMatch(rowData.getGstinUinOfRecipient()::equalsIgnoreCase)) {
				markErrorNAddErrorCode(rowData, "|E00520", "");
			}
			isValidFp(rowData,fpList);
			ValidatePaymentDetails invDataTypeCheck = new ValidatePaymentDetails();
			
			invDataTypeCheck.validatePaymentDetails(rowData);
			paymentInvoiceExistsError(rowData);
			validatePaymentDuplicateData(rowData);
			checkForExcelLevelDuplicat(rowData);
             invDataTypeCheck = null;
			
             
             
             
		});
		sublist.forEach(rowData->
		{
			int paymentListSize=sublist.size();
			checkForExcelDuplicateAgain(rowData);
			checkPreviousMonthFpUploaded(rowData,paymentListSize,uploadReqDTO,yearIdMap);
			if(rowData.isValid())
            {
           	 sucessPaymentDetailsTemplateDTOsList2.add(rowData);
            }
            else {
				errorPaymentDetailsTemplateDTOsList2.add(rowData);
			}
		});
		purchageDnrInvoiceMap.clear();
		paymentDataInPaymentTableMap.clear();
		paymentExcelDataInPaymentTableMap.clear();
	}
	
	 private void isValidFp(PaymentDetails rowdata, String[] fpList) {

	        boolean fp = StringUtils.isNotBlank(rowdata.getFilingPeriod()) && rowdata.getFilingPeriod().length() == 6
	                        && rowdata.getFilingPeriod().matches("\\d+");
	        if (fp && Arrays.stream(fpList).noneMatch(rowdata.getFilingPeriod()::equalsIgnoreCase)) {
	        	markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00353, "");
	        }

	    }
	
	private void checkPreviousMonthFpUploaded(PaymentDetails rowData, int paymentListSize, UploadReqDTO uploadReqDTO,Map<String,String> yearIdMap) {


        int isduplicateInvoiceInDiffMonth = 0;
        String supplierGstnInwardNo = rowData.getGstinOfSupplier() + rowData.getInwardNo();
        if (paymentListSize < 5000) {
            isduplicateInvoiceInDiffMonth = paymentDao.getInwardResultFPCount(
                            rowData.getGstinUinOfRecipient(), rowData.getInwardNo(),
                            rowData.getInwardDate(), rowData.getGstinOfSupplier(), rowData.getFilingPeriod(), yearIdMap.get(rowData.getFilingPeriod()));

        } else {
            // Check invoice already saved in the GSTN
            String keyCheckInBatchData = rowData.getGstinUinOfRecipient() + uploadReqDTO.getBatchNo();
            List<String> invoiceList = null;
            if (suppGSTNWiseMap.get(keyCheckInBatchData) == null) {
                invoiceList = paymentDao.getDuplicateFPInDiffMonth(
                                rowData.getGstinOfSupplier(), rowData.getGstinUinOfRecipient(),yearIdMap.get(rowData.getFilingPeriod()),
                                rowData.getFilingPeriod());
                Map<String, String> map = invoiceList.stream()
                                .collect(Collectors.toMap(str -> str, str -> str));
                suppGSTNWiseMap.put(keyCheckInBatchData, map);
                if (suppGSTNWiseMap.get(keyCheckInBatchData).get(supplierGstnInwardNo) != null) {
                    isduplicateInvoiceInDiffMonth++;
                }

            } else {
                Map<String, String> map = suppGSTNWiseMap.get(keyCheckInBatchData);
                if (map != null && map.get(supplierGstnInwardNo) != null) {
                    isduplicateInvoiceInDiffMonth++;
                }
            }
        }

        String mapKey = rowData.getInwardNo() + rowData.getGstinOfSupplier();

        if (StringUtils.isNotBlank(mapKey)) {
            mapKey = mapKey.toLowerCase();
        }

//        String itcClaimedKey = rowData.getGstinOfRecipient() + uploadRequestDTO.getBatchNo();
        if (isduplicateInvoiceInDiffMonth > 0) {
            markErrorNAddErrorCode(rowData, Constants.COMMUNICATION_ERROR_CODE_O0093, "");
        }
	
		
	}

	private void checkForExcelDuplicateAgain(PaymentDetails rowData) {
		String mapVal=new StringBuilder().append(rowData.getGstinUinOfRecipient())
				.append(rowData.getGstinOfSupplier())
				.append(rowData.getPaymentRefNo()).toString();
		
		if(rowData.getErrorCodeList().indexOf("E00574")<=0)
		{
			if(paymentExcelDataInPaymentTableMap.containsKey(mapVal))
			{
				Set<String>set=new HashSet<>();
				set=paymentExcelDataInPaymentTableMap.get(mapVal);
				if(set.size()>1)
				{
					rowData.setErrorCodeList(rowData.getErrorCodeList().append(Constants.ERROR_CODE_E00574));
					rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(""));
					rowData.setValid(false);
				}
			}	
		}
	}

	private void checkForExcelLevelDuplicat(PaymentDetails rowData) {
		
		String mapVal=new StringBuilder().append(rowData.getGstinUinOfRecipient())
				.append(rowData.getGstinOfSupplier())
				.append(rowData.getPaymentRefNo()).toString();
		
		 
		String setValue= new StringBuilder().append(rowData.getAmountofPayment()).append(rowData.getDateOfPayment()).toString();
		
		if(paymentExcelDataInPaymentTableMap.containsKey(mapVal))
		{
			Set<String>s=paymentExcelDataInPaymentTableMap.get(mapVal);
			s.add(setValue);
			paymentExcelDataInPaymentTableMap.put(mapVal, s);
			
		}
		else
		{
			Set<String>s=new HashSet<>();
			s.add(setValue);
			paymentExcelDataInPaymentTableMap.put(mapVal, s);
		}
		
		if(paymentExcelDataInPaymentTableMap.containsKey(mapVal))
		{
			Set<String>set=paymentExcelDataInPaymentTableMap.get(mapVal);
			if(set.size()>1)
			{
				rowData.setErrorCodeList(rowData.getErrorCodeList().append(Constants.ERROR_CODE_E00574));
				rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(""));
				rowData.setValid(false);
			}
		}	
			
		
	}

	

	private void validatePaymentDuplicateData(PaymentDetails rowData) {
		String mapKey=new StringBuilder().append(rowData.getGstinUinOfRecipient())
				.append(rowData.getGstinOfSupplier())
				.append(rowData.getPaymentRefNo()).toString();
		
		DecimalFormat decfor = new DecimalFormat("0.00"); 
		if(StringUtils.isNotBlank(rowData.getAmountofPayment()) && isNumeric(rowData.getAmountofPayment()))
		{
			
			    String amount = decfor.format(Double.parseDouble(rowData.getAmountofPayment()));
			    rowData.setAmountofPayment(amount);	
		}
		
		
		if(!paymentDataInPaymentTableMap.containsKey(mapKey.toString()))
		{
			Set<String>paymentItemMap=new HashSet<>();
			paymentItemMap=paymentDao.getPaymentItemMap(rowData);
			if( !paymentItemMap.isEmpty() && !paymentItemMap.contains(new StringBuilder().append(rowData.getDateOfPayment()).append(rowData.getAmountofPayment()).toString()))
			{
				paymentDataInPaymentTableMap.put(mapKey.toString(), paymentItemMap);
				markErrorNAddErrorCode(rowData, Constants.ERROR_CODE_E00573, "");
			}
			
			
		}
		else
		{
			if(!paymentDataInPaymentTableMap.get(mapKey.toString()).contains(new StringBuilder().append(rowData.getDateOfPayment()).append(rowData.getAmountofPayment()).toString()))
			{
				markErrorNAddErrorCode(rowData, Constants.ERROR_CODE_E00573, "");
			}
		}
		
	}

	private void paymentInvoiceExistsError(PaymentDetails rowData) {
		StringBuilder mapKey=new StringBuilder().append(rowData.getGstinUinOfRecipient())
				.append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo());
		if(!purchageDnrInvoiceMap.containsKey(mapKey.toString()))
		{
			int count= paymentDao.checkIfInvoiceDetailExits(rowData);
			if(count>0)
			{
				purchageDnrInvoiceMap.put(mapKey.toString(), mapKey.toString());
			}
			else
			{
				markErrorNAddErrorCode(rowData,Constants.ERROR_CODE_E00570 , "");
			}
		}
		
		
	}

	private void markErrorNAddErrorCode(PaymentDetails rowdata, String errorCode, String errorMsg) {
        rowdata.setErrorCodeList(rowdata.getErrorCodeList().append(errorCode));
        rowdata.setErrorDescriptionList(rowdata.getErrorDescriptionList().append(errorMsg));
        rowdata.setValid(false);
    }
	
	public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

}
