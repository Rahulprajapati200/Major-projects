package com.bdo.bvms.common.exception.apierror;

public abstract class ApiSubError {

}