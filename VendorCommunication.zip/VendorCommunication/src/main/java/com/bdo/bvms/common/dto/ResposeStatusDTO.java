package com.bdo.bvms.common.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class ResposeStatusDTO {
	String httpStatus;
	String messageCode;
	String messageDiscription;
	String errMsgDiscription;
}
