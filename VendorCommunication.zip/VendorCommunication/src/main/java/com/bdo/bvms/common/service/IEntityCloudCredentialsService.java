package com.bdo.bvms.common.service;

import com.bdo.bvms.common.model.EntityCloudCredentials;

public interface IEntityCloudCredentialsService {

	EntityCloudCredentials getEntityCloudCredentials(int entityId);

}
