package com.bdo.bvms.common.repository;

import com.bdo.bvms.common.model.EntityCloudCredentials;

public interface IEntityCloudCredentialsRepository {

	EntityCloudCredentials searchEntityCloudCredentials(int entityId);

}
