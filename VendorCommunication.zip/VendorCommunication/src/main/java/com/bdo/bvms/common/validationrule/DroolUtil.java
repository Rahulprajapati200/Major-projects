package com.bdo.bvms.common.validationrule;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class DroolUtil {

	private DroolUtil()
	{
		super();
	}
	public static boolean checkIfDiluted(String dilutedValidationString, String errorID) {
		if (StringUtils.isBlank(dilutedValidationString)) {
			return false;
		} else {
			return dilutedValidationString.contains(errorID);
		}
	}
	

	public static boolean containsNumbersOnly(String source, Integer typeChk) {
		boolean result = false;
		if (source != null && !"".equals(source)) {
			source = source.trim();
			try {
				if (typeChk == 1) {
					Pattern pattern;
					pattern = Pattern.compile("[0-9.]+"); // correct pattern for both float and integer. execute

					result = pattern.matcher(source).matches();

					return result;
				} else {
					Double.parseDouble(source);
					return true;
				}

			} catch (Exception ex) {
				return false;
			}
		} else {
			return false;
		}
	}

	public static boolean isEmpty(String param) {
		boolean isValid = false;
		if (StringUtils.isBlank(param)) {
			isValid = true;
		}
		return isValid;
	}
	public static String hsnCodeCheck(String hsncode, String inputType) {
		String importType = "";
		boolean isValidHSNFormat = true;
		if (inputType.equals("") || inputType.equals("0")) {
			String newHsn = "";
			newHsn = hsncode;
			if (!newHsn.matches("^\\d+$")) {
				isValidHSNFormat = false;
				importType = "inputs";
			} else {
				if (isValidHSNFormat && newHsn.equals("0")) {
					isValidHSNFormat = false;
				}
				if (isValidHSNFormat) {
					if (newHsn.length() == 1) {
						newHsn = "0" + newHsn;
					}
					String sacCode = newHsn.substring(0, 2);
					if (Double.parseDouble(sacCode) == 99) {
						importType = "Input Services";
					} else {
						importType = "inputs";
					}
				}
			}
		} else {
			importType = inputType;
		}
		return importType;
	}


}
