package com.bdo.bvms.common.dto;

import org.springframework.data.relational.core.mapping.Column;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AttachmentListDto {

	@Column("name")
	String name;
	@Column("size")
	String size;
	@Column("path")
	String path;
	@Column("created_at")
	String createdAt;
	@Column("")
	String fileExtension;
	@Column("pld_module_id")
	int moduleId;
	
	String fileUrl;
}
