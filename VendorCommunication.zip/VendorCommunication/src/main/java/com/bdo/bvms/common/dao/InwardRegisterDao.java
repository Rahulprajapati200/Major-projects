package com.bdo.bvms.common.dao;

import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.ExceptionLogDTO;
import com.bdo.bvms.common.dto.InvoiceDetailsDbDto;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.ResponseBean;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;

public interface InwardRegisterDao {

    AzureConnectionCredentialsDTO getAzureCredentialFromDB(int entityId, String blob);

    Map<String, String> getOrgInvoiceForInwardCDN(String gstinUinOfRecipient, String orgInvoiceNo,
            String orgInvoiceDate, String gstinOfSupplier, String fp);
    
    List<InwardInvoiceCDNTemplateDTO> getErrorDataListWithErrorCode(UploadReqDTO uploadRequestDTO);

    List<InwardInvoiceCDNTemplateDTO> setErrorDiscription(List<InwardInvoiceCDNTemplateDTO> errorDataListWithErrorCode);

    String getFPYear(String fp);

    List<String> getUomQuery();

    int getInwardResultFPCount(String gstinUinOfRecipient, String inwardNo, String inwardDate, String gstinOfSupplier,
                    String fp, String yearId);

    List<String> getDuplicateFPInDiffMonth(String gstinOfSupplier, String gstinUinOfRecipient, String yearId,
                    String fp);

    int getITCClaimCount(String gstinUinOfRecipient, String gstinOfSupplier, String inwardNo, String inwardDate,
                    String fp, String yearId, int i);

    List<String> getListOfInvoiceITCClaimedInYear(String gstinOfSupplier, String gstinUinOfRecipient, String yearId,
                    String fp);

    int getITCClaimedCDNCount(String gstinUinOfRecipient, String gstinOfSupplier, String inwardNo, String inwardDate,
                    String fp, String yearId, int i);

    Map<String, String> getHsnCodeList();

    Map<String, String> getStateCodeList();

    Map<String, String> getPortCodeList();

    List<String> getGovtRateList();

    List<String> getDuplicateInwardCdnInDiffFP(String yearId, String fp, String gstinUinOfRecipient, String dbName,
                    String trnDbName);

    void updateExceptionLogTable(ExceptionLogDTO exceptionLogDTO);

    String getEntityId(String gstinUinOfRecipient);

    Map<String, String> getYearId();

    Map<String, String> setErrorDiscriptionForErrorList();

    ResponseBean gstInwardInvCdnInsert(String csvInvSuccessFilePath, String csvCdnSuccessFilePath,
                    String csvInvCdnErrorFilePath, String csvCdnErrorFilePath, String successInvTable,
                    String successCdnTable, String failureInvCdnTable, String failureCdnTable);

    String[] getGstinFromDB(String string, String mstDb);

    void updateInvoiceDetailIntoDb(List<InvoiceDetailsDbDto> invoiceDetailDto);

    ResponseBean gstInvoiceDetailsInvCdnInsert(String csvInvSuccessFilePath, String csvCdnSuccessFilePath,
                    String successInvTable, String successCdnTable);

	void updateProcessStatusWithRemarks(String batchNo, String pldUploadStatus, String remarks);

	String getFPYearId(String fp);

	int getInwardResultFPCountCDN(String gstinUinOfRecipient, String inwardNo, String inwardDate,
			String gstinOfSupplier, String fp, String yearId);

	List<String> getDuplicateFPInDiffMonthCDN(String gstinOfSupplier, String gstinUinOfRecipient, String yearId,
			String fp);	List<String> getTdsSectionList();

	
	void updateTdsDetailTable(List<TdsDetails> tdsSections,UploadReqDTO uploadDto);

	void deletePaymentItem(List<Integer> paymentDeletedIds);

	void deleteTdsItems(List<Integer> paymentDeletedIds);

	void deleteInvoicetItems(List<Integer> paymentDeletedIds, String string);

	void updatePaymentDetailTable(List<PaymentDetails> paymentDetails, UploadReqDTO uploadDto);

	List<InwardInvoiceCDNTemplateDTO> getinvoiceForInwardCDN(String gstinOfRecipient, String orgInvoiceNo,
			String orgInvoiceDate, String gstinOfSupplier, String fp);

}
