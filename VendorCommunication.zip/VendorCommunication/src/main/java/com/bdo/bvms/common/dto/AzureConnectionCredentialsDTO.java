package com.bdo.bvms.common.dto;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AzureConnectionCredentialsDTO {
	private String url;
	private String containerName;
}
