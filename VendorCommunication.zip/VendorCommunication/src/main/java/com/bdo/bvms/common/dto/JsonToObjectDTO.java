package com.bdo.bvms.common.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class JsonToObjectDTO {

    private String pan;
    private String gstin;
    private String fileType;
    private String po;
    private String templateType;
    private String panOrGstn;
    private String fp;

}
