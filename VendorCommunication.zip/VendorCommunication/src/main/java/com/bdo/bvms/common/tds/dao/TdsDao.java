package com.bdo.bvms.common.tds.dao;

import java.util.List;

import com.bdo.bvms.common.dto.PaymentResponseBean;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;

public interface TdsDao {

	PaymentResponseBean gstInwardInvCdnInsert(String csvPaymentSuccessFilePath, String csvPaymentErrorFilePath,
			String successPaymentTable, String failurePaymentTable);

	List<TdsDetails> getPaymentErrorDataListWithErrorCode(UploadReqDTO uploadReqDTO);

	int checkIfInvoiceDetailExits(TdsDetails rowData);

	int getInwardResultFPCount(String gstinUinOfRecipient, String inwardNo, String inwardAate, String gstinOfSupplier,
			String filingPeriod, String string);

	List<String> getDuplicateFPInDiffMonth(String gstinOfSupplier, String gstinUinOfRecipient, String string,
			String filingPeriod);

}
