package com.bdo.bvms.common.sql;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Pageable;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.impl.UploadSQL;

public class CommonMstSQL {

	private CommonMstSQL() {
		
		super();
	}
    public static String getFpMonths(Pageable page, String searchFilterValue) {
        return "select return_period_id,fp,fp_description from sm_return_periods where fp_description like '%"+ searchFilterValue + "%'"+" order by return_period_id desc " + Constants.LIMIT + page.getPageSize()
                        + Constants.OFFSET + page.getOffset();        
    }
    
    public static final String GET_PICKUP_MASTER_SQL = new StringBuilder(
    		Constants.SELECT_PLD_COLUMNS)
                            .append(Constants.FROM_PLD)
                            .append(Constants.JOIN_PICKUP_MASTER_PLD)
                            .append(Constants.JOIN_USERMASTER_PLD)
                            .append(" where pm.name =?   order by pld.sort_order asc ").toString();
    
    public static final String GET_PICKUP_DETAIL_BY_NAME_CODE_SQL = new StringBuilder(
    		Constants.SELECT_PLD_COLUMNS)
                            .append(Constants.FROM_PLD)
                            .append(Constants.JOIN_PICKUP_MASTER_PLD)
                            .append(Constants.JOIN_USERMASTER_PLD)
                            .append(" where pm.name =? and pld.code=? order by pld.sort_order asc ").toString();

	public static String getFpYear(Pageable page, String financialYearId, String filterSearchValue) {
		String sql;
		String subQuery=" order by year_id desc";
		if(!StringUtils.isBlank(financialYearId))
		{
        sql = UploadSQL.GET_FINACIAL_YEAR+" year_id in ("+ financialYearId + ")"+" or financial_year "+"like '%"+ filterSearchValue + "%'" + subQuery+ Constants.LIMIT + page.getPageSize() + Constants.OFFSET + page.getOffset();
		}
		else
		{
			sql = UploadSQL.GET_FINACIAL_YEAR+" financial_year "+"like '%"+ filterSearchValue + "%'" + subQuery+ Constants.LIMIT + page.getPageSize() + Constants.OFFSET + page.getOffset(); 
		}
		return sql;
	}

	public static final String GET_CUSTOM_TEMPLATE_OPTIONS_SQL = new StringBuilder(
			"select cto.id,pld.name,template_column_config_id from am_custom_template_options cto ")
			.append(" join sm_pickup_list_details pld on pld.id=cto.pld_id where template_column_config_id = ?  ")
			.toString();

	public static final String GET_CUSTOM_TEMPLATE_TYPE_SQL = new StringBuilder(
			"select id,name , from_base64(first_name) user_Name,ctn.created_at from am_custom_template_name ctn ")
			.append(" join am_user_master um on ctn.created_by=um.user_id ")
			.append("where  ctn.pld_status = ?  and ctn.pan in (?)  ").toString();

	public static final String GET_CUSTOM_TEMPLATE_HEADER_MAPPING_SQL = new StringBuilder("SELECT  cc.column_name as standardHeader , cm.template_column as customHeader \n")
			.append(" FROM am_template_column_configuration cc ")
			.append(" INNER JOIN   am_custom_template_column_mapping cm ON cc.id = cm.am_template_column_configuration_id\n")
			.append(" where cm.custom_template_name_id=? ")
			.toString();

	public static final String INSERT_CUSTOM_TEMPLATE_NAME_SQL = new StringBuilder(
			"INSERT INTO am_custom_template_name ")
			.append("(pld_template_id,pan,entity_id,name,created_at,created_by,pld_status) ")
			.append("VALUES(?,?,?,?,now(),?,?) ").toString();

	public static final String INSERT_CUSTOM_TEMPLATE_COLUMN_MAPPING_SQL = new StringBuilder(
			"INSERT INTO am_custom_template_column_mapping\r\n")
			.append("(template_column,pld_template_id,pan,entity_id,am_template_column_configuration_id,is_auto_map,created_at,\r\n")
			.append("created_by,custom_template_name_id) VALUE(?,?,?,?,?,?,now(),?,?)  ").toString();

	public static final String INSERT_CUSTOM_TEMPLATE_COLUMN_VALUE_MAPPING_SQL = new StringBuilder(
			" INSERT INTO am_custom_template_column_value_mapping\r\n")
			.append("  (custom_template_mapping_id,option_id,`values`,entity_id,created_at,created_by)\r\n")
			.append("  VALUES (?,?,?,?,now(),?) ").toString();

	public static final String GET_CUSTOM_TEMPLATE_COLUMN_CONFIG_SQL = new StringBuilder(
			"  select id,pld_template_id,column_name,data_type,size,is_mandatory,created_at,created_by,conditional_mandatory_grouping  \r\n")
			.append(" from am_template_column_configuration where pld_template_id = ? ").toString();

	
	public static final String GET_CUSTOM_TEMPLATE_MAPPING_OPTIONS_MAPPINGS_SQL
								= new StringBuilder("select  pm.name as `name`,  ifnull(cvm.`values`,pld.name) as `value`, pld.code as `code` ")
								.append("from am_custom_template_column_value_mapping cvm ")
								.append("INNER JOIN am_custom_template_column_mapping cm ON cvm.custom_template_mapping_id= cm.id  AND cm.custom_template_name_id=? ")
								.append("INNER JOIN am_custom_template_options o ON  cvm.option_id = o.id ")
								.append("Right JOIN sm_pickup_list_details pld ON pld.id = o.pld_id ")
								.append("Right JOIN sm_pickup_master pm ON pm.pickup_master_id = pld.sm_pick_mst_id ")
								.append("where pm.name IN (?,?,?,?)")
								.toString();
	
	public static final String GET_COUNT_CUSTOM_TEMPLATE_TYPE = new StringBuilder(
			"select count(1) from am_custom_template_name ctn ")
			.append(" join am_user_master um on ctn.created_by=um.user_id ")
			.append("where ctn.pan in (?)  and ctn.pld_status = ?  ").toString();

	public static final String UPDATE_CUSTOM_TEMPLATE_PLD_STATUS = new StringBuilder(
			"update am_custom_template_name set pld_status= ?, modified_by = ?  where id = ? ").toString();	
	
	public static final String GET_CUSTOM_TEMPLATE_NAME_SQL = new StringBuilder(
			"SELECT id,pan,entity_id,pld_status,name FROM am_custom_template_name where pan = ? and name = ? and pld_template_id = ? ")
			.toString();
	
	public static final String GET_CUSTOM_TEMPLATE_NAME_BY_ID_SQL = new StringBuilder(
			"SELECT id,pan,entity_id,pld_status,name FROM am_custom_template_name where id = ? ")
			.toString();

	public static final String INSERT_TEMPLATE_SAMPLE_DATA_SQL = new StringBuilder("INSERT INTO am_template_sample_data(am_custom_template_column_mapping_id,column_name,column_value,created_at,created_by) ")
			.append(" VALUES(?,?,?,now(),?)").toString();
	
	public static final String GET_CUSTOM_TEMPLATE_DETAILS_SQL = new StringBuilder(
			"SELECT cc.column_name, cm.pld_template_id , cc.id , cm.template_column , is_auto_map , is_mandatory , cc.data_type , cc.size , cm.id as customTemplateColumnMappingId\r\n")
			.append("FROM am_custom_template_column_mapping  cm\r\n")
			.append("join am_template_column_configuration cc on cc.id=cm.am_template_column_configuration_id  \r\n")
			.append("and custom_template_name_id=?").toString();
	
	public static final String GET_CUSTOM_TEMPLATE_OPTIONS_VALUE_MAPPING_SQL = new StringBuilder(
			"select cto.id as option_id,custom_template_mapping_id ,pld.name,template_column_config_id,\r\n")
			.append( "cvm.values , cvm.id \r\n")
			.append( " from am_custom_template_options cto \r\n")
			.append( "join sm_pickup_list_details pld on pld.id=cto.pld_id \r\n")
			.append( "left join am_custom_template_column_value_mapping cvm on cto.id=cvm.option_id  and custom_template_mapping_id=? \r\n")
			.append( "where template_column_config_id = ? \r\n")
			.toString();

	public static final String GET_CUSTOM_TEMPLATE_COLUMN_MAPPING_BY_ID_SQL  = new StringBuilder("select template_column,is_auto_map from am_custom_template_column_mapping where id = ?").toString();
	
	public static final String UPDATE_CUSTOM_TEMPLATE_MAPPING = new StringBuilder("update am_custom_template_column_mapping\r\n")
			.append( "set  template_column =? ,is_auto_map =? ,modified_at=now() , modified_by =? where id = ?").toString();
	
	public static final String GET_CUSTOM_TEMPLATE_COLUMN_VALUE_MAPPING_BY_ID_SQL =new StringBuilder("select cvm.values,id,cvm.option_id from am_custom_template_column_value_mapping cvm where id = ?").toString();
	
	public static final String GET_CUSTOM_TEMPLATE_COLUMN_VALUE_MAPPING_SQL =new StringBuilder
			("select cvm.values,id,cvm.option_id from am_custom_template_column_value_mapping cvm where custom_template_mapping_id =?\r\n")
			.append( " and option_id =? ").toString();
	
	public static final String UPDATE_CUSTOM_TEMPLATE_COLUMN_VALUE_MAPPING_SQL = new StringBuilder
			("update am_custom_template_column_value_mapping cvm set  cvm.values =?  where cvm.id = ?").toString();
	
			public static final String GET_ENTITY_MASTER_SQL = new StringBuilder(
					"SELECT  em.entity_id, em.entity_type_id, em.parent_id, em.parent_group_id, em.business_name, em.trade_name, em.pan, em.tan, em.gstin, em.gstin_username, em.mobile_no, em.email_id, em.curr_turnover, em.state_code, em.city_code, em.ward, em.center_jurisdiction, em.composition, em.date_commencement, em.cern_no, em.service_tax_no, em.vat_no, em.sales_tax_no, em.iec_no, em.temp_reg_no, em.cin_no, em.business_nature, em.business_constitution, em.alt_email, em.alt_mobile_no, em.alt_tel, em.out_hsn_summ_conf, em.in_hsn_summ_conf, em.itc_avail_conf, em.template_type_id, em.user_count_limit, em.gstin_count_limit, em.transaction_count_limit, em.entity_status\r\n")
					.append("FROM am_entity_master em    \r\n")
					.append("INNER JOIN am_user_master um ON um.entity_id = em.entity_id     \r\n")
					.append("INNER JOIN sm_entity_type et ON et.entity_type_id = em.entity_type_id\r\n")
					.append("WHERE um.user_id = ?     AND et.entity_type_id != ? limit 1").toString();

			public static final String GET_ENTITY_MASTER_LIST_SQL = new StringBuilder(
					"SELECT em.entity_id, from_base64(em.pan) pan,   from_base64(em.gstin) gstin,  from_base64(em.gstin_username),   from_base64(em.email_id) \r\n")
					.append("                FROM  am_entity_master em where ").toString();

			public static final String GET_ENTITY_CLOUD_CREDENTIALS_SQL = new StringBuilder(
					"SELECT id,    entity_id,    type,    url,    user_id,    password,    is_active , container_name \r\n")
					.append(" FROM sm_entity_cloud_credentials where entity_id = ? ").toString();

			public static final String GET_PICKUP_MASTER_DEFAULT_TEMPLATE_SQL = new StringBuilder(
					"Select pld.id,sm_pick_mst_id, pld.name, code, short_desc, long_desc,pick_key, sort_order,pld.status, pld.created_at, pld.created_by,from_base64(first_name) userName \r\n")
					.append(" from sm_pickup_list_details pld\r\n")
					.append(" INNER JOIN sm_pickup_master pm ON pm.pickup_master_id = pld.sm_pick_mst_id  ")
					.append("  join am_user_master um on pld.created_by=um.user_id  ")
					.append(" where pm.name =?  and pick_key=2 order by pld.sort_order asc ").toString();

			public static final String GET_CUSTOM_TEMPLATE_SAMPLE_DATA = new StringBuilder(
					"SELECT tsd.column_name , tsd.column_value,custom_template_name_id FROM am_template_sample_data tsd\r\n")
					.append("join am_custom_template_column_mapping cm on cm.id=tsd.am_custom_template_column_mapping_id \r\n")
					.append("and cm.custom_template_name_id = ? order by tsd.id asc ").toString();

}
