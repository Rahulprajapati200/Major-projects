package com.bdo.bvms.common.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.dao.CommonDao;
import com.bdo.bvms.common.dao.InwardRegisterDao;
import com.bdo.bvms.common.dao.UploadTransDao;
import com.bdo.bvms.common.dto.InvoiceDetailsDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UpadateResponseDto;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.itc.validation.ValidateItcDetails;
import com.bdo.bvms.common.payment.validation.ValidatePaymentDetails;
import com.bdo.bvms.common.service.InvoiceUpdateDetailsService;
import com.bdo.bvms.common.service.InwardUpload;
import com.bdo.bvms.common.util.AppUtil;
import com.bdo.bvms.common.validationrule.DroolUtil;
import com.bdo.bvms.common.validationrule.ValidationRuleTds;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class InvoiceUpdateDetailServiceImpl implements InvoiceUpdateDetailsService {

	@Autowired
    InwardRegisterDao commonCommunicationDao;
	
	@Autowired
	InwardRegisterDao inwardRegisterDao;

	@Autowired
	InwardUpload inwardUpload;
	
	List<String>tdsSection=new ArrayList<>();
	
	@Autowired
    CommonDao commonDao;

	@Autowired
    UploadTransDao uploadTransDao;
	
	@Override
	public UpadateResponseDto updateAndValidateDetails(InvoiceDetailsDTO invoiceDetailDto)
			throws IOException, VendorInvoiceServerException {

		log.info("Validating Manual Update Invoice");
		UploadReqDTO uploadReqDTO = new UploadReqDTO();
		uploadReqDTO.setUserId(invoiceDetailDto.getUserId());
		uploadReqDTO.setBatchNo(invoiceDetailDto.getBatchNo());
		UpadateResponseDto upadateResponseDto=new UpadateResponseDto();
		try {
			
			commonCommunicationDao.deletePaymentItem(invoiceDetailDto.getPaymentDeletedIds());
			commonCommunicationDao.deleteTdsItems(invoiceDetailDto.getTdsDeletedIds());
			commonCommunicationDao.deleteInvoicetItems(invoiceDetailDto.getItemDeletedIds(),invoiceDetailDto.getDocType());
			
		List<InwardInvoiceCDNTemplateDTO> inwardInvoiceINVTemplateDTOList = new ArrayList<>();
		List<InwardInvoiceCDNTemplateDTO> inwardInvoiceCDNTemplateDTOList = new ArrayList<>();
		List<InwardInvoiceCDNTemplateDTO> inwardInvoiceCDNTemplateDTOFinalErrorList = new ArrayList<>();
		List<PaymentDetails>paymentDetailsFinalErrorList=new ArrayList<>();
		List<TdsDetails>tdsDetailsFinalSuccessList=new ArrayList<>();
		List<PaymentDetails>paymentDetailsFinalSuccessList=new ArrayList<>();
		List<TdsDetails>tdsDetailsFinalErrorList=new ArrayList<>();
		List<ItcDto>itcFinalFinalErrorList=new ArrayList<>();
		List<ItcDto>itcFinalFinalSuccessList=new ArrayList<>();
		ValidatePaymentDetails paymentValidation=new ValidatePaymentDetails();
		ValidateItcDetails itcValidation=new ValidateItcDetails();
		Map<String, String> codesMap = commonDao.getErrorCodesDescription();
		
		invoiceDetailDto.getPaymentDetails().forEach(payment->
		{
			payment.setValid(true);
			payment.setGstinUinOfRecipient(invoiceDetailDto.getTaxpayergstin());
			payment.setDocType(invoiceDetailDto.getDocType());
			payment.setGstinOfSupplier(invoiceDetailDto.getSupplierGSTIN());
			payment.setSupplierName(invoiceDetailDto.getVendorlegalname());
			payment.setGstinOfSupplier(invoiceDetailDto.getSupplierGSTIN());
			payment.setInwardNo(invoiceDetailDto.getInvoiceno());
			payment.setInwardDate(invoiceDetailDto.getInvoicedate());
			payment.setPanOfSupplier((StringUtils.isNotBlank(invoiceDetailDto.getSupplierGSTIN())
                    && invoiceDetailDto.getSupplierGSTIN().length() == 15)?
                    invoiceDetailDto.getSupplierGSTIN().substring(2, 12):"");
			
			payment.setPanOfRecipient((StringUtils.isNotBlank(invoiceDetailDto.getTaxpayergstin())
                    && invoiceDetailDto.getTaxpayergstin().length() == 15)?
                    invoiceDetailDto.getTaxpayergstin().substring(2, 12):"");
			paymentValidation.validatePaymentDetails(payment);
			if(!payment.isValid())
			{	
			    payment.setErrorDescriptionList(payment.getErrorDescriptionList().append(getErrorCodeDescription(payment,payment.getErrorCodeList().toString(), codesMap)));
			    paymentDetailsFinalErrorList.add(payment);
			}
			else
			{
				paymentDetailsFinalSuccessList.add(payment);
			}
		});

		
		tdsSection = commonCommunicationDao.getTdsSectionList();
		ValidationRuleTds validationRuleTds= new ValidationRuleTds();
		invoiceDetailDto.getTdsDetails().forEach(tdsDetail->
		{
			if(!isNumeric(tdsDetail.getChallanAmount()))
			{
				tdsDetail.setChallanAmount("0.0");
			}
			if(!isNumeric(tdsDetail.getAmountofProvAdv()))
			{
				tdsDetail.setAmountofProvAdv("0.0");
			}
			if(!isNumeric(tdsDetail.getPaymentAmount()))
			{
				tdsDetail.setPaymentAmount("0.0");
			}
			if(!isNumeric(tdsDetail.getGrossAmount()))
			{
				tdsDetail.setGrossAmount("0.0");
			}
			if(!isNumeric(tdsDetail.getBalOutstanding()))
			{
				tdsDetail.setBalOutstanding("0.0");
			}
			tdsDetail.setValid(true);
			tdsDetail.setVendorCodeErp(invoiceDetailDto.getVendorCodeErp());
			tdsDetail.setGstinUinOfRecipient(invoiceDetailDto.getTaxpayergstin());
			tdsDetail.setGstinOfSupplier(invoiceDetailDto.getSupplierGSTIN());
			tdsDetail.setDocType(invoiceDetailDto.getDocType());
			tdsDetail.setSupplierName(invoiceDetailDto.getVendorlegalname());
			tdsDetail.setDocNo(invoiceDetailDto.getDocNo());
			tdsDetail.setDocDate(invoiceDetailDto.getDocDate());
			tdsDetail.setInwardNo(invoiceDetailDto.getInvoiceno());
			tdsDetail.setInwardAate(invoiceDetailDto.getInvoicedate());
			tdsDetail.setDebitglId(invoiceDetailDto.getDebitGlId());
			tdsDetail.setDebitglName(invoiceDetailDto.getDebitGlName());
			tdsDetail.setCreditglId(invoiceDetailDto.getCreditGlId());
			tdsDetail.setCreditglName(invoiceDetailDto.getCreditGlName());
			
			tdsDetail.setPanOfSupplier((StringUtils.isNotBlank(invoiceDetailDto.getSupplierGSTIN())
                    && invoiceDetailDto.getSupplierGSTIN().length() == 15)?
                    invoiceDetailDto.getSupplierGSTIN().substring(2, 12):"");
			
			tdsDetail.setPanOfRecipient((StringUtils.isNotBlank(invoiceDetailDto.getTaxpayergstin())
                    && invoiceDetailDto.getTaxpayergstin().length() == 15)?
                    invoiceDetailDto.getTaxpayergstin().substring(2, 12):"");
			
			validationRuleTds.validateTds(tdsDetail,tdsSection);
			
			if(!tdsDetail.isValid())
			{	
				tdsDetail.setErrorDescriptionList(tdsDetail.getErrorDescriptionList().append(getErrorCodeDescription(tdsDetail,tdsDetail.getErrorCodeList().toString(), codesMap)));
			    tdsDetailsFinalErrorList.add(tdsDetail);
			}
			else
			{
				tdsDetailsFinalSuccessList.add(tdsDetail);
			}
		});
		
		
		
		if(!paymentDetailsFinalSuccessList.isEmpty())
		{
		    commonCommunicationDao.updatePaymentDetailTable(paymentDetailsFinalSuccessList,uploadReqDTO);
		}
		if(!tdsDetailsFinalSuccessList.isEmpty())
		{
    	    commonCommunicationDao.updateTdsDetailTable(tdsDetailsFinalSuccessList,uploadReqDTO);
		}
		
		
		BigDecimal totalInvoiceValue = new BigDecimal(0);
		if ("CRN".equals(invoiceDetailDto.getDocType()) || "DBN".equals(invoiceDetailDto.getDocType())) {
			for (int i = 0; i < invoiceDetailDto.getEditItemDetail().size(); i++) {
				InwardInvoiceCDNTemplateDTO inwardInvoiceCDNTemplateDTO = new InwardInvoiceCDNTemplateDTO();
				inwardInvoiceCDNTemplateDTO.setGstinOfRecipient(invoiceDetailDto.getTaxpayergstin());
				inwardInvoiceCDNTemplateDTO.setFillingPeriod(invoiceDetailDto.getFp());
				inwardInvoiceCDNTemplateDTO.setSubLocation(invoiceDetailDto.getSubLocation());
			
				inwardInvoiceCDNTemplateDTO.setSupplyType(invoiceDetailDto.getTranType());
				inwardInvoiceCDNTemplateDTO.setGstinOfSupplier(invoiceDetailDto.getVendorgstin());
				inwardInvoiceCDNTemplateDTO.setSupplierName(invoiceDetailDto.getVendorlegalname());
				inwardInvoiceCDNTemplateDTO.setInwardNo(invoiceDetailDto.getInvoiceno());
				inwardInvoiceCDNTemplateDTO.setInwardDate(invoiceDetailDto.getInvoicedate());
                
				inwardInvoiceCDNTemplateDTO.setSgstAmt(invoiceDetailDto.getEditItemDetail().get(i).getSgst());
				inwardInvoiceCDNTemplateDTO
						.setItemDescription(invoiceDetailDto.getEditItemDetail().get(i).getDescription());
				inwardInvoiceCDNTemplateDTO.setHsnSacCode(invoiceDetailDto.getEditItemDetail().get(i).getHsn());
				inwardInvoiceCDNTemplateDTO.setHsnCode(invoiceDetailDto.getEditItemDetail().get(i).getHsn());
				inwardInvoiceCDNTemplateDTO.setUom(invoiceDetailDto.getEditItemDetail().get(i).getUnit());
				inwardInvoiceCDNTemplateDTO.setQuantity(invoiceDetailDto.getEditItemDetail().get(i).getQty());
				inwardInvoiceCDNTemplateDTO.setAssAmt(invoiceDetailDto.getEditItemDetail().get(i).getTaxable());
				inwardInvoiceCDNTemplateDTO.setDocNo(invoiceDetailDto.getDocNo());
				inwardInvoiceCDNTemplateDTO.setGstinOfSupplier(invoiceDetailDto.getSupplierGSTIN());
				inwardInvoiceCDNTemplateDTO.setDiffPercent(invoiceDetailDto.getDifferentialPercent());
				inwardInvoiceCDNTemplateDTO.setImportBillOfEntryNo(invoiceDetailDto.getImportBillofEntryNo());
				inwardInvoiceCDNTemplateDTO.setImportBillOfEntryAmt(invoiceDetailDto.getImportBillofEntryAmt());
				inwardInvoiceCDNTemplateDTO.setOrgImportBillOfEntryAmt(invoiceDetailDto.getImportBillofEntryAmt());
				inwardInvoiceCDNTemplateDTO.setDebitGlId(invoiceDetailDto.getDebitGlId());
				inwardInvoiceCDNTemplateDTO.setDebitGlName(invoiceDetailDto.getDebitGlName());
				inwardInvoiceCDNTemplateDTO.setCreditGlId(invoiceDetailDto.getCreditGlId());
				inwardInvoiceCDNTemplateDTO.setItemRate(invoiceDetailDto.getEditItemDetail().get(i).getItemRate());
				inwardInvoiceCDNTemplateDTO.setCreditGlName(invoiceDetailDto.getCreditGlName());
				inwardInvoiceCDNTemplateDTO.setDocDate(invoiceDetailDto.getDocDate());
				String reverseCharge = invoiceDetailDto.getReverseCharge();
				inwardInvoiceCDNTemplateDTO.setReverseCharge(invoiceDetailDto.getReverseCharge());
				if ("NULL".equalsIgnoreCase(reverseCharge) || StringUtils.isBlank(reverseCharge)
						|| "0".equals(reverseCharge)) {
					reverseCharge = "N";
				}
				inwardInvoiceCDNTemplateDTO.setPort(invoiceDetailDto.getPort());
				inwardInvoiceCDNTemplateDTO.setImportBillOfEntryDate(invoiceDetailDto.getImportBillofDate());

				if (inwardInvoiceCDNTemplateDTO.getImportBillOfEntryDate().equals("00-01-1900")
						|| inwardInvoiceCDNTemplateDTO.getImportBillOfEntryDate().equals("31/12/1899")
						|| inwardInvoiceCDNTemplateDTO.getImportBillOfEntryDate().equals("31-12-1899")) {
					inwardInvoiceCDNTemplateDTO.setImportBillOfEntryDate("0");
				}

				inwardInvoiceCDNTemplateDTO.setCgstAmt(invoiceDetailDto.getEditItemDetail().get(i).getCgst());

				inwardInvoiceCDNTemplateDTO.setIgstAmt(invoiceDetailDto.getEditItemDetail().get(i).getIgst());
				if (Float.parseFloat(invoiceDetailDto.getEditItemDetail().get(i).getIgst()) > 0.0) {
					inwardInvoiceCDNTemplateDTO.setIgstRate(invoiceDetailDto.getEditItemDetail().get(i).getGstRate());
				} else {
					inwardInvoiceCDNTemplateDTO.setIgstRate("0.00");
				}
				if (((Float.parseFloat("0.0") < Float
						.parseFloat(invoiceDetailDto.getEditItemDetail().get(i).getSgst())))
						&& ((Float.parseFloat("0.0") < Float
								.parseFloat(invoiceDetailDto.getEditItemDetail().get(i).getCgst())))) {
					BigDecimal cgst = new BigDecimal(invoiceDetailDto.getEditItemDetail().get(i).getGstRate());
					cgst = cgst.divide(new BigDecimal(2));

					inwardInvoiceCDNTemplateDTO.setCgstRate(cgst.toString());

					BigDecimal sgst = new BigDecimal(invoiceDetailDto.getEditItemDetail().get(i).getGstRate());
					sgst = sgst.divide(new BigDecimal(2));

					inwardInvoiceCDNTemplateDTO.setSgstRate(sgst.toString());
					inwardInvoiceCDNTemplateDTO.setIgstRate("0.0");

				}
				inwardInvoiceCDNTemplateDTO.setCessRate(invoiceDetailDto.getEditItemDetail().get(i).getCessRate());
				inwardInvoiceCDNTemplateDTO.setYearId(invoiceDetailDto.getEditItemDetail().get(i).getYearId());
				inwardInvoiceCDNTemplateDTO.setCessAmount(invoiceDetailDto.getEditItemDetail().get(i).getCess());
				inwardInvoiceCDNTemplateDTO.setInwardGrossTotalAmount(invoiceDetailDto.getInvoicevalue());


				BigDecimal itemValue=new BigDecimal(invoiceDetailDto.getEditItemDetail().get(i).getTotalitemvalue());
				totalInvoiceValue=totalInvoiceValue.add(itemValue);
				inwardInvoiceCDNTemplateDTO.setPlaceOfSupply(invoiceDetailDto.getPos());
				inwardInvoiceCDNTemplateDTO
						.setItcIneligibleReversalIndicator(invoiceDetailDto.getEditItemDetail().get(i).getReversalIndicator());
				inwardInvoiceCDNTemplateDTO
						.setItcIneligibleReversalPercentage(invoiceDetailDto.getEditItemDetail().get(i).getReversalPercentage());
				inwardInvoiceCDNTemplateDTO.setInputType(invoiceDetailDto.getInputType());
				inwardInvoiceCDNTemplateDTO.setOrgInputType(invoiceDetailDto.getInputType());
				inwardInvoiceCDNTemplateDTO.setOrgInvoiceCategory(invoiceDetailDto.getTranType());
				
				inwardInvoiceCDNTemplateDTO.setExcelDocType(invoiceDetailDto.getDocType());
				inwardInvoiceCDNTemplateDTO.setDocType(invoiceDetailDto.getDocType());
				inwardInvoiceCDNTemplateDTO.setOrgDocType(invoiceDetailDto.getDocType());
				inwardInvoiceCDNTemplateDTO.setOrgSupplyType(invoiceDetailDto.getTranType());
				inwardInvoiceCDNTemplateDTO.setOrgImportType(invoiceDetailDto.getInputType());
				inwardInvoiceCDNTemplateDTO.setOrgQuantity(invoiceDetailDto.getEditItemDetail().get(i).getQty());
				inwardInvoiceCDNTemplateDTO.setOrgItemRate(invoiceDetailDto.getEditItemDetail().get(i).getItemRate());
				inwardInvoiceCDNTemplateDTO.setOrgAssAmt(invoiceDetailDto.getEditItemDetail().get(i).getTaxable());

				inwardInvoiceCDNTemplateDTO.setOrgCessRate(invoiceDetailDto.getEditItemDetail().get(i).getCessRate());
				inwardInvoiceCDNTemplateDTO.setOrgCessAmt(invoiceDetailDto.getEditItemDetail().get(i).getCess());
				inwardInvoiceCDNTemplateDTO.setOrgInwardGrossTotalAmount(invoiceDetailDto.getInvoicevalue());
				
				inwardInvoiceCDNTemplateDTO.setImportBillOfEntryAmt("0");
				inwardInvoiceCDNTemplateDTO.setOrgImportBillOfEntryAmt("0");
				inwardInvoiceCDNTemplateDTO.setSupplierStateCode(invoiceDetailDto.getSupplierStateCode());
				if(StringUtils.isNotBlank(inwardInvoiceCDNTemplateDTO.getSupplierStateCode()) && inwardInvoiceCDNTemplateDTO.getSupplierStateCode().length()==1)
				{
					inwardInvoiceCDNTemplateDTO.setSupplierStateCode("0"+inwardInvoiceCDNTemplateDTO.getSupplierStateCode());
				}
				String itcIneligibleReversalIndicator = invoiceDetailDto.getEditItemDetail().get(i).getReversalIndicator();
				String itcPercent = invoiceDetailDto.getEditItemDetail().get(i).getReversalPercentage();

				String sgstAmt = inwardInvoiceCDNTemplateDTO.getSgstAmt();
				String cgstAmt = inwardInvoiceCDNTemplateDTO.getCgstAmt();
				String igstAmt = inwardInvoiceCDNTemplateDTO.getIgstAmt();
				String cessAmt = inwardInvoiceCDNTemplateDTO.getCessAmount();

				if ("NULL".equalsIgnoreCase(sgstAmt) || StringUtils.isBlank(sgstAmt) || DroolUtil.isEmpty(sgstAmt)) {
					sgstAmt = "0";
				}
				if ("NULL".equalsIgnoreCase(cgstAmt) || StringUtils.isBlank(cgstAmt) || DroolUtil.isEmpty(cgstAmt)) {
					cgstAmt = "0";
				}
				if ("NULL".equalsIgnoreCase(igstAmt) || StringUtils.isBlank(igstAmt) || DroolUtil.isEmpty(igstAmt)) {
					igstAmt = "0";
				}
				if ("NULL".equalsIgnoreCase(cessAmt) || StringUtils.isBlank(cessAmt) || DroolUtil.isEmpty(cessAmt)) {
					cessAmt = "0";
				}

				if (("NULL".equalsIgnoreCase(itcIneligibleReversalIndicator)
						|| StringUtils.isBlank(itcIneligibleReversalIndicator)
						|| DroolUtil.isEmpty(itcIneligibleReversalIndicator))
						&& ("NULL".equalsIgnoreCase(itcPercent) || StringUtils.isBlank(itcPercent)
								|| DroolUtil.isEmpty(itcPercent))) {
					itcPercent = "100";
				}

				String grossTotalAmt = invoiceDetailDto.getEditItemDetail().get(i).getTotalitemvalue();
				inwardInvoiceCDNTemplateDTO.setInwardGrossTotalAmount(AppUtil.formatRateAmoutValues(grossTotalAmt));
				
				
				inwardInvoiceCDNTemplateDTO.setInvoiceCategory(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory());
				inwardInvoiceCDNTemplateDTO.setUserSupplyCat(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory());

				inwardInvoiceCDNTemplateDTO.setItemName(invoiceDetailDto.getEditItemDetail().get(i).getDescription());

				String inwardTaxableAmt = invoiceDetailDto.getEditItemDetail().get(i).getTaxable();
				inwardInvoiceCDNTemplateDTO.setInwardTaxableAmt(inwardTaxableAmt);

				String cessRate = invoiceDetailDto.getEditItemDetail().get(i).getCessRate();
				inwardInvoiceCDNTemplateDTO.setCessRate(AppUtil.formatRateAmoutValues(cessRate));

				if (StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getCessRate())) {
					inwardInvoiceCDNTemplateDTO.setCessRate(String.valueOf("0"));
				}
				inwardInvoiceCDNTemplateDTO.setImportType(invoiceDetailDto.getInputType());
				String pos = invoiceDetailDto.getPos();
				if (StringUtils.isNotBlank(pos) && pos.length() == 1) {
					inwardInvoiceCDNTemplateDTO.setPlaceOfSupply("0" + pos);
				} else {
					inwardInvoiceCDNTemplateDTO.setPlaceOfSupply(pos);
				}
				inwardInvoiceCDNTemplateDTO.setSupplyType(invoiceDetailDto.getTranType());
				
				if ("NIL".equalsIgnoreCase(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory())) {
					inwardInvoiceCDNTemplateDTO
							.setNilRatedAmt(AppUtil.formatRateAmoutValues(inwardInvoiceCDNTemplateDTO.getOrgAssAmt()));
				} else {
					inwardInvoiceCDNTemplateDTO.setNilRatedAmt(AppUtil.formatRateAmoutValues("0.00"));
				}
				if ("EXM".equalsIgnoreCase(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory())) {
					inwardInvoiceCDNTemplateDTO
							.setExemptedAmt(AppUtil.formatRateAmoutValues(inwardInvoiceCDNTemplateDTO.getOrgAssAmt()));
				} else {
					inwardInvoiceCDNTemplateDTO.setExemptedAmt(AppUtil.formatRateAmoutValues("0.00"));
				}
				if ("NON".equalsIgnoreCase(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory())) {
					inwardInvoiceCDNTemplateDTO
							.setNonGstAmt(AppUtil.formatRateAmoutValues(inwardInvoiceCDNTemplateDTO.getOrgAssAmt()));
				} else {
					inwardInvoiceCDNTemplateDTO.setNonGstAmt(AppUtil.formatRateAmoutValues("0.00"));
				}

				if ("COMP".equalsIgnoreCase(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory())) {
					inwardInvoiceCDNTemplateDTO.setCompositionAmt(
							AppUtil.formatRateAmoutValues(inwardInvoiceCDNTemplateDTO.getOrgAssAmt()));
				} else {
					inwardInvoiceCDNTemplateDTO.setCompositionAmt(AppUtil.formatRateAmoutValues("0.00"));
				}

				inwardInvoiceCDNTemplateDTO.setSgstAmt(sgstAmt);
				inwardInvoiceCDNTemplateDTO.setCgstAmt(cgstAmt);
				inwardInvoiceCDNTemplateDTO.setIgstAmt(igstAmt);
				inwardInvoiceCDNTemplateDTO.setCessAmount(cessAmt);

				if (!isNumeric(inwardInvoiceCDNTemplateDTO.getCgstRate())) {
					inwardInvoiceCDNTemplateDTO.setCgstRate("0.0");
				}

				if (!isNumeric(inwardInvoiceCDNTemplateDTO.getSgstRate())) {
					inwardInvoiceCDNTemplateDTO.setSgstRate("0.0");
				}
				if (!isNumeric(sgstAmt)) {
					sgstAmt = "0.0";
				}

				if (!isNumeric(sgstAmt)) {
					sgstAmt = "0.0";
				}

				if (!isNumeric(cgstAmt)) {
					cgstAmt = "0.0";
				}

				if (!isNumeric(cessAmt)) {
					cessAmt = "0.0";
				}

				if (!isNumeric(igstAmt)) {
					igstAmt = "0.0";
				}

				BigDecimal igst = new BigDecimal(inwardInvoiceCDNTemplateDTO.getIgstAmt());
				BigDecimal sgst = new BigDecimal(inwardInvoiceCDNTemplateDTO.getSgstAmt());
				BigDecimal cgst = new BigDecimal(inwardInvoiceCDNTemplateDTO.getCgstAmt());
				BigDecimal cess = new BigDecimal(inwardInvoiceCDNTemplateDTO.getCessAmount());

				BigDecimal itcIgst = new BigDecimal(igstAmt);
				BigDecimal itcSgst = new BigDecimal(sgstAmt);
				BigDecimal itcCgst = new BigDecimal(cgstAmt);
				BigDecimal itcCess = new BigDecimal(cessAmt);

				BigDecimal totalTaxAmt = new BigDecimal(0);
				totalTaxAmt = totalTaxAmt.add(sgst).add(cgst).add(igst).add(cess);

				inwardInvoiceCDNTemplateDTO.setTotalTaxAmount(totalTaxAmt.toString());

				if (DroolUtil.containsNumbersOnly(itcPercent, 1)) {
					itcSgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), sgst);
					itcCgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), cgst);
					itcIgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), igst);
					itcCess = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), cess);
				}
				inwardInvoiceCDNTemplateDTO.setItcSgstAmt(itcSgst.toString());
				inwardInvoiceCDNTemplateDTO.setItcCgstAmt(itcCgst.toString());
				inwardInvoiceCDNTemplateDTO.setItcIgstAmt(itcIgst.toString());
				inwardInvoiceCDNTemplateDTO.setItcCessAmt(itcCess.toString());

				totalTaxAmt = totalTaxAmt.add(sgst).add(cgst).add(igst).add(cess);
				inwardInvoiceCDNTemplateDTO.setInwardTotalTaxAmt(totalTaxAmt.toString());

				BigDecimal totalITCTaxAmt = new BigDecimal(0);
				totalITCTaxAmt = totalITCTaxAmt.add(itcSgst).add(itcCgst).add(itcIgst).add(itcCess);
				inwardInvoiceCDNTemplateDTO.setInwardTotalTaxAmt(totalTaxAmt.toString());
				inwardInvoiceCDNTemplateDTO.setTotalItcAmt(totalITCTaxAmt.toString());
				inwardInvoiceCDNTemplateDTO.setTaxableAmount(inwardInvoiceCDNTemplateDTO.getAssAmt());

				inwardInvoiceCDNTemplateDTO.setGrossTotalAmount(grossTotalAmt);
				inwardInvoiceCDNTemplateDTO.setValid(true);
				inwardInvoiceCDNTemplateDTO.setOrgSgstRate(inwardInvoiceCDNTemplateDTO.getSgstRate());
				inwardInvoiceCDNTemplateDTO.setOrgSgstAmt(inwardInvoiceCDNTemplateDTO.getSgstAmt());
				inwardInvoiceCDNTemplateDTO.setOrgCgstRate(inwardInvoiceCDNTemplateDTO.getCgstRate());
				inwardInvoiceCDNTemplateDTO.setOrgCgstAmt(inwardInvoiceCDNTemplateDTO.getCgstAmt());
				inwardInvoiceCDNTemplateDTO.setOrgIgstRate(inwardInvoiceCDNTemplateDTO.getIgstRate());
				inwardInvoiceCDNTemplateDTO.setOrgIgstAmt(inwardInvoiceCDNTemplateDTO.getIgstAmt());

				if (StringUtils.isNotBlank(invoiceDetailDto.getTaxpayergstin())) {
					inwardInvoiceCDNTemplateDTO.setPanOfReciepiet(invoiceDetailDto.getTaxpayergstin().substring(2, 12));
				} else {
					inwardInvoiceCDNTemplateDTO.setPanOfReciepiet("");

				}
				
				
				if (StringUtils.isNotBlank(invoiceDetailDto.getSupplierGSTIN())) {
					inwardInvoiceCDNTemplateDTO.setPanOfSupplier(invoiceDetailDto.getSupplierGSTIN().substring(2, 12));
				} else {
					inwardInvoiceCDNTemplateDTO.setPanOfSupplier("");

				}
				if ("".equals(inwardInvoiceCDNTemplateDTO.getOrgInvoiceDate())
						|| "0".equals(inwardInvoiceCDNTemplateDTO.getOrgInvoiceDate())
						|| StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getOrgInvoiceDate())) {
					inwardInvoiceCDNTemplateDTO.setOrgInvoiceDate("0");
				}
				
				
				inwardInvoiceCDNTemplateDTO.setOrgInvoiceDate(invoiceDetailDto.getOrgInvoiceDate());
				inwardInvoiceCDNTemplateDTO.setOrgInvoiceNo(invoiceDetailDto.getOrgInvoiceNo());
				inwardInvoiceCDNTemplateDTO.setIrn(invoiceDetailDto.getIrn());
				inwardInvoiceCDNTemplateDTO.setAckDate(invoiceDetailDto.getAckDate());
				inwardInvoiceCDNTemplateDTO.setAckNo(invoiceDetailDto.getAckNo());
				
				
				inwardInvoiceCDNTemplateDTO.setTdsSection(invoiceDetailDto.getTdsSection());
				inwardInvoiceCDNTemplateDTO.setTdsRate(invoiceDetailDto.getTdsRate());
				inwardInvoiceCDNTemplateDTO.setTdsTaxAmount(invoiceDetailDto.getTdsTaxAmount());
				inwardInvoiceCDNTemplateDTO.setChallanNumber(invoiceDetailDto.getChallanNo());
				inwardInvoiceCDNTemplateDTO.setChallanDate(invoiceDetailDto.getChallanDate());
				inwardInvoiceCDNTemplateDTO.setChallanAmount(invoiceDetailDto.getChallanAmount());
				inwardInvoiceCDNTemplateDTO.setPeriodOfFiling(invoiceDetailDto.getPeriodFilingTdsReturn());
				inwardInvoiceCDNTemplateDTO.setInvoiceAgainstProvAdv(invoiceDetailDto.getInvoiceAgainstProvAdv());
				inwardInvoiceCDNTemplateDTO.setInwardNoProvAdv(invoiceDetailDto.getInwardNoProvAdv());
				inwardInvoiceCDNTemplateDTO.setInwardDateProvAdv(invoiceDetailDto.getInwardDateprovAdv());
				inwardInvoiceCDNTemplateDTO.setAmountOfProvAdv(invoiceDetailDto.getAmountofProvAdv());
				inwardInvoiceCDNTemplateDTO.setBalOutstanding(invoiceDetailDto.getBalOutstanding());
				
				inwardInvoiceCDNTemplateDTO.setDateOfPayment(invoiceDetailDto.getDateOfPayment());
				inwardInvoiceCDNTemplateDTO.setPaymentAmount(invoiceDetailDto.getAmountofPayment());
				inwardInvoiceCDNTemplateDTO.setPaymentRefNo(invoiceDetailDto.getPaymentRefNo());
				inwardInvoiceCDNTemplateDTO.setImportBillOfEntryDate(invoiceDetailDto.getImportBillofDate());
				
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf1());
				inwardInvoiceCDNTemplateDTO.setUdf2(invoiceDetailDto.getUdf2());
				inwardInvoiceCDNTemplateDTO.setUdf3(invoiceDetailDto.getUdf3());
				inwardInvoiceCDNTemplateDTO.setUdf4(invoiceDetailDto.getUdf4());
				inwardInvoiceCDNTemplateDTO.setUdf5(invoiceDetailDto.getUdf5());
				inwardInvoiceCDNTemplateDTO.setUdf6(invoiceDetailDto.getUdf6());
				inwardInvoiceCDNTemplateDTO.setUdf7(invoiceDetailDto.getUdf7());
				inwardInvoiceCDNTemplateDTO.setUdf8(invoiceDetailDto.getUdf8());
				inwardInvoiceCDNTemplateDTO.setUdf9(invoiceDetailDto.getUdf9());
				inwardInvoiceCDNTemplateDTO.setUdf10(invoiceDetailDto.getUdf10());
				inwardInvoiceCDNTemplateDTO.setUdf11(invoiceDetailDto.getUdf11());
				inwardInvoiceCDNTemplateDTO.setUdf12(invoiceDetailDto.getUdf12());
				inwardInvoiceCDNTemplateDTO.setUdf13(invoiceDetailDto.getUdf13());
				inwardInvoiceCDNTemplateDTO.setUdf14(invoiceDetailDto.getUdf14());
				inwardInvoiceCDNTemplateDTO.setUdf15(invoiceDetailDto.getUdf15());
				inwardInvoiceCDNTemplateDTO.setUdf16(invoiceDetailDto.getUdf16());
				inwardInvoiceCDNTemplateDTO.setUdf17(invoiceDetailDto.getUdf17());
				inwardInvoiceCDNTemplateDTO.setUdf18(invoiceDetailDto.getUdf18());
				inwardInvoiceCDNTemplateDTO.setUdf19(invoiceDetailDto.getUdf19());
				inwardInvoiceCDNTemplateDTO.setUdf20(invoiceDetailDto.getUdf20());
				inwardInvoiceCDNTemplateDTOList.add(inwardInvoiceCDNTemplateDTO);
			}

		} else if ("INV".equals(invoiceDetailDto.getDocType())) {
			for (int i = 0; i < invoiceDetailDto.getEditItemDetail().size(); i++) {

				InwardInvoiceCDNTemplateDTO inwardInvoiceCDNTemplateDTO = new InwardInvoiceCDNTemplateDTO();
				inwardInvoiceCDNTemplateDTO.setGstinOfRecipient(invoiceDetailDto.getTaxpayergstin());
				inwardInvoiceCDNTemplateDTO.setFillingPeriod(invoiceDetailDto.getFp());
				
				inwardInvoiceCDNTemplateDTO.setSupplyType(invoiceDetailDto.getTranType());
				inwardInvoiceCDNTemplateDTO.setGstinOfSupplier(invoiceDetailDto.getVendorgstin());
				inwardInvoiceCDNTemplateDTO.setSupplierName(invoiceDetailDto.getVendorlegalname());
				inwardInvoiceCDNTemplateDTO.setInwardNo(invoiceDetailDto.getInvoiceno());
				inwardInvoiceCDNTemplateDTO.setInwardDate(invoiceDetailDto.getInvoicedate());
				inwardInvoiceCDNTemplateDTO.setItemRate(invoiceDetailDto.getEditItemDetail().get(i).getItemRate());
				
				inwardInvoiceCDNTemplateDTO.setSubLocation(invoiceDetailDto.getSubLocation());
				inwardInvoiceCDNTemplateDTO
						.setItemDescription(invoiceDetailDto.getEditItemDetail().get(i).getDescription());
				inwardInvoiceCDNTemplateDTO.setHsnSacCode(invoiceDetailDto.getEditItemDetail().get(i).getHsn());
				inwardInvoiceCDNTemplateDTO.setHsnCode(invoiceDetailDto.getEditItemDetail().get(i).getHsn());
				inwardInvoiceCDNTemplateDTO.setUom(invoiceDetailDto.getEditItemDetail().get(i).getUnit());
				inwardInvoiceCDNTemplateDTO.setQuantity(invoiceDetailDto.getEditItemDetail().get(i).getQty());
				inwardInvoiceCDNTemplateDTO.setAssAmt(invoiceDetailDto.getEditItemDetail().get(i).getTaxable());
				inwardInvoiceCDNTemplateDTO.setSgstAmt(invoiceDetailDto.getEditItemDetail().get(i).getSgst());
				if (Float.parseFloat(invoiceDetailDto.getEditItemDetail().get(i).getIgst()) > 0.0) {
					inwardInvoiceCDNTemplateDTO.setIgstRate(invoiceDetailDto.getEditItemDetail().get(i).getGstRate());
				} else {
					inwardInvoiceCDNTemplateDTO.setIgstRate("0.00");
				}
				if (((Float.parseFloat("0.0") < Float
						.parseFloat(invoiceDetailDto.getEditItemDetail().get(i).getSgst())))
						&& ((Float.parseFloat("0.0") < Float
								.parseFloat(invoiceDetailDto.getEditItemDetail().get(i).getCgst())))) {
					BigDecimal cgst = new BigDecimal(invoiceDetailDto.getEditItemDetail().get(i).getGstRate());
					cgst = cgst.divide(new BigDecimal(2));

					inwardInvoiceCDNTemplateDTO.setCgstRate(cgst.toString());

					BigDecimal sgst = new BigDecimal(invoiceDetailDto.getEditItemDetail().get(i).getGstRate());
					sgst = sgst.divide(new BigDecimal(2));

					inwardInvoiceCDNTemplateDTO.setSgstRate(sgst.toString());
					inwardInvoiceCDNTemplateDTO.setIgstRate("0.0");

				}
				BigDecimal itemValue=new BigDecimal(invoiceDetailDto.getEditItemDetail().get(i).getTotalitemvalue());
				totalInvoiceValue=totalInvoiceValue.add(itemValue);
				inwardInvoiceCDNTemplateDTO.setDocNo(invoiceDetailDto.getDocNo());
				inwardInvoiceCDNTemplateDTO.setGstinOfSupplier(invoiceDetailDto.getSupplierGSTIN());
				inwardInvoiceCDNTemplateDTO.setDiffPercent(invoiceDetailDto.getDifferentialPercent());
				inwardInvoiceCDNTemplateDTO.setImportBillOfEntryNo(invoiceDetailDto.getImportBillofEntryNo());
				inwardInvoiceCDNTemplateDTO.setImportBillOfEntryAmt(invoiceDetailDto.getImportBillofEntryAmt());
				inwardInvoiceCDNTemplateDTO.setOrgImportBillOfEntryAmt(invoiceDetailDto.getImportBillofEntryAmt());
				inwardInvoiceCDNTemplateDTO.setDebitGlId(invoiceDetailDto.getDebitGlId());
				inwardInvoiceCDNTemplateDTO.setDebitGlName(invoiceDetailDto.getDebitGlName());
				inwardInvoiceCDNTemplateDTO.setCreditGlId(invoiceDetailDto.getCreditGlId());
				inwardInvoiceCDNTemplateDTO.setCreditGlName(invoiceDetailDto.getCreditGlName());
				inwardInvoiceCDNTemplateDTO.setDocDate(invoiceDetailDto.getDocDate());
				String reverseCharge = invoiceDetailDto.getReverseCharge();
				inwardInvoiceCDNTemplateDTO.setReverseCharge(invoiceDetailDto.getReverseCharge());
				if ("NULL".equalsIgnoreCase(reverseCharge) || StringUtils.isBlank(reverseCharge)
						|| "0".equals(reverseCharge)) {
					reverseCharge ="N";
				}
				inwardInvoiceCDNTemplateDTO.setPort(invoiceDetailDto.getPort());
				inwardInvoiceCDNTemplateDTO.setImportBillOfEntryDate(invoiceDetailDto.getImportBillofDate());

				if (inwardInvoiceCDNTemplateDTO.getImportBillOfEntryDate().equals("00-01-1900")
						|| inwardInvoiceCDNTemplateDTO.getImportBillOfEntryDate().equals("31/12/1899")
						|| inwardInvoiceCDNTemplateDTO.getImportBillOfEntryDate().equals("31-12-1899")) {
					inwardInvoiceCDNTemplateDTO.setImportBillOfEntryDate("0");
				}

				inwardInvoiceCDNTemplateDTO.setCgstAmt(invoiceDetailDto.getEditItemDetail().get(i).getCgst());

				inwardInvoiceCDNTemplateDTO.setIgstAmt(invoiceDetailDto.getEditItemDetail().get(i).getIgst());

				inwardInvoiceCDNTemplateDTO.setCessRate(invoiceDetailDto.getEditItemDetail().get(i).getCessRate());
				inwardInvoiceCDNTemplateDTO.setCessAmount(invoiceDetailDto.getEditItemDetail().get(i).getCess());
				inwardInvoiceCDNTemplateDTO.setInwardGrossTotalAmount(invoiceDetailDto.getInvoicevalue());
				
				inwardInvoiceCDNTemplateDTO.setPlaceOfSupply(invoiceDetailDto.getPos());
				inwardInvoiceCDNTemplateDTO
						.setItcIneligibleReversalIndicator(invoiceDetailDto.getEditItemDetail().get(i).getReversalIndicator());
				inwardInvoiceCDNTemplateDTO
						.setItcIneligibleReversalPercentage(invoiceDetailDto.getEditItemDetail().get(i).getReversalPercentage());
				inwardInvoiceCDNTemplateDTO.setInputType(invoiceDetailDto.getInputType());
				inwardInvoiceCDNTemplateDTO.setOrgInputType(invoiceDetailDto.getInputType());
				inwardInvoiceCDNTemplateDTO.setOrgInvoiceCategory(invoiceDetailDto.getTranType());
				inwardInvoiceCDNTemplateDTO.setExcelDocType(invoiceDetailDto.getDocType());
				inwardInvoiceCDNTemplateDTO.setDocType(invoiceDetailDto.getDocType());
				inwardInvoiceCDNTemplateDTO.setOrgDocType(invoiceDetailDto.getDocType());
				inwardInvoiceCDNTemplateDTO.setOrgSupplyType(invoiceDetailDto.getTranType());
				inwardInvoiceCDNTemplateDTO.setOrgImportType(invoiceDetailDto.getInputType());
				inwardInvoiceCDNTemplateDTO.setOrgQuantity(invoiceDetailDto.getEditItemDetail().get(i).getQty());
				inwardInvoiceCDNTemplateDTO.setOrgItemRate(invoiceDetailDto.getEditItemDetail().get(i).getItemRate());
				inwardInvoiceCDNTemplateDTO.setOrgAssAmt(invoiceDetailDto.getEditItemDetail().get(i).getTaxable());

				inwardInvoiceCDNTemplateDTO.setOrgCessRate(invoiceDetailDto.getEditItemDetail().get(i).getCessRate());
				inwardInvoiceCDNTemplateDTO.setOrgCessAmt(invoiceDetailDto.getEditItemDetail().get(i).getCess());
				inwardInvoiceCDNTemplateDTO.setOrgInwardGrossTotalAmount(invoiceDetailDto.getInvoicevalue());
				
				inwardInvoiceCDNTemplateDTO.setImportBillOfEntryAmt("0");
				inwardInvoiceCDNTemplateDTO.setOrgImportBillOfEntryAmt("0");
				inwardInvoiceCDNTemplateDTO.setSupplierStateCode(invoiceDetailDto.getSupplierStateCode());
				if(StringUtils.isNotBlank(inwardInvoiceCDNTemplateDTO.getSupplierStateCode()) && inwardInvoiceCDNTemplateDTO.getSupplierStateCode().length()==1)
				{
					inwardInvoiceCDNTemplateDTO.setSupplierStateCode("0"+inwardInvoiceCDNTemplateDTO.getSupplierStateCode());
				}
				String itcIneligibleReversalIndicator = invoiceDetailDto.getEditItemDetail().get(i).getReversalIndicator();
				String itcPercent = invoiceDetailDto.getEditItemDetail().get(i).getReversalPercentage();

				String sgstAmt = inwardInvoiceCDNTemplateDTO.getSgstAmt();
				String cgstAmt = inwardInvoiceCDNTemplateDTO.getCgstAmt();
				String igstAmt = inwardInvoiceCDNTemplateDTO.getIgstAmt();
				String cessAmt = inwardInvoiceCDNTemplateDTO.getCessAmount();

				if ("NULL".equalsIgnoreCase(sgstAmt) || StringUtils.isBlank(sgstAmt) || DroolUtil.isEmpty(sgstAmt)) {
					sgstAmt = "0";
				}
				if ("NULL".equalsIgnoreCase(cgstAmt) || StringUtils.isBlank(cgstAmt) || DroolUtil.isEmpty(cgstAmt)) {
					cgstAmt = "0";
				}
				if ("NULL".equalsIgnoreCase(igstAmt) || StringUtils.isBlank(igstAmt) || DroolUtil.isEmpty(igstAmt)) {
					igstAmt = "0";
				}
				if ("NULL".equalsIgnoreCase(cessAmt) || StringUtils.isBlank(cessAmt) || DroolUtil.isEmpty(cessAmt)) {
					cessAmt = "0";
				}

				if (("NULL".equalsIgnoreCase(itcIneligibleReversalIndicator)
						|| StringUtils.isBlank(itcIneligibleReversalIndicator)
						|| DroolUtil.isEmpty(itcIneligibleReversalIndicator))
						&& ("NULL".equalsIgnoreCase(itcPercent) || StringUtils.isBlank(itcPercent)
								|| DroolUtil.isEmpty(itcPercent))) {
					itcPercent = "100";
				}

				String grossTotalAmt = invoiceDetailDto.getEditItemDetail().get(i).getTotalitemvalue();
				inwardInvoiceCDNTemplateDTO.setInwardGrossTotalAmount(AppUtil.formatRateAmoutValues(grossTotalAmt));
				

				inwardInvoiceCDNTemplateDTO.setInvoiceCategory(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory());
				inwardInvoiceCDNTemplateDTO.setUserSupplyCat(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory());

				inwardInvoiceCDNTemplateDTO.setItemName(invoiceDetailDto.getEditItemDetail().get(i).getDescription());

				String inwardTaxableAmt = invoiceDetailDto.getEditItemDetail().get(i).getTaxable();
				inwardInvoiceCDNTemplateDTO.setInwardTaxableAmt(inwardTaxableAmt);

				String cessRate = invoiceDetailDto.getEditItemDetail().get(i).getCessRate();
				inwardInvoiceCDNTemplateDTO.setCessRate(AppUtil.formatRateAmoutValues(cessRate));

				if (StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getCessRate())) {
					inwardInvoiceCDNTemplateDTO.setCessRate(String.valueOf("0"));
				}
				inwardInvoiceCDNTemplateDTO.setImportType(invoiceDetailDto.getInputType());
				String pos = invoiceDetailDto.getPos();
				if (StringUtils.isNotBlank(pos) && pos.length() == 1) {
					inwardInvoiceCDNTemplateDTO.setPlaceOfSupply("0" + pos);
				} else {
					inwardInvoiceCDNTemplateDTO.setPlaceOfSupply(pos);
				}
				inwardInvoiceCDNTemplateDTO.setSupplyType(invoiceDetailDto.getTranType());
				
				if ("NIL".equalsIgnoreCase(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory())) {
					inwardInvoiceCDNTemplateDTO
							.setNilRatedAmt(AppUtil.formatRateAmoutValues(inwardInvoiceCDNTemplateDTO.getOrgAssAmt()));
				} else {
					inwardInvoiceCDNTemplateDTO.setNilRatedAmt(AppUtil.formatRateAmoutValues("0.00"));
				}
				if ("EXM".equalsIgnoreCase(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory())) {
					inwardInvoiceCDNTemplateDTO
							.setExemptedAmt(AppUtil.formatRateAmoutValues(inwardInvoiceCDNTemplateDTO.getOrgAssAmt()));
				} else {
					inwardInvoiceCDNTemplateDTO.setExemptedAmt(AppUtil.formatRateAmoutValues("0.00"));
				}
				if ("NON".equalsIgnoreCase(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory())) {
					inwardInvoiceCDNTemplateDTO
							.setNonGstAmt(AppUtil.formatRateAmoutValues(inwardInvoiceCDNTemplateDTO.getOrgAssAmt()));
				} else {
					inwardInvoiceCDNTemplateDTO.setNonGstAmt(AppUtil.formatRateAmoutValues("0.00"));
				}

				if ("COMP".equalsIgnoreCase(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory())) {
					inwardInvoiceCDNTemplateDTO.setCompositionAmt(
							AppUtil.formatRateAmoutValues(inwardInvoiceCDNTemplateDTO.getOrgAssAmt()));
				} else {
					inwardInvoiceCDNTemplateDTO.setCompositionAmt(AppUtil.formatRateAmoutValues("0.00"));
				}

				inwardInvoiceCDNTemplateDTO.setSgstAmt(sgstAmt);
				inwardInvoiceCDNTemplateDTO.setCgstAmt(cgstAmt);
				inwardInvoiceCDNTemplateDTO.setIgstAmt(igstAmt);
				inwardInvoiceCDNTemplateDTO.setCessAmount(cessAmt);

				if (!isNumeric(inwardInvoiceCDNTemplateDTO.getCgstRate())) {
					inwardInvoiceCDNTemplateDTO.setCgstRate("0.0");
				}

				if (!isNumeric(inwardInvoiceCDNTemplateDTO.getSgstRate())) {
					inwardInvoiceCDNTemplateDTO.setSgstRate("0.0");
				}
				if (!isNumeric(sgstAmt)) {
					sgstAmt = "0.0";
				}

				if (!isNumeric(sgstAmt)) {
					sgstAmt = "0.0";
				}

				if (!isNumeric(cgstAmt)) {
					cgstAmt = "0.0";
				}

				if (!isNumeric(cessAmt)) {
					cessAmt = "0.0";
				}

				if (!isNumeric(igstAmt)) {
					igstAmt = "0.0";
				}

				BigDecimal igst = new BigDecimal(inwardInvoiceCDNTemplateDTO.getIgstAmt());
				BigDecimal sgst = new BigDecimal(inwardInvoiceCDNTemplateDTO.getSgstAmt());
				BigDecimal cgst = new BigDecimal(inwardInvoiceCDNTemplateDTO.getCgstAmt());
				BigDecimal cess = new BigDecimal(inwardInvoiceCDNTemplateDTO.getCessAmount());

				BigDecimal itcIgst = new BigDecimal(igstAmt);
				BigDecimal itcSgst = new BigDecimal(sgstAmt);
				BigDecimal itcCgst = new BigDecimal(cgstAmt);
				BigDecimal itcCess = new BigDecimal(cessAmt);

				BigDecimal totalTaxAmt = new BigDecimal(0);
				totalTaxAmt = totalTaxAmt.add(sgst).add(cgst).add(igst).add(cess);

				inwardInvoiceCDNTemplateDTO.setTotalTaxAmount(totalTaxAmt.toString());

				if (DroolUtil.containsNumbersOnly(itcPercent, 1)) {
					itcSgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), sgst);
					itcCgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), cgst);
					itcIgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), igst);
					itcCess = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), cess);
				}
				inwardInvoiceCDNTemplateDTO.setItcSgstAmt(itcSgst.toString());
				inwardInvoiceCDNTemplateDTO.setItcCgstAmt(itcCgst.toString());
				inwardInvoiceCDNTemplateDTO.setItcIgstAmt(itcIgst.toString());
				inwardInvoiceCDNTemplateDTO.setItcCessAmt(itcCess.toString());

				totalTaxAmt = totalTaxAmt.add(sgst).add(cgst).add(igst).add(cess);
				inwardInvoiceCDNTemplateDTO.setInwardTotalTaxAmt(totalTaxAmt.toString());

				BigDecimal totalITCTaxAmt = new BigDecimal(0);
				totalITCTaxAmt = totalITCTaxAmt.add(itcSgst).add(itcCgst).add(itcIgst).add(itcCess);
				inwardInvoiceCDNTemplateDTO.setInwardTotalTaxAmt(totalTaxAmt.toString());
				inwardInvoiceCDNTemplateDTO.setTotalItcAmt(totalITCTaxAmt.toString());
				inwardInvoiceCDNTemplateDTO.setTaxableAmount(inwardInvoiceCDNTemplateDTO.getAssAmt());

				inwardInvoiceCDNTemplateDTO.setGrossTotalAmount(grossTotalAmt);
				inwardInvoiceCDNTemplateDTO.setValid(true);
				inwardInvoiceCDNTemplateDTO.setOrgSgstRate(inwardInvoiceCDNTemplateDTO.getSgstRate());
				inwardInvoiceCDNTemplateDTO.setOrgSgstAmt(inwardInvoiceCDNTemplateDTO.getSgstAmt());
				inwardInvoiceCDNTemplateDTO.setOrgCgstRate(inwardInvoiceCDNTemplateDTO.getCgstRate());
				inwardInvoiceCDNTemplateDTO.setOrgCgstAmt(inwardInvoiceCDNTemplateDTO.getCgstAmt());
				inwardInvoiceCDNTemplateDTO.setOrgIgstRate(inwardInvoiceCDNTemplateDTO.getIgstRate());
				inwardInvoiceCDNTemplateDTO.setOrgIgstAmt(inwardInvoiceCDNTemplateDTO.getIgstAmt());

				if (StringUtils.isNotBlank(invoiceDetailDto.getTaxpayergstin())) {
					inwardInvoiceCDNTemplateDTO.setPanOfReciepiet(invoiceDetailDto.getTaxpayergstin().substring(2, 12));
				} else {
					inwardInvoiceCDNTemplateDTO.setPanOfReciepiet("");

				}
				
				if (StringUtils.isNotBlank(invoiceDetailDto.getSupplierGSTIN())) {
					inwardInvoiceCDNTemplateDTO.setPanOfSupplier(invoiceDetailDto.getSupplierGSTIN().substring(2, 12));
				} else {
					inwardInvoiceCDNTemplateDTO.setPanOfSupplier("");

				}
				if ("".equals(inwardInvoiceCDNTemplateDTO.getOrgInvoiceDate())
						|| "0".equals(inwardInvoiceCDNTemplateDTO.getOrgInvoiceDate())
						|| StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getOrgInvoiceDate())) {
					inwardInvoiceCDNTemplateDTO.setOrgInvoiceDate("0");
				}
				inwardInvoiceCDNTemplateDTO.setOrgInvoiceDate(invoiceDetailDto.getOrgInvoiceDate());
				inwardInvoiceCDNTemplateDTO.setOrgInvoiceNo(invoiceDetailDto.getOrgInvoiceNo());
				inwardInvoiceCDNTemplateDTO.setIrn(invoiceDetailDto.getIrn());
				inwardInvoiceCDNTemplateDTO.setAckDate(invoiceDetailDto.getAckDate());
				inwardInvoiceCDNTemplateDTO.setAckNo(invoiceDetailDto.getAckNo());
				
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf1());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf2());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf3());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf4());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf5());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf6());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf7());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf8());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf9());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf10());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf11());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf12());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf13());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf14());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf15());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf16());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf17());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf18());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf19());
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf20());
				
				inwardInvoiceCDNTemplateDTO.setTdsSection(invoiceDetailDto.getTdsSection());
				inwardInvoiceCDNTemplateDTO.setTdsRate(invoiceDetailDto.getTdsRate());
				inwardInvoiceCDNTemplateDTO.setTdsTaxAmount(invoiceDetailDto.getTdsTaxAmount());
				inwardInvoiceCDNTemplateDTO.setChallanNumber(invoiceDetailDto.getChallanNo());
				inwardInvoiceCDNTemplateDTO.setChallanDate(invoiceDetailDto.getChallanDate());
				inwardInvoiceCDNTemplateDTO.setChallanAmount(invoiceDetailDto.getChallanAmount());
				inwardInvoiceCDNTemplateDTO.setPeriodOfFiling(invoiceDetailDto.getPeriodFilingTdsReturn());
				inwardInvoiceCDNTemplateDTO.setInvoiceAgainstProvAdv(invoiceDetailDto.getInvoiceAgainstProvAdv());
				inwardInvoiceCDNTemplateDTO.setInwardNoProvAdv(invoiceDetailDto.getInwardNoProvAdv());
				inwardInvoiceCDNTemplateDTO.setInwardDateProvAdv(invoiceDetailDto.getInwardDateprovAdv());
				inwardInvoiceCDNTemplateDTO.setAmountOfProvAdv(invoiceDetailDto.getAmountofProvAdv());
				inwardInvoiceCDNTemplateDTO.setBalOutstanding(invoiceDetailDto.getBalOutstanding());
				
				inwardInvoiceCDNTemplateDTO.setDateOfPayment(invoiceDetailDto.getDateOfPayment());
				inwardInvoiceCDNTemplateDTO.setPaymentAmount(invoiceDetailDto.getAmountofPayment());
				inwardInvoiceCDNTemplateDTO.setPaymentRefNo(invoiceDetailDto.getPaymentRefNo());
				inwardInvoiceCDNTemplateDTO.setImportBillOfEntryDate(invoiceDetailDto.getImportBillofDate());
				
				inwardInvoiceCDNTemplateDTO.setUdf1(invoiceDetailDto.getUdf1());
				inwardInvoiceCDNTemplateDTO.setUdf2(invoiceDetailDto.getUdf2());
				inwardInvoiceCDNTemplateDTO.setUdf3(invoiceDetailDto.getUdf3());
				inwardInvoiceCDNTemplateDTO.setUdf4(invoiceDetailDto.getUdf4());
				inwardInvoiceCDNTemplateDTO.setUdf5(invoiceDetailDto.getUdf5());
				inwardInvoiceCDNTemplateDTO.setUdf6(invoiceDetailDto.getUdf6());
				inwardInvoiceCDNTemplateDTO.setUdf7(invoiceDetailDto.getUdf7());
				inwardInvoiceCDNTemplateDTO.setUdf8(invoiceDetailDto.getUdf8());
				inwardInvoiceCDNTemplateDTO.setUdf9(invoiceDetailDto.getUdf9());
				inwardInvoiceCDNTemplateDTO.setUdf10(invoiceDetailDto.getUdf10());
				inwardInvoiceCDNTemplateDTO.setUdf11(invoiceDetailDto.getUdf11());
				inwardInvoiceCDNTemplateDTO.setUdf12(invoiceDetailDto.getUdf12());
				inwardInvoiceCDNTemplateDTO.setUdf13(invoiceDetailDto.getUdf13());
				inwardInvoiceCDNTemplateDTO.setUdf14(invoiceDetailDto.getUdf14());
				inwardInvoiceCDNTemplateDTO.setUdf15(invoiceDetailDto.getUdf15());
				inwardInvoiceCDNTemplateDTO.setUdf16(invoiceDetailDto.getUdf16());
				inwardInvoiceCDNTemplateDTO.setUdf17(invoiceDetailDto.getUdf17());
				inwardInvoiceCDNTemplateDTO.setUdf18(invoiceDetailDto.getUdf18());
				inwardInvoiceCDNTemplateDTO.setUdf19(invoiceDetailDto.getUdf19());
				inwardInvoiceCDNTemplateDTO.setUdf20(invoiceDetailDto.getUdf20());
				
				inwardInvoiceINVTemplateDTOList.add(inwardInvoiceCDNTemplateDTO);
			}

		}

		
		for(InwardInvoiceCDNTemplateDTO rowData:inwardInvoiceINVTemplateDTOList)
		{
			rowData.setTotalInvoiceAmt(totalInvoiceValue.toString());
			rowData.setOrgTotalInvAmt(totalInvoiceValue.toString());
		}
		for(InwardInvoiceCDNTemplateDTO rowData:inwardInvoiceCDNTemplateDTOList)
		{
			rowData.setTotalInvoiceAmt(totalInvoiceValue.toString());
			rowData.setOrgTotalInvAmt(totalInvoiceValue.toString());
		}
		
		
		
		inwardInvoiceCDNTemplateDTOFinalErrorList= inwardUpload.manualValidateAndSaveData(uploadReqDTO, inwardInvoiceINVTemplateDTOList,
				inwardInvoiceCDNTemplateDTOList,invoiceDetailDto.getPaymentDetails(),invoiceDetailDto.getTdsDetails());

		upadateResponseDto.setInwardTemplateErrorListDto(inwardInvoiceCDNTemplateDTOFinalErrorList);
		upadateResponseDto.setPaymentDetailErrorList(paymentDetailsFinalErrorList);
		upadateResponseDto.setTdsDetailErrorList(tdsDetailsFinalErrorList);
		//communicationArchivedInwardUploadData(invoiceDetailDto, "updateAndValidateDetails");
		}
		catch(Exception e)
		{
			log.error("Error while Updating Invoice Manually",e);
		}
		return upadateResponseDto;
		
	}

	
	
	private String getErrorCodeDescription(ItcDto rowData, String codes, Map<String, String> errorCodeMap) {

        List<String>descriptionList=new ArrayList<>();
        String code = codes.replace("|", ",");
        String[] errorCodeList = code.split(",");
        
        String newErrorCode=code.substring(1);
        newErrorCode=newErrorCode.replace("|", ",");
        String[] newErrorCodeList=newErrorCode.split(",");
        String errorStringCodeList=String.join("|", newErrorCodeList); 
        if (errorCodeList.length > 1) {
            for (int i = 1; i < errorCodeList.length; i++) {
                String description = errorCodeMap.get(errorCodeList[i].trim());
                descriptionList.add(description);

            }
        }
        rowData.setErrorCode(errorStringCodeList);
        return String.join("|", descriptionList);
    }



	private void communicationArchivedInwardUploadData(InvoiceDetailsDTO reqDto, String methodName) {
		try {
		    uploadTransDao.vendorCommunicationArchiveInwardUploadData(reqDto);
		}catch(Exception e)
		{
			log.error("Exception in method : ",methodName,"while calling Procedure vendor_communication_archive_inward_upload_data");
		}
	}
	
	public static boolean isNumeric(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
	
	String getErrorCodeDescription(PaymentDetails rowData,String codes, Map<String, String> errorCodeMap) {

        List<String>descriptionList=new ArrayList<>();
        String code = codes.replace("|", ",");
        String[] errorCodeList = code.split(",");
        
        String newErrorCode=code.substring(1);
        newErrorCode=newErrorCode.replace("|", ",");
        String[] newErrorCodeList=newErrorCode.split(",");
        String errorStringCodeList=String.join("|", newErrorCodeList); 
        if (errorCodeList.length > 1) {
            for (int i = 1; i < errorCodeList.length; i++) {
                String description = errorCodeMap.get(errorCodeList[i].trim());
                descriptionList.add(description);

            }
        }
        rowData.setErrorCode(errorStringCodeList);
        return String.join("|", descriptionList);
    }

	String getErrorCodeDescription(TdsDetails rowData,String codes, Map<String, String> errorCodeMap) {

        List<String>descriptionList=new ArrayList<>();
        String code = codes.replace("|", ",");
        String[] errorCodeList = code.split(",");
        
        String newErrorCode=code.substring(1);
        newErrorCode=newErrorCode.replace("|", ",");
        String[] newErrorCodeList=newErrorCode.split(",");
        String errorStringCodeList=String.join("|", newErrorCodeList); 
        if (errorCodeList.length > 1) {
            for (int i = 1; i < errorCodeList.length; i++) {
                String description = errorCodeMap.get(errorCodeList[i].trim());
                descriptionList.add(description);

            }
        }
        rowData.setErrorCode(errorStringCodeList);
        return String.join("|", descriptionList);
    }
	
	

}
