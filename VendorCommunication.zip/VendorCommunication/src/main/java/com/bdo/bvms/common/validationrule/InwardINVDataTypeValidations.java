package com.bdo.bvms.common.validationrule;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;;

public class InwardINVDataTypeValidations {

    public void validateDataType(InwardInvoiceCDNTemplateDTO rowdata) {

        InwardDroolUtil ruleMethods = new InwardDroolUtil();

        // Customer GSTIN validate
        validGstinCheck(rowdata, ruleMethods);

        validGSTINTaxpayer(rowdata, ruleMethods);

        // Check invoice no. is blank
        inwardNoCheck(rowdata, ruleMethods);

        inwardNo16Length(rowdata, ruleMethods);

        // "doc date should be in DD-MM-YYYY format"
        validDocDateCheck(rowdata, ruleMethods);

        // inwardDate should be in DD-MM-YYYY format"
        isValidInvoiceDateCheck(rowdata, ruleMethods);

        isValidInvoiceDateFutureCheck(rowdata, ruleMethods);

        // "check sgst Rate Numeric"

        
        sgstRateCheck(rowdata);

        // "check cgst Rate Numeric"

        cgstRateCheck(rowdata);

        // "check igst Rate Numeric"

        igstRateCheck(rowdata);

        // "HSN Only Number"
        twoDecimalHsnCheckBlankHsnCheck(rowdata, ruleMethods);

        // "Quantity check for number"
        twoDecimalHsnCheckBlankQuantityCheck(rowdata, ruleMethods);

        // Item Rate check Number
        twoDecimalHsnCheckBlankItemRate(rowdata, ruleMethods);

        // taxable check Number
        twoDecimalCheckInwardTaxableAmt(rowdata, ruleMethods);

        // sgstAmt check Number
        twoDecimalCheckSgstAmt(rowdata, ruleMethods);
        // "cgstAmt check Number"
        twoDecimalCheckCgstAmt(rowdata, ruleMethods);

        // "igstAmt check Number"
        twoDecimalCheckIgstAmt(rowdata, ruleMethods);

        // "cessAmount check Number"
        twoDecimalCheckCessAmt(rowdata, ruleMethods);

        /// "inwardTotalTaxAmt check Number"
        twoDecimalCheckInwardTaxableAmount(rowdata, ruleMethods);

        // "itc sgstAmt check Number"
        twoDecimalCheckItcSgstAmt(rowdata, ruleMethods);

        // itc cgstAmt check Number
        twoDecimalCheckItsCgstAmt(rowdata, ruleMethods);

        // itc igstAmt check Number
        twoDecimalCheckItcIgstAmt(rowdata, ruleMethods);

        // itc cessAmount check Number
        twoDecimalCheckItcCessAmt(rowdata, ruleMethods);

        // inwardGrossTotalAmt check Number
        onlyNumericInwardGrossTotalAmt(rowdata, ruleMethods);
        // total invoice amount check Number
        onlyNumericTotalInvoiceAmount(rowdata, ruleMethods);

        // bill entry no check Number
        twoDecimalCheckBoeImportBillOfEntryAmt(rowdata, ruleMethods);

        // bill entry no check Number
        twoDecimalCheckImportBillOfEntryAMt(rowdata, ruleMethods);
        // pos check Number
        onlyNumericHSNPlaceOfSupply(rowdata, ruleMethods);

        // supplier check Number
        onlyNumericHSNSupplierStateCode(rowdata, ruleMethods);

        // check length quantity
        checkLength17HsnConfQuantity(rowdata, ruleMethods);

        // check taxable Amt length
        checkLength12InwardTaxableAmount(rowdata, ruleMethods);

        // "check inwardTotalTaxAmt Amt length"
        checkLength12InwardTotalTax(rowdata, ruleMethods);

        // "check gross taxable Amt length"
        checkLength12InwardGrossTotalAmt(rowdata, ruleMethods);

        // "check sgstAmt length"
        checkLength12SgstAmt(rowdata, ruleMethods);

        // check cgstAmt length
        checkLength12CgstAmt(rowdata, ruleMethods);

        // check igstAmt length
        checkLength12IgstAmt(rowdata, ruleMethods);

        // check igstAmt length
        checkLength12CessAmt(rowdata, ruleMethods);

        // itc check sgstAmt length
        checkLength12ItcSgstAmt(rowdata, ruleMethods);

        // itc check CgstAmt length
        checkLength12ItsCgstAmt(rowdata, ruleMethods);

        // itc check IgstAmt length
        checkLength12IgstAmtCheck(rowdata, ruleMethods);

        // itc check cessAmt length"
        checkLength12ItcCessAmt(rowdata, ruleMethods);

        // "Doc no must be max 16 length"
        docNumber25LengthCheck(rowdata);

        // Doc no Contains other than alphanumeric, slash (/) or dash (-)
        checkDocumentNumberCheck(rowdata, ruleMethods);

        // ack no must be numeric

        isValidAckDateCheck(rowdata, ruleMethods);

        onlyNumericAckNoCheck(rowdata, ruleMethods);
        // "ack no must be max 15 length"
        getAckNoLenghtCheck(rowdata);

        // "sub location must be max 200 length"
        getSublocationCheck(rowdata);

        // "IRN must be max 60 length
        irnCheck(rowdata);

        // "itc reversal percentage value 0.01 to 100"
        checkItcPercentageCheck(rowdata, ruleMethods);

        // irn must be alphanumeric"
        isAlphanumericCheck(rowdata, ruleMethods);
        
        validateTdsTaxAmount(rowdata,ruleMethods);
        
        validateTdsRate(rowdata,ruleMethods);
    	validateTdsRate3Digit2Decimal(rowdata,ruleMethods);
    	validateInwardNoProvAdvLength(rowdata,ruleMethods);
        
        validateChallanNumber(rowdata,ruleMethods);

        validateChallanDate(rowdata,ruleMethods);
        
        challanNumberLengthValidation(rowdata);
        
        validateChallanAmount(rowdata,ruleMethods);
        
        validateFillingPeriod(rowdata,ruleMethods);
        
        validateinvoiceAgainstProvAdv(rowdata,ruleMethods);
        
        validateInwardNoProvAdv(rowdata,ruleMethods);
        
        validateInwardDateProvAdv(rowdata,ruleMethods);
        
        validateAmountOfProvAdv(rowdata,ruleMethods);
        
        validateBalOutstanding(rowdata,ruleMethods);
        
       // validatefPaymentDetails(rowdata,ruleMethods);
        
        validatePaymentDate(rowdata,ruleMethods);
        
        validateinvoiceAgainstProvAdvDateAndNo(rowdata,ruleMethods);
        
        validateCreditGlId(rowdata);
        
        validateCreditGlName(rowdata);
        
        validateDebitGlId(rowdata);
        
        validateDebitGlName(rowdata);
        
        isImportBillOfEntryDateFuture(rowdata,ruleMethods);
        
        checkUdf10Length(rowdata,ruleMethods);
        checkUdf9Length(rowdata,ruleMethods);
        checkUdf8Length(rowdata,ruleMethods);
        checkUdf7Length(rowdata,ruleMethods);
        checkUdf6Length(rowdata,ruleMethods);
        checkUdf5Length(rowdata,ruleMethods);
        checkUdf4Length(rowdata,ruleMethods);
        checkUdf3Length(rowdata,ruleMethods);
        checkUdf2Length(rowdata,ruleMethods);
        checkUdf1Length(rowdata,ruleMethods);
        
        checkUdf1xAlphaNumeric(rowdata,ruleMethods);
        checkUdf2AlphaNumeric(rowdata,ruleMethods);
        checkUdf3AlphaNumeric(rowdata,ruleMethods);
        checkUdf4AlphaNumeric(rowdata,ruleMethods);
        checkUdf5AlphaNumeric(rowdata,ruleMethods);
        checkUdf6AlphaNumeric(rowdata,ruleMethods);
        checkUdf7AlphaNumeric(rowdata,ruleMethods);
        checkUdf8AlphaNumeric(rowdata,ruleMethods);
        checkUdf9AlphaNumeric(rowdata,ruleMethods);
        checkUdf10AlphaNumeric(rowdata,ruleMethods);
        
        checkUdf11Length(rowdata,ruleMethods);
        checkUdf12Length(rowdata,ruleMethods);
        checkUdf13Length(rowdata,ruleMethods);
        checkUdf14Length(rowdata,ruleMethods);
        checkUdf15Length(rowdata,ruleMethods);
        checkUdf16Length(rowdata,ruleMethods);
        checkUdf17Length(rowdata,ruleMethods);
        checkUdf18Length(rowdata,ruleMethods);
        checkUdf19Length(rowdata,ruleMethods);
        checkUdf20Length(rowdata,ruleMethods);
        
        checkUdf11AlphaNumeric(rowdata,ruleMethods);
        checkUdf12AlphaNumeric(rowdata,ruleMethods);
        checkUdf13AlphaNumeric(rowdata,ruleMethods);
        checkUdf14AlphaNumeric(rowdata,ruleMethods);
        checkUdf15AlphaNumeric(rowdata,ruleMethods);
        checkUdf16AlphaNumeric(rowdata,ruleMethods);
        checkUdf17AlphaNumeric(rowdata,ruleMethods);
        checkUdf18AlphaNumeric(rowdata,ruleMethods);
        checkUdf19AlphaNumeric(rowdata,ruleMethods);
        checkUdf20AlphaNumeric(rowdata,ruleMethods);
        
       
    }

    private void isImportBillOfEntryDateFuture(InwardInvoiceCDNTemplateDTO rowdata,InwardDroolUtil ruleMethods) {
    	boolean isValidDate=ruleMethods.isValidInvoiceDate(rowdata.getImportBillOfEntryDate());
		boolean isValidFutureDate=ruleMethods.isValidFutureInvoiceDate(rowdata.getImportBillOfEntryDate());
		if (isValidDate && !isValidFutureDate) {
			 markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00587, "");
        }
		
	}

	private void validateDebitGlName(InwardInvoiceCDNTemplateDTO rowdata) {
		 if(StringUtils.isNotBlank(rowdata.getDebitGlName()) && rowdata.getDebitGlName().length()>45)
			{
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00578, "");
			}
		
	}

	private void validateDebitGlId(InwardInvoiceCDNTemplateDTO rowdata) {
		if(StringUtils.isNotBlank(rowdata.getDebitGlId()) && rowdata.getDebitGlId().length()>45)
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00577, "");
		}
		
	}

	private void validateCreditGlName(InwardInvoiceCDNTemplateDTO rowdata) {
		if(StringUtils.isNotBlank(rowdata.getCreditGlName()) && rowdata.getCreditGlName().length()>45)
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00576, "");
		}
		
	}

	private void validateCreditGlId(InwardInvoiceCDNTemplateDTO rowdata) {
		if(StringUtils.isNotBlank(rowdata.getCreditGlId()) && rowdata.getCreditGlId().length()>45)
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00575, "");
		}
		
	}


    private void validatePaymentDate(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if(StringUtils.isNotBlank(rowdata.getDateOfPayment()) && !ruleMethods.isValidInvoiceDate(rowdata.getDateOfPayment()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00566, "");
		}
		
	}

	private void isAlphanumericCheck(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (StringUtils.isNotBlank(rowdata.getIrn()) && !ruleMethods.isAlphanumeric(rowdata.getIrn())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50119, "");
        }
	}

	private void checkItcPercentageCheck(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkItcPercentage(rowdata.getItcIneligibleReversalPercentage())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50114, "");
        }
	}
	
	private void irnCheck(InwardInvoiceCDNTemplateDTO rowdata) {
		if (StringUtils.isNotBlank(rowdata.getIrn())  && rowdata.getIrn().length() > 0 && rowdata.getIrn().length() != 64) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00164, "");
        }
	}

	private void getSublocationCheck(InwardInvoiceCDNTemplateDTO rowdata) {
		if (StringUtils.isNotBlank(rowdata.getSubLocation())  && rowdata.getSubLocation().length() > 200) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00158, "");
        }
	}

	private void getAckNoLenghtCheck(InwardInvoiceCDNTemplateDTO rowdata) {
		if (StringUtils.isNotBlank(rowdata.getAckNo()) && rowdata.getAckNo().length() > 0
                        && rowdata.getAckNo().length() != 15) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00163, "");
        }
	}

	private void onlyNumericAckNoCheck(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (StringUtils.isNotBlank(rowdata.getAckNo()) && !ruleMethods.onlyNumericAckNo(rowdata.getAckNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50118, "");
        }
	}

	private void isValidAckDateCheck(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (StringUtils.isNotBlank(rowdata.getAckDate()) && !ruleMethods.isValidInvoiceDate(rowdata.getAckDate())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00168, "");
        }
	}

	private void checkDocumentNumberCheck(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (StringUtils.isNotBlank(rowdata.getDocNo()) && !ruleMethods.checkDocumentNumber(rowdata.getDocNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00093, "");
        }
	}

	private void docNumber25LengthCheck(InwardInvoiceCDNTemplateDTO rowdata) {
		if (StringUtils.isNotBlank(rowdata.getDocNo()) && rowdata.getDocNo().length() > 16) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00094, "");
        }
	}

	private void checkLength12ItcCessAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkLength12(rowdata.getItcCessAmt(), rowdata.isValid())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00277, "");
        }
	}

	private void checkLength12IgstAmtCheck(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkLength12(rowdata.getItcIgstAmt(), rowdata.isValid())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00276, "");
        }
	}

	private void checkLength12ItsCgstAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkLength12(rowdata.getItcCgstAmt(), rowdata.isValid())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00275, "");
        }
	}

	private void checkLength12ItcSgstAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkLength12(rowdata.getItcSgstAmt(), rowdata.isValid())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00274, "");
        }
	}

	private void checkLength12CessAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkLength12(rowdata.getCessAmount(), rowdata.isValid())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00037, "");
        }
	}

	private void checkLength12IgstAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkLength12(rowdata.getIgstAmt(), rowdata.isValid())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00035, "");
        }
	}

	private void checkLength12CgstAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkLength12(rowdata.getCgstAmt(), rowdata.isValid())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00034, "");
        }
	}

	private void checkLength12SgstAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkLength12(rowdata.getSgstAmt(), rowdata.isValid())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00033, "");
        }
	}

	private void checkLength12InwardGrossTotalAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkLength12G(rowdata.getInwardGrossTotalAmount(), rowdata.isValid())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00021, "");
        }
	}

	private void checkLength12InwardTotalTax(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkLength12(rowdata.getInwardTotalTaxAmt(), rowdata.isValid())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00021, "");
        }
	}

	private void checkLength12InwardTaxableAmount(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkLength12(rowdata.getInwardTaxableAmt(), rowdata.isValid())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00021, "");
        }
	}

	private void checkLength17HsnConfQuantity(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkLength17HsnConf(rowdata.getQuantity())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00100, "");
        }
	}

	private void onlyNumericHSNSupplierStateCode(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.onlyNumeric(rowdata.getSupplierStateCode())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00073, "");
        }
	}

	private void onlyNumericHSNPlaceOfSupply(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.onlyNumeric(rowdata.getPlaceOfSupply())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00044, "");
        }
	}

	private void twoDecimalCheckImportBillOfEntryAMt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalCheck(rowdata.getDocType(), rowdata.getImportBillOfEntryAmt())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50030, "");
        }
	}

	private void twoDecimalCheckBoeImportBillOfEntryAmt(InwardInvoiceCDNTemplateDTO rowdata,
			InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalCheckBoe(rowdata.getDocType(), rowdata.getImportBillOfEntryNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50013, "");
        }
	}

	private void onlyNumericTotalInvoiceAmount(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.onlyNumeric(rowdata.getTotalInvoiceAmt())
                        && !ruleMethods.twoDecimalCheck(rowdata.getDocType(), rowdata.getTotalInvoiceAmt())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00153, "");
        }
	}

	private void onlyNumericInwardGrossTotalAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.onlyNumeric(rowdata.getInwardGrossTotalAmount())
                        && !ruleMethods.twoDecimalCheck(rowdata.getDocType(), rowdata.getInwardGrossTotalAmount())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00039, "");
        }
	}

	private void twoDecimalCheckItcCessAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalCheck(rowdata.getDocType(), rowdata.getItcCessAmt())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50027, "");
        }
	}

	private void twoDecimalCheckItcIgstAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalCheck(rowdata.getDocType(), rowdata.getItcIgstAmt())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50026, "");
        }
	}

	private void twoDecimalCheckItsCgstAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalCheck(rowdata.getDocType(), rowdata.getItcCgstAmt())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50025, "");
        }
	}

	private void twoDecimalCheckItcSgstAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalCheck(rowdata.getDocType(), rowdata.getItcSgstAmt())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50024, "");
        }
	}

	private void twoDecimalCheckInwardTaxableAmount(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalCheck(rowdata.getDocType(), rowdata.getInwardTotalTaxAmt())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00038, "");
        }
	}

	private void twoDecimalCheckCessAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalCheck(rowdata.getDocType(), rowdata.getCessAmount())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00037, "");
        }
	}

	private void twoDecimalCheckIgstAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalCheck(rowdata.getDocType(), rowdata.getIgstAmt())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00035, "");
        }
	}

	private void twoDecimalCheckCgstAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalCheck(rowdata.getDocType(), rowdata.getCgstAmt())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00034, "");
        }
	}

	private void twoDecimalCheckSgstAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalCheck(rowdata.getDocType(), rowdata.getSgstAmt())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00033, "");
        }
	}

	private void twoDecimalCheckInwardTaxableAmt(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalCheck(rowdata.getDocType(), rowdata.getInwardTaxableAmt())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00021, "");
        }
	}

	private void twoDecimalHsnCheckBlankItemRate(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalHsnCheckBlank(rowdata.getDocType(), rowdata.getItemRate())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00017, "");
        }
	}

	private void twoDecimalHsnCheckBlankQuantityCheck(InwardInvoiceCDNTemplateDTO rowdata,
			InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalHsnCheckBlank(rowdata.getDocType(), rowdata.getQuantity())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00019, "");
        }
	}

	private void twoDecimalHsnCheckBlankHsnCheck(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.twoDecimalHsnCheckBlank(rowdata.getDocType(), rowdata.getHsnCode())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00032, "");
        }
	}

	private void igstRateCheck(InwardInvoiceCDNTemplateDTO rowdata) {
		if (rowdata.getIgstRate() != null && !rowdata.getIgstRate().matches(ValidationConstant.VENDOR_COMMON_REGX)) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00028, " ");
        }
	}

	private void cgstRateCheck(InwardInvoiceCDNTemplateDTO rowdata) {
		if (rowdata.getCgstRate() != null && !rowdata.getCgstRate().matches(ValidationConstant.VENDOR_COMMON_REGX)) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00034, "");
        }
	}

	private void sgstRateCheck(InwardInvoiceCDNTemplateDTO rowdata) {
		if (rowdata.getSgstRate() != null && !rowdata.getSgstRate().matches(ValidationConstant.VENDOR_COMMON_REGX)) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00033, "");
        }
	}

	private void isValidInvoiceDateFutureCheck(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		boolean isValidDate=ruleMethods.isValidInvoiceDate(rowdata.getInwardDate());
		boolean isValidFutureDate=ruleMethods.isValidFutureInvoiceDate(rowdata.getInwardDate());
		if (isValidDate && !isValidFutureDate) {
			 markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00315, "");
        }
	}

	private void isValidInvoiceDateCheck(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.isValidInvoiceDate(rowdata.getInwardDate())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00313, "");
        }
	}

	private void validDocDateCheck(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.isValidDocDate(rowdata.getDocDate())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00095, "");
        }
	}

	private void inwardNo16Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.check16CharacterLength(rowdata.getInwardNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00031, "");
        }
	}

	private void inwardNoCheck(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.isInvoiceNoExist(rowdata.getInwardNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00030, "");
        } else if (!ruleMethods.isSpecialCharExistInInvoiceNo(rowdata.getInwardNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00054, "");
        }
	}

	private void validGSTINTaxpayer(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.validGSTIN(rowdata.getGstinOfRecipient())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00517, "");
        }
	}

	private void validGstinCheck(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.validGSTIN(rowdata.getGstinOfSupplier())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00519, "");
        }
	}
	private void validateTdsRate(InwardInvoiceCDNTemplateDTO rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getTdsRate()) && !ruleMethods.twoDecimalHsnCheckBlank(rawData.getDocType(), rawData.getTdsRate()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00563, "");
		}
	}
	
	private void validateTdsRate3Digit2Decimal(InwardInvoiceCDNTemplateDTO rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getTdsRate()) && !ruleMethods.checkLength3LenTds(rawData.getTdsRate()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00563, "");
		}
	}
	
	private void validateTdsTaxAmount(InwardInvoiceCDNTemplateDTO rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getTdsTaxAmount()) && !ruleMethods.checkLength12(rawData.getTdsTaxAmount(), rawData.isValid()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00528, "");
		}
	}
	
	private void validateChallanNumber(InwardInvoiceCDNTemplateDTO rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getChallanNumber()) && !ruleMethods.onlyNumericAckNo(rawData.getChallanNumber()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00557, "");
		}
	}
	
	private void validateChallanDate(InwardInvoiceCDNTemplateDTO rowData,InwardDroolUtil rulesMethod)
	{
		if(StringUtils.isNotBlank(rowData.getChallanDate()) && !rulesMethod.isValidInvoiceDate(rowData.getChallanDate()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00529, "");
		}
	}

	private void challanNumberLengthValidation(InwardInvoiceCDNTemplateDTO rowdata) {
		if(StringUtils.isNotBlank(rowdata.getChallanNumber()) && rowdata.getChallanNumber().length()>6)
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00530, "");
		}
	}
	private void validateChallanAmount(InwardInvoiceCDNTemplateDTO rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getChallanAmount()) && !ruleMethods.checkLength12(rawData.getChallanAmount(), rawData.isValid()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00531, "");
		}
	}
	private void validateFillingPeriod(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
         if(StringUtils.isNotBlank(rowdata.getPeriodOfFiling()) && !ruleMethods.validatePeriodOfFilling(rowdata))
         {
        	 markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00532, "");
         }
	}

	private void validateinvoiceAgainstProvAdv(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if (StringUtils.isNotBlank(rowdata.getInvoiceAgainstProvAdv())) {
			List<String> invoiceAgainstProvAdv = new ArrayList<>(Arrays.asList("Yes", "No"));
			if (!invoiceAgainstProvAdv.contains(rowdata.getInvoiceAgainstProvAdv())) {
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00533, "");
			}
		}
	}

	private void validateInwardNoProvAdv(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods)
	{
		if (StringUtils.isNotBlank(rowdata.getInwardNoProvAdv()) && !ruleMethods.isSpecialCharExistInInvoiceNo(rowdata.getInwardNoProvAdv())) {
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00534, "");
		}
	}
	
	private void validateInwardNoProvAdvLength(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods)
	{
		if (StringUtils.isNotBlank(rowdata.getInwardNoProvAdv()) && rowdata.getInwardNoProvAdv().length()>16) {
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00559, "");
		}
	}
	
	private void validateInwardDateProvAdv(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rowdata.getInwardDateProvAdv()) && !ruleMethods.isValidDocDate(rowdata.getInwardDateProvAdv()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00535, "");
		}
	}
	
	private void validateAmountOfProvAdv(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods)
	{

		if(StringUtils.isNotBlank(rowdata.getAmountOfProvAdv()) && !ruleMethods.checkLength12(rowdata.getAmountOfProvAdv(),rowdata.isValid()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00536, "");
		}
	
	}
	
//	private void validatefPaymentDetails(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods)
//	{
//		if(((StringUtils.isNotBlank(rowdata.getPaymentAmount()) && (new BigDecimal(rowdata.getPaymentAmount()).compareTo(new BigDecimal(0))>0)) || StringUtils.isNotBlank(rowdata.getDateOfPayment()) || StringUtils.isNotBlank(rowdata.getPaymentRefNo()) ))
//		{
//			
//			if(new BigDecimal(rowdata.getPaymentAmount()).compareTo(new BigDecimal(0))<=0)
//			{
//				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00560, "");
//			}
//			if(StringUtils.isBlank(rowdata.getDateOfPayment()))
//			{
//			    markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00562, "");
//			}
//			
//			if(StringUtils.isBlank(rowdata.getPaymentRefNo()))
//			{
//				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00561, "");
//			}
//		}
//	
//	}
	
	
	
	private void checkUdf11Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf11()) && ruleMethods.checkUDFLength(rowdata.getUdf11())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00537, "");
        }
    }

    private void checkUdf12Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf12()) && ruleMethods.checkUDFLength(rowdata.getUdf12())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00558, "");
        }
    }

    private void checkUdf13Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf13()) && ruleMethods.checkUDFLength(rowdata.getUdf13())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00539, "");
        }
    }

    private void checkUdf14Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf14()) && ruleMethods.checkUDFLength(rowdata.getUdf14())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00540, "");
        }
    }

    private void checkUdf15Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf15()) && ruleMethods.checkUDFLength(rowdata.getUdf15())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00541, "");
        }
    }

    private void checkUdf16Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf16()) && ruleMethods.checkUDFLength(rowdata.getUdf16())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00542, "");
        }
    }

    private void checkUdf17Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf17()) && ruleMethods.checkUDFLength(rowdata.getUdf17())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00543, "");
        }
    }

    private void checkUdf18Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf18()) && ruleMethods.checkUDFLength(rowdata.getUdf18())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00544, "");
        }
    }
 
    private void checkUdf19Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf19()) && ruleMethods.checkUDFLength(rowdata.getUdf19())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00545, "");
        }
    }


    private void checkUdf11AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf11()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf11())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00546, "");
        }
    }

    private void checkUdf12AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf12()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf12())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00547, "");
        }
    }

    private void checkUdf13AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf13()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf13())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00548, "");
        }
    }

    private void checkUdf14AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf14()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf14())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00549, "");
        }
    }
    private void checkUdf15AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf15()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf15())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00550, "");
        }
    }

    private void checkUdf16AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf16()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf16())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00551, "");
        }
    }

    private void checkUdf17AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf17()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf17())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00552, "");
        }
    }

    private void checkUdf18AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf18()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf18())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00553, "");
        }
    }

    private void checkUdf19AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf19()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf19())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00554, "");
        }
    }
  
    private void checkUdf20Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf20()) && ruleMethods.checkUDFLength(rowdata.getUdf20())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00555, "");
        }
    }
    

    private void checkUdf20AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf20()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf20())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00556, "");
        }
    }
	
	private void checkUdf10Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf10()) && ruleMethods.checkUDFLength(rowdata.getUdf10())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00311, "");
        }
    }

    private void checkUdf9Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf9()) && ruleMethods.checkUDFLength(rowdata.getUdf9())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00309, "");
        }
    }

    private void checkUdf8Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf8()) && ruleMethods.checkUDFLength(rowdata.getUdf8())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00307, "");
        }
    }

    private void checkUdf7Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf7()) && ruleMethods.checkUDFLength(rowdata.getUdf7())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00305, "");
        }
    }
   
    private void checkUdf6Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf6()) && ruleMethods.checkUDFLength(rowdata.getUdf6())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00303, "");
        }
    }

    private void checkUdf5Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf5()) && ruleMethods.checkUDFLength(rowdata.getUdf5())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00301, "");
        }
    }

    private void checkUdf4Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf4()) && ruleMethods.checkUDFLength(rowdata.getUdf4())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00299, "");
        }
    }

    private void checkUdf3Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf3()) && ruleMethods.checkUDFLength(rowdata.getUdf3())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00297, "");
        }
    }

    private void checkUdf2Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf2()) && ruleMethods.checkUDFLength(rowdata.getUdf2())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00295, "");
        }
    }

    private void checkUdf10AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf10()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf10())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00275, "");
        }
    }

    private void checkUdf9AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf9()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf9())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00310, "");
        }
    }
    

    private void checkUdf8AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf8()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf8())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00308, "");
        }
    }

    private void checkUdf7AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf7()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf7())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00306, "");
        }
    }

    private void checkUdf6AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf6()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf6())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00304, "");
        }
    }

    private void checkUdf5AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf5()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf5())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00302, "");
        }
    }

    private void checkUdf4AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf4()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf4())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00300, "");
        }
    }

    private void checkUdf3AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf3()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf3())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00298, "");
        }
    }

    private void checkUdf2AlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf2()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf2())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00296, "");
        }
    }
    

    private void checkUdf1Length(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf1()) && ruleMethods.checkUDFLength(rowdata.getUdf1())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00293, "");
        }
    }

    private void checkUdf1xAlphaNumeric(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf1()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf1())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00294, "");
        }
    }
    
    
	private void validateBalOutstanding(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		
		if(StringUtils.isNotBlank(rowdata.getBalOutstanding()) && !ruleMethods.checkLength12(rowdata.getBalOutstanding(),rowdata.isValid()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00536, "");
		}
	}
	
	private void validateinvoiceAgainstProvAdvDateAndNo(InwardInvoiceCDNTemplateDTO rowdata, InwardDroolUtil ruleMethods) {
		if ("Yes".equals(rowdata.getInvoiceAgainstProvAdv()) && ( StringUtils.isBlank(rowdata.getInwardDateProvAdv()) || StringUtils.isBlank(rowdata.getInwardNoProvAdv()) ||StringUtils.isBlank(rowdata.getAmountOfProvAdv()))) {	
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00565, "");	
		}
	}
	
	
	
    private void markErrorNAddErrorCode(InwardInvoiceCDNTemplateDTO rowdata, String errorCode, String errorMsg) {
        rowdata.setErrorCodeList(rowdata.getErrorCodeList().append(errorCode));
        rowdata.setErrorDescriptionList(rowdata.getErrorDescriptionList().append(errorMsg));
        rowdata.setValid(false);
    }

}
