package com.bdo.bvms.common.dao.impl;

public class UploadSQL {

    private UploadSQL() {
        super();
    }

    public static final String INSERT_FILE_SQL = "LOAD DATA LOCAL INFILE ? INTO TABLE table_name CHARACTER SET latin1 FIELDS TERMINATED BY \',\' ENCLOSED BY \'"
                    + '"' + "\' LINES TERMINATED BY \'\n\' IGNORE 1 LINES;";
    public static final String UPDATE_TOTAL_COUNT_TXUPLOADLOGS_SQL = "update upload_log set total_count=? where batch_no = ?";
    public static final String UPDATE_SUCCESS_COUNT_TXUPLOADLOGS_SQL = "update upload_log set success_count=? where batch_no = ?";
    public static final String UPDATE_ERROR_COUNT_TXUPLOADLOGS_SQL = "update upload_log set error_count=? where batch_no = ?";
    public static final String UPDATE_VALIDATION_START_TIME_STAMP = "update upload_log set upload_start_time=? where batch_no=?";

    public static final String UPDATE_VALIDATION_FINAL_TIME_STAMP = "update upload_log set upload_end_time=? where batch_no=?";

    public static final String UPDATE_SUCESSNERROR_COUNT = "update upload_log set error_count=?,success_count=? where batch_no=?";
    public static final String GET_FINACIAL_YEAR = "select year_id,financial_year from sm_financial_year where";
    public static final String GET_BASE_FILE_LOC = "select base_file_location from upload_log where batch_no = '";
    public static final String GET_ERROR_FILE_LOC = "select error_file_location from upload_log where batch_no = '";
    public static final String GET_AZURE_CREDENTIAL_FROM_DB = "select url,container_name from sm_entity_cloud_credentials where entity_id=? AND type=?";
    public static final String GET_COUNT_FP_YEAR = "select count(year_id) from sm_financial_year where";
    public static final String CUSTOMEPLDTEMPLATE = "select name from am_custom_template_name where id='";
    public static final String GETDEFAULTTEMPLATE = "select code,name from sm_pickup_list_details where sm_pick_mst_id=";
    public static final String GETPENDINGMAILDATA = "select * from sm_mail_box where error_success='";
    public static final String UPDATE_ERROR_SUCCESS = "update sm_mail_box set error_success=?,trials=? where error_success=?";
    public static final String GET_SM_MAIL_TEMPLATE = "";

    public static final String GET_ERRORCODE_AND_SHORTDESCRIPTION = "SELECT ErrorCode,ShortDescription FROM bvms_error";
}
