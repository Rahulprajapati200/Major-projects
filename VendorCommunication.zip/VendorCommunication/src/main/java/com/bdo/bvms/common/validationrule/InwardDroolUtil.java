package com.bdo.bvms.common.validationrule;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.math3.util.Precision;


import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.util.ErrorCodes;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class InwardDroolUtil {
	

	public boolean checkBOEDetailforImport(String invoiceCategory, String boeNum, String boeDate, String port) {
		if(StringUtils.isBlank(boeDate))
		{
			boeDate="0";
		}
		if ("impg".equalsIgnoreCase(invoiceCategory) || "impgsez".equalsIgnoreCase(invoiceCategory)) {
			if (boeNum.equals("") && boeDate.equals("") && port.equals("")) {
				return true;
			}
			
			if ("0".equals(boeNum) && ("0".equals(boeDate) || "31/12/1899".equals(boeDate) || "31-12-1899".equals(boeDate)) && "0".equals(port)) {	
				return true;
			}

			if ((!"".equals(boeNum) && !"0".equals(boeNum)) && (!"".equals(boeDate) && !"0".equals(boeDate)) && (!"".equals(port) && !"0".equals(port))) {
				return true;
			} else {
				return false;
			}
		}

		return true;
	}
	
	public boolean checkSEZWOPAYAmount(String invoiceCategory, String sgstAmt, String igstAmt, String cgstAmt) {
		String methodName="checkSEZWOPAYAmount";
		if ("sezwop".equalsIgnoreCase(invoiceCategory)) {
			try {
			if ((Double.parseDouble(sgstAmt) + Double.parseDouble(cgstAmt) + Double.parseDouble(igstAmt) == 0)
					|| (Double.parseDouble(sgstAmt) + Double.parseDouble(cgstAmt) + Double.parseDouble(igstAmt) == 0.0)) {
				return true;
			} else {
				return false;
			}
		}catch(Exception ex) {
			log.error(Constants.LOGERRORMESSAGE,methodName, ex);
			return false;
		}
			
		}
		return true;
	}

	public boolean isValidFutureAckDate(String value)  {
		
			if (StringUtils.isBlank(value) || "00-01-1900".equals(value) || "00/01/1900".equals(value) || "31-12-1899".equals(value) || "31/12/1899".equals(value)) {
				return true;
			} else {
				SimpleDateFormat sdf = null;
				value = value.replace('/', '-');
				sdf = new SimpleDateFormat("dd-MM-yyyy");

				try {
					Date shippingDate = sdf.parse(value);
					Date shippingDate2 = sdf.parse(sdf.format(shippingDate));
					Date sysDate = new Date();
					Date todayDate = sdf.parse(sdf.format(sysDate));
					if (todayDate.compareTo(shippingDate2) < 0) {
						return false;
					}
					return true;
				} catch (Exception ex) {
					return true;
				}
			}
		
	}

	public boolean checkPercentageWithoutIndicator(String indicator, String percentage) {
		
		if ((StringUtils.isBlank(indicator) || "0".equalsIgnoreCase(indicator)) && (StringUtils.isBlank(percentage) || "0".equalsIgnoreCase(percentage))) {
			return true;
		}

		else if ((StringUtils.isBlank(indicator)) && (StringUtils.isNotBlank(percentage))) {
			return false;
		}

		return true;
	}

	public boolean checkindicatorWithoutPercentage(String indicator, String percentage) {
		 if ((StringUtils.isBlank(indicator)) && (StringUtils.isBlank(percentage))) {
			return true;
		}
		if ("INELG-17(5)".equalsIgnoreCase(indicator) || "INELG-OTH".equalsIgnoreCase(indicator) || "REV-42&43".equals(indicator) || "REV-OTH".equals(indicator)) {
			if ((!"".equals(indicator)) && ("".equals(percentage))) {
				return false;
			}
		}
		return true;
	}


	public boolean checkNilRated(String docType, String sgstAmt, String cgstAmt, String igstAmt, String cessAmt, String nilratedAmt, String exemptedAmt, String nonGstAmt,
			String compositionAmt) {
		try {
			if (!"bill of supply".equalsIgnoreCase(docType)) {
				if (Double.parseDouble(nilratedAmt) > 0 || Double.parseDouble(exemptedAmt) > 0 || Double.parseDouble(nonGstAmt) > 0 || Double.parseDouble(compositionAmt) > 0) {
					return false;
				}
			} else {
				if (("0.00".equals(sgstAmt) && "0.00".equals(igstAmt) && "0.00".equals(cgstAmt) && "0.00".equals(cessAmt))
						|| ("0".equals(sgstAmt) && "0".equals(igstAmt) && "0".equals(cgstAmt) && "0".equals(cessAmt))) {
					if ((Double.parseDouble(nilratedAmt) > 0) && (Double.parseDouble(exemptedAmt) == 0) && (Double.parseDouble(nonGstAmt) == 0)
							&& (Double.parseDouble(compositionAmt) == 0)) {
						return true;
					} else if ((Double.parseDouble(exemptedAmt) > 0) && (Double.parseDouble(nilratedAmt) == 0) && (Double.parseDouble(nonGstAmt) == 0)
							&& (Double.parseDouble(compositionAmt) == 0)) {
						return true;
					} else if ((Double.parseDouble(nonGstAmt) > 0) && (Double.parseDouble(nilratedAmt) == 0) && (Double.parseDouble(exemptedAmt) == 0)
							&& (Double.parseDouble(compositionAmt) == 0)) {
						return true;
					} else if ((Double.parseDouble(compositionAmt) > 0) && (Double.parseDouble(nilratedAmt) == 0) && (Double.parseDouble(exemptedAmt) == 0)
							&& (Double.parseDouble(nonGstAmt) == 0)) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			}

		} catch (Exception ex) {
				log.error("Error generated:",ex);
			return false;
		}
		return true;
	}

	public boolean checkAmtAgainstItcAmt(String normalValue, String itcValue) {
		try {
			if (Double.parseDouble(normalValue) < Double.parseDouble(itcValue)) {
				return false;
			}
		} catch (Exception ex) {
			return false;
		}

		return true;
	}

	public boolean checkItcEligible(String itcEligible) {
		boolean x=false;
		if ("Eligible".equalsIgnoreCase(itcEligible) || "Ineligible".equalsIgnoreCase(itcEligible)) {
			x= true;
		}

		return x;
	}

	public boolean checkAllCgstSgstAmount(String sgstAmtStr, String cgstAmtStr, String docType) {
		try {
			Double sgstAmt = Double.parseDouble(sgstAmtStr);
			Double cgstAmt = Double.parseDouble(cgstAmtStr);

			if (!"isd invoice".equalsIgnoreCase(docType)) {
				if (!(sgstAmt).equals(cgstAmt)) {
					return false;
				}
				return true;
			}
		} catch (Exception ex) {
			return false;
		}
		return true;
	}


	public boolean checkAllThreeAmount(String docType, String sgstAmtStr, String cgstAmtStr, String igstAmtStr) {
		try {
			Double sgstAmt = Double.parseDouble(sgstAmtStr);
			Double cgstAmt = Double.parseDouble(cgstAmtStr);
			Double igstAmt = Double.parseDouble(igstAmtStr);
			if (sgstAmt > 0 && cgstAmt > 0 && igstAmt > 0 && !"isd invoice".equalsIgnoreCase(docType)) {
				return false;
			}
		} catch (Exception ex) {
			return false;
		}

		return true;
	}

	public boolean checkInwardTaxCalculationCgstSgstDiff(String docType, String diffPercent, Boolean valid, String taxableAmtStr, String sgstRateStr, String cgstRateStr,
			String sgstAmtStr, String cgstAmtStr, String isDiluted) {
		try {

			Double taxableAmt = Double.parseDouble(taxableAmtStr);
			Double sgstRate = Double.parseDouble(sgstRateStr);
			Double cgstRate = Double.parseDouble(cgstRateStr);
			Double sgstAmt = Double.parseDouble(sgstAmtStr);
			Double cgstAmt = Double.parseDouble(cgstAmtStr);


			Boolean isDilutedValue = checkIfDiluted(isDiluted, ErrorCodes.TAXCALUCULATIONWITHDIFF);
			if (!Boolean.FALSE.equals(isDilutedValue)) {
				if (!"isd invoice".equalsIgnoreCase(docType)) {
					
					if (taxableAmt != null && sgstRate != null && cgstRate != null) {
						try {
							double calSamt = taxableAmt * (sgstRate / 100) * 0.65;
							double calCamt = taxableAmt * (sgstRate / 100) * 0.65;
							sgstAmt = (double) (sgstAmt);
							cgstAmt = (double) (cgstAmt);
							double newRoundSamt = Precision.round(calSamt, 4);
							double newRoundCamt = Precision.round(calCamt, 4);

							double newRoundTwoSamt = Precision.round(newRoundSamt, 2);
							double newRoundTwoCamt = Precision.round(newRoundCamt, 2);

							//if (valid) {
							boolean x;
								if (newRoundTwoCamt == sgstAmt && newRoundTwoSamt == cgstAmt) {
									x= true;
								} else {
									x= false;
								}
								return x;
							//}
						} catch (Exception ex) {
								log.error("Error generated:",ex);
							return false;
						}
					}
				}
			}
		} catch (Exception ex) {
			return false;
		}

		return true;
	}


	public boolean checkInwardTaxCalculationIgst(String docType, String diffPercent, Boolean valid, String taxableAmtStr, String igstRateStr, String igstAmtStr,
			String isDiluted) {
		boolean x=true;
		try {
			Double taxableAmt = Double.parseDouble(taxableAmtStr);
			Double igstRate = Double.parseDouble(igstRateStr);
			Double igstAmt = Double.parseDouble(igstAmtStr);

			Boolean isDilutedValue = checkIfDiluted(isDiluted, ErrorCodes.TAXCALUCULATIONWITHDIFF);
			if (!Boolean.FALSE.equals(isDilutedValue)) {
				if (!"isd invoice".equalsIgnoreCase(docType)) {
					
					if (taxableAmt != null && igstRate != null) {

						try {
							double calIamt = taxableAmt * (igstRate / 100) * 0.65;
							igstAmt = (double) (igstAmt);

							double newRoundIamt = Precision.round(calIamt, 4);
							double newRoundTwoIamt = Precision.round(newRoundIamt, 2);

							//if (valid) {
								if (newRoundTwoIamt == igstAmt) {
									x= true;
								} else {
									x= false;
								}
							//}

						} catch (Exception ex) {
								log.error("Error generated:",ex);
							 return false;
						}

					}
				}
			}
		} catch (Exception ex) {
			return false;
		}
		return x;
	}

	public boolean checkdiffpercentage(String diffPercent) {
		boolean x=false;
		if (StringUtils.isBlank(diffPercent) || "0.65".equals(diffPercent) || "0.00".equals(diffPercent) || "0".equals(diffPercent)) {
			x= true;
		}
		return x;
	}

	public boolean checkGstnIsd(String gstin, String docType) {
		boolean isValid = true;
		if ("isd invoice".equalsIgnoreCase(docType)) {
			if (gstin.length() < 15 || " ".equals(gstin) || "0".equals(gstin) || "".equals(gstin)) {
				isValid = false;
			}
		}
		return isValid;
	}

	public boolean checkRateISD(String sgstRate, String cgstRate, String igstRate, String docType) {
		boolean isValid = true;
		if ("isd invoice".equalsIgnoreCase(docType)) {
			if (Double.parseDouble(sgstRate) + Double.parseDouble(cgstRate) + Double.parseDouble(igstRate) > 0) {
				isValid = false;
			}

		}
		return isValid;
	}

	public boolean checkTaxableISD(String amount, String docType) {
		boolean isvalid = true;
		if ("isd invoice".equalsIgnoreCase(docType)) {
			try {
			if (Double.parseDouble(amount) > 0 || Double.parseDouble(amount) < 0.00) {
				isvalid = false;
			}
			}catch(Exception ex) {
				log.error("Exception in checkTaxableISD method ",ex);
				isvalid = false;
			}
		}
		return isvalid;
	}

	public boolean checkTaxableRegular(String amount, String docType) {
		if (!"isd invoice".equalsIgnoreCase(docType)) {
			if (Double.parseDouble(amount) == 0 || Double.parseDouble(amount) == 0.0 || Double.parseDouble(amount) == 0.00) {
				return false;
			}
		}
		return true;
	}

	public boolean checkForImportTypeISD(String importType, String docType, String hsnSacCode) {
		boolean isValidHSNFormat = true;
		boolean validImportType = true;

		if ("isd invoice".equalsIgnoreCase(docType)) {
			if ("inputs".equalsIgnoreCase(importType) || "capital goods".equalsIgnoreCase(importType)) {
				return false;
			}
			String newHsn = "";
			if (StringUtils.isBlank(importType) || importType.equals("0")) {
				validImportType = false;
			}

			newHsn = hsnSacCode;
			if (!newHsn.matches("^\\d+$")) {
				isValidHSNFormat = false;
			}
			if (isValidHSNFormat && "0".equals(newHsn)) {
				isValidHSNFormat = false;
			}
			if (isValidHSNFormat && !validImportType) {
				if (newHsn.length() == 1) {
					newHsn = "0" + newHsn;
				}
				String sacCode = newHsn.substring(0, 2);
				if (Double.parseDouble(sacCode) == 99) {
					if ("inputs".equalsIgnoreCase(importType) || "capital goods".equalsIgnoreCase(importType)) {
						return false;
					} else {
						return true;
					}
				} else {
					return false;
				}
			}

		}
		return true;
	}


	public boolean checkInwardTaxCalculationIgstWithoutDiff(String docType, String supplierStateCode, Boolean valid, String taxableAmtStr, String igstRateStr, String igstAmtStr
			) {

		String methodName="checkInwardTaxCalculationIgstWithoutDiff";
		Double taxableAmt = Double.parseDouble(taxableAmtStr);
		Double igstRate = Double.parseDouble(igstRateStr);
		Double igstAmt = Double.parseDouble(igstAmtStr);
		boolean x=true;
		
		
			if (!"isd invoice".equalsIgnoreCase(docType)) {

				try {
					
					if (taxableAmt != null && igstRate != null) {
						double calIamt = taxableAmt * (igstRate / 100);
						igstAmt = (double) (igstAmt);
						double newRoundIamt = Precision.round(calIamt, 4);
						double newRoundTwoIamt = Precision.round(newRoundIamt, 2);
					
//						if (valid) {
							if (newRoundTwoIamt == igstAmt) {
								x= true;
							} else {
								x= false;
							}
//						}
					}
				} catch (Exception ex) {
					log.error(Constants.LOGERRORMESSAGE,methodName);
					return false;
				}
			}
		
		return x;		
	}


	public boolean checkInwardTaxCalculationCgstSgst(String docType, String supplierStateCode, Boolean valid, String taxableAmtStr, String sgstRateStr, String cgstRateStr,
			String sgstAmtStr, String cgstAmtStr, String isDiluted) {

		try {

			Double taxableAmt = Double.parseDouble(taxableAmtStr);
			Double sgstRate = Double.parseDouble(sgstRateStr);
			Double cgstRate = Double.parseDouble(cgstRateStr);
			Double sgstAmt = Double.parseDouble(sgstAmtStr);

			Double cgstAmt = Double.parseDouble(cgstAmtStr);

			boolean isDilutedValue = checkIfDiluted(isDiluted, ErrorCodes.TAXCALICULATIONWITHOUTDIFF);
			if (!isDilutedValue && (!"isd invoice".equalsIgnoreCase(docType)) && (taxableAmt != null && sgstRate != null && cgstRate != null)) {
				
						try {
							double calSamt = taxableAmt * (sgstRate / 100);
							double calCamt = taxableAmt * (cgstRate / 100);


							sgstAmt = (double) (sgstAmt);
							cgstAmt = (double) (cgstAmt);

							double newRoundSamt = Precision.round(calSamt, 4);
							double newRoundCamt = Precision.round(calCamt, 4);

							double newRoundTwoSamt = Precision.round(newRoundSamt, 2);
							double newRoundTwoCamt = Precision.round(newRoundCamt, 2);

//							if (valid) {
								if (newRoundTwoSamt == sgstAmt && newRoundTwoCamt == cgstAmt) {
									return true;
								} else {
									return false;
								}
//							}
						} catch (Exception ex) {
								log.error("Error generated:",ex);
							return false;
						}

					
			}

		} catch (Exception ex) {
			return false;
		}
		return true;
	}


	public boolean checkForImportType(String importType) {
		boolean validImportType = true;
		if (StringUtils.isBlank(importType) || "0".equalsIgnoreCase(importType)) {
			validImportType = false;
		}
		if (validImportType) {
			if (!"inputs".equalsIgnoreCase(importType) && !"Input Services".equalsIgnoreCase(importType) && !"capital goods".equalsIgnoreCase(importType)) {
				return false;
			} else {
				return true;
			}
		}
		return true;
	}

	public boolean checkSupplyType(String orgInvoice) {
		
		if ("b2b".equalsIgnoreCase(orgInvoice) || "dexp".equalsIgnoreCase(orgInvoice) || "rcm".equalsIgnoreCase(orgInvoice) || "comp".equalsIgnoreCase(orgInvoice)
				|| "nil".equalsIgnoreCase(orgInvoice) || "exm".equalsIgnoreCase(orgInvoice) || "non".equalsIgnoreCase(orgInvoice) || "isd".equalsIgnoreCase(orgInvoice)
				|| "sezwp".equalsIgnoreCase(orgInvoice) || "sezwop".equalsIgnoreCase(orgInvoice) || "impgsez".equalsIgnoreCase(orgInvoice) || "impg".equalsIgnoreCase(orgInvoice)
				|| "imps".equalsIgnoreCase(orgInvoice)) {
			return true;
		} else {
		return false;
		}
	
	}


	public boolean checkForInterSEZIMP(String docType, String sgstRate, String cgstRate, String igstRate, String igstAmt, String cgstAmt, String sgstAmt, String originalDocType,
			String orgInvoiceCategory) {
		try {
			if ("sez invoice".equalsIgnoreCase(originalDocType) && "sezwop".equalsIgnoreCase(orgInvoiceCategory)) {
				return true;
			} else {
				if ("import invoice".equalsIgnoreCase(originalDocType) || ("sez invoice".equalsIgnoreCase(originalDocType) && orgInvoiceCategory.equalsIgnoreCase("sezwp"))
						|| "impgsez".equalsIgnoreCase(orgInvoiceCategory)) {
					if (Double.parseDouble(cgstAmt) + Double.parseDouble(sgstAmt) != 0) {
						return false;
					} else if (Double.parseDouble(igstAmt) > 0) {
						return true;
					}
				}
			}

		} catch (Exception ex) {
				log.error("Error generated:",ex);
			return false;
		}

		return true;
	}

	public boolean checkValueAgainstTaxableGross(String igstRate, String cgstRate, String sgstRate, String inwardTotalTaxAmt, String inwardGrossTotalAmt, String docType) {
		boolean isValid = true;

		try {

			if ("isd invoice".equalsIgnoreCase(docType)) {
				isValid = true;
			}
			if ("bill of supply".equalsIgnoreCase(docType)) {
				if (Double.parseDouble(inwardGrossTotalAmt) == 0 || Double.parseDouble(inwardGrossTotalAmt) == 0.0 || Double.parseDouble(inwardGrossTotalAmt) == 0.00) {
					isValid = false;
				} else {
					isValid = true;
				}
			}
		} catch (Exception ex) {
			isValid = false;
		}

		return isValid;
	}


	public boolean checkRateAgainstAmounts(String rate, String value, String docType) {

		boolean isValid = true;
		try {
			if ("isd Invoice".equalsIgnoreCase(docType)) {
				isValid = true;
			} else {
				if (Double.parseDouble(rate) > 0
						&& (Double.parseDouble(value) == 0 || Double.parseDouble(value) == 0.00 || value.isEmpty() || StringUtils.isBlank(value))) {
					isValid = false;
				}
			}

		} catch (Exception ex) {
			isValid = false;
		}
		return isValid;
	}


	public boolean checkHsnImportGoods(String docType, String importType, String hsnSacCode) {

		try {

			boolean isValidHSNFormat = true;
			boolean validImportType = true;
			String newHsn = "";
			if (StringUtils.isBlank(importType) || "0".equals(importType)) {
				validImportType = false;
			}

			newHsn = hsnSacCode;
			if (!newHsn.matches("^\\d+$")) {
				isValidHSNFormat = false;
			} else {
				if (isValidHSNFormat && "0".equals(newHsn)) {
					isValidHSNFormat = false;
				}
				if (isValidHSNFormat && validImportType) {
					if (newHsn.length() == 1) {
						newHsn = "0" + newHsn;
					}
					String sacCode = newHsn.substring(0, 2);
					if (Double.parseDouble(sacCode) == 99) {
						if ("Input Services".equalsIgnoreCase(importType)) {
							return true;
						} else {
							return false;
						}
					} else {
						if ("Input Services".equalsIgnoreCase(importType)) {
							return false;
						} else {
							return true;
						}
					}
				}
			}

		} catch (Exception ex) {
				log.error("Error generated:",ex);
			return false;
		}


		return true;
	}


	public boolean isValidRate(String sgstValStr, String cgstValStr, List<String> govtRatesList) {

		boolean isValid = true;

		try {
			Double sgstVal = Double.parseDouble(sgstValStr);
			Double cgstVal = Double.parseDouble(cgstValStr);
			if (sgstVal != null && cgstVal != null) {
				double val = sgstVal + cgstVal;
				if (sgstValStr.equals(cgstValStr) && govtRatesList.contains(String.valueOf(val))) {
					isValid = true;
				}else {
					isValid = false;
				}
			} else {
				isValid = false;
			}
		} catch (Exception ex) {
			isValid = false;

		}


		return isValid;
	}


	public boolean checkImportDoctypeGstin(String docType, String gstinOfSupplier) {
		if ("import invoice".equalsIgnoreCase(docType)) {
			if ("0".equals(gstinOfSupplier) || StringUtils.isBlank(gstinOfSupplier)) {
				return true;
			} else {
				return false;
			}
		}
		return true;
	}


	public boolean checkDeemedGstin(String docType, String gstinOfSupplier) {
	
		boolean x=true;
		if ("deemed export invoice".equalsIgnoreCase(docType) ) {
			if (StringUtils.isBlank(gstinOfSupplier) ||gstinOfSupplier.length() < 15 || "0".equals(gstinOfSupplier) ) {
				x= false;
			} else {
				x= true;
			}
		}
		
		return x;
	}


	public boolean checkRegularGstin(String docType, String gstinOfSupplier) {
		if ("regular tax invoice".equalsIgnoreCase(docType) && gstinOfSupplier != null) {
			if (gstinOfSupplier.length() < 15 || "0".equals(gstinOfSupplier) || StringUtils.isBlank(gstinOfSupplier)) {
				return false;
			} else {
				return true;
			}
		}
		return true;
	}


	public boolean checkSezGstin(String docType, String gstinOfSupplier) {
		boolean x=true;
		if ("sez invoice".equalsIgnoreCase(docType) ) {
			if (StringUtils.isBlank(gstinOfSupplier)||gstinOfSupplier.length() < 15 || "0".equals(gstinOfSupplier) ) {
				x= false;
			} else {
				x= true;
			}
		}
		return x;
	}
	
	public boolean checkSezGstin(String docType,String gstinOfSupplier,String originalDocType){
		if("sez invoice".equals(originalDocType)){
			if( StringUtils.isBlank(gstinOfSupplier) ||  gstinOfSupplier.length() < 15 || "0".equals(gstinOfSupplier) ){
				return false;
			}
			else{
				return true;
			}
		}
			return true;
	}



	public boolean isValidFP(String value, String fp) {
		if (StringUtils.isBlank(value) || "0".equals(value) || "-".equals(value) || value.matches(Constants.VALIDFP)) {
			return false;
		} else {

			try {

				if (value.indexOf("-") > 0) {
					String[] parts = value.split("-");
					String month = parts[1];
					String year = parts[2];
					int fpLength = fp.length();
					if (fpLength == 5) {
						fp = "0" + fp;
					}
					String monthFP = fp.substring(0, 2);
					String yearFP = fp.substring(2, 6);
					if (Double.parseDouble(year) < 2017) {
						return false;
					}
					if (Double.parseDouble(year) > Double.parseDouble(yearFP)) {
						return false;
					} else if (Double.parseDouble(year) == 2017) {
						if (Double.parseDouble(month) < 7 || Double.parseDouble(month) > 12) {
							return false;
						}
					} else {
						if (Double.parseDouble(month) < 0 || Double.parseDouble(month) > 12) {
							return false;
						}

						
						if (Double.parseDouble(month) < Double.parseDouble(monthFP) || Double.parseDouble(month) > Double.parseDouble(monthFP)) {
							if (Double.parseDouble(year) == Double.parseDouble(yearFP)) {
								if (Double.parseDouble(month) > Double.parseDouble(monthFP)) {
									return false;
								}
								return true;
							} else if (Double.parseDouble(year) < Double.parseDouble(yearFP)) {
								return true;
							} else {
								return false;
							}
						}

						if (Double.parseDouble(month) == Double.parseDouble(monthFP)) {
							if (Double.parseDouble(year) <= Double.parseDouble(yearFP)) {
								if (Double.parseDouble(month) > Double.parseDouble(monthFP)) {
									return false;
								}
								return true;
							} else {
								return false;
							}
						}
					}
					return true;
				} else {
					String[] parts = value.split("/");
					String month = parts[1];
					String year = parts[2];
					int fpLength = fp.length();
					if (fpLength == 5) {
						fp = "0" + fp;
					}
					String monthFP = fp.substring(0, 2);
					String yearFP = fp.substring(2, 6);
					if (Double.parseDouble(year) < 2017) {
						return false;
					} else if (Double.parseDouble(year) == 2017) {
						if (Double.parseDouble(month) < 7 || Double.parseDouble(month) > 12) {
							return false;
						}
					} else {
						if (Double.parseDouble(month) < 0 || Double.parseDouble(month) > 12) {
							return false;
						}

						if (Double.parseDouble(month) < Double.parseDouble(monthFP) || Double.parseDouble(month) > Double.parseDouble(monthFP)) {
							if (Double.parseDouble(year) == Double.parseDouble(yearFP)) {
								if (Double.parseDouble(month) > Double.parseDouble(monthFP)) {
									return false;
								}
								return true;
							} else if (Double.parseDouble(year) < Double.parseDouble(yearFP)) {
								return true;
							} else {
								return false;
							}
						}

						if (Double.parseDouble(month) == Double.parseDouble(monthFP)) {
							if (Double.parseDouble(year) <= Double.parseDouble(yearFP)) {
								if (Double.parseDouble(month) > Double.parseDouble(monthFP)) {
									return false;
								}
								return true;
							} else {
								return false;
							}
						}
					}
					return true;
				}


			} catch (Exception ex) {
				return false;
			}
		}
	}

	public boolean isValidInvoiceDate(String value) {
	
		if (StringUtils.isBlank(value) || value.matches(Constants.REGX_DATEPATTERN) ||  "0".equals(value) || "".equals(value) || "-".equals(value)) {
			return false;
		} else {
			try {
			if (value.indexOf("-") > 0) {
				String[] parts = value.split("-");
				if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
					int date = Integer.parseInt(parts[0]);
					int month = Integer.parseInt(parts[1]);
					int year = Integer.parseInt(parts[2]);
					if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

						Calendar c = Calendar.getInstance();
						c.set(Calendar.DAY_OF_MONTH, date);
						c.set(Calendar.MONTH, month - 1);
						c.set(Calendar.YEAR, year);

						try {
							SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
							formatter.setLenient(false);
							formatter.parse(value);
							return true;

						} catch (ParseException e) {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				String[] parts = value.split("/");
				if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
					int date = Integer.parseInt(parts[0]);
					int month = Integer.parseInt(parts[1]);
					int year = Integer.parseInt(parts[2]);
					if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

						Calendar c = Calendar.getInstance();
						c.set(Calendar.DAY_OF_MONTH, date);
						c.set(Calendar.MONTH, month - 1);
						c.set(Calendar.YEAR, year);

						try {
							SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
							formatter.setLenient(false);
							formatter.parse(value);
							return true;

						} catch (ParseException e) {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			}
			}catch(Exception ex) {
				return false;
			}
		}
	
		
	}

	
	
	public boolean checkInwardIntra(String gstinOfRecipient, String docType, String sgstAmt, String igstAmt, String cgstAmt, String placeOfSupply, String supplierStateCode,
			String importType, String reverseCharge) {
		
			if ("regular tax invoice".equalsIgnoreCase(docType) || "rcm invoice".equalsIgnoreCase(docType)) {
				if (StringUtils.isNotBlank(placeOfSupply) && StringUtils.isNotBlank(supplierStateCode) && placeOfSupply.matches("^\\d+$") && supplierStateCode.matches("^\\d+$")) {

					try {

						if (Double.parseDouble(supplierStateCode) == Double.parseDouble(placeOfSupply)) {
							if (Double.parseDouble(igstAmt) != 0) {
								return false;
							} else if (Double.parseDouble(cgstAmt) + Double.parseDouble(sgstAmt) > 0) {
								return true;
							}
						}

					} catch (Exception ex) {
						return false;
					}

				}
			}
		
		return true;
	}
	

	public boolean checkInwardInter(String gstinOfRecipient, String docType, String sgstAmt, String igstAmt, String cgstAmt, String placeOfSupply, String supplierStateCode,
			String importType, String reverseCharge) {
		
			if ("regular tax invoice".equalsIgnoreCase(docType) || "rcm invoice".equalsIgnoreCase(docType)) {
				if (StringUtils.isNotBlank(placeOfSupply) && StringUtils.isNotBlank(supplierStateCode) && placeOfSupply.matches("^\\d+$") && supplierStateCode.matches("^\\d+$")) {

					try {
						if (Double.parseDouble(supplierStateCode) != Double.parseDouble(placeOfSupply)) {
							if (Double.parseDouble(cgstAmt) + Double.parseDouble(sgstAmt) != 0) {
								return false;
							} else if (Double.parseDouble(igstAmt) > 0) {
								return true;
							}
						}
					} catch (Exception ex) {
							log.error("Error generated:",ex);
						return false;
					}

				}
			}
		
		return true;
	}
	

	public boolean checkIfDiluted(String dilutedValidationString, String errorID) {
		if (StringUtils.isBlank(dilutedValidationString)) {
			return false;
		} else {
			return dilutedValidationString.contains(errorID);
		}
	}


	public boolean checkReverseChargeForRCM(String reverseCharge, String docType, String importType, String hsnSacCode) {

		if ("import invoice".equalsIgnoreCase(docType)) {
			if (StringUtils.isBlank(importType) || "0".equals(importType)) {
				importType = checkForIMPGImport(docType, hsnSacCode, importType);
			}
			if (("inputs".equalsIgnoreCase(importType) || "capital goods".equalsIgnoreCase(importType)) && "y".equalsIgnoreCase(reverseCharge)) {
				return false;
			}
			if ("Input Services".equalsIgnoreCase(importType) && "n".equalsIgnoreCase(reverseCharge)) {
				return false;
			}
		} else {
			if ("rcm invoice".equalsIgnoreCase(docType) && "n".equalsIgnoreCase(reverseCharge)) {
				return false;
			}
			if ("regular tax invoice".equalsIgnoreCase(docType) && "y".equalsIgnoreCase(reverseCharge)) {
				return true;
			}
			if (!"rcm invoice".equalsIgnoreCase(docType) && "y".equalsIgnoreCase(reverseCharge)) {
				return false;
			}
		}
		return true;
	}

	public String checkForIMPGImport(String docType, String hsnSacCode, String importType) {
		if ("import invoice".equalsIgnoreCase(docType)) {
			boolean validImportType = true;
			boolean validHsnType = true;
			if (StringUtils.isBlank(importType)) {
				validImportType = false;
			}
			if (StringUtils.isBlank(hsnSacCode)) {
				validHsnType = false;
			}
			if ((!validImportType && !validHsnType) || ("0".equals(importType) && "0".equals(hsnSacCode))) {
				return "inputs";
			}
			if (validHsnType) {
				if (hsnSacCode.length() == 1) {
					hsnSacCode = "0" + hsnSacCode;
				}
				String sacCode = hsnSacCode.substring(0, 2);
				if (Double.parseDouble(sacCode) != 99 && (!validImportType || "0".equals(importType))) {
					return "Input Services";
				} else {
					return "inputs";
				}
			} else if (!validHsnType && "0".equals(importType)) {
				return "input serivces";
			}
			return "input";
		}
		return "input";
	}



public boolean validGSTIN(String gstin) {
	
	try {
	
	if(!"0".equals(gstin)){
		String gstinFormateRegex = "[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[Z]{1}[0-9a-zA-Z]{1}";
		 String uiFormatRegex = "[0-9]{4}[A-Z]{3}[0-9]{5}[UO]{1}[N][A-Z0-9]{1}";
		 		 String tdsREGEX = "[0-9]{2}[a-zA-Z]{4}[a-zA-Z0-9]{1}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[D]{1}[0-9a-zA-Z]{1}";
		 
		boolean isValidFormat = false;

  
        if(gstin.length()<15){
        	return isValidFormat;
        }
        
        if (checkPattern(gstin, gstinFormateRegex) || checkPattern(gstin, tdsREGEX)) {
        	isValidFormat = verifyCheckDigit(gstin);
        }else if(checkPattern(gstin,uiFormatRegex)){
       	 	isValidFormat = verifyCheckDigit(gstin);
        }
        return isValidFormat;     
    }
	
	}catch(Exception ex) {
		log.error("Exception in validGSTIN method ",ex);
		return false;
	}	
	return true;
}


public boolean validTdsGSTIN(String gstin) {
	
	try {
	
	
		String gstinFormateRegex = "[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[Z]{1}[0-9a-zA-Z]{1}";
		 String uiFormatRegex = "[0-9]{4}[A-Z]{3}[0-9]{5}[UO]{1}[N][A-Z0-9]{1}";
		 		 String tdsREGEX = "[0-9]{2}[a-zA-Z]{4}[a-zA-Z0-9]{1}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[D]{1}[0-9a-zA-Z]{1}";
		 
		boolean isValidFormat = false;

  
        if(gstin.length()<15){
        	return isValidFormat;
        }
        
        if (checkPattern(gstin, gstinFormateRegex) || checkPattern(gstin, tdsREGEX)) {
        	isValidFormat = verifyCheckDigit(gstin);
        }else if(checkPattern(gstin,uiFormatRegex)){
       	 	isValidFormat = verifyCheckDigit(gstin);
        }
        return isValidFormat;     
    
	
	}catch(Exception ex) {
		log.error("Exception in validGSTIN method ",ex);
		return false;
	}	
	
}





public boolean checkPattern(String inputval, String regxpatrn) {
    	boolean result = false;
    	if ((inputval.trim()).matches(regxpatrn)) {
    		result = true;
    	}
    	return result;
    }

public boolean verifyCheckDigit(String gstinWCheckDigit) {
    	Boolean isCDValid = false;
    	String newGstninWCheckDigit = getGSTINWithCheckDigit(gstinWCheckDigit.substring(0, gstinWCheckDigit.length()-1));
    	if (gstinWCheckDigit.trim().equals(newGstninWCheckDigit)) {
    		isCDValid = true;
    	}
    	return isCDValid;
    }
    
    
public String getGSTINWithCheckDigit(String gstinWOCheckDigit){
		
		String gstinCodePountChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";		
		
		int factor = 2;
		int sum = 0;
		int checkCodePoint = 0;
		char[] cpChars;
		char[] inputChars;
			
        
			if (gstinWOCheckDigit == null) {
				
				return "";
			}
			cpChars = gstinCodePountChars.toCharArray();
			inputChars = gstinWOCheckDigit.trim().toUpperCase().toCharArray();

			
						
			int mod = cpChars.length;
			for (int i = inputChars.length - 1; i >= 0; i--) {
				int codePoint = -1;
				
				for (int j = 0; j < cpChars.length; j++) {
					if (cpChars[j] == inputChars[i]) {
						codePoint = j;
					}
				}
				int digit = factor * codePoint;
				factor = (factor == 2) ? 1 : 2;
				digit = (digit / mod) + (digit % mod);
				sum += digit;
			}
			checkCodePoint = (mod - (sum % mod)) % mod;
			
			return gstinWOCheckDigit + cpChars[checkCodePoint];			
						
}


	public boolean checkForImportTypeIMPGSEZ(String importType, String docType, String hsnSacCode) {
		boolean isValidHSNFormat = true;
		boolean validImportType = true;

		if ("impgsez".equalsIgnoreCase(docType)) {
			if ("inputs".equalsIgnoreCase(importType) || "capital goods".equalsIgnoreCase(importType)) {
				return true;
			}
			if ("Input Services".equalsIgnoreCase(importType)) {
				return false;
			}
			String newHsn = "";
			if (StringUtils.isBlank(importType) || "0".equals(importType)) {
				validImportType = false;
			}

			newHsn = hsnSacCode;
			if (!newHsn.matches("^\\d+$")) {
				isValidHSNFormat = false;
			}
			if (isValidHSNFormat && "0".equals(newHsn)) {
				isValidHSNFormat = false;
			}
			if (isValidHSNFormat && !validImportType) {

				try {

					if (newHsn.length() == 1) {
						newHsn = "0" + newHsn;
					}
					String sacCode = newHsn.substring(0, 2);
					if (Double.parseDouble(sacCode) == 99) {

						return false;

					} else {
						return true;
					}
				} catch (Exception ex) {
					return false;

				}

			}

		}
		return true;
	}


	public boolean isAlphanumeric(String s) {

		boolean validInvoice = true;
		if (StringUtils.isBlank(s)) {
			validInvoice = false;
		}

		if (validInvoice) {

			Pattern p = Pattern.compile("[^0-9A-Za-z]");
			Matcher m = p.matcher(s);
			if (m.find()) {
				validInvoice = false;
			}
		}
		return validInvoice;
	}

	public boolean isAlphanumericUDF(String s) {

		boolean validInvoice = true;
		if (StringUtils.isBlank(s)) {
			validInvoice = false;
		}

		if (validInvoice) {

			Pattern p = Pattern.compile("[^0-9A-Za-z_ ]");
			//Pattern p2 = Pattern.compile("[^a-zA-Z0-9()-'.,\" ]");
			Matcher m = p.matcher(s);
			if (m.find()) {
				validInvoice = false;
			}
		}
		return validInvoice;
	}
	
	public boolean checkItcPercentage(String itcPercentage) {
		try {

			if (StringUtils.isBlank(itcPercentage)) {
				return true;
			}
			if (containsNumbersOnly(itcPercentage, 2)) {
				if (Double.parseDouble(itcPercentage) >= 0.01 && Double.parseDouble(itcPercentage) <= 100) {
					return true;
				}
			}

		} catch (Exception ex) {
				log.error("Error generated:",ex);
			return false;
		}


		return false;
	}

	public boolean checkItcReversalIndicator(String itcIndicator) {
		if (StringUtils.isBlank(itcIndicator)) {
			return true;
		}
		if (itcIndicator.equalsIgnoreCase("REV-42&43") || itcIndicator.equalsIgnoreCase("REV-OTH") || itcIndicator.equalsIgnoreCase("INELG-17(5)")
				|| itcIndicator.equalsIgnoreCase("INELG-OTH") || itcIndicator.equalsIgnoreCase("OTHER")) {
			return true;
		}
		return false;
	}

	public boolean containsNumbersOnly(String source, Integer typeChk) {
		boolean result = false;
		if (StringUtils.isNotBlank(source)) {
			source = source.trim();
			try {
				if (typeChk == 1) {
					Pattern pattern;
					pattern = Pattern.compile("[0-9.]+"); // correct pattern for both float and integer. execute

					result = pattern.matcher(source).matches();

					return result;
				} else {
					Double.parseDouble(source);
					return true;
				}

			} catch (Exception ex) {
				return false;
			}
		} else {
			return false;
		}
	}


	public boolean isValidAckDate(String value) {
		if (StringUtils.isBlank(value) || "00-01-1900".equals(value) || "00/01/1900".equals(value) || "31-12-1899".equals(value) || "31/12/1899".equals(value)) {
			return true;
		}

		if (value.matches(Constants.VALIDACKREGEX) ||  "-".equals(value)) {

		if (value.matches(Constants.PURCHASEORDERREGE) || "-".equals(value) ) {

			return false;
		} else {
			try {
			if (value.indexOf("-") > 0) {
				String[] parts = value.trim().split("-");
				if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
					int date = Integer.parseInt(parts[0]);
					int month = Integer.parseInt(parts[1]);
					int year = Integer.parseInt(parts[2]);
					if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

						Calendar c = Calendar.getInstance();
						c.set(Calendar.DAY_OF_MONTH, date);
						c.set(Calendar.MONTH, month - 1);
						c.set(Calendar.YEAR, year);

						try {
							SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
							formatter.setLenient(false);
							formatter.parse(value);
							return true;

						} catch (ParseException e) {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				String[] parts = value.trim().split("/");
				if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
					int date = Integer.parseInt(parts[0]);
					int month = Integer.parseInt(parts[1]);
					int year = Integer.parseInt(parts[2]);
					if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

						Calendar c = Calendar.getInstance();
						c.set(Calendar.DAY_OF_MONTH, date);
						c.set(Calendar.MONTH, month - 1);
						c.set(Calendar.YEAR, year);

						try {
							SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
							formatter.setLenient(false);
							formatter.parse(value);
							return true;

						} catch (ParseException e) {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			}
	
		}catch(Exception ex) {
			log.error("Exception in isValidAckDate method ",ex);
			return false;
		}
			
		}
	}
		return true;
		
	}

	public boolean onlyNumericAckNo(String value) {

		boolean isvalid = true;
		if (StringUtils.isBlank(value)) {
			isvalid = false;
		} else {
			Pattern p = Pattern.compile("\\D");
			Matcher m = p.matcher(value);

			if (m.find()) {
				isvalid = false;
			}
		}
		return isvalid;

	}


	public boolean checkDocumentNumber(String docNo) {
		boolean result = true;

		if ("0".equals(docNo)) {
			result = false;
		}

		if (result) {
			Pattern p = Pattern.compile("[^0-9A-Za-z/-]");
			Matcher m = p.matcher(docNo);
			if (m.find()) {
				result = false;
			} else {
				result = true;
			}
		}
		return result;
		
	}

	public boolean checkLength12G(String value, Boolean valid) {
		boolean isValid = true;
		DecimalFormat df2 = new DecimalFormat(".##");
		boolean result = onlyNumeric(value);

		try {
			if (result && df2.format(Double.parseDouble(value)).length() > 12) {

				isValid = false;

			}
		} catch (Exception ex) {
			isValid = false;
		}

		return isValid;
	}


	public boolean checkLength12(String value, boolean valid) {
		boolean isvalid = true;
		DecimalFormat df2 = new DecimalFormat(".##");
		boolean result = onlyNumeric(value);
		if (result && df2.format(Double.parseDouble(value)).length() > 16) {
			isvalid = false;

		}

		return isvalid;
	}

	public boolean checkLength17HsnConf(String value) {
		
		if(StringUtils.isBlank(value)) {
			return true;
		}
		
		boolean isvalid = true;
		if (value != null && value.length() > 17) {
			isvalid = false;
		}

		return isvalid;
	}


	public boolean onlyNumericHSN(String value) {
		boolean isValid = true;
		if (StringUtils.isBlank(value)) {
			isValid = false;
		} else {
			Pattern p = Pattern.compile("\\D");
			Matcher m = p.matcher(value);

			if (m.find()) {
				isValid = false;
			} else {
				if (value.length() > 2) {
					isValid = false;
				}

			}
		}
		return isValid;
	}


	public boolean twoDecimalCheckBoe(String docType, String value) {
		boolean isValid = true;
		if (StringUtils.isBlank(value) || "0".equals(value)) {
			isValid = true;
			return isValid;
		}
		
		if ("b2cs summary invoice".equalsIgnoreCase(docType)) {

			if (!value.matches(Constants.TWODECIMALCHECKBOE)) {
				isValid = false;
			}

		} else {
			if (!value.matches(Constants.TWODECIMALCHECKBOE2)) {
				isValid = false;
			}
		}
		
		return isValid;
	}


	public boolean twoDecimalCheck(String docType, String value) {
		boolean isValid = true;
		try {
		if ("b2cs summary invoice".equalsIgnoreCase(docType)) {
			if (!value.matches(Constants.TWODECIMAL)) {
				isValid = false;
			}

		} else {
			if (!value.matches(Constants.TWODECIMAL2)) {
				isValid = false;
			}

		}
		} catch (Exception ex) {
			return false;
		}
		return isValid;

	}


	public boolean onlyNumeric(String value) {
		boolean isValid = true;
		if (StringUtils.isBlank(value)) {
			isValid = false;
		} else {
			Pattern p = Pattern.compile("[^0-9.]");
			Matcher m = p.matcher(value);
			// boolean b = m.matches();

			if (m.find()) {
				isValid = false;
			}

		}

		return isValid;
	}

	//
	public boolean twoDecimalHsnCheckBlank(String docType, String value) {
		boolean validData = true;
		if (StringUtils.isBlank(value)) {
			return true;
		}
		if (validData && !value.matches(Constants.TWODECIMALHSNCHECK)) {
				return false;
		}
		return true;
		
	}


	
	 public boolean isValidinwardDate(String value) {

	        if (StringUtils.isBlank(value) || value.matches(Constants.NONVALIDDATEFORMAT) || value.equals("0")
	                        || value.equals("") || value.equals("-")) {
	            return false;
	        } else {
	            try {
	                if (value.indexOf("-") >= 1) {
	                    return validateDates(value);
	                } else {
	                    String[] parts = value.split("/");
	                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
	                        int date = Integer.parseInt(parts[0]);
	                        int month = Integer.parseInt(parts[1]);
	                        int year = Integer.parseInt(parts[2]);
	                        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

	                            Calendar c = Calendar.getInstance();
	                            c.set(Calendar.DAY_OF_MONTH, date);
	                            c.set(Calendar.MONTH, month - 1);
	                            c.set(Calendar.YEAR, year);

	                            return checkDateWithDateFormat2(value);
	                        } else {
	                            return false;
	                        }
	                    } else {
	                        return false;
	                    }
	                }
	            } catch (Exception ex) {
	                return false;
	            }
	        }
	    }

	  private boolean checkDateWithDateFormat2(String value) {
	        try {
	            SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATEFORMATE2);
	            formatter.setLenient(false);
	            formatter.parse(value);
	            return true;

	        } catch (ParseException e) {
	            return false;
	        }
	    }
	 private boolean validateDates(String value) {
	        String[] parts = value.split("-");

	        if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
	            int date = Integer.parseInt(parts[0]);
	            int month = Integer.parseInt(parts[1]);
	            int year = Integer.parseInt(parts[2]);
	            if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

	                Calendar c = Calendar.getInstance();
	                c.set(Calendar.DAY_OF_MONTH, date);
	                c.set(Calendar.MONTH, month - 1);
	                c.set(Calendar.YEAR, year);

	                return checkDate(value);

	            } else {
	                return false;
	            }
	        } else {
	            return false;
	        }
	    }
	 
	 private boolean checkDate(String value) {
	        try {
	            SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATEFORMATE1);
	            formatter.setLenient(false);
	            formatter.parse(value);
	            return true;

	        } catch (ParseException e) {
	            return false;
	        }
	    }


	 

	public boolean isValidDocDate(String value) {
		if (StringUtils.isBlank(value) || "0".equals(value) ) {
			return true;
		}
		if (value.matches(Constants.VALIDDOCDATEREGEX) || "-".equals(value)) {
			return false;
		} else {
			try {
			if (value.indexOf("-") > 0) {
				String[] parts = value.trim().split("-");
				if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
					int date = Integer.parseInt(parts[0]);
					int month = Integer.parseInt(parts[1]);
					int year = Integer.parseInt(parts[2]);
					if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

						Calendar c = Calendar.getInstance();
						c.set(Calendar.DAY_OF_MONTH, date);
						c.set(Calendar.MONTH, month - 1);
						c.set(Calendar.YEAR, year);

						try {
							SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
							formatter.setLenient(false);
							formatter.parse(value);
							return true;

						} catch (ParseException e) {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				String[] parts = value.trim().split("/");
				if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
					int date = Integer.parseInt(parts[0]);
					int month = Integer.parseInt(parts[1]);
					int year = Integer.parseInt(parts[2]);
					if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

						Calendar c = Calendar.getInstance();
						c.set(Calendar.DAY_OF_MONTH, date);
						c.set(Calendar.MONTH, month - 1);
						c.set(Calendar.YEAR, year);

						try {
							SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
							formatter.setLenient(false);
							formatter.parse(value);
							return true;

						} catch (ParseException e) {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			}
			
		}catch(Exception ex) {
			log.error("Exception in isValidDocDate method ",ex);
			return false;
		}
		}
			
	}


	public boolean check16CharacterLength(String value) {
		boolean x=true;
		if (StringUtils.isNotBlank(value) && !"0".equals(value) && value.length() > 16) {
			
				x= false;
			
		}

		return x;

	}


	public boolean isInvoiceNoExist(String invoiceNo) {
		boolean x=true;
		if ("".equals(invoiceNo) || "0".equals(invoiceNo)) {
			x= false;
		}
		return x;
	}


	public boolean isSpecialCharExistInInvoiceNo(String invoiceNo) {

		boolean validInvoice = true;

		if (StringUtils.isBlank(invoiceNo) || "0".equals(invoiceNo)) {
			validInvoice = false;
		}

		if (validInvoice) {
			Pattern p = Pattern.compile("[^0-9A-Za-z/-]");
			Matcher m = p.matcher(invoiceNo);
			if (m.find()) {
				validInvoice = false;
			} else {
				validInvoice = true;
			}
		}
		return validInvoice;
	}
	
	
	// data type check started 
	
	public boolean checkOrginalInvoiceWithoutDate(String orgInvNo, String orgInvDate) {
		if (("0".equals(orgInvNo) || "".equals(orgInvNo)) && ("31-12-1899".equals(orgInvDate) || "0".equals(orgInvDate) || "".equals(orgInvDate))) {
			return true;
		} else if ((!"0".equals(orgInvNo) || !"".equals(orgInvNo)) && ("31-12-1899".equals(orgInvDate) || "".equals(orgInvDate))) {
			return false;
		}
		return true;
	}

	public boolean checkOrginalDateWithoutInv(String orgInvNo, String orgInvDate) {
		
		if(StringUtils.isBlank(orgInvNo) && StringUtils.isBlank(orgInvDate)) {
			return true;
		}
		if (("0".equals(orgInvNo) || StringUtils.isBlank(orgInvNo))
				&& ("31-12-1899".equals(orgInvDate) || "31/12/1899".equals(orgInvDate) || "0".equals(orgInvDate) )) {
			return true;
		} else if (("0".equals(orgInvNo) || "".equals(orgInvNo)) && (!"31-12-1899".equals(orgInvDate) || !"31/12/1899".equals(orgInvDate) || !"".equals(orgInvDate))) {
			return false;
		}
		return true;
	}
	
	public  boolean supplyTypeAgainstCustomerGstin(String supplyType, String gstinOfCustomer) {
		if ("b2b".equalsIgnoreCase(supplyType) || "sez".equalsIgnoreCase(supplyType) || "dexp".equalsIgnoreCase(supplyType) || "isd".equalsIgnoreCase(supplyType)) {
			if ("0".equals(gstinOfCustomer) || StringUtils.isBlank(gstinOfCustomer)) {
				return false;
			}
		}
		if ("exp".equalsIgnoreCase(supplyType) || "imp".equalsIgnoreCase(supplyType) || "b2cl".equalsIgnoreCase(supplyType)) {
			if (!"0".equals(gstinOfCustomer)) {
				return false;
			}
		}
		return true;
	}
	
	public boolean supplyTypeAgainstExportType(String supplyType, String expType) {
		String newExpType = "";
		if ("".equals(expType)) {
			newExpType = "0";
		} else {
			newExpType = expType;
		}
		if ("b2b".equalsIgnoreCase(supplyType) || "b2cl".equalsIgnoreCase(supplyType)) {
			if (!"0".equals(newExpType)) {
				return false;
			}
		}
		if ("exp".equalsIgnoreCase(supplyType) || "sez".equalsIgnoreCase(supplyType)) {
			if ("0".equals(newExpType)) {
				return false;
			}
		}
		if ("dexp".equalsIgnoreCase(supplyType) && !"wpay".equalsIgnoreCase(newExpType)) {
			return false;
		}
		return true;
	}
	
	public boolean supplyTypeAgainstInwardInvoiceCategory(String supplyType, String invoiceCategory, String gstinOfCustomer, int haveOrginalData, String nilRated,
			String exempt, String nonGst, String compo, String importType, String hsnCode) {
		if (haveOrginalData == 1) {
			try {

				String newImportType = hsnCodeCheck(hsnCode, importType);
				String newSupplyType = supplyType;
				if ("sez".equalsIgnoreCase(supplyType) || "isd".equalsIgnoreCase(supplyType) || "b2b".equalsIgnoreCase(supplyType)) {
					newSupplyType = "B2B";
				}
				if ("NIL".equalsIgnoreCase(supplyType) && Double.parseDouble(nilRated) > 0) {
					newSupplyType = "Nil rate";
				}
				if ("NIL".equalsIgnoreCase(supplyType) && Double.parseDouble(exempt) > 0) {
					newSupplyType = "Exempt";
				}
				if ("NIL".equalsIgnoreCase(supplyType) && Double.parseDouble(compo) > 0) {
					newSupplyType = "Compo";
				}
				if ("NIL".equalsIgnoreCase(supplyType) && Double.parseDouble(nonGst) > 0) {
					newSupplyType = "Non-GST";
				}
				if (supplyType.equalsIgnoreCase("rcm")) {
					newSupplyType = "b2bur";
				}
				if (supplyType.equalsIgnoreCase("imp") && newImportType.equalsIgnoreCase("Input Services")) {
					newSupplyType = "imps";
				}
				if (supplyType.equalsIgnoreCase("imp") && (newImportType.equalsIgnoreCase("inputs") || newImportType.equalsIgnoreCase("capital goods"))) {
					newSupplyType = "impg";
				}
				if (!newSupplyType.equalsIgnoreCase(invoiceCategory)) {
					return false;
				}
			} catch (Exception ex) {
					log.error("Error generated:",ex);
				return false;
			}

		}

		return true;
	}
	
	
	private String hsnCodeCheck(String hsncode, String inputType) {
		String importType = "";
		boolean isValidHSNFormat = true;
		boolean validImportType = true;
		if (inputType.equals("") || inputType.equals("0")) {
			String newHsn = "";
			newHsn = hsncode;
			if (!newHsn.matches("^\\d+$")) {
				isValidHSNFormat = false;
				importType = "inputs";
			} else {
				if (isValidHSNFormat && newHsn.equals("0")) {
					isValidHSNFormat = false;
				}
				if (isValidHSNFormat && validImportType) {
					if (newHsn.length() == 1) {
						newHsn = "0" + newHsn;
					}
					String sacCode = newHsn.substring(0, 2);
					if (Double.parseDouble(sacCode) == 99) {
						importType = "Input Services";
					} else {
						importType = "inputs";
					}
				}
			}
		} else {
			importType = inputType;
		}
		return importType;
	}
	
	public boolean check255CharacterLength(String value) {
		boolean validValue = true;
		
		if (StringUtils.isNotBlank(value) && !"0".equals(value) && value.length() > 255) {
			validValue = false;
		}

		if(validValue) {
			Pattern p = Pattern.compile("[^0-9A-Za-z]");
			Matcher m = p.matcher(value);
			if (m.find()) {
				validValue = true;
			} else {
				validValue = false;
			}
		}
		return validValue;
		
	}
	
	public boolean checkLength12GNew(String value, Boolean valid) {
		boolean isValid = true;
		DecimalFormat df2 = new DecimalFormat(".##");
		
		if(valid) {
			boolean result = onlyNumeric(value);

			try {
				if (result && df2.format(Double.parseDouble(value)).length() > 12) {

					isValid = false;

				}
			} catch (Exception ex) {
				isValid = false;
			}
		}		

		return isValid;
	}
	
	public boolean checkLength14GNew(String value, Boolean valid) {
		boolean isValid = true;
		DecimalFormat df2 = new DecimalFormat(".##");
		
		if(valid) {
			try {
				boolean result = onlyNumeric(value);
				if (result && df2.format(Double.parseDouble(value)).length() > 14) {

					isValid = false;

				}
			} catch (Exception ex) {
				isValid = false;
			}
		}		

		return isValid;
	}
	
	public boolean checkLength6GNew(String value, Boolean valid) {
		boolean isValid = true;
		DecimalFormat df2 = new DecimalFormat(".##");
		
		if(valid) {
			boolean result = onlyNumeric(value);

			try {
				if (result && df2.format(Double.parseDouble(value)).length() > 6) {

					isValid = false;

				}
			} catch (Exception ex) {
				isValid = false;
			}
		}		

		return isValid;
	}
	
	public boolean checkImportDoctypeGstin(String docType,String gstinOfSupplier,String originalDocType){
		boolean x=true;
		if("import invoice".equalsIgnoreCase(originalDocType)){
			if(StringUtils.isBlank(gstinOfSupplier) || "0".equals(gstinOfSupplier) ){
				x= true;
			}
			else{
				x= false;
			}
		}
		return x;
	}
	
	public  boolean orgDateCheck(String value1, String value2, String preGst, boolean valid)  {
		Date invoiceDate = null;
		Date noteDate = null;


		if ("".equals(value2) || "31-12-1899".equals(value2) || "00-01-1900".equals(value2) || "0".equals(value2)) {
			return true;
		}
		if ("N".equalsIgnoreCase(preGst) || "".equalsIgnoreCase(preGst)) {

			try {

				SimpleDateFormat sdf = null;
				if (value1.indexOf("-") > 0) {
					sdf = new SimpleDateFormat("dd-MM-yyyy");
					noteDate = sdf.parse(value1);

				} else if (value1.indexOf("/") > 0) {
					sdf = new SimpleDateFormat("dd/MM/yyyy");
					noteDate = sdf.parse(value1);

				}
				if (value2.indexOf("-") > 0) {

					sdf = new SimpleDateFormat("dd-MM-yyyy");
					invoiceDate = sdf.parse(value2);

				} else if (value2.indexOf("/") > 0) {
					sdf = new SimpleDateFormat("dd/MM/yyyy");
					invoiceDate = sdf.parse(value2);
				}
				if (invoiceDate!=null && invoiceDate.compareTo(noteDate) > 0) {
					return false;
				}

			} catch (Exception ex) {
				return false;
			}

		}
		return true;
	}
	

	public boolean checkOriginalCustomerGSTIN(String gstinOfCustomer, String customerGstin, String preGst, String invoiceAvailable) {
		if ("true".equalsIgnoreCase(invoiceAvailable)) {
			/*
			 * if ("0".equals(customerGstin) || StringUtils.isBlank(customerGstin)) { customerGstin = "0"; }
			 */
			if (!gstinOfCustomer.equals(customerGstin)) {
				return false;
			}
		}
		return true;
	}


	public boolean checkValueAgainstRate(String rate, String value, String docType) {

		try {

			if ("isd Invoice".equalsIgnoreCase(docType)) {
				return true;
			} else {
				if (Double.parseDouble(value) > 0
						&& (Double.parseDouble(rate) == 0 || Double.parseDouble(rate) == 0.00 || value.isEmpty() || value.equals(" ") || value == null)) {
					return false;
				}
			}
			return true;


		} catch (Exception ex) {
			return false;
		}
	}


	public boolean checkForInter(String docType, String sgstRate, String cgstRate, String igstRate, String igstAmt, String cgstAmt, String sgstAmt) {

		try {

			if ("import invoice".equalsIgnoreCase(docType) || "sez invoice".equalsIgnoreCase(docType)) {
				if (Double.parseDouble(cgstAmt) + Double.parseDouble(sgstAmt) != 0) {
					return false;
				} else if (Double.parseDouble(igstAmt) > 0) {
					return true;
				}
			}
			return true;
		} catch (Exception ex) {
			return false;
		}
	}
	
	
	public boolean checkForInter(String docType,String sgstRate,String cgstRate,String igstRate,String igstAmt,String cgstAmt,String sgstAmt,String originalDocType){
		try {
		if("import invoice".equalsIgnoreCase(originalDocType) || "sez invoice".equalsIgnoreCase(originalDocType)){
			if(Double.parseDouble(cgstAmt) + Double.parseDouble(sgstAmt) != 0){
				return false;
			}
			else if (Double.parseDouble(igstAmt) > 0){
				return true;
			}
		}
		return true;
		} catch (Exception ex) {
			return false;
		}
	}
	
	public boolean checkOrignalInvoice(String invoiceNo,String invoiceAvailable,String preGst){
		if("n".equalsIgnoreCase(preGst)){
				if("false".equals(invoiceAvailable)){
					return false;
				}
			}
		return true;
	}
	
	
	public boolean checkItcEligibleInwardCDNSpecific(String itcEligible){
		if(itcEligible.equals("input")){
			return true;
		}
		if(itcEligible.equals("")){
			return true;
		}
		if(itcEligible.equals("Input Services")){
			return true;
		}if(itcEligible.equals("capital goods")){
			return true;
		}if(itcEligible.equals("ineligible")){
			return true;
		}
		return false;
	}


	 public boolean isValidFutureInvoiceDate(String invoiceDate) {
		 boolean valid = true;

	        try {
	            SimpleDateFormat sdformat = new SimpleDateFormat(Constants.DATEFORMATE1);

	            Date currentDate = new Date();
	            Date localDate = null;
	            if (StringUtils.isBlank(invoiceDate)) {
	                valid = Boolean.FALSE;
	            }

	            localDate = sdformat.parse(invoiceDate);

	            if (localDate.compareTo(currentDate) > 0) {
	                valid = Boolean.FALSE;
	            }

	        } catch (Exception ex) {
	        	log.error("Error while comparing Inward date and Current Date");
	            return false;
	        }

	        return valid;

}
	 

	public boolean checkUDFLength(String udfx) {
        if (udfx.length() > 200) {
            return (udfx.length() > 200);
        }
        return false;

    }
	
	
	public boolean checkLength3LenTds(String value) {
		
		boolean isValid = true;
		DecimalFormat df2 = new DecimalFormat(".##");
		
		if(true) {
			boolean result = onlyNumeric(value);

			try {
				if (result && df2.format(Double.parseDouble(value)).length() > 5) {

					isValid = false;

				}
			} catch (Exception ex) {
				isValid = false;
			}
		}		

		return isValid;
	}

	public boolean validatePeriodOfFilling(InwardInvoiceCDNTemplateDTO rowdata) {
		String fp = rowdata.getPeriodOfFiling();
		if (StringUtils.isNotBlank(fp) && fp.length() != 6) {
			return false;
		}
		int month = Integer.parseInt(fp.substring(0, 2));
		int year = Integer.parseInt(fp.substring(2));
		String value = month + Constants.FORWORDSLASH + year;
		if (month != 00 && month < 13 && year != 0000) {

			Calendar c = Calendar.getInstance();
			c.set(Calendar.MONTH, month - 1);
			c.set(Calendar.YEAR, year);

			return checkFpDateWithDateFormat(value);

		}
		else
		{
			return false;
		}
		

	}
	
	public boolean validatePeriodOfFillingTds(TdsDetails rowdata) {
		String fp = rowdata.getPeriodFilingTdsReturn();
		if (StringUtils.isNotBlank(fp) && fp.length() != 6) {
			return false;
		}
		int month = Integer.parseInt(fp.substring(0, 2));
		int year = Integer.parseInt(fp.substring(2));
		String value = month + Constants.FORWORDSLASH + year;
		if (month != 00 && month < 13 && year != 0000) {

			Calendar c = Calendar.getInstance();
			c.set(Calendar.MONTH, month - 1);
			c.set(Calendar.YEAR, year);

			return checkFpDateWithDateFormat(value);

		}
		else
		{
			return false;
		}
		

	}

	private boolean checkFpDateWithDateFormat(String value) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat(Constants.FPDATEFORMATE);
            formatter.setLenient(false);
            formatter.parse(value);
            return true;

        } catch (ParseException e) {
            log.error("Error occured while execute checkDateWithDateFormat2 function:", e);
            return false;
        }
	}

	public boolean validatePeriodOfFilling(TdsDetails rowdata) {
		String fp = rowdata.getPeriodFilingTdsReturn();
		if (StringUtils.isNotBlank(fp) && fp.length() != 6) {
			return false;
		}
		int month = Integer.parseInt(fp.substring(0, 2));
		int year = Integer.parseInt(fp.substring(2));
		String value = month + Constants.FORWORDSLASH + year;
		if (month != 00 && month < 13 && year != 0000) {

			Calendar c = Calendar.getInstance();
			c.set(Calendar.MONTH, month - 1);
			c.set(Calendar.YEAR, year);

			return checkFpDateWithDateFormat(value);

		}
		else
		{
			return false;
		}
		

	}
	
	public boolean ifExceedDate(String poDate, String docDate) {
        SimpleDateFormat sdformat = new SimpleDateFormat(Constants.DATEFORMATE1);
        try {
            if (StringUtils.isBlank(docDate)) {
                return false;
            }
            if (StringUtils.isBlank(poDate)) {
                return false;
            }
            Date d1 = sdformat.parse(poDate);
            Date d2 = sdformat.parse(docDate);

            if (d1.compareTo(d2) > 0) {

                return false;
            }

        } catch (ParseException e) {
            log.error("Error occured while execute ifExceedDate function:", e);

            return false;
        }
        return true;
    }
 }
