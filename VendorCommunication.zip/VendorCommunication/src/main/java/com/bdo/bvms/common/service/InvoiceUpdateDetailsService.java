package com.bdo.bvms.common.service;

import java.io.IOException;
import java.util.List;

import com.bdo.bvms.common.dto.InvoiceDetailsDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.UpadateResponseDto;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface InvoiceUpdateDetailsService {


	UpadateResponseDto updateAndValidateDetails(InvoiceDetailsDTO invoiceDetailDto) throws IOException, VendorInvoiceServerException;

}
