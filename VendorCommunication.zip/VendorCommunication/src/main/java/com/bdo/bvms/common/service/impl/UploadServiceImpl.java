package com.bdo.bvms.common.service.impl;

import java.io.File;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.InwardRegisterDao;
import com.bdo.bvms.common.dao.UploadTransDao;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNReqDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.itc.service.ItcUpload;
import com.bdo.bvms.common.payment.service.PaymentDetailsUpload;
import com.bdo.bvms.common.service.InwardUpload;
import com.bdo.bvms.common.service.UploadLogService;
import com.bdo.bvms.common.service.UploadNDownloadFileService;
import com.bdo.bvms.common.service.UploadService;
import com.bdo.bvms.common.tds.service.TdsDetailsUpload;
import com.bdo.bvms.common.util.CommonUtils;
import com.google.common.io.Files;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UploadServiceImpl implements UploadService {

    @Autowired
    InwardUpload inwardUpload;

    @Autowired
    UploadTransDao uploadTransDao;

    @Autowired
    InwardRegisterDao commonCommunicationDao;
    
    
    @Autowired
    UploadNDownloadFileService uploadFileService;

    @Autowired
    UploadLogService uploadLogService;

    @Value("${bvms.cloud.temp.file.download.path}")
    String tempFolder;
    
    @Autowired
    PaymentDetailsUpload paymentDetailsUpload;
    
    @Autowired
    TdsDetailsUpload tdsDetailsUpload;
    @Autowired
    ItcUpload itcUpload;

    @Override
    public String uploadAndProcessFile(InwardInvoiceCDNReqDTO uploadRequestDTO) throws VendorInvoiceServerException {

        String batchNo = CommonUtils.getBatchNo(uploadRequestDTO);

        final String methodName = "uploadAndProcessFile";
        log.info(Constants.LOGMESSAGE, methodName);
        try {

            String originalFileName = uploadRequestDTO.getFile().getOriginalFilename();
            String fileName;
            String fileExt = "";

            if (StringUtils.isNotBlank(originalFileName)) {
                fileExt = Files.getFileExtension(originalFileName);
            }

            UploadReqDTO uploadReqDTO = new UploadReqDTO();
            uploadRequestDTO.setFileType(fileExt);

            if ("".equals(uploadRequestDTO.getTemplatetypepldCode())) {
                uploadRequestDTO.setTemplatetypepldCode(
                                Integer.toString(uploadTransDao.updatePldCode(uploadRequestDTO.getCustomtemplateID())));
            }
            uploadTransDao.insertStageNState(Constants.PROCESS_STAGE_FILE_UPLOAD,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadRequestDTO,batchNo);
            uploadLogService.saveInUploadLog(uploadRequestDTO, batchNo,uploadReqDTO);
            int uploadLogId = uploadLogService.getUploadLogId(batchNo);
            fileName = new StringBuilder().append(batchNo).append(Constants.UNSERSCORE_BASE)
                            .append(Constants.DOTSEPARATOR).append(fileExt).toString();
            AzureConnectionCredentialsDTO storageCredentials = commonCommunicationDao.getAzureCredentialFromDB(1,
                            "blob");
            if("1".equals(uploadRequestDTO.getUploadSftpSource()))
			{
				uploadFileService.uploadSftpFileToAzureBlob(uploadRequestDTO, batchNo, storageCredentials);
				uploadReqDTO.setUploadSource("ftps");
			}
            else {
            	 uploadFileService.uploadFileToAzureBlob(uploadRequestDTO.getFile(), uploadRequestDTO, batchNo,
                         storageCredentials);
            }
           

            File file = new File(tempFolder);
            if (!file.exists()) {
                file.mkdir();
            }

            uploadFileService.downloadFileFromAzureBlob(fileName, tempFolder, storageCredentials);
            uploadReqDTO.setFileType(fileExt);
            uploadReqDTO.setPo(uploadRequestDTO.getPo());
            uploadReqDTO.setGstinOrPanList(uploadRequestDTO.getGstinOrPanList());
            uploadReqDTO.setUploadType(uploadRequestDTO.getTemplatetypepldCode());
            uploadReqDTO.setTemplateType(uploadRequestDTO.getTemplatetypepldCode());
            uploadReqDTO.setPanOrGstn(uploadRequestDTO.getGstinOrPan());
            uploadReqDTO.setYear(uploadRequestDTO.getYear());
            uploadReqDTO.setMonth(uploadRequestDTO.getMonth());
            uploadReqDTO.setBatchNo(batchNo);
            uploadReqDTO.setUploadLogId(uploadLogId);
            uploadReqDTO.setId(uploadRequestDTO.getUserId());
            uploadReqDTO.setUserId(uploadRequestDTO.getUserId());
            uploadReqDTO.setIsCustomTemplate(uploadRequestDTO.getIsCustomTemplate());
            uploadReqDTO.setCustomTemplateId(uploadRequestDTO.getCustomtemplateID());
            uploadLogService.saveInUploadStageLog(uploadRequestDTO, uploadReqDTO);

            if (StringUtils.isBlank(uploadRequestDTO.getFile().getOriginalFilename())) {

                uploadTransDao.updateProcessStatus(batchNo, Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
                return Constants.FILEFORMATNOTALLOWED;

            }

            if (Constants.CSV.equals(fileExt) || Constants.XLSX.equals(fileExt) || Constants.XLS.equals(fileExt)) {

                if (Constants.INWARD_REGISTER.equalsIgnoreCase(uploadRequestDTO.getTemplatetypepldCode())) {
                    inwardUpload.validateAndSaveData(uploadReqDTO, storageCredentials);
                }
                else if (Constants.PAYMENT_DETAILS.equalsIgnoreCase(uploadRequestDTO.getTemplatetypepldCode())) {
                	paymentDetailsUpload.validateAndSavePaymentDetails(uploadReqDTO, storageCredentials);
                } else if (Constants.TDS_DETAILS.equalsIgnoreCase(uploadRequestDTO.getTemplatetypepldCode())) {
                	tdsDetailsUpload.validateAndSaveTdsDetails(uploadReqDTO, storageCredentials);
                }
                else if (Constants.ITC.equalsIgnoreCase(uploadRequestDTO.getTemplatetypepldCode())) {
                	itcUpload.validateAndSaveItc(uploadReqDTO, storageCredentials);
                }
                else {
                    uploadTransDao.updateProcessStatus(batchNo, Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
                    return Constants.INVALIDTEMPLATETYPE;
                }
            } else {
            	commonCommunicationDao.updateProcessStatusWithRemarks(uploadReqDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_ERROR,"File Formate is Invalid");
                return Constants.FILEFORMATNOTALLOWED;
            }
            return Constants.FILEUPLOADEPROGRESS;

        } catch (Exception e) {
            // Add entry in the exception log table
            log.error(Constants.LOGERRORMESSAGE, methodName, e);
            uploadTransDao.updateProcessStatus(batchNo, Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            throw new VendorInvoiceServerException(e.getMessage());
            // UploadStageLog also need to be updated****
        }
    }

}
