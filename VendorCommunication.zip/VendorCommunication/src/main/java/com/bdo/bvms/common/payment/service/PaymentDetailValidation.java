package com.bdo.bvms.common.payment.service;

import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;

public interface PaymentDetailValidation {

	void validatePaymentDetails(List<PaymentDetails> paymentDetailsTemplateDTOList,
			UploadReqDTO uploadReqDTO, List<PaymentDetails> errorPaymentDetailsTemplateDTOsList, List<PaymentDetails> sucessPaymentDetailsTemplateDTOsList,Map<String,String> yearIdMap);
}
