package com.bdo.bvms.common.dto;

import java.sql.Timestamp;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class UploadLogDto {

    int id;
    int entityId;
    String batchNo;
    String templateType;
    String taxpayerPan;
    String taxpayerGstin;
    String fp;
    String fileName;
    String fileType;
    Timestamp uploadStartTime;
    Timestamp uploadEndTime;
    long fileSize;
    int totalCount;
    int successCount;
    int errorCount;
    String baseFileLocation;
    String errorFileLocation;
    String successFileLocation;
    String isCustomTemplate;
    int customTemplateId;
    String pldUploadStatus;
    String pldUploadSource;
    String createdAt;
    String createdBy;
    String uploadSource;

}
