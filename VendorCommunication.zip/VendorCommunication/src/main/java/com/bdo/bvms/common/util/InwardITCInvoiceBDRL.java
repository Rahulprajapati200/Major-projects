package com.bdo.bvms.common.util;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;

public class InwardITCInvoiceBDRL {

	public void applyBDRL(InwardInvoiceCDNTemplateDTO inwardInvoice) {

		if (inwardInvoice.getSupplierStateCode().equals(inwardInvoice.getPlaceOfSupply())) {
			inwardInvoice.setSupplyType("INTRA");
		}

		if (!inwardInvoice.getSupplierStateCode().equals(inwardInvoice.getPlaceOfSupply())) {
			inwardInvoice.setSupplyType("INTER");
		}

		if ("regular tax invoice".equalsIgnoreCase(inwardInvoice.getDocType()) && "0".equals(inwardInvoice.getGstinOfSupplier())) {
			inwardInvoice.setInvoiceCategory("B2B");
			inwardInvoice.setTableNo("3");
			inwardInvoice.setInvoiceType("Regular");
		}

		if ("sez invoice".equalsIgnoreCase(inwardInvoice.getDocType()) && !"Input Services".equalsIgnoreCase(inwardInvoice.getImportType())) {
			inwardInvoice.setInvoiceCategory("IMPGSEZ");
			inwardInvoice.setTableNo("5B");
			inwardInvoice.setInvoiceType("Regular");
		}

		// Done
		if ("deemed export invoice".equalsIgnoreCase(inwardInvoice.getDocType()) && !"0".equals(inwardInvoice.getGstinOfSupplier())) {
			inwardInvoice.setInvoiceCategory("B2B");
			inwardInvoice.setTableNo("");
			inwardInvoice.setInvoiceType("Regular");
		}

		// Done
		if (checkForIMPGSez(inwardInvoice.getDocType(), inwardInvoice.getHsnSacCode(), inwardInvoice.getImportType())) {
			inwardInvoice.setInvoiceCategory("IMPGSEZ");
			inwardInvoice.setTableNo("5B");
			inwardInvoice.setInvoiceType("Regular");
			inwardInvoice.setImportType("Inputs");
		}

		if ("sez invoice".equalsIgnoreCase(inwardInvoice.getDocType()) && "Input Services".equalsIgnoreCase(inwardInvoice.getImportType())) {
			inwardInvoice.setInvoiceCategory("B2B");
			inwardInvoice.setTableNo("5B");
			inwardInvoice.setInvoiceType("Regular");
		}

		if (checkIMPS(inwardInvoice.getImportType(), inwardInvoice.getDocType(), inwardInvoice.getHsnSacCode())) {
			inwardInvoice.setInvoiceCategory("B2B");
			inwardInvoice.setTableNo("5B");
			inwardInvoice.setInvoiceType("Regular");
			inwardInvoice.setImportType("Input Services");
		}

		// "Inward table 4A"
		if ("rcm invoice".equalsIgnoreCase(inwardInvoice.getDocType()) && !"0".equals(inwardInvoice.getGstinOfSupplier())
				&& StringUtils.isNotBlank(inwardInvoice.getGstinOfSupplier())) {
			inwardInvoice.setInvoiceCategory("B2B");
			inwardInvoice.setTableNo("4A");
			inwardInvoice.setInvoiceType("Regular");
		}

		// "Inward table 4A regular tax"
		if (StringUtils.isNotBlank(inwardInvoice.getGstinOfSupplier()) && "0".equals(inwardInvoice.getImportType()) && "y".equalsIgnoreCase(inwardInvoice.getReverseCharge())
				&& "regular tax invoice".equalsIgnoreCase(inwardInvoice.getDocType())) {
			inwardInvoice.setInvoiceCategory("B2B");
			inwardInvoice.setTableNo("4A");
			inwardInvoice.setInvoiceType("Regular");
		}

		// "Inward table 5A"
		if (("inputs".equalsIgnoreCase(inwardInvoice.getImportType()) || "capital goods".equals(inwardInvoice.getImportType()))
				&& "import invoice".equalsIgnoreCase(inwardInvoice.getDocType())) {
			inwardInvoice.setInvoiceCategory("IMPG");
			inwardInvoice.setTableNo("5A");
			inwardInvoice.setInvoiceType("Regular");
		}


		// "Inward table 5A HSN"
		if (checkForIMPGImport(inwardInvoice.getDocType(), inwardInvoice.getHsnSacCode(), inwardInvoice.getImportType())) {
			inwardInvoice.setInvoiceCategory("IMPG");
			inwardInvoice.setTableNo("5A");
			inwardInvoice.setInvoiceType("Regular");
			inwardInvoice.setImportType("Inputs");
		}

		// "Inward table 5A IMPS"
		if ("Input Services".equalsIgnoreCase(inwardInvoice.getImportType()) && "import invoice".equalsIgnoreCase(inwardInvoice.getDocType())) {
			inwardInvoice.setInvoiceCategory("IMPS");
			inwardInvoice.setTableNo("5A");
			inwardInvoice.setInvoiceType("Regular");

		}

		// "Inward table 5A IMPS HSN"
		if (checkIMPSImport(inwardInvoice.getImportType(), inwardInvoice.getDocType(), inwardInvoice.getHsnSacCode())) {
			inwardInvoice.setInvoiceCategory("IMPS");
			inwardInvoice.setTableNo("4C");
			inwardInvoice.setInvoiceType("Regular");
			inwardInvoice.setImportType("Input Services");
		}

		// "Inward table 4B"
		if ("regular tax invoice".equalsIgnoreCase(inwardInvoice.getDocType())
				&& ("0".equals(inwardInvoice.getGstinOfSupplier()) || StringUtils.isBlank(inwardInvoice.getGstinOfSupplier()))) {
			inwardInvoice.setInvoiceCategory("B2BUR");
			inwardInvoice.setTableNo("4B");
			inwardInvoice.setInvoiceType("RCM");
		}

		// "Inward table rcm invoice 4B"
		if ("rcm invoice".equalsIgnoreCase(inwardInvoice.getDocType())
				&& ("0".equals(inwardInvoice.getGstinOfSupplier()) || StringUtils.isBlank(inwardInvoice.getGstinOfSupplier()))) {
			inwardInvoice.setInvoiceCategory("B2BUR");
			inwardInvoice.setTableNo("4B");
			inwardInvoice.setInvoiceType("RCM");
		}

		// "Inward Invoice 7A4"
		if (table7A4(inwardInvoice.getDocType(), inwardInvoice.getImportType(), inwardInvoice.getNilRatedAmt(), inwardInvoice.getPlaceOfSupply(),
				inwardInvoice.getSupplierStateCode())) {
			inwardInvoice.setInvoiceCategory("Nil rate");
			inwardInvoice.setTableNo("7A4");
			inwardInvoice.setInvoiceType("Regular");
		}

		// "Inward Invoice 7A3"
		if (table7A3(inwardInvoice.getDocType(), inwardInvoice.getImportType(), inwardInvoice.getExemptedAmt(), inwardInvoice.getPlaceOfSupply(),
				inwardInvoice.getSupplierStateCode())) {
			inwardInvoice.setInvoiceCategory("Exempt");
			inwardInvoice.setTableNo("7A3");
			inwardInvoice.setInvoiceType("Regular");
		}
		
		
	// "Inward Invoice 7A2"

			if (table7A2(inwardInvoice.getDocType(), inwardInvoice.getImportType(), inwardInvoice.getCompositionAmt(), inwardInvoice.getPlaceOfSupply(),
					inwardInvoice.getSupplierStateCode())) {
				inwardInvoice.setInvoiceCategory("Compo");
				inwardInvoice.setTableNo("7A2");
				inwardInvoice.setInvoiceType("Regular");

			}


		// "Inward Invoice 7A5"
			if (table7A5(inwardInvoice.getDocType(), inwardInvoice.getImportType(), inwardInvoice.getNonGstAmt(), inwardInvoice.getPlaceOfSupply(),
					inwardInvoice.getSupplierStateCode())) {
				inwardInvoice.setInvoiceCategory("Non-GST");
				inwardInvoice.setTableNo("7A5");
				inwardInvoice.setInvoiceType("Regular");
			}		
		
		// "Inward Invoice 7B4"
			if (table7B4(inwardInvoice.getDocType(), inwardInvoice.getImportType(), inwardInvoice.getNilRatedAmt(), inwardInvoice.getPlaceOfSupply(),
					inwardInvoice.getSupplierStateCode())) {
				inwardInvoice.setInvoiceCategory("Nil rate");
				inwardInvoice.setTableNo("7B4");
				inwardInvoice.setInvoiceType("Regular");
			}			
			
			
		// "Inward table 8A"
		if ("isd invoice".equalsIgnoreCase(inwardInvoice.getDocType())) {
			inwardInvoice.setInvoiceCategory("B2B");
			inwardInvoice.setTableNo("8A");
			inwardInvoice.setInvoiceType("ISD");				
			inwardInvoice.setImportType("Input Services");
		}
		

		// Inward Invoice 7B3

		if (table7B3(inwardInvoice.getDocType(), inwardInvoice.getImportType(), inwardInvoice.getExemptedAmt(), inwardInvoice.getPlaceOfSupply(),
				inwardInvoice.getSupplierStateCode())) {
			inwardInvoice.setInvoiceCategory("Exempt");
			inwardInvoice.setTableNo("7B3");
			inwardInvoice.setInvoiceType("Regular");
		}

		// Inward Invoice 7B3
		if (table7B3(inwardInvoice.getDocType(), inwardInvoice.getImportType(), inwardInvoice.getExemptedAmt(), inwardInvoice.getPlaceOfSupply(),
				inwardInvoice.getSupplierStateCode())) {
			inwardInvoice.setInvoiceCategory("Exempt");
			inwardInvoice.setTableNo("7B3");
			inwardInvoice.setInvoiceType("Regular");
		}

		// Inward Invoice 7B2a
		if (table7B2(inwardInvoice.getDocType(), inwardInvoice.getImportType(), inwardInvoice.getCompositionAmt(), inwardInvoice.getPlaceOfSupply(),
				inwardInvoice.getSupplierStateCode())) {
			inwardInvoice.setInvoiceCategory("Compo");
			inwardInvoice.setTableNo("7B2");
			inwardInvoice.setInvoiceType("Regular");
		}
		// Inward Invoice 7B5
		if (table7B5(inwardInvoice.getDocType(), inwardInvoice.getImportType(), inwardInvoice.getNonGstAmt(), inwardInvoice.getPlaceOfSupply(),
				inwardInvoice.getSupplierStateCode())) {
			inwardInvoice.setInvoiceCategory("Non-GST");
			inwardInvoice.setTableNo("7B5");
			inwardInvoice.setInvoiceType("Regular");
		}

		// bussinses rule for input type not blank input service
		if (checkImportTypeForHsnService(inwardInvoice.getDocType(), inwardInvoice.getImportType(), inwardInvoice.getHsnSacCode())) {
			inwardInvoice.setImportType("Input Services");
		}


	}

	boolean checkImportTypeForHsnService(String docType, String importType, String hsnSacCode) {
		boolean validImportType = true;
		boolean validHsnCode = true;
		if (docType.equalsIgnoreCase("regular tax invoice") || docType.equalsIgnoreCase("rcm invoice") || docType.equalsIgnoreCase("bill of supply")) {
						
			if(StringUtils.isBlank(importType) || "0".equals(importType)){
				validImportType = false;
			}
			if(StringUtils.isBlank(hsnSacCode) || "0".equals(hsnSacCode)){
				validHsnCode = false;
			}

			if (validHsnCode != false && validImportType == false) {
				if (hsnSacCode.length() == 1) {
					hsnSacCode = "0" + hsnSacCode;
				}
				String sacCode = hsnSacCode.substring(0, 2);
				if (Double.parseDouble(sacCode) == 99) {
					return true;
				}
				return false;
			}
		}
		return false;
	}


	boolean table7B5(String docType, String importType, String nonGstAmt, String placeOfSupply, String gstinSupplierCode) {
		if ("bill of Supply".equalsIgnoreCase(docType)) {
			if (Double.parseDouble(gstinSupplierCode) == Double.parseDouble(placeOfSupply)) {
				if (Double.parseDouble(nonGstAmt) > 0) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}

	boolean table7B2(String docType, String importType, String compositionAmt, String placeOfSupply, String gstinSupplierCode) {
		if ("bill of Supply".equalsIgnoreCase(docType)) {
			if (Double.parseDouble(gstinSupplierCode) == Double.parseDouble(placeOfSupply)) {
				if (Double.parseDouble(compositionAmt) > 0) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}


	boolean table7B3(String docType, String importType, String exemptedAmt, String placeOfSupply, String gstinSupplierCode) {
		if ("bill of Supply".equalsIgnoreCase(docType)) {
			if (Double.parseDouble(gstinSupplierCode) == Double.parseDouble(placeOfSupply)) {
				if (Double.parseDouble(exemptedAmt) > 0) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}


	boolean table7B4(String docType, String importType, String nilRatedAmt, String placeOfSupply, String gstinSupplierCode) {
		if ("bill of Supply".equalsIgnoreCase(docType)) {
			if (Double.parseDouble(gstinSupplierCode) == Double.parseDouble(placeOfSupply)) {
				if (Double.parseDouble(nilRatedAmt) > 0) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}


	boolean table7A5(String docType, String importType, String nonGstAmt, String placeOfSupply, String gstinSupplierCode) {
		if ("bill of Supply".equalsIgnoreCase(docType)) {
			if (Double.parseDouble(gstinSupplierCode) != Double.parseDouble(placeOfSupply)) {
				if (Double.parseDouble(nonGstAmt) > 0) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}


	boolean table7A2(String docType, String importType, String compositionAmt, String placeOfSupply, String gstinSupplierCode) {
		if ("bill of Supply".equalsIgnoreCase(docType)) {
			if (Double.parseDouble(gstinSupplierCode) != Double.parseDouble(placeOfSupply)) {
				if (Double.parseDouble(compositionAmt) > 0) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}


	boolean table7A3(String docType, String importType, String exemptedAmt, String placeOfSupply, String gstinSupplierCode) {
		if ("bill of Supply".equalsIgnoreCase(docType)) {
			if (Double.parseDouble(gstinSupplierCode) != Double.parseDouble(placeOfSupply)) {
				if (Double.parseDouble(exemptedAmt) > 0) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}


	boolean table7A4(String docType, String importType, String nilRatedAmt, String placeOfSupply, String gstinSupplierCode) {
		if ("bill of Supply".equalsIgnoreCase(docType)) {
			if (Double.parseDouble(gstinSupplierCode) != Double.parseDouble(placeOfSupply)) {
				if (Double.parseDouble(nilRatedAmt) > 0) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}

	boolean checkForIMPGImport(String docType, String hsnSacCode, String importType) {
		if ("import invoice".equals(docType)) {
			boolean validImportType = true;
			boolean validHsnType = true;
						
			if(StringUtils.isBlank(importType) || "0".equals(importType)){
				validImportType = false;
			}
			if(StringUtils.isBlank(hsnSacCode) || "0".equals(hsnSacCode)){
				validHsnType = false;
			}
			
			if ((validImportType == false && validHsnType == false) || (importType.equals("0") && hsnSacCode.equals("0"))) {
				return true;
			}
			if (validHsnType != false) {
				if (hsnSacCode.length() == 1) {
					hsnSacCode = "0" + hsnSacCode;
				}
				String sacCode = hsnSacCode.substring(0, 2);
				if (Double.parseDouble(sacCode) != 99 && (validImportType == false || importType.equals("0"))) {
					return true;
				} else {
					return false;
				}
			} else if (validHsnType == false && importType.equals("0")) {

				return true;
			}
			return false;

		}
		return false;
	}

	boolean checkIMPSImport(String importType, String docType, String hsnSacCode) {
		if ("import invoice".equals(docType)) {
			boolean validImportType = true;
			boolean validHsnType = true;
			if(StringUtils.isBlank(importType)){
				validImportType = false;
			}
			if(StringUtils.isBlank(hsnSacCode)){
				validHsnType = false;
			}
			
			if (importType.equals("0") && hsnSacCode.equals("0")) {
				return false;
			}

			if (validHsnType != false && (validImportType == false || importType.equals("0"))) {
				if (hsnSacCode.length() == 1) {
					hsnSacCode = "0" + hsnSacCode;
				}
				String sacCode = hsnSacCode.substring(0, 2);
				if (Double.parseDouble(sacCode) == 99 && (validImportType == false || importType.equals("0"))) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}


	boolean checkIMPS(String importType, String docType, String hsnSacCode) {
		if ("sez invoice".equalsIgnoreCase(docType)) {
			boolean validImportType = true;
			boolean validHsnType = true;
			if (StringUtils.isBlank(importType)) {
				validImportType = false;
			}
			if (StringUtils.isBlank(hsnSacCode)) {
				validHsnType = false;
			}
			if ("0".equals(importType) && "0".equals(hsnSacCode)) {
				return false;
			}

			if (validHsnType != false && (validImportType == false || "0".equals(importType))) {
				String sacCode = hsnSacCode.substring(0, 2);
				if (Double.parseDouble(sacCode) == 99 && (validImportType == false || "0".equals(importType))) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}


	boolean checkForIMPGSez(String docType, String hsnSacCode, String importType) {
		if ("sez invoice".equals(docType)) {
			boolean validImportType = true;
			boolean validHsnType = true;
			if(StringUtils.isBlank(importType)){
				validImportType = false;
			}
			if(StringUtils.isBlank(hsnSacCode)){
				validHsnType = false;
			}			
			
			if (((validImportType == false || "0".equals(importType)) && validHsnType == false) || ("0".equals(importType) && "0".equals(hsnSacCode))) {
				return true;
			}
			if (validHsnType != false) {
				if (hsnSacCode.length() == 1) {
					hsnSacCode = "0" + hsnSacCode;
				}
				String sacCode = hsnSacCode.substring(0, 2);
				if (Double.parseDouble(sacCode) != 99 && (validImportType == false || importType.equals("0"))) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}


}
