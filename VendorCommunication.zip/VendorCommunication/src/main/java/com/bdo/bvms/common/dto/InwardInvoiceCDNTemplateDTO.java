package com.bdo.bvms.common.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.relational.core.mapping.Column;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor

@Getter
@Setter
@ToString
public class InwardInvoiceCDNTemplateDTO {

    @Column("id")
    private Integer rowId;
    @Column("gstin_of_recipient")
    private String gstinOfRecipient;
    @Column("doc_type")
    private String docType;
    @Column("supply_type")
    private String supplyType;
    @Column("doc_no")
    private String docNo;
    @Column("doc_date")
    private String docDate;
    @Column("org_invoice_no")
    private String orgInvoiceNo;
    @Column("org_invoice_date")
    private String orgInvoiceDate;
    @Column("gstin_of_supplier")
    private String gstinOfSupplier;
    @Column("supplier_name")
    private String supplierName;
    @Column("supplier_state_code")
    private String supplierStateCode;

    @Column("inward_no")
    private String inwardNo;
    @Column("inward_date")
    private String inwardDate;
    private String itemDescription;
    private String hsnCode;
    @Column("uom")
    private String uom;
    @Column("quantity")
    private String quantity;
    @Column("item_rate")
    private String itemRate;

    private String assAmt;
    @Column("sgat_rate")
    private String sgstRate;
    @Column("sgst_amt")
    private String sgstAmt;
    @Column("cgst_rate")
    private String cgstRate;
    @Column("cgst_amt")
    private String cgstAmt;
    @Column("igst_rate")
    private String igstRate;
    @Column("igst_amt")
    private String igstAmt;
    @Column("cess_Rate")
    private String cessRate;
    @Column("cessRate")
    private String cessAmount;
    @Column("diff_percent")
    private String diffPercent;

    private String inwardGrossTotalAmount;
    @Column("total_invoice_amt")
    private String totalInvoiceAmt;
    private String inputType;
    @Column("itc_ineligible_reversal_indicator")
    private String itcIneligibleReversalIndicator;
    @Column("itc_ineligible_reversal_percentage")
    private String itcIneligibleReversalPercentage;
    @Column("place_of_supply")
    private String placeOfSupply;
    @Column("reverse_charge")
    private String reverseCharge;
    @Column("port_cd")
    private String port;
    @Column("import_bill_of_entry_no")
    private String importBillOfEntryNo;
    @Column("import_bill_of_Entry_date")
    private String importBillOfEntryDate;
    @Column("import_Bill_of_entry_amt")
    private String importBillOfEntryAmt;
    @Column("date_of_payment")
    private String dateOfPayment;
    @Column("irn")
    private String irn;
    @Column("ack_date")
    private String ackDate;
    @Column("ack_no")
    private String ackNo;
    @Column("debit_gl_id")
    private String debitGlId;
    @Column("debit_gl_name")
    private String debitGlName;
    @Column("credit_gl_id")
    private String creditGlId;
    @Column("credit_gl_name")
    private String creditGlName;
    @Column("sub_location")
    private String subLocation;
    private StringBuilder errorCodeList = new StringBuilder();
    @Column("row_version")
    private String rowVersion;
    private int excelRowId;
    boolean isValid;

    private String orgDocTypeVal;
    @Column("item_name")
    private String itemName;
    @Column("hsn_sac_code")
    private String hsnSacCode;
    private String inwardTaxableAmt;
    private String inwardTotalTaxAmt;
    @Column("itc_eligible")
    private String itcEligible;
    @Column("itc_sgst_amt")
    private String itcSgstAmt;
    @Column("its_cgst_amt")
    private String itcCgstAmt;
    @Column("itc_igst_amt")
    private String itcIgstAmt;
    @Column("itc_cess_amt")
    private String itcCessAmt;
    @Column("total_itc_amt")
    private String totalItcAmt;
    private String compositionAmt;
    private String nilRatedAmt;
    private String exemptedAmt;
    private String nonGstAmt;

    @Column("import_type")
    private String importType;
    private String reason;
    private String preGst;

    private String fileId;
    private String param1;
    private String param2;
    private String param3;
    private String param4;
    private String param5;
    private String param6;
    private String param7;
    private String param8;
    private String param9;
    private String param10;
    private String hasAdditional;
    @Column("fp")
    private String fp;
    @Column
    private String orgInvoiceCategory;
    private StringBuilder errorDescriptionList = new StringBuilder();
    private String orgReverseCharge;
    @Column("invoice_category")
    private String invoiceCategory;
    @Column("invoice_type")
    private String invoiceType;
    private String userSupplyCat;
    private String excelDocType;
    private String itcTotalTaxAmt;
    boolean isDataError;
    @Column("org_doc_type")
    private String orgDocType;
    @Column("org_supply_type")
    private String orgSupplyType;
    private String orgImportType;
    private String orgQuantity;
    private String orgItemRate;
    private String orgAssAmt;
    private String orgSgstRate;
    private String orgSgstAmt;
    private String orgCgstRate;
    private String orgCgstAmt;
    private String orgIgstRate;
    private String orgIgstAmt;
    private String orgCessRate;
    private String orgCessAmt;
    private String orgDiffPercent;
    private String orgInwardGrossTotalAmount;
    private String orgTotalInvAmt;
    private String orgImportBillOfEntryAmt;
    private String invoiceCategoryOfExistingInv;
    private String tableNo;
    List<InwardInvoiceCDNTemplateDTO> getLatestInvoice = new ArrayList<>();

    private String udf1;
    private String udf2;
    private String udf3;
    private String udf4;
    private String udf5;
    private String udf6;
    private String udf7;
    private String udf8;
    private String udf9;
    private String udf10;
    @Column("taxable_amt")
    private String taxableAmount;
    @Column("total_tax_amount")
    private String totalTaxAmount;
    @Column("gross_total_amount")
    private String grossTotalAmount;
    @Column
    private String panOfReciepiet;
    @Column
    private String panOfSupplier;
    private String yearId;
    private String fillingPeriod;
    @Column("user_id")
    private String userId;
    @Column("batch_no")
    private String batchNo;
    @Column("error_description")
    private String errorDescription;
    @Column("error_codes")
    private String errorCode;
    @Column("org_input_type")
    private String orgInputType;
    
    
    private String paymentAmount;
    private String paymentRefNo;
    private String tdsSection;
    private String tdsRate;
    private String tdsTaxAmount;
    private String challanNumber;
    private String challanDate;
    private String challanAmount;
    private String periodOfFiling;
    private String invoiceAgainstProvAdv;
    private String inwardNoProvAdv;
    private String inwardDateProvAdv;
    private String amountOfProvAdv;
    private String balOutstanding;
    private String orgBalOutstanding;
    
    private String orgAmountOfProvAdv;
    private String orgChallanAmount;
    private String orgTdsTaxAmount;
    private String orgPaymentAmount;
    private String orgTdsRate;
    
    private String udf11;
    private String udf12;
    private String udf13;
    private String udf14;
    private String udf15;
    private String udf16;
    private String udf17;
    private String udf18;
    private String udf19;
    private String udf20;


}
