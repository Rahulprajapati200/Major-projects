package com.bdo.bvms.common.dto;

import java.sql.Date;

import com.bdo.bvms.common.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class GstinAttachmentsResDTO {

	Integer id;
    Integer serialNo;
    String uploadedByname;
    String uploadedByEmail;
    String documentType;
    Integer documentTypeId;
    String remarks;
    String path;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATE_ATTACHMENT_UPLOADED_FORMAT)   
    Date uploadedOn;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATE_ATTACHMENT_APPROVAL_FORMAT)   
    Date approvedOn;
}
