package com.bdo.bvms.common.dto;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Setter
@Getter
public class TaxpayerBaseReqDTO {

	 // @NotBlank(message = "{bearerToken.notblank}")
    String bearerToken;

    @NotBlank(message = "{userId.notblank}")
    String userId;

    //    @NotBlank(message = "{entityId.notblank}")
    String entityId;

    // @NotBlank(message = "{userTypeId.notblank}")
    String userTypeId;

    // @NotBlank(message = "{entityTypeId.notblank}")
    String entityTypeId;

    String ipAddress;
	
}
