package com.bdo.bvms.common.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.InwardRegisterDao;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.ExceptionLogDTO;
import com.bdo.bvms.common.dto.InvoiceDetailsDbDto;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.ResponseBean;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.sql.CommunicationSQL;
import com.bdo.bvms.common.sql.TransactionSQL;
import com.bdo.bvms.common.util.AppLogger;

import lombok.extern.slf4j.Slf4j;

// TODO: Auto-generated Javadoc
/** The Constant log. */
@Slf4j
@Repository
public class InwardRegisterDaoImpl implements InwardRegisterDao {

    /** The jdbc template mst. */
    @Autowired
    private JdbcTemplate jdbcTemplateMst;
    
    /** The jdbc template trn. */
    @Autowired
    private JdbcTemplate jdbcTemplateTrn;

    /** The mst database name. */
    @Value("${mst.database-name}")
    private String mstDatabaseName;

    /** The trn database name. */
    @Value("${txn.database-name}")
    private String trnDatabaseName;

    /**
     * Gets the azure credential from DB.
     *
     * @param entityId the entity id
     * @param blob the blob
     * @return the azure credential from DB
     */
    @Override
    public AzureConnectionCredentialsDTO getAzureCredentialFromDB(int entityId, String blob) {
        return jdbcTemplateMst.queryForObject(CommunicationSQL.GET_AZURE_CREDENTIAL_FROM_DB,
                        new BeanPropertyRowMapper<AzureConnectionCredentialsDTO>(AzureConnectionCredentialsDTO.class),
                        new Object[] { entityId, blob });

    }

    /**
     * Gets the org invoice for inward CDN.
     *
     * @param gstin the gstin
     * @param invoiceNo the invoice no
     * @param invoiceDate the invoice date
     * @param supplierGstin the supplier gstin
     * @param p the p
     * @return the org invoice for inward CDN
     */
    @SuppressWarnings("deprecation")
    @Override
    public Map<String, String> getOrgInvoiceForInwardCDN(String gstin, String invoiceNo,
                    String invoiceDate, String supplierGstin, String p) {

        String query = "SELECT  concat(inward_no,inward_date,gstin_of_supplier) as concat1,concat(doc_type,'~',invoice_category,'~',import_type,'~',table_no,'~',fp) as concat2 "
        		+ "FROM    inward_purchase_reg "
        		+ "WHERE   gstin_of_recipient = ? "
        		+ "AND gstin_of_supplier = ?";

        return jdbcTemplateTrn.query(query, new ResultSetExtractor<Map<String, String>>() {

                    @Override
                    public Map<String, String> extractData(final ResultSet rs)
                                    throws SQLException, DataAccessException {
                        AppLogger.debug("GSTDBInwardDAOImpl", "getOrgInvoiceForInwardCDN",
                                        invoiceNo + " : Entered extractor : " + System.currentTimeMillis());
                        final Map<String, String> listOFBatchData = new HashMap<>();
                        while (rs.next()) {
                        	listOFBatchData.put(rs.getString("concat1"),rs.getString("concat2"));
                        }
                        return listOFBatchData;
                    }
                },gstin,supplierGstin);
    }


    /**
     * Gst inward inv cdn insert.
     *
     * @param csvInvSuccessFilePath the csv inv success file path
     * @param csvCdnSuccessFilePath the csv cdn success file path
     * @param csvInvErrorFilePath the csv inv error file path
     * @param csvCdnErrorFilePath the csv cdn error file path
     * @param successInvTable the success inv table
     * @param successCdnTable the success cdn table
     * @param failureInvTable the failure inv table
     * @param failureCdnTable the failure cdn table
     * @return the response bean
     */
    @Override
    public ResponseBean gstInwardInvCdnInsert(String csvInvSuccessFilePath, String csvCdnSuccessFilePath,
                    String csvInvErrorFilePath, String csvCdnErrorFilePath, String successInvTable,
                    String successCdnTable, String failureInvTable, String failureCdnTable) {
        final String methodName = "gstInwardInvCdnInsert";
        int invSuccessCount = 0;
        int cdnSuccessCount = 0;
        int invCdnErrorCount = 0;
        int invInvErrorCount = 0;

        log.info(Constants.LOGMESSAGE, methodName);
        String query;

        ResponseBean response = new ResponseBean();

        try {

            query = CommunicationSQL.INSERT_FILE_SQL.replace("table_name", successInvTable);
            AppLogger.info(Constants.BLANK, methodName, "query = " + query);
            invSuccessCount = saveData(csvInvSuccessFilePath, query);
            AppLogger.info(Constants.BLANK, methodName, "successCount = " + invSuccessCount);

            query = CommunicationSQL.INSERT_FILE_SQL.replace("table_name", successCdnTable);
            cdnSuccessCount = saveData(csvCdnSuccessFilePath, query);
            AppLogger.info(Constants.BLANK, methodName, "errorCount = " + cdnSuccessCount);

            query = CommunicationSQL.INSERT_FILE_SQL.replace("table_name", failureInvTable);
            invInvErrorCount = saveData(csvInvErrorFilePath, query);
            AppLogger.info(Constants.BLANK, methodName, "errorCount = " + invInvErrorCount);

            query = CommunicationSQL.INSERT_FILE_SQL.replace("table_name", failureCdnTable);
            invCdnErrorCount = saveData(csvCdnErrorFilePath, query);
            AppLogger.info(Constants.BLANK, methodName, "errorCount = " + invCdnErrorCount);

            response.setInvSuccessCount(invSuccessCount);
            response.setCdvSuccessCount(cdnSuccessCount);
            response.setErrorCount(invCdnErrorCount + invInvErrorCount);
        } catch (Exception e) {
            log.error(Constants.LOGERRORMESSAGE, methodName, e);
        }
        return response;
    }

    /**
     * Save data.
     *
     * @param filePath the file path
     * @param query the query
     * @return the integer
     * @throws VendorInvoiceServerException the vendor invoice server exception
     */
    private Integer saveData(String filePath, String query) throws VendorInvoiceServerException {

        final String methodName = "";
        log.info(Constants.LOGMESSAGE, methodName);
        Integer count = 0;
        try {
            count = jdbcTemplateTrn.update(query, filePath);

        } catch (Exception e) {
            log.error(Constants.LOGERRORMESSAGE, methodName + e);
            throw new VendorInvoiceServerException("E0006", e);
        }
        return count;
    }

    /** The Constant GET_PERTICULAR_DATA_OF_SUCCESS_RECORDS. */
    public static final String GET_PERTICULAR_DATA_OF_SUCCESS_RECORDS = "select gstin_uin_of_recipient,doc_type,inward_no,inward_date,gstin_of_supplier,hsn_code,total_invoice_amt,purchase_order_no,purchase_order_date,"
                    + "irn,irn_date,udf_1,udf_2,udf_3,udf_4,udf_5,udf_6,udf_7,udf_8,udf_9,udf_10,row_version,status,error_code from invoice_upload_err_log where batch_no like '";

    /**
     * Gets the error data list with error code.
     *
     * @param uploadRequestDTO the upload request DTO
     * @return the error data list with error code
     */
    @Override
    public List<InwardInvoiceCDNTemplateDTO> getErrorDataListWithErrorCode(UploadReqDTO uploadRequestDTO) {
        StringBuilder builder = new StringBuilder();
        builder.append("SELECT id,org_doc_type,org_supply_type,org_input_type,org_invoice_no,org_invoice_date,error_codes,gstin_of_recipient, doc_type, doc_no, doc_date, gstin_of_supplier, supplier_state_code,supplier_name, ")
                        .append("inward_no,inward_date,invoice_category,supply_type,invoice_type,item_name,hsn_sac_code,uom,quantity,item_rate,taxable_amt,sgst_rate,")
                        .append("sgst_amt,cgst_rate,cgst_amt,igst_rate,igst_amt,cess_rate,cess_amount,diff_percent,total_tax_amount,gross_total_amount,total_invoice_amt,")
                        .append("place_of_supply,reverse_charge,import_type,port_cd,import_bill_of_entry_no, ")
                        .append("import_bill_of_entry_date,import_bill_of_entry_amt,user_id,fp,batch_no,itc_eligible, ")
                        .append("itc_sgst_amt,itc_cgst_amt,itc_igst_amt,itc_cess_amt,total_itc_amt,debit_gl_id,debit_gl_name,credit_gl_id,credit_gl_name,error_description, ")
                        .append("row_version,date_of_payment,itc_ineligible_reversal_indicator,itc_ineligible_reversal_percentage, ")
                        .append("irn,ack_date,ack_no,sub_location,udf_1,udf_2,udf_3,udf_4,udf_5,udf_6,udf_7,udf_8,udf_9,udf_10 ,payment_amount,payment_ref_no,")
                        .append("tds_section,tds_rate,tds_tax_amount,challan_number,challan_date,challan_amount,period_of_filing,invoice_against_prov_adv,")
                        .append("inward_no_prov_adv,inward_date_prov_adv,amount_of_prov_adv,bal_outstanding,udf_11,udf_12,udf_13,udf_14,udf_15,udf_16,udf_17,")
                        .append("udf_18,udf_19,udf_20")
                        .append(" FROM( ")
                        .append("SELECT id,org_doc_type,org_supply_type,org_input_type,org_invoice_no,org_invoice_date ,error_codes,gstin_of_recipient, doc_type, doc_no, doc_date, gstin_of_supplier, supplier_state_code, supplier_name,  ")
                        .append("inward_no, inward_date, invoice_category, supply_type, invoice_type, item_name, hsn_sac_code, uom, quantity, item_rate, taxable_amt,  ")
                        .append("sgst_rate, sgst_amt, cgst_rate, cgst_amt, igst_rate, igst_amt, cess_rate, cess_amount, diff_percent, total_tax_amount, gross_total_amount,  ")
                        .append("total_invoice_amt, place_of_supply, reverse_charge, import_type, port_cd,  ")
                        .append("import_bill_of_entry_no, import_bill_of_entry_date, import_bill_of_entry_amt,  ")
                        .append("user_id, fp, batch_no, itc_eligible, itc_sgst_amt, itc_cgst_amt, itc_igst_amt, itc_cess_amt, total_itc_amt, debit_gl_id, debit_gl_name,  ")
                        .append("credit_gl_id, credit_gl_name, error_description, row_version, date_of_payment,  ")
                        .append("itc_ineligible_reversal_indicator, itc_ineligible_reversal_percentage, irn, ack_date, ack_no, sub_location ,udf_1,udf_2,udf_3,udf_4,udf_5,udf_6,udf_7,udf_8,udf_9,udf_10,payment_amount,payment_ref_no,")
                        .append("tds_section,tds_rate,tds_tax_amount,challan_number,challan_date,challan_amount,period_of_filing,invoice_against_prov_adv,")
                        .append("inward_no_prov_adv,inward_date_prov_adv,amount_of_prov_adv,bal_outstanding,udf_11,udf_12,udf_13,udf_14,udf_15,udf_16,udf_17,")
                        .append("udf_18,udf_19,udf_20")
                        .append(" FROM    inward_dnr_error WHERE    batch_no = '").append(uploadRequestDTO.getBatchNo())
                        .append("' and error_codes != ''  ").append("UNION ALL ")

                        .append("SELECT id,org_doc_type,org_supply_type,org_input_type,'' as org_invoice_no,'' as org_invoice_date,error_codes, gstin_of_recipient, doc_type, doc_no, doc_date, gstin_of_supplier, supplier_state_code, supplier_name,  ")
                        .append("inward_no, inward_date, invoice_category, supply_type, invoice_type, item_name, hsn_sac_code, uom, quantity, item_rate, taxable_amt, sgst_rate,  ")
                        .append("sgst_amt, cgst_rate, cgst_amt, igst_rate, igst_amt, cess_rate, cess_amount, diff_percent, total_tax_amount, gross_total_amount, total_invoice_amt,  ")
                        .append(" place_of_supply, reverse_charge, import_type, port_cd, import_bill_of_entry_no,  ")
                        .append("import_bill_of_entry_date, import_bill_of_entry_amt, user_id, fp, batch_no, itc_eligible,  ")
                        .append("itc_sgst_amt, itc_cgst_amt, itc_igst_amt, itc_cess_amt, total_itc_amt, debit_gl_id, debit_gl_name, credit_gl_id, credit_gl_name, error_description,  ")
                        .append("row_version, date_of_payment, itc_ineligible_reversal_indicator, itc_ineligible_reversal_percentage,  ")
                        .append("irn, ack_date, ack_no, sub_location,udf_1,udf_2,udf_3,udf_4,udf_5,udf_6,udf_7,udf_8,udf_9,udf_10,payment_amount,payment_ref_no,")
                        .append("tds_section,tds_rate,tds_tax_amount,challan_number,challan_date,challan_amount,period_of_filing,invoice_against_prov_adv,")
                        .append("inward_no_prov_adv,inward_date_prov_adv,amount_of_prov_adv,bal_outstanding,udf_11,udf_12,udf_13,udf_14,udf_15,udf_16,udf_17,")
                        .append("udf_18,udf_19,udf_20")
                        .append(" FROM    inward_purchase_reg_error")
                        .append(" WHERE    batch_no = '").append(uploadRequestDTO.getBatchNo())
                        .append("' and error_codes != '' ) temp_tbl");
        return jdbcTemplateTrn.query(builder.toString(), new ResultSetExtractor<List<InwardInvoiceCDNTemplateDTO>>() {

            @Override
            public List<InwardInvoiceCDNTemplateDTO> extractData(ResultSet rs)
                            throws SQLException, DataAccessException {

                List<InwardInvoiceCDNTemplateDTO> listOFBatchData = new ArrayList<>();
                while (rs.next()) {
                    InwardInvoiceCDNTemplateDTO template = new InwardInvoiceCDNTemplateDTO();
                    String docType = rs.getString("doc_type");
                    template.setRowId(rs.getInt("id"));
                    template.setOrgInvoiceNo(rs.getString("org_invoice_no"));
                    template.setOrgInvoiceDate(rs.getString("org_invoice_date"));
                    template.setGstinOfRecipient(rs.getString("gstin_of_recipient"));
                    template.setExcelDocType(docType);
                    template.setOrgDocType(rs.getString("org_doc_type"));
                    template.setOrgSupplyType(rs.getString("org_supply_type"));
                    template.setOrgInputType(rs.getString("org_input_type"));
                    template.setDocType(rs.getString("doc_type"));
                    template.setDocNo(rs.getString("doc_no"));
                    template.setDocDate(rs.getString("doc_date"));
                    template.setInwardNo(rs.getString("inward_no"));
                    template.setInwardDate(rs.getString("inward_date"));
                    template.setGstinOfSupplier(rs.getString("gstin_of_supplier"));
                    template.setSupplierName(rs.getString("supplier_name"));
                    template.setSupplierStateCode(rs.getString("supplier_state_code"));
                    template.setInvoiceCategory(rs.getString(Constants.INVOICE_CATEGORY));
                    template.setSupplyType(rs.getString(Constants.INVOICE_CATEGORY));
                    template.setOrgInvoiceCategory(rs.getString(Constants.INVOICE_CATEGORY));
                    template.setInvoiceType(rs.getString("invoice_type"));
                    template.setItemName(rs.getString("item_name"));
                    template.setItemDescription(rs.getString("item_name"));
                    template.setItemRate(rs.getString("item_rate"));
                    template.setHsnSacCode(rs.getString("hsn_sac_code"));
                    template.setUom(rs.getString("uom"));
                    template.setQuantity(rs.getString("quantity"));
                    template.setInwardTaxableAmt(rs.getString("taxable_amt"));
                    template.setTaxableAmount(rs.getString("taxable_amt"));
                    template.setSgstRate(rs.getString("sgst_rate"));
                    template.setSgstAmt(rs.getString("sgst_amt"));
                    template.setCgstRate(rs.getString("cgst_rate"));
                    template.setCgstAmt(rs.getString("cgst_amt"));
                    template.setIgstRate(rs.getString("igst_rate"));
                    template.setIgstAmt(rs.getString("igst_amt"));
                    template.setCessRate(rs.getString("cess_rate"));
                    template.setCessAmount(rs.getString("cess_amount"));
                    template.setDiffPercent(rs.getString("diff_percent"));
                    template.setInwardTotalTaxAmt(rs.getString("total_tax_amount"));
                    template.setInwardGrossTotalAmount(rs.getString("gross_total_amount"));
                    template.setTotalInvoiceAmt(rs.getString("total_invoice_amt"));
                    template.setPlaceOfSupply(rs.getString("place_of_supply"));
                    template.setReverseCharge(rs.getString("reverse_charge"));
                    template.setImportType(rs.getString("import_type"));
                    template.setInputType(rs.getString("import_type"));
                    template.setPort(rs.getString("port_cd"));
                    template.setImportBillOfEntryNo(rs.getString("import_bill_of_entry_no"));
                    template.setImportBillOfEntryDate(rs.getString("import_bill_of_entry_date"));
                    template.setImportBillOfEntryAmt(rs.getString("import_bill_of_entry_amt"));
                    template.setDateOfPayment(rs.getString("date_of_payment"));
                    template.setFp(rs.getString("fp"));
                    template.setBatchNo(rs.getString("batch_no"));
                    template.setItcEligible(rs.getString("itc_eligible"));
                    template.setItcSgstAmt(rs.getString("itc_sgst_amt"));
                    template.setItcCgstAmt(rs.getString("itc_cgst_amt"));
                    template.setItcIgstAmt(rs.getString("itc_igst_amt"));
                    template.setItcCessAmt(rs.getString("itc_cess_amt"));
                    template.setErrorDescription(rs.getString("error_description"));
                    template.setDebitGlId(rs.getString("debit_gl_id"));
                    template.setDebitGlName(rs.getString("debit_gl_name"));
                    template.setCreditGlId(rs.getString("credit_gl_id"));
                    template.setCreditGlName(rs.getString("credit_gl_name"));
                    template.setTotalItcAmt(rs.getString("total_itc_amt"));
                    template.setItcIneligibleReversalIndicator(rs.getString("itc_ineligible_reversal_indicator"));
                    template.setItcIneligibleReversalPercentage(rs.getString("itc_ineligible_reversal_percentage"));
                    template.setIrn(rs.getString("irn"));
                    template.setAckDate(rs.getString("ack_date"));
                    template.setAckNo(rs.getString("ack_no"));
                    template.setErrorCode(rs.getString("error_codes"));
                    template.setFp(rs.getString("fp"));
                    template.setSubLocation(rs.getString("sub_location"));
                    template.setUdf1(rs.getString("udf_1"));
                    template.setUdf2(rs.getString("udf_2"));
                    template.setUdf3(rs.getString("udf_3"));
                    template.setUdf4(rs.getString("udf_4"));
                    template.setUdf5(rs.getString("udf_5"));
                    template.setUdf6(rs.getString("udf_6"));
                    template.setUdf7(rs.getString("udf_7"));
                    template.setUdf8(rs.getString("udf_8"));
                    template.setUdf9(rs.getString("udf_9"));
                    template.setUdf10(rs.getString("udf_10"));
                    template.setPaymentAmount(rs.getString("payment_amount"));
                    template.setPaymentRefNo(rs.getString("payment_ref_no"));
                    template.setTdsSection(rs.getString("tds_section"));
                    template.setTdsRate(rs.getString("tds_rate"));
                    template.setTdsTaxAmount(rs.getString("tds_tax_amount"));
                    template.setChallanNumber(rs.getString("challan_number"));
                    template.setChallanAmount(rs.getString("challan_amount"));
                    template.setPeriodOfFiling(rs.getString("period_of_filing"));
                    template.setInvoiceAgainstProvAdv(rs.getString("invoice_against_prov_adv"));
                    template.setInwardNoProvAdv(rs.getString("inward_no_prov_adv"));
                    template.setInwardDateProvAdv(rs.getString("inward_date_prov_adv"));
                    template.setAmountOfProvAdv(rs.getString("amount_of_prov_adv"));
                    template.setBalOutstanding(rs.getString("bal_outstanding"));
                    template.setUdf11(rs.getString("udf_11"));
                    template.setUdf12(rs.getString("udf_12"));
                    template.setUdf13(rs.getString("udf_13"));
                    template.setUdf14(rs.getString("udf_14"));
                    template.setUdf15(rs.getString("udf_15"));
                    template.setUdf16(rs.getString("udf_16"));
                    template.setUdf17(rs.getString("udf_17"));
                    template.setUdf18(rs.getString("udf_18"));
                    template.setUdf19(rs.getString("udf_19"));
                    template.setUdf20(rs.getString("udf_20"));
                    listOFBatchData.add(template);
                }
                return listOFBatchData;
            }
        });

    }
    /**
     * Sets the error discription.
     *
     * @param errorDataListWithErrorCode the error data list with error code
     * @return the list
     */
    @Override
    public List<InwardInvoiceCDNTemplateDTO> setErrorDiscription(
                    List<InwardInvoiceCDNTemplateDTO> errorDataListWithErrorCode) {
        HashMap<String, String> mapRet = new HashMap<>();

        jdbcTemplateMst.query(CommunicationSQL.GET_ERRORCODE_AND_SHORTDESCRIPTION,
                        new ResultSetExtractor<Map<String, String>>() {

                            @Override
                            public Map<String, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                while (rs.next()) {
                                    mapRet.put(rs.getString("ErrorCode"), rs.getString("ShortDescription"));
                                }
                                return mapRet;
                            }
                        });
        errorDataListWithErrorCode.forEach(data -> {
            String code = data.getErrorCodeList().toString().replace("|", ",");
            String[] errorCodeList = code.split(",");
            if (errorCodeList.length > 1) {
                for (int i = 1; i < errorCodeList.length; i++) {
                    String discription = mapRet.get(errorCodeList[i]);
                    data.setErrorDescriptionList(data.getErrorDescriptionList().append("|" + discription));
                }
            }
        });
        return errorDataListWithErrorCode;
    }

    /**
     * Gets the FP year.
     *
     * @param fp the fp
     * @return the FP year
     */
    @Override
    public String getFPYear(String fp) {
        String yearId = null;
        String methodName = "";
        log.info(Constants.LOGMESSAGE, methodName);
        try {
            yearId = jdbcTemplateMst.queryForObject(CommunicationSQL.GET_RETURN_YEAR, String.class, fp);
        } catch (EmptyResultDataAccessException e) {
            yearId = "0";
        }
        return yearId;
    }

    /**
     * Gets the uom query.
     *
     * @return the uom query
     */
    @Override
    public List<String> getUomQuery() {

        String sqlstr = "select * from sm_uom_master ";
        return jdbcTemplateMst.query(sqlstr, new ResultSetExtractor<List<String>>() {

            @Override
            public List<String> extractData(ResultSet rs) throws SQLException, DataAccessException {
                List<String> uomList = new ArrayList<>();
                while (rs.next()) {

                    uomList.add(rs.getString("keyword").toUpperCase());
                }
                return uomList;
            }
        });
    }

    /**
     * Gets the inward result FP count.
     *
     * @param gstinUinOfRecipient the gstin uin of recipient
     * @param inwardNo the inward no
     * @param inwardDate the inward date
     * @param gstinOfSupplier the gstin of supplier
     * @param fp the fp
     * @param yearId the year id
     * @return the inward result FP count
     */
    @Override
    public int getInwardResultFPCount(String gstinUinOfRecipient, String inwardNo, String inwardDate,
                    String gstinOfSupplier, String fp, String yearId) {

        final String methodName = "";

        log.info(Constants.LOGMESSAGE, methodName);
        try {

            String sqlstr = CommunicationSQL.getInwardResultSql( inwardDate, gstinOfSupplier, fp, yearId,
                            mstDatabaseName, trnDatabaseName);

            return jdbcTemplateTrn.queryForObject(sqlstr, Integer.class, gstinUinOfRecipient, gstinOfSupplier, yearId,
                            fp, inwardNo);

        } catch (Exception ex) {
            log.error(Constants.LOGERRORMESSAGE, methodName);
            return 0;
        }

    }

    
    @Override
    public int getInwardResultFPCountCDN(String gstinUinOfRecipient, String inwardNo, String inwardDate,
                    String gstinOfSupplier, String fp, String yearId) {

        final String methodName = "";

        log.info(Constants.LOGMESSAGE, methodName);
        try {

            String sqlstr = CommunicationSQL.getInwardResultSqlCDN( inwardDate, gstinOfSupplier, fp, yearId,
                            mstDatabaseName, trnDatabaseName);

            return jdbcTemplateTrn.queryForObject(sqlstr, Integer.class, gstinUinOfRecipient, gstinOfSupplier, yearId,
                            fp, inwardNo);

        } catch (Exception ex) {
            log.error(Constants.LOGERRORMESSAGE, methodName);
            return 0;
        }

    }

    
    /**
     * Gets the duplicate FP in diff month.
     *
     * @param gstinOfSupplier the gstin of supplier
     * @param gstinUinOfRecipient the gstin uin of recipient
     * @param yearId the year id
     * @param fp the fp
     * @return the duplicate FP in diff month
     */
    @Override
    public List<String> getDuplicateFPInDiffMonth(String gstinOfSupplier, String gstinUinOfRecipient, String yearId,
                    String fp) {

        String sqlString = CommunicationSQL.getDuplocateFPQuery(trnDatabaseName, mstDatabaseName);

        return jdbcTemplateTrn.queryForList(sqlString, String.class, gstinUinOfRecipient, yearId, fp);

    }
    
    
    @Override
    public List<String> getDuplicateFPInDiffMonthCDN(String gstinOfSupplier, String gstinUinOfRecipient, String yearId,
                    String fp) {

        String sqlString = CommunicationSQL.getDuplocateFPQueryCDN(trnDatabaseName, mstDatabaseName);

        return jdbcTemplateTrn.queryForList(sqlString, String.class, gstinUinOfRecipient, yearId, fp);

    }

    /**
     * Gets the ITC claim count.
     *
     * @param gstinUinOfRecipient the gstin uin of recipient
     * @param gstinOfSupplier the gstin of supplier
     * @param inwardNo the inward no
     * @param inwardDate the inward date
     * @param fp the fp
     * @param yearId the year id
     * @param type the type
     * @return the ITC claim count
     */
    @Override
    public int getITCClaimCount(String gstinUinOfRecipient, String gstinOfSupplier, String inwardNo, String inwardDate,
                    String fp, String yearId, int type) {

        final String methodName = "";
        try {
            AppLogger.debug("Method Name:  ", "getBatchData",
                            inwardNo + " : Entered method : " + System.currentTimeMillis());
            String sqlstr = "";
            log.info(Constants.LOGMESSAGE, methodName);
            if (type == 1) {
                sqlstr = "select count(1) from " + trnDatabaseName + ".inward_purchase_reg where gstin_of_recipient = '"
                                + gstinUinOfRecipient + "'" + " and gstin_of_supplier = '" + gstinOfSupplier + "'"
                                + " and fp in (select fp FROM " + mstDatabaseName
                                + ".sm_return_periods where year_id = '" + yearId + "') and inward_no = '" + inwardNo
                                + "'" + "  and itc_claim = '1'";
            } else {
                sqlstr = "select count(1) from " + trnDatabaseName + ".inward_dnr where gstin_of_supplier = '"
                                + gstinOfSupplier + "' and gstin_of_recipient = '" + gstinUinOfRecipient
                                + "' and itc_claim = '1' and inward_no = '" + inwardNo + "' AND  inward_date = '"
                                + inwardDate + "'";

            }
            return jdbcTemplateTrn.queryForObject(sqlstr, Integer.class);
        } catch (Exception ex) {
            log.error(Constants.LOGERRORMESSAGE, methodName);
            return 0;
        }

    }

    /**
     * Gets the list of invoice ITC claimed in year.
     *
     * @param gstinOfSupplier the gstin of supplier
     * @param gstinUinOfRecipient the gstin uin of recipient
     * @param yearId the year id
     * @param fp the fp
     * @return the list of invoice ITC claimed in year
     */
    @Override
    public List<String> getListOfInvoiceITCClaimedInYear(String gstinOfSupplier, String gstinUinOfRecipient,
                    String yearId, String fp) {

        String query = "select distinct lower(concat(inward_no,gstin_of_supplier)) from inward_purchase_reg where gstin_of_recipient = ? \r\n"
                        + " and itc_claim = '1' ";

        return jdbcTemplateTrn.queryForList(query, String.class, gstinUinOfRecipient);
    }

    /**
     * Gets the duplicate inward cdn in diff FP.
     *
     * @param yearId the year id
     * @param fp the fp
     * @param gstinUinOfRecipient the gstin uin of recipient
     * @param dbName the db name
     * @param trnDbName the trn db name
     * @return the duplicate inward cdn in diff FP
     */
    @Override
    public List<String> getDuplicateInwardCdnInDiffFP(String yearId, String fp, String gstinUinOfRecipient,
                    String dbName, String trnDbName) {

        String query = CommunicationSQL.getDuplicateInwardCdnQuery(mstDatabaseName, trnDbName);

        return jdbcTemplateMst.queryForList(query, String.class, gstinUinOfRecipient, yearId, fp);

    }

    /**
     * Gets the ITC claimed CDN count.
     *
     * @param gstinUinOfRecipient the gstin uin of recipient
     * @param gstinOfSupplier the gstin of supplier
     * @param inwardNo the inward no
     * @param inwardDate the inward date
     * @param fp the fp
     * @param yearId the year id
     * @param type the type
     * @return the ITC claimed CDN count
     */
    @Override
    public int getITCClaimedCDNCount(String gstinUinOfRecipient, String gstinOfSupplier, String inwardNo,
                    String inwardDate, String fp, String yearId, int type) {
        String sqlstr = "";

        try {
            if (type == 1) {
                sqlstr = "select count(1) from " + trnDatabaseName + ".inward_dnr where gstin_of_recipient = '"
                                + gstinUinOfRecipient + "' and gstin_of_supplier = '" + gstinOfSupplier
                                + "' and fp in (select fp FROM " + mstDatabaseName
                                + ".sm_return_periods where year_id = '" + yearId + "') "
                                + " and itc_claim = '1' and inward_no = '" + inwardNo + "' " + " ";
            } else {
                sqlstr = "select count(1) from " + trnDatabaseName + ".inward_dnr where gstin_of_recipient = '"
                                + gstinUinOfRecipient + "' and gstin_of_supplier = '" + gstinOfSupplier
                                + "'  and itc_claim = '1' and inward_no = '" + inwardNo + "' inward_date = '"
                                + inwardDate + "'";
            }

            return jdbcTemplateTrn.queryForObject(sqlstr, Integer.class);

        } catch (Exception ex) {
            return 0;
        }
    }

    /**
     * Gets the hsn code list.
     *
     * @return the hsn code list
     */
    @Override
    public Map<String, String> getHsnCodeList() {

        HashMap<String, String> mapRet = new HashMap<>();
        jdbcTemplateMst.query("select id, hsn_sac_code as hsn_code from sm_hsn_sac_master",
                        new ResultSetExtractor<Map<String, String>>() {

                            @Override
                            public Map<String, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                while (rs.next()) {
                                    mapRet.put(rs.getString("hsn_code"), rs.getString("id"));
                                }
                                return mapRet;
                            }
                        });
        return mapRet;

    }

    /**
     * Gets the state code list.
     *
     * @return the state code list
     */
    @Override
    public Map<String, String> getStateCodeList() {

        HashMap<String, String> mapRet = new HashMap<>();
        jdbcTemplateMst.query("select distinct parent_code from sm_country_state_city",
                        new ResultSetExtractor<Map<String, String>>() {

                            @Override
                            public Map<String, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                while (rs.next()) {
                                    mapRet.put(rs.getString("parent_code"), rs.getString("parent_code"));
                                }
                                return mapRet;
                            }
                        });
        return mapRet;
    }

    /**
     * Gets the port code list.
     *
     * @return the port code list
     */
    @Override
    public Map<String, String> getPortCodeList() {

        HashMap<String, String> mapRet = new HashMap<>();
        jdbcTemplateMst.query("select lower(sm_port_code) as port_code from sm_port",
                        new ResultSetExtractor<Map<String, String>>() {

                            @Override
                            public Map<String, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                while (rs.next()) {
                                    mapRet.put(rs.getString("port_code"), rs.getString("port_code"));
                                }
                                return mapRet;
                            }
                        });
        return mapRet;

    }

    /**
     * Gets the govt rate list.
     *
     * @return the govt rate list
     */
    @Override
    public List<String> getGovtRateList() {
        String govtRateSql = "select sm_gst_rates from sm_gst_rates";
        return jdbcTemplateMst.query(govtRateSql, new ResultSetExtractor<List<String>>() {

            public List<String> extractData(ResultSet rs) throws SQLException, DataAccessException {
                List<String> listOfData = new ArrayList<>();
                while (rs.next()) {
                    String gstRate = rs.getString("sm_gst_rates");
                    listOfData.add(String.valueOf(Double.parseDouble(gstRate)));
                }
                return listOfData;
            }

        });

    }

    /**
     * Update exception log table.
     *
     * @param exceptionLogDTO the exception log DTO
     */
    @Override
    public void updateExceptionLogTable(ExceptionLogDTO exceptionLogDTO) {
        jdbcTemplateTrn.update(CommunicationSQL.INSERT_EXCEPTION_LOG, exceptionLogDTO.getScreenName(),
                        exceptionLogDTO.getFunctionName(), exceptionLogDTO.getErrorMessage(),
                        exceptionLogDTO.getErrorCause(), exceptionLogDTO.getLineNo(), exceptionLogDTO.getUserId(),
                        exceptionLogDTO.getCreatedAt(), exceptionLogDTO.getRequestedAt(),
                        exceptionLogDTO.getRequestedBy());
    }

    /**
     * Gets the entity id.
     *
     * @param supplierGSTNId the supplier GSTN id
     * @return the entity id
     */
    @Override
    public String getEntityId(String supplierGSTNId) {
        String entityId = null;

        try {
            entityId = jdbcTemplateMst.queryForObject(Constants.QUERY_TO_GET_ENTITY_ID, String.class, supplierGSTNId);
        } catch (EmptyResultDataAccessException e) {
            entityId = "0";
        }
        return entityId;
    }

    /**
     * Gets the year id.
     *
     * @return the year id
     */
    @Override
    public HashMap<String, String> getYearId() {
        HashMap<String, String> mapRet = new HashMap<>();
        jdbcTemplateMst.query(Constants.YEARIDQUERY, new ResultSetExtractor<Map<String, String>>() {

            @Override
            public Map<String, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
                while (rs.next()) {
                    mapRet.put(rs.getString(Constants.FP_CONS), rs.getString(Constants.YEARID));
                }
                return mapRet;
            }
        });
        return mapRet;

    }

    /**
     * Sets the error discription for error list.
     *
     * @return the hash map
     */
    @Override
    public HashMap<String, String> setErrorDiscriptionForErrorList() {

        HashMap<String, String> mapRet = new HashMap<>();

        jdbcTemplateMst.query(CommunicationSQL.GET_ERRORCODE_AND_SHORTDESCRIPTION,
                        new ResultSetExtractor<Map<String, String>>() {

                            @Override
                            public Map<String, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                while (rs.next()) {
                                    mapRet.put(rs.getString("ErrorCode"), rs.getString("ShortDescription"));
                                }
                                return mapRet;
                            }
                        });

        return mapRet;
    }

    /**
     * Gets the gstin from DB.
     *
     * @param pan the pan
     * @param mstDB the mst DB
     * @return the gstin from DB
     */
    @Override
    public String[] getGstinFromDB(String pan, String mstDB) {

        String query = CommunicationSQL.getGstinDb(mstDB);
        return jdbcTemplateTrn.queryForList(query, String.class, pan).toArray(new String[0]);

    }

    /**
     * Update invoice detail into db.
     *
     * @param invoiceDetailDto the invoice detail dto
     */
    @Override
    public void updateInvoiceDetailIntoDb(List<InvoiceDetailsDbDto> invoiceDetailDto) {

        jdbcTemplateTrn.batchUpdate(CommunicationSQL.getUpdateCRNINVQuery(invoiceDetailDto.get(0).getDocType()),
                        new BatchPreparedStatementSetter() {

                            @Override
                            public void setValues(PreparedStatement ps, int i) throws SQLException {

                                InvoiceDetailsDbDto myPojo = invoiceDetailDto.get(i);
                                ps.setString(i, myPojo.getTaxpayergstin());
                                ps.setString(i, myPojo.getTranType());
                                ps.setString(i, myPojo.getVendorgstin());
                                ps.setString(i, myPojo.getInvoiceno());
                                ps.setString(i, myPojo.getInvoicedate());
                                ps.setString(i, myPojo.getTaxable());
                                ps.setString(i, myPojo.getPos());
                                ps.setString(i, myPojo.getInvoicevalue());
                                ps.setString(i, myPojo.getInputType());
                                ps.setString(i, myPojo.getItcIneligibleReversalIndicator());
                                ps.setString(i, myPojo.getItcIneligibleReversalPercentage());
                                ps.setString(i, myPojo.getSupplierStateCode());
                                ps.setString(i, myPojo.getHsn());
                                ps.setString(i, myPojo.getQty());
                                ps.setString(i, myPojo.getUnit());
                                ps.setString(i, myPojo.getIgst());
                                ps.setString(i, myPojo.getIgstRate());
                                ps.setString(i, myPojo.getCgst());
                                ps.setString(i, myPojo.getCgstRate());
                                ps.setString(i, myPojo.getSgst());
                                ps.setString(i, myPojo.getSgstRate());
                                ps.setString(i, myPojo.getCess());
                                ps.setString(i, myPojo.getCessRate());
                                ps.setTimestamp(i, Timestamp.from(Instant.now()));

                            }

                            @Override
                            public int getBatchSize() {
                                return invoiceDetailDto.size();
                            }
                        });

    }

    /**
     * Gst invoice details inv cdn insert.
     *
     * @param csvInvSuccessFilePath the csv inv success file path
     * @param csvCdnSuccessFilePath the csv cdn success file path
     * @param successInvTable the success inv table
     * @param successCdnTable the success cdn table
     * @return the response bean
     */
    @Override
    public ResponseBean gstInvoiceDetailsInvCdnInsert(String csvInvSuccessFilePath, String csvCdnSuccessFilePath,
                    String successInvTable, String successCdnTable) {
        final String methodName = "gstInwardInvCdnInsert";
        int invSuccessCount = 0;
        int cdnSuccessCount = 0;
        int invCdnErrorCount = 0;
        int invInvErrorCount = 0;

//		csvInvSuccessFilePath,
//		csvCdnSuccessFilePath, csvInvErrorFilePath,csvCdnErrorFilePath, Constants.SUCCESS_INV_TABLE,
//		Constants.SUCCESS_CDN_TABLE, Constants.FAILURE_INV_TABLE,Constants.FAILURE_CDN_TABLE
        log.info(Constants.LOGMESSAGE, methodName);
        String query;

        ResponseBean response = new ResponseBean();

        try {

            query = CommunicationSQL.INSERT_FILE_SQL.replace("table_name", successInvTable);
            AppLogger.info(Constants.BLANK, methodName, "query = " + query);
            invSuccessCount = saveData(csvInvSuccessFilePath, query);
            AppLogger.info(Constants.BLANK, methodName, "successCount = " + invSuccessCount);

            query = CommunicationSQL.INSERT_FILE_SQL.replace("table_name", successCdnTable);
            cdnSuccessCount = saveData(csvCdnSuccessFilePath, query);
            AppLogger.info(Constants.BLANK, methodName, "errorCount = " + cdnSuccessCount);

            response.setInvSuccessCount(invSuccessCount);
            response.setCdvSuccessCount(cdnSuccessCount);
            response.setErrorCount(invCdnErrorCount + invInvErrorCount);
        } catch (Exception e) {
            log.error(Constants.LOGERRORMESSAGE, methodName, e);
        }
        return response;
    }

    /**
     * Update process status with remarks.
     *
     * @param batchNo the batch no
     * @param pldUploadStatus the pld upload status
     * @param remarks the remarks
     */
    @Override
    public void updateProcessStatusWithRemarks(String batchNo, String pldUploadStatus,String remarks) {

        jdbcTemplateTrn.update(TransactionSQL.UPDATE_ERROR_REMARKS, pldUploadStatus,remarks, batchNo);

    }

	@Override
	public String getFPYearId(String fp) {
		String yearId = null;
		try {
			yearId = (String) jdbcTemplateMst.queryForObject(Constants.GET_RETURN_YEAR,String.class, fp);
		} catch (EmptyResultDataAccessException e) {
			yearId = "0";
		}
		return yearId;
	}

	
    
	@Override
	public List<String> getTdsSectionList() {
        return jdbcTemplateMst.queryForList(CommunicationSQL.GETTDSSECTIONLIST, String.class);
	}

	@Override
	public void updatePaymentDetailTable(List<PaymentDetails> paymentDetails,UploadReqDTO uploadDto) {
		int i=0;
		for(PaymentDetails payment:paymentDetails)
		{
			if(payment.getPaymentId()>=0)
			{
			jdbcTemplateTrn.update(CommunicationSQL.UPDATEPAYMENTDETAILS,payment.getDateOfPayment(),payment.getAmountofPayment(),payment.getPaymentRefNo(),
					payment.getInvAgainstProv(),payment.getInwardNoProvAdv(),Timestamp.from(Instant.now()),Timestamp.from(Instant.now()),payment.getPaymentId());
			}
			else
			{
				jdbcTemplateTrn.update(CommunicationSQL.INSERTPAYMENTDETAILS,payment.getDateOfPayment(),payment.getAmountofPayment(),payment.getPaymentRefNo(),
						payment.getInvAgainstProv(),
						payment.getInwardNoProvAdv(),payment.getGstinUinOfRecipient(),payment.getDocType(),
						payment.getGstinOfSupplier(),payment.getSupplierName(),payment.getInwardNo(),
						payment.getInwardDate(),Timestamp.from(Instant.now()),Timestamp.from(Instant.now()),uploadDto.getBatchNo());
			}
			i++;
		}
		
	}

	@Override
	public void updateTdsDetailTable( List<TdsDetails> tdsSections,UploadReqDTO uploadDto) {

		
		for(TdsDetails tdsDetails:tdsSections)
		{
			if(tdsDetails.getTdsId()>=0)
			{
			jdbcTemplateTrn.update(CommunicationSQL.UPDATETDSDETAILS,tdsDetails.getTdsSection(),tdsDetails.getTdsRate(),tdsDetails.getTdsTaxAmount(),
					tdsDetails.getChallanNo(),tdsDetails.getChallanDate(),tdsDetails.getChallanAmount(),tdsDetails.getPeriodFilingTdsReturn(),
					tdsDetails.getGrossAmount(),tdsDetails.getDateofPayment(),tdsDetails.getPaymentRefNo(),
					tdsDetails.getPaymentAmount(),tdsDetails.getAssAmt(),tdsDetails.getInvoiceAgainstProvAdv(),
					tdsDetails.getInwardNoProvAdv(),tdsDetails.getInwardDateprovAdv(),tdsDetails.getAmountofProvAdv(),
					tdsDetails.getBalOutstanding(),tdsDetails.getVendorCodeErp(),Timestamp.from(Instant.now()),tdsDetails.getTdsId());
			}
			else
			{
				jdbcTemplateTrn.update(CommunicationSQL.INSERTTDSDETAILS,tdsDetails.getPanOfRecipient(),
						tdsDetails.getGstinUinOfRecipient(),
						tdsDetails.getDocType(),tdsDetails.getGstinOfSupplier(),tdsDetails.getPanOfSupplier(),
						tdsDetails.getSupplierName(),
						tdsDetails.getDocNo(),tdsDetails.getDocDate(),
						tdsDetails.getInwardNo(),tdsDetails.getInwardAate(),
						tdsDetails.getTdsSection(),tdsDetails.getTdsRate(),
						tdsDetails.getTdsTaxAmount(),
						tdsDetails.getChallanNo(),tdsDetails.getChallanDate(),
						tdsDetails.getChallanAmount(),tdsDetails.getPeriodFilingTdsReturn(),
						tdsDetails.getDebitglId(),tdsDetails.getDebitglName(),
						tdsDetails.getCreditglId(),tdsDetails.getCreditglName(),
						tdsDetails.getGrossAmount(),tdsDetails.getDateofPayment(),tdsDetails.getPaymentRefNo(),
						tdsDetails.getPaymentAmount(),tdsDetails.getAssAmt(),tdsDetails.getInvoiceAgainstProvAdv(),
						tdsDetails.getInwardNoProvAdv(),tdsDetails.getInwardDateprovAdv(),tdsDetails.getAmountofProvAdv(),
						tdsDetails.getBalOutstanding(),tdsDetails.getVendorCodeErp(),Timestamp.from(Instant.now()),uploadDto.getBatchNo());
			}
			
		}
		
	}

	@Override
	public void deletePaymentItem(List<Integer> paymentDeletedIds) {
		paymentDeletedIds.stream().forEach(x
				->
			jdbcTemplateTrn.update(CommunicationSQL.DELETEFROMPAYMENTTABLE,x)
			);
		
	}

	@Override
	public void deleteTdsItems(List<Integer> paymentDeletedIds) {
		paymentDeletedIds.stream().forEach(x
				->
			jdbcTemplateTrn.update(CommunicationSQL.DELETEFROTDSTABLE,x)
			);
		
		
	}

	@Override
	public void deleteInvoicetItems(List<Integer> paymentDeletedIds,String docType) {
		paymentDeletedIds.stream().forEach(x
				->
			jdbcTemplateTrn.update("INV".equals(docType)?CommunicationSQL.DELETEFROMINVTABLE:CommunicationSQL.DELETEFROMDNRVTABLE,x)
			);
		
		
	}

	@Override
	public List<InwardInvoiceCDNTemplateDTO> getinvoiceForInwardCDN(String gstinOfRecipient, String orgInvoiceNo,
			String orgInvoiceDate, String gstinOfSupplier, String fp) {

		String query = "SELECT  gstin_of_supplier AS gstin_of_supplier,\r\n" + " 		doc_type AS doc_type,\r\n" + " 		invoice_category AS invoice_category,\r\n"
				+ "		import_type AS import_type,\r\n" + " 		is_removed AS isRemoved,\r\n" + " 		table_no AS table_no,\r\n" + "		fp AS fp\r\n"
				+ "     FROM    inward_purchase_reg\r\n" + "     WHERE   gstin_of_recipient = ?\r\n" + " 		AND gstin_of_supplier = ?\r\n" + "         AND inward_no = ?\r\n"
				+ "         AND inward_date=?\r\n" + "         AND (gstin_of_recipient, gstin_of_supplier, inward_no, row_version)\r\n"
				+ "             IN  (SELECT gstin_of_recipient, gstin_of_supplier, inward_no, MAX(row_version)\r\n" + "                     FROM inward_purchase_reg \r\n"
				+ "                     WHERE gstin_of_recipient = ?\r\n" + "                         AND gstin_of_supplier = ?\r\n"
				+ "                         AND inward_no = ? \r\n" + "                         AND inward_date=?\r\n"
				+ "                     GROUP BY inward_no, gstin_of_supplier\r\n" + "                 )\r\n" + "     ORDER BY row_version; ";


		return jdbcTemplateTrn.query(query,
				new ResultSetExtractor<List<InwardInvoiceCDNTemplateDTO>>() {
					@Override
					public List<InwardInvoiceCDNTemplateDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
						List<InwardInvoiceCDNTemplateDTO> listOFBatchData = new ArrayList<InwardInvoiceCDNTemplateDTO>();
						while (rs.next()) {
							InwardInvoiceCDNTemplateDTO template = new InwardInvoiceCDNTemplateDTO();
							template.setDocType(rs.getString("doc_type"));
							template.setGstinOfSupplier(rs.getString("gstin_of_supplier"));
							template.setOrgInvoiceCategory(rs.getString("invoice_category"));
							template.setImportType(rs.getString("import_type"));
							template.setTableNo(rs.getString("table_no"));
							// template.setOrgInvoiceCategory(rs.getString("invoice_category"));
							listOFBatchData.add(template);
						}
						return listOFBatchData;
					}
				},gstinOfRecipient, gstinOfSupplier, orgInvoiceNo, orgInvoiceDate, gstinOfRecipient, gstinOfSupplier, orgInvoiceNo, orgInvoiceDate);
	}

	

}
