package com.bdo.bvms.common.util;

import java.util.HashMap;
import java.util.Map;

public class CommonOpUtils {

	private CommonOpUtils()
	{
		super();
	}
	public static Map<String, String> getDocTypeMap() {
		Map<String, String> docTypes = new HashMap<>();
		docTypes.put("INV", "INV");
		docTypes.put("CRN", "CRN");
		docTypes.put("DBN", "DBN");
		return docTypes; 
	}
	
	public static Map<String, String> getSupplyTypeMap() {
		Map<String, String> supType = new HashMap<>();
		supType.put("B2B", "B2B");
		supType.put("B2BA", "B2BA");
		supType.put("B2CS", "B2CS");
		supType.put("B2CL", "B2CL");
		supType.put("B2CLA", "B2CLA");
		supType.put("NIL", "NIL");
		supType.put("EXM", "EXM");
		supType.put("NON", "NON");
		supType.put("EXPWP", "EXPWP");
		supType.put("EXPWOP", "EXPWOP");
		supType.put("EXPWPA", "EXPWPA");
		supType.put("EXPWOPA", "EXPWOPA");
		supType.put("SEZWP", "SEZWP");
		supType.put("SEZWOP", "SEZWOP");
		supType.put("SEZWPA", "SEZWPA");
		supType.put("SEZWOPA", "SEZWOPA");
		supType.put("DEXP", "DEXP");
		supType.put("DEXPA", "DEXPA");
		return supType; 
	}

}
