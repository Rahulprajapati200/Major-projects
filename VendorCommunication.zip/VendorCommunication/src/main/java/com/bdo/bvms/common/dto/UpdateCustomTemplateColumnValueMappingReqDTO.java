package com.bdo.bvms.common.dto;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UpdateCustomTemplateColumnValueMappingReqDTO {

	//@NotNull(message = "{customTemplateColumnValueMappingId.notNull}")
	Integer customTemplateColumnValueMappingId;
	
	@NotNull(message = "{optionId.notNull}")
	Integer optionId;
	
	List<@NotBlank(message = "{values.notBlank}") String> values;

}
