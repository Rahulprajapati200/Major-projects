package com.bdo.bvms.common.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bdo.bvms.common.dto.FinancialYearResDTO;

public class CustomeRowMapper implements RowMapper<FinancialYearResDTO> {

    @Override
    public FinancialYearResDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

    	FinancialYearResDTO e = new FinancialYearResDTO();
        e.setYearId(rs.getInt("year_id"));
        e.setFinancialYear(rs.getString("financial_year"));
        return e;
    }
}
