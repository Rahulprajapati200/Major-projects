package com.bdo.bvms.common.model;

import org.springframework.data.relational.core.mapping.Column;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EntityMaster {

    @Column(value="entity_id")
    Integer entityId;
    String pan;
    String gstin;

}
