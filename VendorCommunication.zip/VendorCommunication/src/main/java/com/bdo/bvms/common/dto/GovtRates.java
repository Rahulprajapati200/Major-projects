package com.bdo.bvms.common.dto;

import java.io.Serializable;

/**
 *FileType: java
 *Author : anka
 *Created On : 02/11/2017 6:56:39 PM
 *Copy Rights : Anka Technology Solutions Pvt. Ltd.
 */
public class GovtRates implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String gstRates;

	public GovtRates() {
		//
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getGstRates() {
		return gstRates;
	}

	public void setGstRates(String gstRates) {
		this.gstRates = gstRates;
	}

	public GovtRates(Integer id, String gstRates) {
		this.id = id;
		this.gstRates = gstRates;
	}

	@Override
	public String toString() {
		return "PreGST [id=" + id + ", gst_rates=" + gstRates + "]";
	}
}
