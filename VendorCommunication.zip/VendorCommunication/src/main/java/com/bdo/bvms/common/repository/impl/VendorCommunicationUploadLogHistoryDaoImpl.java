package com.bdo.bvms.common.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.CommonDao;
import com.bdo.bvms.common.dao.VendorCommunicationUploadLogHistoryDao;
import com.bdo.bvms.common.dto.ExceptionLogDTO;
import com.bdo.bvms.common.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.common.dto.UploadLogDto;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.sql.TransactionSQL;
import com.bdo.bvms.common.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class VendorCommunicationUploadLogHistoryDaoImpl implements VendorCommunicationUploadLogHistoryDao {

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Autowired
    CommonDao commonDao;
    
    @Value("${mst.database-name}")
    private String mstDatabaseName;

    @Override
    public Page<UploadLogDto> getHistoryList(UploadHistoryRequestDTO uploadHistoryRequestDTO)
                    throws VendorInvoiceServerException {

        // query for getting upload history data from database.
        StringBuilder query = TransactionSQL.getUploadHistory(uploadHistoryRequestDTO.getEntityId(),mstDatabaseName);
        if(StringUtils.isNotBlank(uploadHistoryRequestDTO.getSearchKey())) {
        	query.append(" and ( batch_no like '"+uploadHistoryRequestDTO.getSearchKey()+"%'");
        	query.append(" or taxpayer_pan like '"+uploadHistoryRequestDTO.getSearchKey()+"%'");
        	query.append(" or taxpayer_gstin like '"+uploadHistoryRequestDTO.getSearchKey()+"%'");
        	query.append(" or file_name like '"+uploadHistoryRequestDTO.getSearchKey()+"%')");
        	}
        query.append(" order by ul.created_at desc LIMIT "+uploadHistoryRequestDTO.getDefPageRecords()+" offset "
        +(uploadHistoryRequestDTO.getPageCount()-1)*uploadHistoryRequestDTO.getDefPageRecords());


        List<UploadLogDto> uploadLogDtoList = new ArrayList<>();
        try {
            uploadLogDtoList = jdbcTemplateTrn.query(query.toString(), new ResultSetExtractor<List<UploadLogDto>>() {

                // here we get upload history data from database.
                public List<UploadLogDto> extractData(ResultSet rs) throws SQLException, DataAccessException {
                    List<UploadLogDto> uploadLogDtoList = new ArrayList<>();
                    while (rs.next()) {

                        String createdAt = rs.getString(Constants.CREATED_AT);

                        UploadLogDto uploadLogDto = new UploadLogDto();
                        
                        uploadLogDto.setFp((rs.getString(Constants.FP_CONS)));
                        
                        uploadLogDto.setTaxpayerPan(rs.getString(Constants.TAXPAYER_PAN));
                        uploadLogDto.setTaxpayerGstin((rs.getString(Constants.TAXPAYER_GSTIN)));
                        uploadLogDto.setCreatedAt(DateUtil.convertDBtoScreen(createdAt));
                        uploadLogDto.setCreatedBy(rs.getString(Constants.CREATED_BY));
                        uploadLogDto.setTemplateType(rs.getString(Constants.TEMPLATE_TYPE));
                        uploadLogDto.setFileName(rs.getString(Constants.FILE_NAME));
                        uploadLogDto.setFileType(rs.getString(Constants.FILE_TYPE));
                        uploadLogDto.setTotalCount(rs.getInt(Constants.TOTAL_COUNT));
                        uploadLogDto.setSuccessCount(rs.getInt(Constants.SUCCESS_COUNT));
                        uploadLogDto.setErrorCount(rs.getInt(Constants.ERROR_COUNT));
                        uploadLogDto.setPldUploadStatus(rs.getString(Constants.PLD_UPLOAD_STATUS));
                        uploadLogDto.setBaseFileLocation(rs.getString(Constants.BASE_FILE_LOCATION));
                        uploadLogDto.setErrorFileLocation(rs.getString(Constants.ERROR_FILE_LOCATION));
                        uploadLogDto.setBatchNo(rs.getString(Constants.BATCH_NO));
                        uploadLogDto.setIsCustomTemplate(rs.getString(Constants.ISCUSTOMETEMPLATEFILETYPE));
                        uploadLogDto.setUploadSource(rs.getString(Constants.UPLOADSOURCETYPE));
                        uploadLogDtoList.add(uploadLogDto);
                    }
                    return uploadLogDtoList;
                }

            });
        } catch (DataAccessException e) {
            log.error("Exception come at the time of getting history data", e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();

            String methodName1 = "getHistoryList";

            // exceptionLogDTO.setUserId(uploadHistoryRequestDTO.getModuleID());
            exceptionLogDTO.setScreenName(Constants.VENDOR_COMMUNICATION);
            exceptionLogDTO.setFunctionName(methodName1);
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in getting data from database.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // add exception in exception log table if an exception is coming.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException(e.getMessage(), e.getCause());
        }

        if (uploadLogDtoList != null) {
            return new PageImpl<>(uploadLogDtoList);
        } else {

            return null;
        }

    }
}
