package com.bdo.bvms.common.sftp.upload.sql;

public class SftpUploadSql {
	SftpUploadSql() {

    }
    public static final String GET_PENDING_SFTP_FILES_UPLOAD_DETAILS = "SELECT ID,BATCHED_FILENAME,SFTP_PATH,template_type,PANNO,custom_templateid,CLIENT_FILENAME,dc_type,user_id FROM dc_batch_details where app_processed_status = \"PENDING\" and template_type= \"PURCHASE_REGISTER\";";
	public static String getUserIdQuery(String mstDatabseName, String userId) {
		return "SELECT user_id FROM " +mstDatabseName+".am_user_master where from_base64(login_id)=?";
	}
	public static String updateQuery() {
		return "UPDATE dc_batch_details set app_processed_status=? where app_processed_status=? and template_type like '%PURCHASE_REGISTER%'";
	}
	public static String getModuleId(String mstDatabseName) {
		//return "SELECT entity_id FROM "+ mstDatabseName+".am_entity_master where from_base64(pan)=? limit 1";
		return "SELECT em.entity_id FROM "+ mstDatabseName+ ".am_entity_master em join am_user_role_mapping rm on rm.entity_id=em.entity_id where from_base64(em.pan)=? and rm.gstin='999999'";
	}

}
