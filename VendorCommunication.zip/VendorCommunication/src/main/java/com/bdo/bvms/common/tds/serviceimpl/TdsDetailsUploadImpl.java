package com.bdo.bvms.common.tds.serviceimpl;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.CommonDao;
import com.bdo.bvms.common.dao.CustomTemplateRepo;
import com.bdo.bvms.common.dao.InwardRegisterDao;
import com.bdo.bvms.common.dao.UploadTransDao;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.PaymentResponseBean;
import com.bdo.bvms.common.dto.ResponseBean;

import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvalidTemplateHeaderException;

import com.bdo.bvms.common.payment.service.UploadNDownloadPaymentAzureFile;
import com.bdo.bvms.common.sql.CommunicationSQL;
import com.bdo.bvms.common.tds.dao.TdsDao;
import com.bdo.bvms.common.tds.service.ReadCustomTdsDetailTemplate;
import com.bdo.bvms.common.tds.service.ReadDtsExcelAndCSV;
import com.bdo.bvms.common.tds.service.TdsDetailValidate;
import com.bdo.bvms.common.tds.service.TdsDetailsUpload;
import com.bdo.bvms.common.tds.service.WriteTdsErrorAndSuccessCsv;

import com.bdo.bvms.common.util.CommonUtils;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class TdsDetailsUploadImpl implements TdsDetailsUpload{
	
	

	@Value("${bvms.cloud.temp.file.download.path}")
	String tempFolder;
	
	@Value("${mst.database-name}")
    private String mstDatabseName;
	
	Map<String,String> yearIdMap=new HashMap<>();
	
	@Autowired
	InwardRegisterDao commonCommunicationDao;
	
	@Autowired
    UploadTransDao uploadTransDao;
	
	
	
	@Autowired
	ReadDtsExcelAndCSV readDefaultExcelAndCSV;
	
	@Autowired
	ReadCustomTdsDetailTemplate readCustomTdsDetailTemplate;
	
	@Autowired
	TdsDetailValidate tdsDetailValidation;
	
	@Autowired
	WriteTdsErrorAndSuccessCsv writeErrorAndSuccessCsv;
	
	@Autowired
	CustomTemplateRepo customeTemplateRepo;
	
	@Autowired
	TdsDao tdsDao;
	
	 @Autowired
	 CommonDao commonDao;
	 @Autowired
	 UploadNDownloadPaymentAzureFile uploadNDownloadPaymentAzureFile;
	 
	@Async
	@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
	@Override
	public String validateAndSaveTdsDetails(UploadReqDTO uploadReqDTO,
			AzureConnectionCredentialsDTO storageCredentials) {

	List<TdsDetails>tdsDetailsTemplateDTOList=new ArrayList<>();
	List<TdsDetails>errorTdsDetailsTemplateDTOsList=new ArrayList<>();
	List<TdsDetails>sucessTdsDetailsTemplateDTOsList=new ArrayList<>();
	List<TdsDetails>rowDocErrorPojoList=new ArrayList<>();
    

 
    try {
    	uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_PROCESSING,
                Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadReqDTO);
        // Add entry in the process steps
        uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_INPROGRESS);

        // Add notification
        addInNotification(uploadReqDTO);
        yearIdMap = commonCommunicationDao.getYearId();
        if (Constants.XLSX.equalsIgnoreCase(uploadReqDTO.getFileType())) {
            if (Constants.ISDEFAULTTEMPLATE.equals(uploadReqDTO.getIsCustomTemplate())) {
            	readDefaultExcelAndCSV.readDataFromExcel(uploadReqDTO, tdsDetailsTemplateDTOList);
            } else if (Constants.ISCUSTOMETEMPLATE.equals(uploadReqDTO.getIsCustomTemplate())) {
            	readCustomTdsDetailTemplate.readCustomTemplate(uploadReqDTO,tdsDetailsTemplateDTOList);
            }
        } else if (Constants.CSV.equalsIgnoreCase(uploadReqDTO.getFileType())) {


        	if (uploadReqDTO.getIsCustomTemplate().equals(Constants.ISDEFAULTTEMPLATE)) {

        		readDefaultExcelAndCSV.readCSVFile(uploadReqDTO, tdsDetailsTemplateDTOList);
            
            }else if (uploadReqDTO.getIsCustomTemplate().equals(Constants.ISCUSTOMETEMPLATE)) {
                Map<String, String> customTemplateHeaderMappings = CommonUtils
                        .getCustomTemplateHeaderMappings(uploadReqDTO, customeTemplateRepo);
                readCustomTdsDetailTemplate.getInwardDataListCDV(uploadReqDTO,
                        customTemplateHeaderMappings, Constants.DELIMITER,tdsDetailsTemplateDTOList);
           }
           
        } else {
            return Constants.FILEFORMATNOTALLOWED;
        }
        
        uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_PROCESSING,
                Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadReqDTO);
        
        
        
        uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_VALIDATION,
                Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadReqDTO);
        
        uploadTransDao.updateTotalCountAndDocErrorCount(
        		tdsDetailsTemplateDTOList.size() + rowDocErrorPojoList.size(),
                rowDocErrorPojoList.size(), uploadReqDTO);
        
        tdsDetailValidation.validateTdsDetails(tdsDetailsTemplateDTOList, uploadReqDTO,errorTdsDetailsTemplateDTOsList,sucessTdsDetailsTemplateDTOsList,yearIdMap);
         
        
         
        
        uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_VALIDATION,
                Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadReqDTO);
        
        uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_COMPLETED,
                Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadReqDTO);
        
        writeErrorAndSuccessCsv.writeSuccessNErrorDataInCSVFile(uploadReqDTO, errorTdsDetailsTemplateDTOsList, sucessTdsDetailsTemplateDTOsList);
        
        String csvPaymentSuccessFilePath = CommonUtils.getPaymentSuccessFilePath(uploadReqDTO, tempFolder);
        String csvPaymentErrorFilePath = CommonUtils.getPaymentErrorFilePath(uploadReqDTO, tempFolder);
        
        PaymentResponseBean responseBean = tdsDao.gstInwardInvCdnInsert(csvPaymentSuccessFilePath, csvPaymentErrorFilePath,
                Constants.SUCCESS_TDS_TABLE,
                Constants.FAILURE_TDS_TABLE);
        
        uploadTransDao.updateTdsErrorNSuccessCountAndTotalCount(responseBean, rowDocErrorPojoList,
        		uploadReqDTO.getBatchNo());

        Map<String, String> codesMap = commonDao.getErrorCodesDescription();

        List<TdsDetails> errorDataListWithErrorCode = tdsDao
                        .getPaymentErrorDataListWithErrorCode(uploadReqDTO);
        
        if (!errorTdsDetailsTemplateDTOsList.isEmpty()) {
        	writeErrorAndSuccessCsv.writeAzureErrorDataInCSVFile(errorDataListWithErrorCode, uploadReqDTO, codesMap);
            uploadNDownloadPaymentAzureFile.uploadTDSErrorFile(uploadReqDTO, storageCredentials);
        }
        
        uploadTransDao.updateUploadStageNState(Constants.PROCESS_STAGE_COMPLETED,
                Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadReqDTO.getUploadLogId());
        
        String csvInvCdnErrorFilePath = CommonUtils.getAzureTdsErrorFilePath(uploadReqDTO, tempFolder);
        File file = new File(csvInvCdnErrorFilePath);
        if (file.exists() && responseBean.getErrorCount() > 0) {
            uploadTransDao.updateErrorFileName(uploadReqDTO.getBatchNo(),
            		uploadReqDTO.getBatchNo() + Constants.ERROR_DOT_CSV_AZURE_TDS);
        }
        
        if (responseBean != null && responseBean.getErrorCount() > 0) {
            uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_ERROR);
            uploadTransDao.commonPostNotification(Constants.COMMUNICATIONMSTID,
                            Constants.INWARD_FILE_UPLOAD_ERROR + uploadReqDTO.getBatchNo(), uploadReqDTO.getUserId(),
                            uploadReqDTO.getUserId(), uploadReqDTO.getUserId(), mstDatabseName, Constants.NOTIFICATION_ERROR);

        } else {
            uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_COMPLETED);
            if (responseBean != null) {
                uploadTransDao.commonPostNotification(Constants.COMMUNICATIONMSTID,
                                Constants.INWARDFILEUPLOADED + uploadReqDTO.getBatchNo(), uploadReqDTO.getUserId(),
                                uploadReqDTO.getUserId(), uploadReqDTO.getUserId(), mstDatabseName,
                                Constants.NOTIFICATION_SUCCESS);
            }
        }
        uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_COMPLETED,
                Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadReqDTO);
   
        
        
        uploadTransDao.updateTimeStamp(CommunicationSQL.UPDATE_VALIDATION_FINAL_TIME_STAMP, uploadReqDTO);
    } catch (InvalidTemplateHeaderException ex) {
    	uploadTransDao.updateTimeStamp(CommunicationSQL.UPDATE_VALIDATION_FINAL_TIME_STAMP, uploadReqDTO);
        uploadTransDao.updateProcessStatusWithRemarks(uploadReqDTO.getBatchNo(),
                        Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE, ex.getMessage());
    }        
    catch (Exception ex) {
        log.error(Constants.PROCESSINGFILEEXCEPTIONLOG + uploadReqDTO.getBatchNo(), ex);
        uploadTransDao.updateTimeStamp(CommunicationSQL.UPDATE_VALIDATION_FINAL_TIME_STAMP, uploadReqDTO);
        log.error("Error generated in methodName", ex);
        uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
        uploadTransDao.updateErrorNSuccessCountAndTotalCount(new ResponseBean(0, 0, 0), new ArrayList<>(),
        		uploadReqDTO.getBatchNo());
        //logIntoToExceptionTable(uploadReqDTO, ex, methodName);
    }
    finally {
    	CommonUtils.deleteTempTdsFiles(tempFolder, uploadReqDTO);
	}
    return Constants.FILEUPLOADEDSUCCESSFUL;

}
	
	public void addInNotification(UploadReqDTO uploadRequestDTO) {
        try {
            uploadTransDao.commonPostNotification(Constants.COMMUNICATIONMSTID,
                            Constants.INWARD_FILE_IN_PROGRESS + uploadRequestDTO.getBatchNo(),
                            uploadRequestDTO.getUserId(), uploadRequestDTO.getUserId(), uploadRequestDTO.getUserId(),
                            mstDatabseName, Constants.NOTIFICATION_INITIATED);
        } catch (Exception e) {
            log.error("Error generated while posting notification::", e);
        }
    }

}
