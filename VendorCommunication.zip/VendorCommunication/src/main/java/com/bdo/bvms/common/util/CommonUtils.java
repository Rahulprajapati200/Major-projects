package com.bdo.bvms.common.util;

import java.io.File;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.constant.StringConstant;
import com.bdo.bvms.common.dao.CustomTemplateRepo;
import com.bdo.bvms.common.dto.InwardInvoiceCDNReqDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;
// TODO: Auto-generated Javadoc

/**
 * The Class CommonUtils.
 */
public class CommonUtils {

    /**
     * Instantiates a new common utils.
     */
    CommonUtils() {

    }

    /**
     * Gets the column name list.
     *
     * @param coumnsDataRow
     *            the coumns data row
     * @return the column name list
     */
    public static List<String> getColumnNameList(Row coumnsDataRow) {

        List<String> headerList = new ArrayList<>();
        int minColIx = coumnsDataRow.getFirstCellNum(); // get the first column
        // index for a row
        int maxColIx = coumnsDataRow.getLastCellNum(); // get the last column
        // index for a row
        Cell cell;
        for (int colIx = minColIx; colIx < maxColIx; colIx++) { // loop from
            // first to last
            // index
            cell = coumnsDataRow.getCell(colIx); // get the cell

            if (cell.getCellType() == CellType.NUMERIC) {
                headerList.add(String.valueOf(cell.getNumericCellValue()));
            } else {
                headerList.add(cell.getStringCellValue());
            }

        }
        return headerList;
    }

    /**
     * Gets the batch no. *
     * 
     * @param uploadRequestDTO
     *            the upload request DTO
     * @return the batch no
     */
    public static String getBatchNo(InwardInvoiceCDNReqDTO uploadRequestDTO) {
        StringBuilder batchNo = new StringBuilder();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(Constants.DD_MM);

        String currentDate = simpleDateFormat.format(new Date());

        Long currentTimestamp = new Timestamp(System.currentTimeMillis()).getTime();

        batchNo.append(uploadRequestDTO.getTemplatetypepldCode() + Constants.UNDERSCORE + uploadRequestDTO.getUserId()
                        + Constants.UNDERSCORE + uploadRequestDTO.getEntityId() + Constants.UNDERSCORE + currentDate
                        + Constants.UNDERSCORE + currentTimestamp + Constants.UNDERSCORE
                        + generateRandonAlphabeticString(Constants.RANDOMNUM));

        return batchNo.toString();

    }

    /**
     * Gets the inv error file path.
     *
     * @param uploadDTO
     *            the upload DTO
     * @param tempFolder
     *            the temp folder
     * @return the inv error file path
     */
    public static String getInvErrorFilePath(UploadReqDTO uploadDTO, String tempFolder) {
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(Constants.FILESEPERATOR))
                        .append(uploadDTO.getBatchNo() + Constants.ERROR_DOT_CSV_INV);
        return fileName.toString();
    }

    /**
     * Gets the azure error file path.
     *
     * @param uploadDTO
     *            the upload DTO
     * @param tempFolder
     *            the temp folder
     * @return the azure error file path
     */
    public static String getAzureErrorFilePath(UploadReqDTO uploadDTO, String tempFolder) {
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(Constants.FILESEPERATOR))
                        .append(uploadDTO.getBatchNo() + Constants.ERROR_DOT_CSV_AZURE_INV);
        return fileName.toString();
    }

    /**
     * Gets the INV success file path.
     *
     * @param uploadDTO
     *            the upload DTO
     * @param tempFolder
     *            the temp folder
     * @return the INV success file path
     */
    // System.getProperty(Constants.FILESEPERATOR)
    public static String getINVSuccessFilePath(UploadReqDTO uploadDTO, String tempFolder) {
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(Constants.FILESEPERATOR))
                        .append(uploadDTO.getBatchNo() + Constants.SUCCESS_DOT_CSV_INV);
        return fileName.toString();
    }

    /**
     * Gets the CDN success file path.
     *
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param tempFolder
     *            the temp folder
     * @return the CDN success file path
     */
    public static String getCDNSuccessFilePath(UploadReqDTO uploadRequestDTO, String tempFolder) {
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(Constants.FILESEPERATOR))
                        .append(uploadRequestDTO.getBatchNo() + Constants.SUCCESS_DOT_CSV_CDN);
        return fileName.toString();

    }

    /**
     * Gets the azure inv error file path.
     *
     * @param uploadDTO
     *            the upload DTO
     * @param tempFolder
     *            the temp folder
     * @return the azure inv error file path
     */
    public static String getAzureInvErrorFilePath(UploadReqDTO uploadDTO, String tempFolder) {
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(Constants.FILESEPERATOR))
                        .append(uploadDTO.getBatchNo() + Constants.ERROR_DOT_CSV_AZURE_INV);
        return fileName.toString();
    }

    /**
     * Gets the cdn error file path.
     *
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param tempFolder
     *            the temp folder
     * @return the cdn error file path
     */
    public static String getCdnErrorFilePath(UploadReqDTO uploadRequestDTO, String tempFolder) {
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(Constants.FILESEPERATOR))
                        .append(uploadRequestDTO.getBatchNo() + Constants.ERROR_DOT_CSV_CDN);
        return fileName.toString();
    }

    /**
     * Gets the custom template header mappings.
     *
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param customeTemplateRepo
     *            the custome template repo
     * @return the custom template header mappings
     */
    public static Map<String, String> getCustomTemplateHeaderMappings(UploadReqDTO uploadRequestDTO,
                    CustomTemplateRepo customeTemplateRepo) {
        if (uploadRequestDTO.getIsCustomTemplate().equals(Constants.ISCUSTOMETEMPLATE)) {
            // HardCoding
            return getCustomTemplateHeaderMappings(Integer.parseInt(uploadRequestDTO.getCustomTemplateId()),
                            customeTemplateRepo);
        }
        return Collections.emptyMap();
    }

    /**
     * Gets the custom template header mappings.
     *
     * @param parseInt
     *            the parse int
     * @param customeTemplateRepo
     *            the custome template repo
     * @return the custom template header mappings
     */
    private static Map<String, String> getCustomTemplateHeaderMappings(int parseInt,
                    CustomTemplateRepo customeTemplateRepo) {
        return customeTemplateRepo.searchCustomTemplateHeaderMappings(parseInt);
    }

    /**
     * Generate randon alphabetic string.
     *
     * @param length
     *            the length
     * @return the string
     */
    public static String generateRandonAlphabeticString(int length) {

        if (length < 6) {
            length = 6;
        }

        final char[] allAllowed = "abcdefghijklmnopqrstuvwxyzABCDEFGJKLMNPRSTUVWXYZ0123456789".toCharArray();

        SecureRandom random = new SecureRandom();

        StringBuilder password = new StringBuilder();

        for (int i = 0; i < length; i++) {
            password.append(allAllowed[random.nextInt(allAllowed.length)]);
        }

        return password.toString();

    }
    public static void deleteTempFiles(String tempFolder, UploadReqDTO uploadRequestDTO) {
        StringBuilder baseFileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadRequestDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(uploadRequestDTO.getFileType());
        File baseFile = new File(baseFileName.toString());
        if (baseFile.exists()) {
            FileUtils.deleteQuietly(baseFile);
        }

        String csvInvSuccessFilePath = CommonUtils.getINVSuccessFilePath(uploadRequestDTO, tempFolder);
        String csvCdnSuccessFilePath = CommonUtils.getCDNSuccessFilePath(uploadRequestDTO, tempFolder);
        String csvInvErrorFilePath = CommonUtils.getInvErrorFilePath(uploadRequestDTO, tempFolder);
        String csvCdnErrorFilePath = CommonUtils.getCdnErrorFilePath(uploadRequestDTO, tempFolder);
        String csvInvCdnErrorFilePath = CommonUtils.getAzureInvErrorFilePath(uploadRequestDTO, tempFolder);
        File errorFile = new File(csvInvErrorFilePath);
        if (errorFile.exists()) {
            FileUtils.deleteQuietly(errorFile);
        }
        File successInvFile = new File(csvInvSuccessFilePath);
        if (successInvFile.exists()) {
            FileUtils.deleteQuietly(successInvFile);
        }
        File successCdnFile = new File(csvCdnSuccessFilePath);
        if (successCdnFile.exists()) {
            FileUtils.deleteQuietly(successCdnFile);
        }
        File successCdnErrorFile = new File(csvCdnErrorFilePath);
        if (successCdnErrorFile.exists()) {
            FileUtils.deleteQuietly(successCdnErrorFile);
        }

        File successAxureErrorFile = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                        + uploadRequestDTO.getBatchNo() + Constants.ERROR_DOT_CSV_AZURE_INV);
        if (successAxureErrorFile.exists()) {
            FileUtils.deleteQuietly(successAxureErrorFile);
        }

        File errorFileAzure = new File(csvInvCdnErrorFilePath);
        if (errorFileAzure.exists()) {
            FileUtils.deleteQuietly(errorFileAzure);
        }

    }

	public static String getPaymentErrorFilePath(UploadReqDTO uploadReqDTO, String tempFolder) {
		StringBuilder fileName = new StringBuilder().append(tempFolder)
				.append(System.getProperty(Constants.FILESEPERATOR))
				.append(uploadReqDTO.getBatchNo() + Constants.ERROR_DOT_CSV_PAYMENT);
		return fileName.toString();
	}

	public static String getPaymentSuccessFilePath(UploadReqDTO uploadReqDTO, String tempFolder) {
		StringBuilder fileName = new StringBuilder().append(tempFolder)
				.append(System.getProperty(Constants.FILESEPERATOR))
				.append(uploadReqDTO.getBatchNo() + Constants.SUCCESS_DOT_CSV_PAYMENT);
		return fileName.toString();
	}

	public static String getAzurePaymentErrorFilePath(UploadReqDTO uploadReqDTO, String tempFolder) {
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                .append(System.getProperty(Constants.FILESEPERATOR))
                .append(uploadReqDTO.getBatchNo() + Constants.ERROR_DOT_CSV_AZURE_PAYMENT);
return fileName.toString();
}

	public static String getAzureTdsErrorFilePath(UploadReqDTO uploadRequestDTO, String tempFolder) {
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                .append(System.getProperty(Constants.FILESEPERATOR))
                .append(uploadRequestDTO.getBatchNo() + Constants.ERROR_DOT_CSV_AZURE_TDS);
return fileName.toString();
}


	public static String getItcSuccessFilePath(UploadReqDTO uploadReqDTO, String tempFolder) {
		StringBuilder fileName = new StringBuilder().append(tempFolder)
				.append(System.getProperty(Constants.FILESEPERATOR))
				.append(uploadReqDTO.getBatchNo() + Constants.SUCCESS_DOT_CSV_ITC);
		return fileName.toString();
	}

	public static String getItcErrorFilePath(UploadReqDTO uploadReqDTO, String tempFolder) {
		StringBuilder fileName = new StringBuilder().append(tempFolder)
				.append(System.getProperty(Constants.FILESEPERATOR))
				.append(uploadReqDTO.getBatchNo() + Constants.ERROR_DOT_CSV_ITC);
		return fileName.toString();
	}

	public static String getAzureItcErrorFilePath(UploadReqDTO uploadReqDTO, String tempFolder) {
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                .append(System.getProperty(Constants.FILESEPERATOR))
                .append(uploadReqDTO.getBatchNo() + Constants.ERROR_DOT_CSV_AZURE_ITC);
return fileName.toString();
}

	public static void deleteTempPaymentFiles(String tempFolder, UploadReqDTO uploadRequestDTO) {

        StringBuilder baseFileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadRequestDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(uploadRequestDTO.getFileType());
        File baseFile = new File(baseFileName.toString());
        if (baseFile.exists()) {
            FileUtils.deleteQuietly(baseFile);
        }

        String csvInvSuccessFilePath = CommonUtils.getPaymentSuccessFilePath(uploadRequestDTO, tempFolder);
        
        String csvCdnErrorFilePath = CommonUtils.getPaymentErrorFilePath(uploadRequestDTO, tempFolder);
        String csvInvCdnErrorFilePath = CommonUtils.getAzurePaymentErrorFilePath(uploadRequestDTO, tempFolder);
       
        File successInvFile = new File(csvInvSuccessFilePath);
        if (successInvFile.exists()) {
            FileUtils.deleteQuietly(successInvFile);
        }
       
        File successCdnErrorFile = new File(csvCdnErrorFilePath);
        if (successCdnErrorFile.exists()) {
            FileUtils.deleteQuietly(successCdnErrorFile);
        }

        File errorFileAzure = new File(csvInvCdnErrorFilePath);
        if (errorFileAzure.exists()) {
            FileUtils.deleteQuietly(errorFileAzure);
        }

    
		
	}

	public static void deleteTempTdsFiles(String tempFolder, UploadReqDTO uploadRequestDTO) {

        StringBuilder baseFileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadRequestDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(uploadRequestDTO.getFileType());
        File baseFile = new File(baseFileName.toString());
        if (baseFile.exists()) {
            FileUtils.deleteQuietly(baseFile);
        }

        String csvInvSuccessFilePath = CommonUtils.getPaymentSuccessFilePath(uploadRequestDTO, tempFolder);
        
        String csvCdnErrorFilePath = CommonUtils.getPaymentErrorFilePath(uploadRequestDTO, tempFolder);
        String csvInvCdnErrorFilePath = CommonUtils.getAzureTdsErrorFilePath(uploadRequestDTO, tempFolder);
       
        File successInvFile = new File(csvInvSuccessFilePath);
        if (successInvFile.exists()) {
            FileUtils.deleteQuietly(successInvFile);
        }
       
        File successCdnErrorFile = new File(csvCdnErrorFilePath);
        if (successCdnErrorFile.exists()) {
            FileUtils.deleteQuietly(successCdnErrorFile);
        }

        File errorFileAzure = new File(csvInvCdnErrorFilePath);
        if (errorFileAzure.exists()) {
            FileUtils.deleteQuietly(errorFileAzure);
        }

    
		
	}

	public static void deleteTempItcFiles(String tempFolder, UploadReqDTO uploadRequestDTO) {

        StringBuilder baseFileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadRequestDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(uploadRequestDTO.getFileType());
        File baseFile = new File(baseFileName.toString());
        if (baseFile.exists()) {
            FileUtils.deleteQuietly(baseFile);
        }

        String csvInvSuccessFilePath = CommonUtils.getItcSuccessFilePath(uploadRequestDTO, tempFolder);
        
        String csvCdnErrorFilePath = CommonUtils.getItcErrorFilePath(uploadRequestDTO, tempFolder);
        String csvInvCdnErrorFilePath = CommonUtils.getAzureItcErrorFilePath(uploadRequestDTO, tempFolder);
       
        File successInvFile = new File(csvInvSuccessFilePath);
        if (successInvFile.exists()) {
            FileUtils.deleteQuietly(successInvFile);
        }
       
        File successCdnErrorFile = new File(csvCdnErrorFilePath);
        if (successCdnErrorFile.exists()) {
            FileUtils.deleteQuietly(successCdnErrorFile);
        }

        File errorFileAzure = new File(csvInvCdnErrorFilePath);
        if (errorFileAzure.exists()) {
            FileUtils.deleteQuietly(errorFileAzure);
        }

    
		
	}

    

}
