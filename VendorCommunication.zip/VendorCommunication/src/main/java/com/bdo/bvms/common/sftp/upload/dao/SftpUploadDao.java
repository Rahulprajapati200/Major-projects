package com.bdo.bvms.common.sftp.upload.dao;

import java.util.List;

import com.bdo.bvms.common.sftp.upload.dto.SftpFileDetailsDto;

public interface SftpUploadDao {

	List<SftpFileDetailsDto> getSftpFileDetails();

	int getUserId(SftpFileDetailsDto sftpFileDetailsDto);

	void updateSftpPendingDetails();

	int getModuleId(SftpFileDetailsDto sftpFileDetailsDto);

	String getSftpConnectionStringFromDB();

	String getSftpContainerNameFromDB();

}
