package com.bdo.bvms.common.util;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.springframework.stereotype.Component;

@Component
public class ValidateBeanUtil {

	private ValidateBeanUtil()
	{
		super();
	}
    public static Set<ConstraintViolation<Object>> validateBean(Object object) {
        ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
        Validator validator = validatorFactory.usingContext().getValidator();
        Set<ConstraintViolation<Object>> constrains = validator.validate(object);
        return constrains;
    }

}
