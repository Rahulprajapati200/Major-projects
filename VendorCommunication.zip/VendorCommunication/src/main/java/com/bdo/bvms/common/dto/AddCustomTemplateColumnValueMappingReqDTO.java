package com.bdo.bvms.common.dto;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AddCustomTemplateColumnValueMappingReqDTO extends BaseReqDTO  {
	
	@NotNull(message = "Request parameter optionId must not be null")
	Integer optionId;
	
	List<@NotBlank(message = "Request parameter values must not be null or empty") String> values;

}
