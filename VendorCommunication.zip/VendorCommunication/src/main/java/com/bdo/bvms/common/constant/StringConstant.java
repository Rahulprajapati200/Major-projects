package com.bdo.bvms.common.constant;

import java.util.List;
import java.util.stream.Collectors;

/**
 * The Class StringConstant.
 */
public class StringConstant {
	private StringConstant()
	{
		super();
	}

    /** The Constant DB_COMMUNICATION_ERROR. */
    public static final String DB_COMMUNICATION_ERROR = "bvms.label.common.errorOccuredInOperation";

    /** The Constant DBEXCEPTION. */
    // Common Exception Code started here
    public static final String DBEXCEPTION = "9999";

    /*
     * valid GSTIN verifying regex Strings.
     */
    public static final String GSTINFORMAT_REGEX = "[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[Z]{1}[0-9a-zA-Z]{1}";
    public static final String UINFORMAT_REGEX = "[0-9]{4}[A-Z]{3}[0-9]{5}[UO]{1}[N][A-Z0-9]{1}";
    public static final String TDSREGEX = "[0-9]{2}[a-zA-Z]{4}[a-zA-Z0-9]{1}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[D]{1}[0-9a-zA-Z]{1}";

    /*
     * Regex string for only numeric keywords
     */
    public static final String ONLYNUMERIC = "[^0-9.]";

    /*
     * regex string for NonValid date
     */
    public static final String NONVALIDDATEFORMAT = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";

    /*
     * Valid Date format.
     * 
     */
    public static final String VALIDDATEFORMAT = "dd-MM-yyyy";

    /*
     * E-way bill Valid till can only have space ( ),(-)or colon (:)
     */
    public static final String SPECIALCHARACTERS = "^[a-zA-Z0-9\\-\\␣\\:]*";

    /*
     * Replaces each substring of this string that matches the given regular
     * expression.
     */
    public static final String SUBSTRINGREGEX = "[\n\r]";
    /*
     * Simple Date Format.
     */
    public static final String SIMPLEDATEFORMAT1 = "dd/MM/yyyy";
    public static final String SIMPLEDATEFORMAT2 = "dd/MM/yyyy";

    public static final String COMPAREABLESTRING = "capital goods";
    public static final String IMPORTINVOICE = "import invoice";
    public static final String ISDINVOICE = "isd invoice";
    public static final String INPUTS = "inputs";
    public static final String INPUTSERVICES = "input services";
    public static final String IMPGSEZ = "impgsez";
    public static final String CAPITALGOODS = "capital goods";
    
    public static final String COMMA = ",";
    
    public static final String PIPE =  "\\|"; 
   
    public static final String PIPE_SPACE =  "| ";

	public static final String FILESEPARATOR = "file.separator";

	public static final String DOTSEPARATOR = ".";

	public static final char COMMASEPERATOR = ',';

	public static final String HEADERCOUNTERRORMESSAGE = "Invalid Header or Header count is not matching for batch no."; 
    
    public static String join(List<String> namesList, String separator) {
        return String.join(separator, namesList);
    }
       
    
    public static String strJoin(List<String> namesList) {
        return String.join(",", namesList
                        .stream()
                        .map(name -> ("'" + name + "'"))
                        .collect(Collectors.toList()));
    }
    
	public static String joinString(List<String> string) {

		return org.springframework.util.StringUtils.collectionToDelimitedString(string, ",");

	}
	
	public static String joinStringWithBase64(List<String> namesList) {
        return String.join(",", namesList
                        .stream()
                        .map(name -> ("TO_BASE64('" + name + "')"))
                        .collect(Collectors.toList()));
    }
	
	
}
