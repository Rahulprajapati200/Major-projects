package com.bdo.bvms.common.dto;

import java.io.Serializable;
/**
 *FileType: java
 *Author : anka
 *Created On : 02/11/2017 6:56:39 PM
 *Copy Rights : Anka Technology Solutions Pvt. Ltd.
 */

public class DocType implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer pickupMasterId;
	private String refType;
	private String refCode;
	private String refShortDesc;
	private String refLongDesc;

	public DocType() {
		//
	}

	public Integer getPickupMasterId() {
		return pickupMasterId;
	}

	public void setPickupMasterId(Integer pickupMasterId) {
		this.pickupMasterId = pickupMasterId;
	}

	public String getRefType() {
		return refType;
	}

	public void setRefType(String refType) {
		this.refType = refType;
	}

	public String getRefCode() {
		return refCode;
	}

	public void setRefCode(String refCode) {
		this.refCode = refCode;
	}

	public String getRefShortDesc() {
		return refShortDesc;
	}

	public void setRefShortDesc(String refShortDesc) {
		this.refShortDesc = refShortDesc;
	}
	
	public String getRefLongDesc() {
		return refLongDesc;
	}

	public void setRefLongDesc(String refLongDesc) {
		this.refLongDesc = refLongDesc;
	}
	
	@Override
	public String toString() {
		return "DocType [pickup_master_id=" + pickupMasterId + ", ref_type=" + refType + ", ref_code=" + refCode + ", ref_short_desc=" + refShortDesc + ", ref_long_desc=" + refLongDesc + "]";
	}
}
