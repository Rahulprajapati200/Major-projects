package com.bdo.bvms.common.repository;

import java.util.List;

import com.bdo.bvms.common.model.EntityMaster;

public interface IEntityMasterRepository {

    EntityMaster getEntityMaster(Integer userId);

	List<EntityMaster> getEntityMasterList(List<String> searchList, String panOrGstin, Integer entityTypeId);
    

}
