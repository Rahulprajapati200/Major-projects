package com.bdo.bvms.common.dto;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InwardInvoiceCDNReqDTO extends BaseReqDTO {

    String gstinOrPan;
    MultipartFile file;
    String fileType;
    String templatetypepldCode;
    String year;
    List<String> month;

    String po;
    String poDate;
    List<String> gstinOrPanList;
    int moduleID;
    String customtemplateID;
    String isCustomTemplate;
    
    
    String sftpBatchedFilename;
    String uploadSftpSource;
    String sftpFileName;

}
