package com.bdo.bvms.common.config;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Configuration
class DatasourceConfiguration {

	@Value("${spring.datasource.mst.jdbc-url}")
	private String msturi;
	@Value("${spring.datasource.mst.username}")
	private String mstusername;
	@Value("${spring.datasource.mst.password}")
	private String mstpassword;
	
	@Value("${spring.datasource.txn.jdbc-url}")
	private String txnuri;
	@Value("${spring.datasource.txn.username}")
	private String txnusername;
	@Value("${spring.datasource.txn.password}")
	private String txnpassword;
	
	
	
	@Value("${spring.datasource.txn.driver-class-name}")
	private String driverClassName;

	@Value("${spring.datasource.hikari.maximum-pool-size}")
	private int maxpoolSize;

	@Value("${spring.datasource.hikari.maxLifetime}")
	private long maxLifetime;

	@Value("${spring.datasource.hikari.idleTimeout}")
	private long idleTimeout;

	@Value("${spring.datasource.hikari.connectionTimeout}")
	private long connectionTimeout;

	@Value("${spring.datasource.hikari.minimumIdle}")
	private int minimumIdle;

	@Bean
	@Primary
	@ConfigurationProperties(prefix = "spring.datasource.txn")
	DataSource trnDataSource() {

		SimpleDriverDataSource dataSource = new SimpleDriverDataSource();
		try {
			
			dataSource.setDriver(DriverManager.getDriver(txnuri));
			dataSource.setUrl(txnuri);
			dataSource.setUsername(txnusername);
			dataSource.setPassword(txnpassword);
			Properties connectionProperties = new Properties();
			connectionProperties.setProperty("characterEncoding", "UTF-8");
			connectionProperties.setProperty("prepareThreshold", "0");
			dataSource.setConnectionProperties(connectionProperties);
			return dataSource;
		} catch (SQLException e) {
		log.error("Error generated while creating connection");
		}
		return dataSource;
		
	


	}

	@Bean
	@ConfigurationProperties(prefix = "spring.datasource.mst")
	DataSource mstDataSource() {
		SimpleDriverDataSource dataSource = new SimpleDriverDataSource();
		try {
			
			dataSource.setDriver(DriverManager.getDriver(msturi));
			dataSource.setUrl(msturi);
			dataSource.setUsername(mstusername);
			dataSource.setPassword(mstpassword);
			Properties connectionProperties = new Properties();
			connectionProperties.setProperty("characterEncoding", "UTF-8");
			connectionProperties.setProperty("prepareThreshold", "0");
			dataSource.setConnectionProperties(connectionProperties);
			return dataSource;
		} catch (SQLException e) {
		log.error("Error generated while creating connection");
		}
		return dataSource;
	}

	@Bean
	JdbcTemplate jdbcTemplateTrn(@Qualifier("trnDataSource") DataSource ds) {
		return new JdbcTemplate(ds);
	}

	@Bean
	JdbcTemplate jdbcTemplateMst(@Qualifier("mstDataSource") DataSource ds) {
		return new JdbcTemplate(ds);
	}

}