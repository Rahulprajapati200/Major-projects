package com.bdo.bvms.common.dto;

import java.util.List;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TemplateColumnConfigResDTO {

	Integer id;
	Integer pldTemplateId;
	String columnName;
	String dataType;
	Integer size;
	Boolean isMandatory;
	Boolean isAutoMapped;
	String customAutoMappedSource;
	Integer customColumnMappingId;
	Integer conditionalMandatoryGrouping;
	
	List<CustomTemplateOptionsResDTO> customTemplateOptions;
	
}
