package com.bdo.bvms.common.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class PaymentResponseBean implements Serializable{


	
    public PaymentResponseBean(Integer paymentSuccessCount, Integer errorCount) {
		super();
		this.paymentSuccessCount = paymentSuccessCount;
		this.errorCount = errorCount;
	}
	private static final long serialVersionUID = 8963887436856543497L;

    private String status = null;
    private String message = null;
    private boolean presentErrorRecords = false;
    private boolean presentSuccessRecords = false;
    private StringBuilder errorCodeList = new StringBuilder();
    private Integer paymentSuccessCount;
    private Integer errorCount;


	
}
