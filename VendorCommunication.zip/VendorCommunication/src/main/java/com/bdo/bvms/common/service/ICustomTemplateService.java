package com.bdo.bvms.common.service;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.common.dto.DeleteCustomTemplateReqDTO;
import com.bdo.bvms.common.dto.DownloadCustomTemplateReqDTO;
import com.bdo.bvms.common.dto.PaginationResDTO;
import com.bdo.bvms.common.dto.SearchCustomTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.SearchTemplateDetailsReqDTO;
import com.bdo.bvms.common.dto.TemplateHeaderWithColumnConfigResDTO;
import com.bdo.bvms.common.dto.TemplateTypeDetailsResDTO;
import com.bdo.bvms.common.dto.UpdateCustomTemplateDetailsReqDTO;

public interface ICustomTemplateService {
	
	void addCustomTemplateDetails(String customTemplateDetailsReq, MultipartFile file);
		
	TemplateHeaderWithColumnConfigResDTO searchTemplateHeaderWithAutoMappedColumn(MultipartFile file, Integer pldTemplateId);

	List<TemplateTypeDetailsResDTO> searchDefaultTemplates();

	PaginationResDTO searchCustomTemplates(SearchTemplateDetailsReqDTO searchTemplateDetailsReqDTO);

	void deleteCustomTemplate(DeleteCustomTemplateReqDTO deleteCustomTemplateReqDTO);

	Object searchCustomTemplateDetails(SearchCustomTemplateDetailsReqDTO searchCustomTemplateDetailsReqDTO);

	void updateCustomTemplateDetails(UpdateCustomTemplateDetailsReqDTO updateCustomTemplateDetailsReqDTO);

	File downloadCustomTemplate(DownloadCustomTemplateReqDTO downloadCustomTemplateReqDTO);

	Map<String, List<String>> previewTemplateSampleData(MultipartFile file, String previewCustomTemplateSampleData);
	
	
	Map<String,Map<String,Integer>> searchCustomTemplateOptionsMappings(int customTemplateId);

	Map<String,String> searchCustomTemplateHeaderMappings(int customTemplateId);


}
