package com.bdo.bvms.common.constant;

public class Constants {

    public static final Integer ISHSNVALIDATIONALLOWED = 1;

    private Constants() {
        super();
    }

    public static final String E_INVOICE = "e-Invoice";
    public static final String E_WAY_BILL = "e-Way Bill";
    public static final String INVOICE = "Invoice";
    public static final String INVOICE_MAPPING = "Invoice & PO Mapping";

    public static final String DATEFORMATE1 = "dd-MM-yyyy";

    public static final String DATEFORMATE2 = "dd/MM/yyyy";
    public static final String FILESEPERATOR = "file.separator";
    public static final String ROWVERSION_DATEFORMATE = "dd-M-yyyy hh:mm:ss";
    public static final int E_INVOICE_TEMPLATE_COLUMN_COUNT = 82;
    public static final String DATA_ROW = "coumnsDataRow";

    public static final String XLSX = "xlsx";
    public static final String XLS = "xls";
    public static final String CSV = "csv";
    public static final String PDF = "pdf";

    public static final Object DOTSEPERATOR = ".";

    public static final String FILENOTFOUNTONBLOB = "File is not Available on Blob";

    public static final String DATANOTFOUND = "No further Data is available in DB";
    public static final String VALIDATIONERROR = "Validation error";

    public static final int CUSTOM_TEMPLATE_NAME_PLD_STATUS_ACTIVE = 10;

    public static final int CUSTOM_TEMPLATE_NAME_PLD_STATUS_INACTIVE = 20;

    public static final int COLUMN_AUTOMAP_CHAR_START_INDEX = 0;

    public static final String PICKUP_MASTER_ADDRESS_TYPE = "address_type";

    public static final String PICKUP_MASTER_DEFAULT_ADDRESS_TYPE = "default_address";

    public static final String PICKUP_MASTER_PRIMARY_CONTACT = "primary_contact";

    public static final String PICKUP_MASTER_PRIMARY_BANK = "primary_bank";

    public static final int COLUMN_AUTOMAP_CHAR_END_INDEX = 5;

    public static final String PLD_UPLOAD_TEMPLATE_TYPE = "upload_template_type";
    public static final String CUSTOM_TEMPLATE_TYPE_MODULE = "Vendor Master";

    public static final String VENDOR_UPLOAD_DEFAULT_TEMPLATE_PATH = "vendortemplatesample-excel (1)-1671175935995.xlsx";
    public static final int SMPICKTEMPLATEID = 8;
    public static final String VENDOR_MASTER = "vendor_master";

    public static final int VENDOR_DETAILS_EXCEL_HEADER_ROW_NO = 1;
    public static final int CUSTOM_VENDOR_DETAILS_EXCEL_HEADER_ROW_NO = 0;
    public static final String VENODR_DETAIL_TEMPLATE_FILE_TYPE_XLSX = "xlsx";
    public static final String VENODR_DETAIL_TEMPLATE_FILE_TYPE_XLS = "xls";
    public static final int VENDOR_MASTER_TEMPLATE_SHEET_NO = 0;
    public static final String VENDOR_MASTER_TEMPLATE_ROW_SKIP = "0,1";
    public static final String UNDERSCORE = "_";

    public static final String FILE = "file";
    public static final String HEADERS = "headers";
    public static final String ONE = "1";
    public static final String TWO = "2";

    public static final String PAN = "0";
    public static final String GSTIN = "1";

    public static final String VENDOR_ENTITY_TYPE = "VENDOR";
    public static final String GSTIN_OR_PAN_LIST = "GstinOrPanList";

    public static final String ACCESS_CONTROL_EXPOSE_HEADERS = "Access-Control-Expose-Headers";

    public static final String HEADERS_FILENAME = "fileName";

    public static final String PICKUP_MASTER_MODULES = "modules";

    public static final int PLD_MODULES_VENDOR_MASTER_CODE = 2;

    public static final String FILE_EXTENSION = "fileExtension";

    public static final String CREATED_AT = "created_at";

    public static final String IS_MANDATORY = "is_mandatory";

    public static final String FROM_PLD = " from sm_pickup_list_details pld\r\n";

    public static final String JOIN_USERMASTER_PLD = "  join am_user_master um on pld.created_by=um.user_id  ";

    public static final String JOIN_PICKUP_MASTER_PLD = " INNER JOIN sm_pickup_master pm ON pm.pickup_master_id = pld.sm_pick_mst_id  ";

    public static final String SELECT_PLD_COLUMNS = "Select pld.id,sm_pick_mst_id, pld.name, code, short_desc, long_desc,pick_key, sort_order,pld.status, pld.created_at, pld.created_by,from_base64(first_name) userName \r\n";

    public static final String INNER_JOIN = "        INNER JOIN\n";

    public static final String OFFSET = " OFFSET ";

    public static final String LIMIT = " LIMIT ";
    public static final String PENDING = "pending";
    public static final String SENT = "sent";
    public static final String FAILED = "failed -";
    public static final String DD_MM = "dd_MM";
    public static final String DOTSEPARATOR = ".";
    public static final String ERROR_DOT_CSV_INV = "inv_error.csv";
    public static final String SUCCESS_DOT_CSV_INV = "_inv_success.csv";
    public static final String SUCCESS_DOT_CSV_CDN = "_cdn_success.csv";
    public static final String ERROR_DOT_CSV_AZURE_INV = "inv_cdn_azure_error.csv";
    public static final String FILEFORMATNOTALLOWED = "Invalid file type";
    public static final String FILETYPENOTCORRECT = null;
    public static final String INWARD_REGISTER = "105";
    public static final String OTHERS = "2";
    public static final String INVALIDTEMPLATETYPE = "Template Invalid";
    public static final String FILEUPLOADEPROGRESS = "File upload is in Progress , View Log for more ";
    public static final String FILEUPLOADEDSUCCESSFUL = "";
    public static final String SUBSTRINGREGEX = "[\n\r]";
    public static final String SPACE = "";
    public static final String COLUMN_GSTIN_UIN_OF_RECIPIENT = "gstin_uin_of_recipient";
    public static final String COLUMN_DOC_TYPE = "doc_type";
    public static final String COLUMN_SUPPLY_TYPE = "supply_type";
    public static final String COLUMN_DOC_NO = "doc_no";
    public static final String COLUMN_DOC_DATE = "doc_date";
    public static final String COLUMN_ORG_INVOICE_NO = "org_invoice_no";
    public static final String COLUMN_ORG_INVOICE_DATE = "org_invoice_date";
    public static final String COLUMN_GSTIN_OF_SUPPLIER = "gstin_of_supplier";
    public static final String COLUMN_SUPPLIER_NAME = "supplier_name";
    public static final String COLUMN_SUPPLIER_STATE_CODE = "supplier_state_code";
    public static final String COLUMN_INWARD_NO = "inward_no";
    public static final String COLUMN_INWARD_DATE = "inward_date";
    public static final String COLUMN_ITEM_DESCRIPTION = "item_description";
    public static final String COLUMN_HSN_SAC_CODE = "hsn_sac_code";
    public static final String COLUMN_UOM = "uom";
    public static final String COLUMN_QUINTITY = "quantity";
    public static final String COLUMN_ITEM_RATE = "item_rate";
    public static final String COLUMN_ASS_AMOUNT = "ass_amt";
    public static final String COLUMN_SGST_RATE = "sgst_rate";
    public static final String COLUMN_SGST_AMOUNT = "sgst_amt";
    public static final String COLUMN_CGST_RATE = "cgst_rate";
    public static final String COLUMN_CGST_AMOUNT = "cgst_amt";
    public static final String COLUMN_IGST_RATE = "igst_rate";
    public static final String COLUMN_IGST_AMOUNT = "igst_amt";
    public static final String COLUMN_CESS_RATE = "cess_rate";
    public static final String COLUMN_CESS_AMOUNT = "cess_amount";
    public static final String COLUMN_DIFF_PERCENT = "diff_percent";
    public static final String COLUMN_INWARD_GROSS_TOTAL_AMOUNT = "inward_gross_total_amount";
    public static final String COLUMN_TOTAL_INVOICE_AMOUNT = "total_invoice_amt";
    public static final String COLUMN_INPUT_TYPE = "input_type";
    public static final String COLUMN_ITC_INELIGIBLE_REVERSAL_INDICATOR = "itc_ineligible_reversal_indicator";
    public static final String COLUMN_ITC_INELIGIBLE_REVERSAL_PERCENTAGE = "itc_ineligible_reversal_percentage";
    public static final String COLUMN_PLACE_OF_SUPPLY = "place_of_supply";
    public static final String COLUMN_REVERSE_CHARGE = "reverse_charge";
    public static final String COLUMN_PORT = "port";
    public static final String COLUMN_IMPORT_BILL_OF_ENTRY_NO = "import_bill_of_entry_no";
    public static final String COLUMN_IMPORT_BILL_OF_ENTRY_DATE = "import_bill_of_entry_date";
    public static final String COLUMN_IMPORT_BILL_OF_ENTRY_AMT = "import_bill_of_entry_amt";
    public static final String DATE_OF_PAYMENT = "date_of_payment";
    public static final String IRN = "irn";
    public static final String COLUMN_ACK_DATE = "ack_date";
    public static final String COLUMN_ACK_NO = "ack_no";
    public static final String COLUMN_DEBIT_GL_ID = "debit_gl_id";
    public static final String COLUMN_DEBIT_GL_NAME = "debit_gl_name";
    public static final String COLUMN_CREDIT_GL_ID = "credit_gl_id";
    public static final String COLUMN_CREDIT_GL_NAME = "credit_gl_name";
    public static final String COLUMN_SUB_LOCATION = "sub_location";
    public static final String COLUMN_UDF_1 = "udf_1";
    public static final String COLUMN_UDF_2 = "udf_2";
    public static final String COLUMN_UDF_3 = "udf_3";
    public static final String COLUMN_UDF_4 = "udf_4";
    public static final String COLUMN_UDF_5 = "udf_5";
    public static final String COLUMN_UDF_6 = "udf_6";
    public static final String COLUMN_UDF_7 = "udf_7";
    public static final String COLUMN_UDF_8 = "udf_8";
    public static final String COLUMN_UDF_9 = "udf_9";
    public static final String COLUMN_UDF_10 = "udf_10";
    public static final String COLUMN_HSN_CODE = "hsn_code";

    public static final String BASE_DOT = "_base.";

    public static final String UPLOADSOURCE = "3";

    public static final int THREADCOUNT = 4;
    public static final Double TOLERANCE = 1.00;

    public static final String ID = "Id";

    public static final String BLANK = "";
    public static final String ROWVERSION = "rowVersion";
    public static final String VALID = "valid";
    public static final String BATCHNO = "batchNo";
    public static final String ERRORCODELIST = "error_code_list";

    public static final String SUCCESS_INV_TABLE = "inward_purchase_reg";
    public static final String SUCCESS_CDN_TABLE = "inward_dnr";
    public static final String FAILURE_INV_TABLE = "inward_purchase_reg_error";
    public static final String COLON = " : ";
    public static final String ERROR_DESCRIPTION = "error_Description";
    public static final String ERROR_CODES = "error_code";
    public static final String PROCESSINGFILEEXCEPTIONLOG = "Error generated while uploading templates for batch no:";

    public static final String UPLOAD_INVOICES_PLD_STATUS_INPROGRESS = "80";
    public static final String UPLOAD_INVOICES_PLD_STATUS_COMPLETED = "81";
    public static final String UPLOAD_INVOICES_PLD_STATUS_ERROR = "82";
    public static final String UPLOAD_INVOICES_PLD_STATUS_FAIL = "83";
    public static final String UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE = "84";

    public static final String PROCESS_STAGE_FILE_UPLOAD = "85";
    public static final String PROCESS_STAGE_DATA_VALIDATION = "87";
    public static final String PROCESS_STAGE_DATA_PROCESSING = "86";
    public static final String PROCESS_STAGE_COMPLETED = "88";
    public static final String PROCESS_FILE_UPLOAD_STATUS_START = "1";
    public static final String PROCESS_FILE_UPLOAD_STATUS_COMPLETED = "2";

    public static final String GET_RETURN_YEAR = "select year_id from sm_return_periods where fp = ?";

    public static final String ITEM_LEVEL_ERROR_CODE = "|E00061";
    public static final String COLUMN_SUPPLIER_COUNTRY_CODE = "supplier_country_code";
    public static final String COLUMN_INVOICE_CATEGORY = "invoice_category";
    public static final String COLUMN_INVOICE_TYPE = "invoice_type";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_TAXABLE_AMOUNT = "taxable_amount";
    public static final String TOTAL_TAX_AMOUNT = "total_tax_amount";
    public static final String COLUMN_COMPOSITION_AMT = "composition_amt";
    public static final String COLUMN_NIL_RATED_AMT = "nil_Rated_amt";
    public static final String NON_GST_AMT = "non_gst_amt";
    public static final String ITC_ELIGIBLE = "itc_eligible";
    public static final String TOTAL_ITC_AMT = "total_itc_amt";
    public static final String ITC_CESS_AMT = "itc_cess_amt";
    public static final String EXEMPTED_AMT = "exempted_amt";
    public static final String IMPORT_TYPE = "import_type";
    public static final String ITC_SGST_AMT = "itc_sgst_amt";
    public static final String SAVE_REF_ID = "save_ref_amt";
    public static final String ITC_CGST_AMT = "itc_cgst_amt";
    public static final String ITC_IGST_AMT = "itc_igst_amt";
    public static final String PORT_CD = "port_cd";
    public static final String TRAN_STATUS = "tran_status";
    public static final String USER_ID = "user_id";
    public static final String DELETE_REF_ID = "delete_ref_id";
    public static final String TABLE_NO = "table_no";
    public static final String LABELS = "labels";
    public static final String IS_REMOVED = "is_removed";
    public static final String REMOVED_BY = "removed_by";
    public static final String UPDATED_AT = "updated_at";
    public static final String FP = "fp";
    public static final String GSTR3B_STATUS = "gstr3b_status";
    public static final String ITC_CLAIM = "itc_claim";
    public static final String ITC_CLAIM_ON = "itc_claim_on";
    public static final String EXCEL_ROW_ID = "excel_row_id";
    public static final String ITC_CLAIM_RECORD_TYPE = "itc_claim_record";
    public static final String REASON = "reason";
    public static final String PRE_GST = "pre_gst";
    public static final String IS_AMENDMENT = "is_amendment";
    public static final String IS_INVOICE = "is_invoice";
    public static final String ITC_CLAIM_MONTH = "itc_claim_month";
    public static final String ITC_CLAIM_BY = "itc_claim_by";
    public static final String GROSS_TOTAL_AMOUNT = "gross_total_amount";
    public static final String MESSAGE = "message";
    public static final String VENDORCOMMUNICATION = "Vendor Communication Upload";
    public static final String NOTCONTAINPROPERDATA = "Not contain proper data.";
    public static final String EINVOICE_ERROR_CODE_DE1000 = "|DE1000";
    public static final String QUERY_TO_GET_ENTITY_ID = "select entity_id from am_entity_master where gstin = ? order by 1 desc limit 1";
    public static final String SUBQUERY = ".sm_return_periods where year_id = '";
    public static final String INVOICEREGEX = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";
    public static final String LOGMESSAGE = "Entering  Method : ";
    public static final String LOGERRORMESSAGE = "Error in Method";
    public static final String VENDOR_COMMUNICATION = "Error in Method";

    public static final String PYTHON = "python";
    public static final String USERDIRF = "user.dir";
    public static final String PYTHONSCRIPTANDQRCODESCAN = "\\pythonScripts\\qrcodescan.py";
    public static final String BACKWARDSLASH = "\"";
    public static final String SINGLEQUOTE = "'";
    public static final String QRDETAILS = "qrdetails";
    public static final String DATA = "data";
    public static final String BUYERGSTIN = "BuyerGstin";
    public static final String SELLERGSTIN = "SellerGstin";
    public static final String DOCTYP = "DocTyp";
    public static final String DOCNO = "DocNo";
    public static final String DOCDT = "DocDt";
    public static final String TOTINVVAL = "TotInvVal";
    public static final String MAINHSNCODE = "MainHsnCode";
    public static final String IRNDT = "IrnDt";
    public static final String INVOICEINTEGRATION = "Invoice Integration Upload";
    public static final String INVOICEINTEGRATIONGRIDDATA = "Invoice Integration Grid Data";
    public static final String UNEXPECTEDERROR = "Unexpected error";
    public static final String ERRORCODE = "ErrorCode";
    public static final String SHORTDESCRIPTION = "ShortDescription";
    public static final String TAXPAYER_PAN = "taxpayer_pan";
    public static final String CREATED_BY = "created_by";
    public static final String TEMPLATE_TYPE = "template_type";
    public static final String FILE_NAME = "file_name";
    public static final String FILE_TYPE = "file_type";
    public static final String TOTAL_COUNT = "total_count";
    public static final String SUCCESS_COUNT = "success_count";
    public static final String ERROR_COUNT = "error_count";
    public static final String PLD_UPLOAD_STATUS = "pld_upload_status";
    public static final String BASE_FILE_LOCATION = "base_file_location";
    public static final String ERROR_FILE_LOCATION = "error_file_location";
    public static final String BATCH_NO = "batch_no";
    public static final String BASE = "base";
    public static final String ERROR = "error";
    public static final String LINERETURNTAB = "[\n\r\t]";
    public static final String PLD_TEMPLATE_TYPE = "pld_template_type";

    public static final String FILLING_PERIOD = "filing_period";
    public static final String TAXPAYER_GSTIN = "taxpayer_gstin";
    public static final String NOT = "not";
    public static final String YES = "yes";
    public static final String YEARMONTH = "yyyy-MM";
    public static final String COLUMN_PAN_RECIPIENT = "pan_of_recipient";

    public static final String COLUMN_PAN_OF_SUPPLIER = "pan_of_supplier";

    public static final String YEARID = "year_id";
    public static final Object ZEROVALUE = "0";
    public static final String YEARIDQUERY = "SELECT fp,year_id FROM sm_return_periods";
    public static final String FP_CONS = "fp";

    public static final String ERROR_DOT_CSV_CDN = "cdn_error.csv";
    public static final String DELETE_TRANS_ID = "delete_trans_id";
    public static final String FAILURE_CDN_TABLE = "inward_dnr_error";
    public static final String EXCEL_DOC_TYPE = "excel_doc_type";
    public static final String COLUMN_ORG_INVOICE_CATEGORY = "org_invoice_category";
    public static final String INWARD_TAXABLE_AMOUNT = "inward_taxable_amount";
    public static final String ORG_SUPPLY_TYPE = "org_supply_type";
    public static final String INWARD_TOTALTAX_AMOUNT = "inward_total_tax_amount";
    public static final String PORT = "port";
    public static final String ERROR_CODE_LIST = "error_code";
    public static final String ERROR_CODE_E00353 = "|E00353";
    public static final String BRACKET = ")";
    public static final String NONVALIDDATEFORMAT = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";
    public static final Object UNSERSCORE_BASE = "_base";
    public static final String ERROR_DOT_CSV = "_error.csv";
    public static final String ORG_DOC_TYPE = "org_doc_type";
    public static final String EINVOICE_ERROR_CODE_E00514 = "|E00514";
    public static final String PICKUP_MASTER_ATTACHMENT_TYPE = "attachment_type";
    public static final String SYSTEM_PARAMETER_MAX_FILE_SIZE_ALLOWED_KEYNAME = "Max_File_Size_Allowed";
    public static final String SYSTEM_PARAMETER_FILE_EXTN_NOT_ALLOWED_KEYNAME = "File_Ext_Not_Allowed";
    public static final int PLD_DATA_VERSION_VENDOR = 2;
    public static final String COMPANYLEGALNAME = "company_legal_name";
    public static final int PLD_MODULE_ID_INVITE_TRACKING = 64;
    public static final String WORKFLOW_SCREEN_TAB_CHANGES_ATTACHMENTS = "attachments";
    public static final int WORKFLOW_SCREEN_TAB_CHANGES_STATUS_ACTIVE = 1;
    public static final int COMMUNICATIONMSTID = 10;

    public static final String EINVOICEFILEUPLOADED = "Inward upload completed";
    public static final int SMPICKMSTPICKID = 8;
    public static final int VENDOR_INVOICE_PICK_KEY = 66;
    public static final String ISDEFAULTTEMPLATE = "0";
    public static final Object ISCUSTOMETEMPLATE = "1";
    public static final Object COLUMN_PURCHASE_ORDER_NO = "purchase_order_no";
    public static final Object COLUMN_PURCHASE_ORDER_DATE = "purchase_order_date";
    public static final Object COLUMN_IRN = "irn";
    public static final Object COLUMN_IRN_DATE = "irn_date";
    public static final String PURCHASEORDERREGE = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";
    public static final String VALIDIRNDATEREGEX = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";
    public static final String TWODECIMALCHECKREGEX = "^\\s*[-]{0,1}(?=.*\\d)\\d*(?:\\.\\d{1,2})?\\s*$";
    public static final String TWODECIMALCHECKREGEX2 = "^\\s*(?=.*\\d)\\d*(?:\\.\\d{1,2})?\\s*$";
    public static final String PURCHASEORDERREGEX = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";
    public static final String TWODECIMALHSN = "^\\s*(?=.*\\d)\\d*(?:\\.\\d{1,2})?\\s*$";
    public static final String VALIDINWARD = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";
    public static final String VALIDFP = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";
    public static final String VALIDINVOICEDATEREG = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";
    public static final String VALIDACKREGEX = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";
    public static final String TWODECIMALCHECKBOE = "^\\s*[-]{0,1}(?=.*\\d)\\d*(?:\\.\\d{1,2})?\\s*$";
    public static final String TWODECIMALCHECKBOE2 = "^\\s*(?=.*\\d)\\d*(?:\\.\\d{1,2})?\\s*$";
    public static final String TWODECIMAL = "^\\s*[-]{0,1}(?=.*\\d)\\d*(?:\\.\\d{1,2})?\\s*$";
    public static final String TWODECIMAL2 = "^\\s*(?=.*\\d)\\d*(?:\\.\\d{1,2})?\\s*$";
    public static final String TWODECIMALHSNCHECK = "^\\s*(?=.*\\d)\\d*(?:\\.\\d{1,2})?\\s*$";
    public static final String VALIDDOCDATEREGEX = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";
    public static final String SGSTREGEX = "^\\s*(?=.*[0-9])\\d*(?:\\.\\d{1,2})?\\s*$";
    public static final String CGSTREGEX = "^\\s*(?=.*[0-9])\\d*(?:\\.\\d{1,2})?\\s*$";
    public static final String IGSTREGEX = "^\\s*(?=.*[0-9])\\d*(?:\\.\\d{1,2})?\\s*$";
    public static final int RANDOMNUM = 5;
    public static final String REGX_DATEPATTERN = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";
    public static final String NOTIFICATION_SUCCESS = "220";
    public static final String NOTIFICATION_ERROR = "221";
    public static final String NOTIFICATION_INITIATED = "340";
    public static final String NOTIFICATION_IN_PROGRESS = "222";
    public static final String NOTIFICATION_INFORMATION = "223";
    public static final String INWARDFILEUPLOADED = "Validation Completed Successfully -";
    public static final String INWARD_FILE_IN_PROGRESS = "Validation Initiated  - ";
    public static final String INWARD_FILE_UPLOAD_ERROR = "Validation Failed -";
    public static final String ORG_INPUT_TYPE = "org_input_type";
    public static final String DOC_TYPE = "doc_type";
    public static final String INVOICE_CATEGORY = "invoice_category";
    public static final String EINVOICE_ERROR_CODE_E00019 = "|E00019";
    public static final String JPG = "jpg";
    public static final String MODULEIDCOMMUNICATION = "66";
    public static final String SFTPUPLOADSOURCE = "SFTP";

    public static final String WEBUPLOADSOURCE = "Manual";
    public static final String SUCCESSDETAILS = "SUCCESS";
    public static final String PENDINGDETAILS = "PENDING";
    public static final String COMMUNICATION_ERROR_CODE_O0093 = "|O0093";
    public static final String COMMUNICATION_ERRORCODE_E00253 = "|E00253";
    public static final String FORWORDSLASH = "/";
    public static final String ISCUSTOMETEMPLATEFILETYPE = "is_custom_template";
    public static final String UPLOADSOURCETYPE = "upload_source";

    public static final String PAYMENT_AMOUNT = "payment_amount";

    public static final String PAYMENT_REF_NO = "payment_ref_no";
    public static final String TDS_SECTION = "tds_section";
    public static final String TDS_RATE = "tds_rate";
    public static final String TDS_TAX_AMOUNT = "tds_tax_amount";
    public static final String CHALLAN_NUMBER = "challan_number";
    public static final String CHALLAN_DATE = "challan_date";
    public static final String CHALLAN_AMOUNT = "challan_amount";
    public static final String PERIOD_OF_FILLING = "period_of_filing";
    public static final String INVOICE_AGAINST_PROV_ADV = "invoice_against_prov_adv";
    public static final String INWARD_NO_PROV_ADV = "inward_no_prov_adv";
    public static final String INWARD_DATE_PROV_ADV = "inward_date_prov_adv";
    public static final String AMOUNT_OF_PROV_ADV = "amount_of_prov_adv";
    public static final String BAL_OUTSTANDING = "bal_outstanding";
    public static final String COLUMN_UDF_11 = "udf_11";
    public static final String COLUMN_UDF_12 = "udf_12";
    public static final String COLUMN_UDF_13 = "udf_13";
    public static final String COLUMN_UDF_14 = "udf_14";
    public static final String COLUMN_UDF_15 = "udf_15";
    public static final String COLUMN_UDF_16 = "udf_16";
    public static final String COLUMN_UDF_17 = "udf_17";
    public static final String COLUMN_UDF_18 = "udf_18";
    public static final String COLUMN_UDF_19 = "udf_19";
    public static final String COLUMN_UDF_20 = "udf_20";
    public static final String IS_DEL_FRM_REMOVE_RECORD_SCR = "is_del_frm_remove_record_scr";
    public static final String UUID = "uiid";

    public static final String PAYMENT_DETAILS = "331";
    public static final String ERRORINREADINGHEADECOUNT = "Error in reading Header count with column";
    public static final int PAYMENT_TEMPLATE_HEADER_COUNT = 32;
    public static final String ERROR_DOT_CSV_PAYMENT = "payment_error.csv";
    public static final String SUCCESS_DOT_CSV_PAYMENT = "payment_success.csv";
    public static final String ZERO = "0";
    public static final String INWARD_SUMMARY_HDRID = "inward_summary_hdr_id";
    public static final String PAYMENT_FP = "payment_fp";
    public static final String REFERECE_ID = "reference_if";
    public static final String FAILURE_PAYMENT_TABLE = "inward_purchase_register_payment_details_error";
    public static final String SUCCESS_PAYMENT_TABLE = "inward_purchase_register_payment_details";
    public static final String ERROR_DOT_CSV_AZURE_PAYMENT = "payment_azure_error.csv";
    public static final String PAYMENT_DATE = "date_of_payment";
    public static final String FPDATEFORMATE = "MM/yyyy";
    public static final String TDS_DETAILS = "106";
    public static final String COLUMN_VENDOR_CODE_ERP = "vendor_code_erp";
    public static final String GROSS_AMOUNT = "gross_amount";
    public static final int TDS_TEMPLATE_HEADER_COUNT = 53;
    public static final String ERROR_DOT_CSV_AZURE_TDS = "tds_azure_error.csv";
    public static final String SUCCESS_TDS_TABLE = "inward_tds";
    public static final String FAILURE_TDS_TABLE = "inward_tds_error";
    public static final String PANREGEX = "[A-Z]{5}[0-9]{4}[A-Z]{1}";
    public static final String ITC = "107";
    public static final int ITC_TEMPLATE_HEADER_COUNT = 39;
    public static final String SUCCESS_ITC_TABLE = "inward_itc";
    public static final String FAILURE_ITC_TABLE = "inward_itc_error";
    public static final String SUCCESS_DOT_CSV_ITC = "itc_success.csv";
    public static final String ERROR_DOT_CSV_ITC = "itc_error.csv";
    public static final String ERROR_DOT_CSV_AZURE_ITC = "itc_azure_error.csv";
    public static final String ERROR_CODE_E00570 = "|E00570";
    public static final String ERROR_CODE_E00573 = "|E00573";
    public static final String ERROR_CODE_E00574 = "|E00574";
    public static final String UPDATED_BY = "updated_by";
    public static final String REMARKS = "remarks";
	public static final String ERROR_CODE_E00584 = "|E00584";
	public static final char DELIMITER = ',';
	public static final String NOTIFICATION_FAILED = "387";
	public static final String INVALID_TEMPLATE = "Invalid Template";
	public static final String EINVOICE_ERROR_CODE_E00588 = "|E00588";
	public static final String EINVOICE_ERROR_CODE_E00039 = "|E00039";
	public static final String EINVOICE_ERROR_CODE_E00323 = "|E00323";
	public static final String EINVOICE_ERROR_CODE_E00017 = "|E00017";
	public static final String EINVOICE_ERROR_CODE_E00024 = "|E00024";
	public static final String EINVOICE_ERROR_CODE_E00027 = "|E00027";
	public static final String EINVOICE_ERROR_CODE_E00590 = "|E00590";
	public static final String EINVOICE_ERROR_CODE_E00591 = "|E00591";
	public static final String EINVOICE_ERROR_CODE_E00592 = "|E00592";
	public static final String EINVOICE_ERROR_CODE_E00593 = "|E00593";
	public static final String EINVOICE_ERROR_CODE_E00594 = "|E00594";

}
