package com.bdo.bvms.common.tds.service;

import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvoiceTemplateUploadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface ReadCustomTdsDetailTemplate {
	void readCustomTemplate(UploadReqDTO uploadReqDTO, List<TdsDetails> paymentDetailsTemplateDTOList) throws InvoiceTemplateUploadException;

	void getInwardDataListCDV(UploadReqDTO uploadReqDTO, Map<String, String> customTemplateHeaderMappings,
			char delimiter, List<TdsDetails> tdsDetailsTemplateDTOList) throws VendorInvoiceServerException;

}
