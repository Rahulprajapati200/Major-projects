package com.bdo.bvms.common.payment.validation;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.common.constant.ValidationConstant;

import com.bdo.bvms.common.dto.PaymentDetails;


import com.bdo.bvms.common.validationrule.InwardDroolUtil;

public class ValidatePaymentDetails {


	public void validatePaymentDetails(PaymentDetails rowData) {

		 
		InwardDroolUtil ruleMethods = new InwardDroolUtil();

		// Customer GSTIN validate
        validGstinCheck(rowData, ruleMethods);

        validGSTINTaxpayer(rowData, ruleMethods);
        
        // Check invoice no. is blank
        inwardNoCheck(rowData, ruleMethods);

        inwardNo16Length(rowData, ruleMethods);
        
     // inwardDate should be in DD-MM-YYYY format"
        isValidInvoiceDateCheck(rowData, ruleMethods);

        isValidInvoiceDateFutureCheck(rowData, ruleMethods);

        validatefPaymentDetails(rowData);
        
        validateinvoiceAgainstProvAdv(rowData);
        
        validateInwardNoProvAdv(rowData, ruleMethods);
        
        validateInwardNoProvAdvLength(rowData);
        
        validateDocType(rowData);
      
        validatePaymentDate(rowData, ruleMethods);
        
        validatePaymentAndInvoiceDate(rowData,ruleMethods);
        
        validatePaymentDateFuture(rowData,ruleMethods);
        
        validatePaymentRefNo(rowData,ruleMethods);
        
        checkForTaxPayerGstinEqualsSupplierGstin(rowData);
        
        assAmtDecimalCheck(rowData,ruleMethods);
        
        supplierNameCheck(rowData,ruleMethods);
        
	}
	
	private void supplierNameCheck(PaymentDetails rowData, InwardDroolUtil ruleMethods) {
		if(StringUtils.isNotBlank(rowData.getSupplierName()) && rowData.getSupplierName().length()>255)
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00583, "");
		}
		
	}

	private void validatePaymentAndInvoiceDate(PaymentDetails rowData, InwardDroolUtil ruleMethods) {
		if(ruleMethods.isValidInvoiceDate(rowData.getDateOfPayment()) && ruleMethods.isValidInvoiceDate(rowData.getInwardDate()) && !ruleMethods.ifExceedDate(rowData.getInwardDate(), rowData.getDateOfPayment()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00571, "");
		}
		
	}
	
	private void validatePaymentDateFuture(PaymentDetails rowData, InwardDroolUtil ruleMethods) {
		if(ruleMethods.isValidInvoiceDate(rowData.getDateOfPayment()) && !ruleMethods.isValidFutureInvoiceDate(rowData.getDateOfPayment()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00572, "");
		}
		
	}

	private void validatePaymentRefNo(PaymentDetails rowdata, InwardDroolUtil inwardRules) {

		if (StringUtils.isBlank(rowdata.getPaymentRefNo())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00526, "");
		} else if (!inwardRules.isSpecialCharExistInInvoiceNo(rowdata.getPaymentRefNo())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00526, "");
		}
	}


	private void validGstinCheck(PaymentDetails rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.validTdsGSTIN(rowdata.getGstinOfSupplier())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00519, "");
        }
	}

	
	private void validGSTINTaxpayer(PaymentDetails rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.validGSTIN(rowdata.getGstinUinOfRecipient())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00517, "");
        }
	}
	
	private void inwardNoCheck(PaymentDetails rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.isInvoiceNoExist(rowdata.getInwardNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00030, "");
        } else if (!ruleMethods.isSpecialCharExistInInvoiceNo(rowdata.getInwardNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00054, "");
        }
	}
	
	
	private void inwardNo16Length(PaymentDetails rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.check16CharacterLength(rowdata.getInwardNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00031, "");
        }
	}
	
	private void isValidInvoiceDateCheck(PaymentDetails rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.isValidInvoiceDate(rowdata.getInwardDate())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00313, "");
        }
	}
	
	private void isValidInvoiceDateFutureCheck(PaymentDetails rowdata, InwardDroolUtil ruleMethods) {
		boolean isValidDate=ruleMethods.isValidInvoiceDate(rowdata.getInwardDate());
		boolean isValidFutureDate=ruleMethods.isValidFutureInvoiceDate(rowdata.getInwardDate());
		if (isValidDate && !isValidFutureDate) {
			 markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00315, "");
        }
	}

	
	private void markErrorNAddErrorCode(PaymentDetails rowdata, String errorCode, String errorMsg) {
        rowdata.setErrorCodeList(rowdata.getErrorCodeList().append(errorCode));
        rowdata.setErrorDescriptionList(rowdata.getErrorDescriptionList().append(errorMsg));
        rowdata.setValid(false);
    }


	private void validatefPaymentDetails(PaymentDetails rowdata)
	{	
			if(new BigDecimal(rowdata.getAmountofPayment()).compareTo(new BigDecimal(0))<1)
			{
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00560, "");
			}
			if(StringUtils.isBlank(rowdata.getDateOfPayment()))
			{
			    markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00562, "");
			}
			
			if(StringUtils.isBlank(rowdata.getPaymentRefNo()))
			{
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00561, "");
			}
			
	}
	


	private void validateinvoiceAgainstProvAdv(PaymentDetails rowdata) {
		if (StringUtils.isNotBlank(rowdata.getInvAgainstProv())) {
			List<String> invoiceAgainstProvAdv = new ArrayList<>(Arrays.asList("Yes", "No"));
			if (!invoiceAgainstProvAdv.contains(rowdata.getInvAgainstProv())) {
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00533, "");
			}
		}
	}
	
	private void validateInwardNoProvAdv(PaymentDetails rowdata, InwardDroolUtil ruleMethods)
	{
		if (StringUtils.isNotBlank(rowdata.getInwardNoProvAdv()) && !ruleMethods.isSpecialCharExistInInvoiceNo(rowdata.getInwardNoProvAdv())) {
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00534, "");
		}
	}
	
	private void validateInwardNoProvAdvLength(PaymentDetails rowdata)

	{
		if (StringUtils.isNotBlank(rowdata.getInwardNoProvAdv()) && rowdata.getInwardNoProvAdv().length()>16) {
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00559, "");
		}
	}
	

	private void validateDocType(PaymentDetails rowdata) {
		List<String> docTypeList = new ArrayList<>(Arrays.asList("INV", "CRN","DBN"));
		if (StringUtils.isBlank(rowdata.getDocType()) || !docTypeList.contains(rowdata.getDocType())) {
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00257, "");
		}
	}
	
	 private void validatePaymentDate(PaymentDetails rowdata, InwardDroolUtil ruleMethods) {
			if(!ruleMethods.isValidInvoiceDate(rowdata.getDateOfPayment()))
			{
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00566, "");
			}
			
		}
	 
	 private void checkForTaxPayerGstinEqualsSupplierGstin(PaymentDetails rowdata) {
	        if (StringUtils.isNotBlank(rowdata.getGstinUinOfRecipient())
	                        && rowdata.getGstinUinOfRecipient().equals(rowdata.getGstinOfSupplier())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00518, "");
	        }
	    }
	 
	 
	 private void assAmtDecimalCheck(PaymentDetails rowData, InwardDroolUtil ruleMethods) {

			if(StringUtils.isNotBlank(rowData.getAmountofPayment()) && !ruleMethods.checkLength12(rowData.getAmountofPayment(),rowData.isValid()))
			{
				markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50031, "");
			}	
		}
		
}


