package com.bdo.bvms.common.sftp.upload.service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;

import com.bdo.bvms.common.exceptions.AzureUploadDownloadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.sftp.upload.dto.SftpFileDetailsDto;
import com.bdo.bvms.common.sftp.upload.dto.SftpUploadRequestDTO;
import com.microsoft.azure.storage.StorageException;

public interface SftpUploadService {

	void downloadFileFromSftpCloud(String batchNo, String fileExt, String fileNameOriginal)
			throws InvalidKeyException, URISyntaxException, StorageException, IOException;

	String uploadAndProcessFile(SftpFileDetailsDto fileDetailsDto, SftpUploadRequestDTO reqDto)
			throws VendorInvoiceServerException, AzureUploadDownloadException;

	String getBatchNo(SftpUploadRequestDTO reqDto);

	void downloadFileFromSftpCloud(String fileExtension, String batchedFileName) throws InvalidKeyException, URISyntaxException, StorageException, IOException;

}
