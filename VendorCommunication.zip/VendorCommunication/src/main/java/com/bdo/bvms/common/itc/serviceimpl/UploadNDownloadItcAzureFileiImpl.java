package com.bdo.bvms.common.itc.serviceimpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.config.AzureClientProvider;
import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.itc.service.UploadNDownloadItcAzureFile;
import com.bdo.bvms.common.util.CommonUtils;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class UploadNDownloadItcAzureFileiImpl implements UploadNDownloadItcAzureFile{
	 @Value("${bvms.cloud.temp.file.download.path}")
	 String tempFolder;
	 
	 @Autowired
	 public AzureClientProvider client;
	@Override
	public void uploadITCErrorFile(UploadReqDTO uploadDTO, AzureConnectionCredentialsDTO storageCredentials) {
        String csvErrorFilePath = CommonUtils.getAzureItcErrorFilePath(uploadDTO, tempFolder);
        File file = new File(csvErrorFilePath);

        final String methodName = " uploadErrorFile";
        log.info(Constants.LOGMESSAGE,methodName);
        try {

            try (InputStream inputStream = new FileInputStream(file)) {
                client.getClient(storageCredentials).blobName(uploadDTO.getBatchNo() + Constants.ERROR_DOT_CSV_AZURE_ITC).buildClient()
                                .upload(inputStream, file.length());
            }

        } catch (Exception e) {
        	log.error(Constants.LOGERRORMESSAGE,methodName);
           
        }

    }

}
