package com.bdo.bvms.common.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public class DateUtil {

    private DateUtil() {
        super();
    }

    public static final String DATEFORMATTERFORUI = "dd-MM-yyyy";
    public static final String DATETIMEFORMATTERFORUI = "dd-MM-yyyy HH:mm:ss";

    public static final String DATETIMEFORMATTERFORDB = "yyyy-MM-dd HH:mm:ss";
    public static final String DATEFORMATTERFORDB = "yyyy-MM-dd";
	public static  final String DATE_ATTACHMENT_APPROVAL_FORMAT ="dd-mm-yyyy";
	public static  final String DATE_ATTACHMENT_UPLOADED_FORMAT ="dd/MM/yyyy";

    public static String convertDateToString(Date date, String formatter) {
        if (date == null || StringUtils.isAllBlank(formatter)) {
            return null;
        }

        // Converts the string
        // format to date object
        DateFormat df = new SimpleDateFormat(formatter);

        // Convert the date into a
        // string using format() method
        String dateToString = df.format(date);

        // Return the result
        return (dateToString);
    }

    public static String convertDBtoScreen(String strdate) {
        if (StringUtils.isNoneBlank(strdate)) {
            SimpleDateFormat fromFormatter = new SimpleDateFormat(DATETIMEFORMATTERFORDB);
            SimpleDateFormat toFormatter = new SimpleDateFormat(DATETIMEFORMATTERFORUI);
            try {
                Date date = fromFormatter.parse(strdate);
                return toFormatter.format(date);
            } catch (ParseException ex) {
                return strdate;
            }
        } else {
            return strdate;
        }

    }
    
    
    public static String getFormatedDate(String date) {

        String returnDate = date;

        if (StringUtils.isBlank(date)) {
            return returnDate;
        }

        String datePatternyyyymmddDash = "\\d{4}-\\d{1,2}-\\d{1,2}";
        String datePatternddmmyyyyDash = "\\d{1,2}-\\d{1,2}-\\d{4}";
        String datePatternddmmyyyySlash = "\\d{1,2}/\\d{1,2}/\\d{4}";
        String datePatternyyyymmddSlash = "\\d{4}/\\d{1,2}/\\d{1,2}";
        String datePatternyyyymmmddDash = "\\d{4}-\\d{1,2}-\\d{1,2}";
        String datePatternddmmmyyyyDash = "\\d{1,2}-\\d{1,2}-\\d{4}";
        String datePatternddmmmyyyySlash = "\\d{1,2}/\\d{1,2}/\\d{4}";
        String datePatternyyyymmmddSlash = "\\d{4}/\\d{1,2}/\\d{1,2}";

        if (date.matches(datePatternyyyymmddDash)) {
            if (date.contains("-")) {
                String[] splitedDate = date.split("-");
                returnDate = splitedDate[0] + "-" + splitedDate[1] + "-" + splitedDate[2];
            }
        } else if (date.matches(datePatternddmmyyyyDash)) {

            if (date.contains("-")) {
                String[] splitedDate = date.split("-");
                returnDate = splitedDate[0] + "-" + splitedDate[1] + "-" + splitedDate[2];
            }

        } else if (date.matches(datePatternddmmyyyySlash)) {

            if (date.contains("/")) {
                String[] splitedDate = date.split("/");
                returnDate = splitedDate[0] + "-" + splitedDate[1] + "-" + splitedDate[2];
            }
        } else if (date.matches(datePatternyyyymmddSlash)) {

            if (date.contains("/")) {
                String[] splitedDate = date.split("/");
                returnDate = splitedDate[2] + "-" + splitedDate[1] + "-" + splitedDate[0];
            }
        } else if (date.matches(datePatternyyyymmmddDash)) {
            if (date.contains("-")) {
                String[] splitedDate = date.split("-");
                returnDate = splitedDate[0] + "-" + getMonth(splitedDate[1]) + "-" + splitedDate[2];
            }
        } else if (date.matches(datePatternddmmmyyyyDash)) {

            if (date.contains("-")) {
                String[] splitedDate = date.split("-");
                returnDate = splitedDate[0] + "-" + getMonth(splitedDate[1]) + "-" + splitedDate[2];
            }

        } else if (date.matches(datePatternddmmmyyyySlash)) {

            if (date.contains("/")) {
                String[] splitedDate = date.split("/");
                returnDate = splitedDate[0] + "-" + getMonth(splitedDate[1]) + "-" + splitedDate[2];
            }
        } else if (date.matches(datePatternyyyymmmddSlash) && date.contains("/")) {

            String[] splitedDate = date.split("/");
            returnDate = splitedDate[2] + "-" + getMonth(splitedDate[1]) + "-" + splitedDate[0];
        }

        return returnDate;
    }
    
    static String getMonth(String monthName) {

        String monthNo = "";
        if ("Jan".equals(monthName)) {
            monthNo = "01";
        } else if ("Feb".equals(monthName)) {
            monthNo = "02";
        } else if ("Mar".equals(monthName)) {
            monthNo = "03";
        } else if ("Apr".equals(monthName)) {
            monthNo = "04";
        } else if ("May".equals(monthName)) {
            monthNo = "05";
        } else if ("Jun".equals(monthName)) {
            monthNo = "06";
        } else if ("Jul".equals(monthName)) {
            monthNo = "07";
        } else if ("Aug".equals(monthName)) {
            monthNo = "08";
        } else if ("Sep".equals(monthName)) {
            monthNo = "09";
        } else if ("Oct".equals(monthName)) {
            monthNo = "10";
        } else if ("Nov".equals(monthName)) {
            monthNo = "11";
        } else if ("dec".equals(monthName)) {
            monthNo = "12";
        }
        return monthNo;
    }



}