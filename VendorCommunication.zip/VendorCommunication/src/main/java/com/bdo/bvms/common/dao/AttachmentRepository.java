package com.bdo.bvms.common.dao;

import java.util.List;

import javax.validation.Valid;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bdo.bvms.common.dto.AttachmentListDto;
import com.bdo.bvms.common.dto.AttacmentReqDTO;
import com.bdo.bvms.common.dto.GstinAttachments;
import com.bdo.bvms.common.dto.SearchVendorDetailsReqDTO;
import com.bdo.bvms.common.dto.SystemParameter;
import com.bdo.bvms.common.dto.TaxpayerVendor;
import com.bdo.bvms.common.dto.WorkflowScreenTabChanges;
import com.bdo.bvms.common.dto.WorkflowScreenTabChangesArchived;

public interface AttachmentRepository {

	public List<AttachmentListDto> getAttachmentList(AttacmentReqDTO attacmentReqDTO);

	public Page<GstinAttachments> searchAttachments(Pageable paging,
			@Valid SearchVendorDetailsReqDTO searchVendorDetailsReqDTO);

	public SystemParameter searchSystemParameter(SystemParameter build);

	public TaxpayerVendor searchMasters(TaxpayerVendor build, int pldDataVersionVendor);

	public WorkflowScreenTabChanges checkIfWorkflowScreenTabChangesExists(
			WorkflowScreenTabChanges workflowScreenTabChanges);

	public Integer insertWorkflowScreenTabChanges(WorkflowScreenTabChanges workflowScreenTabChanges, String columnName);

	public Integer archiveWorkflowScreenTabChanges(WorkflowScreenTabChangesArchived build);

	public Integer updateWorkflowScreenTabChanges(WorkflowScreenTabChanges workflowScreenTabChangesExists,
			String columnName);

	public Integer addVendorAttachments(GstinAttachments gstinAttachments);

	}
