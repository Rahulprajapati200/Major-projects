package com.bdo.bvms.common.controller.impl;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.bvms.common.controller.VendorCommunicationUploadLogHistoryController;
import com.bdo.bvms.common.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.common.dto.UploadHistoryResponseDTO;
import com.bdo.bvms.common.dto.UploadLogHistoryResDataDto;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.service.VendorCommunicationUploadLogHistoryService;

@RestController
@RequestMapping("/vendor-communication")

public class VendorCommunicationUploadLogHistoryControllerImpl
                implements VendorCommunicationUploadLogHistoryController {

    @Autowired
    VendorCommunicationUploadLogHistoryService vendorCommunicationUploadLogHistoryService;

    @Override
    @PostMapping(value = "/upload-log-datalist")
    public ResponseEntity<UploadHistoryResponseDTO> logHistory(HttpServletRequest request,
                    @RequestBody UploadHistoryRequestDTO requestDTO) throws VendorInvoiceServerException {
        List<UploadLogHistoryResDataDto> uploadLogHistoryResDataDto = new ArrayList<>();

        // Here we get upload history data in form of list from service layer.

        uploadLogHistoryResDataDto = vendorCommunicationUploadLogHistoryService.getHistoryList(requestDTO);

        return ResponseEntity.ok()
                        .body(UploadHistoryResponseDTO.builder().status(1).messageCode("History data is uploaded.")
                                        .messageDescription(request.getRequestURI()).data(uploadLogHistoryResDataDto)
                                        .build());

    }

}
