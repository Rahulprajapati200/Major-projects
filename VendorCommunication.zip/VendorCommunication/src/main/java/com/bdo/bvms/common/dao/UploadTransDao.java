package com.bdo.bvms.common.dao;

import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.InvoiceDetailsDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNReqDTO;
import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.PaymentResponseBean;
import com.bdo.bvms.common.dto.ResponseBean;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadLogDto;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.dto.UploadStageLogDto;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface UploadTransDao {

    void uploadTxLogDetails(UploadLogDto txUploadLog) throws VendorInvoiceServerException;

    void insertUploadStageLog(UploadStageLogDto uploadStageLogDto);

    int getUploadIdFromDB(String batchNo);

    void updateProcessStatus(String batchNo, String uploadInvoicesPldStatusFail);

    void updateTimeStamp(String updateValidationStartTimeStamp, UploadReqDTO uploadRequestDTO);

    void updateUploadStageNState(String processStageDataValidation, String processFileUploadStatusCompleted,
                    int uploadLogId);

//	void updateErrorNSuccessCountAndTotalCount(ResponseBean responseBean, String batchNo);

    void updateErrorFileName(String batchNo, String string);

    void updateTotalCountAndDocErrorCount(int totalCount, int docErrorCount, UploadReqDTO uploadRequestDTO);

    void updateErrorNSuccessCountAndTotalCount(ResponseBean responseBean,
                    List<com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO> updateErrorNSuccessCountAndTotalCount,
                    String batchNo);

    Map<String, Object> commonPostNotification(int communicationmstid, String string, int userId, int userId2,
                    int userId3, String schemaname, String code);

    int updatePldCode(String customtemplateID);

	void updateProcessStatusWithRemarks(String batchNo, String uploadInvoicesPldStatusFail, String string);

	void updateFpLog(List<String> month, UploadReqDTO uploadRequestDTO);
	
	void insertUploadStageNState(String processStageDataValidation, String processFileUploadStatusStart,
			UploadReqDTO uploadDTO);

	void insertStageNState(String processStageDataValidation, String processFileUploadStatusStart,
			InwardInvoiceCDNReqDTO uploadRequestDTO, String batchNo);

	void vendorCommunicationArchiveInwardUploadData(UploadReqDTO reqDto);

	void updateErrorNSuccessCountAndTotalCount(PaymentResponseBean responseBean,
			List<PaymentDetails> rowDocErrorPojoList, String batchNo);

	void updateTdsErrorNSuccessCountAndTotalCount(PaymentResponseBean responseBean,
			List<TdsDetails> rowDocErrorPojoList, String batchNo);

	void updateItcErrorNSuccessCountAndTotalCount(PaymentResponseBean responseBean, List<ItcDto> rowDocErrorPojoList,
			String batchNo);

	void vendorCommunicationArchiveInwardUploadData(InvoiceDetailsDTO reqDto);

}
