package com.bdo.bvms.common.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class UpadateResponseDto {

	List<PaymentDetails>paymentDetailErrorList=new ArrayList<>();
	List<TdsDetails>tdsDetailErrorList=new ArrayList<>();
	List<InwardInvoiceCDNTemplateDTO>inwardTemplateErrorListDto=new ArrayList<>();
	List<ItcDto>itcErrorList=new ArrayList<>();
	
}
