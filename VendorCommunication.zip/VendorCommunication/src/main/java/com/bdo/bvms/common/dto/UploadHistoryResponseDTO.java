package com.bdo.bvms.common.dto;

import java.util.List;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UploadHistoryResponseDTO {

    Integer status;
    String messageCode;
    String messageDescription;
    List<UploadLogHistoryResDataDto> data;

}
