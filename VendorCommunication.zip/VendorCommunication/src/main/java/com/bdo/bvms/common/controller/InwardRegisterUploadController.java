package com.bdo.bvms.common.controller;

import java.io.IOException;
import java.net.URISyntaxException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.bdo.bvms.common.dto.APIResponseDTO;
import com.bdo.bvms.common.dto.InvoiceDetailsDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNReqDTO;
import com.bdo.bvms.common.exceptions.InvoiceTemplateUploadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.microsoft.azure.storage.StorageException;
import com.monitorjbl.xlsx.exceptions.ParseException;

public interface InwardRegisterUploadController {

    ResponseEntity<APIResponseDTO> uploadFile(HttpServletRequest request,
                    @ModelAttribute InwardInvoiceCDNReqDTO uploadRequestDTO) throws VendorInvoiceServerException,
                    InvoiceTemplateUploadException, URISyntaxException, StorageException, ParseException;

    ResponseEntity<APIResponseDTO> inwardJsonValidationApi(HttpServletRequest request,
                    InvoiceDetailsDTO invoiceDetailDto) throws VendorInvoiceServerException, IOException;

}
