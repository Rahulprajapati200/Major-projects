package com.bdo.bvms.common.repository;

import java.util.List;

import com.bdo.bvms.common.model.PickupListDetail;

public interface IPickupMasterRepository {

    List<PickupListDetail> searchPickupMaster(String lkupcode);

	PickupListDetail searchPickupDetailByNameAndCode(PickupListDetail pickupListDetail);

}
