package com.bdo.bvms.common.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.dao.CustomTemplateRepo;
import com.bdo.bvms.common.sql.CommunicationSQL;

@Repository
public class CustomTemplateRepoImpl implements CustomTemplateRepo {

	@Autowired
	JdbcTemplate jdbcTemplateMst;
	

    @Autowired
    JdbcTemplate jdbcTemplateTrn;
	
    @Value("${mst.database-name}")
    String mstDatabseName;
    
    @Value("${txn.database-name}")
    String tranDb;

	
	@Override
	public Map<String, String> searchCustomTemplateHeaderMappings(int customTemplateId) {
		return jdbcTemplateMst.query(CommunicationSQL.GET_CUSTOM_TEMPLATE_HEADER_MAPPING_SQL,
				new ResultSetExtractor<Map<String, String>>() {

					@Override
					public Map<String, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, String> mapRet = new HashMap<>();
						while (rs.next()) {
							mapRet.put(rs.getString("standardHeader"), rs.getString("customHeader"));
						}
						return mapRet;
					}
				}, customTemplateId);
	}
}
