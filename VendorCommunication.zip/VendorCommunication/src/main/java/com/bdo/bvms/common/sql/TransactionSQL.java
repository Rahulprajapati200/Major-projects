package com.bdo.bvms.common.sql;

public class TransactionSQL {

    TransactionSQL() {

    }

    public static final String GET_ALL_DATA_OF_FAILURE_RECORDS = "select * from ewaybill_upload_err_log where batch_no like '";
    public static final String GET_PERTICULAR_DATA_OF_SUCCESS_RECORDS = "select gstin_uin_of_recipient,doc_type,inward_no,inward_date,gstin_of_supplier,hsn_code,total_invoice_amt,purchase_order_no,purchase_order_date,"
                    + "irn,irn_date,udf_1,udf_2,udf_3,udf_4,udf_5,udf_6,udf_7,udf_8,udf_9,udf_10,row_version,status,error_code from invoice_upload_err_log where batch_no like '";
    public static final String INSERT_FILE_SQL = "LOAD DATA LOCAL INFILE ? INTO TABLE table_name CHARACTER SET latin1 FIELDS TERMINATED BY \',\' ENCLOSED BY \'"
                    + '"' + "\' LINES TERMINATED BY \'\n\' IGNORE 1 LINES;";
    public static final String INSERT_EXCEPTION_LOG = "insert into exception_log(screen_name,function_name,error_message,error_cause,line_no,user_id,created_at,requested_at,requested_by) VALUES (?,?,?,?,?,?,?,?,?)";
	 public static final String COUNT_SEARCH_ATTACHMENTS_SQL = new StringBuilder(
                    "SELECT count(1) FROM gstin_attachments  where  tax_payer_gstin = ? AND vendor_gstin = ? ")
                                    .toString();
	 public static final String GET_SYSTEM_PARAMETER = new StringBuilder(
             "select KeyNAME,KeyVALUE,DESCRIP,otp_validity_duration,user_id from system_parameter where KeyNAME = ?")
                             .toString();
	
    public static final String SEARCH_MASTERS_SQL = new StringBuilder(
                    "Select id,child_relation_id, pld_data_version, company_legal_name,company_trade_name,vendor_code_erp, pan_vendor, \n")
                                    .append("created_at from taxpayer_vendors where gstin_taxpayer=? and gstin_vendor=? AND pld_data_version= ?")
                                    .toString();
	 public static final String CHECK_IF_WORKFLOW_SCREEN_TAB_CHANGES_EXISTS_SQL = new StringBuilder(
                    "select  id, tvcr_id, pld_module_id, master, contact, bank, address, attachments, updated_at, updated_by from workflow_screen_tab_changes\r\n")
                                    .append(" where tvcr_id = ? ").toString();
	
    public static final String INSERT_WORKFLOW_SCREEN_TAB_CHANGES_ARCHIVED_SQL = new StringBuilder(
                    "INSERT INTO workflow_screen_tab_changes_archived \r\n").append(
                                    "(workflow_screen_tab_changes_id, tvcr_id, master, contact, bank, address, attachments, updated_at, updated_by) \r\n")
                                    .append("VALUES ( ?,?,?,?,?,?,?,?,?)").toString();
    public static final String INSERT_VENDOR_ATTACHMENTS_SQL = new StringBuilder(
            "Insert into communication_attachments(communication_reco_ref_id,name, pld_document_type, path, size,  created_by, remarks,pld_module_id)")
                            .append("Values (?,?,?,?,?,?,?,?)").toString();
	public static final String UPDATE_ERROR_REMARKS = "update upload_log set pld_upload_status=?, remarks=? where batch_no=?";



    public static StringBuilder getUploadHistory( int entityId ,String mstDatabaseName) {

        return new StringBuilder("  SELECT taxpayer_pan, fp , ul.created_at , concat(from_base64(first_name) ,from_base64(last_name)) as 'created_by',"
                        + " ld.name as 'template_type', ld1.name as 'pld_upload_status',ul.taxpayer_gstin , file_name , file_type , total_count , success_count ,"
                        + " error_count ,"
                        + "  base_file_location ,upload_source,is_custom_template,fp, error_file_location , batch_no from upload_log  ul "
                        + "left join "+mstDatabaseName+".am_user_master um  on um.user_id=ul.created_by "
                        + "left JOIN "+mstDatabaseName+".sm_pickup_list_details ld on ld.id=ul.pld_template_type  and ld.sm_pick_mst_id=8 "
                        + " left JOIN "+mstDatabaseName+".sm_pickup_list_details ld1 on ld1.code=ul.pld_upload_status and ld1.sm_pick_mst_id=23 "
                        + "left JOIN "+mstDatabaseName+".sm_pickup_list_details ld2 on ld2.code=ul.pld_upload_source and ld2.sm_pick_mst_id=13 "
                        + "where  pld_upload_source=3 and ul.entity_id=" + entityId );
    }

    public static String getSyncPendingList(Integer pageRecords, Integer pageCount, String mstDatabseName,
                    String gstinNewList, String monthList) {
        return " SELECT gstin_uin_of_recipient, gstin_of_supplier, inward_no, inward_date, total_invoice_amt, bill_valid_date,e_way_bill_no,e_way_bill_date,invoice_eway_bill_details.status,"
                        + "inward_no,inward_date,  purchase_order_no,row_version,sm_pickup_list_details.name, company_legal_name,company_trade_name "
                        + "FROM `bvms_trn_local`.invoice_eway_bill_details  join `bvms_trn_local`.taxpayer_vendors on     taxpayer_vendors.gstin_taxpayer=invoice_eway_bill_details.gstin_uin_of_recipient "
                        + "  and taxpayer_vendors.gstin_vendor=invoice_eway_bill_details.gstin_of_supplier " + " join "
                        + mstDatabseName + ".sm_pickup_list_details on " + mstDatabseName
                        + ".sm_pickup_list_details.code= invoice_eway_bill_details.template_type "
                        + " and sm_pick_mst_id=8  where gstin_uin_of_recipient in " + gstinNewList + " "
                        + "and TRIM('\\r' FROM filling_period) in " + monthList + " LIMIT " + " " + pageRecords + " "
                        + "offset" + " " + (pageCount - 1) * pageRecords;

    }

    public static String getSyncTotalCount(String mstDatabseName, String gstinNewList, String monthList) {
        return " SELECT Count(1) "
                        + "FROM `bvms_trn_local`.invoice_eway_bill_details  join `bvms_trn_local`.taxpayer_vendors on     taxpayer_vendors.gstin_taxpayer=invoice_eway_bill_details.gstin_uin_of_recipient "
                        + "  and taxpayer_vendors.gstin_vendor=invoice_eway_bill_details.gstin_of_supplier " + " join "
                        + mstDatabseName + ".sm_pickup_list_details on " + mstDatabseName
                        + ".sm_pickup_list_details.code= invoice_eway_bill_details.template_type "
                        + " and sm_pick_mst_id=8  where gstin_uin_of_recipient in " + gstinNewList + " "
                        + "and TRIM('\\r' FROM filling_period) in " + monthList;

    }

	public static String getAttachmentSql(String mstDatabaseName, String txnDatabaseName,int id) {
		StringBuilder sql=new StringBuilder();
//		sql.append("select pld.name,path,size,att.created_at,pld_module_id from "+txnDatabaseName+".communication_attachments att left join ")
//		.append(mstDatabaseName+".sm_pickup_list_details pld on att.pld_document_type=pld.id where tvcr_id in(select child_relation_id from taxpayer_vendors where \r\n"
//				+ "parent_id=? and and pld_data_version =2)");
		sql.append("select name,path,size,created_at,pld_module_id from "+txnDatabaseName+".communication_attachments where communication_reco_ref_id=? and pld_module_id=?");
		return sql.toString();
	}

	public static String searchAttachmentsSql(String schemaName) {
        return new StringBuilder(
                        "SELECT ga.id, tax_payer_gstin, tvcr_id, vendor_gstin, ga.name, pld_document_type, pld.name as document_type, ")
                                        .append("path, size,  remarks, ga.created_at, ga.created_by, ga.modified_at, ga.modified_by, ")
                                        .append("concat(tvc.first_name,' ',tvc.last_name ) as created_by_name, concat(tvcM.first_name,' ',tvcM.last_name ) as modified_by_name, ")
                                        .append("tvc.email as created_by_email, tvcM.email as modified_by_email ")
                                        .append("FROM gstin_attachments ga ")
                                        .append("INNER JOIN  taxpayer_vendor_contact tvc on tvc.id=ga.created_by ")
                                        .append("INNER JOIN ").append(schemaName)
                                        .append(".sm_pickup_list_details pld ON ga.pld_document_type = pld.code ")
                                        .append("INNER JOIN " + schemaName
                                                        + ".sm_pickup_master pm ON pm.pickup_master_id = pld.sm_pick_mst_id ")
                                        .append("AND pm.name=? AND ga.tax_payer_gstin = ? AND ga.vendor_gstin = ? ")
                                        .append("LEFT JOIN taxpayer_vendor_contact tvcM on tvcM.id=ga.modified_by ")
                                        .append("order by ga.modified_at desc , ga.created_at desc LIMIT ?  OFFSET ? ")
                                        .toString();
    }

	
    public static String insertWorkFlowScreenTabChangesSql(String columnName) {
        return new StringBuilder("INSERT INTO workflow_screen_tab_changes\r\n")
                        .append("( tvcr_id, pld_module_id, ").append(columnName)
                        .append(",updated_at, updated_by) \r\n").append(" VALUES (?,?,?,now(),?)").toString();
    }
    public static String updateWorkflowScreenTabChangesSql(String columnname) {
        return new StringBuilder(" update workflow_screen_tab_changes set ").append(columnname).append(" = ? ")
                        .append(",updated_at=now(),updated_by=? where tvcr_id = ? ").toString();
    }

	public static String getFileUrlSql(String mstDatabaseName) {
		return new StringBuilder(" select KeyVALUE from ").append(mstDatabaseName).append(".system_parameter where KeyNAME='Azure_storage_base_url'").toString();			
	}
	
	 public static String getBlobName(String mstDatabaseName) {
			return new StringBuilder(" select KeyVALUE from ").append(mstDatabaseName).append(".system_parameter where KeyNAME='container name'").toString();			
		}
}
