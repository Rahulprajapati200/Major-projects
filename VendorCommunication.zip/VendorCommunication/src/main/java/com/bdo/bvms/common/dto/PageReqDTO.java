package com.bdo.bvms.common.dto;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PageReqDTO {

    int page;

//    @Value(min = 1, max = 500)
    int size = 5;

}
