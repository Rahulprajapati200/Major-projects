package com.bdo.bvms.common.payment.serviceimpl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.BDOException;
import com.bdo.bvms.common.payment.service.WriteErrorAndSuccessCsv;
import com.bdo.bvms.common.util.CommonUtils;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class WriteErrorAndSuccessCsvImpl implements WriteErrorAndSuccessCsv{

	@Value("${bvms.cloud.temp.file.download.path}")
    String tempFolder;
	
	@Override
	public void writeSuccessNErrorDataInCSVFile(UploadReqDTO uploadReqDTO,
			List<PaymentDetails> errorPaymentDetailsTemplateDTOsList,
			List<PaymentDetails> sucessPaymentDetailsTemplateDTOsList) throws IOException, BDOException {
		


        String methodName = " writeSuccessNErrorDataInCSVFile";
        String csvPaymentSuccessFilePath = CommonUtils.getPaymentSuccessFilePath(uploadReqDTO, tempFolder);
        String csvPaymentErrorFilePath = CommonUtils.getPaymentErrorFilePath(uploadReqDTO, tempFolder);
        InputStream validINVStream = null;

        // Method for CSV writing
        validINVStream = csvPaymentDetailsSuccess(uploadReqDTO, sucessPaymentDetailsTemplateDTOsList);
        Files.copy(validINVStream, Paths.get(csvPaymentSuccessFilePath));

        InputStream validCDNStream = null;
        validCDNStream = csvPaymentDetailsError(uploadReqDTO, errorPaymentDetailsTemplateDTOsList);
        Files.copy(validCDNStream, Paths.get(csvPaymentErrorFilePath));

       
        log.info(Constants.LOGMESSAGE, methodName);
    

	}

	private InputStream csvPaymentDetailsSuccess(UploadReqDTO uploadReqDTO,
			List<PaymentDetails> successPaymentDetailsTemplateDTOsList) throws BDOException {

        log.info("Entering einvoiceExcelDataToCSV method");

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<String> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {

            list = Stream.of(Constants.ID,Constants.INWARD_SUMMARY_HDRID ,Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT,Constants.COLUMN_DOC_TYPE, Constants.COLUMN_GSTIN_OF_SUPPLIER
            		,Constants.COLUMN_SUPPLIER_NAME,Constants.COLUMN_INWARD_NO,Constants.COLUMN_INWARD_DATE, 
            		Constants.DATE_OF_PAYMENT,Constants.INVOICE_AGAINST_PROV_ADV,Constants.INWARD_NO_PROV_ADV,Constants.PAYMENT_AMOUNT,
            		Constants.PAYMENT_REF_NO,Constants.PAYMENT_FP,Constants.REFERECE_ID,Constants.UUID,Constants.BATCH_NO, Constants.ROWVERSION,
            		Constants.CREATED_AT,Constants.CREATED_BY,Constants.UPDATED_AT,
            		        Constants.COLUMN_UDF_1,
                            Constants.COLUMN_UDF_2, Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4,
                            Constants.COLUMN_UDF_5, Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7,
                            Constants.COLUMN_UDF_8, Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10,
                            Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13,
                            Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16,
                            Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19,

                            Constants.COLUMN_UDF_20
                           ).collect(Collectors.toList());
            csvPrinter.printRecord(list);
            
            if (!successPaymentDetailsTemplateDTOsList.isEmpty()) {
                
                for (PaymentDetails paymentTemplateDto : successPaymentDetailsTemplateDTOsList) {
                	List<Object> data = Arrays.asList(Constants.BLANK,Constants.BLANK ,paymentTemplateDto.getGstinUinOfRecipient(),
                                    paymentTemplateDto.getDocType(), paymentTemplateDto.getGstinOfSupplier(),
                                    paymentTemplateDto.getSupplierName(), paymentTemplateDto.getInwardNo(),
                                    paymentTemplateDto.getInwardDate(), paymentTemplateDto.getDateOfPayment(),
                                    paymentTemplateDto.getInvAgainstProv(),paymentTemplateDto.getInwardNoProvAdv(),paymentTemplateDto.getAmountofPayment(),
                                    paymentTemplateDto.getPaymentRefNo(),paymentTemplateDto.getFilingPeriod(),Constants.BLANK,(paymentTemplateDto.getGstinUinOfRecipient()+paymentTemplateDto.getGstinOfSupplier()+paymentTemplateDto.getInwardNo()).hashCode(),uploadReqDTO.getBatchNo(),
                                    Timestamp.from(Instant.now()),Timestamp.from(Instant.now()),uploadReqDTO.getUserId(),Timestamp.from(Instant.now()),
                                    paymentTemplateDto.getUdf1(),
                                    paymentTemplateDto.getUdf2(), paymentTemplateDto.getUdf3(),
                                    paymentTemplateDto.getUdf4(), paymentTemplateDto.getUdf5(),
                                    paymentTemplateDto.getUdf6(), paymentTemplateDto.getUdf7(),
                                    paymentTemplateDto.getUdf8(), paymentTemplateDto.getUdf9(),
                                    paymentTemplateDto.getUdf10(),
                                    paymentTemplateDto.getUdf11(), paymentTemplateDto.getUdf12(), paymentTemplateDto.getUdf13(),
                                    paymentTemplateDto.getUdf14(), paymentTemplateDto.getUdf15(), paymentTemplateDto.getUdf16(), paymentTemplateDto.getUdf17(),
                                    paymentTemplateDto.getUdf18(), paymentTemplateDto.getUdf19(), paymentTemplateDto.getUdf20()
                                    );
                    csvPrinter.printRecord(data);
                    log.info("Size of CVS is " + data.size());
                }
            }
        	csvPrinter.flush();
            log.info("Got the finalCSV File");
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error("fail to import data to CSV file" + e);
            throw new BDOException("fail to import data to CSV file: " + e.getMessage());
        }
    }

	private InputStream csvPaymentDetailsError(UploadReqDTO uploadReqDTO,
			List<PaymentDetails> errorPaymentDetailsTemplateDTOsList) throws BDOException {

        log.info("Entering einvoiceExcelDataToCSV method");

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<String> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {

            list = Stream.of(Constants.ID,Constants.INWARD_SUMMARY_HDRID, Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT,Constants.COLUMN_DOC_TYPE, Constants.COLUMN_GSTIN_OF_SUPPLIER
            		,Constants.COLUMN_SUPPLIER_NAME,Constants.COLUMN_INWARD_NO,Constants.COLUMN_INWARD_DATE, 
            		Constants.DATE_OF_PAYMENT,Constants.INVOICE_AGAINST_PROV_ADV,Constants.INWARD_NO_PROV_ADV,Constants.PAYMENT_AMOUNT,
            		Constants.PAYMENT_REF_NO,Constants.PAYMENT_FP,Constants.REFERECE_ID,Constants.ERROR_CODES,Constants.ERROR_DESCRIPTION,
            		Constants.UUID,Constants.BATCH_NO,Constants.ROWVERSION,Constants.CREATED_AT,Constants.CREATED_BY,
            		Constants.UPDATED_AT,Constants.UPDATED_BY,Constants.REMARKS, Constants.COLUMN_UDF_1,
                            Constants.COLUMN_UDF_2, Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4,
                            Constants.COLUMN_UDF_5, Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7,
                            Constants.COLUMN_UDF_8, Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10,
                            Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13,
                            Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16,
                            Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19,

                            Constants.COLUMN_UDF_20
                            ).collect(Collectors.toList());
            csvPrinter.printRecord(list);
            
            if (!errorPaymentDetailsTemplateDTOsList.isEmpty()) {
                
                for (PaymentDetails paymentTemplateDto : errorPaymentDetailsTemplateDTOsList) {
                	List<Object> data = Arrays.asList(Constants.BLANK,Constants.BLANK ,paymentTemplateDto.getGstinUinOfRecipient(),
                                    paymentTemplateDto.getDocType(), paymentTemplateDto.getGstinOfSupplier(),
                                    paymentTemplateDto.getSupplierName(), paymentTemplateDto.getInwardNo(),
                                    paymentTemplateDto.getInwardDate(), paymentTemplateDto.getDateOfPayment(),
                                    paymentTemplateDto.getInvAgainstProv(),paymentTemplateDto.getInwardNoProvAdv(),paymentTemplateDto.getOrgAmountofPayment(),
                                    paymentTemplateDto.getPaymentRefNo(),paymentTemplateDto.getFilingPeriod(),Constants.BLANK,
                                    paymentTemplateDto.getErrorCodeList(),paymentTemplateDto.getErrorDescriptionList(),(paymentTemplateDto.getGstinUinOfRecipient()+paymentTemplateDto.getGstinOfSupplier()+paymentTemplateDto.getInwardNo()).hashCode(),uploadReqDTO.getBatchNo(),
                                    Timestamp.from(Instant.now()),Timestamp.from(Instant.now()),uploadReqDTO.getUserId(),Timestamp.from(Instant.now()),
                                    uploadReqDTO.getUserId(),Constants.BLANK,
                                    paymentTemplateDto.getUdf1(),
                                    paymentTemplateDto.getUdf2(), paymentTemplateDto.getUdf3(),
                                    paymentTemplateDto.getUdf4(), paymentTemplateDto.getUdf5(),
                                    paymentTemplateDto.getUdf6(), paymentTemplateDto.getUdf7(),
                                    paymentTemplateDto.getUdf8(), paymentTemplateDto.getUdf9(),
                                    paymentTemplateDto.getUdf10(),
                                    paymentTemplateDto.getUdf11(), paymentTemplateDto.getUdf12(), paymentTemplateDto.getUdf13(),
                                    paymentTemplateDto.getUdf14(), paymentTemplateDto.getUdf15(), paymentTemplateDto.getUdf16(), paymentTemplateDto.getUdf17(),
                                    paymentTemplateDto.getUdf18(), paymentTemplateDto.getUdf19(), paymentTemplateDto.getUdf20()
                                    );
                    csvPrinter.printRecord(data);
                    log.info("Size of CVS is " + data.size());
                }
            }
        	csvPrinter.flush();
            log.info("Got the finalCSV File");
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error("fail to import data to CSV file" + e);
            throw new BDOException("fail to import data to CSV file: " + e.getMessage());
        }
    }

	@Override
	public void writeAzureErrorDataInCSVFile(List<PaymentDetails> errorDataListWithErrorCode,
			UploadReqDTO uploadReqDTO, Map<String, String> codesMap) throws IOException, BDOException {
        String csvInvCdnErrorFilePath = CommonUtils.getAzurePaymentErrorFilePath(uploadReqDTO, tempFolder);
        InputStream errorCrnInvStream = null;

        String methodName = "";

        errorCrnInvStream = excelAzureDataToCSVCdnInvErrorFor(errorDataListWithErrorCode, codesMap);

        Files.copy(errorCrnInvStream, Paths.get(csvInvCdnErrorFilePath));
        log.info(Constants.LOGERRORMESSAGE, methodName);

    }

	private InputStream excelAzureDataToCSVCdnInvErrorFor(List<PaymentDetails> errorDataListWithErrorCode,
			Map<String, String> codesMap) throws BDOException {

        log.info("Entering einvoiceExcelDataToCSV method");

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<String> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {

            list = Stream.of(Constants.ERROR_CODES,Constants.ERROR_DESCRIPTION, Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT,Constants.COLUMN_DOC_TYPE, Constants.COLUMN_GSTIN_OF_SUPPLIER
            		,Constants.COLUMN_SUPPLIER_NAME,Constants.COLUMN_INWARD_NO,Constants.COLUMN_INWARD_DATE, 
            		Constants.DATE_OF_PAYMENT,Constants.INVOICE_AGAINST_PROV_ADV,Constants.INWARD_NO_PROV_ADV,Constants.PAYMENT_AMOUNT,
            		Constants.PAYMENT_REF_NO,Constants.FILLING_PERIOD,
            		 Constants.COLUMN_UDF_1,
                            Constants.COLUMN_UDF_2, Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4,
                            Constants.COLUMN_UDF_5, Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7,
                            Constants.COLUMN_UDF_8, Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10,
                            Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13,
                            Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16,
                            Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19,

                            Constants.COLUMN_UDF_20).collect(Collectors.toList());
            csvPrinter.printRecord(list);
            
            if (!errorDataListWithErrorCode.isEmpty()) {
                
                for (PaymentDetails paymentTemplateDto : errorDataListWithErrorCode) {
                	List<Object> data = Arrays.asList(paymentTemplateDto.getErrorCodeList(),getErrorCodeDescription(paymentTemplateDto.getErrorCodeList().toString(),codesMap),
                			paymentTemplateDto.getGstinUinOfRecipient(),
                                    paymentTemplateDto.getDocType(), paymentTemplateDto.getGstinOfSupplier(),
                                    paymentTemplateDto.getSupplierName(), paymentTemplateDto.getInwardNo(),
                                    paymentTemplateDto.getInwardDate(), paymentTemplateDto.getDateOfPayment(),
                                    paymentTemplateDto.getInvAgainstProv(),paymentTemplateDto.getInwardNoProvAdv(),paymentTemplateDto.getAmountofPayment(),
                                    paymentTemplateDto.getPaymentRefNo(),paymentTemplateDto.getFilingPeriod(),
                                    paymentTemplateDto.getUdf1(),
                                    paymentTemplateDto.getUdf2(), paymentTemplateDto.getUdf3(),
                                    paymentTemplateDto.getUdf4(), paymentTemplateDto.getUdf5(),
                                    paymentTemplateDto.getUdf6(), paymentTemplateDto.getUdf7(),
                                    paymentTemplateDto.getUdf8(), paymentTemplateDto.getUdf9(),
                                    paymentTemplateDto.getUdf10(),
                                    paymentTemplateDto.getUdf11(), paymentTemplateDto.getUdf12(), paymentTemplateDto.getUdf13(),
                                    paymentTemplateDto.getUdf14(), paymentTemplateDto.getUdf15(), paymentTemplateDto.getUdf16(), paymentTemplateDto.getUdf17(),
                                    paymentTemplateDto.getUdf18(), paymentTemplateDto.getUdf19(), paymentTemplateDto.getUdf20());
                    csvPrinter.printRecord(data);
                    log.info("Size of CVS is " + data.size());
                }
            }
        	csvPrinter.flush();
            log.info("Got the finalCSV File");
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error("fail to import data to CSV file" + e);
            throw new BDOException("fail to import data to CSV file: " + e.getMessage());
        }
    }
	
	 String getErrorCodeDescription(String codes, Map<String, String> errorCodeMap) {

	        StringBuilder strBuilder = new StringBuilder();
	        String code = codes.replace("|", ",");
	        String[] errorCodeList = code.split(",");

	        if (errorCodeList.length > 1) {
	            for (int i = 1; i < errorCodeList.length; i++) {
	                String description = errorCodeMap.get(errorCodeList[i].trim());
	                strBuilder.append("|" + description);

	            }
	        }
	        return strBuilder.toString();
	    }

}
