package com.bdo.bvms.common.payment.serviceimpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.CommonDao;
import com.bdo.bvms.common.dao.CustomTemplateRepo;
import com.bdo.bvms.common.dao.InwardRegisterDao;
import com.bdo.bvms.common.dao.UploadTransDao;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.PaymentResponseBean;
import com.bdo.bvms.common.dto.ResponseBean;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvalidTemplateHeaderException;
import com.bdo.bvms.common.payment.dao.PaymentDao;
import com.bdo.bvms.common.payment.service.PaymentDetailValidation;
import com.bdo.bvms.common.payment.service.PaymentDetailsUpload;
import com.bdo.bvms.common.payment.service.ReadCustomPaymentDetailTemplate;
import com.bdo.bvms.common.service.InwardUpload;
import com.bdo.bvms.common.sql.CommunicationSQL;
import com.bdo.bvms.common.util.CommonUtils;
import com.bdo.bvms.common.payment.service.ReadDefaultExcelAndCSV;
import com.bdo.bvms.common.payment.service.UploadNDownloadPaymentAzureFile;
import com.bdo.bvms.common.payment.service.WriteErrorAndSuccessCsv;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class PaymentDetailsUploadImpl implements PaymentDetailsUpload{

	@Value("${bvms.cloud.temp.file.download.path}")
	String tempFolder;
	
	Set<String>sftpSet =new HashSet<>();
	
	@Value("${mst.database-name}")
    private String mstDatabseName;
	
	Map<String,String> yearIdMap=new HashMap<>();
	
	@Autowired
	InwardRegisterDao commonCommunicationDao;
	
	@Autowired
    UploadTransDao uploadTransDao;
	
	@Autowired
	InwardUpload inwardUpload;
	
	@Autowired
	ReadDefaultExcelAndCSV readDefaultExcelAndCSV;
	
	@Autowired
	ReadCustomPaymentDetailTemplate readCustomPaymentDetailTemplate;
	
	@Autowired
	PaymentDetailValidation paymentDetailValidation;
	
	@Autowired
	WriteErrorAndSuccessCsv writeErrorAndSuccessCsv;
	
	@Autowired
	PaymentDao paymentDao;
	
	 @Autowired
	 CommonDao commonDao;
	 @Autowired
	 UploadNDownloadPaymentAzureFile uploadNDownloadPaymentAzureFile;
	 @Autowired
	 CustomTemplateRepo customeTemplateRepo;

	@Async
	@Override
	public String validateAndSavePaymentDetails(UploadReqDTO uploadReqDTO,
			AzureConnectionCredentialsDTO storageCredentials) {

		List<PaymentDetails>paymentDetailsTemplateDTOList=new ArrayList<>();
		List<PaymentDetails>errorPaymentDetailsTemplateDTOsList=new ArrayList<>();
		List<PaymentDetails>sucessPaymentDetailsTemplateDTOsList=new ArrayList<>();
		List<PaymentDetails>rowDocErrorPojoList=new ArrayList<>();
        

     
        try {
        	uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_PROCESSING,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadReqDTO);
            // Add entry in the process steps
            uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_INPROGRESS);

            // Add notification
            addInNotification(uploadReqDTO);
            yearIdMap = commonCommunicationDao.getYearId();
            if (Constants.XLSX.equalsIgnoreCase(uploadReqDTO.getFileType())) {
                if (Constants.ISDEFAULTTEMPLATE.equals(uploadReqDTO.getIsCustomTemplate())) {
                	readDefaultExcelAndCSV.readDataFromExcel(uploadReqDTO, paymentDetailsTemplateDTOList,rowDocErrorPojoList);
                } else if (Constants.ISCUSTOMETEMPLATE.equals(uploadReqDTO.getIsCustomTemplate())) {
                	readCustomPaymentDetailTemplate.readCustomTemplate(uploadReqDTO,paymentDetailsTemplateDTOList);
                }
            } else if (Constants.CSV.equalsIgnoreCase(uploadReqDTO.getFileType())) {

            	if (uploadReqDTO.getIsCustomTemplate().equals(Constants.ISDEFAULTTEMPLATE)) {

                	readDefaultExcelAndCSV.readCSVFile(uploadReqDTO, paymentDetailsTemplateDTOList);
                
                }else if (uploadReqDTO.getIsCustomTemplate().equals(Constants.ISCUSTOMETEMPLATE)) {
                    Map<String, String> customTemplateHeaderMappings = CommonUtils
                            .getCustomTemplateHeaderMappings(uploadReqDTO, customeTemplateRepo);
                    readCustomPaymentDetailTemplate.getInwardDataListCDV(uploadReqDTO,
                            customTemplateHeaderMappings, Constants.DELIMITER,paymentDetailsTemplateDTOList);
               }
               
            } else {
                return Constants.FILEFORMATNOTALLOWED;
            }
            
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_PROCESSING,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadReqDTO);
            
            
            
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_VALIDATION,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadReqDTO);
            
            uploadTransDao.updateTotalCountAndDocErrorCount(
                    paymentDetailsTemplateDTOList.size() + rowDocErrorPojoList.size(),
                    rowDocErrorPojoList.size(), uploadReqDTO);

             paymentDetailValidation.validatePaymentDetails(paymentDetailsTemplateDTOList, uploadReqDTO,errorPaymentDetailsTemplateDTOsList,sucessPaymentDetailsTemplateDTOsList,yearIdMap);
             
            
             
            
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_VALIDATION,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadReqDTO);
            
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_COMPLETED,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadReqDTO);
            
            writeErrorAndSuccessCsv.writeSuccessNErrorDataInCSVFile(uploadReqDTO, errorPaymentDetailsTemplateDTOsList, sucessPaymentDetailsTemplateDTOsList);
            
            String csvPaymentSuccessFilePath = CommonUtils.getPaymentSuccessFilePath(uploadReqDTO, tempFolder);
            String csvPaymentErrorFilePath = CommonUtils.getPaymentErrorFilePath(uploadReqDTO, tempFolder);
            
            PaymentResponseBean responseBean = paymentDao.gstInwardInvCdnInsert(csvPaymentSuccessFilePath, csvPaymentErrorFilePath,
                    Constants.SUCCESS_PAYMENT_TABLE,
                    Constants.FAILURE_PAYMENT_TABLE);
            
            uploadTransDao.updateErrorNSuccessCountAndTotalCount(responseBean, rowDocErrorPojoList,
            		uploadReqDTO.getBatchNo());

            Map<String, String> codesMap = commonDao.getErrorCodesDescription();

            List<PaymentDetails> errorDataListWithErrorCode = paymentDao
                            .getPaymentErrorDataListWithErrorCode(uploadReqDTO);
            
            if (!errorPaymentDetailsTemplateDTOsList.isEmpty()) {
            	writeErrorAndSuccessCsv.writeAzureErrorDataInCSVFile(errorDataListWithErrorCode, uploadReqDTO, codesMap);
                uploadNDownloadPaymentAzureFile.uploadErrorFile(uploadReqDTO, storageCredentials);
            }
            
            uploadTransDao.updateUploadStageNState(Constants.PROCESS_STAGE_COMPLETED,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadReqDTO.getUploadLogId());
            
            String csvInvCdnErrorFilePath = CommonUtils.getAzurePaymentErrorFilePath(uploadReqDTO, tempFolder);
            File file = new File(csvInvCdnErrorFilePath);
            if (file.exists() && responseBean.getErrorCount() > 0) {
                uploadTransDao.updateErrorFileName(uploadReqDTO.getBatchNo(),
                		uploadReqDTO.getBatchNo() + Constants.ERROR_DOT_CSV_AZURE_PAYMENT);
            }
            
            if (responseBean != null && responseBean.getErrorCount() > 0) {
                uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_ERROR);
                uploadTransDao.commonPostNotification(Constants.COMMUNICATIONMSTID,
                                Constants.INWARD_FILE_UPLOAD_ERROR + uploadReqDTO.getBatchNo(), uploadReqDTO.getUserId(),
                                uploadReqDTO.getUserId(), uploadReqDTO.getUserId(), mstDatabseName, Constants.NOTIFICATION_ERROR);

            } else {
                uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_COMPLETED);
                if (responseBean != null) {
                    uploadTransDao.commonPostNotification(Constants.COMMUNICATIONMSTID,
                                    Constants.INWARDFILEUPLOADED + uploadReqDTO.getBatchNo(), uploadReqDTO.getUserId(),
                                    uploadReqDTO.getUserId(), uploadReqDTO.getUserId(), mstDatabseName,
                                    Constants.NOTIFICATION_SUCCESS);
                }
            }
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_COMPLETED,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadReqDTO);
       
            
            
            uploadTransDao.updateTimeStamp(CommunicationSQL.UPDATE_VALIDATION_FINAL_TIME_STAMP, uploadReqDTO);
        } catch (InvalidTemplateHeaderException ex) {

        	uploadTransDao.updateTimeStamp(CommunicationSQL.UPDATE_VALIDATION_FINAL_TIME_STAMP, uploadReqDTO);
            uploadTransDao.updateProcessStatusWithRemarks(uploadReqDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE, ex.getMessage());
        }        
        catch (Exception ex) {
            log.error(Constants.PROCESSINGFILEEXCEPTIONLOG + uploadReqDTO.getBatchNo(), ex);
            uploadTransDao.updateTimeStamp(CommunicationSQL.UPDATE_VALIDATION_FINAL_TIME_STAMP, uploadReqDTO);
            log.error("Error generated in methodName", ex);
            uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            uploadTransDao.updateErrorNSuccessCountAndTotalCount(new ResponseBean(0, 0, 0), new ArrayList<>(),
            		uploadReqDTO.getBatchNo());
            //logIntoToExceptionTable(uploadReqDTO, ex, methodName);
        }
        finally {
        	CommonUtils.deleteTempPaymentFiles(tempFolder, uploadReqDTO);
		}
        return Constants.FILEUPLOADEDSUCCESSFUL;
    
	}
	
	@Override
    public void addInNotification(UploadReqDTO uploadRequestDTO) {
        try {
            uploadTransDao.commonPostNotification(Constants.COMMUNICATIONMSTID,
                            Constants.INWARD_FILE_IN_PROGRESS + uploadRequestDTO.getBatchNo(),
                            uploadRequestDTO.getUserId(), uploadRequestDTO.getUserId(), uploadRequestDTO.getUserId(),
                            mstDatabseName, Constants.NOTIFICATION_INITIATED);
        } catch (Exception e) {
            log.error("Error generated while posting notification::", e);
        }
    }

}
