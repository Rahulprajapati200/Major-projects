package com.bdo.bvms.common.dto;

import java.io.Serializable;

/**
 * FileType: java Author : BDO<MUM1611> Created On : 29/04/2020 4:48:39 PM Copy
 * Rights : BDO India LLP.
 */

public class HsnCode implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer hsnId;
    private String headingCode;
    private String hsnCode1;
    private String hsnDescription;

    public HsnCode() {
        //
    }

    public HsnCode(Integer hsnId, String headingCode, String hsnCode, String hsnDescription) {
        this.hsnId = hsnId;
        this.headingCode = headingCode;
        this.hsnCode1 = hsnCode;
        this.hsnDescription = hsnDescription;
    }

    public Integer getHsnId() {
        return hsnId;
    }

    public void setHsnId(Integer hsnId) {
        this.hsnId = hsnId;
    }

    public String getHeadingCode() {
        return headingCode;
    }

    public void setHeadingCode(String headingCode) {
        this.headingCode = headingCode;
    }

    public String getHsnCode() {
        return hsnCode1;
    }

    public void setHsnCode(String hsnCode) {
        this.hsnCode1 = hsnCode;
    }

    public String getHsnDescription() {
        return hsnDescription;
    }

    public void setHsnDescription(String hsnDescription) {
        this.hsnDescription = hsnDescription;
    }

    @Override
    public String toString() {
        return "HsnCode [hsnId=" + hsnId + ", headingCode=" + headingCode + ", hsnCode=" + hsnCode1
                        + ", hsnDescription=" + hsnDescription + "]";
    }
}
