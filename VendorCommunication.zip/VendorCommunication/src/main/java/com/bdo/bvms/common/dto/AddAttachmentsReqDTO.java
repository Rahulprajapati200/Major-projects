package com.bdo.bvms.common.dto;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.common.constant.TaxpayerValidationConstant;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AddAttachmentsReqDTO extends TaxpayerBaseReqDTO {

    List<Integer> communicationRefId;

    @NotNull(message = "document type can not be null")
    int documentType;

    @Size(min = TaxpayerValidationConstant.REMARKS_MIN_SIZE, max = TaxpayerValidationConstant.REMARKS_MAX_SIZE, message = "Request param remarks size must be between "
                    + TaxpayerValidationConstant.REMARKS_MIN_SIZE + " and "
                    + TaxpayerValidationConstant.REMARKS_MAX_SIZE)
    String remarks;

    MultipartFile[] files;

    String moduleId;

}
