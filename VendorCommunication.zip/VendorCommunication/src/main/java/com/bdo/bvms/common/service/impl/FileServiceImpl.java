package com.bdo.bvms.common.service.impl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.exceptions.VendorMasterBusinessException;
import com.bdo.bvms.common.service.IFileService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Component
public class FileServiceImpl implements IFileService {

    @Override
    public String saveFileInLocalStorage(MultipartFile mulFile, String fileName)  {
        final String methodName = "";
        log.info(Constants.LOGMESSAGE,methodName);
        try {
            byte[] bytes = mulFile.getBytes();
            try (FileOutputStream fileOutputStream = new FileOutputStream(fileName)) {
                try (BufferedOutputStream stream = new BufferedOutputStream(fileOutputStream)) {
                    stream.write(bytes);
                }
            }
            return fileName;
        }catch(Exception e) {
        	log.error(Constants.LOGMESSAGE,methodName);
        	throw new VendorMasterBusinessException("Error while saving file to local storage", e);
        }
        
    }

    @Override
    public String generateFileAbsolutePath(String originalFileName) {
        String[] arr = originalFileName.split("\\.");
        return arr[0] + "-" + System.currentTimeMillis() + "." + arr[1];
    }

    @Override
    public File createFileWithURL(String fileUrl, String fileName)  {
        File file = null;
        final String methodName = "";
        log.info(Constants.LOGMESSAGE,methodName);
        try {
            URL url = new URL(fileUrl);
            file = new File(generateFileAbsolutePath(fileName));
            try (FileOutputStream fos = (new FileOutputStream(file))) {
                fos.write(IOUtils.toByteArray(url.openStream()));
            }
        } catch (Exception e) {
        	log.error(Constants.LOGERRORMESSAGE,methodName);
            throw new VendorMasterBusinessException("Error while creating file "+ fileName +" from url " + fileUrl , e);
        } 
        return file;
    }

    

}
