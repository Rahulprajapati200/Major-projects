package com.bdo.bvms.common.dao;


import java.util.Map;

import com.bdo.bvms.common.dto.ExceptionLogDTO;

public interface CommonDao {

    void updateExceptionLogTable(ExceptionLogDTO exceptionLogDTO);
    
    public Map<String, String> getErrorCodesDescription() ;

}
