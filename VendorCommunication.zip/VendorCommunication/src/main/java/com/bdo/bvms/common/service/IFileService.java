package com.bdo.bvms.common.service;

import java.io.File;

import org.springframework.web.multipart.MultipartFile;

public interface IFileService {

    String saveFileInLocalStorage(MultipartFile mulFile, String fileName);

    File createFileWithURL(String fileUrl, String fileName) ;

    String generateFileAbsolutePath(String originalFileName);

}
