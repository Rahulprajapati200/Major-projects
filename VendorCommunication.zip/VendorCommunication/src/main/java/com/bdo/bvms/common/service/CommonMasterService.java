package com.bdo.bvms.common.service;

import java.io.ByteArrayInputStream;
import java.util.List;

import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.DownloadFileBytestreamDto;
import com.bdo.bvms.common.dto.FinancialYearReqDTO;
import com.bdo.bvms.common.dto.GetDefaultUploadTemplateReqDTO;
import com.bdo.bvms.common.dto.GetDefaultUploadTemplateResDTO;
import com.bdo.bvms.common.dto.GetFpByYearIdReqDTO;
import com.bdo.bvms.common.dto.GetFpByYearIdResDTO;
import com.bdo.bvms.common.dto.PaginationSearchResponseDTO;
import com.bdo.bvms.common.dto.PickupDetailListResDTO;
import com.bdo.bvms.common.dto.PickupListDetailReqDTO;
import com.bdo.bvms.common.dto.SearchByLkupcodeReqDTO;
import com.bdo.bvms.common.exceptions.BVMSException;

public interface CommonMasterService {

    PaginationSearchResponseDTO getFpMonths(FinancialYearReqDTO financialYearReqDTO) throws BVMSException;

    PaginationSearchResponseDTO getFpYear(FinancialYearReqDTO financialYearReqDTO) throws BVMSException;

    ByteArrayInputStream downloadFileByteStream(DownloadFileBytestreamDto downloadFileBytestreamDto,
                    AzureConnectionCredentialsDTO azureConnectionCredentialsDTO) throws BVMSException;

    List<PickupDetailListResDTO> searchPickupListDetail(SearchByLkupcodeReqDTO searchByLkupcode);

    AzureConnectionCredentialsDTO getAzureCredentialFromDB(int entityId, String type);

    List<GetDefaultUploadTemplateResDTO> getDefaultUploadTemplate(
                    GetDefaultUploadTemplateReqDTO getDefaultUploadTemplateReqDTO);

    String getFileName(DownloadFileBytestreamDto downloadFileBytestreamDto) throws BVMSException;

    PickupDetailListResDTO searchPickupListDetailByNameAndCode(PickupListDetailReqDTO pickupListDetailReqDTO);

    List<GetFpByYearIdResDTO> getFpByYearId(GetFpByYearIdReqDTO getFpByYearIdReqDTO);

}
