package com.bdo.bvms.common.itc.validation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.validationrule.InwardDroolUtil;

public class ValidateItcDetails {

	public void validateItcDto(ItcDto rowData) {

		 
		InwardDroolUtil ruleMethods = new InwardDroolUtil();

        validGSTINTaxpayer(rowData, ruleMethods);

        validateSupplyType(rowData,ruleMethods);
        
        validateDocType(rowData);
        
        validateDocNo(rowData,ruleMethods);
        
        validateDocDate(rowData,ruleMethods);
        
        validateOrgInvoiceNo(rowData,ruleMethods);
        
        validateOrgInvoiceDateDate(rowData,ruleMethods);
        
        validGstinCheck(rowData, ruleMethods);
        
        
        validateInvoiceNo(rowData,ruleMethods);
        
        validateInvoiceDate(rowData,ruleMethods);
        
        validateInputType(rowData);
        
        inwardNo16Length(rowData, ruleMethods);
       
        isValidInvoiceDateFutureCheck(rowData, ruleMethods);

        checkForTaxPayerGstinEqualsSupplierGstin(rowData);
        
        validItcInelegibalIndicator(rowData,ruleMethods);
        
        checkIndicatorWithoutPercentage(rowData,ruleMethods);
        
        checkPercentageWithoutIndicator(rowData,ruleMethods);
        
        validateCreditGlId(rowData);
        
        validateCreditGlName(rowData);
        
        validateDebitGlId(rowData);
        
        validateDebitGlName(rowData);
        
        itcIneligibleCheck(rowData,ruleMethods);
        
        checkUdf10Length(rowData,ruleMethods);
        checkUdf9Length(rowData,ruleMethods);
        checkUdf8Length(rowData,ruleMethods);
        checkUdf7Length(rowData,ruleMethods);
        checkUdf6Length(rowData,ruleMethods);
        checkUdf5Length(rowData,ruleMethods);
        checkUdf4Length(rowData,ruleMethods);
        checkUdf3Length(rowData,ruleMethods);
        checkUdf2Length(rowData,ruleMethods);
        checkUdf1Length(rowData,ruleMethods);
        
        checkUdf1xAlphaNumeric(rowData,ruleMethods);
        checkUdf2AlphaNumeric(rowData,ruleMethods);
        checkUdf3AlphaNumeric(rowData,ruleMethods);
        checkUdf4AlphaNumeric(rowData,ruleMethods);
        checkUdf5AlphaNumeric(rowData,ruleMethods);
        checkUdf6AlphaNumeric(rowData,ruleMethods);
        checkUdf7AlphaNumeric(rowData,ruleMethods);
        checkUdf8AlphaNumeric(rowData,ruleMethods);
        checkUdf9AlphaNumeric(rowData,ruleMethods);
        checkUdf10AlphaNumeric(rowData,ruleMethods);
        
        checkUdf11Length(rowData,ruleMethods);
        checkUdf12Length(rowData,ruleMethods);
        checkUdf13Length(rowData,ruleMethods);
        checkUdf14Length(rowData,ruleMethods);
        checkUdf15Length(rowData,ruleMethods);
        checkUdf16Length(rowData,ruleMethods);
        checkUdf17Length(rowData,ruleMethods);
        checkUdf18Length(rowData,ruleMethods);
        checkUdf19Length(rowData,ruleMethods);
        checkUdf20Length(rowData,ruleMethods);
        
        checkUdf11AlphaNumeric(rowData,ruleMethods);
        checkUdf12AlphaNumeric(rowData,ruleMethods);
        checkUdf13AlphaNumeric(rowData,ruleMethods);
        checkUdf14AlphaNumeric(rowData,ruleMethods);
        checkUdf15AlphaNumeric(rowData,ruleMethods);
        checkUdf16AlphaNumeric(rowData,ruleMethods);
        checkUdf17AlphaNumeric(rowData,ruleMethods);
        checkUdf18AlphaNumeric(rowData,ruleMethods);
        checkUdf19AlphaNumeric(rowData,ruleMethods);
        checkUdf20AlphaNumeric(rowData,ruleMethods);
	}
	
	private void itcIneligibleCheck(ItcDto rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkItcPercentage(rowdata.getReversalPercentage())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50114, "");
		}
	}
	
	 private void validateDebitGlName(ItcDto rowdata) {
		 if(StringUtils.isNotBlank(rowdata.getDebitGlName()) && rowdata.getDebitGlName().length()>45)
			{
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00578, "");
			}
		
	}

	private void validateDebitGlId(ItcDto rowdata) {
		if(StringUtils.isNotBlank(rowdata.getDebitGlId()) && rowdata.getDebitGlId().length()>45)
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00577, "");
		}
		
	}

	private void validateCreditGlName(ItcDto rowdata) {
		if(StringUtils.isNotBlank(rowdata.getCreditGlName()) && rowdata.getCreditGlName().length()>45)
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00576, "");
		}
		
	}

	private void validateCreditGlId(ItcDto rowdata) {
		if(StringUtils.isNotBlank(rowdata.getCreditGlId()) && rowdata.getCreditGlId().length()>45)
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00575, "");
		}
		
	}
	private void checkPercentageWithoutIndicator(ItcDto rowdata, InwardDroolUtil inwardRules) {
		if (!inwardRules.checkindicatorWithoutPercentage(rowdata.getReversalIndicator(), rowdata.getReversalPercentage())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50117, "");
		}
		
	}

	private void checkIndicatorWithoutPercentage(ItcDto rowdata, InwardDroolUtil inwardRules) {
		if (!inwardRules.checkPercentageWithoutIndicator(rowdata.getReversalIndicator(), rowdata.getReversalPercentage())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50116, "");
		}
		
	}

	private void validItcInelegibalIndicator(ItcDto rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkItcReversalIndicator(rowdata.getReversalIndicator())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50113, "");
		}
		
	}

	private void validateInputType(ItcDto rowdata) {
		List<String> inputTypeList = new ArrayList<>(Arrays.asList("IN", "INS","CG"));	
		if (!inputTypeList.contains(rowdata.getItcInputType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50032, "");
	}
		}

	private void validateInvoiceDate(ItcDto rowData, InwardDroolUtil ruleMethods) {
		if(!ruleMethods.isValidInvoiceDate(rowData.getInwardDate()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00016, "");
		}
		
	}

		private void validateInvoiceNo(ItcDto rowData, InwardDroolUtil ruleMethods) {
			if (!ruleMethods.isInvoiceNoExist(rowData.getInwardNo())) {
	            markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00030, "");
	        } else if (!ruleMethods.isSpecialCharExistInInvoiceNo(rowData.getInwardNo())) {
	            markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00054, "");
	        }
		}

	private void validateOrgInvoiceDateDate(ItcDto rowData, InwardDroolUtil ruleMethods) {
		if(StringUtils.isNotBlank(rowData.getOrgInvoiceDate()) && !ruleMethods.isValidInvoiceDate(rowData.getOrgInvoiceDate()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00167, "");
		}
		
	}

	private void validateOrgInvoiceNo(ItcDto rowData, InwardDroolUtil ruleMethods) {
        if(StringUtils.isNotBlank(rowData.getOrgInvoiceNo()) && !ruleMethods.isSpecialCharExistInInvoiceNo(rowData.getOrgInvoiceNo()))
        {
        	markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00166, "");
        }
		
	}

	private void validateDocDate(ItcDto rowData, InwardDroolUtil ruleMethods) {
		if(StringUtils.isNotBlank(rowData.getDocDate()) && !ruleMethods.isValidInvoiceDate(rowData.getDocDate()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00095, "");
		}
		
	}

	private void validateDocNo(ItcDto rowData, InwardDroolUtil ruleMethods) {
        if(StringUtils.isNotBlank(rowData.getDocNo()) && !ruleMethods.isSpecialCharExistInInvoiceNo(rowData.getDocNo()))
        {
        	markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00093, "");
        }
		
	}

	private void validateSupplyType(ItcDto rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.checkSupplyType(rowdata.getSupplyType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00141, "");
		}}

	private void validGstinCheck(ItcDto rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.validGSTIN(rowdata.getGstinOfSupplier())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00519, "");
        }
	}

	
	private void validGSTINTaxpayer(ItcDto rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.validGSTIN(rowdata.getGstinUinOfRecipient())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00517, "");
        }
	}
	
	
	
	
	private void inwardNo16Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.check16CharacterLength(rowdata.getInwardNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00031, "");
        }
	}
	
	
	private void isValidInvoiceDateFutureCheck(ItcDto rowdata, InwardDroolUtil ruleMethods) {
		boolean isValidDate=ruleMethods.isValidInvoiceDate(rowdata.getInwardDate());
		boolean isValidFutureDate=ruleMethods.isValidFutureInvoiceDate(rowdata.getInwardDate());
		if (isValidDate && !isValidFutureDate) {
			 markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00315, "");
        }
	}

	
	private void markErrorNAddErrorCode(ItcDto rowdata, String errorCode, String errorMsg) {
        rowdata.setErrorCodeList(rowdata.getErrorCodeList().append(errorCode));
        rowdata.setErrorDescriptionList(rowdata.getErrorDescriptionList().append(errorMsg));
        rowdata.setValid(false);
    }


	

	private void validateDocType(ItcDto rowdata) {
		List<String> docTypeList = new ArrayList<>(Arrays.asList("INV", "CRN","DBN"));
		if (StringUtils.isBlank(rowdata.getDocType()) || !docTypeList.contains(rowdata.getDocType())) {
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00257, "");
		}
	}
	 private void checkForTaxPayerGstinEqualsSupplierGstin(ItcDto rowdata) {
	        if (StringUtils.isNotBlank(rowdata.getGstinUinOfRecipient())
	                        && rowdata.getGstinUinOfRecipient().equals(rowdata.getGstinOfSupplier())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00518, "");
	        }
	    }
	 
	 
		private void checkUdf11Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf11()) && ruleMethods.checkUDFLength(rowdata.getUdf11())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00537, "");
	        }
	    }

	    private void checkUdf12Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf12()) && ruleMethods.checkUDFLength(rowdata.getUdf12())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00558, "");
	        }
	    }

	    private void checkUdf13Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf13()) && ruleMethods.checkUDFLength(rowdata.getUdf13())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00539, "");
	        }
	    }

	    private void checkUdf14Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf14()) && ruleMethods.checkUDFLength(rowdata.getUdf14())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00540, "");
	        }
	    }

	    private void checkUdf15Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf15()) && ruleMethods.checkUDFLength(rowdata.getUdf15())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00541, "");
	        }
	    }

	    private void checkUdf16Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf16()) && ruleMethods.checkUDFLength(rowdata.getUdf16())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00542, "");
	        }
	    }

	    private void checkUdf17Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf17()) && ruleMethods.checkUDFLength(rowdata.getUdf17())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00543, "");
	        }
	    }

	    private void checkUdf18Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf18()) && ruleMethods.checkUDFLength(rowdata.getUdf18())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00544, "");
	        }
	    }
	 
	    private void checkUdf19Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf19()) && ruleMethods.checkUDFLength(rowdata.getUdf19())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00545, "");
	        }
	    }


	    private void checkUdf11AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf11()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf11())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00546, "");
	        }
	    }

	    private void checkUdf12AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf12()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf12())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00547, "");
	        }
	    }

	    private void checkUdf13AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf13()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf13())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00548, "");
	        }
	    }

	    private void checkUdf14AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf14()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf14())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00549, "");
	        }
	    }
	    private void checkUdf15AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf15()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf15())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00550, "");
	        }
	    }

	    private void checkUdf16AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf16()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf16())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00551, "");
	        }
	    }

	    private void checkUdf17AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf17()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf17())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00552, "");
	        }
	    }

	    private void checkUdf18AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf18()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf18())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00553, "");
	        }
	    }

	    private void checkUdf19AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf19()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf19())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00554, "");
	        }
	    }
	  
	    private void checkUdf20Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf20()) && ruleMethods.checkUDFLength(rowdata.getUdf20())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00555, "");
	        }
	    }
	    

	    private void checkUdf20AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf20()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf20())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00556, "");
	        }
	    }
		
		private void checkUdf10Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf10()) && ruleMethods.checkUDFLength(rowdata.getUdf10())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00311, "");
	        }
	    }

	    private void checkUdf9Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf9()) && ruleMethods.checkUDFLength(rowdata.getUdf9())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00309, "");
	        }
	    }

	    private void checkUdf8Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf8()) && ruleMethods.checkUDFLength(rowdata.getUdf8())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00307, "");
	        }
	    }

	    private void checkUdf7Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf7()) && ruleMethods.checkUDFLength(rowdata.getUdf7())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00305, "");
	        }
	    }
	   
	    private void checkUdf6Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf6()) && ruleMethods.checkUDFLength(rowdata.getUdf6())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00303, "");
	        }
	    }

	    private void checkUdf5Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf5()) && ruleMethods.checkUDFLength(rowdata.getUdf5())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00301, "");
	        }
	    }

	    private void checkUdf4Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf4()) && ruleMethods.checkUDFLength(rowdata.getUdf4())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00299, "");
	        }
	    }

	    private void checkUdf3Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf3()) && ruleMethods.checkUDFLength(rowdata.getUdf3())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00297, "");
	        }
	    }

	    private void checkUdf2Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf2()) && ruleMethods.checkUDFLength(rowdata.getUdf2())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00295, "");
	        }
	    }

	    private void checkUdf10AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf10()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf10())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00275, "");
	        }
	    }

	    private void checkUdf9AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf9()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf9())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00310, "");
	        }
	    }
	    

	    private void checkUdf8AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf8()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf8())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00308, "");
	        }
	    }

	    private void checkUdf7AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf7()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf7())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00306, "");
	        }
	    }

	    private void checkUdf6AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf6()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf6())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00304, "");
	        }
	    }

	    private void checkUdf5AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf5()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf5())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00302, "");
	        }
	    }

	    private void checkUdf4AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf4()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf4())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00300, "");
	        }
	    }

	    private void checkUdf3AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf3()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf3())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00298, "");
	        }
	    }

	    private void checkUdf2AlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf2()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf2())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00296, "");
	        }
	    }
	    

	    private void checkUdf1Length(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf1()) && ruleMethods.checkUDFLength(rowdata.getUdf1())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00293, "");
	        }
	    }

	    private void checkUdf1xAlphaNumeric(ItcDto rowdata, InwardDroolUtil ruleMethods) {
	        if (StringUtils.isNotBlank(rowdata.getUdf1()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf1())) {
	            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00294, "");
	        }
	    }


}
