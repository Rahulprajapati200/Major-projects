package com.bdo.bvms.common.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class TdsDetails {
	
	private int tdsId;
	private String tdsSection;
	private String tdsRate;
	private String tdsTaxAmount;
	private String challanNo;
	private String challanDate;
	private String challanAmount;
	private String periodFilingTdsReturn;
	private String grossAmount;
	private String dateofPayment;
	private String paymentRefNo;
	private String paymentAmount;
	private String assAmt;
	private String invoiceAgainstProvAdv;
	private String inwardNoProvAdv;	
	private String inwardDateprovAdv;
	private String OrgAmountofProvAdv;
	private String amountofProvAdv;
	private String orgBalOutstanding;
	private String balOutstanding;
	private String vendorCodeErp;	
	
	
	
	private String panOfRecipient;	
	private String gstinUinOfRecipient;
	private String docType;	
	private String gstinOfSupplier;
	private String panOfSupplier;
	private String supplierName;
	private String docNo;
	private String docDate;
	private String inwardNo;	
	private String inwardAate;
	
	
		
	
		
	
	
	
	private String filingPeriod;
	
	private String debitglId;	
	private String debitglName;
	private String creditglId;
	private String creditglName;
	
	private String orgAssAmount;
	private String orgTdsRate;
	private String orgTdsTaxAmount;
	private String orgGrossAmount;
	private String orgPaymentAmount;
	private String orgChallanAmount;
	
	private String udf1;
	private String udf2;
	private String udf3;
	private String udf4;
	private String udf5;
	private String udf6;
	private String udf7;
	private String udf8;
	private String udf9;
	private String udf10;
	private String udf11;
	private String udf12;	
	private String udf13;	
	private String udf14;	
	private String udf15;
	private String udf16;	
	private String udf17;	
	private String udf18;
	private String udf19;
	private String udf20;
	private boolean valid;
	private int excelRowId;
	private StringBuilder errorCodeList=new StringBuilder();
	private StringBuilder errorDescriptionList=new StringBuilder();
	private String errorCode;

}
