package com.bdo.bvms.common.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.bdo.bvms.common.config.AzureClientProvider;
import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.UploadTransDao;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNReqDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.AzureUploadDownloadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.service.UploadNDownloadFileService;
import com.bdo.bvms.common.util.CommonUtils;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class UploadNDownloadFileServiceImpl implements UploadNDownloadFileService {

    @Autowired
    public AzureClientProvider client;

//    @Autowired
//    public UploadTransDao uploadDao;

    @Autowired
    UploadTransDao uploadTransDao;

    @Value("${bvms.cloud.temp.file.download.path}")
    String tempFolder;

    @Override
    public String uploadFileToAzureBlob(MultipartFile file, InwardInvoiceCDNReqDTO apiRequestDTO, String batchNo,
                    AzureConnectionCredentialsDTO credentialMap) throws VendorInvoiceServerException{

    	if (log.isInfoEnabled()) {
            log.info("Class:" + this.getClass().toString() + ", method :uploadFileToAzureBlob");
        }

        try {

            if (file != null && file.getSize() > 0) {

                String fileType = FilenameUtils.getExtension(file.getOriginalFilename());

                String fileName = new StringBuilder().append(batchNo).append(Constants.UNSERSCORE_BASE)
                                .append(Constants.DOTSEPARATOR).append(fileType).toString();

                client.getClient(credentialMap).blobName(fileName).buildClient().upload(file.getInputStream(),
                                file.getSize());

            }

        } catch (Exception ex) {
            // write code update TX uplaod log = Done
        	uploadTransDao.updateProcessStatus(batchNo, Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            throw new VendorInvoiceServerException(ex.getMessage(), ex);
        }

        return batchNo;
    }

    @Override
    public void downloadFileFromAzureBlob(String fileName, String targetPath, AzureConnectionCredentialsDTO map) throws VendorInvoiceServerException
                    {

    	try {
            File file = new File(targetPath + System.getProperty(Constants.FILESEPERATOR) + fileName);
            if (file.exists()) {
                FileUtils.deleteQuietly(file);
            }

            client.getClient(map).blobName(fileName).buildClient()
                            .downloadToFile(targetPath + System.getProperty(Constants.FILESEPERATOR) + fileName);
        } catch (Exception ex) {
            log.info("Exception occur during Downloading file from Azure to Templ Folder");
            throw new VendorInvoiceServerException(ex.getMessage(), ex.getCause());
        }


    }

    @Override
    public void uploadErrorFile(UploadReqDTO uploadDTO, AzureConnectionCredentialsDTO map) {
        String csvErrorFilePath = CommonUtils.getAzureErrorFilePath(uploadDTO, tempFolder);
        File file = new File(csvErrorFilePath);

        final String methodName = "";
        log.info(Constants.LOGMESSAGE,methodName);
        try {

            try (InputStream inputStream = new FileInputStream(file)) {
                client.getClient(map).blobName(uploadDTO.getBatchNo() + Constants.ERROR_DOT_CSV_AZURE_INV).buildClient()
                                .upload(inputStream, file.length());
            }

        } catch (Exception e) {
        	log.error(Constants.LOGERRORMESSAGE,methodName);
           // throw new InvoiceTemplateUploadException(e.getMessage(), e.getCause());
        }

    }

	@Override
	public void uploadSftpFileToAzureBlob(InwardInvoiceCDNReqDTO uploadRequestDTO, String batchNo,
			AzureConnectionCredentialsDTO storageCredentials) throws AzureUploadDownloadException {


        if (log.isInfoEnabled()) {
            log.info("Class:" + this.getClass().toString() + ", method :uploadFileToAzureBlob");
        }

        try {

        	File file=new File(tempFolder+"/"+uploadRequestDTO.getSftpFileName());
        	
            if (file != null && file.length() > 0) {

                String fileType = FilenameUtils.getExtension(uploadRequestDTO.getSftpFileName());

                String fileName = new StringBuilder().append(batchNo).append(Constants.UNSERSCORE_BASE)
                                .append(Constants.DOTSEPARATOR).append(fileType).toString();

                try (InputStream inputStream = new FileInputStream(file)) {
                    client.getClient(storageCredentials).blobName(fileName).buildClient().upload(inputStream,
                                    file.length());
                }

            }

        } catch (Exception ex) {
            // write code update TX uplaod log = Done
            log.error("Error in uploadFileToAzureBlob Method", ex);
            uploadTransDao.updateProcessStatus(batchNo, Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            throw new AzureUploadDownloadException("File storage service is down");
        }

        

    
		
	
		
	}

}