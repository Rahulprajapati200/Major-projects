package com.bdo.bvms.common.dto;

import java.io.Serializable;

/**
 *FileType: java
 *Author : anka
 *Created On : 02/11/2017 6:56:39 PM
 *Copy Rights : Anka Technology Solutions Pvt. Ltd.
 */
public class Template implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer pickupMasterId;
	private String ref_type;
	private String ref_code;
	private String ref_short_desc;
	private String ref_long_desc;
	private String template_name;

	public Template() {
		//
	}

	public Template(Integer pickupMasterId, String ref_type, String ref_code, String ref_short_desc, String ref_long_desc) {
		this.pickupMasterId = pickupMasterId;
		this.ref_type = ref_type;
		this.ref_code = ref_code;
		this.ref_short_desc = ref_short_desc;
		this.ref_long_desc = ref_long_desc;
	}

	public Integer getPickupMasterId() {
		return pickupMasterId;
	}

	public void setPickupMasterId(Integer pickupMasterId) {
		this.pickupMasterId = pickupMasterId;
	}

	public String getRef_type() {
		return ref_type;
	}

	public void setRef_type(String ref_type) {
		this.ref_type = ref_type;
	}

	public String getRef_code() {
		return ref_code;
	}

	public void setRef_code(String ref_code) {
		this.ref_code = ref_code;
	}

	public String getRef_short_desc() {
		return ref_short_desc;
	}

	public void setRef_short_desc(String ref_short_desc) {
		this.ref_short_desc = ref_short_desc;
	}
	
	public String getRef_long_desc() {
		return ref_long_desc;
	}

	public void setRef_long_desc(String ref_long_desc) {
		this.ref_long_desc = ref_long_desc;
	}
	
	public String getTemplate_name() {
		return template_name;
	}

	public void setTemplate_name(String template_name) {
		this.template_name = template_name;
	}
	
	@Override
	public String toString() {
		return "Template [pickup_master_id=" + pickupMasterId + ", ref_type=" + ref_type + ", ref_code=" + ref_code + ", ref_short_desc=" + ref_short_desc + ", ref_long_desc=" + ref_long_desc + ", template_name=" + template_name + "]";
	}
}
