package com.bdo.bvms.common.dto;

import java.sql.Timestamp;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class UploadStageLogDto {

    int id;
    int uploadLogId;
    String processStage;
    String processState;
    Timestamp createdAt;
    int createdBy;
    String batchNo;
}
