package com.bdo.bvms.common.util;


import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;


public class InwardCDNBDRL {
	public void applyBDRL(InwardInvoiceCDNTemplateDTO inwardInvoice,String orignalCategory) {
		
		if (inwardInvoice.getSupplierStateCode().equals(inwardInvoice.getPlaceOfSupply())) {
			inwardInvoice.setSupplyType("INTRA");
		}
		
		if (!inwardInvoice.getSupplierStateCode().equals(inwardInvoice.getPlaceOfSupply())) {
			inwardInvoice.setSupplyType("INTER");
		}
		
		if("debit note".equalsIgnoreCase(inwardInvoice.getDocType())) {
			inwardInvoice.setInvoiceCategory(orignalCategory);
			inwardInvoice.setInvoiceType("D");
		}
		
		if("credit note".equalsIgnoreCase(inwardInvoice.getDocType())) {
			inwardInvoice.setInvoiceCategory(orignalCategory);
			inwardInvoice.setInvoiceType("C");
		}
		
		if("8A".equalsIgnoreCase(inwardInvoice.getTableNo())) {
			
			inwardInvoice.setTableNo(inwardInvoice.getTableNo());
			
		}
		
		if(checkImportTypeForHsn(inwardInvoice.getImportType(),inwardInvoice.getHsnSacCode())) {
			inwardInvoice.setImportType("Inputs");
		}
		
		if(checkImportTypeForHsnService(inwardInvoice.getImportType(),inwardInvoice.getHsnSacCode())) {
			inwardInvoice.setImportType("Input Services");
		}
		
		

		
	}
	
	 boolean checkImportTypeForHsnService(String importType,String hsnSacCode){
		boolean validImportType = true;
		boolean validHsnCode = true;
		if("".equals(importType) || "0".equals(importType)){
			validImportType = false;
		}
		if("".equals(hsnSacCode) || "0".equals(hsnSacCode)){
			validHsnCode = false;
		}
		
		if(validHsnCode && !validImportType){
			if(hsnSacCode.length() == 1){
					hsnSacCode = "0" + hsnSacCode;
				}
			String sacCode = hsnSacCode.substring(0,2);
			if(Double.parseDouble(sacCode) == 99 ){
				return true;
			}
			return false; 				
		}	
		return false;
	}
	
	
	 boolean checkImportTypeForHsn(String importType,String hsnSacCode){
		boolean validImportType = true;
		boolean validHsnCode = true;
		if(StringUtils.isBlank(importType) || "0".equals(importType)){
			validImportType = false;
		}
		if(StringUtils.isBlank(hsnSacCode) || "0".equals(hsnSacCode)){
			validHsnCode = false;
		}
		if(validImportType && hsnSacCode.equals("0")){
			return false;
		}
		if(!validHsnCode && !validImportType){
			return true;
		}
		if(validHsnCode && !validImportType){
			if(hsnSacCode.length() == 1){
					hsnSacCode = "0" + hsnSacCode;
				}
			String sacCode = hsnSacCode.substring(0,2);
			if(Double.parseDouble(sacCode) != 99){
				return true;
			}
			return false; 				
		}	
		return false;
	}
}
