package com.bdo.bvms.common.validationrule;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.common.constant.Constants;

public class EInvoiceValidationUtil {

    public boolean checkInvoiceLength13(String value) {
        boolean isvalid = true;
        if (value != null && value.length() > 13) {
            isvalid = false;
        }

        return isvalid;
    }

    public boolean checkUDFLength(String udfx) {
    	boolean x=true;
        if (udfx.length() > 200) {
            x= false;
        }
       return x;

    }

    public boolean isValidInvoiceDate(String value) {


        if (StringUtils.isBlank(value) || value.matches(Constants.INVOICEREGEX) || value.equals("0")
                        || value.equals("") || value.equals("-")) {
            return false;
        } else {
            try {
                if (value.indexOf("-") > 0) {
                    String[] parts = value.split("-");
                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        int date = Integer.parseInt(parts[0]);
                        int month = Integer.parseInt(parts[1]);
                        int year = Integer.parseInt(parts[2]);
                        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                            Calendar c = Calendar.getInstance();
                            c.set(Calendar.DAY_OF_MONTH, date);
                            c.set(Calendar.MONTH, month - 1);
                            c.set(Calendar.YEAR, year);

                            try {
                                SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATEFORMATE1);
                                formatter.setLenient(false);
                                formatter.parse(value);
                                return true;

                            } catch (ParseException e) {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                } else {
                    String[] parts = value.split("/");
                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        int date = Integer.parseInt(parts[0]);
                        int month = Integer.parseInt(parts[1]);
                        int year = Integer.parseInt(parts[2]);
                        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                            Calendar c = Calendar.getInstance();
                            c.set(Calendar.DAY_OF_MONTH, date);
                            c.set(Calendar.MONTH, month - 1);
                            c.set(Calendar.YEAR, year);

                            try {
                                SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATEFORMATE2);
                                formatter.setLenient(false);
                                formatter.parse(value);
                                return true;

                            } catch (ParseException e) {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                }
            } catch (Exception ex) {
                return false;
            }
        }
    }

    public boolean isValidPurchaseOrderDate(String value) {

        if (StringUtils.isBlank(value) || value.matches(Constants.PURCHASEORDERREGEX) || value.equals("0")
                        || value.equals("") || value.equals("-")) {
            return false;
        } else {
            try {
                if (value.indexOf("-") > 0) {
                    String[] parts = value.split("-");
                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        int date = Integer.parseInt(parts[0]);
                        int month = Integer.parseInt(parts[1]);
                        int year = Integer.parseInt(parts[2]);
                        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                            Calendar c = Calendar.getInstance();
                            c.set(Calendar.DAY_OF_MONTH, date);
                            c.set(Calendar.MONTH, month - 1);
                            c.set(Calendar.YEAR, year);

                            try {
                                SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATEFORMATE1);
                                formatter.setLenient(false);
                                formatter.parse(value);
                                return true;

                            } catch (ParseException e) {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                } else {
                    String[] parts = value.split("/");
                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        int date = Integer.parseInt(parts[0]);
                        int month = Integer.parseInt(parts[1]);
                        int year = Integer.parseInt(parts[2]);
                        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                            Calendar c = Calendar.getInstance();
                            c.set(Calendar.DAY_OF_MONTH, date);
                            c.set(Calendar.MONTH, month - 1);
                            c.set(Calendar.YEAR, year);

                            try {
                                SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATEFORMATE2);
                                formatter.setLenient(false);
                                formatter.parse(value);
                                return true;

                            } catch (ParseException e) {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                }
            } catch (Exception ex) {
                return false;
            }
        }
    }

    public boolean isValidIRNDate(String value) {

        if (StringUtils.isBlank(value) || value.matches(Constants.VALIDIRNDATEREGEX) || value.equals("0")
                        || value.equals("") || value.equals("-")) {
            return false;
        } else {
            try {
                if (value.indexOf("-") > 0) {
                    String[] parts = value.split("-");
                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        int date = Integer.parseInt(parts[0]);
                        int month = Integer.parseInt(parts[1]);
                        int year = Integer.parseInt(parts[2]);
                        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                            Calendar c = Calendar.getInstance();
                            c.set(Calendar.DAY_OF_MONTH, date);
                            c.set(Calendar.MONTH, month - 1);
                            c.set(Calendar.YEAR, year);

                            try {
                                SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
                                formatter.setLenient(false);
                                formatter.parse(value);
                                return true;

                            } catch (ParseException e) {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                } else {
                    String[] parts = value.split("/");
                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        int date = Integer.parseInt(parts[0]);
                        int month = Integer.parseInt(parts[1]);
                        int year = Integer.parseInt(parts[2]);
                        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                            Calendar c = Calendar.getInstance();
                            c.set(Calendar.DAY_OF_MONTH, date);
                            c.set(Calendar.MONTH, month - 1);
                            c.set(Calendar.YEAR, year);

                            try {
                                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                                formatter.setLenient(false);
                                formatter.parse(value);
                                return true;

                            } catch (ParseException e) {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                }
            } catch (Exception ex) {
                return false;
            }
        }
    }

    public boolean checkIfDiluted(String dilutedValidationString, String errorID) {
        if (StringUtils.isBlank(dilutedValidationString)) {
            return false;
        } else {
            return dilutedValidationString.contains(errorID);
        }
    }

    public boolean validGSTIN(String gstin) {

        try {

            if (!"0".equals(gstin)) {
                String gstinFormateregex = "[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[Z]{1}[0-9a-zA-Z]{1}";
                 String tdsRegex = "[0-9]{2}[a-zA-Z]{4}[a-zA-Z0-9]{1}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[D]{1}[0-9a-zA-Z]{1}";

                boolean isValidFormat = false;

                if (gstin.length() < 15) {
                    return isValidFormat;
                }

                if (checkPattern(gstin, gstinFormateregex) || checkPattern(gstin, tdsRegex)) {
                    isValidFormat = verifyCheckDigit(gstin);
                }
                return isValidFormat;

            }

        } catch (Exception ex) {
            return false;
        }

        return true;
    }

    public boolean checkPattern(String inputval, String regxpatrn) {
        boolean result = false;
        if ((inputval.trim()).matches(regxpatrn)) {
            result = true;
        }
        return result;
    }

    public boolean verifyCheckDigit(String gstinWCheckDigit) {
        Boolean isCDValid = false;
        String newGstninWCheckDigit = getGSTINWithCheckDigit(
                        gstinWCheckDigit.substring(0, gstinWCheckDigit.length() - 1));
        if (gstinWCheckDigit.trim().equals(newGstninWCheckDigit)) {
            isCDValid = true;
        }

        return isCDValid;
    }

    public String getGSTINWithCheckDigit(String gstinWOCheckDigit) {

        String gstinCodePointChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        int factor = 2;
        int sum = 0;
        int checkCodePoint = 0;
        char[] cpChars;
        char[] inputChars;

        if (gstinWOCheckDigit == null) {

            return "";
        }
        cpChars = gstinCodePointChars.toCharArray();
        inputChars = gstinWOCheckDigit.trim().toUpperCase().toCharArray();

        int mod = cpChars.length;
        for (int i = inputChars.length - 1; i >= 0; i--) {
            int codePoint = -1;

            for (int j = 0; j < cpChars.length; j++) {
                if (cpChars[j] == inputChars[i]) {
                    codePoint = j;
                }
            }
            int digit = factor * codePoint;
            factor = (factor == 2) ? 1 : 2;
            digit = (digit / mod) + (digit % mod);
            sum += digit;
        }
        checkCodePoint = (mod - (sum % mod)) % mod;

        return gstinWOCheckDigit + cpChars[checkCodePoint];

    }

    public boolean isAlphanumeric(String s) {

        boolean validInvoice = true;
        if (StringUtils.isBlank(s)) {
            validInvoice = false;
        }

        if (validInvoice) {

            Pattern p = Pattern.compile("[^0-9A-Za-z]");
            Matcher m = p.matcher(s);
            if (m.find()) {
                validInvoice = false;
            }
        }
        return validInvoice;
    }

    public boolean containsNumbersOnly(String source, Integer typeChk) {
        boolean result = false;
        if (StringUtils.isNotBlank(source)) {
            source = source.trim();
            try {
                if (typeChk == 1) {
                    Pattern pattern;
                    pattern = Pattern.compile("[0-9.]+"); // correct pattern for
                                                          // both float and
                                                          // integer. execute

                    result = pattern.matcher(source).matches();

                    return result;
                } else {
                    Double.parseDouble(source);
                    return true;
                }

            } catch (Exception ex) {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean onlyNumericMainHsnCode(String value) {

        boolean isvalid = true;
        if (StringUtils.isBlank(value)) {
            isvalid = false;
        } else {
            Pattern p = Pattern.compile("\\D");
            Matcher m = p.matcher(value);

            if (m.find()) {
                isvalid = false;
            }
        }
        return isvalid;

    }

    public boolean checkDocumentNumber(String docNo) {
        boolean result = true;

        if (StringUtils.isBlank(docNo) || "0".equals(docNo)) {
            result = false;
        }

        if (result) {

            String docRegex = "^([^,]{1,})$";
            Pattern p = Pattern.compile(docRegex);
            Matcher m = p.matcher(docNo);
            if (m.find()) {
                result = false;
            } else {
                result = true;
            }
        }
        return result;

    }

    public boolean twoDecimalCheck(String docType, String value) {
        boolean isValid = true;
        try {
            if ("b2cs summary invoice".equalsIgnoreCase(docType)) {
                if (!value.matches(Constants.TWODECIMALCHECKREGEX)) {
                    isValid = false;
                }

            } else {
                if (!value.matches(Constants.TWODECIMALCHECKREGEX2)) {
                    isValid = false;
                }

            }
        } catch (Exception ex) {
            return false;
        }
        return isValid;

    }

    public boolean onlyNumeric(String value) {
        boolean isValid = true;
        if (org.apache.commons.lang3.StringUtils.isBlank(value)) {
            isValid = false;
        } else {
            Pattern p = Pattern.compile("[^0-9.]");
            Matcher m = p.matcher(value);

            if (m.find()) {
                isValid = false;
            }

        }

        return isValid;
    }

    //
    public boolean twoDecimalHsnCheckBlank(String value) {
        boolean validData = true;
        if (StringUtils.isBlank(value)) {
            validData = false;
        }
        if (validData && !value.matches(Constants.TWODECIMALHSN)) {

            validData = false;
        }
        return validData;
    }

    // function to validate date
    public boolean isValidinwardDate(String value) {

        if (StringUtils.isBlank(value) || value.matches(Constants.VALIDINWARD) || "0".equals(value)
                        || "-".equals(value)) {
            return false;
        } else {
            try {
                if (value.indexOf("-") > 0) {
                    String[] parts = value.split("-");

                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        int date = Integer.parseInt(parts[0]);
                        int month = Integer.parseInt(parts[1]);
                        int year = Integer.parseInt(parts[2]);
                        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                            Calendar c = Calendar.getInstance();
                            c.set(Calendar.DAY_OF_MONTH, date);
                            c.set(Calendar.MONTH, month - 1);
                            c.set(Calendar.YEAR, year);

                            try {
                                SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
                                formatter.setLenient(false);
                                formatter.parse(value);

                                return true;

                            } catch (ParseException e) {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                } else {
                    String[] parts = value.split("/");

                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        int date = Integer.parseInt(parts[0]);
                        int month = Integer.parseInt(parts[1]);
                        int year = Integer.parseInt(parts[2]);
                        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                            Calendar c = Calendar.getInstance();
                            c.set(Calendar.DAY_OF_MONTH, date);
                            c.set(Calendar.MONTH, month - 1);
                            c.set(Calendar.YEAR, year);

                            try {
                                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                                formatter.setLenient(false);
                                formatter.parse(value);

                                return true;

                            } catch (ParseException e) {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                }
            } catch (Exception ex) {
                return false;

            }
        }
    }

    public boolean check16CharacterLength(String value) {
    	boolean x=true;
        if (StringUtils.isNotBlank(value) && !"0".equals(value) && value.length() > 16) {
            x= false;
        }
        return x;

    }

    public boolean isInvoiceNoExist(String invoiceNo) {
    	boolean x=true;
        if ("".equals(invoiceNo) || "0".equals(invoiceNo)) {
            x= false;
        }
        return x;
    }

    public boolean isSpecialCharExistInInvoiceNo(String invoiceNo) {

        boolean validInvoice = true;

        if (StringUtils.isBlank(invoiceNo) || "0".equals(invoiceNo)) {
            validInvoice = false;
        }

        if (validInvoice) {
            Pattern p = Pattern.compile("[^0-9A-Za-z/-]");
            Matcher m = p.matcher(invoiceNo);
            if (m.find()) {
                validInvoice = false;
            } else {
                validInvoice = true;
            }
        }
        return validInvoice;
    }

    public boolean isSpecialCharExistInPurchaseOrderNo(String invoiceNo) {

        boolean validInvoice = true;

        if (StringUtils.isBlank(invoiceNo) || "0".equals(invoiceNo)) {
            validInvoice = false;
        }

        if (validInvoice) {
            Pattern p = Pattern.compile("[^0-9A-Za-z/-]");
            Matcher m = p.matcher(invoiceNo);
            if (m.find()) {
                validInvoice = false;
            } else {
                validInvoice = true;
            }
        }
        return validInvoice;
    }

    // E-way bill Date cannot be before 1st July 2017

    public boolean isValidDateRange(String geteWayBillDate) {
        SimpleDateFormat sdformat = new SimpleDateFormat(Constants.DATEFORMATE1);
        try {
            if (StringUtils.isBlank(geteWayBillDate)) {
                return false;
            }
            Date d1 = sdformat.parse("01-07-2017");
            Date d2 = sdformat.parse(geteWayBillDate);

            if (d1.compareTo(d2) > 0) {

                return false;
            }

        } catch (ParseException e) {

            return false;
        }
        return true;
    }

    // E-way bill Date cannot be future date

    public boolean ifFutureDate(String geteWayBillDate) throws ParseException {
        boolean valid = Boolean.TRUE;
        SimpleDateFormat sdformat = new SimpleDateFormat(Constants.DATEFORMATE1);

        Date currentDate = new Date();
        Date localDate = null;
        if (StringUtils.isBlank(geteWayBillDate)) {
            valid = Boolean.FALSE;
        }

        try {
            localDate = sdformat.parse(geteWayBillDate);
        } catch (ParseException e) {
            return Boolean.FALSE;
        }

        if (localDate.compareTo(currentDate) > 0) {
            valid = Boolean.FALSE;
        }
        return valid;

    }

    // Purchase Order Date cannot exceed docDate

    public boolean ifExceedDate(String poDate, String docDate) {
        SimpleDateFormat sdformat = new SimpleDateFormat(Constants.DATEFORMATE1);
        try {
            if (StringUtils.isBlank(docDate)) {
                return false;
            }
            if (StringUtils.isBlank(poDate)) {
                return false;
            }
            Date d1 = sdformat.parse(poDate);
            Date d2 = sdformat.parse(docDate);

            if (d1.compareTo(d2) > 0) {

                return false;
            }

        } catch (ParseException e) {

            return false;
        }
        return true;
    }

    // total Invoice Amount should be greater the 5 CR

    public boolean isValidHsn(String s, String hsnConf, String turnover) {
        boolean validHsn = false;
        if (Double.parseDouble(hsnConf) != 1) {
            if (s.equals("") || s.equals("0")) {
                return false;
            } else {
                if (Double.parseDouble(turnover) > 50000000) {
                    if (s.length() == 6 || s.length() == 7 || s.length() == 8) {
                        validHsn = true;
                    }
                } else {
                    if (s.length() == 4 || s.length() == 5 || s.length() == 6 || s.length() == 7 || s.length() == 8) {
                        validHsn = true;
                    }
                }
                Pattern p = Pattern.compile("\\D");
                Matcher m = p.matcher(s);
               
                boolean b = m.find();
                boolean x=true;
                if (validHsn && b) {                       
                        x= false;                  
                } else {
                    x= true;
                }
                return x;

            }
        }
        return true;

    }

    // function for Hsn code not start with 99 then PO will be mandatory

    public boolean isHsnAsPerPO(String hsnCode, String po) {
        String first2SubStrHsn = hsnCode.substring(0, 2);
        boolean x=true;
        if (!first2SubStrHsn.equals("99") && (po.equals("") || po.equals("0"))) {
            x= false;
        }
        return x;
    }

}
