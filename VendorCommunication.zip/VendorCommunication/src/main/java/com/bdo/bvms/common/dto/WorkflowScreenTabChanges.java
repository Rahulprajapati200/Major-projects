package com.bdo.bvms.common.dto;

import java.sql.Date;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class WorkflowScreenTabChanges {
	Integer id;

	Integer tvcrid;

	Integer master;

	Integer contact;
	
	Integer bank;

	Integer address;

	Integer attachments;

	Date updatedAt;

	Integer updatedBy;
	
	Integer pldModuleId;
}

