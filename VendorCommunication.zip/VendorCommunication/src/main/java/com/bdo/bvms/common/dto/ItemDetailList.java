package com.bdo.bvms.common.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ItemDetailList {

	private String description;
	private String hsn;
	private String qty;
	private String itemRate;
	private String unit;
	private String taxable;
	private String gstRate;
	private String igst;
	private String cgst;
	private String sgst;
	private String cess;
	private String cessRate;
	private String totalitemvalue;
	private String subLocation;
	private String yearId;
	private String reversalIndicator;
	private String reversalPercentage;
}
