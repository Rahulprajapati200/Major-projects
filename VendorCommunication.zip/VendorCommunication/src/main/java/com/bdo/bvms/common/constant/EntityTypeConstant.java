package com.bdo.bvms.common.constant;

public final class EntityTypeConstant {

	EntityTypeConstant(){

	}

	public static final Integer ENTITY_TYPE_VENDOR = 9; 

	public static final Integer ENTITY_TYPE_TAXPAYER = 10; 


}
