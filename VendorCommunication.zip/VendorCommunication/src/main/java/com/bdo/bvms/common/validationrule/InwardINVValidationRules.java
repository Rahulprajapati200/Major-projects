package com.bdo.bvms.common.validationrule;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;

public class InwardINVValidationRules {

	public void validateRules(InwardInvoiceCDNTemplateDTO rowdata, String dilutedValidation,Map<String, String> stateCodeMap ,Map<String, String> portCodeMap ,List<String> govtRateMap, List<String> tdsSections ) {

		InwardDroolUtil inwardRules=new InwardDroolUtil();
		
		// check supply type
		if (!inwardRules.checkSupplyType(rowdata.getOrgInvoiceCategory())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00141, "");
		}
		
		// validate doc type value : It should be from list
		if (("0".equals(rowdata.getDocType()) || "0.00".equals(rowdata.getDocType()) || "0.0".equals(rowdata.getDocType()) || StringUtils.isBlank(rowdata.getDocType()) && (rowdata.getErrorCodeList().indexOf("E00141") <= 0 ))
				|| !rowdata.getDocType().matches("(?i)regular tax invoice|rcm invoice|import invoice|sez invoice|isd invoice|Bill of supply|deemed export invoice")) {
			
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00013, "");
			
		}

		// rules for gstin_of_recipient field
		if (StringUtils.isNotBlank(rowdata.getGstinOfRecipient()) && rowdata.getGstinOfRecipient().equals(rowdata.getGstinOfSupplier())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00518, "");
		}
		
		//for blank gstin_of_recipient field
		if (StringUtils.isBlank(rowdata.getGstinOfRecipient())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00114, "");
		}

		// validate reverse charge on basis of docType"
		if (!inwardRules.checkReverseChargeForRCM(rowdata.getReverseCharge(), rowdata.getDocType(), rowdata.getImportType(), rowdata.getHsnSacCode())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50102, "");
		}

		// validate supplierStateCode
		if (!(String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())) != null && stateCodeMap.get(String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode()))) != null)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50002, "");
		}
		
		// validate supplierStateCode
		if (!(rowdata.getSupplierStateCode() != null && stateCodeMap.get(getSupplierStateCode(rowdata.getSupplierStateCode())) != null)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00073, "");
			
		}

		// Port no == Port no in any value from List Values
		if ( !"null".equalsIgnoreCase(rowdata.getPort()) && !"0.0".equals(rowdata.getPort()) && !"0".equals(rowdata.getPort()) && StringUtils.isNotBlank(rowdata.getPort())
				&& portCodeMap.get(rowdata.getPort().toLowerCase()) == null) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_O0095, "");
		}

		// "inter state supply check with doctypes gstin not equal to pos"
		if (inwardRules.onlyNumeric(rowdata.getSupplierStateCode()) && inwardRules.onlyNumeric(rowdata.getPlaceOfSupply()) && !inwardRules.checkInwardInter(rowdata.getGstinOfRecipient(), rowdata.getDocType(), rowdata.getSgstAmt(), rowdata.getIgstAmt(), rowdata.getCgstAmt(),
				String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply())), String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())), rowdata.getImportType(), rowdata.getReverseCharge())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00050, "");

		}

		// intra check with doctypes in same states

		if (inwardRules.onlyNumeric(rowdata.getSupplierStateCode()) && inwardRules.onlyNumeric(rowdata.getPlaceOfSupply()) && !inwardRules.checkInwardIntra(rowdata.getGstinOfRecipient(), rowdata.getDocType(), rowdata.getSgstAmt(), rowdata.getIgstAmt(), rowdata.getCgstAmt(),
				String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply())), String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())), rowdata.getImportType(), rowdata.getReverseCharge())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00051, "");

		}

		// "check for I50111"
		if (!inwardRules.checkSezGstin(rowdata.getDocType(), rowdata.getGstinOfSupplier())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50016, "");
		}
		
		if (!inwardRules.checkRegularGstin(rowdata.getDocType(), rowdata.getGstinOfSupplier())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50111, "");
		}
		
		// "check for I50115"
		if (!inwardRules.checkDeemedGstin(rowdata.getDocType(), rowdata.getGstinOfSupplier())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50115, "");
		}

		// "check for I50004"
		if (!inwardRules.checkImportDoctypeGstin(rowdata.getDocType(), rowdata.getGstinOfSupplier())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50004, "");
		}

		// "validate sgst rate + cgst rate list"
		String sgstRegex = "^[0-9]\\d*(\\.\\d{1,2})?$";
		if (StringUtils.isNotBlank(rowdata.getSgstRate()) && rowdata.getSgstRate().matches(sgstRegex) && rowdata.getCgstRate() != null
				&& rowdata.getCgstRate().matches(sgstRegex) && !inwardRules.isValidRate(rowdata.getSgstRate(), rowdata.getCgstRate(), govtRateMap)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00022, "");
		}

		// validate IGST rate list
		if (StringUtils.isNotBlank(rowdata.getIgstRate()) && rowdata.getIgstRate().matches(sgstRegex) && !govtRateMap.contains(String.valueOf(Double.parseDouble(rowdata.getIgstRate())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00028, "");
		}

		// check for I50039
		if (!inwardRules.checkHsnImportGoods(rowdata.getDocType(), rowdata.getImportType(), rowdata.getHsnSacCode())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50039, "");
		}

		// check rate Sgst
		if (!inwardRules.checkRateAgainstAmounts(rowdata.getSgstRate(), rowdata.getSgstAmt(), rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00033, "");
		}
		
		
		// check rateCgst
		if (!inwardRules.checkRateAgainstAmounts(rowdata.getCgstRate(), rowdata.getCgstAmt(), rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00034, "");
		}
		// check rate Igst
		if (!inwardRules.checkRateAgainstAmounts(rowdata.getIgstRate(), rowdata.getIgstAmt(), rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00033, "");
		}
	
		// check taxable and gross
		if (!inwardRules.checkValueAgainstTaxableGross(rowdata.getIgstRate(), rowdata.getCgstRate(), rowdata.getSgstRate(), rowdata.getInwardTotalTaxAmt(),
				rowdata.getInwardGrossTotalAmount(), rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00021, "");
		}
		
		// "check for Inter for Import and Sez Doctype
		if (!inwardRules.checkForInterSEZIMP(rowdata.getDocType(), rowdata.getSgstRate(), rowdata.getCgstRate(), rowdata.getIgstRate(), rowdata.getIgstAmt(), rowdata.getCgstAmt(),
				rowdata.getSgstAmt(), rowdata.getDocType(), rowdata.getOrgInvoiceCategory())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50012, "");
		}

		// validate importType
		if (!inwardRules.checkForImportType(rowdata.getImportType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50032, "");
		}

		// validate ReverseCharge
		if (StringUtils.isNotBlank(rowdata.getReverseCharge()) && !"n".equalsIgnoreCase(rowdata.getReverseCharge()) && !"y".equalsIgnoreCase(rowdata.getReverseCharge())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00029, "");
		}

		// rule to calculate tax for O0114 intra
				if(inwardRules.onlyNumeric(rowdata.getSupplierStateCode()) && inwardRules.onlyNumeric(rowdata.getPlaceOfSupply()) && String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())).equals(String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply())))  && "0".equalsIgnoreCase(rowdata.getDiffPercent())) {
					if (!(inwardRules.checkInwardTaxCalculationCgstSgst(rowdata.getDocType(), String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())), rowdata.isValid(),
							rowdata.getInwardTaxableAmt(), rowdata.getSgstRate(), rowdata.getCgstRate(), rowdata.getSgstAmt(), rowdata.getCgstAmt(), dilutedValidation))) {
						markErrorNAddErrorCode(rowdata, "|O0114", "");
					}
				}
		
				// rule to calculate tax for O0114 inter
				if(inwardRules.onlyNumeric(rowdata.getSupplierStateCode()) && inwardRules.onlyNumeric(rowdata.getPlaceOfSupply()) && !String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())).equals(String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply())))  && "0".equalsIgnoreCase(rowdata.getDiffPercent())) {
					if (!(inwardRules.checkInwardTaxCalculationIgstWithoutDiff(rowdata.getDocType(), String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())),
							rowdata.isValid(), rowdata.getInwardTaxableAmt(), rowdata.getIgstRate(), rowdata.getIgstAmt()))) {
						markErrorNAddErrorCode(rowdata, "|O0114", "");
					}
				}

		// validate importType ISD

		if (!inwardRules.checkForImportTypeISD(rowdata.getImportType(), rowdata.getDocType(), rowdata.getHsnSacCode())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50039, "");
		}

		// validate taxable Value
		if (!inwardRules.checkTaxableRegular(rowdata.getInwardTaxableAmt(), rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00021, "");
		}
		
	
		// validate taxable for isd
		if (!inwardRules.checkTaxableISD(rowdata.getInwardTaxableAmt(), rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50041, "");
		}

		// validate gross staxable for isd
		if (!inwardRules.checkTaxableISD(rowdata.getInwardGrossTotalAmount(), rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50042, "");
		}

		// validate rate for isd
		if (!inwardRules.checkRateISD(rowdata.getSgstRate(), rowdata.getCgstRate(), rowdata.getIgstRate(), rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50043, "");
		}

		// check gstin for isd
		if (!inwardRules.checkGstnIsd(rowdata.getGstinOfSupplier(), rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50044, "");
		}

		// check for valid diff percentage
		if (!inwardRules.checkdiffpercentage(rowdata.getDiffPercent())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_O0113, "");
		}
		// "rule to calculate tax for O0115 inter and diff percent is equals 0.65"
		if((inwardRules.onlyNumeric(rowdata.getSupplierStateCode()) && inwardRules.onlyNumeric(rowdata.getPlaceOfSupply()) && !String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())).equals(String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply())))  && "0.65".equalsIgnoreCase(rowdata.getDiffPercent())) && (!(inwardRules.checkInwardTaxCalculationIgst(rowdata.getDocType(), rowdata.getDiffPercent(), rowdata.isValid(),
				rowdata.getInwardTaxableAmt(), rowdata.getIgstRate(), rowdata.getIgstAmt(), dilutedValidation)))) {
			
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_O0115, "");
			
		}

		// rule to calculate tax for O0115 intra and diff percent is equals 0.65
		if(inwardRules.onlyNumeric(rowdata.getSupplierStateCode()) && inwardRules.onlyNumeric(rowdata.getPlaceOfSupply()) && (String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())).equals(String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply())))  && "0.65".equalsIgnoreCase(rowdata.getDiffPercent())) && (!(inwardRules.checkInwardTaxCalculationCgstSgstDiff(rowdata.getDocType(), rowdata.getDiffPercent(), rowdata.isValid(),
				rowdata.getInwardTaxableAmt(), rowdata.getSgstRate(), rowdata.getCgstRate(), rowdata.getSgstAmt(), rowdata.getCgstAmt(), dilutedValidation)))) {
			
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_O0115, "");
			
		}
		// rule to check value in all three amount
		if (!inwardRules.checkAllThreeAmount(rowdata.getDocType(), rowdata.getSgstAmt(), rowdata.getCgstAmt(), rowdata.getIgstAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00021, "");
		}

		
		// rule to check itc cgst and sgst are same
		if (!inwardRules.checkAllCgstSgstAmount(rowdata.getItcSgstAmt(), rowdata.getItcCgstAmt(), rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00127, "");
		}

		// rule to check value in all three itc amount
		if (!inwardRules.checkAllThreeAmount(rowdata.getDocType(), rowdata.getItcSgstAmt(), rowdata.getItcCgstAmt(), rowdata.getItcIgstAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00128, "");
		}
		// rule to check cgst and sgst same amount in all three amount
		if (!inwardRules.checkAllCgstSgstAmount(rowdata.getSgstAmt(), rowdata.getCgstAmt(), rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00092, "");
		}
		// validate itc Eligible
		if (!inwardRules.checkItcEligible(rowdata.getItcEligible())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50018, "");
		}

		// check itc sgst Amount
		if (!inwardRules.checkAmtAgainstItcAmt(rowdata.getSgstAmt(), rowdata.getItcSgstAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50019, "");
		}

		// check itc cgst Amount
		if (!inwardRules.checkAmtAgainstItcAmt(rowdata.getCgstAmt(), rowdata.getItcCgstAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50020, "");
		}
		
		// check itc igst Amount
		if (!inwardRules.checkAmtAgainstItcAmt(rowdata.getIgstAmt(), rowdata.getItcIgstAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50021, "");
		}

		// check itc igst Amount
		if (!inwardRules.checkAmtAgainstItcAmt(rowdata.getCessAmount(), rowdata.getItcCessAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50022, "");
		}
		// check itc Total Amount
		if (!inwardRules.checkAmtAgainstItcAmt(rowdata.getInwardTotalTaxAmt(), rowdata.getTotalItcAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50023, "");
		}

		
		// itc eligible/ reversal indicator list of value check
		if (!inwardRules.checkItcReversalIndicator(rowdata.getItcIneligibleReversalIndicator())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50113, "");
		}
		// indicator present percentage not present
		if (!inwardRules.checkindicatorWithoutPercentage(rowdata.getItcIneligibleReversalIndicator(), rowdata.getItcIneligibleReversalPercentage())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50117, "");
		}

		// indicator No absent percentage present
		if (!inwardRules.checkPercentageWithoutIndicator(rowdata.getItcIneligibleReversalIndicator(), rowdata.getItcIneligibleReversalPercentage())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50116, "");
		}
		// ack date should not be in future
		if (!inwardRules.isValidFutureAckDate(rowdata.getAckDate())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00170, "");
		}
		//WOPAY rate and amount check
		if(!inwardRules.checkSEZWOPAYAmount(rowdata.getOrgInvoiceCategory(),rowdata.getSgstAmt(),rowdata.getIgstAmt(),rowdata.getCgstAmt()) ) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50120, "");
		}
		//BOE,port,boedate if one present all should be present
		if(!inwardRules.checkBOEDetailforImport(rowdata.getOrgInvoiceCategory(),rowdata.getImportBillOfEntryNo(),rowdata.getImportBillOfEntryDate(),rowdata.getPort()) ) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00227, "");
		}
		//check rate Cess
		if(!inwardRules.checkRateAgainstAmounts(rowdata.getCessRate(),rowdata.getCessAmount(),rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50121, "");
		}
		//validate importType IMPGSEZ
		if(!inwardRules.checkForImportTypeIMPGSEZ(rowdata.getImportType(),rowdata.getOrgInvoiceCategory(),rowdata.getHsnSacCode())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00228, "");
		}
		
		//validate Quantity Greater than 11 digit
		if(!inwardRules.checkLength12GNew(rowdata.getQuantity(), (StringUtils.isNotBlank(rowdata.getQuantity()) && !"0".equalsIgnoreCase(rowdata.getQuantity()) && !"0.0".equalsIgnoreCase(rowdata.getQuantity()) && !"0.00".equalsIgnoreCase(rowdata.getQuantity())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00100, "");
		}
		
		//validate Item Rate Greater than 11 digit
		if(!inwardRules.checkLength12GNew(rowdata.getItemRate(), (StringUtils.isNotBlank(rowdata.getItemRate()) && !"0".equalsIgnoreCase(rowdata.getItemRate()) && !"0.0".equalsIgnoreCase(rowdata.getItemRate()) && !"0.00".equalsIgnoreCase(rowdata.getItemRate())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00017, "");
		}
		
		//validate Taxable amount (ass_amt) Greater than 13 digit
		if(!inwardRules.checkLength14GNew(rowdata.getInwardTaxableAmt(), (StringUtils.isNotBlank(rowdata.getInwardTaxableAmt()) && !"0".equalsIgnoreCase(rowdata.getInwardTaxableAmt()) && !"0.0".equalsIgnoreCase(rowdata.getInwardTaxableAmt()) && !"0.00".equalsIgnoreCase(rowdata.getInwardTaxableAmt())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00101, "");
		}
		
		//validate SGST rate Greater than 6 digit
		if(!inwardRules.checkLength6GNew(rowdata.getSgstRate(), (StringUtils.isNotBlank(rowdata.getSgstRate()) && !"0".equalsIgnoreCase(rowdata.getSgstRate()) && !"0.0".equalsIgnoreCase(rowdata.getSgstRate()) && !"0.00".equalsIgnoreCase(rowdata.getSgstRate())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00102, "");
		}
			
		//validate SGST amount Greater than 13 digit
		if(!inwardRules.checkLength14GNew(rowdata.getSgstAmt(), (StringUtils.isNotBlank(rowdata.getSgstAmt()) && !"0".equalsIgnoreCase(rowdata.getSgstAmt()) && !"0.0".equalsIgnoreCase(rowdata.getSgstAmt()) && !"0.00".equalsIgnoreCase(rowdata.getSgstAmt())))) {
			markErrorNAddErrorCode(rowdata,ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00103, "");
		}
		
		//validate CGST rate Greater than 6 digit
		if(!inwardRules.checkLength6GNew(rowdata.getCgstRate(), (StringUtils.isNotBlank(rowdata.getCgstRate()) && !"0".equalsIgnoreCase(rowdata.getCgstRate()) && !"0.0".equalsIgnoreCase(rowdata.getCgstRate()) && !"0.00".equalsIgnoreCase(rowdata.getCgstRate())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00104, "");
		}
		
		//validate CGST amount Greater than 13 digit
		if(!inwardRules.checkLength14GNew(rowdata.getCgstAmt(), (StringUtils.isNotBlank(rowdata.getCgstAmt()) && !"0".equalsIgnoreCase(rowdata.getCgstAmt()) && !"0.0".equalsIgnoreCase(rowdata.getCgstAmt()) && !"0.00".equalsIgnoreCase(rowdata.getCgstAmt())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00105, "");
		}
		
		//validate IGST rate Greater than 6 digit
		if(!inwardRules.checkLength6GNew(rowdata.getIgstRate(), (StringUtils.isNotBlank(rowdata.getIgstRate()) && !"0".equalsIgnoreCase(rowdata.getIgstRate()) && !"0.0".equalsIgnoreCase(rowdata.getIgstRate()) && !"0.00".equalsIgnoreCase(rowdata.getIgstRate())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00106, "");
		}
		
		//validate IGST amount Greater than 13 digit
		if(!inwardRules.checkLength14GNew(rowdata.getIgstAmt(), (StringUtils.isNotBlank(rowdata.getIgstAmt()) && !"0".equalsIgnoreCase(rowdata.getIgstAmt()) && !"0.0".equalsIgnoreCase(rowdata.getIgstAmt()) && !"0.00".equalsIgnoreCase(rowdata.getIgstAmt())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00107, "");
		}
		
		//validate CESS rate Greater than 6 digit
		if(!inwardRules.checkLength6GNew(rowdata.getCessRate(), (StringUtils.isNotBlank(rowdata.getCessRate()) && !"0".equalsIgnoreCase(rowdata.getCessRate()) && !"0.0".equalsIgnoreCase(rowdata.getCessRate()) && !"0.00".equalsIgnoreCase(rowdata.getCessRate())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00108, "");
		}
			
		//validate CESS amount Greater than 13 digit
		if(!inwardRules.checkLength14GNew(rowdata.getCessAmount(), (StringUtils.isNotBlank(rowdata.getCessAmount()) && !"0".equalsIgnoreCase(rowdata.getCessAmount()) && !"0.0".equalsIgnoreCase(rowdata.getCessAmount()) && !"0.00".equalsIgnoreCase(rowdata.getCessAmount())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00109, "");
		}
		

		if(!inwardRules.checkLength6GNew(rowdata.getDiffPercent(), (StringUtils.isNotBlank(rowdata.getDiffPercent()) && !"0".equalsIgnoreCase(rowdata.getDiffPercent()) && !"0.0".equalsIgnoreCase(rowdata.getDiffPercent()) && !"0.00".equalsIgnoreCase(rowdata.getDiffPercent())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00228, "");
		}
		
		
		
		//validate InwardGrossTotal amount Greater than 13 digit
		if((StringUtils.isBlank(rowdata.getInwardGrossTotalAmount())) || !inwardRules.checkLength14GNew(rowdata.getInwardGrossTotalAmount(), true)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00111, "");
		}
		
		//validate Total Invoice amount Greater than 13 digit
		if((StringUtils.isBlank(rowdata.getTotalInvoiceAmt())) || !inwardRules.checkLength14GNew(rowdata.getTotalInvoiceAmt(), true)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00153, "");
		}
		
		//validate ItcIneligible Reversal Percentage Greater than 13 digit
		if(!inwardRules.checkLength14GNew(rowdata.getItcIneligibleReversalPercentage(), (StringUtils.isNotBlank(rowdata.getItcIneligibleReversalPercentage()) && !"0".equalsIgnoreCase(rowdata.getItcIneligibleReversalPercentage()) && !"0.0".equalsIgnoreCase(rowdata.getItcIneligibleReversalPercentage()) && !"0.00".equalsIgnoreCase(rowdata.getItcIneligibleReversalPercentage())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50114, "");
		}
		
		//validate import bill of entry amt Greater than 13 digit
		if(!inwardRules.checkLength14GNew(rowdata.getImportBillOfEntryAmt(), (StringUtils.isNotBlank(rowdata.getImportBillOfEntryAmt()) && !"0".equalsIgnoreCase(rowdata.getImportBillOfEntryAmt()) && !"0.0".equalsIgnoreCase(rowdata.getImportBillOfEntryAmt()) && !"0.00".equalsIgnoreCase(rowdata.getImportBillOfEntryAmt())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50030, "");
		}
		
		
		//validate import bill of entry amt Greater than 13 digit
		if(!StringUtils.isBlank(rowdata.getHsnSacCode()) && !StringUtils.isBlank(rowdata.getOrgInputType()) && !StringUtils.isBlank(rowdata.getQuantity()) && !rowdata.getHsnSacCode().startsWith("99") && "0".equals(rowdata.getQuantity()) && "CG".equals(rowdata.getOrgInputType()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50039, "");
		}
		
		// inwardDate should be in DD-MM-YYYY format
		if (rowdata.getInwardDate() != null && !inwardRules.isValidInvoiceDate(rowdata.getInwardDate())) {
 			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00016, "");
		}
		
           if (!inwardRules.isValidFP(rowdata.getInwardDate(), rowdata.getFillingPeriod()) && StringUtils.isNotBlank(rowdata.getFillingPeriod())) {
			
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00016, "");
		}
		
		// "validate placeOfSupply"
		if (inwardRules.onlyNumeric(rowdata.getPlaceOfSupply()) && stateCodeMap.get(String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply()))) == null) {
					markErrorNAddErrorCode(rowdata, "|E00015", "");
			}
				
		if(StringUtils.isNotBlank(rowdata.getPaymentAmount()) && !inwardRules.onlyNumeric(rowdata.getPaymentAmount()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00538, "");
		}
		if(StringUtils.isNotBlank(rowdata.getPaymentRefNo()) && !inwardRules.isSpecialCharExistInInvoiceNo(rowdata.getPaymentRefNo()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00526, "");
		}
		
		if(StringUtils.isNotBlank(rowdata.getTdsSection()) && !tdsSections.contains(rowdata.getTdsSection()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00527, "");
		}
		
		if (!inwardRules.checkNilRated(rowdata.getDocType(), rowdata.getSgstAmt(), rowdata.getCgstAmt(), rowdata.getIgstAmt(), rowdata.getCessAmount(), rowdata.getNilRatedAmt(),
				rowdata.getExemptedAmt(), rowdata.getNonGstAmt(), rowdata.getCompositionAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50040, "");
		}
		
	}
	

	private void markErrorNAddErrorCode(InwardInvoiceCDNTemplateDTO rowdata, String errorCode, String errorMsg) {
		rowdata.setErrorCodeList(rowdata.getErrorCodeList().append(errorCode));
		rowdata.setErrorDescriptionList(rowdata.getErrorDescriptionList().append(errorMsg));
		rowdata.setValid(false);
	}
	
	String getSupplierStateCode(String code) {
		
		if("01".equals(code)) {
			return "1";
		}else if("02".equals(code)) {
			return "2";
		}else if("03".equals(code)) {
			return "3";
		}else if("04".equals(code)) {
			return "4";
		}else if("05".equals(code)) {
			return "5";
		}else if("06".equals(code)) {
			return "6";
		}else if("07".equals(code)) {
			return "7";
		}else if("08".equals(code)) {
			return "8";
		}else if("09".equals(code)) {
			return "9";
		}
		return code;
		
		
	}


}
