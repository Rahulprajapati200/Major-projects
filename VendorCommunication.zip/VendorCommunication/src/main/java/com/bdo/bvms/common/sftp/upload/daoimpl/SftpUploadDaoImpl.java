package com.bdo.bvms.common.sftp.upload.daoimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.sftp.upload.dao.SftpUploadDao;
import com.bdo.bvms.common.sftp.upload.dto.SftpFileDetailsDto;
import com.bdo.bvms.common.sftp.upload.sql.SftpUploadSql;
@Repository
public class SftpUploadDaoImpl implements SftpUploadDao{

	@Autowired
    JdbcTemplate jdbcTemplateMst;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Override
    public List<SftpFileDetailsDto> getSftpFileDetails() {

        String query = SftpUploadSql.GET_PENDING_SFTP_FILES_UPLOAD_DETAILS;
        return jdbcTemplateTrn.query(query, new ResultSetExtractor<List<SftpFileDetailsDto>>() {

            List<SftpFileDetailsDto> dataList = new ArrayList<>();

            @Override
            public List<SftpFileDetailsDto> extractData(ResultSet rs) throws SQLException, DataAccessException {
                while (rs.next()) {
                    SftpFileDetailsDto data = new SftpFileDetailsDto();
                    data.setId(rs.getInt("ID"));
                    data.setSftpPath(rs.getString("SFTP_PATH"));
                    data.setBatchedFileName(rs.getString("BATCHED_FILENAME"));
                    data.setPanNo(rs.getString("PANNO"));
                    data.setTemplateType(rs.getString("template_type"));
                    data.setCustomTemplateId(rs.getString("custom_templateid"));
                    data.setOriginalFileName(rs.getString("CLIENT_FILENAME"));
                    data.setUploadType(rs.getString("dc_type"));
                    data.setUserId(rs.getString("user_id"));
                    dataList.add(data);
                }
                return dataList;
            }
        });
    }

	@Override
	public int getUserId(SftpFileDetailsDto sftpFileDetailsDto) {
		 String query=SftpUploadSql.getUserIdQuery(mstDatabseName,sftpFileDetailsDto.getUserId());
	        return jdbcTemplateMst.queryForObject(query,Integer.class,sftpFileDetailsDto.getUserId());
	}

	@Override
	public void updateSftpPendingDetails() {
		String query=SftpUploadSql.updateQuery();
		jdbcTemplateTrn.update(query,Constants.SUCCESSDETAILS,Constants.PENDINGDETAILS);
	}
	
	@Override
	public int getModuleId(SftpFileDetailsDto sftpFileDetailsDto)
	{
		String queryString =SftpUploadSql.getModuleId(mstDatabseName);
		return jdbcTemplateMst.queryForObject(queryString, Integer.class,sftpFileDetailsDto.getPanNo());
	}
	
	@Override
	public String getSftpConnectionStringFromDB() {
		String query="select KeyVALUE from system_parameter where KeyNAME= 'sftpConnectionString'";
		return jdbcTemplateMst.queryForObject(query,String.class);
	}
	
	@Override
	public String getSftpContainerNameFromDB() {
		String query="select KeyVALUE from system_parameter where KeyNAME= 'sftpContainerName'";
		return jdbcTemplateMst.queryForObject(query,String.class);
	}
}
