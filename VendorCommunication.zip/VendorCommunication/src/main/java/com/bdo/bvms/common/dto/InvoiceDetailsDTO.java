package com.bdo.bvms.common.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class InvoiceDetailsDTO {
	private int id;
	private String taxpayergstin;
	private String docType;
	
	private String tranType;
	private String vendorgstin;
	private String vendorlegalname;
	private String vendortradename;
	private String invoiceno;
	private String invoicedate;
	private String pos;
	private String invoicevalue;
	
	private String supplierStateCode;
	private String vendorCodeErp;	
	private String docNo;
	private String supplierGSTIN;
	private String differentialPercent;
	private String importBillofEntryNo;
	private String importBillofEntryAmt;
	private String debitGlId;
	private String debitGlName;
	private String creditGlId;
	private String creditGlName;
	private String docDate;
	private String reverseCharge;
	private String port;
	private String importBillofDate;
	
	private String orgInvoiceNo;
	private String orgInvoiceDate;
	private String irn;
	private String ackDate;
	private String ackNo;
	private String subLocation;
	
	List<ItemDetailList> editItemDetail=new ArrayList<>();
	List<PaymentDetails>paymentDetails=new ArrayList<>();
	List<TdsDetails>tdsDetails=new ArrayList<>();
	List<Integer>itemDeletedIds=new ArrayList<>();
	List<Integer>paymentDeletedIds=new ArrayList<>();
	List<Integer>tdsDeletedIds=new ArrayList<>();
	
	private boolean isValid=true;
	private String batchNo;
	private String fp;
	private int userId;
	private String inputType;
	
	private String dateOfPayment;
	private String amountofPayment;
	private String paymentRefNo;
	private String tdsSection;
	private String tdsRate;
	private String tdsTaxAmount;
	private String challanNo;
	private String challanDate;
	private String challanAmount;
	private String periodFilingTdsReturn;
	private String invoiceAgainstProvAdv;
	private String inwardNoProvAdv;
	private String inwardDateprovAdv;
	private String amountofProvAdv;
	private String balOutstanding;
	
	private String udf1;
	private String udf2;
	private String udf3;
	private String udf4;
	private String udf5;
	private String udf6;
	private String udf7;
	private String udf8;
	private String udf9;
	private String udf10;
	private String udf11;
	private String udf12;
	private String udf13;
	private String udf14;
	private String udf15;
	private String udf16;
	private String udf17;
	private String udf18;
	private String udf19;
	private String udf20;
	

}
