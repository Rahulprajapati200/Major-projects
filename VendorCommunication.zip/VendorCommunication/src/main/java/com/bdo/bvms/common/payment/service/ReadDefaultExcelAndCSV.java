package com.bdo.bvms.common.payment.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvoiceTemplateUploadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface ReadDefaultExcelAndCSV {

	void readDataFromExcel(UploadReqDTO uploadReqDTO, List<PaymentDetails> paymentDetailsTemplateDTOList, List<PaymentDetails> rowDocErrorPojoList) throws InvoiceTemplateUploadException;

	void readCSVFile(UploadReqDTO uploadReqDTO, List<PaymentDetails> paymentDetailsTemplateDTOList) throws VendorInvoiceServerException, IOException;

}
