package com.bdo.bvms.common.itc.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvoiceTemplateUploadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface ReadItcExcelAndCSV {

	void readDataFromExcel(UploadReqDTO uploadReqDTO, List<ItcDto> itcDtoTemplateDTOList,
			List<ItcDto> rowDocErrorPojoList) throws InvoiceTemplateUploadException;

	void readCSVFile(UploadReqDTO uploadReqDTO, List<ItcDto> itcDtoTemplateDTOList) throws IOException, VendorInvoiceServerException;

}
