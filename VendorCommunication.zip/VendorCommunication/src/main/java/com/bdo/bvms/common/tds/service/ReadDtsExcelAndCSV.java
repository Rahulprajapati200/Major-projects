package com.bdo.bvms.common.tds.service;

import java.io.IOException;
import java.util.List;

import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvoiceTemplateUploadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface ReadDtsExcelAndCSV {
	void readDataFromExcel(UploadReqDTO uploadReqDTO, List<TdsDetails> tdsDetailsTemplateDTOList) throws InvoiceTemplateUploadException;

	void readCSVFile(UploadReqDTO uploadReqDTO, List<TdsDetails> tdsDetailsTemplateDTOList) throws VendorInvoiceServerException, IOException;


}
