package com.bdo.bvms.common.exceptions;

import java.io.Serializable;
/**
 *FileType: java
 *Author : anka
 *Created On : 02/11/2017 6:56:39 PM
 *Copy Rights : Anka Technology Solutions Pvt. Ltd.
 */
public class BDOException extends Exception implements Serializable {

	private static final long serialVersionUID = 1L;

	public BDOException() {
	}

	public BDOException(String message) {
		super(message);
	}

	public BDOException(Throwable cause) {
		super(cause);
	}

	public BDOException(String message, Throwable cause) {
		super(message, cause);
	}

	public BDOException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
