package com.bdo.bvms.common.sftp.upload.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SftpFileDetailsDto {
    int id;
    String batchedFileName;
    String sftpPath;
    String templateType;
    String panNo;
    String customTemplateId;
    String originalFileName;
    String uploadType;
    String userId;

}
