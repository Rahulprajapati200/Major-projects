package com.bdo.bvms.common.itc.service;

import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;

public interface ItcUpload {
	
	String validateAndSaveItc(UploadReqDTO uploadReqDTO, AzureConnectionCredentialsDTO storageCredentials);

}
