package com.bdo.bvms.common.dto;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SearchTemplateDetailsReqDTO extends BaseReqDTO  {
	
	@NotEmpty(message= "{gstinOrPan.notempty}")
    String gstinOrPan;

    @NotEmpty(message= "{gstinOrPanList.notempty}")
    List<String> gstinOrPanList;
	
	private String templateName;
	
}
