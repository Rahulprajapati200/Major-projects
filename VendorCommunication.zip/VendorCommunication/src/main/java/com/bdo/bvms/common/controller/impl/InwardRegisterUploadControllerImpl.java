package com.bdo.bvms.common.controller.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.Valid;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.controller.InwardRegisterUploadController;
import com.bdo.bvms.common.dto.APIResponseDTO;
import com.bdo.bvms.common.dto.AddAttachmentsReqDTO;
import com.bdo.bvms.common.dto.AttachmentListDto;
import com.bdo.bvms.common.dto.AttacmentReqDTO;
import com.bdo.bvms.common.dto.InvoiceDetailsDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNReqDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.SearchSystemParameterReqDTO;
import com.bdo.bvms.common.dto.SearchSystemParameterResDTO;
import com.bdo.bvms.common.dto.SearchVendorDetailsReqDTO;
import com.bdo.bvms.common.dto.UpadateResponseDto;
import com.bdo.bvms.common.exception.apierror.CustomValidationError;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.global.exception.handler.CustomValidationViolationException;
import com.bdo.bvms.common.service.AttachmentService;
import com.bdo.bvms.common.service.IFileService;
import com.bdo.bvms.common.service.InvoiceUpdateDetailsService;
import com.bdo.bvms.common.service.InwardUpload;
import com.bdo.bvms.common.service.UploadService;

import com.bdo.bvms.common.util.ValidateBeanUtil;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;


/**
 * The Class InwardRegisterUploadControllerImpl.
 */
@RestController
@RequestMapping("/vendor-communication")

/** The Constant log. */
@Slf4j
public class InwardRegisterUploadControllerImpl implements InwardRegisterUploadController {
	
    /** The upload service. */
    @Autowired
    UploadService uploadService;

    /** The inward upload. */
    @Autowired
    InwardUpload inwardUpload;

    /** The file service. */
    @Autowired
    IFileService fileService;

    /** The attachment service. */
    @Autowired
    AttachmentService attachmentService;

    /** The invice update details service. */
    @Autowired
    InvoiceUpdateDetailsService inviceUpdateDetailsService;

    /**
     * Upload file.
     *
     * @param request the request
     * @param uploadRequestDTO the upload request DTO
     * @return the response entity
     * @throws VendorInvoiceServerException the vendor invoice server exception
     */
    @Override
    @PostMapping("/upload-file")
    public ResponseEntity<APIResponseDTO> uploadFile(HttpServletRequest request,
                    @ModelAttribute InwardInvoiceCDNReqDTO uploadRequestDTO) throws VendorInvoiceServerException {

        String fileStatus = uploadService.uploadAndProcessFile(uploadRequestDTO);

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(HttpStatus.OK.value()).message(fileStatus)
                        .tag(request.getRequestURI()).build());

    }

    /**
     * Inward json validation api.
     *
     * @param request the request
     * @param invoiceDetailDto the invoice detail dto
     * @return the response entity
     * @throws VendorInvoiceServerException the vendor invoice server exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @Override
    @PostMapping("/inwardJsonValidationApi")
    public ResponseEntity<APIResponseDTO> inwardJsonValidationApi(HttpServletRequest request,
                    @RequestBody InvoiceDetailsDTO invoiceDetailDto) throws VendorInvoiceServerException, IOException {
       

         UpadateResponseDto upadateResponseDto=inviceUpdateDetailsService.updateAndValidateDetails(invoiceDetailDto);

        if (!(upadateResponseDto.getInwardTemplateErrorListDto().isEmpty() && upadateResponseDto.getPaymentDetailErrorList().isEmpty() && 
        		upadateResponseDto.getTdsDetailErrorList().isEmpty())) {
            return ResponseEntity.ok()
                            .body(APIResponseDTO.builder().status(0)
                                            .message("Invoice's Some validation Failed after Validation")
                                            .data(upadateResponseDto).tag(request.getRequestURI()).build());
        } else {
            return ResponseEntity.ok()
                            .body(APIResponseDTO.builder().status(1)
                                            .message("Invoice Validated and Updated successfully")
                                            .data(upadateResponseDto).tag(request.getRequestURI()).build());
        }

    }

    /**
     * View attachments.
     *
     * @param httpServletRequest the http servlet request
     * @param attacmentReqDTO the attacment req DTO
     * @return the response entity
     */
    @PostMapping(value = "/viewAttachments")
    public ResponseEntity<APIResponseDTO> viewAttachments(HttpServletRequest httpServletRequest,
                    @RequestBody AttacmentReqDTO attacmentReqDTO) {
        List<AttachmentListDto> getAttachmentListDto = attachmentService.getAttachment(attacmentReqDTO);

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).data(getAttachmentListDto)
                        .message("Get Attchment Successfully").tag(httpServletRequest.getRequestURI()).build());

    }

    /**
     * Search attachments.
     *
     * @param httpServletRequest the http servlet request
     * @param searchVendorDetailsReqDTO the search vendor details req DTO
     * @return the response entity
     */
    @PostMapping(value = "/searchAttachments", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> searchAttachments(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid SearchVendorDetailsReqDTO searchVendorDetailsReqDTO) {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(Stream.of(attachmentService.searchAttachments(searchVendorDetailsReqDTO))
                                        .collect(Collectors.toList()))
                        .message("Got vendor attachments successfully").tag(httpServletRequest.getRequestURI())
                        .build());
    }

    /**
     * Adds the vendor attachments.
     *
     * @param httpServletRequest the http servlet request
     * @param addAttachmentsReqDTO the add attachments req DTO
     * @return the response entity
     */
    @PostMapping(value = "/addVendorAttachments", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<APIResponseDTO> addVendorAttachments(HttpServletRequest httpServletRequest,
                    @ModelAttribute AddAttachmentsReqDTO addAttachmentsReqDTO) {

        log.info("Started addVendorAttachments");
        addAttachmentsReqDTO.setRemarks(null);
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        List<CustomValidationError> customValidationErrorList = new ArrayList<>();

        validateAddAttachmentsReqDTO(addAttachmentsReqDTO, customValidationErrorList);

        SearchSystemParameterResDTO maxFileSizeSystemParameterResDTO = attachmentService
                        .searchSystemParameter(SearchSystemParameterReqDTO.builder()
                                        .keyName(Constants.SYSTEM_PARAMETER_MAX_FILE_SIZE_ALLOWED_KEYNAME).build());

        long maxFileSize = Long.parseLong(maxFileSizeSystemParameterResDTO.getKeyValue());

        SearchSystemParameterResDTO fileExtnNotAllowedSystemParameterResDTO = attachmentService
                        .searchSystemParameter(SearchSystemParameterReqDTO.builder()
                                        .keyName(Constants.SYSTEM_PARAMETER_FILE_EXTN_NOT_ALLOWED_KEYNAME).build());

        String[] fileExtnNotAllowed = fileExtnNotAllowedSystemParameterResDTO.getKeyValue().split(",");

        List<File> fileList = new ArrayList<>();

        Arrays.asList(addAttachmentsReqDTO.getFiles()).stream().forEach(file -> {

            if ((file.getSize() / 1024 / 1024) > maxFileSize) {
                CustomValidationError customValidationError = new CustomValidationError(File.class.getName(),
                                file.getOriginalFilename(), file.getSize(), "Max file size allowed is " + maxFileSize);
                customValidationErrorList.add(customValidationError);

            }

            if (Arrays.asList(fileExtnNotAllowed).stream()
                            .anyMatch(FilenameUtils.getExtension(file.getOriginalFilename())::equalsIgnoreCase)) {
                CustomValidationError customValidationError = new CustomValidationError(File.class.getName(),
                                file.getOriginalFilename(), FilenameUtils.getExtension(file.getOriginalFilename()),
                                "File extensions not allowed are " + Arrays.asList(fileExtnNotAllowed));
                customValidationErrorList.add(customValidationError);
            }

            fileList.add(new File(fileService.saveFileInLocalStorage(file,
                            fileService.generateFileAbsolutePath(file.getOriginalFilename()))));

        });

        if (!customValidationErrorList.isEmpty()) {
            throw new CustomValidationViolationException(customValidationErrorList);

        }

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(Stream.of(attachmentService.addVendorAttachments(fileList, addAttachmentsReqDTO))
                                        .collect(Collectors.toList()))
                        .message("Add vendor attachments successfully").tag(httpServletRequest.getRequestURI())
                        .build());
    }

    /**
     * Validate add attachments req DTO.
     *
     * @param addAttachmentsReqDTO the add attachments req DTO
     * @param customValidationErrorList the custom validation error list
     */
    private void validateAddAttachmentsReqDTO(AddAttachmentsReqDTO addAttachmentsReqDTO,
                    List<CustomValidationError> customValidationErrorList) {
        Set<ConstraintViolation<Object>> constraintViolationList = ValidateBeanUtil.validateBean(addAttachmentsReqDTO);
        if (constraintViolationList != null && !constraintViolationList.isEmpty()) {
            for (ConstraintViolation<?> constraint : constraintViolationList) {
                CustomValidationError customValidationError = new CustomValidationError(
                                AddAttachmentsReqDTO.class.getName(), constraint.getPropertyPath().toString(),
                                constraint.getInvalidValue(), constraint.getMessage());
                customValidationErrorList.add(customValidationError);
            }
        }
    }

}
