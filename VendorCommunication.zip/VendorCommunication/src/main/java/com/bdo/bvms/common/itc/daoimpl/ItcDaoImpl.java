package com.bdo.bvms.common.itc.daoimpl;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.dto.PaymentResponseBean;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.itc.dao.ItcDao;
import com.bdo.bvms.common.sql.CommunicationSQL;
import com.bdo.bvms.common.util.AppLogger;

import lombok.extern.slf4j.Slf4j;
@Repository
@Slf4j
public class ItcDaoImpl implements ItcDao{

	 @Autowired
	 private JdbcTemplate jdbcTemplateTrn;
	
	   /** The mst database name. */
	    @Value("${mst.database-name}")
	    private String mstDatabaseName;

	    /** The trn database name. */
	    @Value("${txn.database-name}")
	    private String trnDatabaseName;
	 
	@Override
	public PaymentResponseBean gstInwardInvCdnInsert(String csvPaymentSuccessFilePath, String csvPaymentErrorFilePath,
			String successPaymentTable, String failurePaymentTable) {
	    final String methodName = "gstInwardInvCdnInsert";
	    int paymentSuccessCount = 0;
	    int paymentInvErrorCount = 0;

	    log.info(Constants.LOGMESSAGE, methodName);
	    String query;

	    PaymentResponseBean response = new PaymentResponseBean();

	    try {

	        query = CommunicationSQL.INSERT_FILE_SQL.replace("table_name", successPaymentTable);
	        AppLogger.info(Constants.BLANK, methodName, "query = " + query);
	        paymentSuccessCount = saveData(csvPaymentSuccessFilePath, query);
	        AppLogger.info(Constants.BLANK, methodName, "successCount = " + paymentSuccessCount);


	        query = CommunicationSQL.INSERT_FILE_SQL.replace("table_name", failurePaymentTable);
	        paymentInvErrorCount = saveData(csvPaymentErrorFilePath, query);
	        AppLogger.info(Constants.BLANK, methodName, "errorCount = " + paymentInvErrorCount);

	        response.setPaymentSuccessCount(paymentSuccessCount);
	        response.setErrorCount(paymentInvErrorCount);
	    } catch (Exception e) {
	        log.error(Constants.LOGERRORMESSAGE, methodName, e);
	    }
	    return response;
}
	
	private Integer saveData(String filePath, String query) throws VendorInvoiceServerException {

	    final String methodName = "";
	    log.info(Constants.LOGMESSAGE, methodName);
	    Integer count = 0;
	    try {
	        count = jdbcTemplateTrn.update(query, filePath);

	    } catch (Exception e) {
	        log.error(Constants.LOGERRORMESSAGE, methodName + e);
	        throw new VendorInvoiceServerException("E0006", e);
	    }
	    return count;
	}

	@Override
	public List<ItcDto> getItcErrorDataListWithErrorCode(UploadReqDTO uploadReqDTO) {
	    StringBuilder builder = new StringBuilder();
	    builder.append("SELECT error_code,gstin_uin_of_recipient,doc_type,supply_type,doc_no,doc_date,fp,"
	    		+ "org_invoice_no,org_invoice_date,gstin_of_supplier ,supplier_name,")
	    .append("inward_no ,inward_date,input_type,itc_ineligible_reversal_indicator,itc_ineligible_reversal_percentage,"
	    		+ "debit_gl_id,debit_gl_name,credit_gl_id,credit_gl_name,")
	    .append("udf_1 ,udf_2,udf_3 ,udf_4,udf_5 ,udf_6 ,udf_7,udf_8 ,udf_9,udf_10,udf_11,")
	    .append("udf_12,udf_13 ,udf_14 ,udf_15,udf_16 ,udf_17 ,udf_18,udf_19 ,udf_20")
	    .append(" FROM    inward_itc_error")
	    .append(" WHERE    batch_no = '").append(uploadReqDTO.getBatchNo())
	    .append("' and error_code != ''");
	    
	    
	    return jdbcTemplateTrn.query(builder.toString(), new ResultSetExtractor<List<ItcDto>>() {

	        @Override
	        public List<ItcDto> extractData(ResultSet rs)
	                        throws SQLException, DataAccessException {

	            List<ItcDto> listOFBatchData = new ArrayList<>();
	            while (rs.next()) {
	            	ItcDto template = new ItcDto();
	            	template.setGstinUinOfRecipient(rs.getString("gstin_uin_of_recipient"));
	                template.setDocType(rs.getString("doc_type"));
	                template.setSupplyType(rs.getString("supply_type"));
	                template.setDocNo(rs.getString("doc_no"));
	                template.setDocDate(rs.getString("doc_date"));
	                template.setOrgInvoiceDate(rs.getString("org_invoice_date"));
	                template.setOrgInvoiceNo(rs.getString("org_invoice_no"));
	                template.setItcInputType(rs.getString("input_type"));
	                template.setReversalIndicator(rs.getString("itc_ineligible_reversal_indicator"));
	                template.setReversalPercentage(rs.getString("itc_ineligible_reversal_percentage"));
	                template.setDebitGlId(rs.getString("debit_gl_id"));
	                template.setDebitGlName(rs.getString("debit_gl_name"));
	                template.setCreditGlId(rs.getString("credit_gl_id"));
	                template.setCreditGlName(rs.getString("credit_gl_name"));
	                template.setInwardNo(rs.getString("inward_no"));
	                template.setInwardDate(rs.getString("inward_date"));
	                template.setGstinOfSupplier(rs.getString("gstin_of_supplier"));
	                template.setSupplierName(rs.getString("supplier_name"));
	                template.setFilingPeriod(rs.getString("fp"));
	                template.getErrorCodeList().append(rs.getString("error_code"));
	                template.setUdf1(rs.getString("udf_1"));
	                template.setUdf2(rs.getString("udf_2"));
	                template.setUdf3(rs.getString("udf_3"));
	                template.setUdf4(rs.getString("udf_4"));
	                template.setUdf5(rs.getString("udf_5"));
	                template.setUdf6(rs.getString("udf_6"));
	                template.setUdf7(rs.getString("udf_7"));
	                template.setUdf8(rs.getString("udf_8"));
	                template.setUdf9(rs.getString("udf_9"));
	                template.setUdf10(rs.getString("udf_10"));
	                template.setUdf11(rs.getString("udf_11"));
	                template.setUdf12(rs.getString("udf_12"));
	                template.setUdf13(rs.getString("udf_13"));
	                template.setUdf14(rs.getString("udf_14"));
	                template.setUdf15(rs.getString("udf_15"));
	                template.setUdf16(rs.getString("udf_16"));
	                template.setUdf17(rs.getString("udf_17"));
	                template.setUdf18(rs.getString("udf_18"));
	                template.setUdf19(rs.getString("udf_19"));
	                template.setUdf20(rs.getString("udf_20"));
	                listOFBatchData.add(template);
	            }
	            return listOFBatchData;
	        }
	    });

}

	@Override
	public int checkIfInvoiceDetailExits(ItcDto rowData) {
		
		return jdbcTemplateTrn.queryForObject("INV".equals(rowData.getDocType())?CommunicationSQL.COUNTPAYMENTDATA:CommunicationSQL.COUNTPAYMENTDATAINDNR,Integer.class
				,rowData.getInwardNo(),rowData.getGstinUinOfRecipient(),rowData.getGstinOfSupplier());
		
	}

	@Override
	public void updateItcDetailsInInward(List<ItcDto> sucessItcDtoTemplateDTOsList) {
	
		sucessItcDtoTemplateDTOsList.forEach(rowData->
		{
			jdbcTemplateTrn.update("INV".equals(rowData.getDocType())?CommunicationSQL.UPDATEINVINWARD:CommunicationSQL.UPDATECDNINWARD,
					rowData.getReversalIndicator(),rowData.getReversalPercentage(),rowData.getGstinUinOfRecipient(),
					rowData.getGstinOfSupplier(),rowData.getInwardNo(),rowData.getInwardDate());
		});	    
	}


	 @Override
	    public int getInwardResultFPCount(String gstinUinOfRecipient, String inwardNo, String inwardDate,
	                    String gstinOfSupplier, String fp, String yearId) {

	        final String methodName = "";

	        log.info(Constants.LOGMESSAGE, methodName);
	        try {

	            String sqlstr = CommunicationSQL.getItcResultSql( inwardDate, gstinOfSupplier, fp, yearId,
	                            mstDatabaseName, trnDatabaseName);

	            return jdbcTemplateTrn.queryForObject(sqlstr, Integer.class, gstinUinOfRecipient, gstinOfSupplier, yearId,
	                            fp, inwardNo);

	        } catch (Exception ex) {
	            log.error(Constants.LOGERRORMESSAGE, methodName);
	            return 0;
	        }

	    }


	 @Override
	    public List<String> getDuplicateFPInDiffMonth(String gstinOfSupplier, String gstinUinOfRecipient, String yearId,
	                    String fp) {

	        String sqlString = CommunicationSQL.getItcDuplicateFPQuery(trnDatabaseName, mstDatabaseName);

	        return jdbcTemplateTrn.queryForList(sqlString, String.class, gstinUinOfRecipient, yearId, fp);

	    }

	

}
