package com.bdo.bvms.common.service;

import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNReqDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.AzureUploadDownloadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface UploadNDownloadFileService {

	String uploadFileToAzureBlob(MultipartFile file, InwardInvoiceCDNReqDTO apiRequestDTO, String batchNo,
			AzureConnectionCredentialsDTO credentialMap) throws VendorInvoiceServerException;

	void downloadFileFromAzureBlob(String fileName, String targetPath, AzureConnectionCredentialsDTO map) throws VendorInvoiceServerException;

	void uploadErrorFile(UploadReqDTO uploadDTO, AzureConnectionCredentialsDTO map);

	void uploadSftpFileToAzureBlob(InwardInvoiceCDNReqDTO uploadRequestDTO, String batchNo,
			AzureConnectionCredentialsDTO storageCredentials) throws AzureUploadDownloadException;

}
