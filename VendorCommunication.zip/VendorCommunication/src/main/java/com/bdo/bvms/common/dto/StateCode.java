package com.bdo.bvms.common.dto;

import java.io.Serializable;

/**
 *FileType: java
 *Author : anka
 *Created On : 02/11/2017 6:56:39 PM
 *Copy Rights : Anka Technology Solutions Pvt. Ltd.
 */
public class StateCode implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer state_master_id;
	private String state_name;
	private String state_code;

	public StateCode() {
		//
	}

	public StateCode(Integer state_master_id, String state_name, String state_code) {
		this.state_master_id = state_master_id;
		this.state_name = state_name;
		this.state_code = state_code;
	}

	public Integer getState_master_id() {
		return state_master_id;
	}

	public void setState_master_id(Integer state_master_id) {
		this.state_master_id = state_master_id;
	}

	public String getState_name() {
		return state_name;
	}

	public void setState_name(String state_name) {
		this.state_name = state_name;
	}

	public String getState_code() {
		return state_code;
	}

	public void setState_code(String state_code) {
		this.state_code = state_code;
	}
	
	@Override
	public String toString() {
		return "StateCode [state_master_id=" + state_master_id + ", state_name=" + state_name + ", state_code=" + state_code + "]";
	}
}
