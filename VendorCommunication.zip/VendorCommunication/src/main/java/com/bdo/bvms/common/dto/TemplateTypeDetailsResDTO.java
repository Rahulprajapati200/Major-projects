package com.bdo.bvms.common.dto;

import java.util.Date;

import com.bdo.bvms.common.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TemplateTypeDetailsResDTO {
	
	private Integer id;
	private String name;
	private String templateUrl;
	private String uploadedBy;
	private String module;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI)
	private Date uploadedOn;
	
}
