package com.bdo.bvms.common.service;

import com.bdo.bvms.common.dto.InwardInvoiceCDNReqDTO;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface UploadService {

	String uploadAndProcessFile(InwardInvoiceCDNReqDTO uploadRequestDTO) throws VendorInvoiceServerException;

}
