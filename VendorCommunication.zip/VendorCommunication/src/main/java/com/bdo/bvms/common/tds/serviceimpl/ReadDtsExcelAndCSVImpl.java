package com.bdo.bvms.common.tds.serviceimpl;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.constant.StringConstant;
import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dao.UploadTransDao;

import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvalidTemplateHeaderException;
import com.bdo.bvms.common.exceptions.InvoiceTemplateUploadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.service.InwardUpload;
import com.bdo.bvms.common.tds.service.ReadDtsExcelAndCSV;
import com.bdo.bvms.common.util.AppUtil;
import com.csvreader.CsvReader;
import com.monitorjbl.xlsx.StreamingReader;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class ReadDtsExcelAndCSVImpl implements ReadDtsExcelAndCSV{

    Row headerRow = null;
	
	/** The col name index map. */
    Map<String, Integer> colNameIndexMap = new HashMap<>();
	
	@Value("${bvms.cloud.temp.file.download.path}")
	String tempFolder;

	@Autowired
	InwardUpload inwardUpload;
	
	@Autowired
    UploadTransDao uploadTransDao;
	
	@Override
	public void readDataFromExcel(UploadReqDTO uploadReqDTO, List<TdsDetails> tdsDetailsTemplateDTOList
			) throws InvoiceTemplateUploadException {

		
		String methodName="readDataFromExcel";
		StringBuilder filePath = new StringBuilder()
				.append(tempFolder + System.getProperty(StringConstant.FILESEPARATOR)).append(uploadReqDTO.getBatchNo())
				.append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
				.append(uploadReqDTO.getFileType());
		
		 Map<String, Object> rowCountWithHeader = new HashMap<>();
		 
		 try {
	            try (InputStream inputStream = new FileInputStream(new File(filePath.toString()));
	                            BufferedInputStream br = new BufferedInputStream(inputStream)) {
	                // getting HeaderRowIndexs , coumnsDataRow ,RowCount
	                rowCountWithHeader = getRowCountWithHeader(inputStream, uploadReqDTO);
	            }
	        } catch (Exception e2) {
	            log.error("Error in getEinvoiceDataList Method :" + e2);
	            uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(),Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
	            throw new InvoiceTemplateUploadException(e2.getMessage());
	        }
		 
		 headerRow = (Row) rowCountWithHeader.get(Constants.DATA_ROW);

	        try {
	            colNameIndexMap = AppUtil.getColumnNameIndexMap(headerRow);
	        } catch (Exception ex) {

	            log.error("Error in reading colNameIndexMap :" + ex);
	            uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(),
	                            Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
	            throw new InvoiceTemplateUploadException(ex.getMessage(), ex.getCause());
	        }

	        
	        validateValidTemplate(uploadReqDTO);
	        
	        try (InputStream in = new FileInputStream(new File(filePath.toString()));
                    BufferedInputStream bis = new BufferedInputStream(in);
                    Workbook workbook = StreamingReader.builder().open(bis);) {

        Sheet sheet = workbook.getSheetAt(0);

        sheet.forEach(row -> {
            TdsDetails xlsRow = new TdsDetails();
            if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 1) {
                xlsRow.setExcelRowId(row.getRowNum());
                
                try {
                    // reading Excel Template
                	xlsRow.setValid(true);
                    xlsRow = readTemplateRecord(row, colNameIndexMap, uploadReqDTO);
                    

                } catch (Exception e) {

                    markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
                    log.info("Exception in readTemplateRecord");
                }
                setTaxpayerPan(xlsRow);
                
                
                fixFilingPeriodSizeTo6(xlsRow);
            	tdsDetailsTemplateDTOList.add(xlsRow);
               
               
            }
        });
      
    } catch (Exception exception) {
        log.error(methodName + exception);
        throw new InvoiceTemplateUploadException(exception.getMessage(), exception);

    }


	}

	private void fixFilingPeriodSizeTo6(TdsDetails xlsRow) {
		if (xlsRow.getPeriodFilingTdsReturn().length() == 5) {
			xlsRow.setPeriodFilingTdsReturn(Constants.ZEROVALUE + xlsRow.getPeriodFilingTdsReturn());
		}
		
		if (xlsRow.getFilingPeriod().length() == 5) {
			xlsRow.setFilingPeriod(Constants.ZEROVALUE + xlsRow.getFilingPeriod());
		}
	}

	private void setTaxpayerPan(TdsDetails xlsRow) {
		if (StringUtils.isNotBlank(xlsRow.getGstinUinOfRecipient())
		                && xlsRow.getGstinUinOfRecipient().length() == 15) {
		    xlsRow.setPanOfRecipient(xlsRow.getGstinUinOfRecipient().substring(2, 12));

		} else {
		    xlsRow.setPanOfRecipient("");

		}
	}

	private void validateValidTemplate(UploadReqDTO uploadReqDTO) {
		if (Constants.TDS_TEMPLATE_HEADER_COUNT != colNameIndexMap.size()) {
		    log.error("Error in Header Not Mathching ");
		    uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(),
		                    Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);
		    throw new InvalidTemplateHeaderException(
		            StringConstant.HEADERCOUNTERRORMESSAGE + uploadReqDTO.getBatchNo());

		}
	}

	private void markErrorNAddErrorCode(TdsDetails rowData, String string, String string2) {
        rowData.setValid(false);
        rowData.setErrorCodeList(rowData.getErrorCodeList().append(string));
        rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(string2));

    }

	private TdsDetails readTemplateRecord(Row row, Map<String, Integer> colNameIndexMap2,
			UploadReqDTO uploadReqDTO) {

		TdsDetails xlsRow = new TdsDetails();

        log.info("Reading Cell from excel Rows field wise");

        try {

            xlsRow.setValid(true);
            xlsRow.setExcelRowId(row.getRowNum());
            
            xlsRow.setPanOfRecipient(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_PAN_RECIPIENT))).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setGstinUinOfRecipient(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT))).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setDocType(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.DOC_TYPE)))
            		.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setVendorCodeErp(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_VENDOR_CODE_ERP)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setGstinOfSupplier(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_GSTIN_OF_SUPPLIER)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setPanOfSupplier(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_PAN_OF_SUPPLIER)))
            		.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setSupplierName(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_SUPPLIER_NAME)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setDocNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_DOC_NO)))
            		.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setDocDate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_DOC_DATE)))
            		.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInwardNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_INWARD_NO)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInwardAate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_INWARD_DATE)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgAssAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_ASS_AMOUNT)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setAssAmt(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_ASS_AMOUNT)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            assAmountNonNumericCheck(xlsRow);
            xlsRow.setTdsSection(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.TDS_SECTION)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgTdsRate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.TDS_RATE)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setTdsRate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.TDS_RATE)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            validateItcRate(xlsRow);
            xlsRow.setOrgTdsTaxAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.TDS_TAX_AMOUNT)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setTdsTaxAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.TDS_TAX_AMOUNT)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            checkNumericTdsTaxAmount(xlsRow);
            xlsRow.setOrgGrossAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.GROSS_AMOUNT)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setGrossAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.GROSS_AMOUNT)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            checkNumericGrossAmount(xlsRow);
            xlsRow.setDateofPayment(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.DATE_OF_PAYMENT)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInvoiceAgainstProvAdv(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.INVOICE_AGAINST_PROV_ADV)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInwardNoProvAdv(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.INWARD_NO_PROV_ADV)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgPaymentAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.PAYMENT_AMOUNT))).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setPaymentAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.PAYMENT_AMOUNT))).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            checkNumeicPaymentAmount(xlsRow);
                    
            xlsRow.setPaymentRefNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.PAYMENT_REF_NO)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setChallanAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.CHALLAN_AMOUNT)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgChallanAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.CHALLAN_AMOUNT)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            numericChallanAMount(xlsRow);
            xlsRow.setChallanNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.CHALLAN_NUMBER)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setChallanDate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.CHALLAN_DATE)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setPeriodFilingTdsReturn(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.PERIOD_OF_FILLING)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInwardDateprovAdv(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.INWARD_DATE_PROV_ADV)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgAmountofProvAdv(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.AMOUNT_OF_PROV_ADV)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setAmountofProvAdv(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.AMOUNT_OF_PROV_ADV)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            numericAmountOfProvAdv(xlsRow);
            xlsRow.setOrgBalOutstanding(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.BAL_OUTSTANDING)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setBalOutstanding(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.BAL_OUTSTANDING)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            numericBalOutStanding(xlsRow);
            xlsRow.setCreditglId(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_CREDIT_GL_ID)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setCreditglName(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_CREDIT_GL_NAME)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setDebitglId(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_DEBIT_GL_ID)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setDebitglName(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_DEBIT_GL_NAME)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setFilingPeriod(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.FILLING_PERIOD)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            
            xlsRow.setUdf1(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_1")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf2(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_2")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf3(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_3")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf4(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_4")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf5(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_5")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf6(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_6")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf7(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_7")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf8(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_8")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf9(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_9")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf10(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_10")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            
            xlsRow.setUdf11(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_11")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf12(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_12")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf13(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_13")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf14(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_14")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf15(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_15")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf16(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_16")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf17(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_17")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf18(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_18")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf19(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_19")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf20(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_20")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
 
        } catch (Exception ex) {
            // Mark as not Valid object if Exception occur
            log.error("Error generated:", ex);
            xlsRow.setValid(false);
            log.error("Errro occured while reading row " + row.getRowNum() + " for batch No. " + ex);
        }
        return xlsRow;
    }

	private void assAmountNonNumericCheck(TdsDetails xlsRow) {
		if(!isNumeric(xlsRow.getAssAmt())) {
		if(StringUtils.isBlank(xlsRow.getAssAmt()))
    	{
			xlsRow.setAssAmt("0.0");
    	}
    	else
    	{
    		xlsRow.setAssAmt("0.0");
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00588, Constants.BLANK);
    	}
		}

	}

	@Override
	public void readCSVFile(UploadReqDTO uploadReqDTO, List<TdsDetails> tdsDetailsTemplateDTOList)
			throws VendorInvoiceServerException, IOException {
        int cnt = 0;
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadReqDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(uploadReqDTO.getFileType());

        CsvReader einvoices = new CsvReader(fileName.toString(), StringConstant.COMMASEPERATOR, StandardCharsets.UTF_8);
        CsvReader readHeaderCount = new CsvReader(fileName.toString(), StringConstant.COMMASEPERATOR,
                        StandardCharsets.UTF_8);

        // Add code if header is missing then mark as invalid template
        String[] indexHeaders = AppUtil.getHeaders(readHeaderCount);
        validateInvalidTemplate(uploadReqDTO, indexHeaders);

        einvoices.readHeaders();
        while (einvoices.readRecord()) {
        	TdsDetails paymentDetailsTemplateDTO = new TdsDetails();
            try {

                cnt++;
                if (cnt > 0) {
                	paymentDetailsTemplateDTO.setValid(true);
                	paymentDetailsTemplateDTO.setPanOfRecipient(einvoices.get(0)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setGstinUinOfRecipient(einvoices.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setDocType(einvoices.get(Constants.COLUMN_DOC_TYPE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setVendorCodeErp(einvoices.get(Constants.COLUMN_VENDOR_CODE_ERP)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setGstinOfSupplier(einvoices.get(Constants.COLUMN_GSTIN_OF_SUPPLIER)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setPanOfSupplier(einvoices.get(Constants.COLUMN_PAN_OF_SUPPLIER)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setSupplierName(einvoices.get(Constants.COLUMN_SUPPLIER_NAME)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setDocNo(einvoices.get(Constants.COLUMN_DOC_NO)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setDocDate(einvoices.get(Constants.COLUMN_DOC_DATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setInwardNo(einvoices.get(Constants.COLUMN_INWARD_NO)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setInwardAate(einvoices.get(Constants.COLUMN_INWARD_DATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setOrgAssAmount(einvoices.get(Constants.COLUMN_ASS_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setAssAmt(einvoices.get(Constants.COLUMN_ASS_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	 assAmountNonNumericCheck(paymentDetailsTemplateDTO);
                	paymentDetailsTemplateDTO.setTdsSection(einvoices.get(Constants.TDS_SECTION)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setOrgTdsRate(einvoices.get(Constants.TDS_RATE)
                             .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
         
                	paymentDetailsTemplateDTO.setTdsRate(einvoices.get(Constants.TDS_RATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	validateItcRate(paymentDetailsTemplateDTO);
                	paymentDetailsTemplateDTO.setOrgTdsTaxAmount(einvoices.get(Constants.TDS_TAX_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setTdsTaxAmount(einvoices.get(Constants.TDS_TAX_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	checkNumericTdsTaxAmount(paymentDetailsTemplateDTO);
                	paymentDetailsTemplateDTO.setOrgGrossAmount(einvoices.get(Constants.GROSS_AMOUNT)
                             .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setGrossAmount(einvoices.get(Constants.GROSS_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	checkNumericGrossAmount(paymentDetailsTemplateDTO);
                	paymentDetailsTemplateDTO.setDateofPayment(einvoices.get(Constants.PAYMENT_DATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setPaymentRefNo(einvoices.get(Constants.PAYMENT_REF_NO)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setOrgPaymentAmount(einvoices.get(Constants.PAYMENT_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setPaymentAmount(einvoices.get(Constants.PAYMENT_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	checkNumeicPaymentAmount(paymentDetailsTemplateDTO);
                	paymentDetailsTemplateDTO.setOrgChallanAmount(einvoices.get(Constants.CHALLAN_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setChallanAmount(einvoices.get(Constants.CHALLAN_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	numericChallanAMount(paymentDetailsTemplateDTO);
                	paymentDetailsTemplateDTO.setChallanDate(einvoices.get(Constants.CHALLAN_DATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setChallanNo(einvoices.get(Constants.CHALLAN_NUMBER)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setPeriodFilingTdsReturn(einvoices.get(Constants.PERIOD_OF_FILLING)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setFilingPeriod(einvoices.get(Constants.FILLING_PERIOD)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setInvoiceAgainstProvAdv(einvoices.get(Constants.INVOICE_AGAINST_PROV_ADV)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setInwardNoProvAdv(einvoices.get(Constants.INWARD_NO_PROV_ADV)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setInwardDateprovAdv(einvoices.get(Constants.INWARD_DATE_PROV_ADV)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setOrgAmountofProvAdv(einvoices.get(Constants.AMOUNT_OF_PROV_ADV)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setAmountofProvAdv(einvoices.get(Constants.AMOUNT_OF_PROV_ADV)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	numericAmountOfProvAdv(paymentDetailsTemplateDTO);
                	paymentDetailsTemplateDTO.setOrgBalOutstanding(einvoices.get(Constants.BAL_OUTSTANDING)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setBalOutstanding(einvoices.get(Constants.BAL_OUTSTANDING)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	numericBalOutStanding(paymentDetailsTemplateDTO);
                	paymentDetailsTemplateDTO.setCreditglId(einvoices.get(Constants.COLUMN_CREDIT_GL_ID)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setCreditglName(einvoices.get(Constants.COLUMN_CREDIT_GL_NAME)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setDebitglId(einvoices.get(Constants.COLUMN_DEBIT_GL_ID)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setDebitglName(einvoices.get(Constants.COLUMN_DEBIT_GL_NAME)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf1(einvoices.get(Constants.COLUMN_UDF_1)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf2(einvoices.get(Constants.COLUMN_UDF_2)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf3(einvoices.get(Constants.COLUMN_UDF_3)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf4(einvoices.get(Constants.COLUMN_UDF_4)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf5(einvoices.get(Constants.COLUMN_UDF_5)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf6(einvoices.get(Constants.COLUMN_UDF_6)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf7(einvoices.get(Constants.COLUMN_UDF_7)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf8(einvoices.get(Constants.COLUMN_UDF_8)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf9(einvoices.get(Constants.COLUMN_UDF_9)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf10(einvoices.get(Constants.COLUMN_UDF_10)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	
                    
                	paymentDetailsTemplateDTO.setUdf11(einvoices.get(Constants.COLUMN_UDF_11)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf12(einvoices.get(Constants.COLUMN_UDF_12)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf13(einvoices.get(Constants.COLUMN_UDF_13)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf14(einvoices.get(Constants.COLUMN_UDF_14)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf15(einvoices.get(Constants.COLUMN_UDF_15)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf16(einvoices.get(Constants.COLUMN_UDF_16)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf17(einvoices.get(Constants.COLUMN_UDF_17)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf18(einvoices.get(Constants.COLUMN_UDF_18)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf19(einvoices.get(Constants.COLUMN_UDF_19)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf20(einvoices.get(Constants.COLUMN_UDF_20)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	
                	setTaxpayerPan(paymentDetailsTemplateDTO);
	                
                	fixFilingPeriodSizeTo6(paymentDetailsTemplateDTO);
                	tdsDetailsTemplateDTOList.add(paymentDetailsTemplateDTO);
                        
                     

                }
                
              
            } catch (Exception ex) {

                log.error("Error generated:", ex);
                markErrorNAddErrorCode(paymentDetailsTemplateDTO, ValidationConstant.EINVOICE_ERROR_CODE_DE1000,
                                Constants.BLANK);
            }
        }

    }

	private void numericBalOutStanding(TdsDetails paymentDetailsTemplateDTO) {
		if(!isNumeric(paymentDetailsTemplateDTO.getBalOutstanding()))
		{
			if(StringUtils.isBlank(paymentDetailsTemplateDTO.getBalOutstanding()))
        	{
				paymentDetailsTemplateDTO.setBalOutstanding("0.0");
        	}
        	else
        	{
        		paymentDetailsTemplateDTO.setBalOutstanding("0.0");
        		markErrorNAddErrorCode(paymentDetailsTemplateDTO, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00595, Constants.BLANK);
        	}
		}
	}

	private void numericAmountOfProvAdv(TdsDetails paymentDetailsTemplateDTO) {
		if(!isNumeric(paymentDetailsTemplateDTO.getAmountofProvAdv()))
		{
			if(StringUtils.isBlank(paymentDetailsTemplateDTO.getAmountofProvAdv()))
        	{
				paymentDetailsTemplateDTO.setAmountofProvAdv("0.0");
        	}
        	else
        	{
        		paymentDetailsTemplateDTO.setAmountofProvAdv("0.0");
        		markErrorNAddErrorCode(paymentDetailsTemplateDTO, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00536, Constants.BLANK);
        	}
		}
	}

	private void numericChallanAMount(TdsDetails paymentDetailsTemplateDTO) {
		if(!isNumeric(paymentDetailsTemplateDTO.getChallanAmount()))
		{
			if(StringUtils.isBlank(paymentDetailsTemplateDTO.getChallanAmount()))
        	{
				paymentDetailsTemplateDTO.setChallanAmount("0.0");
        	}
        	else
        	{
        		paymentDetailsTemplateDTO.setChallanAmount("0.0");
        		markErrorNAddErrorCode(paymentDetailsTemplateDTO, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00531, Constants.BLANK);
        	}
		}
	}

	private void checkNumeicPaymentAmount(TdsDetails paymentDetailsTemplateDTO) {
		if(!isNumeric(paymentDetailsTemplateDTO.getPaymentAmount()))
		{
			if(StringUtils.isBlank(paymentDetailsTemplateDTO.getPaymentAmount()))
        	{
				paymentDetailsTemplateDTO.setPaymentAmount("0.0");
        	}
        	else
        	{
        		paymentDetailsTemplateDTO.setPaymentAmount("0.0");
        		markErrorNAddErrorCode(paymentDetailsTemplateDTO, ValidationConstant.EINVOICE_ERROR_CODE_I50031, Constants.BLANK);
        	}
		}
	}

	private void checkNumericGrossAmount(TdsDetails paymentDetailsTemplateDTO) {
		if(!isNumeric(paymentDetailsTemplateDTO.getGrossAmount()))
		{
			if(StringUtils.isBlank(paymentDetailsTemplateDTO.getGrossAmount()))
        	{
				paymentDetailsTemplateDTO.setGrossAmount("0.0");
        	}
        	else
        	{
        		paymentDetailsTemplateDTO.setGrossAmount("0.0");
        		markErrorNAddErrorCode(paymentDetailsTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00039, Constants.BLANK);	
        	}

		}
	}

	private void checkNumericTdsTaxAmount(TdsDetails paymentDetailsTemplateDTO) {
		if(!isNumeric(paymentDetailsTemplateDTO.getTdsTaxAmount()))
		{
			if(StringUtils.isBlank(paymentDetailsTemplateDTO.getTdsTaxAmount()))
        	{
				paymentDetailsTemplateDTO.setTdsTaxAmount("0.0");
        	}
        	else
        	{
        		paymentDetailsTemplateDTO.setTdsTaxAmount("0.0");
        		markErrorNAddErrorCode(paymentDetailsTemplateDTO, ValidationConstant.EINVOICE_ERROR_CODE_E00528, Constants.BLANK);
        	}
		}
	}

	private void validateItcRate(TdsDetails paymentDetailsTemplateDTO) {
		if(!isNumeric(paymentDetailsTemplateDTO.getTdsRate()))
		{
		if(StringUtils.isBlank(paymentDetailsTemplateDTO.getTdsRate()))
    	{
			paymentDetailsTemplateDTO.setTdsRate("0.0");
    	}
    	else
    	{
    		paymentDetailsTemplateDTO.setTdsRate("0.0");
    		markErrorNAddErrorCode(paymentDetailsTemplateDTO, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00563, Constants.BLANK);
    	}
		}
	}

	private void validateInvalidTemplate(UploadReqDTO uploadReqDTO, String[] indexHeaders)
			throws VendorInvoiceServerException {
		if (Constants.TDS_TEMPLATE_HEADER_COUNT != indexHeaders.length) {

            uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);

            throw new VendorInvoiceServerException(
                            StringConstant.HEADERCOUNTERRORMESSAGE + uploadReqDTO.getBatchNo());

        }
	}
	
	public Map<String, Object> getRowCountWithHeader(InputStream inputStream, UploadReqDTO uploadRequestDTO)
            throws VendorInvoiceServerException {
Map<String, Object> dataMap = new HashMap<>();
int totalRowCount = 0;
try (InputStream is = new BufferedInputStream(inputStream);
                Workbook workbook = StreamingReader.builder().open(is);) {

    Sheet sheet = workbook.getSheetAt(0);
    for (Row row : sheet) {
        if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 1) {
            totalRowCount++;
        } else if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() <= 1 && totalRowCount == 0) {

            Row coumnsDataRow = null;
            coumnsDataRow = row;
            dataMap.put("headerRowIndex", row.getRowNum());
            dataMap.put("coumnsDataRow", coumnsDataRow);

        }

    }
    dataMap.put("RowCount", totalRowCount);
} catch (Exception ex) {

    log.error("getRowCountWithHeader Error " + ex);
    throw new VendorInvoiceServerException(
                    Constants.ERRORINREADINGHEADECOUNT+ uploadRequestDTO.getBatchNo());

}
return dataMap;

}
	
	public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

}
