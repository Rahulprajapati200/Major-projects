package com.bdo.bvms.common.tds.serviceimpl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.BDOException;
import com.bdo.bvms.common.tds.service.WriteTdsErrorAndSuccessCsv;
import com.bdo.bvms.common.util.CommonUtils;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class WriteTdsErrorAndSuccessCsvImpl implements WriteTdsErrorAndSuccessCsv{

	@Value("${bvms.cloud.temp.file.download.path}")
    String tempFolder;
	
	@Override
	public void writeSuccessNErrorDataInCSVFile(UploadReqDTO uploadReqDTO,
			List<TdsDetails> errorTdsDetailsTemplateDTOsList, List<TdsDetails> sucessTdsDetailsTemplateDTOsList) throws IOException, BDOException {

		


        String methodName = " writeSuccessNErrorDataInCSVFile";
        String csvPaymentSuccessFilePath = CommonUtils.getPaymentSuccessFilePath(uploadReqDTO, tempFolder);
        String csvPaymentErrorFilePath = CommonUtils.getPaymentErrorFilePath(uploadReqDTO, tempFolder);
        InputStream validINVStream = null;

        // Method for CSV writing
        validINVStream = csvPaymentDetailsSuccess(uploadReqDTO, sucessTdsDetailsTemplateDTOsList);
        Files.copy(validINVStream, Paths.get(csvPaymentSuccessFilePath));

        InputStream validCDNStream = null;
        validCDNStream = csvPaymentDetailsError(uploadReqDTO, errorTdsDetailsTemplateDTOsList);
        Files.copy(validCDNStream, Paths.get(csvPaymentErrorFilePath));

       
        log.info(Constants.LOGMESSAGE, methodName);
    

	
		
	}

	private InputStream csvPaymentDetailsError(UploadReqDTO uploadReqDTO,
			List<TdsDetails> errorTdsDetailsTemplateDTOsList) throws BDOException {

        log.info("Entering einvoiceExcelDataToCSV method");

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<String> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {

            list = Stream.of(Constants.ID,Constants.COLUMN_PAN_RECIPIENT ,Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT,
            		Constants.COLUMN_DOC_TYPE,Constants.COLUMN_VENDOR_CODE_ERP ,
            		Constants.COLUMN_GSTIN_OF_SUPPLIER,Constants.COLUMN_PAN_OF_SUPPLIER,
            		Constants.COLUMN_SUPPLIER_NAME,Constants.COLUMN_DOC_NO,Constants.COLUMN_DOC_DATE,
            		Constants.COLUMN_INWARD_NO,Constants.COLUMN_INWARD_DATE, 
            		Constants.COLUMN_ASS_AMOUNT,Constants.TDS_SECTION,Constants.TDS_RATE,
            		Constants.TDS_TAX_AMOUNT,Constants.GROSS_AMOUNT,
            		Constants.DATE_OF_PAYMENT,Constants.PAYMENT_REF_NO,Constants.PAYMENT_AMOUNT,
            		Constants.CHALLAN_NUMBER,Constants.CHALLAN_DATE,Constants.CHALLAN_AMOUNT,
            		Constants.PERIOD_OF_FILLING,
            		Constants.INVOICE_AGAINST_PROV_ADV,Constants.INWARD_NO_PROV_ADV,
            		Constants.INWARD_DATE_PROV_ADV,Constants.AMOUNT_OF_PROV_ADV,
            		Constants.BAL_OUTSTANDING,Constants.COLUMN_DEBIT_GL_ID,Constants.COLUMN_DEBIT_GL_NAME,
            		Constants.COLUMN_CREDIT_GL_ID,Constants.COLUMN_CREDIT_GL_NAME,Constants.PERIOD_OF_FILLING,Constants.UUID,Constants.BATCH_NO,
            		Constants.ERROR_CODE_LIST,Constants.ERROR_DESCRIPTION,Constants.CREATED_AT,Constants.CREATED_BY,Constants.ROWVERSION
            		, Constants.COLUMN_UDF_1,
                            Constants.COLUMN_UDF_2, Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4,
                            Constants.COLUMN_UDF_5, Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7,
                            Constants.COLUMN_UDF_8, Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10,
                            Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13,
                            Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16,
                            Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19,

                            Constants.COLUMN_UDF_20).collect(Collectors.toList());
            csvPrinter.printRecord(list);
            if (!errorTdsDetailsTemplateDTOsList.isEmpty()) {
                
                for (TdsDetails paymentTemplateDto : errorTdsDetailsTemplateDTOsList) {
                	List<Object> data = Arrays.asList(Constants.BLANK, paymentTemplateDto.getPanOfRecipient(),paymentTemplateDto.getGstinUinOfRecipient(),
                                    paymentTemplateDto.getDocType(),paymentTemplateDto.getVendorCodeErp(), paymentTemplateDto.getGstinOfSupplier(),
                                    paymentTemplateDto.getPanOfSupplier(),paymentTemplateDto.getSupplierName(),paymentTemplateDto.getDocNo(),paymentTemplateDto.getDocDate(),
                                     paymentTemplateDto.getInwardNo(),
                                    paymentTemplateDto.getInwardAate(),
                                    paymentTemplateDto.getOrgAssAmount(),paymentTemplateDto.getTdsSection(),paymentTemplateDto.getOrgTdsRate(),
                                    paymentTemplateDto.getOrgTdsTaxAmount(),paymentTemplateDto.getOrgGrossAmount(),
                                    paymentTemplateDto.getDateofPayment(),paymentTemplateDto.getPaymentRefNo(),paymentTemplateDto.getOrgPaymentAmount(),
                                    paymentTemplateDto.getChallanNo(),paymentTemplateDto.getChallanDate(),paymentTemplateDto.getOrgChallanAmount(),
                                    paymentTemplateDto.getPeriodFilingTdsReturn(),
                                    paymentTemplateDto.getInvoiceAgainstProvAdv(),paymentTemplateDto.getInwardNoProvAdv(),
                                    paymentTemplateDto.getInwardDateprovAdv(),
                                    paymentTemplateDto.getOrgAmountofProvAdv(),
                                    paymentTemplateDto.getOrgBalOutstanding(),paymentTemplateDto.getDebitglId(),paymentTemplateDto.getDebitglName(),
                                    paymentTemplateDto.getCreditglId(),paymentTemplateDto.getCreditglName(),paymentTemplateDto.getFilingPeriod(),(paymentTemplateDto.getGstinUinOfRecipient()+paymentTemplateDto.getGstinOfSupplier()+paymentTemplateDto.getInwardNo()).hashCode(),uploadReqDTO.getBatchNo(),
                                    paymentTemplateDto.getErrorCodeList(),paymentTemplateDto.getErrorDescriptionList(),Timestamp.from(Instant.now()),uploadReqDTO.getUserId(),
                                    Timestamp.from(Instant.now()),
                                    paymentTemplateDto.getUdf1(),
                                    paymentTemplateDto.getUdf2(), paymentTemplateDto.getUdf3(),
                                    paymentTemplateDto.getUdf4(), paymentTemplateDto.getUdf5(),
                                    paymentTemplateDto.getUdf6(), paymentTemplateDto.getUdf7(),
                                    paymentTemplateDto.getUdf8(), paymentTemplateDto.getUdf9(),
                                    paymentTemplateDto.getUdf10(),
                                    paymentTemplateDto.getUdf11(), paymentTemplateDto.getUdf12(), paymentTemplateDto.getUdf13(),
                                    paymentTemplateDto.getUdf14(), paymentTemplateDto.getUdf15(), paymentTemplateDto.getUdf16(), paymentTemplateDto.getUdf17(),
                                    paymentTemplateDto.getUdf18(), paymentTemplateDto.getUdf19(), paymentTemplateDto.getUdf20()
                                    );
                    csvPrinter.printRecord(data);
                    log.info("Size of CVS is " + data.size());
                }
            }
        	csvPrinter.flush();
            log.info("Got the finalCSV File");
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error("fail to import data to CSV file" + e);
            throw new BDOException("fail to import data to CSV file: " + e.getMessage());
        }
    }

	private InputStream csvPaymentDetailsSuccess(UploadReqDTO uploadReqDTO,
			List<TdsDetails> sucessTdsDetailsTemplateDTOsList) throws BDOException {

        log.info("Entering einvoiceExcelDataToCSV method");

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<String> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {

            list = Stream.of(Constants.ID,Constants.COLUMN_PAN_RECIPIENT ,Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT,
            		Constants.COLUMN_DOC_TYPE,Constants.COLUMN_VENDOR_CODE_ERP ,
            		Constants.COLUMN_GSTIN_OF_SUPPLIER,Constants.COLUMN_PAN_OF_SUPPLIER,
            		Constants.COLUMN_SUPPLIER_NAME,Constants.COLUMN_DOC_NO,Constants.COLUMN_DOC_DATE,
            		Constants.COLUMN_INWARD_NO,Constants.COLUMN_INWARD_DATE, 
            		Constants.COLUMN_ASS_AMOUNT,Constants.TDS_SECTION,Constants.TDS_RATE,
            		Constants.TDS_TAX_AMOUNT,Constants.GROSS_AMOUNT,
            		Constants.DATE_OF_PAYMENT,Constants.PAYMENT_REF_NO,Constants.PAYMENT_AMOUNT,
            		Constants.CHALLAN_NUMBER,Constants.CHALLAN_DATE,Constants.CHALLAN_AMOUNT,
            		Constants.PERIOD_OF_FILLING,
            		Constants.INVOICE_AGAINST_PROV_ADV,Constants.INWARD_NO_PROV_ADV,
            		Constants.INWARD_DATE_PROV_ADV,Constants.AMOUNT_OF_PROV_ADV,
            		Constants.BAL_OUTSTANDING,Constants.COLUMN_DEBIT_GL_ID,Constants.COLUMN_DEBIT_GL_NAME,
            		Constants.COLUMN_CREDIT_GL_ID,Constants.COLUMN_CREDIT_GL_NAME,Constants.PERIOD_OF_FILLING,
            		Constants.UUID,Constants.BATCH_NO,Constants.CREATED_AT,Constants.CREATED_BY ,Constants.ROWVERSION,Constants.COLUMN_UDF_1,
                            Constants.COLUMN_UDF_2, Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4,
                            Constants.COLUMN_UDF_5, Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7,
                            Constants.COLUMN_UDF_8, Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10,
                            Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13,
                            Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16,
                            Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19,

                            Constants.COLUMN_UDF_20
                            ).collect(Collectors.toList());
            csvPrinter.printRecord(list);
            
            if (!sucessTdsDetailsTemplateDTOsList.isEmpty()) {
                
                for (TdsDetails paymentTemplateDto : sucessTdsDetailsTemplateDTOsList) {
                	List<Object> data = Arrays.asList(Constants.BLANK, paymentTemplateDto.getPanOfRecipient(),paymentTemplateDto.getGstinUinOfRecipient(),
                                    paymentTemplateDto.getDocType(),paymentTemplateDto.getVendorCodeErp(), paymentTemplateDto.getGstinOfSupplier(),
                                    paymentTemplateDto.getPanOfSupplier(),paymentTemplateDto.getSupplierName(),paymentTemplateDto.getDocNo(),paymentTemplateDto.getDocDate(),
                                     paymentTemplateDto.getInwardNo(),
                                    paymentTemplateDto.getInwardAate(),
                                    paymentTemplateDto.getAssAmt(),paymentTemplateDto.getTdsSection(),paymentTemplateDto.getTdsRate(),
                                    paymentTemplateDto.getTdsTaxAmount(),paymentTemplateDto.getGrossAmount(),
                                    paymentTemplateDto.getDateofPayment(),paymentTemplateDto.getPaymentRefNo(),paymentTemplateDto.getPaymentAmount(),
                                    paymentTemplateDto.getChallanNo(),paymentTemplateDto.getChallanDate(),paymentTemplateDto.getChallanAmount(),
                                    paymentTemplateDto.getPeriodFilingTdsReturn(),
                                    paymentTemplateDto.getInvoiceAgainstProvAdv(),paymentTemplateDto.getInwardNoProvAdv(),
                                    paymentTemplateDto.getInwardDateprovAdv(),
                                    paymentTemplateDto.getAmountofProvAdv(),
                                    paymentTemplateDto.getBalOutstanding(),paymentTemplateDto.getDebitglId(),paymentTemplateDto.getDebitglName(),
                                    paymentTemplateDto.getCreditglId(),paymentTemplateDto.getCreditglName(),paymentTemplateDto.getFilingPeriod(),(paymentTemplateDto.getGstinUinOfRecipient()+paymentTemplateDto.getGstinOfSupplier()+paymentTemplateDto.getInwardNo()).hashCode(),uploadReqDTO.getBatchNo(),
                                    Timestamp.from(Instant.now()),uploadReqDTO.getUserId(),Timestamp.from(Instant.now()),
                                    paymentTemplateDto.getUdf1(),
                                    paymentTemplateDto.getUdf2(), paymentTemplateDto.getUdf3(),
                                    paymentTemplateDto.getUdf4(), paymentTemplateDto.getUdf5(),
                                    paymentTemplateDto.getUdf6(), paymentTemplateDto.getUdf7(),
                                    paymentTemplateDto.getUdf8(), paymentTemplateDto.getUdf9(),
                                    paymentTemplateDto.getUdf10(),
                                    paymentTemplateDto.getUdf11(), paymentTemplateDto.getUdf12(), paymentTemplateDto.getUdf13(),
                                    paymentTemplateDto.getUdf14(), paymentTemplateDto.getUdf15(), paymentTemplateDto.getUdf16(), paymentTemplateDto.getUdf17(),
                                    paymentTemplateDto.getUdf18(), paymentTemplateDto.getUdf19(), paymentTemplateDto.getUdf20()
                                    );
                    csvPrinter.printRecord(data);
                    log.info("Size of CVS is " + data.size());
                }
            }
        	csvPrinter.flush();
            log.info("Got the finalCSV File");
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error("fail to import data to CSV file" + e);
            throw new BDOException("fail to import data to CSV file: " + e.getMessage());
        }
    }

	@Override
	public void writeAzureErrorDataInCSVFile(List<TdsDetails> errorDataListWithErrorCode, UploadReqDTO uploadRequestDTO,
			Map<String, String> codesMap) throws IOException, BDOException {
        String csvInvCdnErrorFilePath = CommonUtils.getAzureTdsErrorFilePath(uploadRequestDTO, tempFolder);
        InputStream errorCrnInvStream = null;

        String methodName = "";

        errorCrnInvStream = excelAzureDataToCSVCdnInvErrorFor(errorDataListWithErrorCode, codesMap);

        Files.copy(errorCrnInvStream, Paths.get(csvInvCdnErrorFilePath));
        log.info(Constants.LOGERRORMESSAGE, methodName);

    }

	private InputStream excelAzureDataToCSVCdnInvErrorFor(List<TdsDetails> errorDataListWithErrorCode,
			Map<String, String> codesMap) throws BDOException {

        log.info("Entering einvoiceExcelDataToCSV method");

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<String> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {

            list = Stream.of(Constants.ERROR_CODE_LIST,Constants.ERROR_DESCRIPTION,Constants.COLUMN_PAN_RECIPIENT ,Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT,
            		Constants.COLUMN_DOC_TYPE,Constants.COLUMN_VENDOR_CODE_ERP ,
            		Constants.COLUMN_GSTIN_OF_SUPPLIER,Constants.COLUMN_PAN_OF_SUPPLIER,
            		Constants.COLUMN_SUPPLIER_NAME,Constants.COLUMN_DOC_NO,Constants.COLUMN_DOC_DATE,
            		Constants.COLUMN_INWARD_NO,Constants.COLUMN_INWARD_DATE, 
            		Constants.COLUMN_ASS_AMOUNT,Constants.TDS_SECTION,Constants.TDS_RATE,
            		Constants.TDS_TAX_AMOUNT,Constants.GROSS_AMOUNT,
            		Constants.DATE_OF_PAYMENT,Constants.PAYMENT_REF_NO,Constants.PAYMENT_AMOUNT,
            		Constants.CHALLAN_NUMBER,Constants.CHALLAN_DATE,Constants.CHALLAN_AMOUNT,
            		Constants.PERIOD_OF_FILLING,
            		Constants.INVOICE_AGAINST_PROV_ADV,Constants.INWARD_NO_PROV_ADV,
            		Constants.INWARD_DATE_PROV_ADV,Constants.AMOUNT_OF_PROV_ADV,
            		Constants.BAL_OUTSTANDING,Constants.COLUMN_DEBIT_GL_ID,Constants.COLUMN_DEBIT_GL_NAME,
            		Constants.COLUMN_CREDIT_GL_ID,Constants.COLUMN_CREDIT_GL_NAME,Constants.FILLING_PERIOD,
            		 Constants.COLUMN_UDF_1,
                            Constants.COLUMN_UDF_2, Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4,
                            Constants.COLUMN_UDF_5, Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7,
                            Constants.COLUMN_UDF_8, Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10,
                            Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13,
                            Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16,
                            Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19,

                            Constants.COLUMN_UDF_20).collect(Collectors.toList());
            csvPrinter.printRecord(list);
            
            if (!errorDataListWithErrorCode.isEmpty()) {
                
                for (TdsDetails paymentTemplateDto : errorDataListWithErrorCode) {
                	List<Object> data = Arrays.asList(
                             paymentTemplateDto.getErrorCodeList(),getErrorCodeDescription(paymentTemplateDto.getErrorCodeList().toString(),codesMap),paymentTemplateDto.getPanOfRecipient(),paymentTemplateDto.getGstinUinOfRecipient(),
                                    paymentTemplateDto.getDocType(),paymentTemplateDto.getVendorCodeErp(), paymentTemplateDto.getGstinOfSupplier(),
                                    paymentTemplateDto.getPanOfSupplier(),paymentTemplateDto.getSupplierName(),paymentTemplateDto.getDocNo(),paymentTemplateDto.getDocDate(),
                                     paymentTemplateDto.getInwardNo(),
                                    paymentTemplateDto.getInwardAate(),
                                    paymentTemplateDto.getAssAmt(),paymentTemplateDto.getTdsSection(),paymentTemplateDto.getTdsRate(),
                                    paymentTemplateDto.getTdsTaxAmount(),paymentTemplateDto.getGrossAmount(),
                                    paymentTemplateDto.getDateofPayment(),paymentTemplateDto.getPaymentRefNo(),paymentTemplateDto.getPaymentAmount(),
                                    paymentTemplateDto.getChallanNo(),paymentTemplateDto.getChallanDate(),paymentTemplateDto.getChallanAmount(),
                                    paymentTemplateDto.getPeriodFilingTdsReturn(),
                                    paymentTemplateDto.getInvoiceAgainstProvAdv(),paymentTemplateDto.getInwardNoProvAdv(),
                                    paymentTemplateDto.getInwardDateprovAdv(),
                                    paymentTemplateDto.getAmountofProvAdv(),
                                    paymentTemplateDto.getBalOutstanding(),paymentTemplateDto.getDebitglId(),paymentTemplateDto.getDebitglName(),
                                    paymentTemplateDto.getCreditglId(),paymentTemplateDto.getCreditglName(),paymentTemplateDto.getFilingPeriod(),
                                    paymentTemplateDto.getUdf1(),
                                    paymentTemplateDto.getUdf2(), paymentTemplateDto.getUdf3(),
                                    paymentTemplateDto.getUdf4(), paymentTemplateDto.getUdf5(),
                                    paymentTemplateDto.getUdf6(), paymentTemplateDto.getUdf7(),
                                    paymentTemplateDto.getUdf8(), paymentTemplateDto.getUdf9(),
                                    paymentTemplateDto.getUdf10(),paymentTemplateDto.getUdf11(), paymentTemplateDto.getUdf12(), paymentTemplateDto.getUdf13(),
                                    paymentTemplateDto.getUdf14(), paymentTemplateDto.getUdf15(), paymentTemplateDto.getUdf16(), paymentTemplateDto.getUdf17(),
                                    paymentTemplateDto.getUdf18(), paymentTemplateDto.getUdf19(), paymentTemplateDto.getUdf20());
                    csvPrinter.printRecord(data);
                    log.info("Size of CVS is " + data.size());
                }
            }
        	csvPrinter.flush();
            log.info("Got the finalCSV File");
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error("fail to import data to CSV file" + e);
            throw new BDOException("fail to import data to CSV file: " + e.getMessage());
        }
    }
	
	String getErrorCodeDescription(String codes, Map<String, String> errorCodeMap) {

        StringBuilder strBuilder = new StringBuilder();
        String code = codes.replace("|", ",");
        String[] errorCodeList = code.split(",");

        if (errorCodeList.length > 1) {
            for (int i = 1; i < errorCodeList.length; i++) {
                String description = errorCodeMap.get(errorCodeList[i].trim());
                strBuilder.append("|" + description);

            }
        }
        return strBuilder.toString();
    }

}
