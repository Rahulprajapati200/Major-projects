package com.bdo.bvms.common.dto;

import java.io.Serializable;

/**
 *FileType: java
 *Author : anka
 *Created On : 02/11/2017 6:56:39 PM
 *Copy Rights : Anka Technology Solutions Pvt. Ltd.
 */
public class ValidationError implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String ErrorCode;
	private String LongDescription;
	private String ShortDescription;

	public ValidationError() {
		//
	}

	public ValidationError(Integer id, String ErrorCode, String LongDescription, String ShortDescription) {
		this.id = id;
		this.ErrorCode = ErrorCode;
		this.LongDescription = LongDescription;
		this.ShortDescription = ShortDescription;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getErrorCode() {
		return ErrorCode;
	}

	public void setErrorCode(String ErrorCode) {
		this.ErrorCode = ErrorCode;
	}

	public String getLongDescription() {
		return LongDescription;
	}

	public void setLongDescription(String LongDescription) {
		this.LongDescription = LongDescription;
	}
	
	public String getShortDescription() {
		return ShortDescription;
	}

	public void setShortDescription(String ShortDescription) {
		this.ShortDescription = ShortDescription;
	}

	@Override
	public String toString() {
		return "ValidationError [id=" + id + ", ErrorCode=" + ErrorCode + ", LongDescription=" + LongDescription + ", ShortDescription=" + ShortDescription + "]";
	}
}
