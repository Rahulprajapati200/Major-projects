package com.bdo.bvms.common.tds.service;

import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;

public interface TdsDetailValidate {

	void validateTdsDetails(List<TdsDetails> tdsDetailsTemplateDTOList, UploadReqDTO uploadReqDTO,
			List<TdsDetails> errorTdsDetailsTemplateDTOsList, List<TdsDetails> sucessTdsDetailsTemplateDTOsList,Map<String,String> yearIdMap);

}
