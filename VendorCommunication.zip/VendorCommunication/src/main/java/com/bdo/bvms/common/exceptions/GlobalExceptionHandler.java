/**
 * Copyright (C) 2020
 * @File          : GlobalExceptionHandler 
 * @Author        : Himanshu Jain
 * @Author        : Himanshu Jain
 * @Company       : BDO
 * @Date Created  : 07-Sept-2022
 * @Description   : Handle the business logic exceptions
 **/

package com.bdo.bvms.common.exceptions;

import java.sql.SQLException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.bdo.bvms.common.constant.StringConstant;
import com.bdo.bvms.common.dto.ExceptionDetailsDTO;

/**
 * The Class GlobalExceptionHandler.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	/**
	 * Resource not found excpetion handler.
	 * 
	 * @author Himanshu Jain
	 * @param ex      the exception
	 * @param request the request
	 * @return the response entity
	 */
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<Object> resourceNotFoundExcpetionHandler(ResourceNotFoundException ex, WebRequest request) {
		ExceptionDetailsDTO errorDetails = new ExceptionDetailsDTO(new Date(), ex.getMessage(),
				request.getDescription(false), false, "");
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(InvalidDataAccessApiUsageException.class)
	public ResponseEntity<Object> invalidDataAccessApiUsageException(ResourceNotFoundException ex, WebRequest request) {
		ExceptionDetailsDTO errorDetails = new ExceptionDetailsDTO(new Date(), ex.getMessage(),
				request.getDescription(false), false, StringConstant.DBEXCEPTION);
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}

	/**
	 * Connection exception.
	 * 
	 * @author bvps
	 * @param ex      the ex
	 * @param request the request
	 * @return the response entity
	 */
	//@ExceptionHandler(CommunicationException.class)
	public ResponseEntity<Object> connectionCommunicationException(ResourceNotFoundException ex, WebRequest request) {
		ExceptionDetailsDTO errorDetails = new ExceptionDetailsDTO(new Date(), ex.getMessage(),
				request.getDescription(false), false, StringConstant.DB_COMMUNICATION_ERROR);
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(SQLException.class)
	public ResponseEntity<Object> sqlException(ResourceNotFoundException ex, WebRequest request) {
		ExceptionDetailsDTO errorDetails = new ExceptionDetailsDTO(new Date(), ex.getMessage(),
				request.getDescription(false), false, StringConstant.DB_COMMUNICATION_ERROR);
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}

	/**
	 * Globle excpetion handler.
	 * 
	 * @author alokpandey
	 * @param ex      the ex
	 * @param request the request
	 * @return the response entity
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> globleExcpetionHandler(Exception ex, WebRequest request) {

		ResponseEntity<Object> responseEntity = null;
		ExceptionDetailsDTO errorDetails = null;
		if (ex instanceof BadSqlGrammarException) {

			errorDetails = new ExceptionDetailsDTO(new Date(), ex.getMessage(), request.getDescription(false), false,
					StringConstant.DBEXCEPTION);

			StringBuilder stringBuffer = new StringBuilder().append("SQL Exception Occured by executing script : ");

			if(logger.isErrorEnabled())
			{
			logger.error(stringBuffer.toString(), ex);
			}

			responseEntity = new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);

		} else if (ex instanceof UnAuthorizedUserException) {

			errorDetails = new ExceptionDetailsDTO(new Date(), ex.getMessage(), request.getDescription(false), false,
					"");
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("Un Authorized User Exception on ").append(ex.getMessage());

			responseEntity = new ResponseEntity<>(errorDetails, HttpStatus.UNAUTHORIZED);

		} else if (ex instanceof AppBusinessException) {

			errorDetails = new ExceptionDetailsDTO(new Date(), ex.getCause().getMessage(),
					request.getDescription(false), false, ex.getMessage());
			StringBuilder stringBuffer = new StringBuilder();
			stringBuffer.append("Business Exception Occured due to ").append(ex.getCause().getMessage());

			logger.debug(stringBuffer.toString());

			responseEntity = new ResponseEntity<>(errorDetails, HttpStatus.UNAUTHORIZED);

		} else {

			errorDetails = new ExceptionDetailsDTO(new Date(), ex.getMessage(), request.getDescription(false), false,
					"");

			logger.error("General Exception Raised, check stack track /n", ex);

			responseEntity = new ResponseEntity<>(errorDetails, HttpStatus.UNAUTHORIZED);
		}
		return responseEntity;

	}

}
