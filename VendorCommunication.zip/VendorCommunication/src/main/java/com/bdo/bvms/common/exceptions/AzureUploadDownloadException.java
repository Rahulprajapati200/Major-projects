package com.bdo.bvms.common.exceptions;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;
@ResponseStatus(value = HttpStatus.PRECONDITION_FAILED)
public class AzureUploadDownloadException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new business exception.
	 *
	 * @param message the message
	 */
	public AzureUploadDownloadException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new business exception.
	 *
	 * @param message the message
	 * @param cause   the cause
	 */
	public AzureUploadDownloadException(String message, Throwable cause) {

		super(message, cause);
	}

}
