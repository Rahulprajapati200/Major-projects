package com.bdo.bvms.common.config;
import java.io.File;
import java.io.FileInputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import com.azure.storage.blob.BlobClientBuilder;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.exceptions.VendorMasterBusinessException;
import com.bdo.bvms.common.model.EntityCloudCredentials;
import com.bdo.bvms.common.service.IEntityCloudCredentialsService;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.blob.BlobContainerPermissions;
import com.microsoft.azure.storage.blob.BlobContainerPublicAccessType;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@PropertySource(value={"classpath:application.properties"})
public class AzureClientProvider {

    static final Logger logger = LoggerFactory.getLogger(AzureClientProvider.class);
    private static final String CLASSNAME = "AzureConnectionValidation";

    @Autowired
	private IEntityCloudCredentialsService iEntityCloudCredentialsServiceImpl;
    
    public BlobClientBuilder getClient(AzureConnectionCredentialsDTO dto) {
        final String methodName = "getClient";
        try {
        	
            BlobClientBuilder client = new BlobClientBuilder();
            client.connectionString(dto.getUrl());
            client.containerName(dto.getContainerName());
            
            return client;
            
        } catch (Exception e) {
            log.error(CLASSNAME, methodName, e + "");
        }
        return null;
    }
    
    
	public String uploadToAzureBlob(File file, int entityId)  {
		String url = null;        
		try (FileInputStream inputStream = new FileInputStream(file)) {

			EntityCloudCredentials entityCloudCredentials = iEntityCloudCredentialsServiceImpl.getEntityCloudCredentials(entityId);

			createAndConfigureContainer(entityCloudCredentials);

			// Retrieve storage account from connection-string.
			CloudStorageAccount storageAccount = CloudStorageAccount.parse(entityCloudCredentials.getUrl());

			// Create the blob client.
			CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

			// Retrieve reference to a previously created container.
			CloudBlobContainer container = blobClient.getContainerReference(entityCloudCredentials.getContainerName());

			// Create or overwrite the blob with contents from a local file.
			CloudBlockBlob blob = container.getBlockBlobReference(file.getName());

			blob.upload(inputStream, file.length()); 

			url = file.getName();

		}catch(Exception e) {
			log.error("Exception in uploadToAzureBlob method ",e);
			throw new VendorMasterBusinessException("Error while uploading file to cloud storage", e);
		}
		return url;
	}
	
	public void createAndConfigureContainer(EntityCloudCredentials entityCloudCredentials)  {
		// Retrieve storage account from connection-string.
		CloudStorageAccount storageAccount;
		try {
			storageAccount = CloudStorageAccount.parse(entityCloudCredentials.getUrl());

			// Create the blob client.
			CloudBlobClient blobClient = storageAccount.createCloudBlobClient();

			// Get a reference to a container.
			// The container name must be lower case
			CloudBlobContainer container = blobClient.getContainerReference(entityCloudCredentials.getContainerName());

			container.createIfNotExists();

			// Create a permissions object.
			BlobContainerPermissions containerPermissions = new BlobContainerPermissions();

			// Include public access in the permissions object.
			containerPermissions.setPublicAccess(BlobContainerPublicAccessType.CONTAINER);

			// Set the permissions on the container.
			container.uploadPermissions(containerPermissions);

		} catch(Exception e) {
			log.error("Exception in createAndConfigureContainer method ",e);
			throw new VendorMasterBusinessException("Error while configuring cloud storage account", e);
		}
	}


}
