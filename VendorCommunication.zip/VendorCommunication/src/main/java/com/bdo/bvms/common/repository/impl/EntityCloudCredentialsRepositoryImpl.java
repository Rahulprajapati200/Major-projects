package com.bdo.bvms.common.repository.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.model.EntityCloudCredentials;
import com.bdo.bvms.common.repository.IEntityCloudCredentialsRepository;
import com.bdo.bvms.common.sql.CommonMstSQL;

@Repository
public class EntityCloudCredentialsRepositoryImpl implements IEntityCloudCredentialsRepository {

	@Autowired
	private JdbcTemplate jdbcTemplateMst;
	
	
	@Override
	public EntityCloudCredentials searchEntityCloudCredentials(int entityId) {
		return jdbcTemplateMst.queryForObject(CommonMstSQL.GET_ENTITY_CLOUD_CREDENTIALS_SQL,
				BeanPropertyRowMapper.newInstance(EntityCloudCredentials.class), entityId);
	}

}
