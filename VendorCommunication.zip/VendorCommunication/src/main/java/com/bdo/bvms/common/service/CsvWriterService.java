package com.bdo.bvms.common.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface CsvWriterService {

	void writeSuccessNErrorDataInCSVFile(UploadReqDTO uploadRequestDTO,
			List<InwardInvoiceCDNTemplateDTO> rowCRNSuccessPoJoList,
			List<InwardInvoiceCDNTemplateDTO> rowINVSuccessPoJoList,
			List<InwardInvoiceCDNTemplateDTO> rowErrorPoJoList,List<InwardInvoiceCDNTemplateDTO>rowErrorCdnPojoList) throws IOException, VendorInvoiceServerException;

	void writeAzureErrorDataInCSVFile(List<InwardInvoiceCDNTemplateDTO> errorDataListWithErrorCode,
			UploadReqDTO uploadRequestDTO, Map<String, String> codesMap) throws IOException, VendorInvoiceServerException;

}
