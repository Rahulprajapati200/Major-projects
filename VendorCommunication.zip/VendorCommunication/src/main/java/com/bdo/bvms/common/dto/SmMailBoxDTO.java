package com.bdo.bvms.common.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SmMailBoxDTO {
	String mailTo ; 
	String mailFrom;
	String mailCc;
	String mailSubject;  
	String mailBody;  
	String trials; 
	String disclaimer; 
	String errorSuccess;  
	String mailCreatedDate;  
	String mailCreater; 
	String mailSendDate; 
	String pldModuleId; 
	String attachmentPath; 
	String isHighImportance;
}
