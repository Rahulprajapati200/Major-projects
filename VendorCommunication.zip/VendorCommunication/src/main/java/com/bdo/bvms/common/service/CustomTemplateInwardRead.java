package com.bdo.bvms.common.service;

import java.util.List;

import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvoiceTemplateUploadException;

public interface CustomTemplateInwardRead {

	void readCustomTemplate(UploadReqDTO uploadRequestDTO,List<InwardInvoiceCDNTemplateDTO> invDataList, List<InwardInvoiceCDNTemplateDTO> cdnDataList, List<InwardInvoiceCDNTemplateDTO> docErrorDataList)
			throws InvoiceTemplateUploadException;

	
}
