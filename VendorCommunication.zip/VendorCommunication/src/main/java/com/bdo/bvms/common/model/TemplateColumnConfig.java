package com.bdo.bvms.common.model;

import java.util.Date;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TemplateColumnConfig {
	
	Integer id;
	Integer pldTemplateId;
	String columnName;
	String dataType;
	Integer size;
	Date createdAt;
	Integer createdBy;
	Boolean isMandatory;
	Integer conditionalMandatoryGrouping;
}
