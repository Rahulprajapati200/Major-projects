package com.bdo.bvms.common.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.dao.CommonDao;
import com.bdo.bvms.common.dto.ExceptionLogDTO;
import com.bdo.bvms.common.sql.TransactionSQL;

@Repository
public class CommonDaoImpl implements CommonDao {

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Override
    public void updateExceptionLogTable(ExceptionLogDTO exceptionLogDTO) {
        jdbcTemplateTrn.update(TransactionSQL.INSERT_EXCEPTION_LOG, exceptionLogDTO.getScreenName(),
                        exceptionLogDTO.getFunctionName(), exceptionLogDTO.getErrorMessage(),
                        exceptionLogDTO.getErrorCause(), exceptionLogDTO.getLineNo(), exceptionLogDTO.getUserId(),
                        exceptionLogDTO.getCreatedAt(), exceptionLogDTO.getRequestedAt(),
                        exceptionLogDTO.getRequestedBy());
    }

    public Map<String, String> getErrorCodesDescription() {

        HashMap<String, String> mapRet = new HashMap<>();

        jdbcTemplateMst.query(UploadSQL.GET_ERRORCODE_AND_SHORTDESCRIPTION,
                        new ResultSetExtractor<Map<String, String>>() {

                            @Override
                            public Map<String, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                while (rs.next()) {
                                    mapRet.put(rs.getString("ErrorCode"), rs.getString("ShortDescription"));
                                }
                                return mapRet;
                            }
                        });
        return mapRet;

    }

}
