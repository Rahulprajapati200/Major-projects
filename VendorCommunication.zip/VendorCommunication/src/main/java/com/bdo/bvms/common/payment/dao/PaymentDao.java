package com.bdo.bvms.common.payment.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.PaymentResponseBean;
import com.bdo.bvms.common.dto.UploadReqDTO;

public interface PaymentDao {

	PaymentResponseBean gstInwardInvCdnInsert(String csvPaymentSuccessFilePath, String csvPaymentErrorFilePath,
			String successPaymentTable, String failurePaymentTable);

	List<PaymentDetails> getPaymentErrorDataListWithErrorCode(UploadReqDTO uploadReqDTO);

	int checkIfInvoiceDetailExits(PaymentDetails rowData);

	int checkPaymentDataExitsInTable(PaymentDetails rowData);

	Set<String> getPaymentItemMap(PaymentDetails rowData);

	int getInwardResultFPCount(String gstinUinOfRecipient, String inwardNo, String inwardDate, String gstinOfSupplier,
			String filingPeriod, String string);

	List<String> getDuplicateFPInDiffMonth(String gstinOfSupplier, String gstinUinOfRecipient, String string,
			String filingPeriod);

}
