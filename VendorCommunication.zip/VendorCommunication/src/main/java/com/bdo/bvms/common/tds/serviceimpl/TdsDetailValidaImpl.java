package com.bdo.bvms.common.tds.serviceimpl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dao.InwardRegisterDao;

import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;

import com.bdo.bvms.common.tds.dao.TdsDao;
import com.bdo.bvms.common.tds.service.TdsDetailValidate;
import com.bdo.bvms.common.tds.validation.TdsDetailValidation;
import com.google.common.collect.Lists;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class TdsDetailValidaImpl implements TdsDetailValidate{


	Map<String, String>purchageDnrInvoiceMap=new HashMap<>();
	
	@Value("${mst.database-name}")
    private String mstDatabaseName;

	@Autowired
	private TdsDao tdsDao;
	
	Map<String, Map<String, String>> suppGSTNWiseMap = new HashMap<>();
    Map<String, String> yearIdMap = new HashMap<>();
	
	@Autowired
	InwardRegisterDao commonCommunicationDao;
	
	@Override
	public void validateTdsDetails(List<TdsDetails> tdsDetailsTemplateDTOList, UploadReqDTO uploadReqDTO,
			List<TdsDetails> errorTdsDetailsTemplateDTOsList, List<TdsDetails> sucessTdsDetailsTemplateDTOsList,Map<String,String> yearIdMap) {
		
		List<List<TdsDetails>> partList = Lists.partition(tdsDetailsTemplateDTOList, Constants.THREADCOUNT);
		
		 String userGSTN[] = null;

	        if (Constants.PAN.equals(uploadReqDTO.getPanOrGstn())) {
	            userGSTN = commonCommunicationDao.getGstinFromDB(uploadReqDTO.getGstinOrPanList().get(0),
	            		mstDatabaseName);
	        } else if (Constants.GSTIN.equals(uploadReqDTO.getPanOrGstn())) {
	            userGSTN = uploadReqDTO.getGstinOrPanList()
	                            .toArray(new String[uploadReqDTO.getGstinOrPanList().size()]);

	        }
	        
	        String[] fpList = uploadReqDTO.getMonth().toArray(new String[uploadReqDTO.getMonth().size()]);
	        
	        for (List<TdsDetails> sublist : partList) {
	           
	              runParallalProcessingValidations(tdsDetailsTemplateDTOList,sublist,
	            		uploadReqDTO, userGSTN, fpList,errorTdsDetailsTemplateDTOsList,sucessTdsDetailsTemplateDTOsList,yearIdMap);
	        }
	        
	}

	private void runParallalProcessingValidations(List<TdsDetails> tdsDetailsTemplateDTOList, List<TdsDetails> sublist,
			UploadReqDTO uploadReqDTO, String[] userGSTN, String[] fpList,
			List<TdsDetails> errorTdsDetailsTemplateDTOsList, List<TdsDetails> sucessTdsDetailsTemplateDTOsList,Map<String,String> yearIdMap) {
		List<String>tdsSections = commonCommunicationDao.getTdsSectionList();
		sublist.forEach(rowData->{
			TdsDetailValidation invDataTypeCheck = new TdsDetailValidation();
			invDataTypeCheck.validateTdsDetails(rowData,tdsSections);
             invDataTypeCheck = null;
             if (StringUtils.isBlank(rowData.getGstinUinOfRecipient())
 					|| Arrays.stream(userGSTN).noneMatch(rowData.getGstinUinOfRecipient()::equalsIgnoreCase)) {
 				markErrorNAddErrorCode(rowData, "|E00520", "");
 			}
             
             isValidFp(rowData,fpList);
             paymentInvoiceExistsError(rowData);
             
             
		});
		
		sublist.forEach(rowData->
		{
			int listSize=sublist.size();
			checkForPreviousMountValidation(rowData,uploadReqDTO,listSize,yearIdMap);
			if(rowData.isValid())
            {
           	 sucessTdsDetailsTemplateDTOsList.add(rowData);
            }
            else {
           	 errorTdsDetailsTemplateDTOsList.add(rowData);
			}
		});
	}
	
	
	
	
	private void isValidFp(TdsDetails rowdata, String[] fpList) {

        boolean fp = StringUtils.isNotBlank(rowdata.getFilingPeriod()) && rowdata.getFilingPeriod().length() == 6
                        && rowdata.getFilingPeriod().matches("\\d+");
        if (fp && Arrays.stream(fpList).noneMatch(rowdata.getFilingPeriod()::equalsIgnoreCase)) {
        	markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00353, "");
        }

    }

	private void checkForPreviousMountValidation(TdsDetails rowData, UploadReqDTO uploadReqDTO,int paymentListSize,Map<String,String> yearIdMap) {


        int isduplicateInvoiceInDiffMonth = 0;
        String supplierGstnInwardNo = rowData.getGstinOfSupplier() + rowData.getInwardNo();
        if (paymentListSize < 5000) {
            isduplicateInvoiceInDiffMonth = tdsDao.getInwardResultFPCount(
                            rowData.getGstinUinOfRecipient(), rowData.getInwardNo(),
                            rowData.getInwardAate(), rowData.getGstinOfSupplier(), rowData.getFilingPeriod(), yearIdMap.get(rowData.getFilingPeriod()));

        } else {
            // Check invoice already saved in the GSTN
            String keyCheckInBatchData = rowData.getGstinUinOfRecipient() + uploadReqDTO.getBatchNo();
            List<String> invoiceList = null;
            if (suppGSTNWiseMap.get(keyCheckInBatchData) == null) {
                invoiceList = tdsDao.getDuplicateFPInDiffMonth(
                                rowData.getGstinOfSupplier(), rowData.getGstinUinOfRecipient(),yearIdMap.get(rowData.getFilingPeriod()),
                                rowData.getFilingPeriod());
                Map<String, String> map = invoiceList.stream()
                                .collect(Collectors.toMap(str -> str, str -> str));
                suppGSTNWiseMap.put(keyCheckInBatchData, map);
                if (suppGSTNWiseMap.get(keyCheckInBatchData).get(supplierGstnInwardNo) != null) {
                    isduplicateInvoiceInDiffMonth++;
                }

            } else {
                Map<String, String> map = suppGSTNWiseMap.get(keyCheckInBatchData);
                if (map != null && map.get(supplierGstnInwardNo) != null) {
                    isduplicateInvoiceInDiffMonth++;
                }
            }
        }

        String mapKey = rowData.getInwardNo() + rowData.getGstinOfSupplier();

        if (StringUtils.isNotBlank(mapKey)) {
            mapKey = mapKey.toLowerCase();
        }

//        String itcClaimedKey = rowData.getGstinOfRecipient() + uploadRequestDTO.getBatchNo();
        if (isduplicateInvoiceInDiffMonth > 0) {
            markErrorNAddErrorCode(rowData, Constants.COMMUNICATION_ERROR_CODE_O0093, "");
        }
	
		
	}

	private void paymentInvoiceExistsError(TdsDetails rowData) {
		StringBuilder mapKey=new StringBuilder().append(rowData.getGstinUinOfRecipient())
				.append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo());
		if(!purchageDnrInvoiceMap.containsKey(mapKey.toString()))
		{
			int count= tdsDao.checkIfInvoiceDetailExits(rowData);
			if(count>0)
			{
				purchageDnrInvoiceMap.put(mapKey.toString(), mapKey.toString());
			}
			else
			{
				markErrorNAddErrorCode(rowData,Constants.ERROR_CODE_E00570 , "");
			}
		}
		
		
	}
	private void markErrorNAddErrorCode(TdsDetails rowdata, String errorCode, String errorMsg) {
        rowdata.setErrorCodeList(rowdata.getErrorCodeList().append(errorCode));
        rowdata.setErrorDescriptionList(rowdata.getErrorDescriptionList().append(errorMsg));
        rowdata.setValid(false);
    }


}
