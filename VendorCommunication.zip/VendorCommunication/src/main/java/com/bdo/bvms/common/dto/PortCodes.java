package com.bdo.bvms.common.dto;

import java.io.Serializable;
/**
 *FileType: java
 *Author : anka
 *Created On : 02/11/2017 6:56:39 PM
 *Copy Rights : Anka Technology Solutions Pvt. Ltd.
 */
public class PortCodes implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String portCode;
	private String portName;
	private String indianStates;

	public PortCodes() {
		//
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPortCode() {
		return portCode;
	}

	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}

	public String getPortName() {
		return portName;
	}

	public void setPortName(String portName) {
		this.portName = portName;
	}

	public String getIndianStates() {
		return indianStates;
	}

	public void setIndianStates(String indianStates) {
		this.indianStates = indianStates;
	}
	
	@Override
	public String toString() {
		return "PortCodes [id=" + id + " port_code=" + portCode + ", port_name=" + portName + ", indian_states=" + indianStates + "]";
	}
}
