package com.bdo.bvms.common.dto;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SearchByLkupcodeReqDTO {
	
	@NotBlank(message = "Request parameter lkupcode must not be null nor blank")
	String lkupcode;

}
