package com.bdo.bvms.common.payment.serviceimpl;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.constant.StringConstant;
import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dao.UploadTransDao;
import com.bdo.bvms.common.dto.ExceptionLogDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvalidTemplateHeaderException;
import com.bdo.bvms.common.exceptions.InvoiceTemplateUploadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.payment.service.ReadDefaultExcelAndCSV;
import com.bdo.bvms.common.service.InwardUpload;
import com.bdo.bvms.common.util.AppUtil;
import com.bdo.bvms.common.util.DateUtil;
import com.bdo.bvms.common.validationrule.DroolUtil;
import com.csvreader.CsvReader;
import com.monitorjbl.xlsx.StreamingReader;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class ReadDefaultExcelAndCSVImpl implements ReadDefaultExcelAndCSV {

	Row headerRow = null;
	
	/** The col name index map. */
    Map<String, Integer> colNameIndexMap = new HashMap<>();
	
	@Value("${bvms.cloud.temp.file.download.path}")
	String tempFolder;

	@Autowired
	InwardUpload inwardUpload;
	
	@Autowired
    UploadTransDao uploadTransDao;
	
	@Override
	public void readDataFromExcel(UploadReqDTO uploadReqDTO,
			List<PaymentDetails> paymentDetailsTemplateDTOList,List<PaymentDetails> rowDocErrorPojoList) throws InvoiceTemplateUploadException {

		
		String methodName="readDataFromExcel";
		StringBuilder filePath = new StringBuilder()
				.append(tempFolder + System.getProperty(StringConstant.FILESEPARATOR)).append(uploadReqDTO.getBatchNo())
				.append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
				.append(uploadReqDTO.getFileType());
		
		 Map<String, Object> rowCountWithHeader = new HashMap<>();
		 
		 try {
	            try (InputStream inputStream = new FileInputStream(new File(filePath.toString()));
	                            BufferedInputStream br = new BufferedInputStream(inputStream)) {
	                // getting HeaderRowIndexs , coumnsDataRow ,RowCount
	                rowCountWithHeader = getRowCountWithHeader(inputStream, uploadReqDTO);
	            }
	        } catch (Exception e2) {
	            log.error("Error in getEinvoiceDataList Method :" + e2);
	            uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(),Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
	            throw new InvoiceTemplateUploadException(e2.getMessage());
	        }
		 
		 headerRow = (Row) rowCountWithHeader.get(Constants.DATA_ROW);

	        try {
	            colNameIndexMap = AppUtil.getColumnNameIndexMap(headerRow);
	        } catch (Exception ex) {

	            log.error("Error in reading colNameIndexMap :" + ex);
	            uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(),
	                            Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
	            throw new InvoiceTemplateUploadException(ex.getMessage(), ex.getCause());
	        }

	        
	        if (Constants.PAYMENT_TEMPLATE_HEADER_COUNT != colNameIndexMap.size()) {
	            log.error("Error in Header Not Mathching ");
	            uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(),
	                            Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);
	            throw new InvalidTemplateHeaderException(
	                    StringConstant.HEADERCOUNTERRORMESSAGE + uploadReqDTO.getBatchNo());

	        }
	        
	        try (InputStream in = new FileInputStream(new File(filePath.toString()));
                    BufferedInputStream bis = new BufferedInputStream(in);
                    Workbook workbook = StreamingReader.builder().open(bis);) {

        Sheet sheet = workbook.getSheetAt(0);

        sheet.forEach(row -> {
            PaymentDetails xlsRow = new PaymentDetails();
            if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 1) {
                xlsRow.setExcelRowId(row.getRowNum());
                
                try {
                    // reading Excel Template
                	xlsRow.setValid(true);
                    xlsRow = readTemplateRecord(row, colNameIndexMap, uploadReqDTO);
                    

                } catch (Exception e) {

                    markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
                    log.info("Exception in readTemplateRecord");
                }
                if (StringUtils.isNotBlank(xlsRow.getGstinUinOfRecipient())
                                && xlsRow.getGstinUinOfRecipient().length() == 15) {
                    xlsRow.setPanOfRecipient(xlsRow.getGstinUinOfRecipient().substring(2, 12));

                } else {
                    xlsRow.setPanOfRecipient("");

                }
                if (xlsRow.getFilingPeriod().length() == 5) {
                	xlsRow.setFilingPeriod(Constants.ZEROVALUE + xlsRow.getFilingPeriod());
                }
                if (StringUtils.isNotBlank(xlsRow.getGstinOfSupplier())
                                && xlsRow.getGstinOfSupplier().length() == 15) {
                    xlsRow.setPanOfSupplier(xlsRow.getGstinOfSupplier().substring(2, 12));
                } else {
                    xlsRow.setPanOfSupplier("");
                }
               
                    paymentDetailsTemplateDTOList.add(xlsRow);
               
               
            }
        });
      
    } catch (Exception exception) {
        log.error(methodName + exception);
        throw new InvoiceTemplateUploadException(exception.getMessage(), exception);

    }


	}
	
	
    public Map<String, Object> getRowCountWithHeader(InputStream inputStream, UploadReqDTO uploadRequestDTO)
                    throws VendorInvoiceServerException {
        Map<String, Object> dataMap = new HashMap<>();
        String methodName = "getRowCountWithHeader";
        int totalRowCount = 0;
        try (InputStream is = new BufferedInputStream(inputStream);
                        Workbook workbook = StreamingReader.builder().open(is);) {

            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 1) {
                    totalRowCount++;
                } else if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() <= 1 && totalRowCount == 0) {

                    Row coumnsDataRow = null;
                    coumnsDataRow = row;
                    dataMap.put("headerRowIndex", row.getRowNum());
                    dataMap.put("coumnsDataRow", coumnsDataRow);

                }

            }
            dataMap.put("RowCount", totalRowCount);
        } catch (Exception ex) {

            log.error("getRowCountWithHeader Error " + ex);
            
            throw new VendorInvoiceServerException(
                            Constants.ERRORINREADINGHEADECOUNT+ uploadRequestDTO.getBatchNo());

        }
        return dataMap;

    }
	
	private PaymentDetails readTemplateRecord(Row row, Map<String, Integer> colNameIndexMap2,
			UploadReqDTO uploadReqDTO) {

		PaymentDetails xlsRow = new PaymentDetails();

        log.info("Reading Cell from excel Rows field wise");

        try {

            xlsRow.setValid(true);
            xlsRow.setExcelRowId(row.getRowNum());

            xlsRow.setGstinUinOfRecipient(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT))).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setDocType(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.DOC_TYPE)))
            		.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setGstinOfSupplier(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_GSTIN_OF_SUPPLIER)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setSupplierName(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_SUPPLIER_NAME)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInwardNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_INWARD_NO)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInwardDate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_INWARD_DATE)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setDateOfPayment(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.DATE_OF_PAYMENT)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInvAgainstProv(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.INVOICE_AGAINST_PROV_ADV)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInwardNoProvAdv(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.INWARD_NO_PROV_ADV)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgAmountofPayment(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.PAYMENT_AMOUNT)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setAmountofPayment(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.PAYMENT_AMOUNT)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setFilingPeriod(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.FILLING_PERIOD)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            if(!isNumeric(xlsRow.getAmountofPayment()))
            {
            	if(StringUtils.isBlank(xlsRow.getAmountofPayment()))
            	{
            		xlsRow.setAmountofPayment("0.0");
            	}
            	else
            	{
            		xlsRow.setAmountofPayment("0.0");
            		markErrorNAddErrorCode(xlsRow, ValidationConstant.EINVOICE_ERROR_CODE_I50031, Constants.BLANK);
            	}
            }
            xlsRow.setPaymentRefNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.PAYMENT_REF_NO)))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setUdf1(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_1")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf2(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_2")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf3(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_3")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf4(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_4")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf5(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_5")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf6(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_6")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf7(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_7")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf8(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_8")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf9(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_9")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf10(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_10")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setUdf11(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_11")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf12(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_12")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf13(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_13")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf14(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_14")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf15(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_15")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf16(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_16")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf17(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_17")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf18(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_18")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf19(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_19")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf20(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_20")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
 
        } catch (Exception ex) {
            // Mark as not Valid object if Exception occur
            log.error("Error generated:", ex);
            xlsRow.setValid(false);
            log.error("Errro occured while reading row " + row.getRowNum() + " for batch No. " + ex);
        }
        return xlsRow;
    }


	private void markErrorNAddErrorCode(PaymentDetails rowData, String string, String string2) {
        rowData.setValid(false);
        rowData.setErrorCodeList(rowData.getErrorCodeList().append(string));
        rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(string2));

    }
	
	

	@Override
	public void readCSVFile(UploadReqDTO uploadReqDTO, List<PaymentDetails> paymentDetailsTemplateDTOList) throws VendorInvoiceServerException, IOException {
        int cnt = 0;
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadReqDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(uploadReqDTO.getFileType());

        CsvReader einvoices = new CsvReader(fileName.toString(), StringConstant.COMMASEPERATOR, StandardCharsets.UTF_8);
        CsvReader readHeaderCount = new CsvReader(fileName.toString(), StringConstant.COMMASEPERATOR,
                        StandardCharsets.UTF_8);

        // Add code if header is missing then mark as invalid template
        String[] indexHeaders = AppUtil.getHeaders(readHeaderCount);
        if (Constants.PAYMENT_TEMPLATE_HEADER_COUNT != indexHeaders.length) {

            uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);

            throw new VendorInvoiceServerException(
                            StringConstant.HEADERCOUNTERRORMESSAGE + uploadReqDTO.getBatchNo());

        }

        einvoices.readHeaders();
        while (einvoices.readRecord()) {
        	PaymentDetails paymentDetailsTemplateDTO = new PaymentDetails();
            try {

                cnt++;
                if (cnt > 0) {
                	paymentDetailsTemplateDTO.setValid(true);
                	paymentDetailsTemplateDTO.setGstinUinOfRecipient(einvoices.get(0)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setDocType(einvoices.get(Constants.COLUMN_DOC_TYPE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	
                	paymentDetailsTemplateDTO.setGstinOfSupplier(einvoices.get(Constants.COLUMN_GSTIN_OF_SUPPLIER)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	
                	paymentDetailsTemplateDTO.setSupplierName(einvoices.get(Constants.COLUMN_SUPPLIER_NAME)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"))
                	;
                	paymentDetailsTemplateDTO.setInwardNo(einvoices.get(Constants.COLUMN_INWARD_NO)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setInwardDate(einvoices.get(Constants.COLUMN_INWARD_DATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setDateOfPayment(einvoices.get(Constants.PAYMENT_DATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	
                	paymentDetailsTemplateDTO.setInvAgainstProv(einvoices.get(Constants.INVOICE_AGAINST_PROV_ADV)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setInwardNoProvAdv(einvoices.get(Constants.INWARD_NO_PROV_ADV)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setOrgAmountofPayment(einvoices.get(Constants.PAYMENT_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setAmountofPayment(einvoices.get(Constants.PAYMENT_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	 if(!isNumeric(paymentDetailsTemplateDTO.getAmountofPayment()))
         			{
                		 if(StringUtils.isBlank(paymentDetailsTemplateDTO.getAmountofPayment()))
                     	{
                			 paymentDetailsTemplateDTO.setAmountofPayment("0.0");
                     	}
                     	else
                     	{
                     		paymentDetailsTemplateDTO.setAmountofPayment("0.0");
                     		markErrorNAddErrorCode(paymentDetailsTemplateDTO, ValidationConstant.EINVOICE_ERROR_CODE_I50031, Constants.BLANK);
                     	}
         			}
                	paymentDetailsTemplateDTO.setPaymentRefNo(einvoices.get(Constants.PAYMENT_REF_NO)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	
                	paymentDetailsTemplateDTO.setFilingPeriod(einvoices.get(Constants.FILLING_PERIOD)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                   
                	paymentDetailsTemplateDTO.setUdf1(einvoices.get(Constants.COLUMN_UDF_1)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf2(einvoices.get(Constants.COLUMN_UDF_2)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf3(einvoices.get(Constants.COLUMN_UDF_3)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf4(einvoices.get(Constants.COLUMN_UDF_4)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf5(einvoices.get(Constants.COLUMN_UDF_5)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf6(einvoices.get(Constants.COLUMN_UDF_6)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf7(einvoices.get(Constants.COLUMN_UDF_7)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf8(einvoices.get(Constants.COLUMN_UDF_8)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf9(einvoices.get(Constants.COLUMN_UDF_9)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf10(einvoices.get(Constants.COLUMN_UDF_10)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	
                	paymentDetailsTemplateDTO.setUdf11(einvoices.get(Constants.COLUMN_UDF_11)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf12(einvoices.get(Constants.COLUMN_UDF_12)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf13(einvoices.get(Constants.COLUMN_UDF_13)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf14(einvoices.get(Constants.COLUMN_UDF_14)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf15(einvoices.get(Constants.COLUMN_UDF_15)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf16(einvoices.get(Constants.COLUMN_UDF_16)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf17(einvoices.get(Constants.COLUMN_UDF_17)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf18(einvoices.get(Constants.COLUMN_UDF_18)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf19(einvoices.get(Constants.COLUMN_UDF_19)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	paymentDetailsTemplateDTO.setUdf20(einvoices.get(Constants.COLUMN_UDF_20)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                	
                	 if (StringUtils.isNotBlank(paymentDetailsTemplateDTO.getGstinUinOfRecipient())
                             && paymentDetailsTemplateDTO.getGstinUinOfRecipient().length() == 15) {
                		 paymentDetailsTemplateDTO.setPanOfRecipient(paymentDetailsTemplateDTO.getGstinUinOfRecipient().substring(2, 12));

             } else {
            	 paymentDetailsTemplateDTO.setPanOfRecipient("");

             }
             if (paymentDetailsTemplateDTO.getFilingPeriod().length() == 5) {
            	 paymentDetailsTemplateDTO.setFilingPeriod(Constants.ZEROVALUE + paymentDetailsTemplateDTO.getFilingPeriod());
             }
             if (StringUtils.isNotBlank(paymentDetailsTemplateDTO.getGstinOfSupplier())
                             && paymentDetailsTemplateDTO.getGstinOfSupplier().length() == 15) {
            	 paymentDetailsTemplateDTO.setPanOfSupplier(paymentDetailsTemplateDTO.getGstinOfSupplier().substring(2, 12));
             } else {
            	 paymentDetailsTemplateDTO.setPanOfSupplier("");
             }
            
                	paymentDetailsTemplateDTOList.add(paymentDetailsTemplateDTO);
                        
                     

                }
                
              
            } catch (Exception ex) {

                log.error("Error generated:", ex);
                markErrorNAddErrorCode(paymentDetailsTemplateDTO, ValidationConstant.EINVOICE_ERROR_CODE_DE1000,
                                Constants.BLANK);
            }
        }

    }
	
	public static boolean isNumeric(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}

}
