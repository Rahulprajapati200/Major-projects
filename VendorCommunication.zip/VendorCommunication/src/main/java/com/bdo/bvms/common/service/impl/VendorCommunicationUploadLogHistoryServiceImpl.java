package com.bdo.bvms.common.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.CommonDao;
import com.bdo.bvms.common.dao.VendorCommunicationUploadLogHistoryDao;
import com.bdo.bvms.common.dto.ExceptionLogDTO;
import com.bdo.bvms.common.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.common.dto.UploadLogDto;
import com.bdo.bvms.common.dto.UploadLogHistoryResDataDto;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.service.VendorCommunicationUploadLogHistoryService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class VendorCommunicationUploadLogHistoryServiceImpl implements VendorCommunicationUploadLogHistoryService {

    @Autowired
    VendorCommunicationUploadLogHistoryDao vendorCommunicationUploadLogHistoryDao;

    @Autowired
    CommonDao commonDao;

    @Override
    public List<UploadLogHistoryResDataDto> getHistoryList(UploadHistoryRequestDTO uploadHistoryRequestDTO)
                    throws VendorInvoiceServerException {

        Page<UploadLogDto> pagedResult = null;
        try {

            // Here we get History upload Data from repository layer.
            pagedResult = vendorCommunicationUploadLogHistoryDao.getHistoryList(uploadHistoryRequestDTO);
        } catch (Exception e) {
            log.error("Exception come at the time of getting history data", e.getCause());
            
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            String methodName1 = "getHistoryList";

            exceptionLogDTO.setUserId(uploadHistoryRequestDTO.getModuleID());
            exceptionLogDTO.setScreenName(Constants.VENDOR_COMMUNICATION);
            exceptionLogDTO.setFunctionName(methodName1);
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in getting data from database.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // add exception in exception table if an exception is coming.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException(e.getMessage(), e.getCause());
        }

        return pagedResult.getContent().stream().map(uploadLog -> UploadLogHistoryResDataDto.builder()
                        .taxpayerPan(uploadLog.getTaxpayerPan()).taxpayerGstin(uploadLog.getTaxpayerGstin())
                        .financialPeriod(uploadLog.getFp()).uploadedDate(uploadLog.getCreatedAt())
                        .uploadedBy(uploadLog.getCreatedBy()).dataType(uploadLog.getTemplateType())
                        .fileName(uploadLog.getFileName()).fileType(uploadLog.getFileType())
                        .totalCount(uploadLog.getTotalCount()).successCount(uploadLog.getSuccessCount())
                        .errorCount(uploadLog.getErrorCount()).status(uploadLog.getPldUploadStatus())
                        .baseFile(uploadLog.getBaseFileLocation()).errorFile(uploadLog.getErrorFileLocation())
                        .batchNo(uploadLog.getBatchNo()).uploadSource(uploadLog.getUploadSource()).customeOrDefault(uploadLog.getIsCustomTemplate().equals("0")?0:1).build()).collect(Collectors.toList());

    }

}
