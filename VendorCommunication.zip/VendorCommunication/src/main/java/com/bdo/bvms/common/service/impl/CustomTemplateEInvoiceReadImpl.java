package com.bdo.bvms.common.service.impl;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.monitorjbl.xlsx.StreamingReader;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.constant.StringConstant;
import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dao.CustomTemplateRepo;
import com.bdo.bvms.common.dao.InwardRegisterDao;
import com.bdo.bvms.common.dao.UploadTransDao;
import com.bdo.bvms.common.dto.ExceptionLogDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvalidTemplateHeaderException;
import com.bdo.bvms.common.exceptions.InvoiceTemplateUploadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.service.CustomTemplateInwardRead;
import com.bdo.bvms.common.util.AppUtil;
import com.bdo.bvms.common.util.CommonUtils;
import com.bdo.bvms.common.util.DateUtil;
import com.bdo.bvms.common.validationrule.DroolUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CustomTemplateEInvoiceReadImpl implements CustomTemplateInwardRead {

	@Value("${bvms.cloud.temp.file.download.path}")
	String tempFolder;

	@Autowired
	CustomTemplateRepo customeTemplateRepo;

	@Autowired
	UploadTransDao uploadTransDao;
	
	Row headerRow = null;
	
	@Autowired
	InwardRegisterDao commonCommunicationDao;
	
	Map<String, Integer> colNameIndexMap = new HashMap<>();
	
	List<InwardInvoiceCDNTemplateDTO> invoiceList = new ArrayList<>();
    
	Set<String>sftpSet =new HashSet<>();
	
	@Override
	public void readCustomTemplate(UploadReqDTO uploadRequestDTO, List<InwardInvoiceCDNTemplateDTO> invDataList, List<InwardInvoiceCDNTemplateDTO> cdnDataList,List<InwardInvoiceCDNTemplateDTO>rowDocErrorPojoList) throws InvoiceTemplateUploadException {
		String methodName = "getEinvoiceDataList";
		invoiceList=new ArrayList<>();
		StringBuilder fileName = new StringBuilder().append(tempFolder)
				.append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadRequestDTO.getBatchNo())
				.append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
				.append(uploadRequestDTO.getFileType());

		Map<String, Object> rowCountWithHeader = new HashMap<>();
		Map<String, String> customTemplateHeaderMappings = CommonUtils.getCustomTemplateHeaderMappings(uploadRequestDTO,
				customeTemplateRepo);
		try {
			try (InputStream inputStream = new FileInputStream(new File(fileName.toString()));
					BufferedInputStream br = new BufferedInputStream(inputStream)) {
				// getting HeaderRowIndexs , coumnsDataRow ,RowCount
				rowCountWithHeader = getRowCustomCountWithHeader(inputStream, uploadRequestDTO);
			}
		} catch (Exception e2) {
			uploadTransDao.updateProcessStatus(uploadRequestDTO.getBatchNo(),
					Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
			ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();

			String methodName1 = "getExcelEWayDataList";

			exceptionLogDTO.setUserId(uploadRequestDTO.getId());
			exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
			exceptionLogDTO.setFunctionName(methodName1);
			exceptionLogDTO.setErrorMessage(e2.getMessage());
			exceptionLogDTO.setErrorCause(Constants.NOTCONTAINPROPERDATA);
			exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
			exceptionLogDTO.setCreatedAt(LocalDateTime.now());

			commonCommunicationDao.updateExceptionLogTable(exceptionLogDTO);

			throw new InvoiceTemplateUploadException(e2.getMessage());
		}

		headerRow = (Row) rowCountWithHeader.get(Constants.DATA_ROW);

		try {
			colNameIndexMap = AppUtil.getColumnNameIndexMap(headerRow);

		} catch (Exception ex) {

			log.error("Exception ", ex);

			uploadTransDao.updateProcessStatus(uploadRequestDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);

			logIntoToExceptionTable(uploadRequestDTO, ex, methodName);

			throw new InvoiceTemplateUploadException(ex.getMessage(), ex.getCause());
		}

		// throw exception and Update in Exception Log table as per Batch Number
		if (Constants.E_INVOICE_TEMPLATE_COLUMN_COUNT != colNameIndexMap.size()) {
			uploadTransDao.updateProcessStatus(uploadRequestDTO.getBatchNo(),
					Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);

			throw new InvalidTemplateHeaderException(StringConstant.HEADERCOUNTERRORMESSAGE + uploadRequestDTO.getBatchNo());

		}

		try (InputStream in = new FileInputStream(new File(fileName.toString()));
				BufferedInputStream bis = new BufferedInputStream(in);
				Workbook workbook = StreamingReader.builder().open(bis);) {

			Sheet sheet = workbook.getSheetAt(0);

			sheet.forEach(row -> {
				InwardInvoiceCDNTemplateDTO rowObj = new InwardInvoiceCDNTemplateDTO();
				if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 0) {
					rowObj.setExcelRowId(row.getRowNum());
					try {
						// reading Excel Template
						rowObj.setValid(true);
						rowObj = readTemplateRecord(row, colNameIndexMap, uploadRequestDTO, customTemplateHeaderMappings);
						

					} catch (Exception e) {
						log.error("Error generated while reading xls ", e);
						markErrorNAddErrorCode(rowObj, ValidationConstant.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
					}
					if (rowObj.getFillingPeriod().length() == 5) {
						rowObj.setFillingPeriod(Constants.ZEROVALUE + rowObj.getFillingPeriod());
					}
					if (rowObj.getPeriodOfFiling().length() == 5) {
						rowObj.setPeriodOfFiling(Constants.ZEROVALUE + rowObj.getPeriodOfFiling());
                    }
					if (StringUtils.isNotBlank(rowObj.getGstinOfRecipient()) && rowObj.getGstinOfRecipient().length()==15) {
						rowObj.setPanOfReciepiet(rowObj.getGstinOfRecipient().substring(2, 12));
					} else {
						rowObj.setPanOfReciepiet("");
					}
					if (StringUtils.isNotBlank(rowObj.getGstinOfSupplier()) && rowObj.getGstinOfSupplier().length()==15) {
						rowObj.setPanOfSupplier(rowObj.getGstinOfSupplier().substring(2, 12));
					} else {
						rowObj.setPanOfSupplier("");
					}
            
					if(StringUtils.isNotBlank(rowObj.getFillingPeriod()))
					{
						sftpSet.add(rowObj.getFillingPeriod());
					}
					
					if ("INV".equals(rowObj.getDocType())) {
						invDataList.add(rowObj);
                    } else if ("CRN".equals(rowObj.getDocType()) || "DBN".equals(rowObj.getDocType())) {
                    	cdnDataList.add(rowObj);
                    } else {
                        rowDocErrorPojoList.add(rowObj);
                        rowObj.setErrorCodeList(rowObj.getErrorCodeList().append("|E00257"));
                        rowObj.setValid(false);
                    }
					
					
				}
			});

			if("ftps".equals(uploadRequestDTO.getUploadSource()))
			{
				uploadRequestDTO.setMonth(new ArrayList<>(sftpSet));
				uploadTransDao.updateFpLog(uploadRequestDTO.getMonth(),uploadRequestDTO);
			}
		} catch (Exception exception) {
			throw new InvoiceTemplateUploadException(exception.getMessage(), exception);
		}

	}


    private InwardInvoiceCDNTemplateDTO readTemplateRecord(Row row, Map<String, Integer> colNameIndexMap,
            UploadReqDTO uploadDTO, Map<String, String> columnMap) throws VendorInvoiceServerException {

    	InwardInvoiceCDNTemplateDTO xlsRow = new InwardInvoiceCDNTemplateDTO();
log.info("Reading Cell from excel Rows field wise");

try {
	
	 if (colNameIndexMap.size() != columnMap.size()) {
	        uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),
	                        Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);
	    }

	 
    String customHeaderName = columnMap.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT);
    Integer idxForGstinReceipient = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForGstinReceipient);

    
    customHeaderName = columnMap.get(Constants.COLUMN_DOC_TYPE);
    Integer idxForDocType = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForDocType);
    
    customHeaderName = columnMap.get(Constants.PERIOD_OF_FILLING);
    Integer idxPeriodOfFiling = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForDocType);
    xlsRow.setPeriodOfFiling(AppUtil.getCellValue(row.getCell(idxPeriodOfFiling)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\").replace("\\", "\\\\"));


    customHeaderName = columnMap.get(Constants.COLUMN_SUPPLY_TYPE);
    Integer idxForSupplyType = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForSupplyType);

    customHeaderName = columnMap.get(Constants.COLUMN_DOC_NO);
    Integer idxForDocNo = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForDocNo);
    
    customHeaderName = columnMap.get(Constants.COLUMN_DOC_DATE);
    Integer idxForDocDate = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForDocDate);
    
    customHeaderName = columnMap.get(Constants.COLUMN_ORG_INVOICE_NO);
    Integer idxForOrgInvoiceNo = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForOrgInvoiceNo);
    
    customHeaderName = columnMap.get(Constants.COLUMN_ORG_INVOICE_DATE);
    Integer idxForOrgInvoiceDate = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForOrgInvoiceDate);
    
    customHeaderName = columnMap.get(Constants.COLUMN_GSTIN_OF_SUPPLIER);
    Integer idxForGstinSupplier = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForGstinSupplier);
    
    customHeaderName = columnMap.get(Constants.COLUMN_SUPPLIER_NAME);
    Integer idxForSupplierName = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForSupplierName);
    
    customHeaderName = columnMap.get(Constants.COLUMN_SUPPLIER_STATE_CODE);
    Integer idxForSupplierStateCode = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForSupplierStateCode);
    
    customHeaderName = columnMap.get(Constants.COLUMN_INWARD_NO);
    Integer idxForInwarNo = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForInwarNo);
    
    customHeaderName = columnMap.get(Constants.COLUMN_INWARD_DATE);
    Integer idxForInwardDate = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForInwardDate);

    customHeaderName = columnMap.get(Constants.COLUMN_ITEM_DESCRIPTION);
    Integer idxForItemDescription = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForItemDescription);
    
    customHeaderName = columnMap.get(Constants.COLUMN_HSN_CODE);
    Integer idxForHsnCode = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForHsnCode);

    customHeaderName = columnMap.get(Constants.COLUMN_UOM);
    Integer idxForUom = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUom);
    
    customHeaderName = columnMap.get(Constants.COLUMN_QUINTITY);
    Integer idxForQuantity = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForQuantity);
    
    customHeaderName = columnMap.get(Constants.COLUMN_ITEM_RATE);
    Integer idxForItemRate = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForItemRate);
    
    customHeaderName = columnMap.get(Constants.COLUMN_ASS_AMOUNT);
    Integer idxForAssAmount = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForAssAmount);
    
    customHeaderName = columnMap.get(Constants.COLUMN_SGST_RATE);
    Integer idxForSgstRate = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForSgstRate);
    
    customHeaderName = columnMap.get(Constants.COLUMN_SGST_AMOUNT);
    Integer idxForSgstAmount = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForSgstAmount);
    
    customHeaderName = columnMap.get(Constants.COLUMN_CGST_RATE);
    Integer idxForCgstRate = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForCgstRate);
    
    customHeaderName = columnMap.get(Constants.COLUMN_CGST_AMOUNT);
    Integer idxForCgstAmount = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForCgstAmount);
    
    customHeaderName = columnMap.get(Constants.COLUMN_IGST_RATE);
    Integer idxForIgstRate = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForIgstRate);
    
    customHeaderName = columnMap.get(Constants.COLUMN_IGST_AMOUNT);
    Integer idxForIgstAmount = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForIgstAmount);
    
    customHeaderName = columnMap.get(Constants.COLUMN_CESS_RATE);
    Integer idxForCessRate = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForCessRate);
    
    customHeaderName = columnMap.get(Constants.COLUMN_CESS_AMOUNT);
    Integer idxForCessAmount = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForCessAmount);

    
    customHeaderName = columnMap.get(Constants.COLUMN_DIFF_PERCENT);
    Integer idxForDiffPercent = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForDiffPercent);
    
    customHeaderName = columnMap.get(Constants.COLUMN_INWARD_GROSS_TOTAL_AMOUNT);
    Integer idxForInwardGrossTotalAmount = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForInwardGrossTotalAmount);
    
    customHeaderName = columnMap.get(Constants.COLUMN_TOTAL_INVOICE_AMOUNT);
    Integer idxForTotalInvoiceAMt = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForTotalInvoiceAMt);
    
    customHeaderName = columnMap.get(Constants.COLUMN_INPUT_TYPE);
    Integer idxForInputType = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForInputType);
    
    customHeaderName = columnMap.get(Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_INDICATOR);
    Integer idxForItcIneligibleReversalIndicator = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForItcIneligibleReversalIndicator);
    
    customHeaderName = columnMap.get(Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_PERCENTAGE);
    Integer idxForItcIneligibleReversalPercent = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForItcIneligibleReversalPercent);
    
    //import_bill_of_entry_no	import_bill_of_entry_date
    
    customHeaderName = columnMap.get(Constants.COLUMN_PLACE_OF_SUPPLY);
    Integer idxForPlaceOfSupply = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForPlaceOfSupply);
    
    customHeaderName = columnMap.get(Constants.COLUMN_REVERSE_CHARGE);
    Integer idxForReverseCharge = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForReverseCharge);
    
    customHeaderName = columnMap.get(Constants.COLUMN_PORT);
    Integer idxForPort = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForPort);
    
    customHeaderName = columnMap.get(Constants.COLUMN_IMPORT_BILL_OF_ENTRY_NO);
    Integer idxForImportBillOfEntryNo = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForImportBillOfEntryNo);
    
    customHeaderName = columnMap.get(Constants.COLUMN_IMPORT_BILL_OF_ENTRY_DATE);
    Integer idxForImportBillOfEntryDate = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForImportBillOfEntryDate);
    
    customHeaderName = columnMap.get(Constants.COLUMN_IMPORT_BILL_OF_ENTRY_AMT);
    Integer idxForImportBillOfEntryAmt = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForImportBillOfEntryAmt);
    
    //	debit_gl_name	credit_gl_id	credit_gl_name
    
    customHeaderName = columnMap.get(Constants.DATE_OF_PAYMENT);
    Integer idxForDateOfPayment = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForDateOfPayment);
    
    customHeaderName = columnMap.get(Constants.COLUMN_IRN);
    Integer idxForIrn = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForIrn);
    
    customHeaderName = columnMap.get(Constants.COLUMN_ACK_DATE);
    Integer idxForAckDate = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForAckDate);
    
    customHeaderName = columnMap.get(Constants.COLUMN_ACK_NO);
    Integer idxForAckNo = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForAckNo);
    
    customHeaderName = columnMap.get(Constants.COLUMN_DEBIT_GL_ID);
    Integer idxForDebitGlId = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForDebitGlId);
    
    customHeaderName = columnMap.get(Constants.COLUMN_DEBIT_GL_NAME);
    Integer idxForDebitGlName = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForDebitGlName);
    
    
    customHeaderName = columnMap.get(Constants.COLUMN_CREDIT_GL_NAME);
    Integer idxForCreditGlName = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForCreditGlName);
    
    customHeaderName = columnMap.get(Constants.COLUMN_CREDIT_GL_ID);
    Integer idxForCreditGlId = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForCreditGlId);
    
    
    
    customHeaderName = columnMap.get(Constants.COLUMN_SUB_LOCATION);
    Integer idxForSubLocation = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForSubLocation); 
    
    customHeaderName = columnMap.get(Constants.FILLING_PERIOD);
    Integer idxForFilingPeriod = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForFilingPeriod); 
    xlsRow.setFillingPeriod(AppUtil.getCellValue(row.getCell(idxForFilingPeriod)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\").replace("\\", "\\\\"));

    customHeaderName = columnMap.get(Constants.COLUMN_UDF_1);
    Integer idxForUdf1 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf1);
    xlsRow.setUdf1(AppUtil.getCellValue(row.getCell(idxForUdf1)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\").replace("\\", "\\\\"));


    customHeaderName = columnMap.get(Constants.COLUMN_UDF_2);
    Integer idxForUdf2 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf2);
    xlsRow.setUdf2(AppUtil.getCellValue(row.getCell(idxForUdf2)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


    customHeaderName = columnMap.get(Constants.COLUMN_UDF_3);
    Integer idxForUdf3 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf3);
    xlsRow.setUdf3(AppUtil.getCellValue(row.getCell(idxForUdf3)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


    customHeaderName = columnMap.get(Constants.COLUMN_UDF_4);
    Integer idxForUdf4 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf4);
    xlsRow.setUdf4(AppUtil.getCellValue(row.getCell(idxForUdf4)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


    customHeaderName = columnMap.get(Constants.COLUMN_UDF_5);
    Integer idxForUdf5 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf5);
    xlsRow.setUdf5(AppUtil.getCellValue(row.getCell(idxForUdf5)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


    customHeaderName = columnMap.get(Constants.COLUMN_UDF_6);
    Integer idxForUdf6 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf6);
    xlsRow.setUdf6(AppUtil.getCellValue(row.getCell(idxForUdf6)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


    customHeaderName = columnMap.get(Constants.COLUMN_UDF_7);
    Integer idxForUdf7 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf7);
    xlsRow.setUdf7(AppUtil.getCellValue(row.getCell(idxForUdf7)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


    customHeaderName = columnMap.get(Constants.COLUMN_UDF_8);
    Integer idxForUdf8 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf8);
    xlsRow.setUdf8(AppUtil.getCellValue(row.getCell(idxForUdf8)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


    customHeaderName = columnMap.get(Constants.COLUMN_UDF_9);
    Integer idxForUdf9 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf9);
    xlsRow.setUdf9(AppUtil.getCellValue(row.getCell(idxForUdf9)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


    customHeaderName = columnMap.get(Constants.COLUMN_UDF_10);
    Integer idxForUdf10 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf10);
    xlsRow.setUdf10(AppUtil.getCellValue(row.getCell(idxForUdf10)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


    customHeaderName = columnMap.get(Constants.COLUMN_UDF_12);
    Integer idxForUdf12 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf12);
    xlsRow.setUdf12(AppUtil.getCellValue(row.getCell(idxForUdf12)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

    
    customHeaderName = columnMap.get(Constants.COLUMN_UDF_11);
    Integer idxForUdf11 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf11);
    xlsRow.setUdf11(AppUtil.getCellValue(row.getCell(idxForUdf11)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

    
    customHeaderName = columnMap.get(Constants.COLUMN_UDF_13);
    Integer idxForUdf13 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf13);
    xlsRow.setUdf13(AppUtil.getCellValue(row.getCell(idxForUdf13)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

    
    customHeaderName = columnMap.get(Constants.COLUMN_UDF_14);
    Integer idxForUdf14 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf14);
    xlsRow.setUdf14(AppUtil.getCellValue(row.getCell(idxForUdf14)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

    
    customHeaderName = columnMap.get(Constants.COLUMN_UDF_15);
    Integer idxForUdf15 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf15);
    xlsRow.setUdf15(AppUtil.getCellValue(row.getCell(idxForUdf15)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

    
    customHeaderName = columnMap.get(Constants.COLUMN_UDF_16);
    Integer idxForUdf16 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf16);
    xlsRow.setUdf16(AppUtil.getCellValue(row.getCell(idxForUdf16)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

    
    customHeaderName = columnMap.get(Constants.COLUMN_UDF_17);
    Integer idxForUdf17 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf17);
    xlsRow.setUdf17(AppUtil.getCellValue(row.getCell(idxForUdf17)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

    
    customHeaderName = columnMap.get(Constants.COLUMN_UDF_18);
    Integer idxForUdf18 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf18);
    xlsRow.setUdf18(AppUtil.getCellValue(row.getCell(idxForUdf18)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

    
    customHeaderName = columnMap.get(Constants.COLUMN_UDF_19);
    Integer idxForUdf19 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf19);
    xlsRow.setUdf19(AppUtil.getCellValue(row.getCell(idxForUdf19)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

    
    customHeaderName = columnMap.get(Constants.COLUMN_UDF_20);
    Integer idxForUdf20 = colNameIndexMap.get(customHeaderName);
    checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf20);
    xlsRow.setUdf20(AppUtil.getCellValue(row.getCell(idxForUdf20)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

    
    xlsRow.setValid(true);
	xlsRow.setRowId(row.getRowNum());
	xlsRow.setExcelRowId(row.getRowNum());

	xlsRow.setInputType(AppUtil.getCellValue(row.getCell(idxForInputType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgInputType(AppUtil.getCellValue(row.getCell(idxForInputType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setDateOfPayment(DateUtil.getFormatedDate(AppUtil.getCellValue(row.getCell(idxForDateOfPayment)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
	xlsRow.setExcelDocType(AppUtil.getCellValue(row.getCell(idxForDocType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgDocType(AppUtil.getCellValue(row.getCell(idxForDocType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgSupplyType(AppUtil.getCellValue(row.getCell(idxForSupplyType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgImportType(AppUtil.getCellValue(row.getCell(idxForInputType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgDiffPercent(AppUtil.getCellValue(row.getCell(idxForDiffPercent)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setFillingPeriod(AppUtil.getCellValue(row.getCell(idxForFilingPeriod)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setHsnCode(AppUtil.getCellValue(row.getCell(idxForHsnCode)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgQuantity(AppUtil.getCellValue(row.getCell(idxForQuantity)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgItemRate(AppUtil.getCellValue(row.getCell(idxForItemRate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgAssAmt(AppUtil.getCellValue(row.getCell(idxForAssAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setAssAmt(AppUtil.getCellValue(row.getCell(idxForAssAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	if (!isNumeric(xlsRow.getAssAmt())) {
		if(StringUtils.isBlank(xlsRow.getAssAmt()))
    	{
    	    xlsRow.setAssAmt("0.0");
    	}
    	else
    	{
    		xlsRow.setAssAmt("0.0");
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00588, Constants.BLANK);
    	}
	}
	xlsRow.setOrgSgstRate(AppUtil.getCellValue(row.getCell(idxForSgstRate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgSgstAmt(AppUtil.getCellValue(row.getCell(idxForSgstAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgCgstRate(AppUtil.getCellValue(row.getCell(idxForCgstRate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgCgstAmt(AppUtil.getCellValue(row.getCell(idxForCgstAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgIgstRate(AppUtil.getCellValue(row.getCell(idxForIgstRate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgIgstAmt(AppUtil.getCellValue(row.getCell(idxForIgstAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgCessRate(AppUtil.getCellValue(row.getCell(idxForCessRate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgCessAmt(AppUtil.getCellValue(row.getCell(idxForCessAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgInwardGrossTotalAmount(
			AppUtil.getCellValue(row.getCell(idxForInwardGrossTotalAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgTotalInvAmt(AppUtil.getCellValue(row.getCell(idxForTotalInvoiceAMt)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgImportBillOfEntryAmt(
			AppUtil.getCellValue(row.getCell(idxForImportBillOfEntryAmt)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	String reverseCharge = AppUtil.getCellValue(row.getCell(idxForReverseCharge)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	xlsRow.setOrgReverseCharge(AppUtil.getCellValue(row.getCell(idxForReverseCharge)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	String itcIneligibleReversalIndicator = AppUtil
			.getCellValue(row.getCell(idxForItcIneligibleReversalIndicator)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");

	String itcPercent = AppUtil
			.getCellValue(row.getCell(idxForItcIneligibleReversalPercent)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	
	xlsRow.setItcIneligibleReversalIndicator(itcIneligibleReversalIndicator);
	xlsRow.setItcIneligibleReversalPercentage(itcPercent);

	String sgstAmt = AppUtil.getCellValue(row.getCell(idxForSgstAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	if (!isNumeric(sgstAmt)) {
    	if(StringUtils.isBlank(sgstAmt))
    	{
    		sgstAmt="0.0";
    	}
    	else
    	{
    		sgstAmt="0.0";
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00590, Constants.BLANK);
    	}
    
    }
	String cgstAmt = AppUtil.getCellValue(row.getCell(idxForCgstAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	if (!isNumeric(cgstAmt)) {
    	if(StringUtils.isBlank(cgstAmt))
    	{
    		cgstAmt="0.0";
    	}
    	else
    	{
    		cgstAmt="0.0";
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00591, Constants.BLANK);
    	}
    
    }
	String igstAmt = AppUtil.getCellValue(row.getCell(idxForIgstAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	if (!isNumeric(igstAmt)) {
    	if(StringUtils.isBlank(igstAmt))
    	{
    		igstAmt="0.0";
    	}
    	else
    	{
    		igstAmt="0.0";
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00592, Constants.BLANK);
    	}
    
    }
	String cessAmt = AppUtil.getCellValue(row.getCell(idxForCessAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	if (!isNumeric(cessAmt)) {
    	if(StringUtils.isBlank(cessAmt))
    	{
    		cessAmt="0.0";
    	}
    	else
    	{
    		cessAmt="0.0";
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00593, Constants.BLANK);
    	}
    
    }
	
	if ("NULL".equalsIgnoreCase(reverseCharge) || StringUtils.isBlank(reverseCharge)
			|| "0".equals(reverseCharge)) {
		reverseCharge = "N";
	}

	if ("NULL".equalsIgnoreCase(sgstAmt) || StringUtils.isBlank(sgstAmt) || DroolUtil.isEmpty(sgstAmt)) {
		sgstAmt = "0";
	}
	if ("NULL".equalsIgnoreCase(cgstAmt) || StringUtils.isBlank(cgstAmt) || DroolUtil.isEmpty(cgstAmt)) {
		cgstAmt = "0";
	}
	if ("NULL".equalsIgnoreCase(igstAmt) || StringUtils.isBlank(igstAmt) || DroolUtil.isEmpty(igstAmt)) {
		igstAmt = "0";
	}
	if ("NULL".equalsIgnoreCase(cessAmt) || StringUtils.isBlank(cessAmt) || DroolUtil.isEmpty(cessAmt)) {
		cessAmt = "0";
	}

	if (("NULL".equalsIgnoreCase(itcIneligibleReversalIndicator)
			|| StringUtils.isBlank(itcIneligibleReversalIndicator)
			|| DroolUtil.isEmpty(itcIneligibleReversalIndicator))
			&& ("NULL".equalsIgnoreCase(itcPercent) || StringUtils.isBlank(itcPercent)
					|| DroolUtil.isEmpty(itcPercent))) {
		itcPercent = "100";
	}

	String grossTotalAmt = AppUtil.getCellValue(row.getCell(idxForInwardGrossTotalAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	if (!isNumeric(grossTotalAmt)) {
		if(StringUtils.isBlank(grossTotalAmt))
    	{
    		grossTotalAmt="0.0";
    	}
    	else
    	{
    		grossTotalAmt="0.0";
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00039, Constants.BLANK);	
    	}
    }
	xlsRow.setInwardGrossTotalAmount(AppUtil.formatRateAmoutValues(grossTotalAmt));
	if (!isNumeric(xlsRow.getInwardGrossTotalAmount())) {
		if(StringUtils.isBlank(grossTotalAmt))
    	{
    		grossTotalAmt="0.0";
    	}
    	else
    	{
    		grossTotalAmt="0.0";
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00039, Constants.BLANK);	
    	}
	}
	String invTotalAmt = AppUtil.getCellValue(row.getCell(idxForTotalInvoiceAMt)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	xlsRow.setTotalInvoiceAmt(AppUtil.formatRateAmoutValues(invTotalAmt));
	if (!isNumeric(xlsRow.getTotalInvoiceAmt())) {
		if(StringUtils.isBlank(xlsRow.getTotalInvoiceAmt()))
    	{
			xlsRow.setTotalInvoiceAmt("0.0");
    	}
    	else
    	{
    		xlsRow.setTotalInvoiceAmt("0.0");
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00594, Constants.BLANK);
    	}
	}
	xlsRow.setGstinOfRecipient(
			AppUtil.getCellValue(row.getCell(idxForGstinReceipient)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setDocType(AppUtil.getCellValue(row.getCell(idxForDocType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgInvoiceCategory(AppUtil.getCellValue(row.getCell(idxForSupplyType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setInvoiceCategory(xlsRow.getOrgInvoiceCategory());
	xlsRow.setUserSupplyCat(xlsRow.getOrgInvoiceCategory());

	xlsRow.setDocNo(AppUtil.getCellValue(row.getCell(idxForDocNo)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	// xlsRow.setDocDate(AppUtil.formatDate(row.getCell(colNameIndexMap.get("doc_date"))));11
	xlsRow.setDocDate(DateUtil.getFormatedDate(AppUtil.getCellValue(row.getCell(idxForDocDate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));

	xlsRow.setOrgInvoiceNo(AppUtil.getCellValue(row.getCell(idxForOrgInvoiceNo)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setOrgInvoiceDate(DateUtil.getFormatedDate(AppUtil.getCellValue(row.getCell(idxForOrgInvoiceDate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
	xlsRow.setGstinOfSupplier(AppUtil.getCellValue(row.getCell(idxForGstinSupplier)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setSupplierName(AppUtil.getCellValue(row.getCell(idxForSupplierName))
			.replaceAll("[^A-Za-z0-9_\\-\\s\\&]", "").replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
//	xlsRow.setSupplierStateCode(dataFormatter.formatCellValue(row.getCell(colNameIndexMap.get("supplier_state_code"))).replaceAll("[\n\r]", " "));
	xlsRow.setSupplierStateCode(AppUtil.getCellValue(row.getCell(idxForSupplierStateCode))
			.replaceAll("[\n\r]", ""));
	xlsRow.setInwardNo(AppUtil.getCellValue(row.getCell(idxForInwarNo)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

//	xlsRow.setInwardDate(AppUtil.formatDate(row.getCell(colNameIndexMap.get("inward_date"))));33
	xlsRow.setInwardDate(DateUtil.getFormatedDate(AppUtil.getCellValue(row.getCell(idxForInwardDate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
	xlsRow.setItemName(AppUtil.getCellValue(row.getCell(idxForItemDescription))
			.replaceAll("[^A-Za-z0-9_\\-\\s\\&]", "").replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setHsnSacCode(AppUtil.getCellValue(row.getCell(idxForHsnCode)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setUom(AppUtil.getCellValue(row.getCell(idxForUom)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	String quantity = AppUtil.getCellValue(row.getCell(idxForQuantity))
            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
if(isNumeric(quantity)) {		
		BigDecimal quantityDecimal = new BigDecimal(quantity);
        xlsRow.setQuantity(String.valueOf(quantityDecimal.intValue()));
} else {
	if(StringUtils.isBlank(quantity))
	{	
	 xlsRow.setQuantity("0");
	}
	else
	{
		xlsRow.setQuantity("0");
		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00019, Constants.BLANK);	
	}
}


	String itemRate = AppUtil.getCellValue(row.getCell(idxForItemRate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	xlsRow.setItemRate(AppUtil.formatRateAmoutValues(itemRate));
	if (!isNumeric(xlsRow.getItemRate())) {
		if(StringUtils.isBlank(xlsRow.getItemRate()))
    	{
			xlsRow.setItemRate("0.0");
    	    
    	}
    	else
    	{
    		xlsRow.setItemRate("0.0");
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00017, Constants.BLANK);
        	
    	}
	}

	String inwardTaxableAmt = AppUtil.getCellValue(row.getCell(idxForAssAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	xlsRow.setInwardTaxableAmt(AppUtil.formatRateAmoutValues(inwardTaxableAmt));
	if (!isNumeric(inwardTaxableAmt)) {
		if(StringUtils.isBlank(inwardTaxableAmt))
    	{
			xlsRow.setInwardTaxableAmt("0.0");
    	}
    	else
    	{
    		xlsRow.setInwardTaxableAmt("0.0");
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00588, Constants.BLANK);
    	}
		
	}

	String sgstRate = AppUtil.getCellValue(row.getCell(idxForSgstRate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	if (!isNumeric(sgstRate)) {
    	if(StringUtils.isBlank(sgstRate))
    	{
    	     sgstRate = "0.0";
    	}
    	else
    	{
    		sgstRate = "0.0";
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00024, Constants.BLANK);
    	}
    }
	if (!isNumeric(sgstRate)) {
		sgstRate="0.0";
	}
	xlsRow.setSgstRate(AppUtil.formatRateAmoutValues(sgstRate));
	

	String cgstRate = AppUtil.getCellValue(row.getCell(idxForCgstRate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	if(StringUtils.isBlank(cgstRate))
	{
		cgstRate = "0.0";
	}
	else
	{
		cgstRate = "0.0";
		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00024, Constants.BLANK);
	}
	if (!isNumeric(cgstRate)) {
		cgstRate="0.0";
	}
	xlsRow.setCgstRate(AppUtil.formatRateAmoutValues(cgstRate));
	
	
	String igstRate = AppUtil.getCellValue(row.getCell(idxForIgstRate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	if (!isNumeric(igstRate)) {
		if(StringUtils.isBlank(igstRate))
    	{
    		igstRate = "0.0";
    	}
    	else
    	{
    		igstRate = "0.0";
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00027, Constants.BLANK);
    	}
	}
	xlsRow.setIgstRate(AppUtil.formatRateAmoutValues(igstRate));
	
	
	String cessRate = AppUtil.getCellValue(row.getCell(idxForCessRate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	xlsRow.setCessRate(AppUtil.formatRateAmoutValues(cessRate));
	if (!isNumeric(xlsRow.getCessRate())) {
		if(StringUtils.isBlank(cessRate))
    	{
			xlsRow.setCessRate("0.0");
    	}
    	else
    	{
    		xlsRow.setCessRate("0.0");
    		markErrorNAddErrorCode(xlsRow, ValidationConstant.EINVOICE_ERROR_CODE_E00036, Constants.BLANK);
    	}
		
	}
	
	if (StringUtils.isBlank(xlsRow.getCessRate())) {
		xlsRow.setCessRate(String.valueOf("0"));
	}
	 if (StringUtils.isBlank(xlsRow.getCgstRate())) {
         xlsRow.setCgstRate(String.valueOf("0"));
     }
     if (StringUtils.isBlank(xlsRow.getSgstRate())) {
         xlsRow.setSgstRate(String.valueOf("0"));
     }
	String diffPercent = AppUtil.getCellValue(row.getCell(idxForDiffPercent)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	if (StringUtils.isBlank(diffPercent) || "NULL".equalsIgnoreCase(diffPercent)) {
		diffPercent = "0.00";
	}
	xlsRow.setDiffPercent(AppUtil.formatRateAmoutValues(diffPercent));

	xlsRow.setImportType(AppUtil.getCellValue(row.getCell(idxForInputType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

	String pos = AppUtil.getCellValue(row.getCell(idxForPlaceOfSupply)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	if (StringUtils.isNotBlank(pos) && pos.length() == 1) {
		xlsRow.setPlaceOfSupply("0" + pos);
	} else {
		xlsRow.setPlaceOfSupply(pos);
	}

	xlsRow.setPort(AppUtil.getCellValue(row.getCell(idxForPort)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

	xlsRow.setImportBillOfEntryNo(
			AppUtil.getCellValue(row.getCell(idxForImportBillOfEntryNo)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

//	xlsRow.setImportBillOfEntryDate(AppUtil.formatDate(row.getCell(colNameIndexMap.get("import_bill_of_entry_date"))));44
	xlsRow.setImportBillOfEntryDate(
			DateUtil.getFormatedDate(AppUtil.getCellValue(row.getCell(idxForImportBillOfEntryDate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));

	String importBillOfEntryAmt = AppUtil
			.getCellValue(row.getCell(idxForImportBillOfEntryAmt)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
	xlsRow.setImportBillOfEntryAmt(importBillOfEntryAmt);
	if (!isNumeric(xlsRow.getImportBillOfEntryAmt())) {
		if(StringUtils.isBlank(importBillOfEntryAmt))
    	{
			xlsRow.setImportBillOfEntryAmt("0.0");
    	}
    	else
    	{
    		xlsRow.setImportBillOfEntryAmt("0.0");
    		markErrorNAddErrorCode(xlsRow, ValidationConstant.EINVOICE_ERROR_CODE_E00589, Constants.BLANK);
    	}
		
	}
	// inwardItcInvCdnTemplate.setPreGst(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("pre_gst")),
	// evaluator));
	xlsRow.setIrn(AppUtil.getCellValue(row.getCell(idxForIrn)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setSupplyType(AppUtil.getCellValue(row.getCell(idxForSupplyType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
//	xlsRow.setAck_date(AppUtil.formatDate(row.getCell(colNameIndexMap.get("ack_date"))));
	xlsRow.setAckDate(DateUtil.getFormatedDate(AppUtil.getCellValue(row.getCell(idxForAckDate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
	xlsRow.setAckNo(AppUtil.getCellValue(row.getCell(idxForAckNo)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

	xlsRow.setDebitGlId(AppUtil.getCellValue(row.getCell(idxForDebitGlId)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setDebitGlName(AppUtil.getCellValue(row.getCell(idxForDebitGlName)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setCreditGlId(AppUtil.getCellValue(row.getCell(idxForCreditGlId)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setCreditGlName(AppUtil.getCellValue(row.getCell(idxForCreditGlName)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
	xlsRow.setSubLocation(AppUtil.getCellValue(row.getCell(idxForSubLocation)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

	xlsRow.setReverseCharge(reverseCharge);


	if ("NIL".equalsIgnoreCase(xlsRow.getOrgInvoiceCategory())) {
		xlsRow.setNilRatedAmt(AppUtil.formatRateAmoutValues(xlsRow.getOrgAssAmt()));
	} else {
		xlsRow.setNilRatedAmt(AppUtil.formatRateAmoutValues("0.00"));
	}
	if ("EXM".equalsIgnoreCase(xlsRow.getOrgInvoiceCategory())) {
		xlsRow.setExemptedAmt(AppUtil.formatRateAmoutValues(xlsRow.getOrgAssAmt()));
	} else {
		xlsRow.setExemptedAmt(AppUtil.formatRateAmoutValues("0.00"));
	}
	if ("NON".equalsIgnoreCase(xlsRow.getOrgInvoiceCategory())) {
		xlsRow.setNonGstAmt(AppUtil.formatRateAmoutValues(xlsRow.getOrgAssAmt()));
	} else {
		xlsRow.setNonGstAmt(AppUtil.formatRateAmoutValues("0.00"));
	}

	if ("COMP".equalsIgnoreCase(xlsRow.getOrgInvoiceCategory())) {
		xlsRow.setCompositionAmt(AppUtil.formatRateAmoutValues(xlsRow.getOrgAssAmt()));
	} else {
		xlsRow.setCompositionAmt(AppUtil.formatRateAmoutValues("0.00"));
	}

	if (xlsRow.getDateOfPayment().equals("00-01-1900") || xlsRow.getDateOfPayment().equals("31/12/1899")
			|| xlsRow.getDateOfPayment().equals("31-12-1899")) {
		xlsRow.setDateOfPayment("0");
	}

	if (xlsRow.getImportBillOfEntryDate().equals("00-01-1900")
			|| xlsRow.getImportBillOfEntryDate().equals("31/12/1899")
			|| xlsRow.getImportBillOfEntryDate().equals("31-12-1899")) {
		xlsRow.setImportBillOfEntryDate("0");
	}

	xlsRow.setSgstAmt(sgstAmt);
	xlsRow.setCgstAmt(cgstAmt);
	xlsRow.setIgstAmt(igstAmt);
	xlsRow.setCessAmount(cessAmt);

	/************* Amount Calculation Start ************************/

	if (!isNumeric(sgstAmt)) {
		sgstAmt = "0.0";
	}

	if (!isNumeric(cgstAmt)) {
		cgstAmt = "0.0";
	}

	if (!isNumeric(cessAmt)) {
		cessAmt = "0.0";
	}

	if (!isNumeric(igstAmt)) {
		igstAmt = "0.0";
	}

	BigDecimal igst = new BigDecimal(igstAmt);
	BigDecimal sgst = new BigDecimal(sgstAmt);
	BigDecimal cgst = new BigDecimal(cgstAmt);
	BigDecimal cess = new BigDecimal(cessAmt);

	BigDecimal itcIgst = new BigDecimal(igstAmt);
	BigDecimal itcSgst = new BigDecimal(sgstAmt);
	BigDecimal itcCgst = new BigDecimal(cgstAmt);
	BigDecimal itcCess = new BigDecimal(cessAmt);

	BigDecimal totalTaxAmt = new BigDecimal(0);
	totalTaxAmt = totalTaxAmt.add(sgst).add(cgst).add(igst).add(cess);
	

	xlsRow.setTotalTaxAmount(totalTaxAmt.toString());


	if (DroolUtil.containsNumbersOnly(itcPercent, 1)) {
		itcSgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), sgst);
		itcCgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), cgst);
		itcIgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), igst);
		itcCess = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), cess);
	}

	xlsRow.setItcSgstAmt(itcSgst.toString());
	xlsRow.setItcCgstAmt(itcCgst.toString());
	xlsRow.setItcIgstAmt(itcIgst.toString());
	xlsRow.setItcCessAmt(itcCess.toString());

	xlsRow.setGrossTotalAmount(grossTotalAmt);

	BigDecimal totalITCTaxAmt = new BigDecimal(0);
	totalITCTaxAmt = totalITCTaxAmt.add(itcSgst).add(itcCgst).add(itcIgst).add(itcCess);
	xlsRow.setInwardTotalTaxAmt(totalTaxAmt.toString());
	xlsRow.setTotalItcAmt(totalITCTaxAmt.toString());
	xlsRow.setTaxableAmount(xlsRow.getAssAmt());
	
	 if (!isNumeric(importBillOfEntryAmt)) {
     	importBillOfEntryAmt = "0.0";
     }

     if (!isNumeric(inwardTaxableAmt)) {
     	inwardTaxableAmt = "0.0";
     }

     
     customHeaderName = columnMap.get(Constants.PAYMENT_AMOUNT);
     Integer indexForPaymentAmount = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexForPaymentAmount);
     xlsRow.setPaymentAmount(AppUtil.getCellValue(row.getCell(indexForPaymentAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
 
     xlsRow.setOrgPaymentAmount(AppUtil.getCellValue(row.getCell(indexForPaymentAmount))
             .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));    
     if (!isNumeric(xlsRow.getPaymentAmount())) {
    	 if(StringUtils.isBlank(xlsRow.getPaymentAmount()))
     	{
     	    xlsRow.setPaymentAmount("0.0");
     	}
     	else
     	{
     		xlsRow.setPaymentAmount("0.0");
     		markErrorNAddErrorCode(xlsRow, ValidationConstant.EINVOICE_ERROR_CODE_I50031, Constants.BLANK);
     	}
      }
     
     customHeaderName = columnMap.get(Constants.PAYMENT_REF_NO);
     Integer indexForPaymentRefNo = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexForPaymentRefNo);
     xlsRow.setPaymentRefNo(AppUtil.getCellValue(row.getCell(indexForPaymentRefNo)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

     customHeaderName = columnMap.get(Constants.TDS_SECTION);
     Integer indexForTdsSection = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexForTdsSection);
     xlsRow.setTdsSection(AppUtil.getCellValue(row.getCell(indexForTdsSection)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

     customHeaderName = columnMap.get(Constants.TDS_RATE);
     Integer indexForTdsRate = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexForTdsRate);
     xlsRow.setTdsRate(AppUtil.getCellValue(row.getCell(indexForTdsRate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
     xlsRow.setOrgTdsRate(AppUtil.getCellValue(row.getCell(indexForTdsRate))
             .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
     
     if (!isNumeric(xlsRow.getTdsRate())) {
        if(StringUtils.isBlank(xlsRow.getTdsRate()))
     	{
     	    xlsRow.setTdsRate("0.0");
     	}
     	else
     	{
     		xlsRow.setTdsRate("0.0");
     		markErrorNAddErrorCode(xlsRow, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00563, Constants.BLANK);
     	}
          
      }
     
     customHeaderName = columnMap.get(Constants.TDS_TAX_AMOUNT);
     Integer indexForTdsTaxAmount = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexForTdsTaxAmount);
     xlsRow.setTdsTaxAmount(AppUtil.getCellValue(row.getCell(indexForTdsTaxAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
     xlsRow.setOrgTdsTaxAmount(AppUtil.getCellValue(row.getCell(indexForTdsTaxAmount))
             .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
    
customHeaderName = columnMap.get(Constants.CHALLAN_NUMBER);
     Integer indexForChallanNumber = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexForChallanNumber);
     xlsRow.setChallanNumber(AppUtil.getCellValue(row.getCell(indexForChallanNumber)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

     customHeaderName = columnMap.get(Constants.CHALLAN_DATE);
     Integer indexForChallanDate = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexForChallanDate);
     xlsRow.setChallanDate(AppUtil.getCellValue(row.getCell(indexForChallanDate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

     customHeaderName = columnMap.get(Constants.CHALLAN_AMOUNT);
     Integer indexForChallanAmount = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexForChallanAmount);
     xlsRow.setChallanAmount(AppUtil.getCellValue(row.getCell(indexForChallanAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
     xlsRow.setOrgChallanAmount(AppUtil.getCellValue(row.getCell(indexForChallanAmount))
             .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
				

     if (!isNumeric(xlsRow.getChallanAmount())) {
    	 if(StringUtils.isBlank(xlsRow.getChallanAmount()))
     	{
     	    xlsRow.setChallanAmount("0.0");
     	}
     	else
     	{
     		xlsRow.setChallanAmount("0.0");
     		markErrorNAddErrorCode(xlsRow, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00531, Constants.BLANK);
     	}

      }
     
     customHeaderName = columnMap.get(Constants.PERIOD_OF_FILLING);
     Integer indexForPeriodOfFilling = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexForPeriodOfFilling);
     xlsRow.setPeriodOfFiling(AppUtil.getCellValue(row.getCell(indexForPeriodOfFilling)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

     customHeaderName = columnMap.get(Constants.INVOICE_AGAINST_PROV_ADV);
     Integer indexForInvoiceAgainstProvAdv = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexForInvoiceAgainstProvAdv);
     xlsRow.setInvoiceAgainstProvAdv(AppUtil.getCellValue(row.getCell(indexForInvoiceAgainstProvAdv)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

     customHeaderName = columnMap.get(Constants.INWARD_NO_PROV_ADV);
     Integer indexForInwardNoProvAdv = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexForInwardNoProvAdv);
     xlsRow.setInwardNoProvAdv(AppUtil.getCellValue(row.getCell(indexForInwardNoProvAdv)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

     customHeaderName = columnMap.get(Constants.INWARD_DATE_PROV_ADV);
     Integer indexForInwardDateProvAdv = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexForInwardDateProvAdv);
     xlsRow.setInwardDateProvAdv(AppUtil.getCellValue(row.getCell(indexForInwardDateProvAdv)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

     customHeaderName = columnMap.get(Constants.AMOUNT_OF_PROV_ADV);
     Integer indexForAmountOfProvAdv = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexForAmountOfProvAdv);
     xlsRow.setAmountOfProvAdv(AppUtil.getCellValue(row.getCell(indexForAmountOfProvAdv)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
     
     xlsRow.setOrgAmountOfProvAdv(AppUtil.getCellValue(row.getCell(indexForAmountOfProvAdv))
             .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

     if (!isNumeric(xlsRow.getAmountOfProvAdv())) {
    	 if(StringUtils.isBlank(xlsRow.getAmountOfProvAdv()))
     	{
     	    xlsRow.setAmountOfProvAdv("0.0");
     	}
     	else
     	{
     		xlsRow.setAmountOfProvAdv("0.0");
     		markErrorNAddErrorCode(xlsRow, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00536, Constants.BLANK);
     	}
      }
     
     customHeaderName = columnMap.get(Constants.BAL_OUTSTANDING);
     Integer indexBalOutstanding = colNameIndexMap.get(customHeaderName);
     checkForInvalidTemplate(uploadDTO, customHeaderName, indexBalOutstanding);
     xlsRow.setBalOutstanding(AppUtil.getCellValue(row.getCell(indexBalOutstanding)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
     xlsRow.setOrgBalOutstanding(AppUtil.getCellValue(row.getCell(indexBalOutstanding))
             .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
     if (!isNumeric(xlsRow.getBalOutstanding())) {
     	if(StringUtils.isBlank(xlsRow.getBalOutstanding()))
     	{
     	    xlsRow.setBalOutstanding("0.0");
     	}
     	else
     	{
     		xlsRow.setBalOutstanding("0.0");
     		markErrorNAddErrorCode(xlsRow, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00595, Constants.BLANK);
     	}
     	
     }
     
} catch (Exception ex) {
    // Mark as not Valid object if Exception occur
    log.error("Error generated while reading xls ", ex);
    markErrorNAddErrorCode(xlsRow, ValidationConstant.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
    ExceptionLogDTO exceptionLogDto = new ExceptionLogDTO();
    exceptionLogDto.setUserId(uploadDTO.getUploadBy());
    exceptionLogDto.setScreenName(Constants.INVOICEINTEGRATION);
    exceptionLogDto.setFunctionName("readTemplateRecord");
    exceptionLogDto.setErrorMessage(ex.getMessage());
    exceptionLogDto.setErrorCause(ex.getCause().getMessage());
    exceptionLogDto.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
    exceptionLogDto.setCreatedAt(LocalDateTime.now());

    commonCommunicationDao.updateExceptionLogTable(exceptionLogDto);

    log.error("Errro occured while reading row " + row.getRowNum() + " for batch No. " + ex);
}
return xlsRow;
}


    public static boolean isNumeric(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}



	private void checkForInvalidTemplate(UploadReqDTO uploadDTO, String customHeaderName,
			Integer idxForGstinReceipient) {
//		 if (customHeaderName.indexOf("of_recipient") > 0) {
//	            customHeaderName = "﻿gstin_of_recipient";
//	        }
		
	}


	public Map<String, Object> getRowCountWithHeader(InputStream fis, UploadReqDTO uploadDTO)
			throws IOException, VendorInvoiceServerException {
		Map<String, Object> dataMap = new HashMap<>();
		String methodName = "getRowCountWithHeader";
		int totalRowCount = 0;
		try (InputStream is = new BufferedInputStream(fis); Workbook workbook = StreamingReader.builder().open(is);) {

			Sheet sheet = workbook.getSheetAt(0);
			for (Row row : sheet) {
				if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 1) {
					totalRowCount++;
				} else if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() <= 0 && totalRowCount == 0) {

					Row coumnsDataRow = null;
					coumnsDataRow = row;
					dataMap.put("headerRowIndex", row.getRowNum());
					dataMap.put("coumnsDataRow", coumnsDataRow);

				}

			}
			dataMap.put("RowCount", totalRowCount);
			return dataMap;
		} catch (Exception ex) {

			logIntoToExceptionTable(uploadDTO, ex, methodName);
			throw new VendorInvoiceServerException(StringConstant.HEADERCOUNTERRORMESSAGE + uploadDTO.getBatchNo());

		}

	}
	
	public Map<String, Object> getRowCustomCountWithHeader(InputStream fis, UploadReqDTO uploadDTO)
			throws IOException, VendorInvoiceServerException {
		Map<String, Object> dataMap = new HashMap<>();
		String methodName = "getRowCountWithHeader";
		int totalRowCount = 0;
		try (InputStream is = new BufferedInputStream(fis); Workbook workbook = StreamingReader.builder().open(is);) {

			Sheet sheet = workbook.getSheetAt(0);
			for (Row row : sheet) {
				if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 0) {
					totalRowCount++;
				} else if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() <= 0 && totalRowCount == 0) {

					Row coumnsDataRow = null;
					coumnsDataRow = row;
					dataMap.put("headerRowIndex", row.getRowNum());
					dataMap.put("coumnsDataRow", coumnsDataRow);

				}

			}
			dataMap.put("RowCount", totalRowCount);
			return dataMap;
		} catch (Exception ex) {

			logIntoToExceptionTable(uploadDTO, ex, methodName);
			throw new VendorInvoiceServerException(StringConstant.HEADERCOUNTERRORMESSAGE + uploadDTO.getBatchNo());

		}

	}
	
	 private void logIntoToExceptionTable(UploadReqDTO uploadDTO, Exception ex, String functionName) {
	        ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
	        exceptionLogDTO.setUserId(uploadDTO.getId());
	        exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
	        exceptionLogDTO.setFunctionName(functionName);
	        exceptionLogDTO.setErrorMessage(ex.getMessage());
	        exceptionLogDTO.setErrorCause(Constants.NOTCONTAINPROPERDATA);
	        exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
	        exceptionLogDTO.setCreatedAt(LocalDateTime.now());

	        commonCommunicationDao.updateExceptionLogTable(exceptionLogDTO);
	    }
	 
	 private void markErrorNAddErrorCode(InwardInvoiceCDNTemplateDTO rowData, String errorCode, String errorMessage) {
	        log.info("Entering markErrorNAddErrorCode Method ");
	        rowData.setValid(false);
	        rowData.setErrorCodeList(rowData.getErrorCodeList().append(errorCode));
	        rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(errorMessage));
	    }


	public void getInwardDataListCDV(UploadReqDTO reqDto, Map<String, String> customTemplateHeaderMappings,
			char delimiter, List<InwardInvoiceCDNTemplateDTO> invDataList,
			List<InwardInvoiceCDNTemplateDTO> cdnDataList, List<InwardInvoiceCDNTemplateDTO> rowDocErrorPojoList) throws VendorInvoiceServerException {

        Iterable<CSVRecord> records = null;
       
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(reqDto.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(reqDto.getFileType());

        File file = new File(fileName.toString());
        Path path = file.toPath();

        Map<String, Integer> columnIndexMap = new HashMap<>();

        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String headerLine = reader.readLine();
            String[] headers = headerLine.split(",");

            Map<String, String> customTemplateMap = new HashMap<>();
            String columnNameNotMatchedWithTemplate = "";
            for (Entry<String, String> map : customTemplateHeaderMappings.entrySet()) {

                byte[] bytes = map.getValue().trim().getBytes();
                String str = new String(bytes, StandardCharsets.UTF_8);

                customTemplateMap.put(str, str);
            }

            for (int cnt = 0; cnt <= headers.length - 1; cnt++) {
                byte[] bytes = headers[cnt].trim().getBytes();
                String str = new String(bytes, StandardCharsets.UTF_8).replaceAll("[^a-zA-Z0-9\\s+_-]", "");
                columnIndexMap.put(str, cnt);
                if (!str.trim().equals(customTemplateMap.get(str))) {
                    if ("".equals(columnNameNotMatchedWithTemplate)) {
                        columnNameNotMatchedWithTemplate = columnNameNotMatchedWithTemplate + headers[cnt];
                    } else {
                        columnNameNotMatchedWithTemplate = columnNameNotMatchedWithTemplate + "," + headers[cnt];
                    }

                }

            }

            if (columnNameNotMatchedWithTemplate.length() > 2) {
                log.error("Uploaded file(s) some columns does not matching with defined template");
                uploadTransDao.updateProcessStatus(reqDto.getBatchNo(),
                                Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);
                throw new VendorInvoiceServerException(
                                "Uploaded file(s) some columns does not matching with defined template,column(s) are "
                                                + columnNameNotMatchedWithTemplate);
            }

            records = CSVFormat.DEFAULT.withDelimiter(delimiter).withAllowMissingColumnNames(true).parse(reader);

            sftpSet = new HashSet<>();
            for (CSVRecord csvRecord : records) {

                boolean isEmptyRow = true;
                for (String value : csvRecord) {
                    if (!value.trim().isEmpty()) {
                        isEmptyRow = false;
                        break;
                    }
                }

                if (!isEmptyRow) {
                    readCsvCustomRecord(reqDto, csvRecord, customTemplateHeaderMappings, invDataList,cdnDataList,rowDocErrorPojoList,
                                    columnIndexMap);
                }

            }
            if("ftps".equals(reqDto.getUploadSource()))
            {
            	reqDto.setMonth(new ArrayList<>(sftpSet));
            }

        } catch (Exception e) {
            log.error("Error in getEinvoiceDataListCDV method ", e);
            if (e.getMessage().contains("matching with defined template,column(s)")) {
                throw new VendorInvoiceServerException(e.getMessage());
            } else {
                throw new VendorInvoiceServerException("Error while reading custom template for vendor details import ",
                                e);
            }
        } finally {
            records = null;
        }
        if ("ftps".equals(reqDto.getUploadType()) || reqDto.getFp().isEmpty()) {
        	reqDto.setMonth(new ArrayList<>(sftpSet));
        	uploadTransDao.updateFpLog(reqDto.getMonth(), reqDto);
        }
     
	}


	private void readCsvCustomRecord(UploadReqDTO reqDto, CSVRecord csvRecord,
			Map<String, String> customTemplateHeaderMappings, List<InwardInvoiceCDNTemplateDTO> inwardINVDataList,
			List<InwardInvoiceCDNTemplateDTO> inwardCDNDataList,
			List<InwardInvoiceCDNTemplateDTO> inwardDocErrorDataList, Map<String, Integer> columnIndexMap) {

		InwardInvoiceCDNTemplateDTO vendorUploadStage1 = new InwardInvoiceCDNTemplateDTO();
		vendorUploadStage1.setValid(true);
		String taxpayerGSTCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT);
		vendorUploadStage1.setGstinOfRecipient(csvRecord.get(columnIndexMap.get(taxpayerGSTCustomHeaderName)));

//        xlsRow.setRowId(row.getRowNum());
//        xlsRow.setExcelRowId(row.getRowNum());
		String OrgInvoiceNoCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_ORG_INVOICE_NO);
		vendorUploadStage1.setOrgInvoiceNo(csvRecord.get(columnIndexMap.get(OrgInvoiceNoCustomHeaderName)));

		String OrgInvoiceDateCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_ORG_INVOICE_DATE);
		vendorUploadStage1.setOrgInvoiceDate(csvRecord.get(columnIndexMap.get(OrgInvoiceDateCustomHeaderName)));

		String inputTypeCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_INPUT_TYPE);
		vendorUploadStage1.setInputType(csvRecord.get(columnIndexMap.get(inputTypeCustomHeaderName)));

		String orgInputTypeCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_INPUT_TYPE);
		vendorUploadStage1.setOrgInputType(csvRecord.get(columnIndexMap.get(orgInputTypeCustomHeaderName)));

		String dateOfPaymentCustomHeaderName = customTemplateHeaderMappings.get(Constants.DATE_OF_PAYMENT);
		vendorUploadStage1.setDateOfPayment(csvRecord.get(columnIndexMap.get(dateOfPaymentCustomHeaderName)));

		String excelDocTypeCustomHeaderName = customTemplateHeaderMappings.get(Constants.DOC_TYPE);
		vendorUploadStage1.setExcelDocType(csvRecord.get(columnIndexMap.get(excelDocTypeCustomHeaderName)));

		String orgDocTypeCustomHeaderName = customTemplateHeaderMappings.get(Constants.DOC_TYPE);
		vendorUploadStage1.setOrgDocType(csvRecord.get(columnIndexMap.get(orgDocTypeCustomHeaderName)));

		String orgSupplyTypeCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_SUPPLY_TYPE);
		vendorUploadStage1.setOrgSupplyType(csvRecord.get(columnIndexMap.get(orgSupplyTypeCustomHeaderName)));

		String orgImportTypeCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_INPUT_TYPE);
		vendorUploadStage1.setOrgImportType(csvRecord.get(columnIndexMap.get(orgImportTypeCustomHeaderName)));

		String orgDiffPercentCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_DIFF_PERCENT);
		vendorUploadStage1.setOrgDiffPercent(csvRecord.get(columnIndexMap.get(orgDiffPercentCustomHeaderName)));

		String orgFillinfPeriodCustomHeaderName = customTemplateHeaderMappings.get(Constants.FILLING_PERIOD);
		vendorUploadStage1.setFillingPeriod(csvRecord.get(columnIndexMap.get(orgFillinfPeriodCustomHeaderName)));

		String orgHsnCodeCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_HSN_CODE);
		vendorUploadStage1.setHsnCode(csvRecord.get(columnIndexMap.get(orgHsnCodeCustomHeaderName)));

		String orgOrgItemRateCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_ITEM_RATE);
		vendorUploadStage1.setOrgItemRate(csvRecord.get(columnIndexMap.get(orgOrgItemRateCustomHeaderName)));

		String orgOrgAssAmtCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_ASS_AMOUNT);
		vendorUploadStage1.setOrgAssAmt(csvRecord.get(columnIndexMap.get(orgOrgAssAmtCustomHeaderName)));

		String orgAssAmtCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_ASS_AMOUNT);
		vendorUploadStage1.setOrgAssAmt(csvRecord.get(columnIndexMap.get(orgAssAmtCustomHeaderName)));
		if (!isNumeric(vendorUploadStage1.getAssAmt())) {
			if(StringUtils.isBlank(vendorUploadStage1.getAssAmt()))
        	{
				vendorUploadStage1.setAssAmt("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setAssAmt("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00588, Constants.BLANK);
        	}

		}

		String orgOrgSgstRateCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_SGST_RATE);
		vendorUploadStage1.setOrgSgstRate(csvRecord.get(columnIndexMap.get(orgOrgSgstRateCustomHeaderName)));

		String orgOrgSgstAmtCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_SGST_AMOUNT);
		vendorUploadStage1.setOrgSgstAmt(csvRecord.get(columnIndexMap.get(orgOrgSgstAmtCustomHeaderName)));

		String orgOrgCgstRateCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_CGST_RATE);
		vendorUploadStage1.setOrgCgstRate(csvRecord.get(columnIndexMap.get(orgOrgCgstRateCustomHeaderName)));

		String orgOrgCgstAmtCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_CGST_AMOUNT);
		vendorUploadStage1.setOrgCgstAmt(csvRecord.get(columnIndexMap.get(orgOrgCgstAmtCustomHeaderName)));

		String orgOrgIgstRateCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_IGST_RATE);
		vendorUploadStage1.setOrgIgstRate(csvRecord.get(columnIndexMap.get(orgOrgIgstRateCustomHeaderName)));

		String orgOrgIgstAmtCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_IGST_AMOUNT);
		vendorUploadStage1.setOrgIgstAmt(csvRecord.get(columnIndexMap.get(orgOrgIgstAmtCustomHeaderName)));

		String orgOrgCessCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_CESS_RATE);
		vendorUploadStage1.setOrgCessRate(csvRecord.get(columnIndexMap.get(orgOrgCessCustomHeaderName)));

		String orgOrgCessAmtCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_CESS_AMOUNT);
		vendorUploadStage1.setOrgCessAmt(csvRecord.get(columnIndexMap.get(orgOrgCessAmtCustomHeaderName)));

		String setOrgInwardGrossTotalAmount = customTemplateHeaderMappings
				.get(Constants.COLUMN_INWARD_GROSS_TOTAL_AMOUNT);
		vendorUploadStage1
				.setOrgInwardGrossTotalAmount(csvRecord.get(columnIndexMap.get(setOrgInwardGrossTotalAmount)));

		String setOrgTotalInvAmt = customTemplateHeaderMappings.get(Constants.COLUMN_TOTAL_INVOICE_AMOUNT);
		vendorUploadStage1.setOrgTotalInvAmt(csvRecord.get(columnIndexMap.get(setOrgTotalInvAmt)));

		String setOrgImportBillOfEntryAmt = customTemplateHeaderMappings.get(Constants.COLUMN_IMPORT_BILL_OF_ENTRY_AMT);
		vendorUploadStage1.setOrgImportBillOfEntryAmt(csvRecord.get(columnIndexMap.get(setOrgImportBillOfEntryAmt)));

		String setOrgReverseCharge = customTemplateHeaderMappings.get(Constants.COLUMN_REVERSE_CHARGE);
		String reverseCharge = csvRecord.get(columnIndexMap.get(setOrgImportBillOfEntryAmt));
		vendorUploadStage1.setOrgReverseCharge(csvRecord.get(columnIndexMap.get(setOrgReverseCharge)));

		String setItcIneligibleReversalIndicator = customTemplateHeaderMappings
				.get(Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_INDICATOR);
		String itcIneligibleReversalIndicator = csvRecord.get(columnIndexMap.get(setItcIneligibleReversalIndicator));

		String itcPercentIdx = customTemplateHeaderMappings.get(Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_PERCENTAGE);
		String itcPercent = csvRecord.get(columnIndexMap.get(itcPercentIdx));

		vendorUploadStage1.setItcIneligibleReversalIndicator(itcIneligibleReversalIndicator);
		vendorUploadStage1.setItcIneligibleReversalPercentage(itcPercent);

		String sgstAmt = csvRecord.get(columnIndexMap.get(orgOrgSgstAmtCustomHeaderName));
		if (!isNumeric(sgstAmt)) {
        	if(StringUtils.isBlank(sgstAmt))
        	{
        		sgstAmt="0.0";
        	}
        	else
        	{
        		sgstAmt="0.0";
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00590, Constants.BLANK);
        	}
        
        }
		String cgstAmt = csvRecord.get(columnIndexMap.get(orgOrgCgstAmtCustomHeaderName));
		if (!isNumeric(cgstAmt)) {
        	if(StringUtils.isBlank(cgstAmt))
        	{
        		cgstAmt="0.0";
        	}
        	else
        	{
        		cgstAmt="0.0";
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00591, Constants.BLANK);
        	}
        
        }
		String igstAmt = csvRecord.get(columnIndexMap.get(orgOrgIgstAmtCustomHeaderName));
		if (!isNumeric(igstAmt)) {
        	if(StringUtils.isBlank(igstAmt))
        	{
        		igstAmt="0.0";
        	}
        	else
        	{
        		igstAmt="0.0";
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00592, Constants.BLANK);
        	}
        
        }
		String cessAmt = csvRecord.get(columnIndexMap.get(orgOrgCessAmtCustomHeaderName));
		if (!isNumeric(cessAmt)) {
        	if(StringUtils.isBlank(cessAmt))
        	{
        		cessAmt="0.0";
        	}
        	else
        	{
        		igstAmt="0.0";
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00593, Constants.BLANK);
        	}
        
        }
		if ("NULL".equalsIgnoreCase(reverseCharge) || StringUtils.isBlank(reverseCharge) || "0".equals(reverseCharge)) {
			reverseCharge = "N";
		}

		if ("NULL".equalsIgnoreCase(sgstAmt) || StringUtils.isBlank(sgstAmt) || DroolUtil.isEmpty(sgstAmt)) {
			sgstAmt = "0";
		}
		if ("NULL".equalsIgnoreCase(cgstAmt) || StringUtils.isBlank(cgstAmt) || DroolUtil.isEmpty(cgstAmt)) {
			cgstAmt = "0";
		}
		if ("NULL".equalsIgnoreCase(igstAmt) || StringUtils.isBlank(igstAmt) || DroolUtil.isEmpty(igstAmt)) {
			igstAmt = "0";
		}
		if ("NULL".equalsIgnoreCase(cessAmt) || StringUtils.isBlank(cessAmt) || DroolUtil.isEmpty(cessAmt)) {
			cessAmt = "0";
		}

		if (("NULL".equalsIgnoreCase(itcIneligibleReversalIndicator)
				|| StringUtils.isBlank(itcIneligibleReversalIndicator)
				|| DroolUtil.isEmpty(itcIneligibleReversalIndicator))
				&& ("NULL".equalsIgnoreCase(itcPercent) || StringUtils.isBlank(itcPercent)
						|| DroolUtil.isEmpty(itcPercent))) {
			itcPercent = "100";
		}

		String grossTotalAmt = csvRecord.get(columnIndexMap.get(setOrgInwardGrossTotalAmount));
		if (!isNumeric(grossTotalAmt)) {
			if(StringUtils.isBlank(grossTotalAmt))
        	{
        		grossTotalAmt="0.0";
        	}
        	else
        	{
        		grossTotalAmt="0.0";
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00039, Constants.BLANK);	
        	}
		}
		vendorUploadStage1.setInwardGrossTotalAmount(AppUtil.formatRateAmoutValues(grossTotalAmt));
		String invTotalAmt = csvRecord.get(columnIndexMap.get(setOrgTotalInvAmt));
		if (!isNumeric(invTotalAmt)) {
			if(StringUtils.isBlank(invTotalAmt))
        	{
        		invTotalAmt="0.0";
        	}
        	else
        	{
        		invTotalAmt="0.0";
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00323, Constants.BLANK);
        	}

		}
		vendorUploadStage1.setTotalInvoiceAmt(AppUtil.formatRateAmoutValues(invTotalAmt));
		if (!isNumeric(vendorUploadStage1.getTotalInvoiceAmt())) {
			if(StringUtils.isBlank(vendorUploadStage1.getTotalInvoiceAmt()))
	    	{
				vendorUploadStage1.setTotalInvoiceAmt("0.0");
	    	}
	    	else
	    	{
	    		vendorUploadStage1.setTotalInvoiceAmt("0.0");
	    		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00594, Constants.BLANK);
	    	}
		}
		String setDocType = customTemplateHeaderMappings.get(Constants.DOC_TYPE);
		vendorUploadStage1.setDocType(csvRecord.get(columnIndexMap.get(setDocType)));

		String setOrgInvoiceCategory = customTemplateHeaderMappings.get(Constants.COLUMN_SUPPLY_TYPE);
		vendorUploadStage1.setOrgInvoiceCategory(csvRecord.get(columnIndexMap.get(setOrgInvoiceCategory)));

		vendorUploadStage1.setInvoiceCategory(vendorUploadStage1.getOrgInvoiceCategory());
		vendorUploadStage1.setUserSupplyCat(vendorUploadStage1.getOrgInvoiceCategory());

		String setDocNo = customTemplateHeaderMappings.get(Constants.COLUMN_DOC_NO);
		vendorUploadStage1.setDocNo(csvRecord.get(columnIndexMap.get(setDocNo)));

		String setDocDate = customTemplateHeaderMappings.get(Constants.COLUMN_DOC_DATE);
		vendorUploadStage1.setDocDate(csvRecord.get(columnIndexMap.get(setDocDate)));

		String setOrgInvoiceNo = customTemplateHeaderMappings.get(Constants.COLUMN_ORG_INVOICE_NO);
		vendorUploadStage1.setOrgInvoiceNo(csvRecord.get(columnIndexMap.get(setOrgInvoiceNo)));

		String setGstinOfSupplier = customTemplateHeaderMappings.get(Constants.COLUMN_GSTIN_OF_SUPPLIER);
		vendorUploadStage1.setGstinOfSupplier(csvRecord.get(columnIndexMap.get(setGstinOfSupplier)));

		String setSupplierName = customTemplateHeaderMappings.get(Constants.COLUMN_SUPPLIER_NAME);
		vendorUploadStage1.setSupplierName(csvRecord.get(columnIndexMap.get(setSupplierName)));

		String setSupplierStateCode = customTemplateHeaderMappings.get(Constants.COLUMN_SUPPLIER_STATE_CODE);
		vendorUploadStage1.setSupplierStateCode(csvRecord.get(columnIndexMap.get(setSupplierStateCode)));

		String setInwardNo = customTemplateHeaderMappings.get(Constants.COLUMN_INWARD_NO);
		vendorUploadStage1.setInwardNo(csvRecord.get(columnIndexMap.get(setInwardNo)));

		String setInwardDate = customTemplateHeaderMappings.get(Constants.COLUMN_INWARD_DATE);
		vendorUploadStage1.setInwardDate(csvRecord.get(columnIndexMap.get(setInwardDate)));

		String setItemName = customTemplateHeaderMappings.get(Constants.COLUMN_ITEM_DESCRIPTION);
		vendorUploadStage1.setItemName(csvRecord.get(columnIndexMap.get(setItemName)));

		String setHsnSacCode = customTemplateHeaderMappings.get(Constants.COLUMN_HSN_CODE);
		vendorUploadStage1.setHsnSacCode(csvRecord.get(columnIndexMap.get(setHsnSacCode)));

		String setUom = customTemplateHeaderMappings.get(Constants.COLUMN_UOM);
		vendorUploadStage1.setUom(csvRecord.get(columnIndexMap.get(setUom)));

		String setQuantity = customTemplateHeaderMappings.get(Constants.COLUMN_QUINTITY);
		String quantity = csvRecord.get(columnIndexMap.get(setQuantity));

		if (isNumeric(quantity)) {
			BigDecimal quantityDecimal = new BigDecimal(quantity);
			vendorUploadStage1.setQuantity(String.valueOf(quantityDecimal.intValue()));
		} else {

			if(StringUtils.isBlank(quantity))
        	{	
        	    vendorUploadStage1.setQuantity("0");
        	}
        	else
        	{
        		vendorUploadStage1.setQuantity("0");
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00019, Constants.BLANK);	
        	}
		}

		vendorUploadStage1.setOrgQuantity(csvRecord.get(columnIndexMap.get(setQuantity)));

		String setItemRate = customTemplateHeaderMappings.get(Constants.COLUMN_ITEM_RATE);
		String itemRate = csvRecord.get(columnIndexMap.get(setItemRate));

		if (!isNumeric(itemRate)) {
			if(StringUtils.isBlank(itemRate))
        	{
        	    itemRate="0.0";
        	}
        	else
        	{
        		itemRate="0.0";
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00017, Constants.BLANK);
            	
        	}
		}
		vendorUploadStage1.setItemRate(AppUtil.formatRateAmoutValues(itemRate));

		String setInwardTaxableAmt = customTemplateHeaderMappings.get(Constants.COLUMN_ASS_AMOUNT);
		String inwardTaxableAmt = csvRecord.get(columnIndexMap.get(setInwardTaxableAmt));

		if (!isNumeric(inwardTaxableAmt)) {
			if(StringUtils.isBlank(inwardTaxableAmt))
        	{
        	    inwardTaxableAmt = "0.0";
        	}
        	else
        	{
        		inwardTaxableAmt = "0.0";
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00588, Constants.BLANK);
        	}
		}
		vendorUploadStage1.setInwardTaxableAmt(AppUtil.formatRateAmoutValues(inwardTaxableAmt));

		String setSgstRate = customTemplateHeaderMappings.get(Constants.COLUMN_SGST_RATE);
		String sgstRate = csvRecord.get(columnIndexMap.get(setSgstRate));

		if (!isNumeric(sgstRate)) {
			if(StringUtils.isBlank(sgstRate))
        	{
        	     sgstRate = "0.0";
        	}
        	else
        	{
        		sgstRate = "0.0";
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00024, Constants.BLANK);
        	}
		}

		vendorUploadStage1.setSgstRate(AppUtil.formatRateAmoutValues(sgstRate));

		String setCgstRate = customTemplateHeaderMappings.get(Constants.COLUMN_CGST_RATE);
		String cgstRate = csvRecord.get(columnIndexMap.get(setCgstRate));

		if (!isNumeric(cgstRate)) {
			if(StringUtils.isBlank(cgstRate))
        	{
        		cgstRate = "0.0";
        	}
        	else
        	{
        		cgstRate = "0.0";
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00024, Constants.BLANK);
        	}
		}

		vendorUploadStage1.setCgstRate(AppUtil.formatRateAmoutValues(cgstRate));

		String setIgstRate = customTemplateHeaderMappings.get(Constants.COLUMN_IGST_RATE);
		String igstRate = csvRecord.get(columnIndexMap.get(setIgstRate));

		if (!isNumeric(igstRate)) {
			if(StringUtils.isBlank(igstRate))
        	{
        		igstRate = "0.0";
        	}
        	else
        	{
        		igstRate = "0.0";
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00027, Constants.BLANK);
        	}
		}

		vendorUploadStage1.setIgstRate(AppUtil.formatRateAmoutValues(igstRate));

		String setCessRate = customTemplateHeaderMappings.get(Constants.COLUMN_CESS_RATE);
		String cessRate = csvRecord.get(columnIndexMap.get(setCessRate));

		if (!isNumeric(cessRate)) {
			if(StringUtils.isBlank(cessRate))
        	{
        		cessRate = "0.0";
        	}
        	else
        	{
        		cessRate = "0.0";
        		markErrorNAddErrorCode(vendorUploadStage1, ValidationConstant.EINVOICE_ERROR_CODE_E00036, Constants.BLANK);
        	}
		}

		vendorUploadStage1.setCessRate(AppUtil.formatRateAmoutValues(cessRate));

		if (StringUtils.isBlank(vendorUploadStage1.getCessRate())) {
			vendorUploadStage1.setCessRate(String.valueOf("0"));
		}

		String setDiffPercent = customTemplateHeaderMappings.get(Constants.COLUMN_DIFF_PERCENT);
		String diffPercent = csvRecord.get(columnIndexMap.get(setDiffPercent));

		if (StringUtils.isBlank(diffPercent) || "NULL".equalsIgnoreCase(diffPercent)) {
			diffPercent = "0.00";
		}
		vendorUploadStage1.setDiffPercent(AppUtil.formatRateAmoutValues(diffPercent));

		vendorUploadStage1.setImportType(csvRecord.get(columnIndexMap.get(inputTypeCustomHeaderName)));

		String setPlaceOfSupply = customTemplateHeaderMappings.get(Constants.COLUMN_PLACE_OF_SUPPLY);
		String pos = csvRecord.get(columnIndexMap.get(setPlaceOfSupply));
		if (StringUtils.isNotBlank(pos) && pos.length() == 1) {
			vendorUploadStage1.setPlaceOfSupply("0" + pos);
		} else {
			vendorUploadStage1.setPlaceOfSupply(pos);
		}

		String setPort = customTemplateHeaderMappings.get(Constants.PORT);

		vendorUploadStage1.setPort(csvRecord.get(columnIndexMap.get(setPort)));

		String setImportBillOfEntryNo = customTemplateHeaderMappings.get(Constants.COLUMN_IMPORT_BILL_OF_ENTRY_NO);

		vendorUploadStage1.setImportBillOfEntryNo(csvRecord.get(columnIndexMap.get(setImportBillOfEntryNo)));

		String setImportBillOfEntryDate = customTemplateHeaderMappings.get(Constants.COLUMN_IMPORT_BILL_OF_ENTRY_DATE);

		vendorUploadStage1.setImportBillOfEntryDate(csvRecord.get(columnIndexMap.get(setImportBillOfEntryDate)));

		String setImportBillOfEntryAmt = customTemplateHeaderMappings.get(Constants.COLUMN_IMPORT_BILL_OF_ENTRY_AMT);

		String importBillOfEntryAmt = csvRecord.get(columnIndexMap.get(setImportBillOfEntryDate));

		if (!isNumeric(importBillOfEntryAmt)) {
			if(StringUtils.isBlank(importBillOfEntryAmt))
        	{
        		importBillOfEntryAmt = "0.0";
        	}
        	else
        	{
        		importBillOfEntryAmt = "0.0";
        		markErrorNAddErrorCode(vendorUploadStage1, ValidationConstant.EINVOICE_ERROR_CODE_E00589, Constants.BLANK);
        	}
		}
		vendorUploadStage1.setImportBillOfEntryAmt(importBillOfEntryAmt);

		// inwardItcInvCdnTemplate.setPreGst(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("pre_gst")),
		// evaluator));

		String setIrn = customTemplateHeaderMappings.get(Constants.COLUMN_IRN);

		vendorUploadStage1.setIrn(csvRecord.get(columnIndexMap.get(setIrn)));

		String setSupplyType = customTemplateHeaderMappings.get(Constants.COLUMN_SUPPLY_TYPE);

		vendorUploadStage1.setSupplyType(csvRecord.get(columnIndexMap.get(setSupplyType)));

		String setAckDate = customTemplateHeaderMappings.get(Constants.COLUMN_ACK_DATE);

		vendorUploadStage1.setAckDate(csvRecord.get(columnIndexMap.get(setAckDate)));

		String setAckNo = customTemplateHeaderMappings.get(Constants.COLUMN_ACK_NO);

		vendorUploadStage1.setAckNo(csvRecord.get(columnIndexMap.get(setAckNo)));

		String setDebitGlId = customTemplateHeaderMappings.get(Constants.COLUMN_DEBIT_GL_ID);

		vendorUploadStage1.setDebitGlId(csvRecord.get(columnIndexMap.get(setDebitGlId)));

		String setDebitGlName = customTemplateHeaderMappings.get(Constants.COLUMN_DEBIT_GL_NAME);

		vendorUploadStage1.setDebitGlName(csvRecord.get(columnIndexMap.get(setDebitGlName)));

		String setCreditGlId = customTemplateHeaderMappings.get(Constants.COLUMN_CREDIT_GL_ID);

		vendorUploadStage1.setCreditGlId(csvRecord.get(columnIndexMap.get(setCreditGlId)));

		String setCreditGlName = customTemplateHeaderMappings.get(Constants.COLUMN_CREDIT_GL_NAME);

		vendorUploadStage1.setCreditGlName(csvRecord.get(columnIndexMap.get(setCreditGlName)));

		String setSubLocation = customTemplateHeaderMappings.get(Constants.COLUMN_SUB_LOCATION);

		vendorUploadStage1.setSubLocation(csvRecord.get(columnIndexMap.get(setSubLocation)));

		vendorUploadStage1.setReverseCharge(reverseCharge);

		if ("NIL".equalsIgnoreCase(vendorUploadStage1.getOrgInvoiceCategory())) {
			vendorUploadStage1.setNilRatedAmt(AppUtil.formatRateAmoutValues(vendorUploadStage1.getOrgAssAmt()));
		} else {
			vendorUploadStage1.setNilRatedAmt(AppUtil.formatRateAmoutValues("0.00"));
		}
		if ("EXM".equalsIgnoreCase(vendorUploadStage1.getOrgInvoiceCategory())) {
			vendorUploadStage1.setExemptedAmt(AppUtil.formatRateAmoutValues(vendorUploadStage1.getOrgAssAmt()));
		} else {
			vendorUploadStage1.setExemptedAmt(AppUtil.formatRateAmoutValues("0.00"));
		}
		if ("NON".equalsIgnoreCase(vendorUploadStage1.getOrgInvoiceCategory())) {
			vendorUploadStage1.setNonGstAmt(AppUtil.formatRateAmoutValues(vendorUploadStage1.getOrgAssAmt()));
		} else {
			vendorUploadStage1.setNonGstAmt(AppUtil.formatRateAmoutValues("0.00"));
		}

		if ("COMP".equalsIgnoreCase(vendorUploadStage1.getOrgInvoiceCategory())) {
			vendorUploadStage1.setCompositionAmt(AppUtil.formatRateAmoutValues(vendorUploadStage1.getOrgAssAmt()));
		} else {
			vendorUploadStage1.setCompositionAmt(AppUtil.formatRateAmoutValues("0.00"));
		}

		if (vendorUploadStage1.getDateOfPayment().equals("00-01-1900")
				|| vendorUploadStage1.getDateOfPayment().equals("31/12/1899")
				|| vendorUploadStage1.getDateOfPayment().equals("31-12-1899")) {
			vendorUploadStage1.setDateOfPayment("0");
		}

		if (vendorUploadStage1.getImportBillOfEntryDate().equals("00-01-1900")
				|| vendorUploadStage1.getImportBillOfEntryDate().equals("31/12/1899")
				|| vendorUploadStage1.getImportBillOfEntryDate().equals("31-12-1899")) {
			vendorUploadStage1.setImportBillOfEntryDate("0");
		}

		vendorUploadStage1.setSgstAmt(sgstAmt);
		vendorUploadStage1.setCgstAmt(cgstAmt);
		vendorUploadStage1.setIgstAmt(igstAmt);
		vendorUploadStage1.setCessAmount(cessAmt);

		/************* Amount Calculation Start ************************/

		if (!isNumeric(sgstAmt)) {
			sgstAmt = "0.0";
		}

		if (!isNumeric(cgstAmt)) {
			cgstAmt = "0.0";
		}

		if (!isNumeric(cessAmt)) {
			cessAmt = "0.0";
		}

		if (!isNumeric(igstAmt)) {
			igstAmt = "0.0";
		}

		BigDecimal igst = new BigDecimal(igstAmt);
		BigDecimal sgst = new BigDecimal(sgstAmt);
		BigDecimal cgst = new BigDecimal(cgstAmt);
		BigDecimal cess = new BigDecimal(cessAmt);

		BigDecimal itcIgst = new BigDecimal(igstAmt);
		BigDecimal itcSgst = new BigDecimal(sgstAmt);
		BigDecimal itcCgst = new BigDecimal(cgstAmt);
		BigDecimal itcCess = new BigDecimal(cessAmt);

		BigDecimal totalTaxAmt = new BigDecimal(0);
		totalTaxAmt = totalTaxAmt.add(sgst).add(cgst).add(igst).add(cess);

		vendorUploadStage1.setTotalTaxAmount(totalTaxAmt.toString());

		if (DroolUtil.containsNumbersOnly(itcPercent, 1)) {
			itcSgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), sgst);
			itcCgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), cgst);
			itcIgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), igst);
			itcCess = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), cess);
		}

		vendorUploadStage1.setItcSgstAmt(itcSgst.toString());
		vendorUploadStage1.setItcCgstAmt(itcCgst.toString());
		vendorUploadStage1.setItcIgstAmt(itcIgst.toString());
		vendorUploadStage1.setItcCessAmt(itcCess.toString());

		vendorUploadStage1.setGrossTotalAmount(grossTotalAmt);

		BigDecimal totalITCTaxAmt = new BigDecimal(0);
		totalITCTaxAmt = totalITCTaxAmt.add(itcSgst).add(itcCgst).add(itcIgst).add(itcCess);
		vendorUploadStage1.setInwardTotalTaxAmt(totalTaxAmt.toString());
		vendorUploadStage1.setTotalItcAmt(totalITCTaxAmt.toString());
		vendorUploadStage1.setTaxableAmount(vendorUploadStage1.getAssAmt());

		String setOrgPaymentAmount = customTemplateHeaderMappings.get(Constants.PAYMENT_AMOUNT);

		vendorUploadStage1.setOrgPaymentAmount(csvRecord.get(columnIndexMap.get(setOrgPaymentAmount)));

		String setPaymentAmount = customTemplateHeaderMappings.get(Constants.PAYMENT_AMOUNT);

		vendorUploadStage1.setPaymentAmount(csvRecord.get(columnIndexMap.get(setPaymentAmount)));

		if (!isNumeric(vendorUploadStage1.getPaymentAmount())) {
			if(StringUtils.isBlank(vendorUploadStage1.getPaymentAmount()))
        	{
        	    vendorUploadStage1.setPaymentAmount("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setPaymentAmount("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, ValidationConstant.EINVOICE_ERROR_CODE_I50031, Constants.BLANK);
        	}
		}
		String setPaymentRefNo = customTemplateHeaderMappings.get(Constants.PAYMENT_REF_NO);

		vendorUploadStage1.setPaymentRefNo(csvRecord.get(columnIndexMap.get(setPaymentRefNo)));

		String setTdsSection = customTemplateHeaderMappings.get(Constants.TDS_SECTION);

		vendorUploadStage1.setTdsSection(csvRecord.get(columnIndexMap.get(setTdsSection)));

		String setTdsRate = customTemplateHeaderMappings.get(Constants.TDS_RATE);

		vendorUploadStage1.setTdsRate(csvRecord.get(columnIndexMap.get(setTdsRate)));
		vendorUploadStage1.setOrgTdsRate(csvRecord.get(columnIndexMap.get(setTdsRate)));

		String setOrgTdsTaxAmount = customTemplateHeaderMappings.get(Constants.TDS_TAX_AMOUNT);

		vendorUploadStage1.setOrgTdsTaxAmount(csvRecord.get(columnIndexMap.get(setOrgTdsTaxAmount)));

		String setChallanNumber = customTemplateHeaderMappings.get(Constants.CHALLAN_NUMBER);

		vendorUploadStage1.setChallanNumber(csvRecord.get(columnIndexMap.get(setChallanNumber)));

		if (!isNumeric(vendorUploadStage1.getTdsTaxAmount())) {
			if(StringUtils.isBlank(vendorUploadStage1.getTdsTaxAmount()))
        	{
        	    vendorUploadStage1.setTdsTaxAmount("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setTdsTaxAmount("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, ValidationConstant.EINVOICE_ERROR_CODE_E00528, Constants.BLANK);
        	}
		}

		String setChallanDate = customTemplateHeaderMappings.get(Constants.CHALLAN_DATE);

		vendorUploadStage1.setChallanDate(csvRecord.get(columnIndexMap.get(setChallanDate)));

		String setOrgChallanAmount = customTemplateHeaderMappings.get(Constants.CHALLAN_AMOUNT);

		vendorUploadStage1.setOrgChallanAmount(csvRecord.get(columnIndexMap.get(setOrgChallanAmount)));

		String setChallanAmount = customTemplateHeaderMappings.get(Constants.CHALLAN_AMOUNT);

		vendorUploadStage1.setChallanAmount(csvRecord.get(columnIndexMap.get(setChallanAmount)));

		if (!isNumeric(vendorUploadStage1.getChallanAmount())) {
			if(StringUtils.isBlank(vendorUploadStage1.getChallanAmount()))
        	{
        	    vendorUploadStage1.setChallanAmount("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setChallanAmount("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00531, Constants.BLANK);
        	}
		}

		String setPeriodOfFiling = customTemplateHeaderMappings.get(Constants.PERIOD_OF_FILLING);

		vendorUploadStage1.setPeriodOfFiling(csvRecord.get(columnIndexMap.get(setPeriodOfFiling)));

		String setInvoiceAgainstProvAdv = customTemplateHeaderMappings.get(Constants.INVOICE_AGAINST_PROV_ADV);

		vendorUploadStage1.setInvoiceAgainstProvAdv(csvRecord.get(columnIndexMap.get(setInvoiceAgainstProvAdv)));

		String setInwardNoProvAdv = customTemplateHeaderMappings.get(Constants.INWARD_NO_PROV_ADV);

		vendorUploadStage1.setInwardNoProvAdv(csvRecord.get(columnIndexMap.get(setInwardNoProvAdv)));

		String setInwardDateProvAdv = customTemplateHeaderMappings.get(Constants.INWARD_DATE_PROV_ADV);

		vendorUploadStage1.setInwardDateProvAdv(csvRecord.get(columnIndexMap.get(setInwardDateProvAdv)));

		String setOrgAmountOfProvAdv = customTemplateHeaderMappings.get(Constants.AMOUNT_OF_PROV_ADV);

		vendorUploadStage1.setOrgAmountOfProvAdv(csvRecord.get(columnIndexMap.get(setOrgAmountOfProvAdv)));

		String setAmountOfProvAdv = customTemplateHeaderMappings.get(Constants.AMOUNT_OF_PROV_ADV);

		vendorUploadStage1.setAmountOfProvAdv(csvRecord.get(columnIndexMap.get(setAmountOfProvAdv)));

		if (!isNumeric(vendorUploadStage1.getAmountOfProvAdv())) {
			if(StringUtils.isBlank(vendorUploadStage1.getAmountOfProvAdv()))
        	{
        	    vendorUploadStage1.setAmountOfProvAdv("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setAmountOfProvAdv("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00536, Constants.BLANK);
        	}
		}
		String setBalOutstanding = customTemplateHeaderMappings.get(Constants.BAL_OUTSTANDING);

		vendorUploadStage1.setBalOutstanding(csvRecord.get(columnIndexMap.get(setBalOutstanding)));

		vendorUploadStage1.setOrgBalOutstanding(csvRecord.get(columnIndexMap.get(setBalOutstanding)));
		if (!isNumeric(vendorUploadStage1.getOrgBalOutstanding())) {
			if(StringUtils.isBlank(vendorUploadStage1.getOrgBalOutstanding()))
        	{
        	    vendorUploadStage1.setOrgBalOutstanding("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setOrgBalOutstanding("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00595, Constants.BLANK);
        	}
		}
		String setUdf1 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_1);

		vendorUploadStage1.setUdf1(csvRecord.get(columnIndexMap.get(setUdf1)));

		String setUdf2 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_2);

		vendorUploadStage1.setUdf2(csvRecord.get(columnIndexMap.get(setUdf2)));

		String setUdf3 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_3);

		vendorUploadStage1.setUdf3(csvRecord.get(columnIndexMap.get(setUdf3)));

		String setUdf4 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_4);

		vendorUploadStage1.setUdf4(csvRecord.get(columnIndexMap.get(setUdf4)));

		String setUdf5 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_5);

		vendorUploadStage1.setUdf5(csvRecord.get(columnIndexMap.get(setUdf5)));

		String setUdf6 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_6);

		vendorUploadStage1.setUdf6(csvRecord.get(columnIndexMap.get(setUdf6)));

		String setUdf7 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_7);

		vendorUploadStage1.setUdf7(csvRecord.get(columnIndexMap.get(setUdf7)));

		String setUdf8 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_8);

		vendorUploadStage1.setUdf8(csvRecord.get(columnIndexMap.get(setUdf8)));

		String setUdf9 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_9);

		vendorUploadStage1.setUdf9(csvRecord.get(columnIndexMap.get(setUdf9)));

		String setUdf10 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_10);

		vendorUploadStage1.setUdf10(csvRecord.get(columnIndexMap.get(setUdf10)));

		String setUdf11 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_11);

		vendorUploadStage1.setUdf11(csvRecord.get(columnIndexMap.get(setUdf11)));

		String setUdf12 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_12);

		vendorUploadStage1.setUdf12(csvRecord.get(columnIndexMap.get(setUdf12)));

		String setUdf13 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_13);

		vendorUploadStage1.setUdf13(csvRecord.get(columnIndexMap.get(setUdf13)));

		String setUdf14 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_14);

		vendorUploadStage1.setUdf14(csvRecord.get(columnIndexMap.get(setUdf14)));

		String setUdf15 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_15);

		vendorUploadStage1.setUdf15(csvRecord.get(columnIndexMap.get(setUdf15)));

		String setUdf16 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_16);

		vendorUploadStage1.setUdf16(csvRecord.get(columnIndexMap.get(setUdf16)));

		String setUdf17 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_17);

		vendorUploadStage1.setUdf17(csvRecord.get(columnIndexMap.get(setUdf17)));

		String setUdf18 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_18);

		vendorUploadStage1.setUdf18(csvRecord.get(columnIndexMap.get(setUdf18)));

		String setUdf19 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_19);

		vendorUploadStage1.setUdf19(csvRecord.get(columnIndexMap.get(setUdf19)));

		String setUdf20 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_20);

		vendorUploadStage1.setUdf20(csvRecord.get(columnIndexMap.get(setUdf20)));

		if (StringUtils.isNotBlank(vendorUploadStage1.getGstinOfRecipient())
				&& vendorUploadStage1.getGstinOfRecipient().length() == 15) {
			vendorUploadStage1.setPanOfReciepiet(vendorUploadStage1.getGstinOfRecipient().substring(2, 12));

		} else {
			vendorUploadStage1.setPanOfReciepiet("");

		}
		if (StringUtils.isNotBlank(vendorUploadStage1.getGstinOfSupplier())
				&& vendorUploadStage1.getGstinOfSupplier().length() == 15) {
			vendorUploadStage1.setPanOfSupplier(vendorUploadStage1.getGstinOfSupplier().substring(2, 12));
		} else {
			vendorUploadStage1.setPanOfSupplier("");
		}

		if (StringUtils.isNotBlank(vendorUploadStage1.getFillingPeriod())) {
			sftpSet.add(vendorUploadStage1.getFillingPeriod());
		}
		if (vendorUploadStage1.getPeriodOfFiling().length() == 5) {
			vendorUploadStage1.setPeriodOfFiling(Constants.ZEROVALUE + vendorUploadStage1.getPeriodOfFiling());
		}
		if (vendorUploadStage1.getFillingPeriod().length() == 5) {
			vendorUploadStage1.setFillingPeriod(Constants.ZEROVALUE + vendorUploadStage1.getFillingPeriod());
		}
		if ("INV".equals(vendorUploadStage1.getDocType())) {
			inwardINVDataList.add(vendorUploadStage1);
		} else if ("CRN".equals(vendorUploadStage1.getDocType()) || "DBN".equals(vendorUploadStage1.getDocType())) {
			inwardCDNDataList.add(vendorUploadStage1);
		} else {
			inwardDocErrorDataList.add(vendorUploadStage1);
			vendorUploadStage1.setErrorCodeList(vendorUploadStage1.getErrorCodeList().append("|E00257"));
			vendorUploadStage1.setValid(false);
		}

	}

}
