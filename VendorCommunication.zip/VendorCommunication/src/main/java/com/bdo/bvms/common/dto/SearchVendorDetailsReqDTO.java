package com.bdo.bvms.common.dto;

import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@AllArgsConstructor
@NoArgsConstructor
@Getter
@Builder
@Setter
public class SearchVendorDetailsReqDTO extends PageReqDTO {

    
    @NotEmpty(message = "{taxpayerGstin.notempty}")
    String taxpayerGstin;

    
    @NotEmpty(message = "{vendorGstin.notempty}")
    String vendorGstin;


}

