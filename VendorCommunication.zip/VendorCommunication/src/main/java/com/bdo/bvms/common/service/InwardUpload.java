package com.bdo.bvms.common.service;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;


public interface InwardUpload {

	String validateAndSaveData(UploadReqDTO uploadRequestDTO, AzureConnectionCredentialsDTO storageCredentials) throws IOException, VendorInvoiceServerException;

	//void init(UploadReqDTO vbo) throws IOException;

	

	void saveCdnSuccessRecord(List<InwardInvoiceCDNTemplateDTO> sucessInvDataList, UploadReqDTO validationBO,
			DateFormat dateFormat, Date date, int threadCnt) throws VendorInvoiceServerException;

	List<InwardInvoiceCDNTemplateDTO> manualValidateAndSaveData(UploadReqDTO uploadRequestDTO, List<InwardInvoiceCDNTemplateDTO> rowINVPoJoList,
			List<InwardInvoiceCDNTemplateDTO> rowCRNPoJoList, List<PaymentDetails> list, List<TdsDetails> list2) throws IOException, VendorInvoiceServerException;

	void addInNotification(UploadReqDTO uploadRequestDTO);

	/**
	 * Gets the row count with header.
	 *
	 * @param inputStream
	 *            the input stream
	 * @param uploadRequestDTO
	 *            the upload request DTO
	 * @return the row count with header
	 * @throws VendorInvoiceServerException
	 *             the vendor invoice server exception
	 */
	Map<String, Object> getRowCountWithHeader(InputStream inputStream, UploadReqDTO uploadRequestDTO)
			throws VendorInvoiceServerException;
}
