package com.bdo.bvms.common.service;

import java.util.List;

import com.bdo.bvms.common.dto.EntityMasterResDTO;

public interface IEntityMasterService {
    
    EntityMasterResDTO getEntityMaster(Integer userId);

	List<EntityMasterResDTO> getEntityMasterList(List<String> searchList, String panOrGstin, Integer entityTypeId);

}
