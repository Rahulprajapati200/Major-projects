package com.bdo.bvms.common.service.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.common.config.AzureClientProvider;
import com.bdo.bvms.common.dao.AttachmentRepository;
import com.bdo.bvms.common.dto.AddAttachmentsReqDTO;
import com.bdo.bvms.common.dto.AttachmentListDto;
import com.bdo.bvms.common.dto.AttacmentReqDTO;
import com.bdo.bvms.common.dto.GstinAttachments;
import com.bdo.bvms.common.dto.GstinAttachmentsResDTO;
import com.bdo.bvms.common.dto.PaginationResDTO;
import com.bdo.bvms.common.dto.SearchSystemParameterReqDTO;
import com.bdo.bvms.common.dto.SearchSystemParameterResDTO;
import com.bdo.bvms.common.dto.SearchVendorDetailsReqDTO;
import com.bdo.bvms.common.dto.SystemParameter;
import com.bdo.bvms.common.dto.TaxpayerVendor;
import com.bdo.bvms.common.exceptions.ResourceNotFoundException;
import com.bdo.bvms.common.service.AttachmentService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class AttachmentServiceImpl implements AttachmentService {

    @Autowired
    AzureClientProvider azureClientProvider;

    @Autowired
    AttachmentRepository attachmentRepository;

    int i;

    @Override
    public List<AttachmentListDto> getAttachment(AttacmentReqDTO attacmentReqDTO) {

        return attachmentRepository.getAttachmentList(attacmentReqDTO);
    }

    public static PaginationResDTO defaultPaginationResponse() {
        return PaginationResDTO.builder().totalElements(0).noOfElements(0).number(0).size(0).totalPages(0)
                        .searchElements(Collections.emptyList()).build();
    }

    @Override
    public Object searchAttachments(@Valid SearchVendorDetailsReqDTO searchVendorDetailsReqDTO) {
        Pageable paging = PageRequest.of(searchVendorDetailsReqDTO.getPage(), searchVendorDetailsReqDTO.getSize());
        Page<GstinAttachments> pagedResultAttachments = attachmentRepository.searchAttachments(paging,
                        searchVendorDetailsReqDTO);
        if (pagedResultAttachments != null) {
            List<GstinAttachmentsResDTO> gstinAttachmentsResList = pagedResultAttachments.getContent().stream()
                            .map(attachment -> GstinAttachmentsResDTO.builder().id(attachment.getId())
                                            .uploadedByEmail(attachment.getModifiedByEmail() == null
                                                            ? attachment.getCreatedByEmail()
                                                            : attachment.getModifiedByEmail())
                                            .uploadedByname(attachment.getModifiedByName() == null
                                                            ? attachment.getCreatedByName()
                                                            : attachment.getModifiedByName())
                                            .uploadedOn(attachment.getModifiedAt() == null ? attachment.getCreatedAt()
                                                            : attachment.getModifiedAt())
                                            .documentType(attachment.getDocumentType()).remarks(attachment.getRemarks())
                                            .path(attachment.getPath()).documentTypeId(attachment.getPldDocumentType())
                                            .build())
                            .collect(Collectors.toList());
            return PaginationResDTO.builder().totalElements(pagedResultAttachments.getTotalElements())
                            .noOfElements(pagedResultAttachments.getNumberOfElements())
                            .number(pagedResultAttachments.getNumber()).size(pagedResultAttachments.getSize())
                            .totalPages(pagedResultAttachments.getTotalPages()).searchElements(gstinAttachmentsResList)
                            .build();
        } else {
            return defaultPaginationResponse();
        }
    }

    @Override
    public SearchSystemParameterResDTO searchSystemParameter(SearchSystemParameterReqDTO searchSystemParameterReqDTO) {
        SystemParameter systemParameter = null;
        try {
            systemParameter = attachmentRepository.searchSystemParameter(
                            SystemParameter.builder().keyName(searchSystemParameterReqDTO.getKeyName()).build());
        } catch (EmptyResultDataAccessException e) {
            throw new ResourceNotFoundException(SearchSystemParameterReqDTO.class, "keyName",
                            searchSystemParameterReqDTO.getKeyName());
        }
        return SearchSystemParameterResDTO.builder().keyName(systemParameter.getKeyName())
                        .keyValue(systemParameter.getKeyValue()).build();
    }

    @Override
    public Object addVendorAttachments(List<File> fileList, AddAttachmentsReqDTO addAttachmentsReqDTO) {
        TaxpayerVendor taxpayerVendor = null;

        final TaxpayerVendor[] taxpayerVendorArr = new TaxpayerVendor[1];
        taxpayerVendorArr[0] = taxpayerVendor;

        final List<Integer> attachmentIdList = new ArrayList<>();
        i = 0;

        fileList.stream().forEach(fileAttachment -> {
            addAttachmentsReqDTO.getCommunicationRefId().stream().forEach(id -> {

                String fileURL = azureClientProvider.uploadToAzureBlob(fileAttachment,
                                Integer.parseInt(addAttachmentsReqDTO.getEntityId()));

                GstinAttachments gstinAttachments = GstinAttachments.builder().communicationRefId(id)
                                .name(fileAttachment.getName()).pldDocumentType(addAttachmentsReqDTO.getDocumentType())
                                .path(fileURL).createdBy(Integer.parseInt(addAttachmentsReqDTO.getUserId()))
                                .remarks(addAttachmentsReqDTO.getRemarks())
                                .pldModuleId(addAttachmentsReqDTO.getModuleId()).build();
                attachmentIdList.add(attachmentRepository.addVendorAttachments(gstinAttachments));

            });
            try {
                Files.delete(fileAttachment.toPath());
            } catch (IOException e) {
                log.error("Error while deleting error file ", e);
            }
        });

        fileList.clear();
        return attachmentIdList;
    }

}
