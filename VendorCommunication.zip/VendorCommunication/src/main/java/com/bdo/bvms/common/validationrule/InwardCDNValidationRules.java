package com.bdo.bvms.common.validationrule;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
public class InwardCDNValidationRules {


	public void validateRules(InwardInvoiceCDNTemplateDTO rowdata,String dilutedValidation,String invoiceAvailable,String gstinCustomer,String invoiceCategory,int haveOrginalData,String orgDocType,String fp,Map<String, String> cdnStateCodeMap,Map<String, String> cdnPortCodeMap,List<String>cdnGovCodeMap,List<String>tdsSections)  {

	InwardDroolUtil inwardRules=new InwardDroolUtil();
		
		/// rules for check for invoice
		if("n".equalsIgnoreCase(rowdata.getPreGst()) && "false".equalsIgnoreCase(invoiceAvailable)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00055,""); 
		}
		
		//preGst field value == Y || N
		if("".equalsIgnoreCase(rowdata.getPreGst())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00049, "");
		}
		
		//check fields gstin against  supply type
		//ctin
		if (!inwardRules.validGSTIN(rowdata.getGstinOfSupplier())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00519, "");
		}else if(!inwardRules.supplyTypeAgainstCustomerGstin(rowdata.getOrgInvoiceCategory(), rowdata.getGstinOfSupplier())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00142, "");
		}
		if (!inwardRules.checkOriginalCustomerGSTIN(rowdata.getGstinOfSupplier(),gstinCustomer,rowdata.getPreGst(),invoiceAvailable)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00058, "");
		}
	
		
		if(!inwardRules.validGSTIN(rowdata.getGstinOfRecipient()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00517, "");
		}
		
		//check fields supply type against org invoice category
		if(!inwardRules.supplyTypeAgainstInwardInvoiceCategory(rowdata.getOrgInvoiceCategory(), invoiceCategory ,rowdata.getGstinOfSupplier(), haveOrginalData, rowdata.getNilRatedAmt(), rowdata.getExemptedAmt(), rowdata.getNonGstAmt(), rowdata.getCompositionAmt(), rowdata.getImportType(), rowdata.getHsnSacCode())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00144, "");
		}
		
		//Validate orgInvoice date/no 
		
		if("credit note".equalsIgnoreCase(rowdata.getDocType()) || "debit note".equalsIgnoreCase(rowdata.getDocType())) {
			if(!inwardRules.checkOrginalInvoiceWithoutDate(rowdata.getOrgInvoiceNo(), rowdata.getOrgInvoiceDate())) {
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00147, "");
			}
			
		}

	// check supply type
		if (!inwardRules.checkSupplyType(rowdata.getOrgInvoiceCategory())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00141, "");
		}
			
		// validate doc type value : It should be from list
		if ("0".equals(rowdata.getDocType()) || "0.00".equals(rowdata.getDocType()) || "0.0".equals(rowdata.getDocType()) || rowdata.getDocType().isEmpty()
				|| !rowdata.getDocType().matches("(?i)credit note|debit note")) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00013, "");
		}

		// Customer GSTIN validate
		

		// rules for gstin_of_recipient field
		if (StringUtils.isNotBlank(rowdata.getGstinOfRecipient()) && rowdata.getGstinOfRecipient().equals(rowdata.getGstinOfSupplier())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00518, "");
		}

		// "validate placeOfSupply"
		if (!(String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply())) != null && cdnStateCodeMap.get(String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply()))) != null)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00015, "");
		}
		

		// validate reverse charge on basis of docType"
		if (!inwardRules.checkReverseChargeForRCM(rowdata.getReverseCharge(), orgDocType, rowdata.getImportType(), rowdata.getHsnSacCode())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50102, "");
		}

		// validate supplierStateCode
		if (!(String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())) != null && cdnStateCodeMap.get(String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode()))) != null)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50002, "");
		}

		// Port no == Port no in any value from List Values
		if (rowdata.getPort() != null && !"0.0".equals(rowdata.getPort()) && !"0".equals(rowdata.getPort()) && StringUtils.isNotBlank(rowdata.getPort())
				&& cdnPortCodeMap.get(rowdata.getPort().toLowerCase()) == null) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_O0095, "");
		}

		// "inter state supply check with doctypes gstin not equal to pos"
				if (!inwardRules.checkInwardInter(rowdata.getGstinOfRecipient(), orgDocType, rowdata.getSgstAmt(), rowdata.getIgstAmt(), rowdata.getCgstAmt(),
						String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply())), String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())), rowdata.getImportType(), rowdata.getReverseCharge())) {
					markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00050, "");

		}
				

		// intra check with doctypes in same states

		if (!inwardRules.checkInwardIntra(rowdata.getGstinOfRecipient(), orgDocType, rowdata.getSgstAmt(), rowdata.getIgstAmt(), rowdata.getCgstAmt(),
				String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply())), String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())), rowdata.getImportType(), rowdata.getReverseCharge())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00051, "");
			
		}
		
//		if (!inwardRules.checkInwardInter(rowdata.getGstinOfRecipient(),orgDocType,rowdata.getSgstAmt(),rowdata.getIgstAmt(),rowdata.getCgstAmt()
//				,rowdata.getPlaceOfSupply(), rowdata.getSupplierStateCode(),rowdata.getImportType(), rowdata.getReverseCharge(),dilutedValidation)) {
//			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00050, "");
//			
//		}
		
		
		
		// inwardDate should be in DD-MM-YYYY format
		if (rowdata.getInwardDate() != null && !inwardRules.isValidInvoiceDate(rowdata.getInwardDate())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00016, "");
		}

		// validate month value : It should be from list
		if (!inwardRules.isValidFP(rowdata.getInwardDate(), rowdata.getFillingPeriod()) && StringUtils.isNotBlank(rowdata.getFillingPeriod())) {
			
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00016, "");
		}

		// "check for I50111"
		if (!inwardRules.checkSezGstin(rowdata.getDocType(), rowdata.getGstinOfSupplier(),orgDocType)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50016, "");
		}
		// "check for I50115"
		if (!inwardRules.checkDeemedGstin(orgDocType, rowdata.getGstinOfSupplier())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50115, "");
		}

		// "check for I50004"
		if (!inwardRules.checkImportDoctypeGstin(rowdata.getDocType(), rowdata.getGstinOfSupplier(),orgDocType)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50004, "");
		}

		// "validate sgst rate + cgst rate list"
		String sgstRegex = "^\\d\\d*(\\.\\d{1,2})?$";
		if (rowdata.getSgstRate() != null && rowdata.getSgstRate().matches(sgstRegex) && rowdata.getCgstRate() != null
				&& rowdata.getCgstRate().matches(sgstRegex) && !inwardRules.isValidRate(rowdata.getSgstRate(), rowdata.getCgstRate(), cdnGovCodeMap)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00024, "");
		}

		// validate IGST rate list
		if (rowdata.getIgstRate() != null && rowdata.getIgstRate().matches(sgstRegex) && !cdnGovCodeMap.contains(String.valueOf(Double.parseDouble(rowdata.getIgstRate())))) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00028, "");
		}

		// check for I50039
		if (!inwardRules.checkHsnImportGoods(rowdata.getDocType(), rowdata.getImportType(), rowdata.getHsnSacCode())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50039, "");
		}

		// check rate Sgst
		if (!inwardRules.checkRateAgainstAmounts(rowdata.getSgstRate(), rowdata.getSgstAmt(), orgDocType)) {
			markErrorNAddErrorCode(rowdata,ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00033, "");
		}

		// check rateCgst
		if (!inwardRules.checkRateAgainstAmounts(rowdata.getCgstRate(), rowdata.getCgstAmt(), orgDocType)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00034, "");
		}
		
		
		// check taxable and gross
		if (!inwardRules.checkRateAgainstAmounts(rowdata.getIgstRate(), rowdata.getIgstAmt(), rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00035, "");
		}
		// check taxable and gross
		if (!inwardRules.checkValueAgainstTaxableGross(rowdata.getIgstRate(), rowdata.getCgstRate(), rowdata.getSgstRate(), rowdata.getInwardTotalTaxAmt(),
				rowdata.getInwardGrossTotalAmount(), orgDocType)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00021, "");
		}

		// "check for Inter for Import and Sez Doctype
		if (!inwardRules.checkForInterSEZIMP(rowdata.getDocType(), rowdata.getSgstRate(), rowdata.getCgstRate(), rowdata.getIgstRate(), rowdata.getIgstAmt(), rowdata.getCgstAmt(),
				rowdata.getSgstAmt(), orgDocType, rowdata.getOrgInvoiceCategory())) {
			
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50012, "");
		}

		// validate importType
		if (!inwardRules.checkForImportType(rowdata.getImportType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50032, "");
		}

		// validate ReverseCharge
		if (!StringUtils.isBlank(rowdata.getReverseCharge()) && !"n".equalsIgnoreCase(rowdata.getReverseCharge()) && !"y".equalsIgnoreCase(rowdata.getReverseCharge())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00029, "");
		}

		// rule to calculate tax for O0114 intra
		if(String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply())).equals(String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode()))) && "0".equalsIgnoreCase(rowdata.getDiffPercent())) {
			if (!inwardRules.checkInwardTaxCalculationCgstSgst(orgDocType, String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())), rowdata.isValid(),
					rowdata.getInwardTaxableAmt(), rowdata.getSgstRate(), rowdata.getCgstRate(), rowdata.getSgstAmt(), rowdata.getCgstAmt(), dilutedValidation)) {
				markErrorNAddErrorCode(rowdata, "|O0114", "");
			}
		}
				
		if(!String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply())).equals(String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode()))) && "0".equalsIgnoreCase(rowdata.getDiffPercent())) {
			if (!inwardRules.checkInwardTaxCalculationIgstWithoutDiff(orgDocType, String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode())),
					rowdata.isValid(), rowdata.getInwardTaxableAmt(), rowdata.getIgstRate(), rowdata.getIgstAmt())) {
				markErrorNAddErrorCode(rowdata, "|O0114", "");
			}
		}



		// validate importType ISD

		if (!inwardRules.checkForImportTypeISD(rowdata.getImportType(), rowdata.getDocType(), rowdata.getHsnSacCode())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50039, "");
		}

		// validate taxable Value
		if (!inwardRules.checkTaxableRegular(rowdata.getInwardTaxableAmt(), orgDocType)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00021, "");
		}


		// validate taxable for isd
		if (!inwardRules.checkTaxableISD(rowdata.getInwardTaxableAmt(), orgDocType)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50041, "");
		}

		// validate gross staxable for isd
		if (!inwardRules.checkTaxableISD(rowdata.getInwardGrossTotalAmount(), orgDocType)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50042, "");
		}

		// validate rate for isd
		if (!inwardRules.checkRateISD(rowdata.getSgstRate(), rowdata.getCgstRate(), rowdata.getIgstRate(), orgDocType)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50043, "");
		}

		// check gstin for isd
		if (!inwardRules.checkGstnIsd(rowdata.getGstinOfSupplier(), orgDocType)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50044, "");
		}

		
		// check for valid diff percentage
		if (!inwardRules.checkdiffpercentage(rowdata.getDiffPercent())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_O0113, "");
		}
		// "rule to calculate tax for O0115 inter and diff percent is equals 0.65"
		if(!String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply())).equals(String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode()))) && "0.65".equalsIgnoreCase(rowdata.getDiffPercent()) && (!inwardRules.checkInwardTaxCalculationIgst(orgDocType, rowdata.getDiffPercent(), rowdata.isValid(),
				rowdata.getInwardTaxableAmt(), rowdata.getIgstRate(), rowdata.getIgstAmt(), dilutedValidation))) {
		
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_O0115, "");
			
		}

		// rule to calculate tax for O0115 intra and diff percent is equals 0.65
		// rule to calculate tax for O0115 intra and diff percent is equals 0.65
		if(String.valueOf(Integer.parseInt(rowdata.getPlaceOfSupply())).equals(String.valueOf(Integer.parseInt(rowdata.getSupplierStateCode()))) && "0.65".equalsIgnoreCase(rowdata.getDiffPercent()) && (!inwardRules.checkInwardTaxCalculationCgstSgstDiff(orgDocType, rowdata.getDiffPercent(), rowdata.isValid(),
				rowdata.getInwardTaxableAmt(), rowdata.getSgstRate(), rowdata.getCgstRate(), rowdata.getSgstAmt(), rowdata.getCgstAmt(), dilutedValidation))) {
			
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_O0115, "");
		
		}
		// rule to check value in all three amount
		if (!inwardRules.checkAllThreeAmount(orgDocType, rowdata.getSgstAmt(), rowdata.getCgstAmt(), rowdata.getIgstAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00021, "");
		}

		// rule to check itc cgst and sgst are same
		if (!inwardRules.checkAllCgstSgstAmount(rowdata.getItcSgstAmt(), rowdata.getItcCgstAmt(), orgDocType)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00127, "");
		}

		// rule to check value in all three itc amount
		if (!inwardRules.checkAllThreeAmount(orgDocType, rowdata.getItcSgstAmt(), rowdata.getItcCgstAmt(), rowdata.getItcIgstAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00128, "");
		}
		// rule to check cgst and sgst same amount in all three amount
		if (!inwardRules.checkAllCgstSgstAmount(rowdata.getSgstAmt(), rowdata.getCgstAmt(), orgDocType)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00092, "");
		}
		
		
		// validate itc Eligible
		if (!inwardRules.checkItcEligible(rowdata.getItcEligible())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50018, "");
		}
		
		if (!inwardRules.checkOrginalDateWithoutInv(rowdata.getOrgInvoiceNo(),rowdata.getOrgInvoiceDate())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00146, "");
		}
		

		
	// validate itc Eligible
			if (!inwardRules.orgDateCheck(rowdata.getInwardDate(),rowdata.getOrgInvoiceDate(),rowdata.getPreGst(),rowdata.isValid())) {
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_O0120, "");
			}

		// check itc sgst Amount
		if (!inwardRules.checkAmtAgainstItcAmt(rowdata.getSgstAmt(), rowdata.getItcSgstAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50019, "");
		}

		// check itc cgst Amount
		if (!inwardRules.checkAmtAgainstItcAmt(rowdata.getCgstAmt(), rowdata.getItcCgstAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50020, "");
		}

		// check itc igst Amount
		if (!inwardRules.checkAmtAgainstItcAmt(rowdata.getIgstAmt(), rowdata.getItcIgstAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50021, "");
		}

		// check itc igst Amount
		if (!inwardRules.checkAmtAgainstItcAmt(rowdata.getCessAmount(), rowdata.getItcCessAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50022, "");
		}
		// check itc Total Amount
		if (!inwardRules.checkAmtAgainstItcAmt(rowdata.getInwardTotalTaxAmt(), rowdata.getTotalItcAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50023, "");
		}

		
		// itc eligible/ reversal indicator list of value check
		if (!inwardRules.checkItcReversalIndicator(rowdata.getItcIneligibleReversalIndicator())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50113, "");
		}
		// indicator present percentage not present
		if (!inwardRules.checkindicatorWithoutPercentage(rowdata.getItcIneligibleReversalIndicator(), rowdata.getItcIneligibleReversalPercentage())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50117, "");
		}

		// indicator No absent percentage present
		if (!inwardRules.checkPercentageWithoutIndicator(rowdata.getItcIneligibleReversalIndicator(), rowdata.getItcIneligibleReversalPercentage())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50116, "");
		}
		// ack date should not be in future
		if (!inwardRules.isValidFutureAckDate(rowdata.getAckDate())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00170, "");
		}
		//WOPAY rate and amount check
		if(!inwardRules.checkSEZWOPAYAmount(rowdata.getOrgInvoiceCategory(),rowdata.getSgstAmt(),rowdata.getIgstAmt(),rowdata.getCgstAmt()) ) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50120, "");
		}
		//BOE,port,boedate if one present all should be present
		if(!inwardRules.checkBOEDetailforImport(rowdata.getOrgInvoiceCategory(),rowdata.getImportBillOfEntryNo(),rowdata.getImportBillOfEntryDate(),rowdata.getPort()) ) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00227, "");
		}
		
		//validate InwardGrossTotal amount Greater than 13 digit
		if((StringUtils.isBlank(rowdata.getInwardGrossTotalAmount())) || !inwardRules.checkLength14GNew(rowdata.getInwardGrossTotalAmount(), true)) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00111, "");
		}
		//check rate Cess
		if(!inwardRules.checkRateAgainstAmounts(rowdata.getCessRate(),rowdata.getCessAmount(),rowdata.getDocType())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50121, "");
		}
		
		//validate importType IMPGSEZ
		if(!inwardRules.checkForImportTypeIMPGSEZ(rowdata.getImportType(),rowdata.getOrgInvoiceCategory(),rowdata.getHsnSacCode())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00228, "");
		}
		
		if(StringUtils.isNotBlank(rowdata.getPaymentAmount()) && !inwardRules.onlyNumeric(rowdata.getPaymentAmount()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00538, "");
		}
		
		if(StringUtils.isNotBlank(rowdata.getTdsSection()) && !tdsSections.contains(rowdata.getTdsSection()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00527, "");
		}
				
			
		if(StringUtils.isNotBlank(rowdata.getPaymentAmount()) && !inwardRules.onlyNumeric(rowdata.getPaymentAmount()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00538, "");
		}
		if(StringUtils.isNotBlank(rowdata.getPaymentRefNo()) && !inwardRules.isSpecialCharExistInInvoiceNo(rowdata.getPaymentRefNo()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00526, "");
		}
		
		if (!inwardRules.checkNilRated(orgDocType, rowdata.getSgstAmt(), rowdata.getCgstAmt(), rowdata.getIgstAmt(), rowdata.getCessAmount(), rowdata.getNilRatedAmt(),
				rowdata.getExemptedAmt(), rowdata.getNonGstAmt(), rowdata.getCompositionAmt())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_I50040, "");
		}
		
		}
	
	


	private void markErrorNAddErrorCode(InwardInvoiceCDNTemplateDTO rowdata, String errorCode, String errorMsg) {
		rowdata.setErrorCodeList(rowdata.getErrorCodeList().append(errorCode));
		rowdata.setErrorDescriptionList(rowdata.getErrorDescriptionList().append(errorMsg));
		rowdata.setValid(false);
	}

		
	

}
