package com.bdo.bvms.common.util;

import java.io.IOException;

import java.math.BigDecimal;
import java.math.RoundingMode;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.csvreader.CsvReader;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AppUtil {

	private AppUtil()
	{
		super();
	}
	
	public static String getCellValue(Cell cell) {
		String strCellValue = null;
		
		try {
		
		if (cell != null) {
		
				switch (cell.getCellType()) {
					case STRING:
						strCellValue = cell.getStringCellValue().replaceAll("[\n\r\t]", " ");
						break;
					case FORMULA:
					    switch (cell.getCachedFormulaResultType()) {
					        case BOOLEAN:
					        	strCellValue=Boolean.toString(cell.getBooleanCellValue());
					            break;
					        case NUMERIC:
					        	strCellValue = NumberToTextConverter.toText(cell.getNumericCellValue());
					            break;
					        case STRING:
					        	
					            strCellValue = cell.getRichStringCellValue().getString().replaceAll("[\n\r\t]", " ");
					            break;
					        default:    
					    }
					
						break;
					case NUMERIC:
						if (DateUtil.isCellDateFormatted(cell)) {
							SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
							strCellValue = dateFormat.format(cell.getDateCellValue());

						} else {
							strCellValue = NumberToTextConverter.toText(cell.getNumericCellValue());
						}
						break;
					case BOOLEAN:
						strCellValue = Boolean.toString(cell.getBooleanCellValue());
						break;
					case BLANK:
						strCellValue = "";
						break;
					default:
						
				}
			}
		
		if (strCellValue != null) {
			strCellValue = strCellValue.trim();
		} else {
			strCellValue = "";
		}
		
		}catch(Exception ex) {
			log.error("Exception in getCellValue method ",ex);
			switch (cell.getCellType()) {
				case STRING:
					strCellValue = "";
					break;
				case FORMULA:
				    switch (cell.getCachedFormulaResultType()) {
				        case BOOLEAN:
				        	strCellValue="false";
				            break;
				        case NUMERIC:
				        	strCellValue = "0";
				            break;
				        case STRING:
				           
				            strCellValue = "";
				            break;
				        default:    
				    }
				
					break;
				case NUMERIC:
					if (DateUtil.isCellDateFormatted(cell)) {
						strCellValue = "";

					} else {
						strCellValue = "0";
					}
					break;
				case BOOLEAN:
					strCellValue = "false";
					break;
				case BLANK:
					strCellValue = "";
					break;
				default:
					
		}
		}
		return strCellValue;
	}
	public static Map<String, Integer> getColumnNameIndexMap(Row coumnsDataRow) throws VendorInvoiceServerException {

		Map<String, Integer> colNameIndexMap = new java.util.HashMap<>(); // Create map
		try {
		int minColIx = coumnsDataRow.getFirstCellNum(); // get the first column
		// index for a row
		int maxColIx = coumnsDataRow.getLastCellNum(); // get the last column
		// index for a row
		Cell cell;
		for (int colIx = minColIx; colIx < maxColIx; colIx++) { // loop from
			// first to last
			// index
			cell = coumnsDataRow.getCell(colIx); // get the cell
			
			if(cell.getCellType()==CellType.NUMERIC) {
				colNameIndexMap.put(String.valueOf(cell.getNumericCellValue()), cell.getColumnIndex()); // add the cell contents (name of column) and cell index to the map
			}else {
				colNameIndexMap.put(cell.getStringCellValue().replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE), cell.getColumnIndex()); // add the cell contents (name of column) and cell index to the map
			}
			
			
		}
		}
		catch(Exception ex)
		{
			log.error("Exception in getColumnNameIndexMap method ",ex);
			throw new VendorInvoiceServerException(ex.getMessage(), ex.getCause());
		}
		return colNameIndexMap;
	}
	
	public static Boolean isNotBlank(Row row) {
		int cellCount;
		Cell cell;
		for (cellCount = row.getFirstCellNum(); cellCount <= row.getLastCellNum(); cellCount++) {
			cell = row.getCell(cellCount);
			if (cell != null && row.getCell(cellCount).getCellType() != CellType.BLANK) {
				return true;
			}
		}
		return false;
	}
	
	public static List<String> getColumnNameList(Row coumnsDataRow) {

        List<String> headerList = new ArrayList<>();
        int minColIx = coumnsDataRow.getFirstCellNum(); // get the first column
        // index for a row
        int maxColIx = coumnsDataRow.getLastCellNum(); // get the last column
        // index for a row
        Cell cell;
        for (int colIx = minColIx; colIx < maxColIx; colIx++) { // loop from
            // first to last
            // index
            cell = coumnsDataRow.getCell(colIx); // get the cell

            if (cell.getCellType() == CellType.NUMERIC) {
                headerList.add(String.valueOf(cell.getNumericCellValue())); 
            } else {
                headerList.add(cell.getStringCellValue()); 
            }
        }
        return headerList;
    }

	public static String formatRateAmoutValues(String inputStr) {
		String opStr = null;
		if (inputStr != null) {
			opStr = inputStr.replace(",", "");
		}
		return opStr;
	}

	public static BigDecimal calculatePercentage(double percent, BigDecimal amount) {
		int scale=0;
		if(amount!=null && amount.intValue()==0) {
			
			return new BigDecimal("0.0");
		}


		double percentAmount = (percent / 100);

		BigDecimal newPercentAmount = BigDecimal.valueOf(percentAmount);

		newPercentAmount = newPercentAmount.setScale(3, RoundingMode.HALF_UP);

		if(!String.valueOf(amount).contains(".")) {
			amount = new BigDecimal(amount+".0");
		}
		
		if(amount!=null) {
			scale = amount.scale();
		}
	
		newPercentAmount = newPercentAmount.multiply(amount).setScale(scale,RoundingMode.HALF_UP);
		return newPercentAmount;
	}

	 public static String[] getHeaders(CsvReader products) throws IOException {
        String[] data = null;

        while (products.readRecord()) {
            if (products.getCurrentRecord() == 0) {
                data = products.getValues();
                break;
            }

        }

        return data;
    }

	public static String einvdocTypeToGstr2Doctype(String doctype) {
		String gstr1Doctype = "";
		switch (doctype) {
			case "B2B":
				gstr1Doctype = "Regular Tax Invoice";
				break;
			case "ISD":
				gstr1Doctype = "ISD Invoice";
				break;
			case "RCM":
				gstr1Doctype = "RCM Invoice";
				break;
			case "NIL":
			case "EXM":
			case "NON":
			case "COMP":
				gstr1Doctype = "Bill of supply";
				break;
			case "IMPG":
			case "IMPS":
				gstr1Doctype = "Import Invoice";
				break;
			case "SEZWP":
			case "SEZWOP":
			case "IMPGSEZ":
				gstr1Doctype = "SEZ Invoice";
				break;
			case "DEXP":
				gstr1Doctype = "Deemed Export Invoice";
				break;
			case "CRN":
				gstr1Doctype = "Credit note";
				break;
			case "DBN":
				gstr1Doctype = "Debit note";
				break;
			default:
				gstr1Doctype = doctype;
				break;
		}

		return gstr1Doctype;
	}

	public static StringBuilder formatValueForCSV(StringBuilder sb, String str) {
		String string = str;
		if (sb != null && string != null && !string.isEmpty()) {
			if (string.indexOf('"') != -1) {
				string = str.replace("\"", "\"\"");
			}
			if (string.contains(",")) {
				sb.append("\"").append(string).append("\"");
			} else {
				sb.append(string);
			}
		}
		return sb;
	}
	
}
