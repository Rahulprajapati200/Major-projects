package com.bdo.bvms.common.service;

import java.util.List;

import com.bdo.bvms.common.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.common.dto.UploadLogHistoryResDataDto;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface VendorCommunicationUploadLogHistoryService {

    List<UploadLogHistoryResDataDto> getHistoryList(UploadHistoryRequestDTO uploadHistoryRequestDTO)
                    throws VendorInvoiceServerException;

}
