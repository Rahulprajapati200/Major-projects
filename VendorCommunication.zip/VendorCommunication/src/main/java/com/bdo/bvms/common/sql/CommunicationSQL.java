package com.bdo.bvms.common.sql;

public class CommunicationSQL {

    private CommunicationSQL() {
        super();
    }

    public static final String GET_AZURE_CREDENTIAL_FROM_DB = "select url,container_name from sm_entity_cloud_credentials where entity_id=? AND type=?";
    public static final String INSERT_INTO_UPLOAD_LOG = "INSERT INTO upload_log (upload_source,entity_id,batch_no,pld_template_type,taxpayer_pan,taxpayer_gstin,file_name,fp,file_type,upload_start_time,file_size,base_file_location,is_custom_template,custom_template_id,pld_upload_status,pld_upload_source,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    public static final String INSERT_INTO_UPLOAD_STAGE_LOG = "INSERT INTO upload_stage_log (upload_log_id, pld_process_stage, pld_process_state,created_at,created_by,batch_no) VALUES (?,?,?,?,?,?)";
    public static final String GET_UPLOAD_LOG_ID = "select id from upload_log where batch_no=?";
    public static final String UPDATE_PLD_UPLOAD_STATUS = "update upload_log set pld_upload_status=? where batch_no=?";
    public static final String INSERT_FILE_SQL = "LOAD DATA LOCAL INFILE ? INTO TABLE table_name CHARACTER SET latin1 FIELDS TERMINATED BY \',\' ENCLOSED BY \'"
            + '"' + "\' LINES TERMINATED BY \'\r\n\' IGNORE 1 LINES;";
    public static final String GET_PERTICULAR_DATA_OF_SUCCESS_RECORDS = "select gstin_uin_of_recipient,doc_type,supply_type,doc_no,doc_date,org_invoice_no,org_invoice_date,gstin_of_supplier,supplier_name,"
                    + "supplier_state_code,inward_no,inward_date,item_description,hsn_code,uom,quantity,item_rate,ass_amt,sgst_rate,sgst_amt,cgst_rate,cgst_amt,"
                    + "igst_rate,igst_amt,cess_rate,cess_amount,diff_percent,inward_gross_total_amount,total_invoice_amt,"
                    + "input_type,itc_ineligible_reversal_indicator,itc_ineligible_reversal_percentage,place_of_supply,"
                    + "reverse_charge,port,import_bill_of_entry_no,import_bill_of_entry_date,import_bill_of_entry_amt,"
                    + "date_of_payment,irn,ack_date,ack_no,debit_gl_id,debit_gl_name,credit_gl_id,credit_gl_name,sub_location,"
                    + "row_version,status,error_code from invoice_upload_err_log where batch_no like '";
    public static final String GET_ERRORCODE_AND_SHORTDESCRIPTION = "SELECT ErrorCode,ShortDescription FROM bvms_error";
    public static final String UPDATE_VALIDATION_START_TIME_STAMP = "update upload_log set upload_start_time=? where batch_no=?";
    public static final String UPDATE_STAGE_STATE = "update upload_stage_log set pld_process_stage=?,pld_process_state=? where upload_log_id=?";
    public static final String UPDATE_SUCESSNERROR_COUNT = "update upload_log set error_count=?,success_count=? where batch_no=?";
    public static final String UPDATE_TOTAL_COUNT = "update upload_log set total_count=?,doc_err_count=? where batch_no=?";
    public static final String UPDATE_VALIDATION_FINAL_TIME_STAMP = "update upload_log set upload_end_time=? where batch_no=?";
    public static final String UPDAT_ERROR_FILE_NAME = "update upload_log set error_file_location=? where batch_no=?";
    public static final String GET_RETURN_YEAR = "select fp from sm_return_periods where year_id = ?";
    public static final String INSERT_EXCEPTION_LOG = "insert into exception_log(screen_name,function_name,error_message,error_cause,line_no,user_id,created_at,requested_at,requested_by) VALUES (?,?,?,?,?,?,?,?,?)";
    public static final String GET_AM_ENTITY_GSTIN_LIST_QYERY = "select gstin_taxpayer from bvms_trn_local.taxpayer_vendors where pan_taxpayer=";
    public static final String GET_CUSTOM_TEMPLATE_HEADER_MAPPING_SQL = new StringBuilder(
                    "SELECT  cc.column_name as standardHeader , cm.template_column as customHeader \n")
                                    .append(" FROM am_template_column_configuration cc ")
                                    .append(" INNER JOIN   am_custom_template_column_mapping cm ON cc.id = cm.am_template_column_configuration_id\n")
                                    .append(" where cm.custom_template_name_id=? order by cc.order_no  ").toString();
	public static final String UPDATE_ERROR_REMARKS = "update upload_log set pld_upload_status=?, remarks=? where batch_no=?";
	public static final String UPDATEFPLOG = "update upload_log set fp=? where batch_no=?";
	public static final String INSERTINTOSTAGELOG = " insert into upload_stage_log(batch_no,pld_process_stage,pld_process_state,created_at,created_by) VALUES (?,?,?,?,?)";
	public static final String GETTDSSECTIONLIST = "select section_name from sm_tds_sections";
	public static final String UPDATEPAYMENTDETAILS = "update inward_purchase_register_payment_details set date_of_payment=?,payment_amount=?,payment_ref_no=?,invoice_against_prov_adv=?,inward_no_prov_adv=? ,updated_on=?,row_version=? where id=?";
	public static final String INSERTPAYMENTDETAILS = "insert into inward_purchase_register_payment_details(date_of_payment,payment_amount,payment_ref_no,invoice_against_prov_adv,inward_no_prov_adv"
			+ "           ,gstin_uin_of_recipient,doc_type,gstin_of_supplier,supplier_name,inward_no,inward_date,updated_on,row_version,batch_no)  values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String UPDATETDSDETAILS = "update inward_tds set tds_section=?,tds_rate=?,tds_tax_amount=?,challan_number=?,challan_date=? ,challan_amount=?,period_of_filing=?,gross_amount=?,"
			+ "date_of_payment=?,payment_ref_no=?,payment_amount=?,ass_amt=?,invoice_against_prov_adv=?,inward_no_prov_adv=?,"
			+ "inward_date_prov_adv=?,amount_of_prov_adv=?,bal_outstanding=?,vendor_code_erp=?,row_version=? where id=?";

	public static final String INSERTTDSDETAILS = "insert into inward_tds(pan_of_recipient,gstin_uin_of_recipient,doc_type,gstin_of_supplier,\r\n"
			+ "pan_of_supplier,supplier_name,doc_no,doc_date,inward_no,inward_date,tds_section,tds_rate,\r\n"
			+ "tds_tax_amount,challan_number,challan_date,\r\n"
			+ "challan_amount,period_of_filing,\r\n"
			+ "debit_gl_id,debit_gl_name,credit_gl_id,credit_gl_name,gross_amount,date_of_payment,"
			+ " payment_ref_no,payment_amount,ass_amt,invoice_against_prov_adv,inward_no_prov_adv,"
			+ "inward_date_prov_adv,amount_of_prov_adv,bal_outstanding,vendor_code_erp,row_version,batch_no)\r\n"
			+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
	public static final String DELETEFROMPAYMENTTABLE = "delete from inward_purchase_register_payment_details where id =?";

	public static final String DELETEFROTDSTABLE = "delete from inward_tds where id =?";

	public static final String DELETEFROMINVTABLE = "delete from inward_dnr where id =?";

	public static final String DELETEFROMDNRVTABLE = "delete from inward_purchase_reg where id =?";
	public static final String COUNTPAYMENTDATA = "select count(1) from inward_purchase_reg where inward_no=? and"
			+ " gstin_of_recipient=? and gstin_of_supplier=? ";
	public static final String COUNTPAYMENTDATAINDNR = "select count(1) from inward_dnr where inward_no=? and"
			+ " gstin_of_recipient=? and gstin_of_supplier=? ";
	public static final String COUNTPAYMENTDATADUPLICATE = "select count(1) from inward_purchase_register_payment_details where inward_no=? and"
			+ " gstin_uin_of_recipient=? and gstin_of_supplier=? and doc_type =? and payment_amount =? and payment_ref_no =?"
			+ " and inward_date=? and date_of_payment=?";
	public static final String PAYMENTITEMSQL = "select concat(date_of_payment,payment_amount"
			+ ") as payment_key from inward_purchase_register_payment_details where gstin_uin_of_recipient=? and gstin_of_supplier=? and payment_ref_no=?";
	public static final String UPDATEINVINWARD = "update inward_purchase_reg set itc_ineligible_reversal_indicator=? ,itc_ineligible_reversal_percentage=? where gstin_of_recipient=?"
			+ " and gstin_of_supplier=? and inward_no=? and inward_date=?";
	public static final String UPDATECDNINWARD = "update inward_dnr set itc_ineligible_reversal_indicator=? ,itc_ineligible_reversal_percentage=? where gstin_of_recipient=?"
			+ " and gstin_of_supplier=? and inward_no=? and inward_date=?";
	
    public static String getUpdateCRNINVQuery(String docType) {
        StringBuilder sql = new StringBuilder();
        if ("INV".equals(docType)) {

            sql.append("insert int trnDatabaseName.inward_purchase_reg (gstin_of_recipient,doc_type,supply_type,gstin_of_supplier,"
                            + "supplier_name,inward_no,inward_date,taxable_amt,place_of_supply,gross_total_amount,invoice_type,"
                            + "itc_ineligible_reversal_indicator,itc_ineligible_reversal_percentage,supplier_state_code,hsn_sac_code"
                            + "quantity,uom,igst_amt,igst_rate,cgst_amt,cgst_rate,sgst_amt,sgst_rate,cess_amt,cess_rate,row_version) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        } else {
            sql.append("insert int trnDatabaseName.inward_purchase_reg (gstin_of_recipient,doc_type,supply_type,gstin_of_supplier,"
                            + "supplier_name,inward_no,inward_date,taxable_amt,place_of_supply,gross_total_amount,invoice_type,"
                            + "itc_ineligible_reversal_indicator,itc_ineligible_reversal_percentage,supplier_state_code,hsn_sac_code"
                            + "quantity,uom,igst_amt,igst_rate,cgst_amt,cgst_rate,sgst_amt,sgst_rate,cess_amount,cess_rate,row_version) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        }
        return sql.toString();
    }

    public static final String getUPDATEPLDCODEQUERY(String mstDb) {
        return "select ld.id from " + mstDb + ".am_custom_template_name tn join " + mstDb
                        + ".sm_pickup_list_details ld on "
                        + "ld.code= tn.pld_template_id where tn.id =? and ld.sm_pick_mst_id=? and  ld.pick_key=?";
    }

    public static String getInwardResultSql( String inwardDate, String gstinOfSupplier, String fp,
                    String yearId, String mstDatabaseName, String trnDatabaseName) {
        return "select count(1) from " + trnDatabaseName
                        + ".inward_purchase_reg where gstin_of_recipient = ? and gstin_of_supplier = ? and fp in (select fp FROM "
                        + mstDatabaseName + ".sm_return_periods where year_id = ? and fp != ?) and inward_no = ?";

    }

    public static String getInwardResultSqlCDN( String inwardDate, String gstinOfSupplier, String fp,
            String yearId, String mstDatabaseName, String trnDatabaseName) {
return "select count(1) from " + trnDatabaseName
                + ".inward_dnr where gstin_of_recipient = ? and gstin_of_supplier = ? and fp in (select fp FROM "
                + mstDatabaseName + ".sm_return_periods where year_id = ? and fp != ?) and inward_no = ?";

}

    
    public static String getDuplocateFPQuery(String trnDatabaseName, String mstDatabaseName) {
        return " Select distinct lower(concat(gstin_of_supplier,inward_no)) from " + trnDatabaseName
                        + ".inward_purchase_reg \r\n" + "where  gstin_of_recipient=? and fp in (select fp FROM "
                        + mstDatabaseName + ".sm_return_periods where year_id = ? and fp != ?)";
    }
    
    public static String getDuplocateFPQueryCDN(String trnDatabaseName, String mstDatabaseName) {
        return " Select distinct lower(concat(gstin_of_supplier,inward_no)) from " + trnDatabaseName
                        + ".inward_dnr \r\n" + "where  gstin_of_recipient=? and fp in (select fp FROM "
                        + mstDatabaseName + ".sm_return_periods where year_id = ? and fp != ?)";
    }

    public static String getDuplicateInwardCdnQuery(String mstDatabaseName, String trnDbName) {
        return "  select distinct lower(concat(inward_no,gstin_of_supplier)) from " + trnDbName
                        + ".inward_dnr where gstin_of_recipient = ? and fp in (select fp FROM " + mstDatabaseName
                        + ".sm_return_periods where year_id = ? and fp != ?) and is_amendment = 0";
    }

    public static String getGstinDb(String mstDB) {

        return "select distinct from_base64(gstin) from " + mstDB + ".am_entity_master where from_base64(pan)=?";

    }

	public static String getItcResultSql( String inwardDate, String gstinOfSupplier, String fp,
                    String yearId, String mstDatabaseName, String trnDatabaseName) {
        return "select count(1) from " + trnDatabaseName
                        + ".inward_itc where gstin_uin_of_recipient = ? and gstin_of_supplier = ? and fp in (select fp FROM "
                        + mstDatabaseName + ".sm_return_periods where year_id = ? and fp != ?) and inward_no = ?";

    }


	  public static String getItcDuplicateFPQuery(String trnDatabaseName, String mstDatabaseName) {
	        return " Select distinct lower(concat(gstin_of_supplier,inward_no)) from " + trnDatabaseName
	                        + ".inward_itc \r\n" + "where  gstin_uin_of_recipient=? and fp in (select fp FROM "
	                        + mstDatabaseName + ".sm_return_periods where year_id = ? and fp != ?)";
	    }

	
	public static String getPaymentResultSql( String inwardDate, String gstinOfSupplier, String fp,
            String yearId, String mstDatabaseName, String trnDatabaseName) {
return "select count(1) from " + trnDatabaseName
                + ".inward_purchase_register_payment_details where gstin_uin_of_recipient = ? and gstin_of_supplier = ? and payment_fp in (select fp FROM "
                + mstDatabaseName + ".sm_return_periods where year_id = ? and fp != ?) and inward_no = ?";

}

	
	  public static String getPaymentDuplicateFPQuery(String trnDatabaseName, String mstDatabaseName) {
	        return " Select distinct lower(concat(gstin_of_supplier,inward_no)) from " + trnDatabaseName
	                        + ".inward_purchase_register_payment_details " + "where  gstin_uin_of_recipient=? and fp in (select fp FROM "
	                        + mstDatabaseName + ".sm_return_periods where year_id = ? and fp != ?)";
	    }


	
	 public static String getTdsDuplicateFPQuery(String trnDatabaseName, String mstDatabaseName) {
	        return " Select distinct lower(concat(gstin_of_supplier,inward_no)) from " + trnDatabaseName
	                        + ".inward_tds " + "where  gstin_uin_of_recipient=? and fp in (select fp FROM "
	                        + mstDatabaseName + ".sm_return_periods where year_id = ? and fp != ?)";
	    }

	
	public static String getTdsResultSql( String inwardDate, String gstinOfSupplier, String fp,
            String yearId, String mstDatabaseName, String trnDatabaseName) {
return "select count(1) from " + trnDatabaseName
                + ".inward_tds where gstin_uin_of_recipient = ? and gstin_of_supplier = ? and fp in (select fp FROM "
                + mstDatabaseName + ".sm_return_periods where year_id = ? and fp != ?) and inward_no = ?";

}


}
