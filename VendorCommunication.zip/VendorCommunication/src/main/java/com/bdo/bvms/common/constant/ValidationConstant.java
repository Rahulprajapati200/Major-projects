package com.bdo.bvms.common.constant;

public final class ValidationConstant {

	ValidationConstant() {

	}

	public static final String GSTIN_PATTERN = "^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$";

	public static final String EMAIL_ID_PATTERN = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}";

	public static final String PAN_PATTERN = "[A-Z]{5}[0-9]{4}[A-Z]{1}";

	public static final String MOBILE_PATTERN = "[0-9]{10}";

	public static final String EMAIL_PATTERN = "^(.+)@(\\S+)$";

	public static final String BANK_IFSC_PATTERN = "^[A-Z]{4}0[A-Z0-9]{6}$";

	public static final String PINCODE_PATTERN = "[0-9]{6}";

	public static final int GSTIN_MIN_SIZE = 15;

	public static final int GSTIN_MAX_SIZE = 15;

	public static final int PAN_MIN_SIZE = 10;

	public static final int PAN_MAX_SIZE = 10;

	public static final int MOBILE_MIN_SIZE = 10;

	public static final int MOBILE_MAX_SIZE = 10;

	public static final int AADHAR_MIN_SIZE = 12;

	public static final int AADHAR_MAX_SIZE = 12;

	public static final int PINCODE_MIN_SIZE = 0;

	public static final int PINCODE_MAX_SIZE = 999999;

	// ***********************BANK DETAILS LENGTH VALIDATION

	public static final int BANKNAME_MIN_SIZE = 1;

	public static final int BANKNAME_MAX_SIZE = 50;

	public static final int BANK_ACCOUNT_HOLDER_NAME_MIN_SIZE = 1;

	public static final int BANK_ACCOUNT_HOLDER_NAME_MAX_SIZE = 50;

	public static final int BANK_ACCOUNT_NO_MIN_SIZE = 9;

	public static final int BANK_ACCOUNT_NO_MAX_SIZE = 18;

	public static final int BANK_IFSC_MIN_SIZE = 11;

	public static final int BANK_IFSC_MAX_SIZE = 11;

	public static final int BANK_ADDRESS_MIN_SIZE = 1;

	public static final int BANK_ADDRESS_MAX_SIZE = 50;

	// ********************************ADDRESS LENGTH VALIDATIONS*****************

	public static final int ADDRESS_TYPE_MAX_SIZE = 5;

	public static final int ADDRESS_TYPE_MIN_SIZE = 1;

	public static final int ADDRESS_LINE1_MAX_SIZE = 100;

	public static final int ADDRESS_LINE1_MIN_SIZE = 1;

	public static final int PLACE_MAX_SIZE = 100;

	public static final int PLACE_MIN_SIZE = 1;

	// ********************************CONTACT LENGTH VALIDATIONS******************

	public static final int FIRST_NAME_MIN_SIZE = 1;

	public static final int FIRST_NAME_MAX_SIZE = 25;

	public static final int LAST_NAME_MIN_SIZE = 1;

	public static final int LAST_NAME_MAX_SIZE = 25;

	public static final int EMAIL_COND_MIN_SIZE = 0;

	public static final int EMAIL_MIN_SIZE = 1;

	public static final int EMAIL_MAX_SIZE = 320;

	// ********************************MASTER UPDATE VALIDATIONS******************

	public static final int LEGAL_NAME_OF_BUSINESS_MIN_SIZE = 1;

	public static final int LEGAL_NAME_OF_BUSINESS_MAX_SIZE = 200;

	public static final int TRADE_NAME_OF_BUSINESS_MIN_SIZE = 1;

	public static final int TRADE_NAME_OF_BUSINESS_MAX_SIZE = 200;

	public static final int VENDOR_CODE_MIN_SIZE = 1;

	public static final int VENDOR_CODE_MAX_SIZE = 40;

	public static final Long VENDOR_UPLOAD_FILE_MIN_SIZE = 10000l;

	public static String generateNullOrEmptyMsg(String fieldName) {
		return fieldName;
	}

	public static final int UPLOAD_LOG_FILE_TYPE_MIN = 0;

	public static final int UPLOAD_LOG_FILE_TYPE_MAX = 1;

	public static final int CUSTOM_TEMPLATE_NAME_MIN = 1;

	public static final int CUSTOM_TEMPLATE_NAME_MAX = 100;

	public static final String EINVOICE_ERROR_CODE_DE1000 = "|DE1000";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00055 = "|E00055";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00049 = "|E00049";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00517 = "|E00517";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00142 = "|E00142";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00058 = "|E00058";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00144 = "|E00144";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00046 = "|E00046";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00047 = "|E00047";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00141 = "|E00141";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00013 = "|E00013";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00518 = "|E00518";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00015 = "|E00015";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50102 = "|I50102";
	public static final String VENDOR_COMMON_VALIDATION_CODE_O0095 = "|O0095";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50002 = "|I50002";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00051 = "|E00051";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00050 = "|E00050";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00016 = "|E00016";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50016 = "|I50016";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50115 = "|I50115";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50004 = "|I50004";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00024 = "|E00024";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00028 = "|E00028";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50039 = "|I50039";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00033 = "|E00033";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00034 = "|E00034";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00035 = "|E00035";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00021 = "|E00021";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50012 = "|I50012";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50032 = "|I50032";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00029 = "|E00029";
	public static final String VENDOR_COMMON_VALIDATION_CODE_O0114 = "|O0114";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50041 = "|I50041";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50042 = "|I50042";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50043 = "|I50043";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50044 = "|I50044";
	public static final String VENDOR_COMMON_VALIDATION_CODE_O0113 = "|O0113";
	public static final String VENDOR_COMMON_VALIDATION_CODE_O0115 = "|O0115";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00127 = "|E00127";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00128 = "|E00128";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00092 = "|E00092";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50018 = "|I50018";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00147 = "|E00147";
	public static final String VENDOR_COMMON_VALIDATION_CODE_O0120 = "|O0120";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50019 = "|I50019";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50020 = "|I50020";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50021 = "|I50021";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50022 = "|I50022";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50023 = "|I50023";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50113 = "|I50113";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50117 = "|I50117";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50116 = "|I50116";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00170 = "|E00170";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50120 = "|I50120";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00227 = "|E00227";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50121 = "|I50121";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00228 = "|E00228";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00030 = "|E00030";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00054 = "|E00054";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00031 = "|E00031";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00165 = "|E00165";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00095 = "|E00095";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00022 = "|E00022";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00027 = "|E00027";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00032 = "|E00032";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00019 = "|E00019";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00017 = "|E00017";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00037 = "|E00037";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00038 = "|E00038";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50024 = "|I50024";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50025 = "|I50025";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50026 = "|I50026";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50027 = "|I50027";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50028 = "|I50028";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00039 = "|E00039";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00153 = "|E00153";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50013 = "|I50013";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50030 = "|I50030";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00044 = "|E00044";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00094 = "|E00094";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00093 = "|E00093";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00168 = "|E00168";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50118 = "|I50118";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00163 = "|E00163";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00158 = "|E00158";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50114 = "|I50114";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50119 = "|I50119";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00164 = "|E00164";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00270 = "|E00270";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00272 = "|E00272";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00271 = "|E00271";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00273 = "|E00273";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50201 = "|I50201";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00100 = "|E00100";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00275 = "|E00275";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00274 = "|E00274";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00276 = "|E00276";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00277 = "|E00277";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00278 = "|E00278";
	public static final String VENDOR_COMMON_VALIDATION_CODE_I50111 = "|I50111";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00101 = "|E00101";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00102 = "|E00102";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00103 = "|E00103";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00104 = "|E00104";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00105 = "|E00105";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00106 = "|E00106";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00107 = "|E00107";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00108 = "|E00108";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00109 = "|E00109";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00111 = "|E00111";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00114 = "|E00114";
	public static final String ERROR_CODE_E00353 = "|E00353";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00313 = "|E00313";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00519 = "|E00519";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00315 = "|E00315";
	public static final String VENDOR_COMMON_REGX = "^\\s*(?=.*[0-9])\\d*(?:\\.\\d{1,2})?\\s*$";

	public static final String ERRORCODEE00352 = "|E00352";	

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00356 = "|E00356";


	public static final String VENDOR_COMMON_VALIDATION_CODE_E00073 = "|E00073";
	

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00539 = "|E00539";


	public static final String VENDOR_COMMON_VALIDATION_CODE_E00526 = "|E00526";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00527 = "|E00527";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00528 = "|E00528";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00529 = "|E00529";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00530 = "|E00530";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00531 = "|E00531";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00532 = "|E00532";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00533 = "|E00533";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00534 = "|E00534";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00535 = "|E00535";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00536 = "|E00536";

	public static final String ERROR_CODE_E00310 = "|E00310";
	public static final String ERROR_CODE_E00309 = "|E00309";

	public static final String ERROR_CODE_E00275 = "|E00275";
	public static final String ERROR_CODE_E00311 = "|E00311";

	public static final String ERROR_CODE_E00308 = "|E00308";
	public static final String ERROR_CODE_E00307 = "|E00307";

	public static final String ERROR_CODE_E00306 = "|E00306";
	
	public static final String ERROR_CODE_E00305 = "|E00305";

	public static final String ERROR_CODE_E00304 = "|E00304";
	public static final String ERROR_CODE_E00303 = "|E00303";

	public static final String ERROR_CODE_E00302 = "|E00302";
	public static final String ERROR_CODE_E00301 = "|E00301";

	public static final String ERROR_CODE_E00293 = "|E00293";

	public static final String ERROR_CODE_E00294 = "|E00294";

	public static final String ERROR_CODE_E00295 = "|E00295";

	public static final String ERROR_CODE_E00296 = "|E00296";

	public static final String ERROR_CODE_E00297 = "|E00297";

	public static final String ERROR_CODE_E00298 = "|E00298";

	public static final String ERROR_CODE_E00299 = "|E00299";

	public static final String ERROR_CODE_E00300 = "|E00300";

	public static final String ERROR_CODE_E00312 = "|E00312";

	public static final String ERROR_CODE_E00556 = "|E00556";

	public static final String ERROR_CODE_E00555 = "|E00555";

	public static final String ERROR_CODE_E00554 = "|E00554";

	public static final String ERROR_CODE_E00553 = "|E00553";

	public static final String ERROR_CODE_E00552 = "|E00552";

	public static final String ERROR_CODE_E00551 = "|E00551";

	public static final String ERROR_CODE_E00550 = "|E00550";

	public static final String ERROR_CODE_E00549 = "|E00549";

	public static final String ERROR_CODE_E00548 = "|E00548";

	public static final String ERROR_CODE_E00547 = "|E00547";

	public static final String ERROR_CODE_E00546 = "|E00546";

	public static final String ERROR_CODE_E00545 = "|E00545";

	public static final String ERROR_CODE_E00544 = "|E00544";

	public static final String ERROR_CODE_E00543 = "|E00543";

	public static final String ERROR_CODE_E00542 = "|E00542";

	public static final String ERROR_CODE_E00540 = "|E00540";

	public static final String ERROR_CODE_E00541 = "|E00541";

	public static final String ERROR_CODE_E00539 = "|E00539";

	public static final String ERROR_CODE_E00538 = "|E00538";

	public static final String ERROR_CODE_E00537 = "|E00537";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00565 = "|E00565";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00538 = "|E00538";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00557 = "|E00557";

	public static final String ERROR_CODE_E00558 = "|E00558";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00559 = "|E00559";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00560 = "|E00560";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00561 = "|E00561";
	
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00562 ="|E00562";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00563 = "|E00563";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00257 = "|E00257";


	public static final String VENDOR_COMMON_VALIDATION_CODE_E00564 = "|E00565";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00566 = "|E00566";

	public static final String ERROR_CODE_E00014 = "|E00014";

	public static final String ERROR_CODE_E00567 = "|E00567";

	public static final String ERROR_CODE_E00330 = "|E00330";
	public static final String VENDOR_COMMON_VALIDATION_CODE_E00166 = "|E00166";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00167 = "|E00167";

	public static final String VENDOR_COMMON_VALIDATION_CODE_I50031 = "|I50031";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00235 = "|E00235";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00571 = "|E00571";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00572 = "|E00572";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00578 = "|E00578";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00577 = "|E00577";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00576 = "|E00576";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00575 = "|E00575";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00579 = "|E00579";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00580 = "|E00580";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00581 = "|E00581";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00146 = "|E00146";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00583 = "|E00583";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00582 = "|E00582";

	public static final String VENDOR_COMMON_VALIDATION_CODE_I50040 = "|I50040";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00587 = "|E00587";

	public static final String EINVOICE_ERROR_CODE_E00036 = "|E00036";

	public static final String EINVOICE_ERROR_CODE_E00589 = "|E00589";

	public static final String EINVOICE_ERROR_CODE_I50031 = "|I50031";

	public static final String EINVOICE_ERROR_CODE_E00528 = "|E00528";

	public static final String VENDOR_COMMON_VALIDATION_CODE_E00595 = "|E00595";



		


}
