package com.bdo.bvms.common.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class JsonToObjDTO {

	private List<String> gstinOrPanList;
    private String fileType;
    private String po;
    private String templateType;
    private String panOrGstn;
    private String year;
    private List<String> month;
    private String poDate;
}
