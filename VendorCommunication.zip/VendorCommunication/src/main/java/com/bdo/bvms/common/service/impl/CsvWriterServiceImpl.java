package com.bdo.bvms.common.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.service.CsvWriterService;
import com.bdo.bvms.common.util.CommonUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CsvWriterServiceImpl implements CsvWriterService {

    @Value("${bvms.cloud.temp.file.download.path}")
    String tempFolder;

    @Override
    public void writeSuccessNErrorDataInCSVFile(UploadReqDTO uploadRequestDTO,
                    List<InwardInvoiceCDNTemplateDTO> rowCRNSuccessPoJoList,
                    List<InwardInvoiceCDNTemplateDTO> rowINVSuccessPoJoList,
                    List<InwardInvoiceCDNTemplateDTO> rowErrorPoJoList,
                    List<InwardInvoiceCDNTemplateDTO> rowErrorCdnPojoList)
                    throws IOException, VendorInvoiceServerException {

        String methodName = "";
        String csvInvSuccessFilePath = CommonUtils.getINVSuccessFilePath(uploadRequestDTO, tempFolder);
        String csvCdnSuccessFilePath = CommonUtils.getCDNSuccessFilePath(uploadRequestDTO, tempFolder);
        String csvInvErrorFilePath = CommonUtils.getInvErrorFilePath(uploadRequestDTO, tempFolder);
        String csvCdnErrorFilePath = CommonUtils.getCdnErrorFilePath(uploadRequestDTO, tempFolder);
        InputStream validINVStream = null;

       
        // Method for CSV writing
        validINVStream = excelDataToCSVINVSuccess(uploadRequestDTO, rowINVSuccessPoJoList);
        Files.copy(validINVStream, Paths.get(csvInvSuccessFilePath));

        InputStream validCDNStream = null;
        validCDNStream = excelDataToCSVCDNSuccess(uploadRequestDTO, rowCRNSuccessPoJoList);
        Files.copy(validCDNStream, Paths.get(csvCdnSuccessFilePath));

        InputStream nonValidInvErrorStream = null;
        nonValidInvErrorStream = excelDataToCSVInvError(uploadRequestDTO, rowErrorPoJoList);
        Files.copy(nonValidInvErrorStream, Paths.get(csvInvErrorFilePath));

        InputStream nonValidCdnErrorStream = null;
        nonValidCdnErrorStream = excelDataToCSVCdnError(uploadRequestDTO, rowErrorCdnPojoList);
        Files.copy(nonValidCdnErrorStream, Paths.get(csvCdnErrorFilePath));

        log.info(Constants.LOGMESSAGE, methodName);
    }

    private InputStream excelDataToCSVCdnError(UploadReqDTO uploadRequestDTO,
                    List<InwardInvoiceCDNTemplateDTO> rowErrorPoJoList) throws VendorInvoiceServerException {
        String methodName = "";
        log.info(Constants.LOGMESSAGE, methodName);

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<Object> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {
            list = Stream.of(Constants.ID, Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT,

                            Constants.COLUMN_DOC_TYPE, Constants.COLUMN_DOC_NO, Constants.COLUMN_DOC_DATE,
                            Constants.COLUMN_ORG_INVOICE_NO, Constants.COLUMN_ORG_INVOICE_DATE,
                            Constants.COLUMN_GSTIN_OF_SUPPLIER,

                            Constants.COLUMN_SUPPLIER_STATE_CODE,

                            Constants.COLUMN_SUPPLIER_NAME, Constants.COLUMN_INWARD_NO, Constants.COLUMN_INWARD_DATE,
                            Constants.COLUMN_INVOICE_CATEGORY, Constants.COLUMN_SUPPLY_TYPE,
                            Constants.COLUMN_INVOICE_TYPE, Constants.COLUMN_ITEM_NAME,

                            Constants.COLUMN_HSN_SAC_CODE, Constants.COLUMN_UOM, Constants.COLUMN_QUINTITY,
                            Constants.COLUMN_ITEM_RATE, Constants.COLUMN_TAXABLE_AMOUNT, Constants.COLUMN_SGST_RATE,
                            Constants.COLUMN_SGST_AMOUNT, Constants.COLUMN_CGST_RATE, Constants.COLUMN_CGST_AMOUNT,
                            Constants.COLUMN_IGST_RATE, Constants.COLUMN_IGST_AMOUNT, Constants.COLUMN_CESS_RATE,
                            Constants.COLUMN_CESS_AMOUNT, Constants.COLUMN_DIFF_PERCENT, Constants.TOTAL_TAX_AMOUNT,
                            Constants.GROSS_TOTAL_AMOUNT, Constants.COLUMN_TOTAL_INVOICE_AMOUNT,

                            Constants.COLUMN_PLACE_OF_SUPPLY, Constants.COLUMN_REVERSE_CHARGE, Constants.IMPORT_TYPE,
                            Constants.PORT_CD, Constants.COLUMN_IMPORT_BILL_OF_ENTRY_NO,
                            Constants.COLUMN_IMPORT_BILL_OF_ENTRY_DATE, Constants.COLUMN_IMPORT_BILL_OF_ENTRY_AMT,
                            Constants.REASON, Constants.PRE_GST, Constants.DELETE_TRANS_ID, Constants.USER_ID,
                            Constants.FP_CONS,

                            Constants.BATCHNO,

                            Constants.ITC_ELIGIBLE, Constants.ITC_SGST_AMT, Constants.ITC_CGST_AMT,
                            Constants.ITC_IGST_AMT, Constants.ITC_CESS_AMT, Constants.TOTAL_ITC_AMT,
                            Constants.IS_AMENDMENT, Constants.IS_INVOICE, Constants.COLUMN_DEBIT_GL_ID,
                            Constants.COLUMN_DEBIT_GL_NAME, Constants.COLUMN_CREDIT_GL_ID,
                            Constants.COLUMN_CREDIT_GL_NAME, Constants.ERROR_DESCRIPTION, Constants.ROWVERSION,
                            Constants.DATE_OF_PAYMENT, Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_INDICATOR,
                            Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_PERCENTAGE, Constants.IRN,
                            Constants.COLUMN_ACK_DATE, Constants.COLUMN_ACK_NO, Constants.COLUMN_SUB_LOCATION,
                            Constants.EXCEL_ROW_ID, Constants.COLUMN_PAN_RECIPIENT, Constants.COLUMN_PAN_OF_SUPPLIER,
                            Constants.YEARID, Constants.ERROR_CODES, Constants.ORG_DOC_TYPE,
                            Constants.ORG_SUPPLY_TYPE, Constants.ORG_INPUT_TYPE,Constants.COLUMN_NIL_RATED_AMT,Constants.EXEMPTED_AMT,
                            Constants.NON_GST_AMT,Constants.COLUMN_COMPOSITION_AMT,
                            Constants.PAYMENT_AMOUNT,Constants.PAYMENT_REF_NO,Constants.TDS_SECTION,Constants.TDS_RATE,
                            Constants.TDS_TAX_AMOUNT,Constants.CHALLAN_NUMBER,Constants.CHALLAN_DATE,Constants.CHALLAN_AMOUNT,
                            Constants.PERIOD_OF_FILLING,Constants.INVOICE_AGAINST_PROV_ADV,Constants.INWARD_NO_PROV_ADV,
                            Constants.INWARD_DATE_PROV_ADV,Constants.AMOUNT_OF_PROV_ADV,Constants.BAL_OUTSTANDING,Constants.UUID,
                            Constants.COLUMN_UDF_1, Constants.COLUMN_UDF_2, Constants.COLUMN_UDF_3,
                            Constants.COLUMN_UDF_4, Constants.COLUMN_UDF_5, Constants.COLUMN_UDF_6,
                            Constants.COLUMN_UDF_7, Constants.COLUMN_UDF_8, Constants.COLUMN_UDF_9,

                            Constants.COLUMN_UDF_10,
                            Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13,
                            Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16,
                            Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19,

                            Constants.COLUMN_UDF_20).collect(Collectors.toList());

            csvPrinter.printRecord(list);

            if (!rowErrorPoJoList.isEmpty()) {
                for (InwardInvoiceCDNTemplateDTO inwardInvoiceCDNTemplateDTO : rowErrorPoJoList) {
                    List<Object> data = Arrays.asList(Constants.BLANK,
                                    inwardInvoiceCDNTemplateDTO.getGstinOfRecipient(),

                                    inwardInvoiceCDNTemplateDTO.getDocType(), inwardInvoiceCDNTemplateDTO.getDocNo(),
                                    inwardInvoiceCDNTemplateDTO.getDocDate(),
                                    inwardInvoiceCDNTemplateDTO.getOrgInvoiceNo(),
                                                                 inwardInvoiceCDNTemplateDTO.getOrgInvoiceDate(),
                                    inwardInvoiceCDNTemplateDTO.getGstinOfSupplier(),

                                    inwardInvoiceCDNTemplateDTO.getSupplierStateCode(),

                                    inwardInvoiceCDNTemplateDTO.getSupplierName(),
                                    inwardInvoiceCDNTemplateDTO.getInwardNo(),
                                    inwardInvoiceCDNTemplateDTO.getInwardDate(),
                                    inwardInvoiceCDNTemplateDTO.getInvoiceCategory(),
                                    inwardInvoiceCDNTemplateDTO.getSupplyType(),
                                    inwardInvoiceCDNTemplateDTO.getInvoiceType(),
                                    inwardInvoiceCDNTemplateDTO.getItemName(),

                                    inwardInvoiceCDNTemplateDTO.getHsnSacCode(), inwardInvoiceCDNTemplateDTO.getUom(),
                                    inwardInvoiceCDNTemplateDTO.getOrgQuantity(),
                                    inwardInvoiceCDNTemplateDTO.getItemRate(),
                                    inwardInvoiceCDNTemplateDTO.getTaxableAmount(),
                                    inwardInvoiceCDNTemplateDTO.getSgstRate(), inwardInvoiceCDNTemplateDTO.getSgstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getCgstRate(), inwardInvoiceCDNTemplateDTO.getCgstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getIgstRate(), inwardInvoiceCDNTemplateDTO.getIgstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getCessRate(),
                                    inwardInvoiceCDNTemplateDTO.getCessAmount(),
                                    inwardInvoiceCDNTemplateDTO.getDiffPercent(),
                                    inwardInvoiceCDNTemplateDTO.getTotalTaxAmount(),
                                    inwardInvoiceCDNTemplateDTO.getGrossTotalAmount(),
                                    inwardInvoiceCDNTemplateDTO.getOrgTotalInvAmt(),

                                    inwardInvoiceCDNTemplateDTO.getPlaceOfSupply(),
                                    inwardInvoiceCDNTemplateDTO.getReverseCharge(),
                                    inwardInvoiceCDNTemplateDTO.getImportType(), inwardInvoiceCDNTemplateDTO.getPort(),
                                    inwardInvoiceCDNTemplateDTO.getImportBillOfEntryNo(),
                                    inwardInvoiceCDNTemplateDTO.getImportBillOfEntryDate(),
                                    inwardInvoiceCDNTemplateDTO.getImportBillOfEntryAmt(),
                                    inwardInvoiceCDNTemplateDTO.getReason(), inwardInvoiceCDNTemplateDTO.getPreGst(),
                                    Constants.BLANK, uploadRequestDTO.getUserId(),
                                    inwardInvoiceCDNTemplateDTO.getFillingPeriod(),

                                    uploadRequestDTO.getBatchNo(),

                                    inwardInvoiceCDNTemplateDTO.getItcEligible(),
                                    inwardInvoiceCDNTemplateDTO.getItcSgstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getItcCgstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getItcIgstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getItcCessAmt(),
                                    inwardInvoiceCDNTemplateDTO.getTotalItcAmt(), Constants.BLANK, Constants.BLANK,
                                    inwardInvoiceCDNTemplateDTO.getDebitGlId(),
                                    inwardInvoiceCDNTemplateDTO.getDebitGlName(),
                                    inwardInvoiceCDNTemplateDTO.getCreditGlId(),
                                    inwardInvoiceCDNTemplateDTO.getCreditGlName(),
                                    inwardInvoiceCDNTemplateDTO.getErrorDescriptionList(),
                                    Timestamp.from(Instant.now()), inwardInvoiceCDNTemplateDTO.getDateOfPayment(),
                                    inwardInvoiceCDNTemplateDTO.getItcIneligibleReversalIndicator(),
                                    inwardInvoiceCDNTemplateDTO.getItcIneligibleReversalPercentage(),
                                    inwardInvoiceCDNTemplateDTO.getIrn(), inwardInvoiceCDNTemplateDTO.getAckDate(),
                                    inwardInvoiceCDNTemplateDTO.getAckNo(),
                                    inwardInvoiceCDNTemplateDTO.getSubLocation(),
                                    inwardInvoiceCDNTemplateDTO.getExcelRowId(),
                                    inwardInvoiceCDNTemplateDTO.getPanOfReciepiet(),
                                    inwardInvoiceCDNTemplateDTO.getPanOfSupplier(),
                                    inwardInvoiceCDNTemplateDTO.getYearId(),
                                    inwardInvoiceCDNTemplateDTO.getErrorCodeList().toString(),
                                    inwardInvoiceCDNTemplateDTO.getExcelDocType(),
                                    inwardInvoiceCDNTemplateDTO.getOrgSupplyType(),
                                    inwardInvoiceCDNTemplateDTO.getOrgInputType(),inwardInvoiceCDNTemplateDTO.getNilRatedAmt(),
                                    inwardInvoiceCDNTemplateDTO.getExemptedAmt(),inwardInvoiceCDNTemplateDTO.getNonGstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getCompositionAmt(),
                                    inwardInvoiceCDNTemplateDTO.getOrgPaymentAmount(),inwardInvoiceCDNTemplateDTO.getPaymentRefNo(),
                                    inwardInvoiceCDNTemplateDTO.getTdsSection(),inwardInvoiceCDNTemplateDTO.getTdsRate(),inwardInvoiceCDNTemplateDTO.getOrgTdsTaxAmount(),inwardInvoiceCDNTemplateDTO.getChallanNumber(),
                                    inwardInvoiceCDNTemplateDTO.getChallanDate(),inwardInvoiceCDNTemplateDTO.getOrgChallanAmount(),inwardInvoiceCDNTemplateDTO.getPeriodOfFiling(),inwardInvoiceCDNTemplateDTO.getInvoiceAgainstProvAdv(),
                                    inwardInvoiceCDNTemplateDTO.getInwardNoProvAdv(),inwardInvoiceCDNTemplateDTO.getInwardDateProvAdv(),inwardInvoiceCDNTemplateDTO.getOrgAmountOfProvAdv(),inwardInvoiceCDNTemplateDTO.getBalOutstanding(),
                                    (inwardInvoiceCDNTemplateDTO.getGstinOfRecipient()+inwardInvoiceCDNTemplateDTO.getGstinOfSupplier()+inwardInvoiceCDNTemplateDTO.getFillingPeriod()+inwardInvoiceCDNTemplateDTO.getInwardNo()).hashCode(),
                                    inwardInvoiceCDNTemplateDTO.getUdf1(),
                                    inwardInvoiceCDNTemplateDTO.getUdf2(), inwardInvoiceCDNTemplateDTO.getUdf3(),
                                    inwardInvoiceCDNTemplateDTO.getUdf4(), inwardInvoiceCDNTemplateDTO.getUdf5(),
                                    inwardInvoiceCDNTemplateDTO.getUdf6(), inwardInvoiceCDNTemplateDTO.getUdf7(),
                                    inwardInvoiceCDNTemplateDTO.getUdf8(), inwardInvoiceCDNTemplateDTO.getUdf9(),
                                    inwardInvoiceCDNTemplateDTO.getUdf10(),
                                    inwardInvoiceCDNTemplateDTO.getUdf11(), inwardInvoiceCDNTemplateDTO.getUdf12(), inwardInvoiceCDNTemplateDTO.getUdf13(),
                                    inwardInvoiceCDNTemplateDTO.getUdf14(), inwardInvoiceCDNTemplateDTO.getUdf15(), inwardInvoiceCDNTemplateDTO.getUdf16(), inwardInvoiceCDNTemplateDTO.getUdf17(),
                                    inwardInvoiceCDNTemplateDTO.getUdf18(), inwardInvoiceCDNTemplateDTO.getUdf19(), inwardInvoiceCDNTemplateDTO.getUdf20());

                    csvPrinter.printRecord(data);
                    log.info(Constants.LOGMESSAGE, methodName);
                }
            }
            csvPrinter.flush();
            log.info(Constants.LOGMESSAGE, methodName);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error(Constants.LOGERRORMESSAGE, methodName);
            throw new VendorInvoiceServerException("fail to import data to CSV file: " + e.getMessage());
        }
    }

    private InputStream excelDataToCSVCDNSuccess(UploadReqDTO uploadRequestDTO,
                    List<InwardInvoiceCDNTemplateDTO> rowINVSuccessPoJoList) throws VendorInvoiceServerException {
        String methodName = "excelDataToCSVCDNSuccess";
        log.info(Constants.LOGMESSAGE, methodName);

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<Object> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {
            list = Stream.of(Constants.ID, Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT, Constants.COLUMN_DOC_TYPE,
                            Constants.ORG_DOC_TYPE, Constants.COLUMN_GSTIN_OF_SUPPLIER, Constants.COLUMN_SUPPLIER_NAME,
                            Constants.COLUMN_DOC_NO, Constants.COLUMN_DOC_DATE, Constants.COLUMN_INWARD_NO,
                            Constants.COLUMN_INWARD_DATE, Constants.COLUMN_ORG_INVOICE_NO,
                            Constants.COLUMN_ORG_INVOICE_DATE, Constants.COLUMN_SUPPLIER_STATE_CODE,
                            Constants.COLUMN_INVOICE_CATEGORY, Constants.COLUMN_SUPPLY_TYPE,
                            Constants.COLUMN_INVOICE_TYPE, Constants.COLUMN_ITEM_NAME, Constants.COLUMN_HSN_SAC_CODE,
                            Constants.COLUMN_UOM, Constants.COLUMN_QUINTITY, Constants.COLUMN_ITEM_RATE,
                            Constants.COLUMN_TAXABLE_AMOUNT, Constants.COLUMN_SGST_RATE, Constants.COLUMN_SGST_AMOUNT,
                            Constants.COLUMN_CGST_RATE, Constants.COLUMN_CGST_AMOUNT, Constants.COLUMN_IGST_RATE,
                            Constants.COLUMN_IGST_AMOUNT, Constants.COLUMN_CESS_RATE, Constants.COLUMN_CESS_AMOUNT,
                            Constants.COLUMN_DIFF_PERCENT, Constants.TOTAL_TAX_AMOUNT, Constants.GROSS_TOTAL_AMOUNT,
                            Constants.COLUMN_TOTAL_INVOICE_AMOUNT, Constants.ITC_ELIGIBLE, Constants.ITC_SGST_AMT,
                            Constants.ITC_CGST_AMT, Constants.ITC_IGST_AMT, Constants.ITC_CESS_AMT,
                            Constants.TOTAL_ITC_AMT, Constants.COLUMN_PLACE_OF_SUPPLY, Constants.COLUMN_REVERSE_CHARGE,
                            Constants.IMPORT_TYPE, Constants.PORT_CD, Constants.COLUMN_IMPORT_BILL_OF_ENTRY_NO,
                            Constants.COLUMN_IMPORT_BILL_OF_ENTRY_DATE, Constants.COLUMN_IMPORT_BILL_OF_ENTRY_AMT,
                            Constants.REASON, Constants.PRE_GST, Constants.FP_CONS, Constants.USER_ID,
                            Constants.BATCHNO, Constants.IS_AMENDMENT, Constants.IS_INVOICE,
                            Constants.COLUMN_DEBIT_GL_ID, Constants.COLUMN_DEBIT_GL_NAME, Constants.COLUMN_CREDIT_GL_ID,
                            Constants.COLUMN_CREDIT_GL_NAME, Constants.ROWVERSION, Constants.DATE_OF_PAYMENT,
                            Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_INDICATOR,
                            Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_PERCENTAGE, Constants.IRN,
                            Constants.COLUMN_ACK_DATE, Constants.COLUMN_ACK_NO, Constants.COLUMN_SUB_LOCATION,
                            Constants.EXCEL_ROW_ID, Constants.COLUMN_PAN_RECIPIENT, Constants.COLUMN_PAN_OF_SUPPLIER,
                            Constants.TABLE_NO, Constants.TRAN_STATUS, Constants.YEARID,
                            Constants.ORG_SUPPLY_TYPE,Constants.COLUMN_NIL_RATED_AMT,Constants.EXEMPTED_AMT,
                            Constants.NON_GST_AMT,Constants.COLUMN_COMPOSITION_AMT,Constants.ORG_INPUT_TYPE,
                            Constants.PAYMENT_AMOUNT,Constants.PAYMENT_REF_NO,Constants.TDS_SECTION,Constants.TDS_RATE,
                            Constants.TDS_TAX_AMOUNT,Constants.CHALLAN_NUMBER,Constants.CHALLAN_DATE,Constants.CHALLAN_AMOUNT,
                            Constants.PERIOD_OF_FILLING,Constants.INVOICE_AGAINST_PROV_ADV,Constants.INWARD_NO_PROV_ADV,
                            Constants.INWARD_DATE_PROV_ADV,Constants.AMOUNT_OF_PROV_ADV,Constants.BAL_OUTSTANDING,Constants.UUID,
                            Constants.COLUMN_UDF_1,
                            Constants.COLUMN_UDF_2, Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4,
                            Constants.COLUMN_UDF_5, Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7,
                            Constants.COLUMN_UDF_8, Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10,
                            Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13,
                            Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16,
                            Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19,

                            Constants.COLUMN_UDF_20).collect(Collectors.toList());

            csvPrinter.printRecord(list);

            if (!rowINVSuccessPoJoList.isEmpty()) {

                for (InwardInvoiceCDNTemplateDTO rowdata : rowINVSuccessPoJoList) {

                    if (" ".equals(rowdata.getItcEligible()) || "".equals(rowdata.getItcEligible())) {
                        rowdata.setItcEligible("Eligible");
                    } else if (("Inputs".equalsIgnoreCase(rowdata.getImportType()))
                                    || "IN".equalsIgnoreCase(rowdata.getImportType())) {
                        rowdata.setItcEligible("Eligible");
                    } else if ("Input Services".equalsIgnoreCase(rowdata.getImportType())
                                    || "INS".equalsIgnoreCase(rowdata.getImportType())) {
                        rowdata.setItcEligible("Eligible");
                    } else if ("Capital Goods".equalsIgnoreCase(rowdata.getImportType())
                                    || "CG".equalsIgnoreCase(rowdata.getImportType())) {
                        rowdata.setItcEligible("Eligible");
                    }
                    if ("REV-42&43".equalsIgnoreCase(rowdata.getItcIneligibleReversalIndicator())
                                    || "REV-OTH".equalsIgnoreCase(rowdata.getItcIneligibleReversalIndicator())) {
                        rowdata.setItcEligible("reversal");
                    }
                    if ("INELG-17(5)".equalsIgnoreCase(rowdata.getItcIneligibleReversalIndicator())
                                    || "INELG-OTH".equalsIgnoreCase(rowdata.getItcIneligibleReversalIndicator())) {
                        rowdata.setItcEligible("ineligible");

                    }

                    List<Object> data = Arrays.asList(Constants.BLANK, rowdata.getGstinOfRecipient(),
                                    rowdata.getDocType(), rowdata.getExcelDocType(), rowdata.getGstinOfSupplier(),
                                    rowdata.getSupplierName(), rowdata.getDocNo(), rowdata.getDocDate(),
                                    rowdata.getInwardNo(), rowdata.getInwardDate(), rowdata.getOrgInvoiceNo(),
                                    rowdata.getOrgInvoiceDate(), rowdata.getSupplierStateCode(),
                                    rowdata.getInvoiceCategory(), rowdata.getSupplyType(), rowdata.getInvoiceType(),
                                    rowdata.getItemName(), rowdata.getHsnSacCode(), rowdata.getUom(),
                                    rowdata.getQuantity(), rowdata.getItemRate(), rowdata.getTaxableAmount(),
                                    rowdata.getSgstRate(), rowdata.getSgstAmt(), rowdata.getCgstRate(),
                                    rowdata.getCgstAmt(), rowdata.getIgstRate(), rowdata.getIgstAmt(),
                                    rowdata.getCessRate(), rowdata.getCessAmount(), rowdata.getDiffPercent(),
                                    rowdata.getTotalTaxAmount(), rowdata.getGrossTotalAmount(),
                                    rowdata.getTotalInvoiceAmt(), rowdata.getItcEligible(), rowdata.getItcSgstAmt(),
                                    rowdata.getItcCgstAmt(), rowdata.getItcIgstAmt(), rowdata.getItcCessAmt(),
                                    rowdata.getTotalItcAmt(), rowdata.getPlaceOfSupply(), rowdata.getReverseCharge(),
                                    rowdata.getImportType(), rowdata.getPort(), rowdata.getImportBillOfEntryNo(),
                                    rowdata.getImportBillOfEntryDate(), rowdata.getImportBillOfEntryAmt(),
                                    rowdata.getReason(), rowdata.getPreGst(), rowdata.getFillingPeriod(),
                                    uploadRequestDTO.getUserId(), uploadRequestDTO.getBatchNo(), Constants.BLANK,
                                    Constants.BLANK, rowdata.getDebitGlId(), rowdata.getDebitGlName(),
                                    rowdata.getCreditGlId(), rowdata.getCreditGlName(), Timestamp.from(Instant.now()),
                                    rowdata.getDateOfPayment(), rowdata.getItcIneligibleReversalIndicator(),
                                    rowdata.getItcIneligibleReversalPercentage(), rowdata.getIrn(),
                                    rowdata.getAckDate(), rowdata.getAckNo(), rowdata.getSubLocation(),
                                    rowdata.getExcelRowId(), rowdata.getPanOfReciepiet(), rowdata.getPanOfSupplier(),
                                    rowdata.getTableNo(), Constants.ZEROVALUE, rowdata.getYearId(),rowdata.getOrgSupplyType(),rowdata.getNilRatedAmt(),rowdata.getExemptedAmt(),
                                    rowdata.getNonGstAmt(),
                                    rowdata.getCompositionAmt(),rowdata.getOrgInputType(),rowdata.getPaymentAmount(),rowdata.getPaymentRefNo(),
                                    rowdata.getTdsSection(),rowdata.getTdsRate(),rowdata.getTdsTaxAmount(),rowdata.getChallanNumber(),
                                    rowdata.getChallanDate(),rowdata.getChallanAmount(),rowdata.getPeriodOfFiling(),rowdata.getInvoiceAgainstProvAdv(),
                                    rowdata.getInwardNoProvAdv(),rowdata.getInwardDateProvAdv(),rowdata.getAmountOfProvAdv(),rowdata.getBalOutstanding(),
                                    (rowdata.getGstinOfRecipient()+rowdata.getGstinOfSupplier()+rowdata.getFillingPeriod()+rowdata.getInwardNo()).hashCode(), rowdata.getUdf1(),
                                    rowdata.getUdf2(), rowdata.getUdf3(), rowdata.getUdf4(), rowdata.getUdf5(),
                                    rowdata.getUdf6(), rowdata.getUdf7(), rowdata.getUdf8(), rowdata.getUdf9(),

                                    rowdata.getUdf10(),
                                    rowdata.getUdf11(), rowdata.getUdf12(), rowdata.getUdf13(),
                                    rowdata.getUdf14(), rowdata.getUdf15(), rowdata.getUdf16(), rowdata.getUdf17(),
                                    rowdata.getUdf18(), rowdata.getUdf19(), rowdata.getUdf20());
                    csvPrinter.printRecord(data);
                    log.info(Constants.LOGMESSAGE, methodName);
                }
            }
            csvPrinter.flush();
            log.info(Constants.LOGMESSAGE, methodName);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error(Constants.LOGERRORMESSAGE, methodName);
            throw new VendorInvoiceServerException("fail to import data to CSV file: " + e.getMessage());
        }
    }

    private InputStream excelDataToCSVINVSuccess(UploadReqDTO uploadRequestDTO,
                    List<InwardInvoiceCDNTemplateDTO> rowCRNSuccessPoJoList)
                    throws IOException, VendorInvoiceServerException {

        String methodName = "";
        log.info(Constants.LOGERRORMESSAGE, methodName);

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<Object> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {

            list = Stream.of(Constants.ID, Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT, Constants.COLUMN_PAN_RECIPIENT,
                            Constants.COLUMN_DOC_TYPE, Constants.ORG_DOC_TYPE, Constants.COLUMN_GSTIN_OF_SUPPLIER,
                            Constants.COLUMN_PAN_OF_SUPPLIER, Constants.COLUMN_SUPPLIER_NAME, Constants.COLUMN_DOC_NO,
                            Constants.COLUMN_DOC_DATE, Constants.COLUMN_INWARD_NO, Constants.COLUMN_INWARD_DATE,
                            Constants.COLUMN_SUPPLIER_STATE_CODE, Constants.COLUMN_INVOICE_CATEGORY,
                            Constants.COLUMN_SUPPLY_TYPE, Constants.COLUMN_INVOICE_TYPE, Constants.COLUMN_ITEM_NAME,
                            Constants.COLUMN_HSN_SAC_CODE, Constants.COLUMN_UOM, Constants.COLUMN_QUINTITY,
                            Constants.COLUMN_ITEM_RATE, Constants.COLUMN_TAXABLE_AMOUNT, Constants.COLUMN_SGST_RATE,
                            Constants.COLUMN_SGST_AMOUNT, Constants.COLUMN_CGST_RATE, Constants.COLUMN_CGST_AMOUNT,
                            Constants.COLUMN_IGST_RATE, Constants.COLUMN_IGST_AMOUNT, Constants.COLUMN_CESS_RATE,
                            Constants.COLUMN_CESS_AMOUNT, Constants.COLUMN_DIFF_PERCENT, Constants.TOTAL_TAX_AMOUNT,
                            Constants.GROSS_TOTAL_AMOUNT, Constants.COLUMN_TOTAL_INVOICE_AMOUNT, Constants.ITC_ELIGIBLE,
                            Constants.ITC_SGST_AMT, Constants.ITC_CGST_AMT, Constants.ITC_IGST_AMT,
                            Constants.ITC_CESS_AMT, Constants.TOTAL_ITC_AMT, Constants.COLUMN_PLACE_OF_SUPPLY,
                            Constants.COLUMN_REVERSE_CHARGE, Constants.IMPORT_TYPE, Constants.PORT_CD,
                            Constants.COLUMN_IMPORT_BILL_OF_ENTRY_NO, Constants.COLUMN_IMPORT_BILL_OF_ENTRY_DATE,
                            Constants.COLUMN_IMPORT_BILL_OF_ENTRY_AMT, Constants.DATE_OF_PAYMENT, Constants.FP_CONS,
                            Constants.TRAN_STATUS, Constants.USER_ID, Constants.BATCHNO, Constants.TABLE_NO,
                            Constants.COLUMN_DEBIT_GL_ID, Constants.COLUMN_DEBIT_GL_NAME, Constants.COLUMN_CREDIT_GL_ID,
                            Constants.COLUMN_CREDIT_GL_NAME, Constants.ROWVERSION, Constants.IS_REMOVED,
                            Constants.REMOVED_BY, Constants.UPDATED_AT,
                            Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_INDICATOR,
                            Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_PERCENTAGE, Constants.IRN,
                            Constants.COLUMN_ACK_DATE, Constants.COLUMN_ACK_NO, Constants.COLUMN_SUB_LOCATION,
                            Constants.YEARID, Constants.ORG_SUPPLY_TYPE,Constants.COLUMN_NIL_RATED_AMT,Constants.EXEMPTED_AMT,
                            Constants.NON_GST_AMT,Constants.COLUMN_COMPOSITION_AMT,Constants.ORG_INPUT_TYPE,
                            Constants.PAYMENT_AMOUNT,Constants.PAYMENT_REF_NO,Constants.TDS_SECTION,Constants.TDS_RATE,
                            Constants.TDS_TAX_AMOUNT,Constants.CHALLAN_NUMBER,Constants.CHALLAN_DATE,Constants.CHALLAN_AMOUNT,
                            Constants.PERIOD_OF_FILLING,Constants.INVOICE_AGAINST_PROV_ADV,Constants.INWARD_NO_PROV_ADV,
                            Constants.INWARD_DATE_PROV_ADV,Constants.AMOUNT_OF_PROV_ADV,Constants.BAL_OUTSTANDING,Constants.UUID,
                            Constants.COLUMN_UDF_1, Constants.COLUMN_UDF_2, Constants.COLUMN_UDF_3,
                            Constants.COLUMN_UDF_4, Constants.COLUMN_UDF_5, Constants.COLUMN_UDF_6,
                            Constants.COLUMN_UDF_7, Constants.COLUMN_UDF_8, Constants.COLUMN_UDF_9,

                            Constants.COLUMN_UDF_10,
                            Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13,
                            Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16,
                            Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19,

                            Constants.COLUMN_UDF_20
                            ).collect(Collectors.toList());

            csvPrinter.printRecord(list);

            if (!rowCRNSuccessPoJoList.isEmpty()) {

                for (InwardInvoiceCDNTemplateDTO template : rowCRNSuccessPoJoList) {
                    if ("REV-42&43".equalsIgnoreCase(template.getItcIneligibleReversalIndicator())
                                    || "REV-OTH".equalsIgnoreCase(template.getItcIneligibleReversalIndicator())) {
                        if (StringUtils.isBlank(template.getItcIneligibleReversalPercentage())) {
                            template.setItcIneligibleReversalPercentage("0");
                        }
                    } else if (StringUtils.isBlank(template.getItcIneligibleReversalPercentage())) {
                        template.setItcIneligibleReversalPercentage("100");
                    }
                    String itcEligible = template.getItcEligible();
                    if (itcEligible.equalsIgnoreCase("Eligible")
                                    && template.getImportType().equalsIgnoreCase("Inputs")) {
                        template.setItcEligible("01");
                    } else if (itcEligible.equalsIgnoreCase("Eligible")
                                    && template.getImportType().equalsIgnoreCase("Input Services")) {
                        template.setItcEligible("02");
                    } else if (itcEligible.equalsIgnoreCase("Eligible")
                                    && template.getImportType().equalsIgnoreCase("Capital Goods")) {
                        template.setItcEligible("03");
                    } else if (itcEligible.equalsIgnoreCase("ineligible")) {
                        template.setItcEligible("04");
                    } else if (itcEligible.equalsIgnoreCase("reversal")) {
                        template.setItcEligible("05");
                    } else {
                        template.setItcEligible("");
                    }

                    if (StringUtils.isNotBlank(template.getImportBillOfEntryDate()) && (template.getImportBillOfEntryDate().equals("00-01-1900")
                                    || template.getImportBillOfEntryDate().equals("31/12/1899")
                                    || template.getImportBillOfEntryDate().equals("31-12-1899"))) {
                        template.setImportBillOfEntryDate("0");
                    }

                    if ( StringUtils.isNotBlank(template.getDateOfPayment()) && StringUtils.isNotBlank(template.getImportBillOfEntryDate()) && (template.getDateOfPayment().equals("00-01-1900")
                                    || template.getDateOfPayment().equals("31/12/1899")
                                    || template.getDateOfPayment().equals("31-12-1899"))) {
                        template.setDateOfPayment("0");
                    }
                    List<Object> data = Arrays.asList(Constants.BLANK, template.getGstinOfRecipient(),
                                    template.getPanOfReciepiet(), template.getDocType(), template.getExcelDocType(),
                                    template.getGstinOfSupplier(), template.getPanOfSupplier(),
                                    template.getSupplierName(), template.getDocNo(), template.getDocDate(),
                                    template.getInwardNo(), template.getInwardDate(), template.getSupplierStateCode(),
                                    template.getInvoiceCategory(), template.getSupplyType(), template.getInvoiceType(),
                                    template.getItemName(), template.getHsnSacCode(), template.getUom(),
                                    template.getQuantity(), template.getItemRate(), template.getTaxableAmount(),
                                    template.getSgstRate(), template.getSgstAmt(), template.getCgstRate(),
                                    template.getCgstAmt(), template.getIgstRate(), template.getIgstAmt(),
                                    template.getCessRate(), template.getCessAmount(), template.getDiffPercent(),
                                    template.getTotalTaxAmount(), template.getGrossTotalAmount(),
                                    template.getTotalInvoiceAmt(), template.getItcEligible(), template.getItcSgstAmt(),
                                    template.getItcCgstAmt(), template.getItcIgstAmt(), template.getItcCessAmt(),
                                    template.getTotalItcAmt(), template.getPlaceOfSupply(), template.getReverseCharge(),
                                    template.getImportType(), template.getPort(), template.getImportBillOfEntryNo(),
                                    template.getImportBillOfEntryDate(), template.getImportBillOfEntryAmt(),
                                    template.getDateOfPayment(), template.getFillingPeriod(), Constants.ZEROVALUE,
                                    uploadRequestDTO.getUserId(), uploadRequestDTO.getBatchNo(), template.getTableNo(),
                                    template.getDebitGlId(), template.getDebitGlName(), template.getCreditGlId(),
                                    template.getCreditGlName(), Timestamp.from(Instant.now()), Constants.ZEROVALUE,
                                    Constants.ZEROVALUE, Timestamp.from(Instant.now()), template.getItcIneligibleReversalIndicator(),
                                    template.getItcIneligibleReversalPercentage(), template.getIrn(),
                                    template.getAckDate(), template.getAckNo(), template.getSubLocation(),
                                    template.getYearId(),
                                    template.getOrgSupplyType(),template.getNilRatedAmt(),template.getExemptedAmt(),template.getNonGstAmt(),
                                    template.getCompositionAmt(),template.getOrgInputType(),template.getPaymentAmount(),template.getPaymentRefNo(),
                                    template.getTdsSection(),template.getTdsRate(),template.getTdsTaxAmount(),template.getChallanNumber(),
                                    template.getChallanDate(),template.getChallanAmount(),template.getPeriodOfFiling(),template.getInvoiceAgainstProvAdv(),
                                    template.getInwardNoProvAdv(),template.getInwardDateProvAdv(),template.getAmountOfProvAdv(),template.getBalOutstanding(),
                                    (template.getGstinOfRecipient()+template.getGstinOfSupplier()+template.getFillingPeriod()+template.getInwardNo()).hashCode(),
                                    template.getUdf1(), template.getUdf2(), template.getUdf3(),
                                    template.getUdf4(), template.getUdf5(), template.getUdf6(), template.getUdf7(),
                                    template.getUdf8(), template.getUdf9(), template.getUdf10(),
                                    template.getUdf11(), template.getUdf12(), template.getUdf13(),
                                    template.getUdf14(), template.getUdf15(), template.getUdf16(), template.getUdf17(),
                                    template.getUdf18(), template.getUdf19(), template.getUdf20());

                    csvPrinter.printRecord(data);
                    log.info(Constants.LOGMESSAGE, methodName);
                }
            }
            /*
             * 
             * Constants.PAYMENT_AMOUNT,Constants.PAYMENT_REF_NO,Constants.TDS_SECTION,Constants.TDS_RATE,
                            Constants.TDS_TAX_AMOUNT,Constants.CHALLAN_NUMBER,Constants.CHALLAN_DATE,Constants.CHALLAN_AMOUNT,
                            Constants.PERIOD_OF_FILLING,Constants.INVOICE_AGAINST_PROV_ADV,Constants.INWARD_NO_PROV_ADV,
                            Constants.INWARD_DATE_PROV_ADV,Constants.AMOUNT_OF_PROV_ADV,Constants.BAL_OUTSTANDING,
                            Constants.COLUMN_UDF_11,Constants.COLUMN_UDF_12,Constants.COLUMN_UDF_13,Constants.COLUMN_UDF_14,Constants.COLUMN_UDF_15,
                            Constants.COLUMN_UDF_16,Constants.COLUMN_UDF_17,Constants.COLUMN_UDF_18,Constants.COLUMN_UDF_19,Constants.COLUMN_UDF_20
             */
            csvPrinter.flush();
            log.info(Constants.LOGMESSAGE, methodName);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.info(Constants.LOGMESSAGE, methodName);
            throw new VendorInvoiceServerException("fail to import data to CSV file: " + e.getMessage());
        }
    }

    private InputStream excelDataToCSVInvError(UploadReqDTO uploadRequestDTO,
                    List<InwardInvoiceCDNTemplateDTO> rowErrorPoJoList)
                    throws IOException, VendorInvoiceServerException {

        String methodName = "";
        log.info(Constants.LOGMESSAGE, methodName);

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<Object> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {
            list = Stream.of(Constants.ID, Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT, Constants.COLUMN_PAN_RECIPIENT,
                            Constants.COLUMN_DOC_TYPE, Constants.COLUMN_DOC_NO, Constants.COLUMN_DOC_DATE,
                            Constants.COLUMN_INWARD_NO, Constants.COLUMN_INWARD_DATE,
                            Constants.COLUMN_GSTIN_OF_SUPPLIER, Constants.COLUMN_PAN_OF_SUPPLIER,
                            Constants.COLUMN_SUPPLIER_NAME,

                            Constants.COLUMN_SUPPLIER_STATE_CODE,

                            Constants.COLUMN_INVOICE_CATEGORY, Constants.COLUMN_SUPPLY_TYPE,
                            Constants.COLUMN_INVOICE_TYPE, Constants.COLUMN_ITEM_NAME, Constants.COLUMN_ITEM_RATE,

                            Constants.COLUMN_HSN_SAC_CODE, Constants.COLUMN_UOM, Constants.COLUMN_QUINTITY,
                            Constants.COLUMN_TAXABLE_AMOUNT, Constants.COLUMN_SGST_RATE, Constants.COLUMN_SGST_AMOUNT,
                            Constants.COLUMN_CGST_RATE, Constants.COLUMN_CGST_AMOUNT, Constants.COLUMN_IGST_RATE,
                            Constants.COLUMN_IGST_AMOUNT, Constants.COLUMN_CESS_RATE, Constants.COLUMN_CESS_AMOUNT,
                            Constants.COLUMN_DIFF_PERCENT, Constants.TOTAL_TAX_AMOUNT, Constants.GROSS_TOTAL_AMOUNT,
                            Constants.COLUMN_TOTAL_INVOICE_AMOUNT,

                            Constants.COLUMN_NIL_RATED_AMT,

                            Constants.COLUMN_PLACE_OF_SUPPLY, Constants.COLUMN_REVERSE_CHARGE, Constants.IMPORT_TYPE,
                            Constants.PORT_CD, Constants.COLUMN_IMPORT_BILL_OF_ENTRY_NO,
                            Constants.COLUMN_IMPORT_BILL_OF_ENTRY_DATE, Constants.COLUMN_IMPORT_BILL_OF_ENTRY_AMT,
                            Constants.DATE_OF_PAYMENT, Constants.FP_CONS,

                            Constants.TRAN_STATUS, Constants.USER_ID, Constants.BATCHNO, Constants.TABLE_NO,
                            Constants.ITC_ELIGIBLE, Constants.ITC_SGST_AMT, Constants.ITC_CGST_AMT,
                            Constants.ITC_IGST_AMT, Constants.ITC_CESS_AMT, Constants.TOTAL_ITC_AMT,
                            Constants.COLUMN_DEBIT_GL_ID, Constants.COLUMN_DEBIT_GL_NAME, Constants.COLUMN_CREDIT_GL_ID,
                            Constants.COLUMN_CREDIT_GL_NAME, Constants.ERROR_DESCRIPTION, Constants.ROWVERSION,
                            Constants.GSTR3B_STATUS, Constants.IS_REMOVED, Constants.REMOVED_BY, Constants.UPDATED_AT,

                            Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_INDICATOR,
                            Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_PERCENTAGE, Constants.IRN,
                            Constants.COLUMN_ACK_DATE, Constants.COLUMN_ACK_NO, Constants.COLUMN_SUB_LOCATION,
                            Constants.YEARID, Constants.MESSAGE, Constants.ERROR_CODES,
                            Constants.ORG_DOC_TYPE, Constants.ORG_SUPPLY_TYPE,Constants.COLUMN_NIL_RATED_AMT,Constants.EXEMPTED_AMT,
                            Constants.NON_GST_AMT,Constants.COLUMN_COMPOSITION_AMT,Constants.ORG_INPUT_TYPE,
                            Constants.PAYMENT_AMOUNT,Constants.PAYMENT_REF_NO,Constants.TDS_SECTION,Constants.TDS_RATE,
                            Constants.TDS_TAX_AMOUNT,Constants.CHALLAN_NUMBER,Constants.CHALLAN_DATE,Constants.CHALLAN_AMOUNT,
                            Constants.PERIOD_OF_FILLING,Constants.INVOICE_AGAINST_PROV_ADV,Constants.INWARD_NO_PROV_ADV,
                            Constants.INWARD_DATE_PROV_ADV,Constants.AMOUNT_OF_PROV_ADV,Constants.BAL_OUTSTANDING,Constants.UUID,
                            Constants.COLUMN_UDF_1, Constants.COLUMN_UDF_2,
                            Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4, Constants.COLUMN_UDF_5,
                            Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7, Constants.COLUMN_UDF_8,

                            Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10,
                            Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13,
                            Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16,
                            Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19,

                            Constants.COLUMN_UDF_20)

                            .collect(Collectors.toList());
            csvPrinter.printRecord(list);

            if (!rowErrorPoJoList.isEmpty()) {
                for (InwardInvoiceCDNTemplateDTO inwardInvoiceCDNTemplateDTO : rowErrorPoJoList) {
                    List<Object> data = Arrays.asList(Constants.BLANK,
                                    inwardInvoiceCDNTemplateDTO.getGstinOfRecipient(),
                                    inwardInvoiceCDNTemplateDTO.getPanOfReciepiet(),
                                    inwardInvoiceCDNTemplateDTO.getDocType(), inwardInvoiceCDNTemplateDTO.getDocNo(),
                                    inwardInvoiceCDNTemplateDTO.getDocDate(), inwardInvoiceCDNTemplateDTO.getInwardNo(),
                                    inwardInvoiceCDNTemplateDTO.getInwardDate(),
                                    inwardInvoiceCDNTemplateDTO.getGstinOfSupplier(),
                                    inwardInvoiceCDNTemplateDTO.getPanOfSupplier(),
                                    inwardInvoiceCDNTemplateDTO.getSupplierName(),
                                    inwardInvoiceCDNTemplateDTO.getSupplierStateCode(),

                                    inwardInvoiceCDNTemplateDTO.getInvoiceCategory(),
                                    inwardInvoiceCDNTemplateDTO.getSupplyType(),
                                    inwardInvoiceCDNTemplateDTO.getInvoiceType(),
                                    inwardInvoiceCDNTemplateDTO.getItemName(),
                                    inwardInvoiceCDNTemplateDTO.getItemRate(),
                                    inwardInvoiceCDNTemplateDTO.getHsnSacCode(), inwardInvoiceCDNTemplateDTO.getUom(),
                                    inwardInvoiceCDNTemplateDTO.getOrgQuantity(),
                                    inwardInvoiceCDNTemplateDTO.getTaxableAmount(),
                                    inwardInvoiceCDNTemplateDTO.getSgstRate(), inwardInvoiceCDNTemplateDTO.getSgstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getCgstRate(), inwardInvoiceCDNTemplateDTO.getCgstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getIgstRate(), inwardInvoiceCDNTemplateDTO.getIgstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getCessRate(),
                                    inwardInvoiceCDNTemplateDTO.getCessAmount(),
                                    inwardInvoiceCDNTemplateDTO.getDiffPercent(),
                                    inwardInvoiceCDNTemplateDTO.getTotalTaxAmount(),
                                    inwardInvoiceCDNTemplateDTO.getGrossTotalAmount(),
                                    inwardInvoiceCDNTemplateDTO.getOrgTotalInvAmt(),

                                    inwardInvoiceCDNTemplateDTO.getNilRatedAmt(),

                                    inwardInvoiceCDNTemplateDTO.getPlaceOfSupply(),
                                    inwardInvoiceCDNTemplateDTO.getReverseCharge(),
                                    inwardInvoiceCDNTemplateDTO.getImportType(), inwardInvoiceCDNTemplateDTO.getPort(),
                                    inwardInvoiceCDNTemplateDTO.getImportBillOfEntryNo(),
                                    inwardInvoiceCDNTemplateDTO.getImportBillOfEntryDate(),
                                    inwardInvoiceCDNTemplateDTO.getImportBillOfEntryAmt(),
                                    inwardInvoiceCDNTemplateDTO.getDateOfPayment(),
                                    inwardInvoiceCDNTemplateDTO.getFillingPeriod(), Constants.ZEROVALUE,
                                    uploadRequestDTO.getUserId(), uploadRequestDTO.getBatchNo(),
                                    inwardInvoiceCDNTemplateDTO.getTableNo(),
                                    inwardInvoiceCDNTemplateDTO.getItcEligible(),
                                    inwardInvoiceCDNTemplateDTO.getItcSgstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getItcCgstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getItcIgstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getItcCessAmt(),
                                    inwardInvoiceCDNTemplateDTO.getTotalItcAmt(),
                                    inwardInvoiceCDNTemplateDTO.getDebitGlId(),
                                    inwardInvoiceCDNTemplateDTO.getDebitGlName(),
                                    inwardInvoiceCDNTemplateDTO.getCreditGlId(),
                                    inwardInvoiceCDNTemplateDTO.getCreditGlName(),
                                    inwardInvoiceCDNTemplateDTO.getErrorDescriptionList(),
                                    Timestamp.from(Instant.now()), Constants.ZEROVALUE, Constants.ZEROVALUE,
                                    Constants.ZEROVALUE, Timestamp.from(Instant.now()),
                                    inwardInvoiceCDNTemplateDTO.getItcIneligibleReversalIndicator(),
                                    inwardInvoiceCDNTemplateDTO.getItcIneligibleReversalPercentage(),
                                    inwardInvoiceCDNTemplateDTO.getIrn(), inwardInvoiceCDNTemplateDTO.getAckDate(),
                                    inwardInvoiceCDNTemplateDTO.getAckNo(),
                                    inwardInvoiceCDNTemplateDTO.getSubLocation(),
                                    inwardInvoiceCDNTemplateDTO.getYearId(), Constants.BLANK,
                                    inwardInvoiceCDNTemplateDTO.getErrorCodeList().toString(),
                                    inwardInvoiceCDNTemplateDTO.getExcelDocType(),
                                    inwardInvoiceCDNTemplateDTO.getOrgSupplyType(),inwardInvoiceCDNTemplateDTO.getNilRatedAmt(),
                                    inwardInvoiceCDNTemplateDTO.getExemptedAmt(),inwardInvoiceCDNTemplateDTO.getNonGstAmt(),
                                    inwardInvoiceCDNTemplateDTO.getCompositionAmt(),
                                    inwardInvoiceCDNTemplateDTO.getOrgInputType(),
                                    inwardInvoiceCDNTemplateDTO.getOrgPaymentAmount(),inwardInvoiceCDNTemplateDTO.getPaymentRefNo(),
                                    inwardInvoiceCDNTemplateDTO.getTdsSection(),inwardInvoiceCDNTemplateDTO.getTdsRate(),inwardInvoiceCDNTemplateDTO.getOrgTdsTaxAmount(),inwardInvoiceCDNTemplateDTO.getChallanNumber(),
                                    inwardInvoiceCDNTemplateDTO.getChallanDate(),inwardInvoiceCDNTemplateDTO.getOrgChallanAmount(),inwardInvoiceCDNTemplateDTO.getPeriodOfFiling(),inwardInvoiceCDNTemplateDTO.getInvoiceAgainstProvAdv(),
                                    inwardInvoiceCDNTemplateDTO.getInwardNoProvAdv(),inwardInvoiceCDNTemplateDTO.getInwardDateProvAdv(),inwardInvoiceCDNTemplateDTO.getOrgAmountOfProvAdv(),inwardInvoiceCDNTemplateDTO.getBalOutstanding(),
                                    (inwardInvoiceCDNTemplateDTO.getGstinOfRecipient()+inwardInvoiceCDNTemplateDTO.getGstinOfSupplier()+inwardInvoiceCDNTemplateDTO.getFillingPeriod()+inwardInvoiceCDNTemplateDTO.getInwardNo()).hashCode(),
                                    inwardInvoiceCDNTemplateDTO.getUdf1(), inwardInvoiceCDNTemplateDTO.getUdf2(),
                                    inwardInvoiceCDNTemplateDTO.getUdf3(), inwardInvoiceCDNTemplateDTO.getUdf4(),
                                    inwardInvoiceCDNTemplateDTO.getUdf5(), inwardInvoiceCDNTemplateDTO.getUdf6(),
                                    inwardInvoiceCDNTemplateDTO.getUdf7(), inwardInvoiceCDNTemplateDTO.getUdf8(),
                                    inwardInvoiceCDNTemplateDTO.getUdf9(), inwardInvoiceCDNTemplateDTO.getUdf10(),
                                    inwardInvoiceCDNTemplateDTO.getUdf11(), inwardInvoiceCDNTemplateDTO.getUdf12(), inwardInvoiceCDNTemplateDTO.getUdf13(),
                                    inwardInvoiceCDNTemplateDTO.getUdf14(), inwardInvoiceCDNTemplateDTO.getUdf15(), inwardInvoiceCDNTemplateDTO.getUdf16(), inwardInvoiceCDNTemplateDTO.getUdf17(),
                                    inwardInvoiceCDNTemplateDTO.getUdf18(), inwardInvoiceCDNTemplateDTO.getUdf19(), inwardInvoiceCDNTemplateDTO.getUdf20());

                    csvPrinter.printRecord(data);
                    log.info(Constants.LOGMESSAGE, methodName);
                }
            }
            csvPrinter.flush();
            log.info(Constants.LOGMESSAGE, methodName);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error(Constants.LOGERRORMESSAGE, methodName);
            throw new VendorInvoiceServerException("fail to import data to CSV file: " + e.getMessage());
        }
    }

    @Override
    public void writeAzureErrorDataInCSVFile(List<InwardInvoiceCDNTemplateDTO> errorDataListWithErrorCode,
                    UploadReqDTO uploadRequestDTO, Map<String, String> errorCodeMap)
                    throws IOException, VendorInvoiceServerException {
        String csvInvCdnErrorFilePath = CommonUtils.getAzureInvErrorFilePath(uploadRequestDTO, tempFolder);
        InputStream errorCrnInvStream = null;

        String methodName = "";

        errorCrnInvStream = excelAzureDataToCSVCdnInvErrorFor(errorDataListWithErrorCode, errorCodeMap);

        Files.copy(errorCrnInvStream, Paths.get(csvInvCdnErrorFilePath));
        log.info(Constants.LOGERRORMESSAGE, methodName);

    }

    private InputStream excelAzureDataToCSVCdnInvErrorFor(List<InwardInvoiceCDNTemplateDTO> errorDataListWithErrorCode,
                    Map<String, String> errorCodeMap) throws VendorInvoiceServerException {
        String methodName = "";
        log.info(Constants.LOGMESSAGE, methodName);

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<Object> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {
            list = Stream.of(Constants.ERROR_CODES, Constants.ERROR_DESCRIPTION,Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT, Constants.COLUMN_DOC_TYPE, Constants.COLUMN_SUPPLY_TYPE,
                            Constants.COLUMN_DOC_NO, Constants.COLUMN_DOC_DATE,Constants.COLUMN_ORG_INVOICE_NO, Constants.COLUMN_ORG_INVOICE_DATE,
                            Constants.COLUMN_GSTIN_OF_SUPPLIER,Constants.COLUMN_SUPPLIER_NAME,
                            Constants.COLUMN_SUPPLIER_STATE_CODE,
                            Constants.COLUMN_INWARD_NO, Constants.COLUMN_INWARD_DATE,Constants.COLUMN_ITEM_DESCRIPTION,Constants.COLUMN_HSN_CODE,
                            Constants.COLUMN_UOM,Constants.COLUMN_QUINTITY,Constants.COLUMN_ITEM_RATE,
                             Constants.COLUMN_ASS_AMOUNT,
                            Constants.COLUMN_SGST_RATE, Constants.COLUMN_SGST_AMOUNT, Constants.COLUMN_CGST_RATE,
                            Constants.COLUMN_CGST_AMOUNT, Constants.COLUMN_IGST_RATE, Constants.COLUMN_IGST_AMOUNT,
                            Constants.COLUMN_CESS_RATE, Constants.COLUMN_CESS_AMOUNT, Constants.COLUMN_DIFF_PERCENT,
                            Constants.COLUMN_INWARD_GROSS_TOTAL_AMOUNT,Constants.COLUMN_TOTAL_INVOICE_AMOUNT, Constants.COLUMN_INPUT_TYPE,
                            Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_INDICATOR,
                            Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_PERCENTAGE,
                            Constants.COLUMN_PLACE_OF_SUPPLY,
                            Constants.COLUMN_REVERSE_CHARGE, Constants.PORT, Constants.COLUMN_IMPORT_BILL_OF_ENTRY_NO,
                            Constants.COLUMN_IMPORT_BILL_OF_ENTRY_DATE, Constants.COLUMN_IMPORT_BILL_OF_ENTRY_AMT,
                            Constants.DATE_OF_PAYMENT,  Constants.IRN,Constants.COLUMN_ACK_DATE, Constants.COLUMN_ACK_NO,
                            Constants.COLUMN_DEBIT_GL_ID,
                            Constants.COLUMN_DEBIT_GL_NAME,Constants.COLUMN_CREDIT_GL_ID,
                            Constants.COLUMN_CREDIT_GL_NAME,Constants.COLUMN_SUB_LOCATION,Constants.FILLING_PERIOD,
                            Constants.PAYMENT_AMOUNT,Constants.PAYMENT_REF_NO,Constants.TDS_SECTION,Constants.TDS_RATE,
                            Constants.TDS_TAX_AMOUNT,Constants.CHALLAN_NUMBER,Constants.CHALLAN_DATE,Constants.CHALLAN_AMOUNT,
                            Constants.PERIOD_OF_FILLING,Constants.INVOICE_AGAINST_PROV_ADV,Constants.INWARD_NO_PROV_ADV,
                            Constants.INWARD_DATE_PROV_ADV,Constants.AMOUNT_OF_PROV_ADV,Constants.BAL_OUTSTANDING,
                             Constants.COLUMN_UDF_1,
                            Constants.COLUMN_UDF_2, Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4,
                            Constants.COLUMN_UDF_5, Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7,
                            Constants.COLUMN_UDF_8, Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10,
                            Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13,
                            Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16,
                            Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19,

                            Constants.COLUMN_UDF_20
                             )

                            .collect(Collectors.toList());
            csvPrinter.printRecord(list);
/*
 * 
            
            
            inwardInvoiceCDNTemplateDTO.getUdf11(),inwardInvoiceCDNTemplateDTO.getUdf12(),inwardInvoiceCDNTemplateDTO.getUdf13(),inwardInvoiceCDNTemplateDTO.getUdf14(),inwardInvoiceCDNTemplateDTO.getUdf15(),inwardInvoiceCDNTemplateDTO.getUdf16(),
            inwardInvoiceCDNTemplateDTO.getUdf17(),inwardInvoiceCDNTemplateDTO.getUdf18(),inwardInvoiceCDNTemplateDTO.getUdf19(),inwardInvoiceCDNTemplateDTO.getUdf20()
            
 */
            if (!errorDataListWithErrorCode.isEmpty()) {
                for (InwardInvoiceCDNTemplateDTO template : errorDataListWithErrorCode) {
                    List<Object> data = Arrays.asList(template.getErrorCode(),
                            getErrorCodeDescription(template.getErrorCode(), errorCodeMap),template.getGstinOfRecipient(), template.getOrgDocType(),template.getOrgSupplyType(),
                                    template.getDocNo(), template.getDocDate(), template.getOrgInvoiceNo(),
                                    template.getOrgInvoiceDate(), template.getGstinOfSupplier(), template.getSupplierName(),
                                    template.getSupplierStateCode(), template.getInwardNo(),
                                    template.getInwardDate(), template.getItemDescription(), template.getHsnSacCode(),template.getUom(),template.getQuantity(),
                                    template.getItemRate(),
                                    template.getTaxableAmount(), template.getSgstRate(), template.getSgstAmt(),
                                    template.getCgstRate(), template.getCgstAmt(), template.getIgstRate(),
                                    template.getIgstAmt(), template.getCessRate(), template.getCessAmount(),
                                    template.getDiffPercent(), template.getInwardGrossTotalAmount(),template.getTotalInvoiceAmt(),
                                    template.getOrgInputType(),template.getItcIneligibleReversalIndicator(), template.getItcIneligibleReversalPercentage(),
                                    template.getPlaceOfSupply(), template.getReverseCharge(), template.getPort(),
                                    template.getImportBillOfEntryNo(), template.getImportBillOfEntryDate(),
                                    template.getImportBillOfEntryAmt(), template.getDateOfPayment(),template.getIrn(),
                                    template.getAckDate(), template.getAckNo(),template.getDebitGlId(),
                                    template.getDebitGlName(),
                                    template.getCreditGlId(), template.getCreditGlName(),template.getSubLocation(),template.getFp(),
                                    template.getPaymentAmount(),template.getPaymentRefNo(),
                                    template.getTdsSection(),template.getTdsRate(),template.getTdsTaxAmount(),template.getChallanNumber(),
                                    template.getChallanDate(),template.getChallanAmount(),template.getPeriodOfFiling(),template.getInvoiceAgainstProvAdv(),
                                    template.getInwardNoProvAdv(),template.getInwardDateProvAdv(),template.getAmountOfProvAdv(),template.getBalOutstanding(),
                                    template.getUdf1(), template.getUdf2(),
                                    template.getUdf3(), template.getUdf4(), template.getUdf5(), template.getUdf6(),
                                    template.getUdf7(), template.getUdf8(), template.getUdf9(), template.getUdf10(),
                                    template.getUdf11(), template.getUdf12(), template.getUdf13(),
                                    template.getUdf14(), template.getUdf15(), template.getUdf16(), template.getUdf17(),
                                    template.getUdf18(), template.getUdf19(), template.getUdf20());
                    csvPrinter.printRecord(data);
                    log.info(Constants.LOGMESSAGE, methodName);
                }
            }

            csvPrinter.flush();
            log.info(Constants.LOGMESSAGE, methodName);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error(Constants.LOGERRORMESSAGE, methodName);
            throw new VendorInvoiceServerException("fail to import data to CSV file: " + e.getMessage());
        }
    }

    String getErrorCodeDescription(String codes, Map<String, String> errorCodeMap) {

        StringBuilder strBuilder = new StringBuilder();
        String code = codes.replace("|", ",");
        String[] errorCodeList = code.split(",");

        if (errorCodeList.length > 1) {
            for (int i = 1; i < errorCodeList.length; i++) {
                String description = errorCodeMap.get(errorCodeList[i].trim());
                strBuilder.append("|" + description);

            }
        }
        return strBuilder.toString();
    }

}
