package com.bdo.bvms.common.itc.serviceimpl;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.constant.StringConstant;
import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dao.CustomTemplateRepo;
import com.bdo.bvms.common.dao.InwardRegisterDao;
import com.bdo.bvms.common.dao.UploadTransDao;
import com.bdo.bvms.common.dto.ExceptionLogDTO;
import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvalidTemplateHeaderException;
import com.bdo.bvms.common.exceptions.InvoiceTemplateUploadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.itc.service.ReadCustomItcDetailTemplate;
import com.bdo.bvms.common.util.AppUtil;
import com.bdo.bvms.common.util.CommonUtils;
import com.monitorjbl.xlsx.StreamingReader;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class ReadCustomItcDetailTemplateImpl implements ReadCustomItcDetailTemplate{

	@Value("${bvms.cloud.temp.file.download.path}")
	String tempFolder;

	@Autowired
	CustomTemplateRepo customeTemplateRepo;
	
	@Autowired
	UploadTransDao uploadTransDao;
	
	@Autowired
	InwardRegisterDao commonCommunicationDao;
	
	Row headerRow = null;
	Set<String>sftpSet=new HashSet<>();
	Map<String, Integer> colNameIndexMap = new HashMap<>();
	
	
	@Override
	public void readCustomTemplate(UploadReqDTO uploadRequestDTO, List<ItcDto> itcDtoTemplateDTOList) throws InvoiceTemplateUploadException {
		
		StringBuilder fileName = new StringBuilder().append(tempFolder)
				.append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadRequestDTO.getBatchNo())
				.append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
				.append(uploadRequestDTO.getFileType());

		Map<String, Object> rowCountWithHeader = new HashMap<>();
		Map<String, String> customTemplateHeaderMappings = CommonUtils.getCustomTemplateHeaderMappings(uploadRequestDTO,
				customeTemplateRepo);
		try {
			try (InputStream inputStream = new FileInputStream(new File(fileName.toString()));
					BufferedInputStream br = new BufferedInputStream(inputStream)) {
				// getting HeaderRowIndexs , coumnsDataRow ,RowCount
				rowCountWithHeader = getRowCustomCountWithHeader(inputStream, uploadRequestDTO);
			}
		} catch (Exception e2) {
			uploadTransDao.updateProcessStatus(uploadRequestDTO.getBatchNo(),
					Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
			ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();

			String methodName1 = "getExcelEWayDataList";

			exceptionLogDTO.setUserId(uploadRequestDTO.getId());
			exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
			exceptionLogDTO.setFunctionName(methodName1);
			exceptionLogDTO.setErrorMessage(e2.getMessage());
			exceptionLogDTO.setErrorCause(Constants.NOTCONTAINPROPERDATA);
			exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
			exceptionLogDTO.setCreatedAt(LocalDateTime.now());

			commonCommunicationDao.updateExceptionLogTable(exceptionLogDTO);

			throw new InvoiceTemplateUploadException(e2.getMessage());
		}

		headerRow = (Row) rowCountWithHeader.get(Constants.DATA_ROW);

		try {
			colNameIndexMap = AppUtil.getColumnNameIndexMap(headerRow);

		} catch (Exception ex) {

			log.error("Exception ", ex);

			uploadTransDao.updateProcessStatus(uploadRequestDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);

			

			throw new InvoiceTemplateUploadException(ex.getMessage(), ex.getCause());
		}

		// throw exception and Update in Exception Log table as per Batch Number
		if (Constants.ITC_TEMPLATE_HEADER_COUNT != colNameIndexMap.size()) {
			uploadTransDao.updateProcessStatus(uploadRequestDTO.getBatchNo(),
					Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);

			throw new InvalidTemplateHeaderException(StringConstant.HEADERCOUNTERRORMESSAGE + uploadRequestDTO.getBatchNo());

		}

		try (InputStream in = new FileInputStream(new File(fileName.toString()));
				BufferedInputStream bis = new BufferedInputStream(in);
				Workbook workbook = StreamingReader.builder().open(bis);) {

			Sheet sheet = workbook.getSheetAt(0);

			sheet.forEach(row -> {
				ItcDto rowObj = new ItcDto();
				if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 0) {
					rowObj.setExcelRowId(row.getRowNum());
					try {
						// reading Excel Template
						rowObj.setValid(true);
						rowObj = readTemplateRecord(row, colNameIndexMap, uploadRequestDTO, customTemplateHeaderMappings);
						

					} catch (Exception e) {
						log.error("Error generated while reading xls ", e);
						markErrorNAddErrorCode(rowObj, ValidationConstant.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
					}
					
					if (StringUtils.isNotBlank(rowObj.getGstinUinOfRecipient())
                            && rowObj.getGstinUinOfRecipient().length() == 15) {
						rowObj.setPanOfRecipient(rowObj.getGstinUinOfRecipient().substring(2, 12));

            } else {
            	rowObj.setPanOfRecipient("");

            }
            
            if (rowObj.getFilingPeriod().length() == 5) {
            	rowObj.setFilingPeriod(Constants.ZEROVALUE + rowObj.getFilingPeriod());
            }
            
            if (StringUtils.isNotBlank(rowObj.getGstinOfSupplier())
                            && rowObj.getGstinOfSupplier().length() == 15) {
            	rowObj.setPanOfSupplier(rowObj.getGstinOfSupplier().substring(2, 12));
            } else {
            	rowObj.setPanOfSupplier("");
            }
					itcDtoTemplateDTOList.add(rowObj);
				}
			});

			
		} catch (Exception exception) {
			throw new InvoiceTemplateUploadException(exception.getMessage(), exception);
		}

		
	}
	
	private ItcDto readTemplateRecord(Row row, Map<String, Integer> colNameIndexMap, UploadReqDTO uploadDTO,
			Map<String, String> columnMap) {

		ItcDto xlsRow = new ItcDto();
		log.info("Reading Cell from excel Rows field wise");

		try {

			if (colNameIndexMap.size() != columnMap.size()) {
				uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),
						Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);
			}
		
			xlsRow.setValid(true);
			xlsRow.setExcelRowId(row.getRowNum());

			
			String customHeaderName = columnMap.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT);
			Integer idxForGstinReceipient = colNameIndexMap.get(customHeaderName);
			xlsRow.setGstinUinOfRecipient(AppUtil.getCellValue(row.getCell(idxForGstinReceipient)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_DOC_TYPE);
			Integer idxForDocType = colNameIndexMap.get(customHeaderName);
			xlsRow.setDocType(AppUtil.getCellValue(row.getCell(idxForDocType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
			customHeaderName = columnMap.get(Constants.FILLING_PERIOD);
			Integer idxForFilingPeriod = colNameIndexMap.get(customHeaderName);
			xlsRow.setFilingPeriod(AppUtil.getCellValue(row.getCell(idxForFilingPeriod)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
			
			customHeaderName = columnMap.get(Constants.COLUMN_SUPPLY_TYPE);
			Integer idxForSupplyType = colNameIndexMap.get(customHeaderName);
			xlsRow.setSupplyType(AppUtil.getCellValue(row.getCell(idxForSupplyType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
			customHeaderName = columnMap.get(Constants.COLUMN_DOC_NO);
			Integer idxForDocNo = colNameIndexMap.get(customHeaderName);
			xlsRow.setDocNo(AppUtil.getCellValue(row.getCell(idxForDocNo)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
			customHeaderName = columnMap.get(Constants.COLUMN_DOC_DATE);
			Integer idxForDocDate = colNameIndexMap.get(customHeaderName);
			xlsRow.setDocDate(AppUtil.getCellValue(row.getCell(idxForDocDate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_ORG_INVOICE_NO);
			Integer idxForOrgInvoiceNo = colNameIndexMap.get(customHeaderName);
			xlsRow.setOrgInvoiceNo(AppUtil.getCellValue(row.getCell(idxForOrgInvoiceNo)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_ORG_INVOICE_DATE);
			Integer idxForOrgInvoiceDate = colNameIndexMap.get(customHeaderName);
			xlsRow.setOrgInvoiceDate(AppUtil.getCellValue(row.getCell(idxForOrgInvoiceDate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			
			customHeaderName = columnMap.get(Constants.COLUMN_GSTIN_OF_SUPPLIER);
			Integer idxForGstinSupplier = colNameIndexMap.get(customHeaderName);
			xlsRow.setGstinOfSupplier(AppUtil.getCellValue(row.getCell(idxForGstinSupplier)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_SUPPLIER_NAME);
			Integer idxForSupplierName = colNameIndexMap.get(customHeaderName);
			xlsRow.setSupplierName(AppUtil.getCellValue(row.getCell(idxForSupplierName)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_INWARD_NO);
			Integer idxForInwardNo = colNameIndexMap.get(customHeaderName);
			xlsRow.setInwardNo(AppUtil.getCellValue(row.getCell(idxForInwardNo)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_INWARD_DATE);
			Integer idxForInwardDate = colNameIndexMap.get(customHeaderName);
			xlsRow.setInwardDate(AppUtil.getCellValue(row.getCell(idxForInwardDate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_INPUT_TYPE);
			Integer idxForInputType = colNameIndexMap.get(customHeaderName);
			xlsRow.setItcInputType(AppUtil.getCellValue(row.getCell(idxForInputType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_INDICATOR);
			Integer idxForItcIneligibleReversalIndicator = colNameIndexMap.get(customHeaderName);
			xlsRow.setReversalIndicator(AppUtil.getCellValue(row.getCell(idxForItcIneligibleReversalIndicator)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_PERCENTAGE);
			Integer idxForItcIneligibleReversalPercentage = colNameIndexMap.get(customHeaderName);
			xlsRow.setReversalPercentage(AppUtil.getCellValue(row.getCell(idxForItcIneligibleReversalPercentage)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			assAmountNonNumericCheck(xlsRow);
			
			customHeaderName = columnMap.get(Constants.COLUMN_DEBIT_GL_ID);
			Integer idxForDebitGlId = colNameIndexMap.get(customHeaderName);
			xlsRow.setDebitGlId(AppUtil.getCellValue(row.getCell(idxForDebitGlId)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_DEBIT_GL_NAME);
			Integer idxForDebitGlName = colNameIndexMap.get(customHeaderName);
			xlsRow.setDebitGlName(AppUtil.getCellValue(row.getCell(idxForDebitGlName)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_CREDIT_GL_ID);
			Integer idxForCreditGlId = colNameIndexMap.get(customHeaderName);
			xlsRow.setCreditGlId(AppUtil.getCellValue(row.getCell(idxForCreditGlId)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_CREDIT_GL_NAME);
			Integer idxForCreditGlName = colNameIndexMap.get(customHeaderName);
			xlsRow.setCreditGlName(AppUtil.getCellValue(row.getCell(idxForCreditGlName)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			
			
			customHeaderName = columnMap.get(Constants.COLUMN_UDF_1);
			Integer idxForUdf1 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf1(AppUtil.getCellValue(row.getCell(idxForUdf1))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_2);
			Integer idxForUdf2 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf2(AppUtil.getCellValue(row.getCell(idxForUdf2)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_3);
			Integer idxForUdf3 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf3(AppUtil.getCellValue(row.getCell(idxForUdf3)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


			customHeaderName = columnMap.get(Constants.COLUMN_UDF_4);
			Integer idxForUdf4 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf4(AppUtil.getCellValue(row.getCell(idxForUdf4)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_5);
			Integer idxForUdf5 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf5(AppUtil.getCellValue(row.getCell(idxForUdf5)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_6);
			Integer idxForUdf6 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf6(AppUtil.getCellValue(row.getCell(idxForUdf6)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_7);
			Integer idxForUdf7 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf7(AppUtil.getCellValue(row.getCell(idxForUdf7)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_8);
			Integer idxForUdf8 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf8(AppUtil.getCellValue(row.getCell(idxForUdf8)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_9);
			Integer idxForUdf9 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf9(AppUtil.getCellValue(row.getCell(idxForUdf9)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_10);
			Integer idxForUdf10 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf10(AppUtil.getCellValue(row.getCell(idxForUdf10)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_11);
			Integer idxForUdf11 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf11(AppUtil.getCellValue(row.getCell(idxForUdf11)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_12);
			Integer idxForUdf12 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf12(AppUtil.getCellValue(row.getCell(idxForUdf12)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_13);
			Integer idxForUdf13 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf13(AppUtil.getCellValue(row.getCell(idxForUdf13)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_14);
			Integer idxForUdf14 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf14(AppUtil.getCellValue(row.getCell(idxForUdf14)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_15);
			Integer idxForUdf15 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf15(AppUtil.getCellValue(row.getCell(idxForUdf15)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_16);
			Integer idxForUdf16 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf16(AppUtil.getCellValue(row.getCell(idxForUdf16)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_17);
			Integer idxForUdf17 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf17(AppUtil.getCellValue(row.getCell(idxForUdf17)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_18);
			Integer idxForUdf18 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf18(AppUtil.getCellValue(row.getCell(idxForUdf18)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			
			customHeaderName = columnMap.get(Constants.COLUMN_UDF_19);
			Integer idxForUdf19 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf19(AppUtil.getCellValue(row.getCell(idxForUdf19)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_20);
			Integer idxForUdf20 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf20(AppUtil.getCellValue(row.getCell(idxForUdf20)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			
			

		} catch (Exception ex) {
			// Mark as not Valid object if Exception occur
			log.error("Error generated while reading xls ", ex);
			markErrorNAddErrorCode(xlsRow, ValidationConstant.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
			ExceptionLogDTO exceptionLogDto = new ExceptionLogDTO();
			exceptionLogDto.setUserId(uploadDTO.getUploadBy());
			exceptionLogDto.setScreenName(Constants.INVOICEINTEGRATION);
			exceptionLogDto.setFunctionName("readTemplateRecord");
			exceptionLogDto.setErrorMessage(ex.getMessage());
			exceptionLogDto.setErrorCause(ex.getCause().getMessage());
			exceptionLogDto.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
			exceptionLogDto.setCreatedAt(LocalDateTime.now());

			commonCommunicationDao.updateExceptionLogTable(exceptionLogDto);

			log.error("Errro occured while reading row " + row.getRowNum() + " for batch No. " + ex);
		}
		return xlsRow;
	}

	public Map<String, Object> getRowCustomCountWithHeader(InputStream fis, UploadReqDTO uploadDTO)
			throws IOException, VendorInvoiceServerException {
		Map<String, Object> dataMap = new HashMap<>();
		int totalRowCount = 0;
		try (InputStream is = new BufferedInputStream(fis); Workbook workbook = StreamingReader.builder().open(is);) {

			Sheet sheet = workbook.getSheetAt(0);
			for (Row row : sheet) {
				if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 0) {
					totalRowCount++;
				} else if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() <= 0 && totalRowCount == 0) {

					Row coumnsDataRow = null;
					coumnsDataRow = row;
					dataMap.put("headerRowIndex", row.getRowNum());
					dataMap.put("coumnsDataRow", coumnsDataRow);

				}

			}
			dataMap.put("RowCount", totalRowCount);
			return dataMap;
		} catch (Exception ex) {
			throw new VendorInvoiceServerException(StringConstant.HEADERCOUNTERRORMESSAGE + uploadDTO.getBatchNo());

		}

	}
	public static boolean isNumeric(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
	
	private void markErrorNAddErrorCode(ItcDto rowData, String errorCode, String errorMessage) {
        log.info("Entering markErrorNAddErrorCode Method ");
        rowData.setValid(false);
        rowData.setErrorCodeList(rowData.getErrorCodeList().append(errorCode));
        rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(errorMessage));
    }

	@Override
	public void getInwardDataListCDV(UploadReqDTO uploadReqDTO, Map<String, String> customTemplateHeaderMappings,
			char delimiter, List<ItcDto> itcDtoTemplateDTOList) throws VendorInvoiceServerException {
		
		Iterable<CSVRecord> records = null;
       
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadReqDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(uploadReqDTO.getFileType());

        File file = new File(fileName.toString());
        Path path = file.toPath();

        Map<String, Integer> columnIndexMap = new HashMap<>();

        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String headerLine = reader.readLine();
            String[] headers = headerLine.split(",");

            Map<String, String> customTemplateMap = new HashMap<>();
            String columnNameNotMatchedWithTemplate = "";
            for (Entry<String, String> map : customTemplateHeaderMappings.entrySet()) {

                byte[] bytes = map.getValue().trim().getBytes();
                String str = new String(bytes, StandardCharsets.UTF_8);

                customTemplateMap.put(str, str);
            }

            for (int cnt = 0; cnt <= headers.length - 1; cnt++) {
                byte[] bytes = headers[cnt].trim().getBytes();
                String str = new String(bytes, StandardCharsets.UTF_8).replaceAll("[^a-zA-Z0-9\\s+_-]", "");
                columnIndexMap.put(str, cnt);
                if (!str.trim().equals(customTemplateMap.get(str))) {
                    if ("".equals(columnNameNotMatchedWithTemplate)) {
                        columnNameNotMatchedWithTemplate = columnNameNotMatchedWithTemplate + headers[cnt];
                    } else {
                        columnNameNotMatchedWithTemplate = columnNameNotMatchedWithTemplate + "," + headers[cnt];
                    }

                }

            }

            if (columnNameNotMatchedWithTemplate.length() > 2) {
                log.error("Uploaded file(s) some columns does not matching with defined template");
                uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(),
                                Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);
                throw new VendorInvoiceServerException(
                                "Uploaded file(s) some columns does not matching with defined template,column(s) are "
                                                + columnNameNotMatchedWithTemplate);
            }

            records = CSVFormat.DEFAULT.withDelimiter(delimiter).withAllowMissingColumnNames(true).parse(reader);

            sftpSet = new HashSet<>();
            for (CSVRecord csvRecord : records) {

                boolean isEmptyRow = true;
                for (String value : csvRecord) {
                    if (!value.trim().isEmpty()) {
                        isEmptyRow = false;
                        break;
                    }
                }

                if (!isEmptyRow) {
                    readCsvCustomRecord(uploadReqDTO, csvRecord, customTemplateHeaderMappings,itcDtoTemplateDTOList,
                                    columnIndexMap);
                }

            }
            if("ftps".equals(uploadReqDTO.getUploadSource()))
            {
            	uploadReqDTO.setMonth(new ArrayList<>(sftpSet));
            }

        } catch (Exception e) {
            log.error("Error in getEinvoiceDataListCDV method ", e);
            if (e.getMessage().contains("matching with defined template,column(s)")) {
                throw new VendorInvoiceServerException(e.getMessage());
            } else {
                throw new VendorInvoiceServerException("Error while reading custom template for vendor details import ",
                                e);
            }
        } finally {
            records = null;
        }
        if ("ftps".equals(uploadReqDTO.getUploadType()) || uploadReqDTO.getFp().isEmpty()) {
        	uploadReqDTO.setMonth(new ArrayList<>(sftpSet));
        	uploadTransDao.updateFpLog(uploadReqDTO.getMonth(), uploadReqDTO);
        }
     
	
		
	
		
	}

	private void readCsvCustomRecord(UploadReqDTO uploadReqDTO, CSVRecord csvRecord,
			Map<String, String> customTemplateHeaderMappings, List<ItcDto> itcDtoTemplateDTOList, Map<String, Integer> columnIndexMap) {
		ItcDto vendorUploadStage1 = new ItcDto();
		vendorUploadStage1.setValid(true);
		String taxpayerGSTCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT);
		vendorUploadStage1.setGstinUinOfRecipient(csvRecord.get(columnIndexMap.get(taxpayerGSTCustomHeaderName)));

		
//		xlsRow.setValid(true);
//		xlsRow.setExcelRowId(row.getRowNum());

		String setDocType = customTemplateHeaderMappings.get(Constants.DOC_TYPE);
		vendorUploadStage1.setDocType(csvRecord.get(columnIndexMap.get(setDocType)));

		
		String setSupplyType = customTemplateHeaderMappings.get(Constants.COLUMN_SUPPLY_TYPE);
		vendorUploadStage1.setSupplyType(csvRecord.get(columnIndexMap.get(setSupplyType)));

	
		String setFilingPeriod = customTemplateHeaderMappings.get(Constants.FILLING_PERIOD);
		vendorUploadStage1.setFilingPeriod(csvRecord.get(columnIndexMap.get(setFilingPeriod)));

		
		String setDocNo = customTemplateHeaderMappings.get(Constants.COLUMN_DOC_NO);
		vendorUploadStage1.setDocNo(csvRecord.get(columnIndexMap.get(setDocNo)));

		
		String setDocDate = customTemplateHeaderMappings.get(Constants.COLUMN_DOC_DATE);
		vendorUploadStage1.setDocDate(csvRecord.get(columnIndexMap.get(setDocDate)));

		
		
		String setOrgInvoiceNo = customTemplateHeaderMappings.get(Constants.COLUMN_ORG_INVOICE_NO);
		vendorUploadStage1.setOrgInvoiceNo(csvRecord.get(columnIndexMap.get(setOrgInvoiceNo)));

		
		
		String setOrgInvoiceDate = customTemplateHeaderMappings.get(Constants.COLUMN_ORG_INVOICE_DATE);
		vendorUploadStage1.setOrgInvoiceDate(csvRecord.get(columnIndexMap.get(setOrgInvoiceDate)));

		
		
		String setGstinOfSupplier = customTemplateHeaderMappings.get(Constants.COLUMN_GSTIN_OF_SUPPLIER);
		vendorUploadStage1.setGstinOfSupplier(csvRecord.get(columnIndexMap.get(setGstinOfSupplier)));

		
		String setSupplierName = customTemplateHeaderMappings.get(Constants.COLUMN_SUPPLIER_NAME);
		vendorUploadStage1.setSupplierName(csvRecord.get(columnIndexMap.get(setSupplierName)));

	
		
		String setInwardNo = customTemplateHeaderMappings.get(Constants.COLUMN_INWARD_NO);
		vendorUploadStage1.setInwardNo(csvRecord.get(columnIndexMap.get(setInwardNo)));

	
		
		String setInwardDate = customTemplateHeaderMappings.get(Constants.COLUMN_INWARD_DATE);
		vendorUploadStage1.setInwardDate(csvRecord.get(columnIndexMap.get(setInwardDate)));

		
		
		
		String setItcInputType = customTemplateHeaderMappings.get(Constants.COLUMN_INPUT_TYPE);
		vendorUploadStage1.setItcInputType(csvRecord.get(columnIndexMap.get(setItcInputType)));

	
		
		String setReversalIndicator = customTemplateHeaderMappings.get(Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_INDICATOR);
		vendorUploadStage1.setReversalIndicator(csvRecord.get(columnIndexMap.get(setReversalIndicator)));

	
		
		String setReversalPercentage = customTemplateHeaderMappings.get(Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_PERCENTAGE);
		vendorUploadStage1.setReversalPercentage(csvRecord.get(columnIndexMap.get(setReversalPercentage)));

		assAmountNonNumericCheck(vendorUploadStage1);
		
		
		String setDebitGlId = customTemplateHeaderMappings.get(Constants.COLUMN_DEBIT_GL_ID);
		vendorUploadStage1.setDebitGlId(csvRecord.get(columnIndexMap.get(setDebitGlId)));

		
		
		String setDebitGlName = customTemplateHeaderMappings.get(Constants.COLUMN_DEBIT_GL_NAME);
		vendorUploadStage1.setDebitGlName(csvRecord.get(columnIndexMap.get(setDebitGlName)));

		
		String setCreditGlId = customTemplateHeaderMappings.get(Constants.COLUMN_CREDIT_GL_ID);
		vendorUploadStage1.setCreditGlId(csvRecord.get(columnIndexMap.get(setCreditGlId)));

		
		
		String setCreditGlName = customTemplateHeaderMappings.get(Constants.COLUMN_CREDIT_GL_NAME);
		vendorUploadStage1.setCreditGlName(csvRecord.get(columnIndexMap.get(setCreditGlName)));

		
		
		String setUdf1 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_1);
		vendorUploadStage1.setUdf1(csvRecord.get(columnIndexMap.get(setUdf1)));

	    String setUdf2 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_2);
		vendorUploadStage1.setUdf2(csvRecord.get(columnIndexMap.get(setUdf2)));

		String setUdf3 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_3);
		vendorUploadStage1.setUdf3(csvRecord.get(columnIndexMap.get(setUdf3)));

	    String setUdf4 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_4);
		vendorUploadStage1.setUdf4(csvRecord.get(columnIndexMap.get(setUdf4)));

		String setUdf5 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_5);
		vendorUploadStage1.setUdf5(csvRecord.get(columnIndexMap.get(setUdf5)));

		String setUdf6 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_6);
		vendorUploadStage1.setUdf6(csvRecord.get(columnIndexMap.get(setUdf6)));

		String setUdf7 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_7);
		vendorUploadStage1.setUdf7(csvRecord.get(columnIndexMap.get(setUdf7)));

		String setUdf8 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_8);
		vendorUploadStage1.setUdf8(csvRecord.get(columnIndexMap.get(setUdf8)));

		String setUdf9 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_9);
		vendorUploadStage1.setUdf9(csvRecord.get(columnIndexMap.get(setUdf9)));

		String setUdf10 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_10);
		vendorUploadStage1.setUdf10(csvRecord.get(columnIndexMap.get(setUdf10)));

		 
        
		String setUdf11 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_11);
		vendorUploadStage1.setUdf11(csvRecord.get(columnIndexMap.get(setUdf11)));

		String setUdf12 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_12);
		vendorUploadStage1.setUdf12(csvRecord.get(columnIndexMap.get(setUdf12)));

		String setUdf13 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_13);
		vendorUploadStage1.setUdf13(csvRecord.get(columnIndexMap.get(setUdf13)));

		String setUdf14 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_14);
		vendorUploadStage1.setUdf14(csvRecord.get(columnIndexMap.get(setUdf14)));

		String setUdf15 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_15);
		vendorUploadStage1.setUdf15(csvRecord.get(columnIndexMap.get(setUdf15)));

		String setUdf16 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_16);
		vendorUploadStage1.setUdf16(csvRecord.get(columnIndexMap.get(setUdf16)));

		String setUdf17 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_17);
		vendorUploadStage1.setUdf17(csvRecord.get(columnIndexMap.get(setUdf17)));

		String setUdf18 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_18);
		vendorUploadStage1.setUdf18(csvRecord.get(columnIndexMap.get(setUdf18)));

		String setUdf19 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_19);
		vendorUploadStage1.setUdf19(csvRecord.get(columnIndexMap.get(setUdf19)));
		String setUdf20 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_20);
		vendorUploadStage1.setUdf20(csvRecord.get(columnIndexMap.get(setUdf20)));
		itcDtoTemplateDTOList.add(vendorUploadStage1);
		
	}
	
	private void assAmountNonNumericCheck(ItcDto xlsRow) {
		if(!isNumeric(xlsRow.getReversalPercentage())) {
		if(StringUtils.isBlank(xlsRow.getReversalPercentage()))
    	{
			xlsRow.setReversalPercentage("0.0");
    	}
    	else
    	{
    		xlsRow.setReversalPercentage("0.0");
    		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00588, Constants.BLANK);
    	}
		}

	}


}
