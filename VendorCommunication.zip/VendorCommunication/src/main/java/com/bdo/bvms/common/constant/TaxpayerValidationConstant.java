package com.bdo.bvms.common.constant;

public final class TaxpayerValidationConstant {

    TaxpayerValidationConstant() {

    }

    public static final String GSTIN_PATTERN = "^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$";

    public static final String VENDOR_CODE_ERP = "^[a-zA-Z0-9_]*$";

    public static final String EMAIL_ID_PATTERN = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}";

    public static final String PAN_PATTERN = "[A-Z]{5}[0-9]{4}[A-Z]{1}";

    public static final String MOBILE_PATTERN = "[1-9]{1}[0-9]{9}";

    public static final String BANK_IFSC_PATTERN = "^[A-Z|a-z]{4}[0][0-9]{6}$";

    public static final String COMPANY_LEGAL_NAME_PATTERN = "^[^ ]{1}[a-zA-Z0-9_&.@ ]*$";

    public static final String COMPANY_TRADE_NAME_PATTERN = "^[^ ]{1}[a-zA-Z0-9_&.@ ]*$";

    public static final String AADHAR_PATTERN = "^[0-9]{12}$";

    public static final String FIRST_NAME_PATTERN = "^[a-zA-Z]{1}(([a-zA-Z ])*)[a-zA-Z]{1}$";

    public static final String LAST_NAME_PATTERN = "^[a-zA-Z]{1}(([a-zA-Z ])*)[a-zA-Z]{1}$";

    public static final String PINCODE_PATTERN = "[1-9]{1}[0-9]{5}";

    public static final String ADDRESS_LINE1_PATTERN = "^[a-zA-Z0-9\\&\\,\\.]{1}(([a-zA-Z0-9\\&\\,\\. ])*)$";

    public static final String ADDRESS_LINE2_PATTERN = "^[a-zA-Z0-9\\&\\,\\.]{1}(([a-zA-Z0-9\\&\\,\\. ])*)$";

    public static final String PLACE_PATTERN = "^[a-zA-Z0-9\\&\\.]{1}(([a-zA-Z0-9\\&\\. ])*)$";

    public static final String BANKNAME_PATTERN = "^[^ ]{1}[a-zA-Z0-9_&.@ ]*$";

    public static final String BANK_ADDRESS_PATTERN = "^[a-zA-Z0-9\\&\\,\\.]{1}(([a-zA-Z0-9\\&\\,\\. ])*)$";

    public static final String BANK_ACCOUNT_HOLDER_NAME_PATTERN = "^[a-zA-Z0-9\\&\\.]{1}(([a-zA-Z0-9\\&\\. ])*)$";

    public static final String BANK_ACCOUNT_NO_PATTERN = "^[0-9]{9,18}$";

    public static final String PRIMARY_UPI_PATTERN = "^[a-zA-Z0-9.-]+@[a-zA-Z]+$";

    public static final String SECONDARY_UPI_PATTERN = "^[a-zA-Z0-9.-]+@[a-zA-Z]+$";

    public static final int GSTIN_MIN_SIZE = 15;

    public static final int GSTIN_MAX_SIZE = 15;

    public static final int PAN_MIN_SIZE = 10;

    public static final int PAN_MAX_SIZE = 10;

    public static final int MOBILE_MIN_SIZE = 10;

    public static final int MOBILE_MAX_SIZE = 10;

    public static final int AADHAR_MIN_SIZE = 12;

    public static final int AADHAR_MAX_SIZE = 12;

    public static final int PINCODE_MIN_SIZE = 6;

    public static final int PINCODE_MAX_SIZE = 6;

    public static final int PINCODE_MIN_VALUE_FROM = 100000;

    public static final int PINCODE_MAX_VALUE_TO = 999999;

    public static final int COMPANY_LEGAL_NAME_MIN_SIZE = 1;

    public static final int COMPANY_LEGAL_NAME_MAX_SIZE = 100;

    public static final int COMPANY_TRADE_NAME_MIN_SIZE = 1;

    public static final int COMPANY_TRADE_NAME_MAX_SIZE = 100;

    // ***********************BANK DETAILS LENGTH VALIDATION

    public static final int BANKNAME_MIN_SIZE = 1;

    public static final int BANKNAME_MAX_SIZE = 100;

    public static final int BANK_ACCOUNT_HOLDER_NAME_MIN_SIZE = 1;

    public static final int BANK_ACCOUNT_HOLDER_NAME_MAX_SIZE = 200;

    public static final int BANK_ACCOUNT_NO_MIN_SIZE = 1;

    public static final int BANK_ACCOUNT_NO_MAX_SIZE = 17;

    public static final int BANK_IFSC_MIN_SIZE = 1;

    public static final int BANK_IFSC_MAX_SIZE = 11;

    public static final int BANK_ADDRESS_MIN_SIZE = 1;

    public static final int BANK_ADDRESS_MAX_SIZE = 255;

    public static final int PRIMARY_UPI_MIN_SIZE = 1;

    public static final int PRIMARY_UPI_MAX_SIZE = 20;

    public static final int SECONDARY_UPI_MIN_SIZE = 4;

    public static final int SECONDARY_UPI_MAX_SIZE = 20;

    public static final int UDF_MIN_SIZE_1 = 1;

    public static final int UDF_MAX_SIZE_1 = 200;

    public static final int UDF_MIN_SIZE_2 = 1;

    public static final int UDF_MAX_SIZE_2 = 200;

    public static final int UDF_MIN_SIZE_3 = 1;

    public static final int UDF_MAX_SIZE_3 = 200;

    public static final int UDF_MIN_SIZE_4 = 1;

    public static final int UDF_MAX_SIZE_4 = 200;

    public static final int UDF_MIN_SIZE_5 = 1;

    public static final int UDF_MAX_SIZE_5 = 200;

    public static final int UDF_MIN_SIZE_6 = 1;

    public static final int UDF_MAX_SIZE_6 = 200;

    public static final int UDF_MIN_SIZE_7 = 1;

    public static final int UDF_MAX_SIZE_7 = 200;

    public static final int UDF_MIN_SIZE_8 = 1;

    public static final int UDF_MAX_SIZE_8 = 200;

    public static final int UDF_MIN_SIZE_9 = 1;

    public static final int UDF_MAX_SIZE_9 = 200;

    public static final int UDF_MIN_SIZE_10 = 1;

    public static final int UDF_MAX_SIZE_10 = 200;

    // ********************************ADDRESS LENGTH
    // VALIDATIONS*****************

    public static final int ADDRESS_TYPE_MAX_SIZE = 5;

    public static final int ADDRESS_TYPE_MIN_SIZE = 1;

    public static final int ADDRESS_LINE1_MAX_SIZE = 100;

    public static final int ADDRESS_LINE1_MIN_SIZE = 1;

    public static final int ADDRESS_LINE2_MAX_SIZE = 100;

    public static final int ADDRESS_LINE2_MIN_SIZE = 1;

    public static final int PLACE_MAX_SIZE = 100;

    public static final int PLACE_MIN_SIZE = 1;

    // ********************************CONTACT LENGTH
    // VALIDATIONS******************

    public static final int FIRST_NAME_MIN_SIZE = 1;

    public static final int FIRST_NAME_MAX_SIZE = 100;

    public static final int LAST_NAME_MIN_SIZE = 1;

    public static final int LAST_NAME_MAX_SIZE = 100;

    public static final int EMAIL_MIN_SIZE = 0;

    public static final int EMAIL_MAX_SIZE = 100;

    public static final long MOBILE_MIN_VALUE = 1000000000l;

    public static final long MOBILE_MAX_VALUE = 9999999999l;

    // ********************************MASTER UPDATE
    // VALIDATIONS******************

    public static final int LEGAL_NAME_OF_BUSINESS_MIN_SIZE = 1;

    public static final int LEGAL_NAME_OF_BUSINESS_MAX_SIZE = 200;

    public static final int TRADE_NAME_OF_BUSINESS_MIN_SIZE = 1;

    public static final int TRADE_NAME_OF_BUSINESS_MAX_SIZE = 200;

    public static final int VENDOR_CODE_MIN_SIZE = 1;

    public static final int VENDOR_CODE_MAX_SIZE = 50;

    public static final Long VENDOR_UPLOAD_FILE_MIN_SIZE = 10000l;

    public static String generateNullOrEmptyMsg(String fieldName) {
        return fieldName;
    }

    public static final int UPLOAD_LOG_FILE_TYPE_MIN = 0;

    public static final int UPLOAD_LOG_FILE_TYPE_MAX = 1;

    public static final int REMARKS_MIN_SIZE = 1;

    public static final int REMARKS_MAX_SIZE = 45;

}
