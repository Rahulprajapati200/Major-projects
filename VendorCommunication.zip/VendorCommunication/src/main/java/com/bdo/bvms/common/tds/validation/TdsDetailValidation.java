package com.bdo.bvms.common.tds.validation;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dto.TdsDetails;

import java.util.regex.Matcher;
import com.bdo.bvms.common.validationrule.InwardDroolUtil;


public class TdsDetailValidation {

	public void validateTdsDetails(TdsDetails rowData,List<String>map) {

		InwardDroolUtil ruleMethods = new InwardDroolUtil();
		
		 validGstinCheck(rowData, ruleMethods);

		 validPanCheck(rowData);
		 
	     validGSTINTaxpayer(rowData, ruleMethods);
	     
	     validVendorPan(rowData);
	     
	     checkForTaxPayerGstinEqualsSupplierGstin(rowData);
		
	     validateDocType(rowData);
	     
	     docNoSpecialCharCheck(rowData,ruleMethods);
	     
	     docNoMaxLengthCheck(rowData);
	     
	     docDateValidCheck(rowData,ruleMethods);
	     
	     // Check invoice no. is blank
	        inwardNoCheck(rowData, ruleMethods);

	        inwardNo16Length(rowData, ruleMethods);
	        
	     // inwardDate should be in DD-MM-YYYY format"
	        isValidInvoiceDateCheck(rowData, ruleMethods);

	        isValidInvoiceDateFutureCheck(rowData, ruleMethods);
	        
	        assAMtBlankCheck(rowData);
	        
	        assAmtDecimalCheck(rowData,ruleMethods);
	        
	        validateTdsTaxAmount(rowData,ruleMethods);
	        
	        validateTdsRate(rowData,ruleMethods);
	    	validateTdsRate3Digit2Decimal(rowData,ruleMethods);
	    	
	    	validateGrossAmt3Digit2Decimal(rowData,ruleMethods);
	    	validateGrossAmt(rowData, ruleMethods);
	    	
	    	idTdsFromTable(rowData,map);
	    	
	    	//validatefPaymentDetails(rowData);
	    	
	    	validatePaymentRefNo(rowData,ruleMethods);
	    	
	    	validateChallanAmount(rowData,ruleMethods);
	    	
	    	validateChallanNumber(rowData,ruleMethods);
	    	
	    	validateChallanDate(rowData,ruleMethods);
	    	
	    	challanNumberLengthValidation(rowData);
	    	
	    	validateFillingPeriod(rowData,ruleMethods);
	    	
	    	validateAmountOfProvAdv(rowData,ruleMethods);
	    	
	    	validateinvoiceAgainstProvAdv(rowData);
	    	
	    	validateInwardNoProvAdv(rowData,ruleMethods);
	    	
	    	validateInwardNoProvAdvLength(rowData);
	    	
	    	validateInwardDateProvAdv(rowData,ruleMethods);
	    	
	    	validateinvoiceAgainstProvAdvDateAndNo(rowData);
	    	
	    	validateBalOutstanding(rowData,ruleMethods);
	    	
	    	validatePaymentDate(rowData,ruleMethods);
	    	
	    	 validateCreditGlId(rowData);
	         
	         validateCreditGlName(rowData);
	         
	         validateDebitGlId(rowData);
	         
	         validateDebitGlName(rowData);
	         
	         validatePaymentAmount(rowData,ruleMethods);
	    	
	         isValidChallanDateFutureCheck(rowData,ruleMethods);
	         
	         isValidDateOfPaymentFutureCheck(rowData,ruleMethods);
	         
	         isValidDocDateFutureCheck(rowData,ruleMethods);
	         
	         isValidInwardProvAdvDateFutureCheck(rowData,ruleMethods);
	         
	         validatePaymentAmount2Decimal(rowData,ruleMethods);
	         
	    	checkUdf10Length(rowData,ruleMethods);
	        checkUdf9Length(rowData,ruleMethods);
	        checkUdf8Length(rowData,ruleMethods);
	        checkUdf7Length(rowData,ruleMethods);
	        checkUdf6Length(rowData,ruleMethods);
	        checkUdf5Length(rowData,ruleMethods);
	        checkUdf4Length(rowData,ruleMethods);
	        checkUdf3Length(rowData,ruleMethods);
	        checkUdf2Length(rowData,ruleMethods);
	        checkUdf1Length(rowData,ruleMethods);
	        
	        checkUdf1xAlphaNumeric(rowData,ruleMethods);
	        checkUdf2AlphaNumeric(rowData,ruleMethods);
	        checkUdf3AlphaNumeric(rowData,ruleMethods);
	        checkUdf4AlphaNumeric(rowData,ruleMethods);
	        checkUdf5AlphaNumeric(rowData,ruleMethods);
	        checkUdf6AlphaNumeric(rowData,ruleMethods);
	        checkUdf7AlphaNumeric(rowData,ruleMethods);
	        checkUdf8AlphaNumeric(rowData,ruleMethods);
	        checkUdf9AlphaNumeric(rowData,ruleMethods);
	        checkUdf10AlphaNumeric(rowData,ruleMethods);
	        
	        checkUdf11Length(rowData,ruleMethods);
	        checkUdf12Length(rowData,ruleMethods);
	        checkUdf13Length(rowData,ruleMethods);
	        checkUdf14Length(rowData,ruleMethods);
	        checkUdf15Length(rowData,ruleMethods);
	        checkUdf16Length(rowData,ruleMethods);
	        checkUdf17Length(rowData,ruleMethods);
	        checkUdf18Length(rowData,ruleMethods);
	        checkUdf19Length(rowData,ruleMethods);
	        checkUdf20Length(rowData,ruleMethods);
	        
	        checkUdf11AlphaNumeric(rowData,ruleMethods);
	        checkUdf12AlphaNumeric(rowData,ruleMethods);
	        checkUdf13AlphaNumeric(rowData,ruleMethods);
	        checkUdf14AlphaNumeric(rowData,ruleMethods);
	        checkUdf15AlphaNumeric(rowData,ruleMethods);
	        checkUdf16AlphaNumeric(rowData,ruleMethods);
	        checkUdf17AlphaNumeric(rowData,ruleMethods);
	        checkUdf18AlphaNumeric(rowData,ruleMethods);
	        checkUdf19AlphaNumeric(rowData,ruleMethods);
	        checkUdf20AlphaNumeric(rowData,ruleMethods);
	
	}
	
	 private void docNoMaxLengthCheck(TdsDetails rowData) {
            if(StringUtils.isNotBlank(rowData.getDocNo()) && rowData.getDocNo().length()>16)
            {
            	markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00094, "");
            }
	 }

	private void validateDebitGlName(TdsDetails rowdata) {
		 if(StringUtils.isNotBlank(rowdata.getDebitglName()) && rowdata.getDebitglName().length()>45)
			{
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00578, "");
			}
		
	}

	private void validateDebitGlId(TdsDetails rowdata) {
		if(StringUtils.isNotBlank(rowdata.getDebitglId()) && rowdata.getDebitglId().length()>45)
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00577, "");
		}
		
	}

	private void validateCreditGlName(TdsDetails rowdata) {
		if(StringUtils.isNotBlank(rowdata.getCreditglName()) && rowdata.getCreditglName().length()>45)
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00576, "");
		}
		
	}

	private void validateCreditGlId(TdsDetails rowdata) {
		if(StringUtils.isNotBlank(rowdata.getCreditglId()) && rowdata.getCreditglId().length()>45)
		{
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00575, "");
		}
		
	}
	 private void validatePaymentDate(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
			if(StringUtils.isNotBlank(rowdata.getDateofPayment()) && !ruleMethods.isValidInvoiceDate(rowdata.getDateofPayment()))
			{
				markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00566, "");
			}
			
		}
	
	private void validatePaymentRefNo(TdsDetails rowdata, InwardDroolUtil inwardRules) {

		if (StringUtils.isNotBlank(rowdata.getPaymentRefNo())
				&& !inwardRules.isSpecialCharExistInInvoiceNo(rowdata.getPaymentRefNo())) {
			markErrorNAddErrorCode(rowdata, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00526, "");
		}
	}
	
	
	private void checkUdf11Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf11()) && ruleMethods.checkUDFLength(rowdata.getUdf11())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00537, "");
        }
    }

    private void checkUdf12Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf12()) && ruleMethods.checkUDFLength(rowdata.getUdf12())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00558, "");
        }
    }

    private void checkUdf13Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf13()) && ruleMethods.checkUDFLength(rowdata.getUdf13())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00539, "");
        }
    }

    private void checkUdf14Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf14()) && ruleMethods.checkUDFLength(rowdata.getUdf14())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00540, "");
        }
    }

    private void checkUdf15Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf15()) && ruleMethods.checkUDFLength(rowdata.getUdf15())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00541, "");
        }
    }

    private void checkUdf16Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf16()) && ruleMethods.checkUDFLength(rowdata.getUdf16())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00542, "");
        }
    }

    private void checkUdf17Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf17()) && ruleMethods.checkUDFLength(rowdata.getUdf17())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00543, "");
        }
    }

    private void checkUdf18Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf18()) && ruleMethods.checkUDFLength(rowdata.getUdf18())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00544, "");
        }
    }
 
    private void checkUdf19Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf19()) && ruleMethods.checkUDFLength(rowdata.getUdf19())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00545, "");
        }
    }


    private void checkUdf11AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf11()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf11())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00546, "");
        }
    }

    private void checkUdf12AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf12()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf12())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00547, "");
        }
    }

    private void checkUdf13AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf13()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf13())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00548, "");
        }
    }

    private void checkUdf14AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf14()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf14())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00549, "");
        }
    }
    private void checkUdf15AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf15()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf15())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00550, "");
        }
    }

    private void checkUdf16AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf16()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf16())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00551, "");
        }
    }

    private void checkUdf17AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf17()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf17())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00552, "");
        }
    }

    private void checkUdf18AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf18()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf18())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00553, "");
        }
    }

    private void checkUdf19AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf19()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf19())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00554, "");
        }
    }
  
    private void checkUdf20Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf20()) && ruleMethods.checkUDFLength(rowdata.getUdf20())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00555, "");
        }
    }
    

    private void checkUdf20AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf20()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf20())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00556, "");
        }
    }
	
	private void checkUdf10Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf10()) && ruleMethods.checkUDFLength(rowdata.getUdf10())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00311, "");
        }
    }

    private void checkUdf9Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf9()) && ruleMethods.checkUDFLength(rowdata.getUdf9())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00309, "");
        }
    }

    private void checkUdf8Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf8()) && ruleMethods.checkUDFLength(rowdata.getUdf8())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00307, "");
        }
    }

    private void checkUdf7Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf7()) && ruleMethods.checkUDFLength(rowdata.getUdf7())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00305, "");
        }
    }
   
    private void checkUdf6Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf6()) && ruleMethods.checkUDFLength(rowdata.getUdf6())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00303, "");
        }
    }

    private void checkUdf5Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf5()) && ruleMethods.checkUDFLength(rowdata.getUdf5())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00301, "");
        }
    }

    private void checkUdf4Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf4()) && ruleMethods.checkUDFLength(rowdata.getUdf4())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00299, "");
        }
    }

    private void checkUdf3Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf3()) && ruleMethods.checkUDFLength(rowdata.getUdf3())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00297, "");
        }
    }

    private void checkUdf2Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf2()) && ruleMethods.checkUDFLength(rowdata.getUdf2())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00295, "");
        }
    }

    private void checkUdf10AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf10()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf10())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00275, "");
        }
    }

    private void checkUdf9AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf9()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf9())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00310, "");
        }
    }
    

    private void checkUdf8AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf8()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf8())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00308, "");
        }
    }

    private void checkUdf7AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf7()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf7())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00306, "");
        }
    }

    private void checkUdf6AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf6()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf6())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00304, "");
        }
    }

    private void checkUdf5AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf5()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf5())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00302, "");
        }
    }

    private void checkUdf4AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf4()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf4())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00300, "");
        }
    }

    private void checkUdf3AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf3()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf3())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00298, "");
        }
    }

    private void checkUdf2AlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf2()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf2())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00296, "");
        }
    }
    

    private void checkUdf1Length(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf1()) && ruleMethods.checkUDFLength(rowdata.getUdf1())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00293, "");
        }
    }

    private void checkUdf1xAlphaNumeric(TdsDetails rowdata, InwardDroolUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf1()) && !ruleMethods.isAlphanumericUDF(rowdata.getUdf1())) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00294, "");
        }
    }
    
    
	
	
	private void validateBalOutstanding(TdsDetails rowData, InwardDroolUtil ruleMethods) {
		
		if(StringUtils.isNotBlank(rowData.getBalOutstanding()) && !ruleMethods.checkLength12(rowData.getBalOutstanding(),rowData.isValid()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00536, "");
		}
	}
	
	private void validateinvoiceAgainstProvAdvDateAndNo(TdsDetails rowData) {
		if ("Yes".equals(rowData.getInvoiceAgainstProvAdv()) && ( StringUtils.isBlank(rowData.getInwardDateprovAdv()) || StringUtils.isBlank(rowData.getInwardNoProvAdv()) ||StringUtils.isBlank(rowData.getAmountofProvAdv()))) {	
				markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00565, "");	
		}
	}
	
	private void validateinvoiceAgainstProvAdv(TdsDetails rowData) {
		if (StringUtils.isNotBlank(rowData.getInvoiceAgainstProvAdv())) {
			List<String> invoiceAgainstProvAdv = new ArrayList<>(Arrays.asList("Yes", "No"));
			if (!invoiceAgainstProvAdv.contains(rowData.getInvoiceAgainstProvAdv())) {
				markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00533, "");
			}
		}
	}

	private void validateInwardNoProvAdv(TdsDetails rowData, InwardDroolUtil ruleMethods)
	{
		if (StringUtils.isNotBlank(rowData.getInwardNoProvAdv()) && !ruleMethods.isSpecialCharExistInInvoiceNo(rowData.getInwardNoProvAdv())) {
				markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00534, "");
		}
	}
	
	private void validateInwardNoProvAdvLength(TdsDetails rowData)
	{
		if (StringUtils.isNotBlank(rowData.getInwardNoProvAdv()) && rowData.getInwardNoProvAdv().length()>16) {
				markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00559, "");
		}
	}
	
	private void validateInwardDateProvAdv(TdsDetails rowData, InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rowData.getInwardDateprovAdv()) && !ruleMethods.isValidDocDate(rowData.getInwardDateprovAdv()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00535, "");
		}
	}
	
	private void validateAmountOfProvAdv(TdsDetails rowData, InwardDroolUtil ruleMethods)
	{

		if(StringUtils.isNotBlank(rowData.getAmountofProvAdv()) && !ruleMethods.checkLength12(rowData.getAmountofProvAdv(),rowData.isValid()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00536, "");
		}
	
	}
	
	
	
	private void validateFillingPeriod(TdsDetails rowData, InwardDroolUtil ruleMethods) {
        if(StringUtils.isNotBlank(rowData.getPeriodFilingTdsReturn()) && !ruleMethods.validatePeriodOfFilling(rowData))
        {
       	 markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00532, "");
        }
	}
	
	private void validateChallanNumber(TdsDetails rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getChallanNo()) && !ruleMethods.onlyNumericAckNo(rawData.getChallanNo()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00557, "");
		}
	}
	
	private void validateChallanDate(TdsDetails rowData,InwardDroolUtil rulesMethod)
	{
		if(StringUtils.isNotBlank(rowData.getChallanDate()) && !rulesMethod.isValidInvoiceDate(rowData.getChallanDate()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00529, "");
		}
	}

	private void challanNumberLengthValidation(TdsDetails rowData) {
		if(StringUtils.isNotBlank(rowData.getChallanNo()) && rowData.getChallanNo().length()>6)
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00530, "");
		}
	}
	private void validateChallanAmount(TdsDetails rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getChallanAmount()) && !ruleMethods.checkLength12(rawData.getChallanAmount(), rawData.isValid()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00531, "");
		}
	}
	
	
	private void validatePaymentAmount2Decimal(TdsDetails rawData,InwardDroolUtil rules)
	{
		if(StringUtils.isNotBlank(rawData.getOrgPaymentAmount()) && !rules.twoDecimalHsnCheckBlank(rawData.getDocType(), rawData.getOrgPaymentAmount()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00560, "");
		}
	}
	
	private void validatePaymentAmount(TdsDetails rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getOrgPaymentAmount()) && !ruleMethods.checkLength12(rawData.getOrgPaymentAmount(), rawData.isValid()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00560, "");
		}
	}
	
	
//	private void validatefPaymentDetails(TdsDetails rowData)
//	{
//		if(((StringUtils.isNotBlank(rowData.getPaymentAmount()) && !"0.0".equals(rowData.getPaymentAmount())) || StringUtils.isNotBlank(rowData.getDateofPayment()) || StringUtils.isNotBlank(rowData.getPaymentRefNo()) ))
//		{
//			
//			if(new BigDecimal(rowData.getPaymentAmount()).compareTo(new BigDecimal(0))<=1)
//		
//			{
//				markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00560, "");
//			}
//			
//		}
//	
//	}
//	
	
	
	private void validateGrossAmt(TdsDetails rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getGrossAmount()) && !ruleMethods.twoDecimalHsnCheckBlank(rawData.getDocType(), rawData.getGrossAmount()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00039, "");
		}
	}
	
	private void validateGrossAmt3Digit2Decimal(TdsDetails rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getOrgGrossAmount()) && !ruleMethods.checkLength12(rawData.getGrossAmount(),rawData.isValid()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00039, "");
		}
	}
	
	private void validateTdsRate(TdsDetails rawData,InwardDroolUtil ruleMethods)
	{
		if(!isNumeric(rawData.getOrgTdsRate()) || !ruleMethods.twoDecimalHsnCheckBlank(rawData.getDocType(), rawData.getTdsRate()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00563, "");
		}
	}
	
	private void validateTdsRate3Digit2Decimal(TdsDetails rawData,InwardDroolUtil ruleMethods)
	{
		if(StringUtils.isNotBlank(rawData.getTdsRate()) && !ruleMethods.checkLength3LenTds(rawData.getTdsRate()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00563, "");
		}
	}
	
	private void validateTdsTaxAmount(TdsDetails rawData,InwardDroolUtil ruleMethods)
	{
		if(!isNumeric(rawData.getOrgTdsTaxAmount()) || !ruleMethods.checkLength12(rawData.getTdsTaxAmount(), rawData.isValid()))
		{
			markErrorNAddErrorCode(rawData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00528, "");
		}
	}
	
	
	private void idTdsFromTable(TdsDetails rowData, List<String> tdsSections) {
		if(StringUtils.isBlank(rowData.getTdsSection()) || !tdsSections.contains(rowData.getTdsSection()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00527, "");
		}
		
	}

	private void assAmtDecimalCheck(TdsDetails rowData, InwardDroolUtil ruleMethods) {

		if(StringUtils.isNotBlank(rowData.getAssAmt()) && !ruleMethods.checkLength12(rowData.getAssAmt(),rowData.isValid()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00021, "");
		}	
	}
	

	private void assAMtBlankCheck(TdsDetails rowData) {
		if(!isNumeric(rowData.getOrgAssAmount()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00235, "");
		       
		}
		
	}

	private void inwardNo16Length(TdsDetails rowData, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.check16CharacterLength(rowData.getInwardNo())) {
            markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00031, "");
        }
	}
	
	private void isValidInvoiceDateCheck(TdsDetails rowData, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.isValidInvoiceDate(rowData.getInwardAate())) {
            markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00313, "");
        }
	}
	
	private void isValidInvoiceDateFutureCheck(TdsDetails rowData, InwardDroolUtil ruleMethods) {
		boolean isValidDate=ruleMethods.isValidInvoiceDate(rowData.getInwardAate());
		boolean isValidFutureDate=ruleMethods.isValidFutureInvoiceDate(rowData.getInwardAate());
		if (isValidDate && !isValidFutureDate) {
			 markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00315, "");
        }
	}
	
	private void isValidDocDateFutureCheck(TdsDetails rowData, InwardDroolUtil ruleMethods) {
		if(StringUtils.isNotBlank(rowData.getDocDate()))
		{
			boolean isValidDate = ruleMethods.isValidInvoiceDate(rowData.getDocDate());
			boolean isValidFutureDate = ruleMethods.isValidFutureInvoiceDate(rowData.getDocDate());
			if (isValidDate && !isValidFutureDate) {
				markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00582, "");
			}
		}
	}
	
	
private void isValidInwardProvAdvDateFutureCheck(TdsDetails rowData, InwardDroolUtil ruleMethods) {
		
		boolean isValidDate=ruleMethods.isValidInvoiceDate(rowData.getInwardDateprovAdv());
		boolean isValidFutureDate=ruleMethods.isValidFutureInvoiceDate(rowData.getInwardDateprovAdv());
		if (isValidDate && !isValidFutureDate) {
			 markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00581, "");
        }
	}
	
	
	private void isValidDateOfPaymentFutureCheck(TdsDetails rowData, InwardDroolUtil ruleMethods) {
		boolean isValidDate=ruleMethods.isValidInvoiceDate(rowData.getDateofPayment());
		boolean isValidFutureDate=ruleMethods.isValidFutureInvoiceDate(rowData.getDateofPayment());
		if (isValidDate && !isValidFutureDate) {
			 markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00580, "");
        }
	}
	
	private void isValidChallanDateFutureCheck(TdsDetails rowData, InwardDroolUtil ruleMethods) {
		boolean isValidDate=ruleMethods.isValidInvoiceDate(rowData.getChallanDate());
		boolean isValidFutureDate=ruleMethods.isValidFutureInvoiceDate(rowData.getChallanDate());
		if (isValidDate && !isValidFutureDate) {
			 markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00579, "");
        }
	}

	
	
	private void inwardNoCheck(TdsDetails rowData, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.isInvoiceNoExist(rowData.getInwardNo())) {
            markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00030, "");
        } else if (!ruleMethods.isSpecialCharExistInInvoiceNo(rowData.getInwardNo())) {
            markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00054, "");
        }
	}
	
	private void docDateValidCheck(TdsDetails rowData, InwardDroolUtil ruleMethods) {
		if (StringUtils.isNotBlank(rowData.getDocDate()) && !ruleMethods.isValidInvoiceDate(rowData.getDocDate())) {
            markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00095, "");
        }
	}

	private void docNoSpecialCharCheck(TdsDetails rowData,InwardDroolUtil ruleMethods) {
		if(StringUtils.isNotBlank(rowData.getDocNo()) && !ruleMethods.isSpecialCharExistInInvoiceNo(rowData.getDocNo()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00093, "");
		}
		
	}

	private void validGSTINTaxpayer(TdsDetails rowData, InwardDroolUtil ruleMethods) {
		if (!ruleMethods.validGSTIN(rowData.getGstinUinOfRecipient())) {
            markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00517, "");
        }
	}
	
	private void validGstinCheck(TdsDetails rowData, InwardDroolUtil ruleMethods) {
		if (StringUtils.isNotBlank(rowData.getGstinOfSupplier()) &&  !ruleMethods.validTdsGSTIN(rowData.getGstinOfSupplier())) {
            markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00519, "");
        }
	}
	
	private void validVendorPan(TdsDetails rowData) {
		
		Pattern p=Pattern.compile(Constants.PANREGEX);
		Matcher m=p.matcher(rowData.getPanOfSupplier());
		if(!m.matches())
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.ERROR_CODE_E00330, "");
		}
		
	}

	private void validPanCheck(TdsDetails rowData) {
		if(StringUtils.isNotBlank(rowData.getPanOfRecipient()) &&  !rowData.getGstinUinOfRecipient().contains(rowData.getPanOfRecipient()))
		{
			markErrorNAddErrorCode(rowData, ValidationConstant.ERROR_CODE_E00567, "");
		}
		
	}

	private void checkForTaxPayerGstinEqualsSupplierGstin(TdsDetails rowData) {
        if (StringUtils.isNotBlank(rowData.getGstinUinOfRecipient())
                        && rowData.getGstinUinOfRecipient().equals(rowData.getGstinOfSupplier())) {
            markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00518, "");
        }
    }
	
	private void markErrorNAddErrorCode(TdsDetails rowData, String errorCode, String errorMsg) {
        rowData.setErrorCodeList(rowData.getErrorCodeList().append(errorCode));
        rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(errorMsg));
        rowData.setValid(false);
    }
	
	private void validateDocType(TdsDetails rowData) {
		List<String> docTypeList = new ArrayList<>(Arrays.asList("INV", "CRN","DBN"));
		if (StringUtils.isBlank(rowData.getDocType()) || !docTypeList.contains(rowData.getDocType())) {			
				markErrorNAddErrorCode(rowData, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00257, "");
			
		}
	}
	
	public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

}
