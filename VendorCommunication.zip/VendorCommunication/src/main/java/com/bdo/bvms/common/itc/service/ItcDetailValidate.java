package com.bdo.bvms.common.itc.service;

import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.dto.UploadReqDTO;

public interface ItcDetailValidate {

	void validateItcDto(List<ItcDto> itcDtoTemplateDTOList, UploadReqDTO uploadReqDTO,
			List<ItcDto> errorItcDtoTemplateDTOsList, List<ItcDto> sucessItcDtoTemplateDTOsList,Map<String,String> yearIdMap);

}
