package com.bdo.bvms.common.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * FileType: java Author : anka Created On : 02/11/2017 6:56:39 PM Copy Rights :
 * Anka Technology Solutions Pvt. Ltd.
 */

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ResponseBean implements Serializable {

	
    public ResponseBean(Integer invSuccessCount, Integer cdvSuccessCount, Integer errorCount) {
		super();
		this.invSuccessCount = invSuccessCount;
		this.cdvSuccessCount = cdvSuccessCount;
		this.errorCount = errorCount;
	}
	private static final long serialVersionUID = 8963887436856543497L;

    private String status = null;
    private String message = null;
    private boolean presentErrorRecords = false;
    private boolean presentSuccessRecords = false;
    private StringBuilder errorCodeList = new StringBuilder();
    private Integer invSuccessCount;
    private Integer cdvSuccessCount;
    private Integer errorCount;

}
