package com.bdo.bvms.common.tds.service;

import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;

public interface TdsDetailsUpload {

	 String validateAndSaveTdsDetails(UploadReqDTO uploadReqDTO, AzureConnectionCredentialsDTO storageCredentials);

}
