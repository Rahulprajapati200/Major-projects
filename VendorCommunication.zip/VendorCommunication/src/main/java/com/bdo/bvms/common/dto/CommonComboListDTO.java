package com.bdo.bvms.common.dto;

public class CommonComboListDTO  {

}
