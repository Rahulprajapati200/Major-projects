package com.bdo.bvms.common.exceptions;


public class InvoiceTemplateUploadException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvoiceTemplateUploadException() {
		super();
	}

	public InvoiceTemplateUploadException(Throwable cause) {

		super(cause);

	}

	public InvoiceTemplateUploadException(String message, Throwable cause) {

		super(message, cause);

	}
	
	public InvoiceTemplateUploadException(String message) {

		super(message);

	}


}
