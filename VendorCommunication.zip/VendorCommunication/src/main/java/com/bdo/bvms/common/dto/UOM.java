package com.bdo.bvms.common.dto;

import java.io.Serializable;
/**
 *FileType: java
 *Author : anka
 *Created On : 02/11/2017 6:56:39 PM
 *Copy Rights : Anka Technology Solutions Pvt. Ltd.
 */

public class UOM implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String keyword;
	private String description;

	public UOM() {
		//
	}

	public UOM(Integer id, String keyword, String description) {
		this.id = id;
		this.keyword = keyword;
		this.description = description;
	}
	
	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "UOM [id=" + id + ", keyword=" + keyword + ", description=" + description + "]";
	}
}
