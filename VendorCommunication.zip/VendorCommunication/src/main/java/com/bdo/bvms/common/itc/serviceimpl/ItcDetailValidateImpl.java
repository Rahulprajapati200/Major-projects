package com.bdo.bvms.common.itc.serviceimpl;

import java.util.Arrays;
import java.util.HashMap;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dao.InwardRegisterDao;

import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.itc.dao.ItcDao;
import com.bdo.bvms.common.itc.service.ItcDetailValidate;
import com.bdo.bvms.common.itc.validation.ValidateItcDetails;
import com.google.common.collect.Lists;
@Service
public class ItcDetailValidateImpl implements ItcDetailValidate{

	@Value("${mst.database-name}")
    private String mstDatabaseName;
	
	Map<String,String>purchageDnrInvoiceMap=new HashMap<>();
	Map<String,Integer>itcExcelDuplicateCHeckMap=new HashMap<>();
	Map<String, Map<String, String>> suppGSTNWiseMap = new HashMap<>();
    Map<String, String> yearIdMap = new HashMap<>();
	@Autowired
	ItcDao itcDao;
	
	@Autowired
	InwardRegisterDao commonCommunicationDao;
	@Override
	public void validateItcDto(List<ItcDto> itcDtoTemplateDTOList, UploadReqDTO uploadReqDTO,
			List<ItcDto> errorItcDtoTemplateDTOsList, List<ItcDto> sucessItcDtoTemplateDTOsList,Map<String,String> yearIdMap) {
		
		List<List<ItcDto>> partList = Lists.partition(itcDtoTemplateDTOList, Constants.THREADCOUNT);
		
		 String[] userGSTN = null;

	        if (Constants.PAN.equals(uploadReqDTO.getPanOrGstn())) {
	            userGSTN = commonCommunicationDao.getGstinFromDB(uploadReqDTO.getGstinOrPanList().get(0),
	            		mstDatabaseName);
	        } else if (Constants.GSTIN.equals(uploadReqDTO.getPanOrGstn())) {
	            userGSTN = uploadReqDTO.getGstinOrPanList()
	                            .toArray(new String[uploadReqDTO.getGstinOrPanList().size()]);

	        }
	        
	        String[] fpList = uploadReqDTO.getMonth().toArray(new String[uploadReqDTO.getMonth().size()]);
	        
	        for (List<ItcDto> sublist : partList) {
	           
	              runParallalProcessingValidations(itcDtoTemplateDTOList,sublist,
	            		uploadReqDTO, userGSTN, fpList,errorItcDtoTemplateDTOsList,sucessItcDtoTemplateDTOsList,yearIdMap);
	        }
	        purchageDnrInvoiceMap.clear();
	        itcExcelDuplicateCHeckMap.clear();
	        
	}
	private void runParallalProcessingValidations(List<ItcDto> itcDtoTemplateDTOList, List<ItcDto> sublist,
			UploadReqDTO uploadReqDTO, String[] userGSTN, String[] fpList, List<ItcDto> errorItcDtoTemplateDTOsList,
			List<ItcDto> sucessItcDtoTemplateDTOsList,Map<String,String> yearIdMap) {
		
		sublist.forEach(rowData->{
			ValidateItcDetails invDataTypeCheck = new ValidateItcDetails();
			invDataTypeCheck.validateItcDto(rowData);
             invDataTypeCheck = null;
			if (StringUtils.isBlank(rowData.getGstinUinOfRecipient())
					|| Arrays.stream(userGSTN).noneMatch(rowData.getGstinUinOfRecipient()::equalsIgnoreCase)) {
				markErrorNAddErrorCode(rowData, "|E00520", "");
			}
			
			isValidFp(rowData,fpList);
			
			paymentInvoiceExistsError(rowData);
			excelLevelDuplicateItcDetails(rowData);
             
             
		});
		
		sublist.forEach(rowData->
		{
			
			 int totalSize = sublist.size();
			checkForExcelDuplicateAgain(rowData);
			checkForSamFpDuplicate(rowData,totalSize,uploadReqDTO,yearIdMap);
			if(rowData.isValid())
            {
           	 sucessItcDtoTemplateDTOsList.add(rowData);
            }
            else {
           	 errorItcDtoTemplateDTOsList.add(rowData);
			}
			
			
			
		});
	}
	
	 private void isValidFp(ItcDto rowdata, String[] fpList) {

	        boolean fp = StringUtils.isNotBlank(rowdata.getFilingPeriod()) && rowdata.getFilingPeriod().length() == 6
	                        && rowdata.getFilingPeriod().matches("\\d+");
	        if (fp && Arrays.stream(fpList).noneMatch(rowdata.getFilingPeriod()::equalsIgnoreCase)) {
	        	markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00353, "");
	        }

	    }
	
	private void checkForSamFpDuplicate(ItcDto rowData,int totalSize,UploadReqDTO uploadReqDTO,Map<String,String> yearIdMap) {

        int isduplicateInvoiceInDiffMonth = 0;
        String supplierGstnInwardNo = rowData.getGstinOfSupplier() + rowData.getInwardNo();
        if (totalSize < 5000) {
            isduplicateInvoiceInDiffMonth = itcDao.getInwardResultFPCount(
                            rowData.getGstinUinOfRecipient(), rowData.getInwardNo(),
                            rowData.getInwardDate(), rowData.getGstinOfSupplier(), rowData.getFilingPeriod(), yearIdMap.get(rowData.getFilingPeriod()));

        } else {
            // Check invoice already saved in the GSTN
            String keyCheckInBatchData = rowData.getGstinUinOfRecipient() + uploadReqDTO.getBatchNo();
            List<String> invoiceList = null;
            if (suppGSTNWiseMap.get(keyCheckInBatchData) == null) {
                invoiceList = itcDao.getDuplicateFPInDiffMonth(
                                rowData.getGstinOfSupplier(), rowData.getGstinUinOfRecipient(),yearIdMap.get(rowData.getFilingPeriod()),
                                rowData.getFilingPeriod());
                Map<String, String> map = invoiceList.stream()
                                .collect(Collectors.toMap(str -> str, str -> str));
                suppGSTNWiseMap.put(keyCheckInBatchData, map);
                if (suppGSTNWiseMap.get(keyCheckInBatchData).get(supplierGstnInwardNo) != null) {
                    isduplicateInvoiceInDiffMonth++;
                }

            } else {
                Map<String, String> map = suppGSTNWiseMap.get(keyCheckInBatchData);
                if (map != null && map.get(supplierGstnInwardNo) != null) {
                    isduplicateInvoiceInDiffMonth++;
                }
            }
        }

        String mapKey = rowData.getInwardNo() + rowData.getGstinOfSupplier();

        if (StringUtils.isNotBlank(mapKey)) {
            mapKey = mapKey.toLowerCase();
        }

//        String itcClaimedKey = rowData.getGstinOfRecipient() + uploadRequestDTO.getBatchNo();
        if (isduplicateInvoiceInDiffMonth > 0) {
            markErrorNAddErrorCode(rowData, Constants.COMMUNICATION_ERROR_CODE_O0093, "");
        }
	}
	private void excelLevelDuplicateItcDetails(ItcDto rowData) {
	
		String mapKey=new StringBuilder().append(rowData.getGstinUinOfRecipient())
		.append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo()).append(rowData.getInwardDate()).toString();
		itcExcelDuplicateCHeckMap.put(mapKey, itcExcelDuplicateCHeckMap.getOrDefault(mapKey, 0)+1); 

		
	}	
		private void checkForExcelDuplicateAgain(ItcDto rowData) {

			String mapKey=new StringBuilder().append(rowData.getGstinUinOfRecipient())
			.append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo()).append(rowData.getInwardDate()).toString();
	
			
				if(itcExcelDuplicateCHeckMap.get(mapKey)>1)
				{
						rowData.setErrorCodeList(rowData.getErrorCodeList().append(Constants.ERROR_CODE_E00584));
						rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(""));
						rowData.setValid(false);
				}	
			
		}
	
	
	private void paymentInvoiceExistsError(ItcDto rowData) {
		StringBuilder mapKey=new StringBuilder().append(rowData.getGstinUinOfRecipient())
				.append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo());
		if(!purchageDnrInvoiceMap.containsKey(mapKey.toString()))
		{
			int count= itcDao.checkIfInvoiceDetailExits(rowData);
			if(count>0)
			{
				purchageDnrInvoiceMap.put(mapKey.toString(), mapKey.toString());
			}
			else
			{
				markErrorNAddErrorCode(rowData,Constants.ERROR_CODE_E00570 , "");
			}
		}
		
		
	}
	
	private void markErrorNAddErrorCode(ItcDto rowdata, String errorCode, String errorMsg) {
        rowdata.setErrorCodeList(rowdata.getErrorCodeList().append(errorCode));
        rowdata.setErrorDescriptionList(rowdata.getErrorDescriptionList().append(errorMsg));
        rowdata.setValid(false);
    }

}
