package com.bdo.bvms.common.util;

public class ErrorCodes {

	private ErrorCodes()
	{
		super();
	}
	public static final String INTERSTATECHECK = "40";
	public static final String INTRASTATECHECK = "41";
	public static final String TAXCALICULATIONWITHOUTDIFF = "102";
	public static final String TAXCALUCULATIONWITHDIFF = "103";
	public static final String INVOICEHAVESAMEDOCNO = "275";
}
