package com.bdo.bvms.common.dao;

import org.springframework.data.domain.Page;

import com.bdo.bvms.common.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.common.dto.UploadLogDto;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface VendorCommunicationUploadLogHistoryDao {

    Page<UploadLogDto> getHistoryList(UploadHistoryRequestDTO uploadHistoryRequestDTO)
                    throws VendorInvoiceServerException;

}
