package com.bdo.bvms.common.model;

import java.util.Date;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomTemplateName {

	Integer id;
	Integer pldTemplateId;
	String pan;
	Integer entityId;
	String name;
	String freeSearch;
	Date createdAt;
	Integer createdBy;
	Date modifiedAt;
	Integer modifiedBy;
	Integer pldStatus;
	
	
	//Added for user detail on custom template mapping
	String userName;
	
}
