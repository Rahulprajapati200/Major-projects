package com.bdo.bvms.common.itc.service;

import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvoiceTemplateUploadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface ReadCustomItcDetailTemplate {

	void readCustomTemplate(UploadReqDTO uploadReqDTO, List<ItcDto> itcDtoTemplateDTOList) throws InvoiceTemplateUploadException;

	void getInwardDataListCDV(UploadReqDTO uploadReqDTO, Map<String, String> customTemplateHeaderMappings,
			char delimiter, List<ItcDto> itcDtoTemplateDTOList) throws VendorInvoiceServerException;

}
