package com.bdo.bvms.common.itc.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.BDOException;

public interface WriteItcErrorAndSuccessCsv {

	void writeSuccessNErrorDataInCSVFile(UploadReqDTO uploadReqDTO, List<ItcDto> errorItcDtoTemplateDTOsList,
			List<ItcDto> sucessItcDtoTemplateDTOsList) throws IOException, BDOException;

	void writeAzureErrorDataInCSVFile(List<ItcDto> errorDataListWithErrorCode, UploadReqDTO uploadReqDTO,
			Map<String, String> codesMap) throws BDOException, IOException;

}
