package com.bdo.bvms.common.dto;

import java.sql.Date;

import org.springframework.data.relational.core.mapping.Column;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Getter
public class GstinAttachments {

    Integer id;

    @Column(value = "tvcr_id")
    Integer tvcrId;

    @Column(value = "tax_payer_gstin")
    String taxPayerGstin;

    @Column(value = "vendor_gstin")
    String vendorGstin;

    String name;

    @Column(value = "pld_document_type")
    Integer pldDocumentType;

    @Column(value = "document_type_name")
    String docType;

    String documentType;

    String path;

    Long size;

    @Column(value = "created_by")
    Integer createdBy;

    @Column(value = "uploaded_by")
    String uploadedBy;

    String createdByName;

    String createdByEmail;

    @Column(value = "modified_by")
    Integer modifiedBy;

    String modifiedByName;

    String modifiedByEmail;

    @Column(value = "modified_at")
    Date modifiedAt;

    @Column(value = "created_at")
    Date createdAt;

    @Column(value = "is_approved")
    Boolean isApproved;

    Date approvedAt;

    @Column(value = "approval_id")
    Integer approvalId;

    String remarks;

    @Column(value = "pld_module_id")
    String pldModuleId;

    @Column(value = "communication_reco_ref_id")
    int communicationRefId;
}
