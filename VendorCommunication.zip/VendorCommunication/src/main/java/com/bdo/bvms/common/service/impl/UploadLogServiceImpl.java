
package com.bdo.bvms.common.service.impl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.InwardRegisterDao;
import com.bdo.bvms.common.dao.impl.UploadTransDaoImpl;
import com.bdo.bvms.common.dto.InwardInvoiceCDNReqDTO;
import com.bdo.bvms.common.dto.UploadLogDto;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.dto.UploadStageLogDto;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.service.UploadLogService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UploadLogServiceImpl implements UploadLogService {

    @Autowired
    UploadTransDaoImpl uploadTransDao;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Autowired
    InwardRegisterDao commonCommunicationDao;

    @Override
    public void saveInUploadLog(InwardInvoiceCDNReqDTO uploadRequestDTO, String batchNo,UploadReqDTO uploadReqDTO)
                    throws VendorInvoiceServerException {

        UploadLogDto uploadLog = new UploadLogDto();
        Set<String> uniquePans = new HashSet<>();

        if (Constants.PAN.equals(uploadRequestDTO.getGstinOrPan())) {
            uploadLog.setTaxpayerPan(uploadRequestDTO.getGstinOrPanList().get(0));
            uploadLog.setTaxpayerGstin(String.join(",", commonCommunicationDao
                            .getGstinFromDB(uploadRequestDTO.getGstinOrPanList().get(0), mstDatabseName)));

        } else if (Constants.GSTIN.equals(uploadRequestDTO.getGstinOrPan())) {
            uploadLog.setTaxpayerGstin(String.join(",", uploadRequestDTO.getGstinOrPanList()));
            for (String gstin : uploadRequestDTO.getGstinOrPanList()) {
                String pan = gstin.substring(2, 12);
                uniquePans.add(pan);
            }
            uploadLog.setTaxpayerPan(String.join(",", new ArrayList<>(uniquePans)));

        }

        String fp = "";
        if (!"1".equals(uploadRequestDTO.getUploadSftpSource())) {
            fp = uploadRequestDTO.getMonth().toString().replace("[", "").replace("]", "").replace("{", "")
                            .replace("}", "").replace(" ", "");
        }
        if ("1".equals(uploadRequestDTO.getUploadSftpSource())) {
            uploadLog.setUploadSource(Constants.SFTPUPLOADSOURCE);
        } else {
            uploadLog.setUploadSource(Constants.WEBUPLOADSOURCE);
        }
        if (StringUtils.isBlank(uploadRequestDTO.getCustomtemplateID())
                        || "".equals(uploadRequestDTO.getCustomtemplateID())) {
            uploadRequestDTO.setCustomtemplateID("0");
        }
        uploadReqDTO.setFp(fp);
        uploadLog.setTemplateType(uploadRequestDTO.getTemplatetypepldCode());
        uploadLog.setFileSize(uploadRequestDTO.getFile().getSize());
        uploadLog.setFileName(uploadRequestDTO.getFile().getOriginalFilename());
        uploadLog.setBatchNo(batchNo);
        uploadLog.setPldUploadStatus(Constants.UPLOAD_INVOICES_PLD_STATUS_INPROGRESS);
        uploadLog.setFp(fp);
        uploadLog.setFileType(uploadRequestDTO.getFileType());
        uploadLog.setPldUploadSource(Constants.UPLOADSOURCE);
        uploadLog.setCustomTemplateId(Integer.valueOf(uploadRequestDTO.getCustomtemplateID()));
        uploadLog.setEntityId(uploadRequestDTO.getEntityId());
        uploadLog.setId(uploadRequestDTO.getUserId());
        uploadLog.setUploadStartTime(Timestamp.from(Instant.now()));
        uploadLog.setIsCustomTemplate(uploadRequestDTO.getIsCustomTemplate());
        uploadLog.setBaseFileLocation(batchNo + Constants.BASE_DOT + uploadRequestDTO.getFileType());
        uploadLog.setCreatedBy(String.valueOf(uploadRequestDTO.getUserId()));
        try {

            uploadTransDao.uploadTxLogDetails(uploadLog);

        } catch (Exception ex) {
            log.error(ex + " Error come in uploading file related data into database " + ex.getMessage());

        }

    }

    @Override
    public void saveInUploadStageLog(InwardInvoiceCDNReqDTO uploadRequestDTO, UploadReqDTO uploadReqDTO) {

        final String methodName = "";
        log.info(Constants.LOGMESSAGE, methodName);
        UploadStageLogDto uploadStageLogDto = new UploadStageLogDto();
        uploadStageLogDto.setUploadLogId(uploadReqDTO.getUploadLogId());
        uploadStageLogDto.setCreatedBy(uploadRequestDTO.getUserId());
        uploadStageLogDto.setBatchNo(uploadReqDTO.getBatchNo());
        uploadStageLogDto.setProcessStage(Constants.PROCESS_STAGE_FILE_UPLOAD);

        uploadStageLogDto.setProcessState(Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED);

        Timestamp createdAt = Timestamp.from(Instant.now());
        uploadStageLogDto.setCreatedAt(createdAt);
        try {

            uploadTransDao.insertStageNState(Constants.PROCESS_STAGE_FILE_UPLOAD,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadRequestDTO,
                            uploadReqDTO.getBatchNo());

        } catch (Exception ex) {
            log.error(Constants.LOGERRORMESSAGE, methodName);

        }

    }

    @Override
    public int getUploadLogId(String batchNo) throws VendorInvoiceServerException {
        return uploadTransDao.getUploadIdFromDB(batchNo);
    }

}
