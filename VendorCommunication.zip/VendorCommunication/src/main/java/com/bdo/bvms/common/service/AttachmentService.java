package com.bdo.bvms.common.service;

import java.io.File;
import java.util.List;

import javax.validation.Valid;

import com.bdo.bvms.common.dto.AddAttachmentsReqDTO;
import com.bdo.bvms.common.dto.AttachmentListDto;
import com.bdo.bvms.common.dto.AttacmentReqDTO;
import com.bdo.bvms.common.dto.SearchSystemParameterReqDTO;
import com.bdo.bvms.common.dto.SearchSystemParameterResDTO;
import com.bdo.bvms.common.dto.SearchVendorDetailsReqDTO;

public interface AttachmentService {

	List<AttachmentListDto> getAttachment(AttacmentReqDTO attacmentReqDTO);

	Object searchAttachments(@Valid SearchVendorDetailsReqDTO searchVendorDetailsReqDTO);

	SearchSystemParameterResDTO searchSystemParameter(SearchSystemParameterReqDTO build);

	Object addVendorAttachments(List<File> fileList, AddAttachmentsReqDTO addAttachmentsReqDTO);

}
