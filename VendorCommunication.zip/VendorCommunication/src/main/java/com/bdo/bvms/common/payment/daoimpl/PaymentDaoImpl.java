package com.bdo.bvms.common.payment.daoimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.constant.Constants;

import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.PaymentResponseBean;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.payment.dao.PaymentDao;
import com.bdo.bvms.common.sql.CommunicationSQL;
import com.bdo.bvms.common.util.AppLogger;

import lombok.extern.slf4j.Slf4j;
@Repository
@Slf4j
public class PaymentDaoImpl implements PaymentDao{
	 @Autowired
	 private JdbcTemplate jdbcTemplateTrn;
	
	   /** The mst database name. */
	    @Value("${mst.database-name}")
	    private String mstDatabaseName;

	    /** The trn database name. */
	    @Value("${txn.database-name}")
	    private String trnDatabaseName;
	 
	 
	@Override
	public PaymentResponseBean gstInwardInvCdnInsert(String csvPaymentSuccessFilePath, String csvPaymentErrorFilePath,
			String successPaymentTable, String failurePaymentTable) {
    final String methodName = "gstInwardInvCdnInsert";
    int paymentSuccessCount = 0;
    int paymentInvErrorCount = 0;

    log.info(Constants.LOGMESSAGE, methodName);
    String query;

    PaymentResponseBean response = new PaymentResponseBean();

    try {

        query = CommunicationSQL.INSERT_FILE_SQL.replace("table_name", successPaymentTable);
        AppLogger.info(Constants.BLANK, methodName, "query = " + query);
        paymentSuccessCount = saveData(csvPaymentSuccessFilePath, query);
        AppLogger.info(Constants.BLANK, methodName, "successCount = " + paymentSuccessCount);


        query = CommunicationSQL.INSERT_FILE_SQL.replace("table_name", failurePaymentTable);
        paymentInvErrorCount = saveData(csvPaymentErrorFilePath, query);
        AppLogger.info(Constants.BLANK, methodName, "errorCount = " + paymentInvErrorCount);

        response.setPaymentSuccessCount(paymentSuccessCount);
        response.setErrorCount(paymentInvErrorCount);
    } catch (Exception e) {
        log.error(Constants.LOGERRORMESSAGE, methodName, e);
    }
    return response;
}


private Integer saveData(String filePath, String query) throws VendorInvoiceServerException {

    final String methodName = "";
    log.info(Constants.LOGMESSAGE, methodName);
    Integer count = 0;
    try {
        count = jdbcTemplateTrn.update(query, filePath);

    } catch (Exception e) {
        log.error(Constants.LOGERRORMESSAGE, methodName + e);
        throw new VendorInvoiceServerException("E0006", e);
    }
    return count;
}


@Override
public List<PaymentDetails> getPaymentErrorDataListWithErrorCode(UploadReqDTO uploadReqDTO) {
    StringBuilder builder = new StringBuilder();
    builder.append("SELECT error_codes,error_description ,gstin_uin_of_recipient,doc_type,gstin_of_supplier ,supplier_name,payment_fp,")
    .append("inward_no ,inward_date,date_of_payment,invoice_against_prov_adv,inward_no_prov_adv ,payment_amount,")
    .append("payment_ref_no,udf_1 ,udf_2,udf_3 ,udf_4,udf_5 ,udf_6 ,udf_7,udf_8 ,udf_9,udf_10,udf_11,")
    .append("udf_12,udf_13 ,udf_14 ,udf_15,udf_16 ,udf_17 ,udf_18,udf_19 ,udf_20")
    .append(" FROM    inward_purchase_register_payment_details_error")
    .append(" WHERE    batch_no = '").append(uploadReqDTO.getBatchNo())
    .append("' and error_codes != ''");
    
    
    return jdbcTemplateTrn.query(builder.toString(), new ResultSetExtractor<List<PaymentDetails>>() {

        @Override
        public List<PaymentDetails> extractData(ResultSet rs)
                        throws SQLException, DataAccessException {

            List<PaymentDetails> listOFBatchData = new ArrayList<>();
            while (rs.next()) {
            	PaymentDetails template = new PaymentDetails();
            	template.setGstinUinOfRecipient(rs.getString("gstin_uin_of_recipient"));
                template.setDocType(rs.getString("doc_type"));
                template.setInwardNo(rs.getString("inward_no"));
                template.setInwardDate(rs.getString("inward_date"));
                template.setGstinOfSupplier(rs.getString("gstin_of_supplier"));
                template.setSupplierName(rs.getString("supplier_name"));
                template.setDateOfPayment(rs.getString("date_of_payment"));
                template.setAmountofPayment(rs.getString("payment_amount"));
                template.setPaymentRefNo(rs.getString("payment_ref_no"));
                template.setInvAgainstProv(rs.getString("invoice_against_prov_adv"));
                template.setInwardNoProvAdv(rs.getString("inward_no_prov_adv"));
                template.getErrorCodeList().append(rs.getString("error_codes"));
                template.setFilingPeriod(rs.getString("payment_fp"));
                template.setUdf1(rs.getString("udf_1"));
                template.setUdf2(rs.getString("udf_2"));
                template.setUdf3(rs.getString("udf_3"));
                template.setUdf4(rs.getString("udf_4"));
                template.setUdf5(rs.getString("udf_5"));
                template.setUdf6(rs.getString("udf_6"));
                template.setUdf7(rs.getString("udf_7"));
                template.setUdf8(rs.getString("udf_8"));
                template.setUdf9(rs.getString("udf_9"));
                template.setUdf10(rs.getString("udf_10"));
                template.setUdf11(rs.getString("udf_11"));
                template.setUdf12(rs.getString("udf_12"));
                template.setUdf13(rs.getString("udf_13"));
                template.setUdf14(rs.getString("udf_14"));
                template.setUdf15(rs.getString("udf_15"));
                template.setUdf16(rs.getString("udf_16"));
                template.setUdf17(rs.getString("udf_17"));
                template.setUdf18(rs.getString("udf_18"));
                template.setUdf19(rs.getString("udf_19"));
                template.setUdf20(rs.getString("udf_20"));
                listOFBatchData.add(template);
            }
            return listOFBatchData;
        }
    });

}


@Override
public int checkIfInvoiceDetailExits(PaymentDetails rowData) {
	
	return jdbcTemplateTrn.queryForObject("INV".equals(rowData.getDocType())?CommunicationSQL.COUNTPAYMENTDATA:CommunicationSQL.COUNTPAYMENTDATAINDNR,Integer.class
			,rowData.getInwardNo(),rowData.getGstinUinOfRecipient(),rowData.getGstinOfSupplier());
	
}


@Override
public int checkPaymentDataExitsInTable(PaymentDetails rowData) {

	return jdbcTemplateTrn.queryForObject(CommunicationSQL.COUNTPAYMENTDATADUPLICATE,Integer.class
			,rowData.getInwardNo(),rowData.getGstinUinOfRecipient(),rowData.getGstinOfSupplier(),rowData.getDocType(),rowData.getAmountofPayment(),rowData.getPaymentRefNo(),
			rowData.getInwardDate(),rowData.getDateOfPayment());
	
}


@Override
public Set<String> getPaymentItemMap(PaymentDetails rowData) {
	return jdbcTemplateTrn.query(CommunicationSQL.PAYMENTITEMSQL, new ResultSetExtractor<Set<String>>()
			{

				@Override
				public Set<String> extractData(ResultSet rs) throws SQLException, DataAccessException {
					
					Set<String>m=new HashSet<>();
					while(rs.next())
					{
						m.add(rs.getString("payment_key"));
					}
					return m;
				}
				
		
			},rowData.getGstinUinOfRecipient(),rowData.getGstinOfSupplier(),rowData.getInwardNo());
	
}




@Override
   public int getInwardResultFPCount(String gstinUinOfRecipient, String inwardNo, String inwardDate,
                   String gstinOfSupplier, String fp, String yearId) {

       final String methodName = "";

       log.info(Constants.LOGMESSAGE, methodName);
       try {

           String sqlstr = CommunicationSQL.getPaymentResultSql( inwardDate, gstinOfSupplier, fp, yearId,
                           mstDatabaseName, trnDatabaseName);

           return jdbcTemplateTrn.queryForObject(sqlstr, Integer.class, gstinUinOfRecipient, gstinOfSupplier, yearId,
                           fp, inwardNo);

       } catch (Exception ex) {
           log.error(Constants.LOGERRORMESSAGE, methodName);
           return 0;
       }

   }


@Override
   public List<String> getDuplicateFPInDiffMonth(String gstinOfSupplier, String gstinUinOfRecipient, String yearId,
                   String fp) {

       String sqlString = CommunicationSQL.getPaymentDuplicateFPQuery(trnDatabaseName, mstDatabaseName);

       return jdbcTemplateTrn.queryForList(sqlString, String.class, gstinUinOfRecipient, yearId, fp);

   }





}
