package com.bdo.bvms.common.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import com.bdo.bvms.common.model.CustomTemplateColumnMapping;
import com.bdo.bvms.common.model.CustomTemplateColumnValueMapping;
import com.bdo.bvms.common.model.CustomTemplateDetails;
import com.bdo.bvms.common.model.CustomTemplateName;
import com.bdo.bvms.common.model.CustomTemplateOptionValueDetails;
import com.bdo.bvms.common.model.CustomTemplateOptions;
import com.bdo.bvms.common.model.TemplateColumnConfig;
import com.bdo.bvms.common.model.TemplateSampleData;

public interface ICustomTemplateRepository {

	List<TemplateColumnConfig> getCustomTemplateColumnConfig(TemplateColumnConfig customTemplateColumnConfig);

	void insertCustomTemplateColumnValueMapping(
			List<CustomTemplateColumnValueMapping> customTemplateColumnValueMappingList);

	Integer insertCustomTemplateColumnMapping(CustomTemplateColumnMapping customTemplateColumnMapping);

	Integer insertCustomTemplateName(CustomTemplateName customTemplateName);

	

	List<CustomTemplateOptions> getCustomTemplateOptions(CustomTemplateOptions customTemplateOptions);

	

	

	PageImpl<CustomTemplateName> getCustomTemplatesName(CustomTemplateName customTemplateNameReq , Pageable paging);

	List<CustomTemplateName> getCustomTemplateNames(CustomTemplateName customTemplateNameReq);

	int updateCustomTemplateStatus(CustomTemplateName customTemplateName);

	CustomTemplateName getCustomTemplateName(CustomTemplateName customTemplateName);

	Map<String,Map<String,Integer>> searchCustomTemplateOptionsMappings(int customTemplateId, String primaryContactLkUpName,String defaultAddressLkUpName, String primaryBankLkUpName,String addressTypeLkUpName);

	Map<String, String> searchCustomTemplateHeaderMappings(int customTemplateId);
	
	void insertTemplateSampleData(TemplateSampleData templateSampleData);

	List<CustomTemplateDetails> getCustomTemplateMappingDetails(CustomTemplateName customTemplateName);

	List<CustomTemplateOptionValueDetails> getCustomTemplateOptionsValueMapping(CustomTemplateColumnMapping customTemplateColumnMapping);

	CustomTemplateColumnMapping checkIfCustomTemplateColumnMappingExists(
			CustomTemplateColumnMapping customTemplateColumnMapping);

	int updateCustomTemplateMapping(CustomTemplateColumnMapping customTemplateColumnMapping);

	CustomTemplateColumnValueMapping checkIfCustomTemplateColumnValueMappingExistsById(
			CustomTemplateColumnValueMapping customTemplateColumnValueMapping);

	int updateCustomTemplateColumnValueMapping(CustomTemplateColumnValueMapping customTemplateColumnValueMapping);

	CustomTemplateColumnValueMapping checkIfCustomTemplateColumnValueMappingExists(
			CustomTemplateColumnValueMapping customTemplateColumnValueMapping);

	CustomTemplateName getCustomTemplateNameById(CustomTemplateName customTemplateName);

	List<TemplateSampleData> getCustomTemplateSampleData(TemplateSampleData templateSampleData);

}
