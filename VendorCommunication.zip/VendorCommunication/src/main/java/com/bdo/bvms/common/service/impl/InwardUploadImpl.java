package com.bdo.bvms.common.service.impl;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.constant.StringConstant;
import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dao.CommonDao;
import com.bdo.bvms.common.dao.CustomTemplateRepo;
import com.bdo.bvms.common.dao.InwardRegisterDao;
import com.bdo.bvms.common.dao.UploadTransDao;
import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.ExceptionLogDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.ResponseBean;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvalidTemplateHeaderException;
import com.bdo.bvms.common.exceptions.InvoiceTemplateUploadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.service.CsvWriterService;
import com.bdo.bvms.common.service.InwardUpload;
import com.bdo.bvms.common.service.UploadNDownloadFileService;
import com.bdo.bvms.common.sql.CommunicationSQL;
import com.bdo.bvms.common.util.AppUtil;
import com.bdo.bvms.common.util.CommonUtils;
import com.bdo.bvms.common.util.DateUtil;
import com.bdo.bvms.common.util.ErrorCodes;
import com.bdo.bvms.common.util.InwardCDNBDRL;
import com.bdo.bvms.common.util.InwardITCInvoiceBDRL;
import com.bdo.bvms.common.validationrule.DroolUtil;
import com.bdo.bvms.common.validationrule.InwardCDNValidationRules;
import com.bdo.bvms.common.validationrule.InwardICDNDataTypeValidations;
import com.bdo.bvms.common.validationrule.InwardINVDataTypeValidations;
import com.bdo.bvms.common.validationrule.InwardINVValidationRules;
import com.csvreader.CsvReader;
import com.google.common.collect.Lists;
import com.monitorjbl.xlsx.StreamingReader;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class InwardUploadImpl.
 */
//notification_master
@Service

/** The Constant log. */
@Slf4j
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class InwardUploadImpl implements InwardUpload {

    /** The mst databse name. */
    @Value("${mst.database-name}")
    private String mstDatabseName;

    /** The trn database name. */
    @Value("${txn.database-name}")
    private String trnDatabaseName;

    /** The input type list. */
    List<String> inputTypeList = new ArrayList<>();

    /** The item level error map. */
    Map<String, String> itemLevelErrorMap = new ConcurrentHashMap<>();

    /** The line level error. */
    Map<String, Set<String>> lineLevelError = new HashMap<>();

    /** The doc level error. */
    Map<String, Set<String>> docLevelError = new HashMap<>();
    Map<String, Set<String>> cdnDocLevelError = new HashMap<>();
    /** The year id map. */
    Map<String, String> yearIdMap = new HashMap<>();

    /** The state code map. */
    Map<String, String> stateCodeMap = new HashMap<>();

    /** The port code map. */
    Map<String, String> portCodeMap = new HashMap<>();

    /** The govt rate map. */
    List<String> govtRateMap = new ArrayList<>();

    /** The cdn state code map. */
    Map<String, String> cdnStateCodeMap = new HashMap<>();

    /** The cdn port code map. */
    Map<String, String> cdnPortCodeMap = new HashMap<>();

    /** The cdn govt rate map. */
    List<String> cdnGovtRateMap = new ArrayList<>();

    /** The hsn id. */
    String hsnId = null;

    /** The cdn level error map. */
    Map<String, String> cdnLevelErrorMap = new ConcurrentHashMap<>();

    /** The cdn line level error. */
    Map<String, Set<String>> cdnLineLevelError = new HashMap<>();

    List<String>tdsSections=new ArrayList<>();
    
    Set<String>sftpSet=new HashSet<>();
    /**
     * Instantiates a new inward upload impl.
     */
    public InwardUploadImpl() {
        inputTypeList.add("IN");
        inputTypeList.add("INS");
        inputTypeList.add("CG");
        inputTypeList.add("0");
    }

    /** The fp. */
    String fp = "";

    /** The row INV success po jo list. */
    List<InwardInvoiceCDNTemplateDTO> rowINVSuccessPoJoList = null;

    /** The row CRN success po jo list. */
    List<InwardInvoiceCDNTemplateDTO> rowCRNSuccessPoJoList = null;

    /** The row inv error po jo list. */
    List<InwardInvoiceCDNTemplateDTO> rowInvErrorPoJoList = null;

    /** The row cdn error po jo list. */
    List<InwardInvoiceCDNTemplateDTO> rowCdnErrorPoJoList = null;

    /** The row doc error pojo list. */
    List<InwardInvoiceCDNTemplateDTO> rowDocErrorPojoList = null;

    /** The header row. */
    Row headerRow = null;

    /** The year id. */
    String yearId = null;

    /** The csv writer service. */
    @Autowired
    CsvWriterService csvWriterService;

    /** The upload trans dao. */
    @Autowired
    UploadTransDao uploadTransDao;

    /** The common dao. */
    @Autowired
    CommonDao commonDao;

    /** The common communication dao. */
    @Autowired
    InwardRegisterDao commonCommunicationDao;

    /** The custom template inward read. */
    @Autowired
    CustomTemplateEInvoiceReadImpl customTemplateInwardRead;

    /** The upload N download file service. */
    @Autowired
    UploadNDownloadFileService uploadNDownloadFileService;

    /** The col name index map. */
    Map<String, Integer> colNameIndexMap = new HashMap<>();

    /** The temp folder. */
    @Value("${bvms.cloud.temp.file.download.path}")
    String tempFolder;

    /** The json objfor doc mapping. */
    JSONObject jsonObjforDocMapping = null;

    
    Map<String,Map<String,String>>saveCdnMap=new HashMap<>(); 
    
    /** The json objfor supply mapping. */
    JSONObject jsonObjforSupplyMapping = null;

	@Autowired
	CustomTemplateRepo customeTemplateRepo;

    
    /**
     * Validate and save data.
     *
     * @param reqDto
     *            the upload request DTO
     * @param storageCredentials
     *            the storage credentials
     * @return the string
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Async
    @Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
    @Override
    public String validateAndSaveData(UploadReqDTO reqDto, AzureConnectionCredentialsDTO storageCredentials)
                    throws IOException, VendorInvoiceServerException {

        String methodName = "validateAndSaveData";

        List<InwardInvoiceCDNTemplateDTO> invDataList = new ArrayList<>();
        List<InwardInvoiceCDNTemplateDTO> cdnDataList = new ArrayList<>();

        rowINVSuccessPoJoList = new ArrayList<>();
        rowCRNSuccessPoJoList = new ArrayList<>();
        rowInvErrorPoJoList = new ArrayList<>();
        rowCdnErrorPoJoList = new ArrayList<>();
        rowDocErrorPojoList = new ArrayList<>();

        try {
        	uploadTransDao.commonPostNotification(Constants.COMMUNICATIONMSTID, Constants.INWARD_FILE_IN_PROGRESS,
        			reqDto.getUserId(), reqDto.getUserId(), reqDto.getUserId(), mstDatabseName,
                    Constants.NOTIFICATION_INITIATED);
        	uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_PROCESSING,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_START, reqDto);
            // Add entry in the process steps
            uploadTransDao.updateProcessStatus(reqDto.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_INPROGRESS);

            // Add notification
            addInNotification(reqDto);
            yearIdMap = commonCommunicationDao.getYearId();
            
            if (Constants.XLSX.equalsIgnoreCase(reqDto.getFileType())) {
                if (Constants.ISDEFAULTTEMPLATE.equals(reqDto.getIsCustomTemplate())) {
                    readDataFromExcel(reqDto, invDataList, cdnDataList);
                } else if (Constants.ISCUSTOMETEMPLATE.equals(reqDto.getIsCustomTemplate())) {
                    customTemplateInwardRead.readCustomTemplate(reqDto,invDataList,cdnDataList,rowDocErrorPojoList);
                }
            } else if (Constants.CSV.equalsIgnoreCase(reqDto.getFileType())) {
            	if (reqDto.getIsCustomTemplate().equals(Constants.ISDEFAULTTEMPLATE)) {
            		 readCSVFile(reqDto, invDataList, cdnDataList);
                }else if (reqDto.getIsCustomTemplate().equals(Constants.ISCUSTOMETEMPLATE)) {
                    Map<String, String> customTemplateHeaderMappings = CommonUtils
                            .getCustomTemplateHeaderMappings(reqDto, customeTemplateRepo);
                    customTemplateInwardRead.getInwardDataListCDV(reqDto,
                            customTemplateHeaderMappings, Constants.DELIMITER,invDataList,cdnDataList,rowDocErrorPojoList);
               }
               
            } else {
                return Constants.FILEFORMATNOTALLOWED;
            }
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_PROCESSING,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, reqDto);
            // updating time Stamp in upload_log table
            uploadTransDao.updateTimeStamp(CommunicationSQL.UPDATE_VALIDATION_START_TIME_STAMP, reqDto);

            // updating stages in upload_stage_log table
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_VALIDATION,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_START, reqDto);
            // Update total Count in the upload log table
            uploadTransDao.updateTotalCountAndDocErrorCount(
                            invDataList.size() + cdnDataList.size() + rowDocErrorPojoList.size(),
                            rowDocErrorPojoList.size(), reqDto);

            if (!invDataList.isEmpty()) {
                startProcessingInvoiceData(invDataList, reqDto);
            }
            if (!cdnDataList.isEmpty()) {
                startProcessingCrnData(cdnDataList, reqDto);
            }

            rowCdnErrorPoJoList.addAll(rowDocErrorPojoList);

            // upload_stage_log Table stage updating
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_VALIDATION,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, reqDto);

            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_COMPLETED,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_START, reqDto);


            csvWriterService.writeSuccessNErrorDataInCSVFile(reqDto, rowCRNSuccessPoJoList, rowINVSuccessPoJoList,
                            rowInvErrorPoJoList, rowCdnErrorPoJoList);

            String csvInvSuccessFilePath = CommonUtils.getINVSuccessFilePath(reqDto, tempFolder);
            String csvCdnSuccessFilePath = CommonUtils.getCDNSuccessFilePath(reqDto, tempFolder);
            String csvInvErrorFilePath = CommonUtils.getInvErrorFilePath(reqDto, tempFolder);
            String csvCdnErrorFilePath = CommonUtils.getCdnErrorFilePath(reqDto, tempFolder);

            uploadTransDao.updateTimeStamp(CommunicationSQL.UPDATE_VALIDATION_START_TIME_STAMP, reqDto);

            ResponseBean responseBean = commonCommunicationDao.gstInwardInvCdnInsert(csvInvSuccessFilePath,
                            csvCdnSuccessFilePath, csvInvErrorFilePath, csvCdnErrorFilePath,
                            Constants.SUCCESS_INV_TABLE, Constants.SUCCESS_CDN_TABLE, Constants.FAILURE_INV_TABLE,
                            Constants.FAILURE_CDN_TABLE);

            uploadTransDao.updateErrorNSuccessCountAndTotalCount(responseBean, rowDocErrorPojoList,
                            reqDto.getBatchNo());


            Map<String, String> codesMap = commonDao.getErrorCodesDescription();

            List<InwardInvoiceCDNTemplateDTO> errorDataListWithErrorCode = commonCommunicationDao
                            .getErrorDataListWithErrorCode(reqDto);

            if (!rowCdnErrorPoJoList.isEmpty() || !rowInvErrorPoJoList.isEmpty()) {
                csvWriterService.writeAzureErrorDataInCSVFile(errorDataListWithErrorCode, reqDto, codesMap);
                uploadNDownloadFileService.uploadErrorFile(reqDto, storageCredentials);
            }

           

            // Update File name into Database which is uploaded on the Azure
            String csvInvCdnErrorFilePath = CommonUtils.getAzureInvErrorFilePath(reqDto, tempFolder);
            File file = new File(csvInvCdnErrorFilePath);
            if (file.exists() && responseBean.getErrorCount() > 0) {
                uploadTransDao.updateErrorFileName(reqDto.getBatchNo(),
                                reqDto.getBatchNo() + Constants.ERROR_DOT_CSV_AZURE_INV);
            }
            // Update PLD status in upload_log table

            // Exception Handling and Updating in the exception_log table in
            // Database
            communicationArchivedInwardUploadData(reqDto, methodName);
            if (responseBean != null && responseBean.getErrorCount() > 0) {
                uploadTransDao.updateProcessStatus(reqDto.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_ERROR);
                uploadTransDao.commonPostNotification(Constants.COMMUNICATIONMSTID,
                                Constants.INWARD_FILE_UPLOAD_ERROR + reqDto.getBatchNo(), reqDto.getUserId(),
                                reqDto.getUserId(), reqDto.getUserId(), mstDatabseName, Constants.NOTIFICATION_ERROR);

            } else {
                uploadTransDao.updateProcessStatus(reqDto.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_COMPLETED);
                if (responseBean != null) {
                    uploadTransDao.commonPostNotification(Constants.COMMUNICATIONMSTID,
                                    Constants.INWARDFILEUPLOADED + reqDto.getBatchNo(), reqDto.getUserId(),
                                    reqDto.getUserId(), reqDto.getUserId(), mstDatabseName,
                                    Constants.NOTIFICATION_SUCCESS);
                }
            }
           
            
            

            
            uploadTransDao.updateTimeStamp(CommunicationSQL.UPDATE_VALIDATION_FINAL_TIME_STAMP, reqDto);
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_COMPLETED,
                    Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, reqDto);
        } catch (InvalidTemplateHeaderException ex) {
        	uploadTransDao.updateTimeStamp(CommunicationSQL.UPDATE_VALIDATION_FINAL_TIME_STAMP, reqDto);
        	uploadTransDao.commonPostNotification(Constants.COMMUNICATIONMSTID, Constants.INVALID_TEMPLATE,
        			reqDto.getUserId(), reqDto.getUserId(), reqDto.getUserId(), mstDatabseName,
                    Constants.NOTIFICATION_FAILED);
            uploadTransDao.updateProcessStatusWithRemarks(reqDto.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE, ex.getMessage());
        }        
        catch (Exception ex) {
        	uploadTransDao.updateTimeStamp(CommunicationSQL.UPDATE_VALIDATION_FINAL_TIME_STAMP, reqDto);
            log.error(Constants.PROCESSINGFILEEXCEPTIONLOG + reqDto.getBatchNo(), ex);
            uploadTransDao.commonPostNotification(Constants.COMMUNICATIONMSTID,
                    Constants.FAILED + reqDto.getBatchNo(), reqDto.getUserId(), reqDto.getUserId(),
                    reqDto.getUserId(), mstDatabseName, Constants.NOTIFICATION_FAILED);
            log.error("Error generated:", ex);
            uploadTransDao.updateProcessStatus(reqDto.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            uploadTransDao.updateErrorNSuccessCountAndTotalCount(new ResponseBean(0, 0, 0), new ArrayList<>(),
                            reqDto.getBatchNo());
            logIntoToExceptionTable(reqDto, ex, methodName);
        }
        finally {
        	CommonUtils.deleteTempFiles(tempFolder, reqDto);
		}
        return Constants.FILEUPLOADEDSUCCESSFUL;
    }

	private void communicationArchivedInwardUploadData(UploadReqDTO reqDto, String methodName) {
		try {
		    uploadTransDao.vendorCommunicationArchiveInwardUploadData(reqDto);
		}catch(Exception e)
		{
			log.error("Exception in method : ",methodName,"while calling Procedure vendor_communication_archive_inward_upload_data");
		}
	}

    /**
     * Adds the in notification.
     *
     * @param uploadRequestDTO
     *            the upload request DTO
     */
    @Override
    public void addInNotification(UploadReqDTO uploadRequestDTO) {
        try {
            uploadTransDao.commonPostNotification(Constants.COMMUNICATIONMSTID,
                            Constants.INWARD_FILE_IN_PROGRESS + uploadRequestDTO.getBatchNo(),
                            uploadRequestDTO.getUserId(), uploadRequestDTO.getUserId(), uploadRequestDTO.getUserId(),
                            mstDatabseName, Constants.NOTIFICATION_INITIATED);
        } catch (Exception e) {
            log.error("Error generated while posting notification::", e);
        }
    }

    
    
    /**
     * Gets the csv E invoice data list.
     *
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param rowINVPoJoList
     *            the row INV po jo list
     * @param rowCRNPoJoList
     *            the row CRN po jo list
     * @return the csv E invoice data list
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    private void readCSVFile(UploadReqDTO uploadRequestDTO, List<InwardInvoiceCDNTemplateDTO> rowINVPoJoList,
                    List<InwardInvoiceCDNTemplateDTO> rowCRNPoJoList) throws IOException, VendorInvoiceServerException {
        int cnt = 0;
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadRequestDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(uploadRequestDTO.getFileType());

        CsvReader einvoices = new CsvReader(fileName.toString(), StringConstant.COMMASEPERATOR, StandardCharsets.UTF_8);
        CsvReader readHeaderCount = new CsvReader(fileName.toString(), StringConstant.COMMASEPERATOR,
                        StandardCharsets.UTF_8);

        // Add code if header is missing then mark as invalid template
        String[] indexHeaders = AppUtil.getHeaders(readHeaderCount);
        if (Constants.E_INVOICE_TEMPLATE_COLUMN_COUNT != indexHeaders.length) {

            uploadTransDao.updateProcessStatus(uploadRequestDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);

            throw new VendorInvoiceServerException(
                            StringConstant.HEADERCOUNTERRORMESSAGE + uploadRequestDTO.getBatchNo());

        }

        einvoices.readHeaders();
        while (einvoices.readRecord()) {
            InwardInvoiceCDNTemplateDTO inwardInvoiceCDNTemplateDTO = new InwardInvoiceCDNTemplateDTO();
            try {

                cnt++;
                if (cnt > 0) {
                	inwardInvoiceCDNTemplateDTO.setValid(true);
                	inwardInvoiceCDNTemplateDTO.setPeriodOfFiling(einvoices.get("period_of_filing")
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setGstinOfRecipient(
                                    einvoices.get(0).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setExcelDocType(einvoices.get(Constants.COLUMN_DOC_TYPE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setOrgDocType(einvoices.get(Constants.COLUMN_DOC_TYPE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setDocType(einvoices.get(Constants.COLUMN_DOC_TYPE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setSupplyType(einvoices.get(Constants.COLUMN_SUPPLY_TYPE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setDocNo(einvoices.get(Constants.COLUMN_DOC_NO)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setDocDate(DateUtil.getFormatedDate(einvoices.get(Constants.COLUMN_DOC_DATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
                    inwardInvoiceCDNTemplateDTO.setOrgSupplyType(einvoices.get(Constants.COLUMN_SUPPLY_TYPE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setOrgDiffPercent(einvoices.get(Constants.COLUMN_DIFF_PERCENT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setOrgAssAmt(einvoices.get(Constants.COLUMN_ASS_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setOrgItemRate(einvoices.get(Constants.COLUMN_ITEM_RATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setOrgImportType(einvoices.get(Constants.COLUMN_INPUT_TYPE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setOrgInvoiceNo(einvoices.get(Constants.COLUMN_ORG_INVOICE_NO)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setFillingPeriod(einvoices.get(Constants.FILLING_PERIOD)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));;
                    inwardInvoiceCDNTemplateDTO.setOrgInvoiceDate(DateUtil.getFormatedDate(einvoices.get(Constants.COLUMN_ORG_INVOICE_DATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
                    inwardInvoiceCDNTemplateDTO.setGstinOfSupplier(einvoices.get(Constants.COLUMN_GSTIN_OF_SUPPLIER)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setSupplierName(einvoices.get(Constants.COLUMN_SUPPLIER_NAME)
                                    .replaceAll("[^A-Za-z0-9_\\-]", Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setOrgInvoiceCategory(einvoices.get(Constants.COLUMN_SUPPLY_TYPE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setSupplierStateCode(einvoices.get(Constants.COLUMN_SUPPLIER_STATE_CODE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setInwardNo(einvoices.get(Constants.COLUMN_INWARD_NO)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setInwardDate(DateUtil.getFormatedDate(einvoices.get(Constants.COLUMN_INWARD_DATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
                    inwardInvoiceCDNTemplateDTO.setHsnSacCode(einvoices.get(Constants.COLUMN_HSN_CODE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setOrgSgstRate(einvoices.get(Constants.COLUMN_SGST_RATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    
                    inwardInvoiceCDNTemplateDTO.setOrgSgstAmt(einvoices.get(Constants.COLUMN_SGST_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    
                  
                    
                    inwardInvoiceCDNTemplateDTO.setOrgCgstRate(einvoices.get(Constants.COLUMN_CGST_RATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    
                    
                    inwardInvoiceCDNTemplateDTO.setOrgCgstAmt(einvoices.get(Constants.COLUMN_CGST_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    
                    
                    inwardInvoiceCDNTemplateDTO.setOrgIgstRate(einvoices.get(Constants.COLUMN_IGST_RATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                   
                    
                    inwardInvoiceCDNTemplateDTO.setOrgIgstAmt(einvoices.get(Constants.COLUMN_IGST_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                   
                    
                    inwardInvoiceCDNTemplateDTO.setOrgCessRate(einvoices.get(Constants.COLUMN_CESS_RATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                   
                    
                    inwardInvoiceCDNTemplateDTO.setOrgCessAmt(einvoices.get(Constants.COLUMN_CESS_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                   
                    
                    inwardInvoiceCDNTemplateDTO.setOrgInwardGrossTotalAmount(einvoices.get(Constants.COLUMN_INWARD_GROSS_TOTAL_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                   
                    
                    inwardInvoiceCDNTemplateDTO.setOrgTotalInvAmt(einvoices.get(Constants.COLUMN_TOTAL_INVOICE_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
                    inwardInvoiceCDNTemplateDTO.setOrgImportBillOfEntryAmt(einvoices.get(Constants.COLUMN_IMPORT_BILL_OF_ENTRY_AMT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
           
                    
                    inwardInvoiceCDNTemplateDTO.setItemDescription(einvoices.get(Constants.COLUMN_ITEM_DESCRIPTION)
                    		.replaceAll("[^A-Za-z0-9_\\-\\s\\&]", "").replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setHsnCode(einvoices.get(Constants.COLUMN_HSN_SAC_CODE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUom(einvoices.get(Constants.COLUMN_UOM)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setQuantity(einvoices.get(Constants.COLUMN_QUINTITY)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setItemRate(einvoices.get(Constants.COLUMN_ITEM_RATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getItemRate())) {
                    	
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getItemRate()))
                    	{
                    		inwardInvoiceCDNTemplateDTO.setItemRate("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setItemRate("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00017, Constants.BLANK);
                        	
                    	}
                    }
                    inwardInvoiceCDNTemplateDTO.setAssAmt(einvoices.get(Constants.COLUMN_ASS_AMOUNT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getAssAmt())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getAssAmt()))
                    	{
                    	    inwardInvoiceCDNTemplateDTO.setAssAmt("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setAssAmt("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00588, Constants.BLANK);
                    	}

                    	
                    }
                    inwardInvoiceCDNTemplateDTO.setSgstRate(einvoices.get(Constants.COLUMN_SGST_RATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getSgstRate())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getSgstRate()))
                    	{
                    		inwardInvoiceCDNTemplateDTO.setSgstRate("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setSgstRate("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00024, Constants.BLANK);
                    	}
                    	
                    }
                    inwardInvoiceCDNTemplateDTO.setSgstAmt(einvoices.get(Constants.COLUMN_SGST_AMOUNT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setCgstRate(einvoices.get(Constants.COLUMN_CGST_RATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setCgstAmt(einvoices.get(Constants.COLUMN_CGST_AMOUNT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setIgstRate(einvoices.get(Constants.COLUMN_IGST_RATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setIgstAmt(einvoices.get(Constants.COLUMN_IGST_AMOUNT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setCessRate(einvoices.get(Constants.COLUMN_CESS_RATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setCessAmount(einvoices.get(Constants.COLUMN_CESS_AMOUNT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setDiffPercent(einvoices.get(Constants.COLUMN_DIFF_PERCENT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO
                                    .setInwardGrossTotalAmount(einvoices.get(Constants.COLUMN_INWARD_GROSS_TOTAL_AMOUNT)
                                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    
                    inwardInvoiceCDNTemplateDTO.setTotalInvoiceAmt(einvoices.get(Constants.COLUMN_TOTAL_INVOICE_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getTotalInvoiceAmt())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getTotalInvoiceAmt()))
                    	{
                    		inwardInvoiceCDNTemplateDTO.setTotalInvoiceAmt("0.0");
                    	}
                    	else
                    	{
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00594, Constants.BLANK);
                    		inwardInvoiceCDNTemplateDTO.setTotalInvoiceAmt("0.0");
                    	}
                    }
                    inwardInvoiceCDNTemplateDTO.setTotalInvoiceAmt(einvoices.get(Constants.COLUMN_TOTAL_INVOICE_AMOUNT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setInputType(einvoices.get(Constants.COLUMN_INPUT_TYPE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setOrgInputType(einvoices.get(Constants.COLUMN_INPUT_TYPE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setItcIneligibleReversalIndicator(
                                    einvoices.get(Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_INDICATOR)
                                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setItcIneligibleReversalPercentage(
                                    einvoices.get(Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_PERCENTAGE)
                                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setPlaceOfSupply(einvoices.get(Constants.COLUMN_PLACE_OF_SUPPLY)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setReverseCharge(einvoices.get(Constants.COLUMN_REVERSE_CHARGE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setPort(einvoices.get(Constants.COLUMN_PORT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO
                                    .setImportBillOfEntryNo(einvoices.get(Constants.COLUMN_IMPORT_BILL_OF_ENTRY_NO)
                                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO
                                    .setImportBillOfEntryDate(DateUtil.getFormatedDate(einvoices.get(Constants.COLUMN_IMPORT_BILL_OF_ENTRY_DATE)
                                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
                    inwardInvoiceCDNTemplateDTO
                                    .setOrgImportBillOfEntryAmt(einvoices.get(Constants.COLUMN_IMPORT_BILL_OF_ENTRY_AMT)
                                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    
                    inwardInvoiceCDNTemplateDTO.setDateOfPayment(DateUtil.getFormatedDate(einvoices.get(Constants.DATE_OF_PAYMENT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
                    inwardInvoiceCDNTemplateDTO.setPaymentAmount(einvoices.get(Constants.PAYMENT_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getPaymentAmount())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getPaymentAmount()))
                    	{
                    	    inwardInvoiceCDNTemplateDTO.setPaymentAmount("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setPaymentAmount("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, ValidationConstant.EINVOICE_ERROR_CODE_I50031, Constants.BLANK);
                    	}
                    	
                    }
                    inwardInvoiceCDNTemplateDTO.setPaymentRefNo(einvoices.get(Constants.PAYMENT_REF_NO)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setIrn(
                                    einvoices.get(Constants.IRN).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setAckDate(DateUtil.getFormatedDate(einvoices.get(Constants.COLUMN_ACK_DATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
                    inwardInvoiceCDNTemplateDTO.setAckNo(einvoices.get(Constants.COLUMN_ACK_NO)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setDebitGlId(einvoices.get(Constants.COLUMN_DEBIT_GL_ID)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setDebitGlName(einvoices.get(Constants.COLUMN_DEBIT_GL_NAME)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setCreditGlId(einvoices.get(Constants.COLUMN_CREDIT_GL_ID)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setCreditGlName(einvoices.get(Constants.COLUMN_CREDIT_GL_NAME)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setSubLocation(einvoices.get(Constants.COLUMN_SUB_LOCATION)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

                    inwardInvoiceCDNTemplateDTO.setFillingPeriod(einvoices.get(Constants.FILLING_PERIOD)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

                    String inwardTaxableAmt = einvoices.get(Constants.COLUMN_ASS_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
                     if (!isNumeric(inwardTaxableAmt)) {
                    	 if(StringUtils.isBlank(inwardTaxableAmt))
                     	{
                     	    inwardTaxableAmt = "0.0";
                     	}
                     	else
                     	{
                     		inwardTaxableAmt = "0.0";
                     		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00588, Constants.BLANK);
                     	}
                      }
                     inwardInvoiceCDNTemplateDTO.setInwardTaxableAmt(AppUtil.formatRateAmoutValues(inwardTaxableAmt));

                    String reverseCharge = einvoices.get(Constants.COLUMN_REVERSE_CHARGE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
                    String sgstAmt = einvoices.get(Constants.COLUMN_SGST_AMOUNT).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE).replace("\\", "\\\\");
                    if (!isNumeric(sgstAmt)) {
                    	if(StringUtils.isBlank(sgstAmt))
                    	{
                    		sgstAmt="0.0";
                    	}
                    	else
                    	{
                    		sgstAmt="0.0";
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00590, Constants.BLANK);
                    	}
                    
                    }
                    String cgstAmt = einvoices.get(Constants.COLUMN_CGST_AMOUNT).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE).replace("\\", "\\\\");
                    if (!isNumeric(cgstAmt)) {
                    	if(StringUtils.isBlank(cgstAmt))
                    	{
                    		cgstAmt="0.0";
                    	}
                    	else
                    	{
                    		cgstAmt="0.0";
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00591, Constants.BLANK);
                    	}
                    
                    }
                    String igstAmt = einvoices.get(Constants.COLUMN_IGST_AMOUNT).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE).replace("\\", "\\\\");
                    
                    if (!isNumeric(igstAmt)) {
                    	if(StringUtils.isBlank(igstAmt))
                    	{
                    		igstAmt="0.0";
                    	}
                    	else
                    	{
                    		igstAmt="0.0";
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00592, Constants.BLANK);
                    	}
                    
                    }
                    String cessAmt = einvoices.get(Constants.COLUMN_CESS_AMOUNT).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE).replace("\\", "\\\\");

                    if (!isNumeric(cessAmt)) {
                    	if(StringUtils.isBlank(cessAmt))
                    	{
                    		cessAmt="0.0";
                    	}
                    	else
                    	{
                    		cessAmt="0.0";
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00593, Constants.BLANK);
                    	}
                    
                    }
                    
                    if ("NULL".equalsIgnoreCase(reverseCharge) || StringUtils.isBlank(reverseCharge)
                                    || "0".equals(reverseCharge)) {
                        reverseCharge = "N";
                    }

                    if ("NULL".equalsIgnoreCase(sgstAmt) || StringUtils.isBlank(sgstAmt)
                                    || DroolUtil.isEmpty(sgstAmt)) {
                        sgstAmt = "0";
                    }
                    if ("NULL".equalsIgnoreCase(cgstAmt) || StringUtils.isBlank(cgstAmt)
                                    || DroolUtil.isEmpty(cgstAmt)) {
                        cgstAmt = "0";
                    }
                    if ("NULL".equalsIgnoreCase(igstAmt) || StringUtils.isBlank(igstAmt)
                                    || DroolUtil.isEmpty(igstAmt)) {
                        igstAmt = "0";
                    }
                    if ("NULL".equalsIgnoreCase(cessAmt) || StringUtils.isBlank(cessAmt)
                                    || DroolUtil.isEmpty(cessAmt)) {
                        cessAmt = "0";
                    }
                    String itcIneligibleReversalIndicator = einvoices
                                    .get(Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_INDICATOR)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
                    inwardInvoiceCDNTemplateDTO.setItcIneligibleReversalIndicator(itcIneligibleReversalIndicator);
                    String itcPercent = einvoices.get(Constants.COLUMN_ITC_INELIGIBLE_REVERSAL_PERCENTAGE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
                    inwardInvoiceCDNTemplateDTO.setItcIneligibleReversalPercentage(itcPercent);
                    if (("NULL".equalsIgnoreCase(itcIneligibleReversalIndicator)
                                    || StringUtils.isBlank(itcIneligibleReversalIndicator)
                                    || DroolUtil.isEmpty(itcIneligibleReversalIndicator))
                                    && ("NULL".equalsIgnoreCase(itcPercent) || StringUtils.isBlank(itcPercent)
                                                    || DroolUtil.isEmpty(itcPercent))) {
                        itcPercent = "100";
                    }

                    String grossTotalAmt = einvoices.get(Constants.COLUMN_INWARD_GROSS_TOTAL_AMOUNT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
                    inwardInvoiceCDNTemplateDTO.setInwardGrossTotalAmount(AppUtil.formatRateAmoutValues(grossTotalAmt));
                    String invTotalAmt = einvoices.get(Constants.COLUMN_TOTAL_INVOICE_AMOUNT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
                    inwardInvoiceCDNTemplateDTO.setTotalInvoiceAmt(invTotalAmt);

                    inwardInvoiceCDNTemplateDTO.setDocType(einvoices.get(Constants.COLUMN_DOC_TYPE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setInvoiceCategory(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory());
                    inwardInvoiceCDNTemplateDTO.setSupplyType(einvoices.get(Constants.COLUMN_SUPPLY_TYPE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO
                                    .setOrgInvoiceCategory(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory());
                    inwardInvoiceCDNTemplateDTO.setDocNo(einvoices.get(Constants.COLUMN_DOC_NO)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    // xlsRow.setDocDate(AppUtil.formatDate(row.getCell(colNameIndexMap.get("doc_date"))));11
                    inwardInvoiceCDNTemplateDTO.setDocDate(DateUtil.getFormatedDate(einvoices.get(Constants.COLUMN_DOC_DATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));

                    inwardInvoiceCDNTemplateDTO.setOrgInvoiceNo(einvoices.get(Constants.COLUMN_ORG_INVOICE_NO)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                     inwardInvoiceCDNTemplateDTO.setOrgInvoiceDate(DateUtil.getFormatedDate(einvoices.get(Constants.COLUMN_ORG_INVOICE_DATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));

//					xlsRow.setSupplierStateCode(dataFormatter.formatCellValue(row.getCell(colNameIndexMap.get("supplier_state_code"))).replaceAll("[\n\r]", " "));

//					xlsRow.setInwardDate(AppUtil.formatDate(row.getCell(colNameIndexMap.get("inward_date"))));33
                    inwardInvoiceCDNTemplateDTO.setItemName(einvoices.get(Constants.COLUMN_ITEM_NAME)
                    		.replaceAll("[^A-Za-z0-9_\\-\\s\\&]", "").replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setHsnSacCode(einvoices.get(Constants.COLUMN_HSN_SAC_CODE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


                    
                    String quantity = einvoices.get(Constants.COLUMN_QUINTITY)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
                if(isNumeric(quantity)) {		
                		BigDecimal quantityDecimal = new BigDecimal(quantity);
                		inwardInvoiceCDNTemplateDTO.setQuantity(String.valueOf(quantityDecimal.intValue()));
                } else {
                	
                	if(StringUtils.isBlank(quantity))
                	{	
                	 inwardInvoiceCDNTemplateDTO.setQuantity("0");
                	}
                	else
                	{
                		inwardInvoiceCDNTemplateDTO.setQuantity("0");
                		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00019, Constants.BLANK);	
                	}
                }
                	
                inwardInvoiceCDNTemplateDTO.setOrgQuantity(einvoices.get(Constants.COLUMN_QUINTITY)
                        .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

                    inwardInvoiceCDNTemplateDTO.setItemRate(einvoices.get(Constants.COLUMN_ITEM_RATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getItemRate())) {
                    	
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getItemRate()))
                    	{
                    		inwardInvoiceCDNTemplateDTO.setItemRate("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setItemRate("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00017, Constants.BLANK);
                        	
                    	}
                    }
                    inwardInvoiceCDNTemplateDTO.setAssAmt(einvoices.get(Constants.COLUMN_ASS_AMOUNT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getAssAmt())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getAssAmt()))
                    	{
                    	    inwardInvoiceCDNTemplateDTO.setAssAmt("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setAssAmt("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00588, Constants.BLANK);
                    	}
                    }
                    inwardInvoiceCDNTemplateDTO.setSgstRate(einvoices.get(Constants.COLUMN_SGST_RATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getSgstRate())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getSgstRate()))
                    	{
                    		inwardInvoiceCDNTemplateDTO.setSgstRate("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setSgstRate("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00024, Constants.BLANK);
                    	}
                    	
                    }
                    inwardInvoiceCDNTemplateDTO.setCgstRate(einvoices.get(Constants.COLUMN_CGST_RATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getCgstRate())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getCgstRate()))
                    	{
                    		inwardInvoiceCDNTemplateDTO.setCgstRate("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setCgstRate("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00024, Constants.BLANK);
                    	}
                    	
                    }
                    inwardInvoiceCDNTemplateDTO.setIgstRate(einvoices.get(Constants.COLUMN_IGST_RATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getIgstRate())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getIgstRate()))
                    	{
                    		inwardInvoiceCDNTemplateDTO.setIgstRate("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setIgstRate("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, Constants.EINVOICE_ERROR_CODE_E00027, Constants.BLANK);
                    	}
                    	
                    }
                    inwardInvoiceCDNTemplateDTO.setCessRate(einvoices.get(Constants.COLUMN_CESS_RATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getCessRate())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getCessRate()))
                    	{
                    		inwardInvoiceCDNTemplateDTO.setCessRate(String.valueOf("0.0"));
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setCessRate(String.valueOf("0.0"));
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, ValidationConstant.EINVOICE_ERROR_CODE_E00036, Constants.BLANK);
                    	}
                        
                    }

                    String diffPercent = einvoices.get(Constants.COLUMN_DIFF_PERCENT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
                    if (StringUtils.isBlank(diffPercent) || "NULL".equalsIgnoreCase(diffPercent)) {
                        diffPercent = "0.00";
                    }
                    inwardInvoiceCDNTemplateDTO.setDiffPercent(AppUtil.formatRateAmoutValues(diffPercent));

                    inwardInvoiceCDNTemplateDTO.setImportType(einvoices.get(Constants.COLUMN_INPUT_TYPE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

                    String pos = einvoices.get(Constants.COLUMN_PLACE_OF_SUPPLY).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE).replace("\\", "\\\\");
                    if (StringUtils.isNotBlank(pos) && pos.length() == 1) {
                        inwardInvoiceCDNTemplateDTO.setPlaceOfSupply("0" + pos);
                    } else {
                        inwardInvoiceCDNTemplateDTO.setPlaceOfSupply(pos);
                    }

                    inwardInvoiceCDNTemplateDTO.setPort(einvoices.get(Constants.PORT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

//					
                    String importBillOfEntryAmt = einvoices.get(Constants.COLUMN_IMPORT_BILL_OF_ENTRY_AMT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
                    if (!isNumeric(importBillOfEntryAmt)) {
                    	if(StringUtils.isBlank(importBillOfEntryAmt))
                    	{
                    		importBillOfEntryAmt = "0.0";
                    	}
                    	else
                    	{
                    		importBillOfEntryAmt = "0.0";
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, ValidationConstant.EINVOICE_ERROR_CODE_E00589, Constants.BLANK);
                    	}
                    }
                    inwardInvoiceCDNTemplateDTO.setImportBillOfEntryAmt(importBillOfEntryAmt);

                    // inwardItcInvCdnTemplate.setPreGst(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("pre_gst")),
                    // evaluator));

//					xlsRow.setAck_date(AppUtil.formatDate(row.getCell(colNameIndexMap.get("ack_date"))));

                    inwardInvoiceCDNTemplateDTO.setReverseCharge(reverseCharge);


                    if ("NIL".equalsIgnoreCase(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory())) {
                        inwardInvoiceCDNTemplateDTO.setNilRatedAmt(
                                        AppUtil.formatRateAmoutValues(inwardInvoiceCDNTemplateDTO.getOrgAssAmt()));
                    } else {
                        inwardInvoiceCDNTemplateDTO.setNilRatedAmt(AppUtil.formatRateAmoutValues("0.00"));
                    }
                    if ("EXM".equalsIgnoreCase(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory())) {
                        inwardInvoiceCDNTemplateDTO.setExemptedAmt(
                                        AppUtil.formatRateAmoutValues(inwardInvoiceCDNTemplateDTO.getOrgAssAmt()));
                    } else {
                        inwardInvoiceCDNTemplateDTO.setExemptedAmt(AppUtil.formatRateAmoutValues("0.00"));
                    }
                    if ("NON".equalsIgnoreCase(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory())) {
                        inwardInvoiceCDNTemplateDTO.setNonGstAmt(
                                        AppUtil.formatRateAmoutValues(inwardInvoiceCDNTemplateDTO.getOrgAssAmt()));
                    } else {
                        inwardInvoiceCDNTemplateDTO.setNonGstAmt(AppUtil.formatRateAmoutValues("0.00"));
                    }

                    if ("COMP".equalsIgnoreCase(inwardInvoiceCDNTemplateDTO.getOrgInvoiceCategory())) {
                        inwardInvoiceCDNTemplateDTO.setCompositionAmt(
                                        AppUtil.formatRateAmoutValues(inwardInvoiceCDNTemplateDTO.getOrgAssAmt()));
                    } else {
                        inwardInvoiceCDNTemplateDTO.setCompositionAmt(AppUtil.formatRateAmoutValues("0.00"));
                    }

                    if (inwardInvoiceCDNTemplateDTO.getDateOfPayment().equals("00-01-1900")
                                    || inwardInvoiceCDNTemplateDTO.getDateOfPayment().equals("31/12/1899")
                                    || inwardInvoiceCDNTemplateDTO.getDateOfPayment().equals("31-12-1899")) {
                        inwardInvoiceCDNTemplateDTO.setDateOfPayment("0");
                    }

                    if (inwardInvoiceCDNTemplateDTO.getImportBillOfEntryDate().equals("00-01-1900")
                                    || inwardInvoiceCDNTemplateDTO.getImportBillOfEntryDate().equals("31/12/1899")
                                    || inwardInvoiceCDNTemplateDTO.getImportBillOfEntryDate().equals("31-12-1899")) {
                        inwardInvoiceCDNTemplateDTO.setImportBillOfEntryDate("0");
                    }

                    inwardInvoiceCDNTemplateDTO.setSgstAmt(sgstAmt);
                    inwardInvoiceCDNTemplateDTO.setCgstAmt(cgstAmt);
                    inwardInvoiceCDNTemplateDTO.setIgstAmt(igstAmt);
                    inwardInvoiceCDNTemplateDTO.setCessAmount(cessAmt);

                    /*************
                     * Amount Calculation Start
                     ************************/

                    if (!isNumeric(sgstAmt)) {
                        sgstAmt = "0.0";
                    }

                    if (!isNumeric(cgstAmt)) {
                        cgstAmt = "0.0";
                    }

                    if (!isNumeric(cessAmt)) {
                        cessAmt = "0.0";
                    }

                    if (!isNumeric(igstAmt)) {
                        igstAmt = "0.0";
                    }

                    BigDecimal igst = new BigDecimal(igstAmt);
                    BigDecimal sgst = new BigDecimal(sgstAmt);
                    BigDecimal cgst = new BigDecimal(cgstAmt);
                    BigDecimal cess = new BigDecimal(cessAmt);

                    BigDecimal itcIgst = new BigDecimal(igstAmt);
                    BigDecimal itcSgst = new BigDecimal(sgstAmt);
                    BigDecimal itcCgst = new BigDecimal(cgstAmt);
                    BigDecimal itcCess = new BigDecimal(cessAmt);

                    BigDecimal totalTaxAmt = new BigDecimal(0);
                    totalTaxAmt = totalTaxAmt.add(sgst).add(cgst).add(igst).add(cess);

                    inwardInvoiceCDNTemplateDTO.setTotalTaxAmount(totalTaxAmt.toString());


                    if (DroolUtil.containsNumbersOnly(itcPercent, 1)) {
                        itcSgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), sgst);
                        itcCgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), cgst);
                        itcIgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), igst);
                        itcCess = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), cess);
                    }

                    inwardInvoiceCDNTemplateDTO.setItcSgstAmt(itcSgst.toString());
                    inwardInvoiceCDNTemplateDTO.setItcCgstAmt(itcCgst.toString());
                    inwardInvoiceCDNTemplateDTO.setItcIgstAmt(itcIgst.toString());
                    inwardInvoiceCDNTemplateDTO.setItcCessAmt(itcCess.toString());

                    inwardInvoiceCDNTemplateDTO.setGrossTotalAmount(grossTotalAmt);

                    BigDecimal totalITCTaxAmt = new BigDecimal(0);
                    totalITCTaxAmt = totalITCTaxAmt.add(itcSgst).add(itcCgst).add(itcIgst).add(itcCess);
                    inwardInvoiceCDNTemplateDTO.setInwardTotalTaxAmt(totalTaxAmt.toString());
                    inwardInvoiceCDNTemplateDTO.setTotalItcAmt(totalITCTaxAmt.toString());
                    inwardInvoiceCDNTemplateDTO.setTaxableAmount(inwardInvoiceCDNTemplateDTO.getAssAmt());

                    
                    inwardInvoiceCDNTemplateDTO.setOrgPaymentAmount(einvoices.get(Constants.PAYMENT_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                   
                    inwardInvoiceCDNTemplateDTO.setPaymentAmount(einvoices.get(Constants.PAYMENT_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getPaymentAmount())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getPaymentAmount()))
                    	{
                    		inwardInvoiceCDNTemplateDTO.setPaymentAmount("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setPaymentAmount("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, ValidationConstant.EINVOICE_ERROR_CODE_I50031, Constants.BLANK);
                    	}
                    }
                    inwardInvoiceCDNTemplateDTO.setPaymentRefNo(einvoices.get("payment_ref_no")
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setTdsSection(einvoices.get(Constants.TDS_SECTION)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setTdsRate(einvoices.get(Constants.TDS_RATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setOrgTdsRate(einvoices.get(Constants.TDS_RATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getTdsRate())) {
                   	 
                   	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getTdsRate()))
                	{
                   		inwardInvoiceCDNTemplateDTO.setTdsRate("0.0");
                	}
                	else
                	{
                		inwardInvoiceCDNTemplateDTO.setTdsRate("0.0");
                		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00563, Constants.BLANK);
                	}
                     }
                    inwardInvoiceCDNTemplateDTO.setOrgTdsTaxAmount(einvoices.get(Constants.TDS_TAX_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    
                    inwardInvoiceCDNTemplateDTO.setTdsTaxAmount(einvoices.get(Constants.TDS_TAX_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getTdsTaxAmount())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getTdsTaxAmount()))
                    	{
                    		inwardInvoiceCDNTemplateDTO.setTdsTaxAmount("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setTdsTaxAmount("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, ValidationConstant.EINVOICE_ERROR_CODE_E00528, Constants.BLANK);
                    	}
                    	
                    }
                    inwardInvoiceCDNTemplateDTO.setChallanNumber(einvoices.get(Constants.CHALLAN_NUMBER)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setChallanDate(DateUtil.getFormatedDate(einvoices.get(Constants.CHALLAN_DATE)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
                    inwardInvoiceCDNTemplateDTO.setOrgChallanAmount(einvoices.get(Constants.CHALLAN_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                   
                    inwardInvoiceCDNTemplateDTO.setChallanAmount(einvoices.get(Constants.CHALLAN_AMOUNT)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getChallanAmount())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getChallanAmount()))
                    	{
                    		inwardInvoiceCDNTemplateDTO.setChallanAmount("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setChallanAmount("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00531, Constants.BLANK);
                    	}
                    	
                    }
                    inwardInvoiceCDNTemplateDTO.setPeriodOfFiling(einvoices.get(Constants.PERIOD_OF_FILLING)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setInvoiceAgainstProvAdv(einvoices.get(Constants.INVOICE_AGAINST_PROV_ADV)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setInwardNoProvAdv(einvoices.get(Constants.INWARD_NO_PROV_ADV)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setInwardDateProvAdv(DateUtil.getFormatedDate(einvoices.get(Constants.INWARD_DATE_PROV_ADV)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
                    inwardInvoiceCDNTemplateDTO.setOrgAmountOfProvAdv(einvoices.get(Constants.AMOUNT_OF_PROV_ADV)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setAmountOfProvAdv(einvoices.get(Constants.AMOUNT_OF_PROV_ADV)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getAmountOfProvAdv())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getAmountOfProvAdv()))
                    	{
                    		inwardInvoiceCDNTemplateDTO.setAmountOfProvAdv("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setAmountOfProvAdv("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00536, Constants.BLANK);
                    	}
                    	
                    }
                    inwardInvoiceCDNTemplateDTO.setBalOutstanding(einvoices.get(Constants.BAL_OUTSTANDING)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                   
                    inwardInvoiceCDNTemplateDTO.setOrgBalOutstanding(einvoices.get(Constants.BAL_OUTSTANDING)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                   
                    if (!isNumeric(inwardInvoiceCDNTemplateDTO.getBalOutstanding())) {
                    	if(StringUtils.isBlank(inwardInvoiceCDNTemplateDTO.getBalOutstanding()))
                    	{
                    		inwardInvoiceCDNTemplateDTO.setBalOutstanding("0.0");
                    	}
                    	else
                    	{
                    		inwardInvoiceCDNTemplateDTO.setBalOutstanding("0.0");
                    		markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00595, Constants.BLANK);
                    	}
                    	
                    }
                    
                    inwardInvoiceCDNTemplateDTO.setUdf1(einvoices.get(Constants.COLUMN_UDF_1)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf2(einvoices.get(Constants.COLUMN_UDF_2)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf3(einvoices.get(Constants.COLUMN_UDF_3)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf4(einvoices.get(Constants.COLUMN_UDF_4)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf5(einvoices.get(Constants.COLUMN_UDF_5)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf6(einvoices.get(Constants.COLUMN_UDF_6)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf7(einvoices.get(Constants.COLUMN_UDF_7)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf8(einvoices.get(Constants.COLUMN_UDF_8)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf9(einvoices.get(Constants.COLUMN_UDF_9)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf10(einvoices.get(Constants.COLUMN_UDF_10)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    
                    inwardInvoiceCDNTemplateDTO.setUdf11(einvoices.get(Constants.COLUMN_UDF_11)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf12(einvoices.get(Constants.COLUMN_UDF_12)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf13(einvoices.get(Constants.COLUMN_UDF_13)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf14(einvoices.get(Constants.COLUMN_UDF_14)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf15(einvoices.get(Constants.COLUMN_UDF_15)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf16(einvoices.get(Constants.COLUMN_UDF_16)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf17(einvoices.get(Constants.COLUMN_UDF_17)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf18(einvoices.get(Constants.COLUMN_UDF_18)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf19(einvoices.get(Constants.COLUMN_UDF_19)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    inwardInvoiceCDNTemplateDTO.setUdf20(einvoices.get(Constants.COLUMN_UDF_20)
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
                    
                    
                    if (StringUtils.isNotBlank(inwardInvoiceCDNTemplateDTO.getGstinOfRecipient())
                                    && inwardInvoiceCDNTemplateDTO.getGstinOfRecipient().length() == 15) {
                        inwardInvoiceCDNTemplateDTO.setPanOfReciepiet(
                                        inwardInvoiceCDNTemplateDTO.getGstinOfRecipient().substring(2, 12));

                    } else {
                        inwardInvoiceCDNTemplateDTO.setPanOfReciepiet("");

                    }
                    if (StringUtils.isNotBlank(inwardInvoiceCDNTemplateDTO.getGstinOfSupplier())
                                    && inwardInvoiceCDNTemplateDTO.getGstinOfSupplier().length() == 15) {
                        inwardInvoiceCDNTemplateDTO.setPanOfSupplier(
                                        inwardInvoiceCDNTemplateDTO.getGstinOfSupplier().substring(2, 12));
                    } else {
                        inwardInvoiceCDNTemplateDTO.setPanOfSupplier("");
                    }

                    if(StringUtils.isNotBlank(inwardInvoiceCDNTemplateDTO.getFillingPeriod()))
                    {
                    	sftpSet.add(inwardInvoiceCDNTemplateDTO.getFillingPeriod());
                    }
                    if (inwardInvoiceCDNTemplateDTO.getPeriodOfFiling().length() == 5) {
                    	inwardInvoiceCDNTemplateDTO.setPeriodOfFiling(Constants.ZEROVALUE + inwardInvoiceCDNTemplateDTO.getPeriodOfFiling());
                    }
                    if (inwardInvoiceCDNTemplateDTO.getFillingPeriod().length() == 5) {
                    	inwardInvoiceCDNTemplateDTO.setFillingPeriod(Constants.ZEROVALUE + inwardInvoiceCDNTemplateDTO.getFillingPeriod());
                    }
                    if ("INV".equals(inwardInvoiceCDNTemplateDTO.getDocType())) {
                        rowINVPoJoList.add(inwardInvoiceCDNTemplateDTO);
                    } else if ("CRN".equals(inwardInvoiceCDNTemplateDTO.getDocType())
                                    || "DBN".equals(inwardInvoiceCDNTemplateDTO.getDocType())) {
                        rowCRNPoJoList.add(inwardInvoiceCDNTemplateDTO);
                    } else {
                        rowDocErrorPojoList.add(inwardInvoiceCDNTemplateDTO);
                        inwardInvoiceCDNTemplateDTO.setErrorCodeList(
                                        inwardInvoiceCDNTemplateDTO.getErrorCodeList().append("|E00257"));
                        inwardInvoiceCDNTemplateDTO.setValid(false);
                    }

                }
                
               
                
                if("ftps".equals(uploadRequestDTO.getUploadSource()))
                {
              	  uploadRequestDTO.setMonth(new ArrayList<>(sftpSet));
                }
            } catch (Exception ex) {

                log.error("Error generated:", ex);
                markErrorNAddErrorCode(inwardInvoiceCDNTemplateDTO, ValidationConstant.EINVOICE_ERROR_CODE_DE1000,
                                Constants.BLANK);
            }
        }

    }

    /**
     * Log into to exception table.
     *
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param ex
     *            the ex
     * @param functionName
     *            the function name
     */
    private void logIntoToExceptionTable(UploadReqDTO uploadRequestDTO, Exception ex, String functionName) {
        ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
        exceptionLogDTO.setUserId(uploadRequestDTO.getId());
        exceptionLogDTO.setScreenName(Constants.VENDORCOMMUNICATION);
        exceptionLogDTO.setFunctionName(functionName);
        exceptionLogDTO.setErrorMessage(ex.getMessage());
        exceptionLogDTO.setErrorCause(Constants.NOTCONTAINPROPERDATA);
        exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
        exceptionLogDTO.setCreatedAt(LocalDateTime.now());

        commonCommunicationDao.updateExceptionLogTable(exceptionLogDTO);

    }

    /**
     * Gets the einvoice data list.
     *
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param rowINVPoJoList
     *            the row INV po jo list
     * @param rowCRNPoJoList
     *            the row CRN po jo list
     * @return the einvoice data list
     * @throws InvoiceTemplateUploadException
     *             the invoice template upload exception
     */
    private void readDataFromExcel(UploadReqDTO uploadRequestDTO, List<InwardInvoiceCDNTemplateDTO> rowINVPoJoList,
                    List<InwardInvoiceCDNTemplateDTO> rowCRNPoJoList) throws InvalidTemplateHeaderException, InvoiceTemplateUploadException {
        String methodName = "getEinvoiceDataList";


        // adding to valid or notValid list According to Status code of
        // Object

        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadRequestDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(uploadRequestDTO.getFileType());

        Map<String, Object> rowCountWithHeader = new HashMap<>();

        try {
            try (InputStream inputStream = new FileInputStream(new File(fileName.toString()));
                            BufferedInputStream br = new BufferedInputStream(inputStream)) {
                // getting HeaderRowIndexs , coumnsDataRow ,RowCount
                rowCountWithHeader = getRowCountWithHeader(inputStream, uploadRequestDTO);
            }
        } catch (Exception e2) {
            log.error("Error in getEinvoiceDataList Method :" + e2);
            uploadTransDao.updateProcessStatus(uploadRequestDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();

            String methodName1 = "getExcelEWayDataList";

            exceptionLogDTO.setUserId(uploadRequestDTO.getId());
            exceptionLogDTO.setScreenName(Constants.VENDORCOMMUNICATION);
            exceptionLogDTO.setFunctionName(methodName1);
            exceptionLogDTO.setErrorMessage(e2.getMessage());
            exceptionLogDTO.setErrorCause(Constants.NOTCONTAINPROPERDATA);
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());

            commonCommunicationDao.updateExceptionLogTable(exceptionLogDTO);

            throw new InvoiceTemplateUploadException(e2.getMessage());
        }

        headerRow = (Row) rowCountWithHeader.get(Constants.DATA_ROW);

        try {
            colNameIndexMap = AppUtil.getColumnNameIndexMap(headerRow);
        } catch (Exception ex) {

            log.error("Error in reading colNameIndexMap :" + ex);
            uploadTransDao.updateProcessStatus(uploadRequestDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);

            logIntoToExceptionTable(uploadRequestDTO, ex, methodName);

            throw new InvoiceTemplateUploadException(ex.getMessage(), ex.getCause());
        }

        // throw exception and Update in Exception Log table as per Batch Number
        if (Constants.E_INVOICE_TEMPLATE_COLUMN_COUNT != colNameIndexMap.size()) {
            log.error("Error in Header Not Mathching ");
            uploadTransDao.updateProcessStatus(uploadRequestDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);
            throw new InvalidTemplateHeaderException(
                    StringConstant.HEADERCOUNTERRORMESSAGE + uploadRequestDTO.getBatchNo());

        }

        try (InputStream in = new FileInputStream(new File(fileName.toString()));
                        BufferedInputStream bis = new BufferedInputStream(in);
                        Workbook workbook = StreamingReader.builder().open(bis);) {

            Sheet sheet = workbook.getSheetAt(0);

            sheet.forEach(row -> {
                InwardInvoiceCDNTemplateDTO xlsRow = new InwardInvoiceCDNTemplateDTO();
                if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 1) {
                    xlsRow.setExcelRowId(row.getRowNum());
                    xlsRow.setUserId(Integer.toString(uploadRequestDTO.getUserId()));
                    try {
                        // reading Excel Template
                    	xlsRow.setValid(true);
                        xlsRow = readTemplateRecord(row, colNameIndexMap, uploadRequestDTO);
                        

                    } catch (Exception e) {

                        markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
                        log.info("Exception in readTemplateRecord");
                    }
                    if (StringUtils.isNotBlank(xlsRow.getGstinOfRecipient())
                                    && xlsRow.getGstinOfRecipient().length() == 15) {
                        xlsRow.setPanOfReciepiet(xlsRow.getGstinOfRecipient().substring(2, 12));

                    } else {
                        xlsRow.setPanOfReciepiet("");

                    }
                    
                    if (xlsRow.getFillingPeriod().length() == 5) {
                    	xlsRow.setFillingPeriod(Constants.ZEROVALUE + xlsRow.getFillingPeriod());
                    }
                    if (xlsRow.getPeriodOfFiling().length() == 5) {
                    	xlsRow.setPeriodOfFiling(Constants.ZEROVALUE + xlsRow.getPeriodOfFiling());
                    }
                    if (StringUtils.isNotBlank(xlsRow.getGstinOfSupplier())
                                    && xlsRow.getGstinOfSupplier().length() == 15) {
                        xlsRow.setPanOfSupplier(xlsRow.getGstinOfSupplier().substring(2, 12));
                    } else {
                        xlsRow.setPanOfSupplier("");
                    }
                    if(StringUtils.isNotBlank(xlsRow.getFillingPeriod()))
                    {
                    	sftpSet.add(xlsRow.getFillingPeriod());
                    }
                    if ("INV".equals(xlsRow.getDocType())) {
                        rowINVPoJoList.add(xlsRow);
                    } else if ("CRN".equals(xlsRow.getDocType()) || "DBN".equals(xlsRow.getDocType())) {
                        rowCRNPoJoList.add(xlsRow);
                    } else {
                        rowDocErrorPojoList.add(xlsRow);
                        xlsRow.setErrorCodeList(xlsRow.getErrorCodeList().append("|E00257"));
                        xlsRow.setValid(false);
                    }
                }
            });
          if("ftps".equals(uploadRequestDTO.getUploadSource()))
          {
        	  uploadRequestDTO.setMonth(new ArrayList<>(sftpSet));
        	  uploadTransDao.updateFpLog(uploadRequestDTO.getMonth(),uploadRequestDTO);
          }
        } catch (Exception exception) {
            log.error(methodName + exception);
            throw new InvoiceTemplateUploadException(exception.getMessage(), exception);

        }
    }

    /**
     * Read template record.
     *
     * @param row
     *            the row
     * @param colNameIndexMap2
     *            the col name index map 2
     * @param uploadRequestDTO
     *            the upload request DTO
     * @return the inward invoice CDN template DTO
     */
    private InwardInvoiceCDNTemplateDTO readTemplateRecord(Row row, Map<String, Integer> colNameIndexMap2,
                    UploadReqDTO uploadRequestDTO) {

        InwardInvoiceCDNTemplateDTO xlsRow = new InwardInvoiceCDNTemplateDTO();

        log.info("Reading Cell from excel Rows field wise");

        try {
        	
            xlsRow.setValid(true);
            xlsRow.setRowId(row.getRowNum());
            xlsRow.setExcelRowId(row.getRowNum());
            xlsRow.setOrgInvoiceNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("org_invoice_no")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgInvoiceDate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("org_invoice_date")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInputType(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("input_type")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgInputType(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("input_type")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setDateOfPayment(DateUtil.getFormatedDate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("date_of_payment")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE)).replace("\\", "\\\\"));
            xlsRow.setExcelDocType(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("doc_type")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

            xlsRow.setOrgDocType(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("doc_type")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgSupplyType(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("supply_type")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgImportType(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("input_type")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgDiffPercent(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("diff_percent")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setFillingPeriod(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("filing_period")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setHsnCode(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("hsn_code")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgItemRate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("item_rate")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setOrgAssAmt(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("ass_amt")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setAssAmt(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("ass_amt")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            if (!isNumeric(xlsRow.getAssAmt())) {
            	if(StringUtils.isBlank(xlsRow.getAssAmt()))
            	{
            	    xlsRow.setAssAmt("0.0");
            	}
            	else
            	{
            		xlsRow.setAssAmt("0.0");
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00588, Constants.BLANK);
            	}
            }
            xlsRow.setOrgSgstRate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("sgst_rate")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
           
            xlsRow.setOrgSgstAmt(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("sgst_amt")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setOrgCgstRate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("cgst_rate")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
           
            xlsRow.setOrgCgstAmt(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("cgst_amt")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setOrgIgstRate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("igst_rate")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setOrgIgstAmt(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("igst_amt")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setOrgCessRate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("cess_rate")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setOrgCessAmt(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("cess_amount")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setOrgInwardGrossTotalAmount(
                            AppUtil.getCellValue(row.getCell(colNameIndexMap.get("inward_gross_total_amount")))
                                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setOrgTotalInvAmt(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("total_invoice_amt")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setOrgImportBillOfEntryAmt(
                            AppUtil.getCellValue(row.getCell(colNameIndexMap.get("import_bill_of_entry_amt")))
                                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
           
            String reverseCharge = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("reverse_charge")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            xlsRow.setOrgReverseCharge(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("reverse_charge")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            String itcIneligibleReversalIndicator = AppUtil
                            .getCellValue(row.getCell(colNameIndexMap.get("itc_ineligible_reversal_indicator")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");

            String itcPercent = AppUtil
                            .getCellValue(row.getCell(colNameIndexMap.get("itc_ineligible_reversal_percentage")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");

            xlsRow.setItcIneligibleReversalIndicator(itcIneligibleReversalIndicator);
            xlsRow.setItcIneligibleReversalPercentage(itcPercent);

            String sgstAmt = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("sgst_amt")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            if (!isNumeric(sgstAmt)) {
            	if(StringUtils.isBlank(sgstAmt))
            	{
            		sgstAmt="0.0";
            	}
            	else
            	{
            		sgstAmt="0.0";
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00590, Constants.BLANK);
            	}
            
            }
            String cgstAmt = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("cgst_amt")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            if (!isNumeric(cgstAmt)) {
            	if(StringUtils.isBlank(cgstAmt))
            	{
            		cgstAmt="0.0";
            	}
            	else
            	{
            		cgstAmt="0.0";
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00591, Constants.BLANK);
            	}
            
            }
            String igstAmt = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("igst_amt")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            if (!isNumeric(igstAmt)) {
            	if(StringUtils.isBlank(igstAmt))
            	{
            		igstAmt="0.0";
            	}
            	else
            	{
            		igstAmt="0.0";
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00592, Constants.BLANK);
            	}
            
            }
            String cessAmt = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("cess_amount")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");

            if (!isNumeric(cessAmt)) {
            	if(StringUtils.isBlank(cessAmt))
            	{
            		cessAmt="0.0";
            	}
            	else
            	{
            		cessAmt="0.0";
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00593, Constants.BLANK);
            	}
            
            }
            if ("NULL".equalsIgnoreCase(reverseCharge) || StringUtils.isBlank(reverseCharge)
                            || "0".equals(reverseCharge)) {
                reverseCharge = "N";
            }

            if ("NULL".equalsIgnoreCase(sgstAmt) || StringUtils.isBlank(sgstAmt) || DroolUtil.isEmpty(sgstAmt)) {
                sgstAmt = "0";
            }
            if ("NULL".equalsIgnoreCase(cgstAmt) || StringUtils.isBlank(cgstAmt) || DroolUtil.isEmpty(cgstAmt)) {
                cgstAmt = "0";
            }
            if ("NULL".equalsIgnoreCase(igstAmt) || StringUtils.isBlank(igstAmt) || DroolUtil.isEmpty(igstAmt)) {
                igstAmt = "0";
            }
            if ("NULL".equalsIgnoreCase(cessAmt) || StringUtils.isBlank(cessAmt) || DroolUtil.isEmpty(cessAmt)) {
                cessAmt = "0";
            }

            if (("NULL".equalsIgnoreCase(itcIneligibleReversalIndicator)
                            || StringUtils.isBlank(itcIneligibleReversalIndicator)
                            || DroolUtil.isEmpty(itcIneligibleReversalIndicator))
                            && ("NULL".equalsIgnoreCase(itcPercent) || StringUtils.isBlank(itcPercent)
                                            || DroolUtil.isEmpty(itcPercent))) {
                itcPercent = "100";
            }

            String grossTotalAmt = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("inward_gross_total_amount")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            if (!isNumeric(grossTotalAmt)) {
            	if(StringUtils.isBlank(grossTotalAmt))
            	{
            		grossTotalAmt="0.0";
            	}
            	else
            	{
            		grossTotalAmt="0.0";
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00039, Constants.BLANK);	
            	}
            }
            xlsRow.setInwardGrossTotalAmount(AppUtil.formatRateAmoutValues(grossTotalAmt));
            String invTotalAmt = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("total_invoice_amt")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
           
            if (!isNumeric(invTotalAmt)) {
            	if(StringUtils.isBlank(invTotalAmt))
            	{
            		invTotalAmt="0.0";
            	}
            	else
            	{
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00594, Constants.BLANK);
            		invTotalAmt="0.0";
            	}
            }
            xlsRow.setTotalInvoiceAmt(AppUtil.formatRateAmoutValues(invTotalAmt));
            
            xlsRow.setGstinOfRecipient(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("gstin_uin_of_recipient")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setDocType(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("doc_type")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgInvoiceCategory(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("supply_type")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInvoiceCategory(xlsRow.getOrgInvoiceCategory());
            xlsRow.setUserSupplyCat(xlsRow.getOrgInvoiceCategory());

            xlsRow.setDocNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("doc_no")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            // xlsRow.setDocDate(AppUtil.formatDate(row.getCell(colNameIndexMap.get("doc_date"))));11
            xlsRow.setDocDate(DateUtil.getFormatedDate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("doc_date")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));

            xlsRow.setOrgInvoiceNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("org_invoice_no")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

            xlsRow.setGstinOfSupplier(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("gstin_of_supplier")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setSupplierName(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("supplier_name")))
                            .replaceAll("[^A-Za-z0-9_\\-\\s\\&]", "").replaceAll("[\n\r]", ""));
//			xlsRow.setSupplierStateCode(dataFormatter.formatCellValue(row.getCell(colNameIndexMap.get("supplier_state_code"))).replaceAll("[\n\r]", " "));
            xlsRow.setSupplierStateCode(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("supplier_state_code")))
                            .replaceAll("[\n\r]", ""));
            xlsRow.setInwardNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("inward_no")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

//			xlsRow.setInwardDate(AppUtil.formatDate(row.getCell(colNameIndexMap.get("inward_date"))));33
            xlsRow.setInwardDate(DateUtil.getFormatedDate(DateUtil.getFormatedDate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("inward_date")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"))));
            xlsRow.setItemName(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("item_description")))
                            .replaceAll("[^A-Za-z0-9_\\-\\s\\&]", "").replaceAll("[\n\r]", ""));
            xlsRow.setHsnSacCode(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("hsn_code")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUom(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("uom")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            String quantity = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("quantity")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
        if(isNumeric(quantity)) {		
        		BigDecimal quantityDecimal = new BigDecimal(quantity);
                xlsRow.setQuantity(String.valueOf(quantityDecimal.intValue()));
        } else {
        	if(StringUtils.isBlank(quantity))
        	{	
        	 xlsRow.setQuantity("0");
        	}
        	else
        	{
        		xlsRow.setQuantity("0");
        		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00019, Constants.BLANK);	
        	}
        }
        	
        xlsRow.setOrgQuantity(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("quantity")))
                .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

           
            String itemRate = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("item_rate")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            if (!isNumeric(itemRate)) {
            	if(StringUtils.isBlank(itemRate))
            	{
            	    itemRate="0.0";
            	}
            	else
            	{
            		itemRate="0.0";
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00017, Constants.BLANK);
                	
            	}
            }
            xlsRow.setItemRate(AppUtil.formatRateAmoutValues(itemRate));
           
            String inwardTaxableAmt = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("ass_amt")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            if (!isNumeric(inwardTaxableAmt)) {
            	if(StringUtils.isBlank(inwardTaxableAmt))
            	{
            	    inwardTaxableAmt = "0.0";
            	}
            	else
            	{
            		inwardTaxableAmt = "0.0";
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00588, Constants.BLANK);
            	}
            }
            xlsRow.setInwardTaxableAmt(AppUtil.formatRateAmoutValues(inwardTaxableAmt));

            String sgstRate = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("sgst_rate")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            if (!isNumeric(sgstRate)) {
            	if(StringUtils.isBlank(sgstRate))
            	{
            	     sgstRate = "0.0";
            	}
            	else
            	{
            		sgstRate = "0.0";
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00024, Constants.BLANK);
            	}
            }
            xlsRow.setSgstRate(AppUtil.formatRateAmoutValues(sgstRate));

            String cgstRate = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("cgst_rate")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            if (!isNumeric(cgstRate)) {
            	if(StringUtils.isBlank(cgstRate))
            	{
            		cgstRate = "0.0";
            	}
            	else
            	{
            		cgstRate = "0.0";
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00024, Constants.BLANK);
            	}
            }
            xlsRow.setCgstRate(AppUtil.formatRateAmoutValues(cgstRate));

            String igstRate = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("igst_rate")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            if (!isNumeric(igstRate)) {
            	if(StringUtils.isBlank(igstRate))
            	{
            		igstRate = "0.0";
            	}
            	else
            	{
            		igstRate = "0.0";
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00027, Constants.BLANK);
            	}
            }
            xlsRow.setIgstRate(AppUtil.formatRateAmoutValues(igstRate));

            String cessRate = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("cess_rate")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            if (!isNumeric(cessRate)) {
            	if(StringUtils.isBlank(cessRate))
            	{
            		cessRate = "0.0";
            	}
            	else
            	{
            		cessRate = "0.0";
            		markErrorNAddErrorCode(xlsRow, ValidationConstant.EINVOICE_ERROR_CODE_E00036, Constants.BLANK);
            	}
            }
            xlsRow.setCessRate(AppUtil.formatRateAmoutValues(cessRate));
            if (StringUtils.isBlank(xlsRow.getCessRate())) {
                xlsRow.setCessRate(String.valueOf("0"));
            }

            String diffPercent = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("diff_percent")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            if (StringUtils.isBlank(diffPercent) || "NULL".equalsIgnoreCase(diffPercent)) {
                diffPercent = "0.00";
            }
            xlsRow.setDiffPercent(AppUtil.formatRateAmoutValues(diffPercent));

            xlsRow.setImportType(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("input_type")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

            String pos = AppUtil.getCellValue(row.getCell(colNameIndexMap.get("place_of_supply")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            if (StringUtils.isNotBlank(pos) && pos.length() == 1) {
                xlsRow.setPlaceOfSupply("0" + pos);
            } else {
                xlsRow.setPlaceOfSupply(pos);
            }

            xlsRow.setPort(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("port")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

            xlsRow.setImportBillOfEntryNo(
                            AppUtil.getCellValue(row.getCell(colNameIndexMap.get("import_bill_of_entry_no")))
                                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

//			xlsRow.setImportBillOfEntryDate(AppUtil.formatDate(row.getCell(colNameIndexMap.get("import_bill_of_entry_date"))));44
            xlsRow.setImportBillOfEntryDate(
            		DateUtil.getFormatedDate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("import_bill_of_entry_date")))
                                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));

            String importBillOfEntryAmt = AppUtil
                            .getCellValue(row.getCell(colNameIndexMap.get("import_bill_of_entry_amt")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\");
            if (!isNumeric(importBillOfEntryAmt)) {
            	if(StringUtils.isBlank(importBillOfEntryAmt))
            	{
            		importBillOfEntryAmt = "0.0";
            	}
            	else
            	{
            		importBillOfEntryAmt = "0.0";
            		markErrorNAddErrorCode(xlsRow, ValidationConstant.EINVOICE_ERROR_CODE_E00589, Constants.BLANK);
            	}
            }
            xlsRow.setImportBillOfEntryAmt(importBillOfEntryAmt);

            // inwardItcInvCdnTemplate.setPreGst(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("pre_gst")),
            // evaluator));
            xlsRow.setIrn(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("irn")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setSupplyType(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("supply_type")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
//			xlsRow.setAck_date(AppUtil.formatDate(row.getCell(colNameIndexMap.get("ack_date"))));
            xlsRow.setAckDate(DateUtil.getFormatedDate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("ack_date")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
            xlsRow.setAckNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("ack_no")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

            xlsRow.setDebitGlId(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("debit_gl_id")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setDebitGlName(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("debit_gl_name")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setCreditGlId(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("credit_gl_id")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setCreditGlName(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("credit_gl_name")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setSubLocation(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("sub_location")))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

            xlsRow.setReverseCharge(reverseCharge);



            if ("NIL".equalsIgnoreCase(xlsRow.getOrgInvoiceCategory())) {
                xlsRow.setNilRatedAmt(AppUtil.formatRateAmoutValues(xlsRow.getOrgAssAmt()));
            } else {
                xlsRow.setNilRatedAmt(AppUtil.formatRateAmoutValues("0.00"));
            }
            if ("EXM".equalsIgnoreCase(xlsRow.getOrgInvoiceCategory())) {
                xlsRow.setExemptedAmt(AppUtil.formatRateAmoutValues(xlsRow.getOrgAssAmt()));
            } else {
                xlsRow.setExemptedAmt(AppUtil.formatRateAmoutValues("0.00"));
            }
            if ("NON".equalsIgnoreCase(xlsRow.getOrgInvoiceCategory())) {
                xlsRow.setNonGstAmt(AppUtil.formatRateAmoutValues(xlsRow.getOrgAssAmt()));
            } else {
                xlsRow.setNonGstAmt(AppUtil.formatRateAmoutValues("0.00"));
            }

            if ("COMP".equalsIgnoreCase(xlsRow.getOrgInvoiceCategory())) {
                xlsRow.setCompositionAmt(AppUtil.formatRateAmoutValues(xlsRow.getOrgAssAmt()));
            } else {
                xlsRow.setCompositionAmt(AppUtil.formatRateAmoutValues("0.00"));
            }

            if (xlsRow.getDateOfPayment().equals("00-01-1900") || xlsRow.getDateOfPayment().equals("31/12/1899")
                            || xlsRow.getDateOfPayment().equals("31-12-1899")) {
                xlsRow.setDateOfPayment("0");
            }

            if (xlsRow.getImportBillOfEntryDate().equals("00-01-1900")
                            || xlsRow.getImportBillOfEntryDate().equals("31/12/1899")
                            || xlsRow.getImportBillOfEntryDate().equals("31-12-1899")) {
                xlsRow.setImportBillOfEntryDate("0");
            }

            xlsRow.setSgstAmt(sgstAmt);
            xlsRow.setCgstAmt(cgstAmt);
            xlsRow.setIgstAmt(igstAmt);
            xlsRow.setCessAmount(cessAmt);

            /************* Amount Calculation Start ************************/

            if (!isNumeric(sgstAmt)) {
                sgstAmt = "0.0";
            }

            if (!isNumeric(cgstAmt)) {
                cgstAmt = "0.0";
            }

            if (!isNumeric(cessAmt)) {
                cessAmt = "0.0";
            }

            if (!isNumeric(igstAmt)) {
                igstAmt = "0.0";
            }

            BigDecimal igst = new BigDecimal(igstAmt);
            BigDecimal sgst = new BigDecimal(sgstAmt);
            BigDecimal cgst = new BigDecimal(cgstAmt);
            BigDecimal cess = new BigDecimal(cessAmt);

            BigDecimal itcIgst = new BigDecimal(igstAmt);
            BigDecimal itcSgst = new BigDecimal(sgstAmt);
            BigDecimal itcCgst = new BigDecimal(cgstAmt);
            BigDecimal itcCess = new BigDecimal(cessAmt);

            BigDecimal totalTaxAmt = new BigDecimal(0);
            totalTaxAmt = totalTaxAmt.add(sgst).add(cgst).add(igst).add(cess);

            xlsRow.setTotalTaxAmount(totalTaxAmt.toString());

            if (DroolUtil.containsNumbersOnly(itcPercent, 1)) {
                itcSgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), sgst);
                itcCgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), cgst);
                itcIgst = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), igst);
                itcCess = AppUtil.calculatePercentage(Double.parseDouble(itcPercent), cess);
            }

            xlsRow.setItcSgstAmt(itcSgst.toString());
            xlsRow.setItcCgstAmt(itcCgst.toString());
            xlsRow.setItcIgstAmt(itcIgst.toString());
            xlsRow.setItcCessAmt(itcCess.toString());

            xlsRow.setGrossTotalAmount(grossTotalAmt);

            BigDecimal totalITCTaxAmt = new BigDecimal(0);
            totalITCTaxAmt = totalITCTaxAmt.add(itcSgst).add(itcCgst).add(itcIgst).add(itcCess);
            xlsRow.setInwardTotalTaxAmt(totalTaxAmt.toString());
            xlsRow.setTotalItcAmt(totalITCTaxAmt.toString());
            xlsRow.setTaxableAmount(xlsRow.getAssAmt());


            xlsRow.setOrgPaymentAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("payment_amount")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
           
            xlsRow.setPaymentAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("payment_amount")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            if (!isNumeric(xlsRow.getPaymentAmount())) {
            	if(StringUtils.isBlank(xlsRow.getPaymentAmount()))
            	{
            	    xlsRow.setPaymentAmount("0.0");
            	}
            	else
            	{
            		xlsRow.setOrgPaymentAmount("0.0");
            		markErrorNAddErrorCode(xlsRow, ValidationConstant.EINVOICE_ERROR_CODE_I50031, Constants.BLANK);
            	}
            }
            xlsRow.setPaymentRefNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("payment_ref_no")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setTdsSection(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("tds_section")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgTdsRate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("tds_rate")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setTdsRate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("tds_rate")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            if (!isNumeric(xlsRow.getTdsRate())) {
           	 
           	if(StringUtils.isBlank(xlsRow.getTdsRate()))
        	{
        	    xlsRow.setTdsRate("0.0");
        	}
        	else
        	{
        		xlsRow.setTdsRate("0.0");
        		markErrorNAddErrorCode(xlsRow, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00563, Constants.BLANK);
        	}
             }
            xlsRow.setOrgTdsTaxAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("tds_tax_amount")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setTdsTaxAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("tds_tax_amount")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            if (!isNumeric(xlsRow.getTdsTaxAmount())) {
            	if(StringUtils.isBlank(xlsRow.getTdsTaxAmount()))
            	{
            	    xlsRow.setTdsTaxAmount("0.0");
            	}
            	else
            	{
            		xlsRow.setTdsTaxAmount("0.0");
            		markErrorNAddErrorCode(xlsRow, ValidationConstant.EINVOICE_ERROR_CODE_E00528, Constants.BLANK);
            	}
            	
            }
            xlsRow.setChallanNumber(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("challan_number")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setChallanDate(DateUtil.getFormatedDate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("challan_date")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
            xlsRow.setOrgChallanAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("challan_amount")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
           
            xlsRow.setChallanAmount(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("challan_amount")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            if (!isNumeric(xlsRow.getChallanAmount())) {
            	if(StringUtils.isBlank(xlsRow.getChallanAmount()))
            	{
            	    xlsRow.setChallanAmount("0.0");
            	}
            	else
            	{
            		xlsRow.setChallanAmount("0.0");
            		markErrorNAddErrorCode(xlsRow, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00531, Constants.BLANK);
            	}
            	
            }
            xlsRow.setPeriodOfFiling(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("period_of_filing")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInvoiceAgainstProvAdv(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("invoice_against_prov_adv")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInwardNoProvAdv(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("inward_no_prov_adv")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setInwardDateProvAdv(DateUtil.getFormatedDate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("inward_date_prov_adv")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\")));
            xlsRow.setOrgAmountOfProvAdv(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("amount_of_prov_adv")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setAmountOfProvAdv(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("amount_of_prov_adv")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            if (!isNumeric(xlsRow.getAmountOfProvAdv())) {
            	if(StringUtils.isBlank(xlsRow.getAmountOfProvAdv()))
            	{
            	    xlsRow.setAmountOfProvAdv("0.0");
            	}
            	else
            	{
            		xlsRow.setAmountOfProvAdv("0.0");
            		markErrorNAddErrorCode(xlsRow, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00536, Constants.BLANK);
            	}
            	
            }
            
            xlsRow.setBalOutstanding(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("bal_outstanding")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setOrgBalOutstanding(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("bal_outstanding")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            if (!isNumeric(xlsRow.getBalOutstanding())) {
            	if(StringUtils.isBlank(xlsRow.getBalOutstanding()))
            	{
            	    xlsRow.setBalOutstanding("0.0");
            	}
            	else
            	{
            		xlsRow.setBalOutstanding("0.0");
            		markErrorNAddErrorCode(xlsRow, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00595, Constants.BLANK);
            	}
            	
            }
            
           
            xlsRow.setUdf1(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_1")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf2(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_2")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf3(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_3")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf4(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_4")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf5(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_5")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf6(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_6")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf7(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_7")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf8(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_8")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf9(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_9")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf10(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_10")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            
            xlsRow.setUdf11(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_11")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf12(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_12")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf13(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_13")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf14(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_14")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf15(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_15")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf16(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_16")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf17(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_17")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf18(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_18")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf19(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_19")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
            xlsRow.setUdf20(AppUtil.getCellValue(row.getCell(colNameIndexMap.get("udf_20")))
                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
         
 
        } catch (Exception ex) {
            // Mark as not Valid object if Exception occur
            log.error("Error generated:", ex);
            markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
            ExceptionLogDTO exceptionLogDto = new ExceptionLogDTO();
            exceptionLogDto.setUserId(uploadRequestDTO.getUploadBy());
            exceptionLogDto.setScreenName(Constants.VENDORCOMMUNICATION);
            exceptionLogDto.setFunctionName("readTemplateRecord");
            exceptionLogDto.setErrorMessage(ex.getMessage());
            // exceptionLogDto.setErrorCause(ex.getCause());
            exceptionLogDto.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDto.setCreatedAt(LocalDateTime.now());
            xlsRow.setValid(false);

            commonCommunicationDao.updateExceptionLogTable(exceptionLogDto);
            log.error("Error generated:", ex);
            log.error("Errro occured while reading row " + row.getRowNum() + " for batch No. " + ex);
        }
        return xlsRow;
    }

    /**
     * Checks if is numeric.
     *
     * @param strNum
     *            the str num
     * @return true, if is numeric
     */
    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    /**
     * Gets the row count with header.
     *
     * @param inputStream
     *            the input stream
     * @param uploadRequestDTO
     *            the upload request DTO
     * @return the row count with header
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    public Map<String, Object> getRowCountWithHeader(InputStream inputStream, UploadReqDTO uploadRequestDTO)
                    throws VendorInvoiceServerException {
        Map<String, Object> dataMap = new HashMap<>();
        String methodName = "getRowCountWithHeader";
        int totalRowCount = 0;
        try (InputStream is = new BufferedInputStream(inputStream);
                        Workbook workbook = StreamingReader.builder().open(is);) {

            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 1) {
                    totalRowCount++;
                } else if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() <= 1 && totalRowCount == 0) {

                    Row coumnsDataRow = null;
                    coumnsDataRow = row;
                    dataMap.put("headerRowIndex", row.getRowNum());
                    dataMap.put("coumnsDataRow", coumnsDataRow);

                }

            }
            dataMap.put("RowCount", totalRowCount);
        } catch (Exception ex) {

            log.error("getRowCountWithHeader Error " + ex);
            logIntoToExceptionTable(uploadRequestDTO, ex, methodName);
            throw new VendorInvoiceServerException(
                            Constants.ERRORINREADINGHEADECOUNT+ uploadRequestDTO.getBatchNo());

        }
        return dataMap;

    }

    /**
     * Start processing invoice data.
     *
     * @param invList
     *            the inv list
     * @param uploadRequestDTO
     *            the upload request DTO
     */
    public void startProcessingInvoiceData(List<InwardInvoiceCDNTemplateDTO> invList, UploadReqDTO uploadRequestDTO) {

        if (log.isDebugEnabled()) {
            log.debug("Start processing invoice data for invoice " + invList.size() + " for request "
                            + uploadRequestDTO.toString());
        }
        rowINVSuccessPoJoList=new ArrayList<>();
        rowInvErrorPoJoList=new ArrayList<>();
        List<InwardInvoiceCDNTemplateDTO> validatedList = null;

        boolean isJavaRulesEnables = Boolean.TRUE;

        stateCodeMap = commonCommunicationDao.getStateCodeList();
        portCodeMap = commonCommunicationDao.getPortCodeList();
        govtRateMap = commonCommunicationDao.getGovtRateList();
        tdsSections = commonCommunicationDao.getTdsSectionList();

        validatedList = validateInvoices(invList, uploadRequestDTO, isJavaRulesEnables);


                    rowINVSuccessPoJoList.forEach(rowData -> {
                    	
                    	
                        try {
                             
                            if ("urp".equalsIgnoreCase(rowData.getGstinOfSupplier())) {
                                rowData.setGstinOfSupplier("0");
                            }

                            rowData.setDocType(AppUtil
                                            .einvdocTypeToGstr2Doctype(rowData.getOrgInvoiceCategory().toUpperCase()));
                            if (StringUtils.isBlank(rowData.getImportType())) {
                                rowData.setImportType("Inputs");
                                if (rowData.getHsnSacCode().length() > 2
                                                && rowData.getHsnSacCode().substring(0, 2).equalsIgnoreCase("99")) {
                                    rowData.setImportType("Input Services");
                                }

                            } else {
                                if ("IN".equalsIgnoreCase(rowData.getImportType())) {
                                    rowData.setImportType("Inputs");
                                } else if ("INS".equalsIgnoreCase(rowData.getImportType())) {
                                    rowData.setImportType("Input Services");
                                } else if ("CG".equalsIgnoreCase(rowData.getImportType())) {
                                    rowData.setImportType("Capital Goods");
                                }
                            }
                            

                            if (StringUtils.isBlank(rowData.getItcEligible())) {
                                rowData.setItcEligible("Eligible");
                            } else if ("Inputs".equalsIgnoreCase(rowData.getImportType())
                                            || "IN".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setItcEligible("Eligible");
                            } else if ("Input Services".equalsIgnoreCase(rowData.getImportType())
                                            || "INS".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setItcEligible("Eligible");
                            } else if ("Capital Goods".equalsIgnoreCase(rowData.getImportType())
                                            || "CG".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setItcEligible("Eligible");
                            }

                            if ("REV-42&43".equalsIgnoreCase(rowData.getItcIneligibleReversalIndicator()) || "REV-OTH"
                                            .equalsIgnoreCase(rowData.getItcIneligibleReversalIndicator())) {
                                rowData.setItcEligible("reversal");
                            }

                            if ("INELG-17(5)".equalsIgnoreCase(rowData.getItcIneligibleReversalIndicator())
                                            || "INELG-OTH".equalsIgnoreCase(
                                                            rowData.getItcIneligibleReversalIndicator())) {
                                rowData.setItcEligible("ineligible");
                            }

                            InwardITCInvoiceBDRL inwardITCInvoiceBDRL = new InwardITCInvoiceBDRL();
                            inwardITCInvoiceBDRL.applyBDRL(rowData);

                        } catch (Exception ex) {
                            log.error("Error generated:", ex);
                        }
                    	
                    });
                    

               

        lineLevelError.clear();
        docLevelError.clear();
        itemLevelErrorMap.clear();
        
    }

    /**
     * Transform objets N check item level error.
     *
     * @param rowINVSuccessPoJoListM
     *            the row INV success po jo list M
     * @param rowErrorPoJoList2
     *            the row error po jo list 2
     * @param rowData
     *            the row data
     * @param uploadRequestDTO
     *            the upload request DTO
     */
    private void transformObjetsNCheckItemLevelError(List<InwardInvoiceCDNTemplateDTO> rowINVSuccessPoJoListM,
                    List<InwardInvoiceCDNTemplateDTO> rowErrorPoJoList2, InwardInvoiceCDNTemplateDTO rowData,
                    UploadReqDTO uploadRequestDTO) {
    	String yearIdData = yearIdMap.get(rowData.getFillingPeriod());
    	
        String lineItemLevelErrorkey = new StringBuilder().append(rowData.getGstinOfRecipient())
                        .append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo()).toString();

        String itemLevelErrorkey = new StringBuilder().append(rowData.getGstinOfRecipient()).append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo())
				.append(yearIdData).toString();
        
        
		


        if (rowData.getErrorCodeList().indexOf("E00061") <= 0 && itemLevelErrorMap.get(itemLevelErrorkey) != null
                        && itemLevelErrorMap.get(itemLevelErrorkey).equalsIgnoreCase(itemLevelErrorkey)
                        && rowData.isValid()) {
            markErrorNAddErrorCode(rowData, Constants.ITEM_LEVEL_ERROR_CODE, "");

        }

        if (rowData.getErrorCodeList().indexOf("E00056") <= 0 && lineLevelError.get(lineItemLevelErrorkey) != null
                        && lineLevelError.get(lineItemLevelErrorkey).size() > 1) {
            rowData.setErrorCodeList(rowData.getErrorCodeList().append("|E00056"));
            rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(""));
            rowData.setValid(false);
        }

        if (rowData.getErrorCodeList().indexOf("I50110") <= 0 && docLevelError.get(lineItemLevelErrorkey) != null
                        && docLevelError.get(lineItemLevelErrorkey).size() > 1) {
            rowData.setErrorCodeList(rowData.getErrorCodeList().append("|I50110"));
            rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(""));
            rowData.setValid(false);
        }

        if (!rowData.isValid()) {
            rowErrorPoJoList2.add(rowData);
        } else {
            if (einvdocTypeToGstr2Doctype(rowData.getOrgInvoiceCategory().toUpperCase()).equals(rowData.getDocType())) {
                rowINVSuccessPoJoListM.add(rowData);
            }

        }

    }

    /**
     * Validate invoices.
     *
     * @param invList
     *            the inv list
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param isJavaRulesEnables
     *            the is java rules enables
     * @return the list
     */
    private List<InwardInvoiceCDNTemplateDTO> validateInvoices(List<InwardInvoiceCDNTemplateDTO> invList,
                    UploadReqDTO uploadRequestDTO, boolean isJavaRulesEnables) {

        int totalSize = invList.size();

        // Not in use in future we can use
        boolean isInvDiluted = checkIfDiluted(uploadRequestDTO);
     
        List<InwardInvoiceCDNTemplateDTO> validatedList = new ArrayList<>(800000);
        Map<String, Map<String, String>> suppGSTNWiseMap = new HashMap<>();
        Map<String, Map<String, String>> invoiceExistInFpMap = new HashMap<>();
        Map<String, Map<String, String>> invoiceExistInPreFpMap = new ConcurrentHashMap<>();
        Map<String, Map<String, String>> ictCclaimedListMap = new ConcurrentHashMap<>();
        Map<String, Map<String, String>> ictCclaimedCDNListMap = new ConcurrentHashMap<>();

        List<List<InwardInvoiceCDNTemplateDTO>> partList = Lists.partition(invList, Constants.THREADCOUNT);

        fp = new StringBuilder().append(uploadRequestDTO).append(uploadRequestDTO.getYear()).toString();

        int totalProcessedRec = 0;

        String userGSTN[] = null;

        if (Constants.PAN.equals(uploadRequestDTO.getPanOrGstn())) {
            userGSTN = commonCommunicationDao.getGstinFromDB(uploadRequestDTO.getGstinOrPanList().get(0),
                            mstDatabseName);
        } else if (Constants.GSTIN.equals(uploadRequestDTO.getPanOrGstn())) {
            userGSTN = uploadRequestDTO.getGstinOrPanList()
                            .toArray(new String[uploadRequestDTO.getGstinOrPanList().size()]);

        }

        String[] fpList = uploadRequestDTO.getMonth().toArray(new String[uploadRequestDTO.getMonth().size()]);

        List<String> uomList = commonCommunicationDao.getUomQuery();

        for (List<InwardInvoiceCDNTemplateDTO> sublist : partList) {

            totalProcessedRec = totalProcessedRec + sublist.size();

            List<InwardInvoiceCDNTemplateDTO> rulesValidatedsublist = runParallalProcessingValidations(sublist,
                            uploadRequestDTO, isJavaRulesEnables, userGSTN, fpList);

            rulesValidatedsublist.forEach(rowData -> {
                try {

                    // Invoice + Supplier GSTN + Recipients wise values should
                    // be same
                	
                        markLineLevelError(rowData, uploadRequestDTO);
                	
                        markDocNoLevelError(rowData);
                    

                    rowData.setDocType(
                                    AppUtil.einvdocTypeToGstr2Doctype(rowData.getOrgInvoiceCategory().toUpperCase()));

                    if ("urp".equalsIgnoreCase(rowData.getGstinOfSupplier())) {
                        rowData.setGstinOfSupplier("0");
                    }
                    if (StringUtils.isBlank(rowData.getImportType()) || "0".equals(rowData.getImportType())) {
                        rowData.setImportType("Inputs");
                        if (StringUtils.isNotBlank(rowData.getHsnSacCode()) && rowData.getHsnSacCode().length() > 2
                                        && "99".equalsIgnoreCase(rowData.getHsnSacCode().substring(0, 2))) {
                            rowData.setImportType("Input Services");
                        }
                    } else {
                        if ("IN".equalsIgnoreCase(rowData.getImportType())) {
                            rowData.setImportType("Inputs");
                        } else if ("INS".equalsIgnoreCase(rowData.getImportType())) {
                            rowData.setImportType("Input Services");
                        } else if ("CG".equalsIgnoreCase(rowData.getImportType())) {
                            rowData.setImportType("Capital Goods");
                        }
                    }

                    if (StringUtils.isBlank(rowData.getItcEligible())
                                    || "Inputs".equalsIgnoreCase(rowData.getImportType())
                                    || "IN".equalsIgnoreCase(rowData.getImportType())
                                    || "Input Services".equalsIgnoreCase(rowData.getImportType())
                                    || "INS".equalsIgnoreCase(rowData.getImportType())
                                    || "Capital Goods".equalsIgnoreCase(rowData.getImportType())
                                    || "CG".equalsIgnoreCase(rowData.getImportType())) {

                        rowData.setItcEligible("Eligible");
                    }

                    if (StringUtils.isNotBlank(rowData.getUom())) {

                        if (!uomList.isEmpty() && !uomList.contains(rowData.getUom().toUpperCase())) {
                            markErrorNAddErrorCode(rowData, "|E00020", "");
                        }
                    }
                    if (StringUtils.isBlank(rowData.getFillingPeriod())) {
                    	markErrorNAddErrorCode(rowData, ValidationConstant.ERRORCODEE00352, "");
                    }
                    
                        String supplierGstnInwardNo = rowData.getGstinOfSupplier() + rowData.getInwardNo();
                        if (StringUtils.isNotBlank(supplierGstnInwardNo)) {
                            supplierGstnInwardNo = supplierGstnInwardNo.toLowerCase();
                        }

                        int isduplicateInvoiceInDiffMonth = 0;
                        if (totalSize < 5000) {
                            isduplicateInvoiceInDiffMonth = commonCommunicationDao.getInwardResultFPCount(
                                            rowData.getGstinOfRecipient(), rowData.getInwardNo(),
                                            rowData.getInwardDate(), rowData.getGstinOfSupplier(), rowData.getFillingPeriod(), yearIdMap.get(rowData.getFillingPeriod()));

                        } else {
                            // Check invoice already saved in the GSTN
                            String keyCheckInBatchData = rowData.getGstinOfRecipient() + uploadRequestDTO.getBatchNo();
                            List<String> invoiceList = null;
                            if (suppGSTNWiseMap.get(keyCheckInBatchData) == null) {
                                invoiceList = commonCommunicationDao.getDuplicateFPInDiffMonth(
                                                rowData.getGstinOfSupplier(), rowData.getGstinOfRecipient(),yearIdMap.get(rowData.getFillingPeriod()),
                                                rowData.getFillingPeriod());
                                Map<String, String> map = invoiceList.stream()
                                                .collect(Collectors.toMap(str -> str, str -> str));
                                suppGSTNWiseMap.put(keyCheckInBatchData, map);
                                if (suppGSTNWiseMap.get(keyCheckInBatchData).get(supplierGstnInwardNo) != null) {
                                    isduplicateInvoiceInDiffMonth++;
                                }

                            } else {
                                Map<String, String> map = suppGSTNWiseMap.get(keyCheckInBatchData);
                                if (map != null && map.get(supplierGstnInwardNo) != null) {
                                    isduplicateInvoiceInDiffMonth++;
                                }
                            }
                        }

                        String mapKey = rowData.getInwardNo() + rowData.getGstinOfSupplier();

                        if (StringUtils.isNotBlank(mapKey)) {
                            mapKey = mapKey.toLowerCase();
                        }

//                        String itcClaimedKey = rowData.getGstinOfRecipient() + uploadRequestDTO.getBatchNo();
                        if (isduplicateInvoiceInDiffMonth > 0) {
                            markErrorNAddErrorCode(rowData, Constants.COMMUNICATION_ERROR_CODE_O0093, "");
                        }
//                        int isItcClaim = 0;

                        if (yearIdMap.containsKey(rowData.getFillingPeriod())) {
                            rowData.setYearId(yearIdMap.get(rowData.getFillingPeriod()));
                        } else {
                            rowData.setYearId("");
                            markErrorNAddErrorCode(rowData, Constants.EINVOICE_ERROR_CODE_E00514, "");
                        }

                        
                    

                } catch (Exception | Error ex) {
                    log.error("Error generated:", ex);
                    log.error("Error in " + "validateInvoices" + ex);
                    markErrorNAddErrorCode(rowData, ValidationConstant.EINVOICE_ERROR_CODE_DE1000, ex.getMessage());
                }

                String itemLevelErrorkey = rowData.getGstinOfRecipient() + rowData.getGstinOfSupplier()
                                + rowData.getInwardNo();

                if (!rowData.isValid() && itemLevelErrorMap.get(itemLevelErrorkey) == null) {
                    itemLevelErrorMap.put(itemLevelErrorkey, itemLevelErrorkey);
                }

                
                validatedList.add(rowData);
                
                rowData = null;

            });
        }

        validatedList.forEach(rowData->
        {
        	transformObjetsNCheckItemLevelError(rowINVSuccessPoJoList, rowInvErrorPoJoList, rowData,
              uploadRequestDTO);
        });
        
        uomList.clear();
        suppGSTNWiseMap.clear();
        invoiceExistInFpMap.clear();
        invoiceExistInPreFpMap.clear();
        ictCclaimedListMap.clear();
        
        
        ictCclaimedCDNListMap.clear();
        return validatedList;

    }

    /**
     * Mark doc no level error.
     *
     * @param rowData
     *            the row data
     */
    private void markDocNoLevelError(InwardInvoiceCDNTemplateDTO rowData) {

        String lineItemLevelErrorkey = new StringBuilder().append(rowData.getGstinOfRecipient())
                        .append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo()).toString();
        // gstin_of_recipient, gstin_of_supplier, inward_no, doc_no

        String lineItemLevelErrorValue = new StringBuilder().append(rowData.getGstinOfRecipient())
                        .append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo()).append(rowData.getDocNo())
                        .toString();

        if (docLevelError.get(lineItemLevelErrorkey) == null) {
            Set<String> setLineItem = new HashSet<>();
            setLineItem.add(lineItemLevelErrorValue);
            docLevelError.put(lineItemLevelErrorkey, setLineItem);

        } else if (docLevelError.get(lineItemLevelErrorkey) != null
                        && docLevelError.get(lineItemLevelErrorkey).size() == 1) {
            Set<String> setLineItem = docLevelError.get(lineItemLevelErrorkey);
            setLineItem.add(lineItemLevelErrorValue);
            docLevelError.put(lineItemLevelErrorkey, setLineItem);
        }

        if (docLevelError.get(lineItemLevelErrorkey) != null && (docLevelError.get(lineItemLevelErrorkey).size() > 1)) {
            rowData.setErrorCodeList(rowData.getErrorCodeList().append("|I50110"));
            rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(""));
            rowData.setValid(false);

        }

    }

    /**
     * Mark line level error.
     *
     * @param rowData
     *            the row data
     * @param uploadRequestDTO
     *            the upload request DTO
     */
    private void markLineLevelError(InwardInvoiceCDNTemplateDTO rowData, UploadReqDTO uploadRequestDTO) {

        // Checking item level Error start
        String lineItemLevelErrorkey = new StringBuilder().append(rowData.getGstinOfRecipient())
                        .append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo()).toString();
        
        String lineItemLevelErrorValue = "";
        
            lineItemLevelErrorValue = new StringBuilder().append(rowData.getGstinOfRecipient())
                            .append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo())
                            .append(rowData.getInwardDate()).append(rowData.getPlaceOfSupply())
                            .append(rowData.getSupplierStateCode()).append(rowData.getDiffPercent())
                            .append(rowData.getOrgSupplyType()).append(rowData.getInvoiceCategory())
                            .append(rowData.getReverseCharge()).append(rowData.getSupplierName())
                            .append(rowData.getDocNo()).append(rowData.getDocDate()).append(rowData.getOrgDocType())
                            .append(rowData.getTdsSection())
                            .toString();
        

        if (lineLevelError.get(lineItemLevelErrorkey) == null) {
            Set<String> setLineItem = new HashSet<>();
            setLineItem.add(lineItemLevelErrorValue);
            lineLevelError.put(lineItemLevelErrorkey, setLineItem);

        } else if (lineLevelError.get(lineItemLevelErrorkey) != null
                        && lineLevelError.get(lineItemLevelErrorkey).size() == 1) {
            Set<String> setLineItem = lineLevelError.get(lineItemLevelErrorkey);
            setLineItem.add(lineItemLevelErrorValue);
            lineLevelError.put(lineItemLevelErrorkey, setLineItem);
        }

        if (lineLevelError.get(lineItemLevelErrorkey) != null && lineLevelError.get(lineItemLevelErrorkey).size() > 1) {
            rowData.setErrorCodeList(rowData.getErrorCodeList().append("|E00056"));
            rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(""));
            rowData.setValid(false);
        }
    }

    /**
     * Check if diluted.
     *
     * @param vbo
     *            the vbo
     * @return true, if successful
     */
    private boolean checkIfDiluted(UploadReqDTO vbo) {
        return DroolUtil.checkIfDiluted(vbo.getInwardValidationRule(), ErrorCodes.INVOICEHAVESAMEDOCNO);
    }

    /**
     * Run parallal processing validations.
     *
     * @param sublist
     *            the sublist
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param isJavaRulesEnables
     *            the is java rules enables
     * @param userGSTN
     *            the user GSTN
     * @param fpList
     *            the fp list
     * @return the list
     */
    private List<InwardInvoiceCDNTemplateDTO> runParallalProcessingValidations(
                    List<InwardInvoiceCDNTemplateDTO> sublist, UploadReqDTO uploadRequestDTO,
                    boolean isJavaRulesEnables, String[] userGSTN, String[] fpList) {


        List<InwardInvoiceCDNTemplateDTO> validatedList = new ArrayList<>(sublist.size());
        
            if (isJavaRulesEnables) {
            	sublist.forEach(rowData -> {

//					String[] userGSTN = uploadRequestDTO.getGstinOrPanList()
//							.toArray(new String[uploadRequestDTO.getGstinOrPanList().size()]);

                    if (StringUtils.isBlank(rowData.getGstinOfRecipient()) || !Arrays.stream(userGSTN)
                                    .anyMatch(rowData.getGstinOfRecipient()::equalsIgnoreCase)) {
                        markErrorNAddErrorCode(rowData, "|E00520", "");
                    }

                    isFpMatchWithFpList(rowData, fpList);

                    if (!StringUtils.isBlank(rowData.getImportType())
                                    && !inputTypeList.contains(rowData.getImportType())) {
                        markErrorNAddErrorCode(rowData, "|I50032", "");
                    }

                    try {

                        if (StringUtils.isBlank(rowData.getImportType()) || "0".equals(rowData.getImportType())) {
                            rowData.setImportType("Inputs");
                            if (StringUtils.isNotBlank(rowData.getHsnSacCode()) && rowData.getHsnSacCode().length() > 2
                                            && "99".equalsIgnoreCase(rowData.getHsnSacCode().substring(0, 2))) {
                                rowData.setImportType("Input Services");
                            }
                        }

                        else {
                            if ("IN".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Inputs");
                            } else if ("INS".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Input Services");
                            } else if ("CG".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Capital Goods");
                            }
                        }

                        if (StringUtils.isBlank(rowData.getItcEligible())
                                        || "Inputs".equalsIgnoreCase(rowData.getImportType())
                                        || "IN".equalsIgnoreCase(rowData.getImportType())
                                        || "Input Services".equalsIgnoreCase(rowData.getImportType())
                                        || "INS".equalsIgnoreCase(rowData.getImportType())
                                        || "Capital Goods".equalsIgnoreCase(rowData.getImportType())
                                        || "CG".equalsIgnoreCase(rowData.getImportType())) {
                            rowData.setItcEligible("Eligible");
                        }

                        if (!(rowData.getDocType().equalsIgnoreCase("inv")
                                        || rowData.getDocType().equalsIgnoreCase("crn")
                                        || rowData.getDocType().equalsIgnoreCase("dbn"))) {
                            rowData.setErrorCodeList(rowData.getErrorCodeList().append("|E00013"));
                            rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(""));
                            rowData.setValid(false);
                        }

                        rowData.setDocType(einvdocTypeToGstr2Doctype(rowData.getOrgInvoiceCategory().toUpperCase()));

                        InwardINVDataTypeValidations invDataTypeCheck = new InwardINVDataTypeValidations();
                        invDataTypeCheck.validateDataType(rowData);
                        invDataTypeCheck = null;
                        

                        
                            InwardINVValidationRules invTemplValidations = new InwardINVValidationRules();
                            String dilutedValidation = uploadRequestDTO.getInwardValidationRule();
                            invTemplValidations.validateRules(rowData, dilutedValidation, stateCodeMap, portCodeMap,
                                            govtRateMap,tdsSections);
                        
                    } catch (Exception ex) {
                        log.error("Error in runParallalProcessingValidations" + ex);
                        log.error("Error generated:", ex);
                        markErrorNAddErrorCode(rowData, ValidationConstant.EINVOICE_ERROR_CODE_DE1000, "");
                    }
                    validatedList.add(rowData);
                });
            }
        

        return validatedList;
    }

    

	/**
     * Start processing crn data.
     *
     * @param rowCRNPoJoList
     *            the row CRN po jo list
     * @param uploadRequestDTO
     *            the upload request DTO
     */
    public void startProcessingCrnData(List<InwardInvoiceCDNTemplateDTO> rowCRNPoJoList,
                    UploadReqDTO uploadRequestDTO) {
        List<InwardInvoiceCDNTemplateDTO> validatedList = null;
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        boolean isJavaRulesEnables = Boolean.TRUE;
        cdnStateCodeMap = commonCommunicationDao.getStateCodeList();
        cdnPortCodeMap = commonCommunicationDao.getPortCodeList();
        cdnGovtRateMap = commonCommunicationDao.getGovtRateList();
        tdsSections = commonCommunicationDao.getTdsSectionList();
        rowCRNSuccessPoJoList=new ArrayList<>();
        rowCdnErrorPoJoList=new ArrayList<>();
        try {
            if (rowCRNPoJoList.size() > 0) {
                validatedList = validateCDN(rowCRNPoJoList, uploadRequestDTO, isJavaRulesEnables);
            }
        } catch (Exception ex) {
            log.error("Error in " + "startProcessingCrnData");
        }
        if (validatedList != null && !validatedList.isEmpty()) {

            try {
            saveCdnSuccessRecord(rowCRNSuccessPoJoList, uploadRequestDTO, dateFormat, date,
                    Constants.THREADCOUNT);
            }
            catch(Exception | Error e)
            {
            	log.error("Error Generated ::", e);
            }
        }
        lineLevelError.clear();
        docLevelError.clear();
        itemLevelErrorMap.clear();

    }

    /**
     * Transform objets N check item level error CDN.
     *
     * @param rowCRNSuccessPoJoList2
     *            the row CRN success po jo list 2
     * @param rowErrorPoJoList2
     *            the row error po jo list 2
     * @param rowData
     *            the row data
     * @param uploadRequestDTO
     *            the upload request DTO
     */
    private void transformObjetsNCheckItemLevelErrorCDN(List<InwardInvoiceCDNTemplateDTO> rowCRNSuccessPoJoList2,
                    List<InwardInvoiceCDNTemplateDTO> rowErrorPoJoList2, InwardInvoiceCDNTemplateDTO rowData,
                    UploadReqDTO uploadRequestDTO) {

        String key = new StringBuilder().append(rowData.getGstinOfRecipient()).append(rowData.getGstinOfSupplier())
                        .append(rowData.getInwardNo()).toString();

        if (rowData.getErrorCodeList().indexOf("E00061") <= 0 && cdnLevelErrorMap.get(key) != null
                        && cdnLevelErrorMap.get(key).equalsIgnoreCase(key) && rowData.isValid()) {
            rowData.setValid(false);
            rowData.setErrorCodeList(rowData.getErrorCodeList().append(Constants.ITEM_LEVEL_ERROR_CODE));

        }

        if (rowData.getErrorCodeList().indexOf("E00056") <= 0 && cdnLineLevelError.get(key) != null
                        && cdnLineLevelError.get(key).size() > 1) {
            rowData.setErrorCodeList(rowData.getErrorCodeList().append("|E00056"));
            rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(""));
            rowData.setValid(false);
        }

        String docLevelErrorkey = new StringBuilder().append(rowData.getGstinOfRecipient())
                        .append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo()).toString();

        if (rowData.getErrorCodeList().indexOf("I50110") <= 0 && cdnDocLevelError.get(docLevelErrorkey) != null
                        && cdnDocLevelError.get(docLevelErrorkey).size() > 1) {
            rowData.setErrorCodeList(rowData.getErrorCodeList().append("|I50110"));
            rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(""));
            rowData.setValid(false);
        }

        if (!rowData.isValid()) {
            rowErrorPoJoList2.add(rowData);
        } else {
            if (einvdocTypeToGstr2Doctype(rowData.getOrgDocType().toUpperCase()).equals(rowData.getDocType())) {
                rowCRNSuccessPoJoList2.add(rowData);
            }

        }

    }

    /**
     * Validate CDN.
     *
     * @param rowCRNPoJoList
     *            the row CRN po jo list
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param isJavaRulesEnables
     *            the is java rules enables
     * @return the list
     */
    private List<InwardInvoiceCDNTemplateDTO> validateCDN(List<InwardInvoiceCDNTemplateDTO> rowCRNPoJoList,
                    UploadReqDTO uploadRequestDTO, boolean isJavaRulesEnables) {

        fp = uploadRequestDTO.getMonth() + uploadRequestDTO.getYear();
        CopyOnWriteArrayList<InwardInvoiceCDNTemplateDTO> validatedList = new CopyOnWriteArrayList<InwardInvoiceCDNTemplateDTO>();
        List<List<InwardInvoiceCDNTemplateDTO>> partList = Lists.partition(rowCRNPoJoList, Constants.THREADCOUNT);
        Map<String, List<String>> invoiceExistInFpMap = new HashMap<String, List<String>>();
        Map<String, String> hsnCodeMap = commonCommunicationDao.getHsnCodeList();
        List<String> uomList = commonCommunicationDao.getUomQuery();
        int totalProcessedRec = 0;
        for (List<InwardInvoiceCDNTemplateDTO> sublist : partList) {

            totalProcessedRec = totalProcessedRec + sublist.size();

            List<InwardInvoiceCDNTemplateDTO> rulesValidatedsublist = runCRNParallalProcessingValidations(sublist,
                            uploadRequestDTO, isJavaRulesEnables, invoiceExistInFpMap, hsnCodeMap, uomList);

            rulesValidatedsublist.forEach(rowData -> {

                Boolean isInvDiluted = DroolUtil.checkIfDiluted(uploadRequestDTO.getInwardValidationRule(),
                                ErrorCodes.INVOICEHAVESAMEDOCNO); // Ask why it
                                                                  // is added

                try {

                	
                	
                    cdnMarkLineLevelError(rowData, uploadRequestDTO);
                	

                    
                        cdnMarkDocNoLevelError(rowData, uploadRequestDTO);
                    

                } catch (Exception ex) {

                    rowData.setValid(false);
                    rowData.setErrorCodeList(
                                    rowData.getErrorCodeList().append(ValidationConstant.EINVOICE_ERROR_CODE_DE1000));
                    log.error("Error generated:", ex);
                }
                
                validatedList.add(rowData);
                
            });
        }
        validatedList.forEach(rowData->
        {
        	transformObjetsNCheckItemLevelErrorCDN(rowCRNSuccessPoJoList, rowCdnErrorPoJoList, rowData,
              uploadRequestDTO);
        });
        return validatedList;
    }

    /**
     * Cdn mark doc no level error.
     *
     * @param rowData
     *            the row data
     * @param uploadRequestDTO
     *            the upload request DTO
     */
    private void cdnMarkDocNoLevelError(InwardInvoiceCDNTemplateDTO rowData, UploadReqDTO uploadRequestDTO) {

        String lineItemLevelErrorkey = new StringBuilder().append(rowData.getGstinOfRecipient())
                        .append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo()).toString();

       
        String lineItemLevelErrorValue = "";
        
            lineItemLevelErrorValue = new StringBuilder().append(rowData.getGstinOfRecipient())
                            .append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo())
                            .append(rowData.getInwardDate()).append(rowData.getPlaceOfSupply())
                            .append(rowData.getSupplierStateCode()).append(rowData.getDiffPercent())
                            .append(rowData.getOrgSupplyType()).append(rowData.getInvoiceCategory())
                            .append(rowData.getReverseCharge()).append(rowData.getSupplierName())
                            .append(rowData.getDocNo()).append(rowData.getDocDate()).append(rowData.getOrgDocType())
                            .toString();

        if (cdnDocLevelError.get(lineItemLevelErrorkey) == null) {
            Set<String> setLineItem = new HashSet<>();
            setLineItem.add(lineItemLevelErrorValue);
            docLevelError.put(lineItemLevelErrorkey, setLineItem);

        } else if (cdnDocLevelError.get(lineItemLevelErrorkey) != null
                        && cdnDocLevelError.get(lineItemLevelErrorkey).size() == 1) {
            Set<String> setLineItem = cdnDocLevelError.get(lineItemLevelErrorkey);
            setLineItem.add(lineItemLevelErrorValue);
            cdnDocLevelError.put(lineItemLevelErrorkey, setLineItem);
        }

        if (cdnDocLevelError.get(lineItemLevelErrorkey) != null && cdnDocLevelError.get(lineItemLevelErrorkey).size() > 1) {
            rowData.setErrorCodeList(rowData.getErrorCodeList().append("|I50110"));
            rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(""));
            rowData.setValid(false);
        }
    }

    /**
     * Cdn mark line level error.
     *
     * @param rowData
     *            the row data
     * @param uploadRequestDTO
     *            the upload request DTO
     */
    private void cdnMarkLineLevelError(InwardInvoiceCDNTemplateDTO rowData, UploadReqDTO uploadRequestDTO) {

        String lineItemLevelErrorkey = new StringBuilder().append(rowData.getGstinOfRecipient())
                        .append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo()).toString();

        String lineItemLevelErrorValue = "";
       
            lineItemLevelErrorValue = new StringBuilder().append(rowData.getGstinOfRecipient())
                            .append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo())
                            .append(rowData.getInwardDate()).append(rowData.getPlaceOfSupply())
                            .append(rowData.getSupplierStateCode()).append(rowData.getDiffPercent())
                            .append(rowData.getOrgSupplyType()).append(rowData.getInvoiceCategory())
                            .append(rowData.getReverseCharge()).append(rowData.getSupplierName())
                            .append(rowData.getDocNo()).append(rowData.getDocDate()).append(rowData.getOrgDocType())
                            .append(rowData.getTdsSection())
                            .toString();
        
        
        

        if (cdnLineLevelError.get(lineItemLevelErrorkey) == null) {
            Set<String> setLineItem = new HashSet<>();
            setLineItem.add(lineItemLevelErrorValue);
            cdnLineLevelError.put(lineItemLevelErrorkey, setLineItem);

        } else if (cdnLineLevelError.get(lineItemLevelErrorkey) != null
                        && cdnLineLevelError.get(lineItemLevelErrorkey).size() == 1) {
            Set<String> setLineItem = cdnLineLevelError.get(lineItemLevelErrorkey);
            setLineItem.add(lineItemLevelErrorValue);
            cdnLineLevelError.put(lineItemLevelErrorkey, setLineItem);
        }

        if (cdnLineLevelError.get(lineItemLevelErrorkey) != null && cdnLineLevelError.get(lineItemLevelErrorkey).size() > 1) {
            rowData.setErrorCodeList(rowData.getErrorCodeList().append("|E00056"));
            rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(""));
            rowData.setValid(false);
        }
    }

    /**
     * Run CRN parallal processing validations.
     *
     * @param sublist
     *            the sublist
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param isJavaRulesEnables
     *            the is java rules enables
     * @param invoiceExistInFpMap
     *            the invoice exist in fp map
     * @param hsnCodeMap
     *            the hsn code map
     * @param uomList
     *            the uom list
     * @return the list
     */
    private List<InwardInvoiceCDNTemplateDTO> runCRNParallalProcessingValidations(
                    List<InwardInvoiceCDNTemplateDTO> sublist, UploadReqDTO uploadRequestDTO,
                    boolean isJavaRulesEnables, Map<String, List<String>> invoiceExistInFpMap,
                    Map<String, String> hsnCodeMap, List<String> uomList) {
        List<List<InwardInvoiceCDNTemplateDTO>> partList = Lists.partition(sublist, Constants.THREADCOUNT);
        final String methodName = "";

        List<InwardInvoiceCDNTemplateDTO> validatedList = new ArrayList<>(sublist.size());
        Map<String, Map<String, String>> suppGSTNWiseMap = new HashMap<String, Map<String, String>>();
        Map<String, Map<String, String>> ictCclaimedListMap = new HashMap<String, Map<String, String>>();
        String[] fpList = uploadRequestDTO.getMonth().toArray(new String[uploadRequestDTO.getMonth().size()]);
        for (List<InwardInvoiceCDNTemplateDTO> devidedList : partList) {
            if (true) {
                devidedList.forEach(rowData -> {
                    try {
                        // rowData
                        String uom = rowData.getUom();
                        int totalSize = partList.size();
                        if (!StringUtils.isBlank(rowData.getImportType())
                                        && !inputTypeList.contains(rowData.getImportType())) {
                            rowData = logBusinessRulesErrors(rowData, "|I50032", "|Business Error");
                        }
                        if (StringUtils.isBlank(rowData.getImportType()) || "0".equals(rowData.getImportType())) {
                            rowData.setImportType("Inputs");
                            if (rowData.getHsnSacCode() != null && rowData.getHsnSacCode().length() > 2
                                            && "99".equalsIgnoreCase(rowData.getHsnSacCode().substring(0, 2))) {
                                rowData.setImportType("Input Services");
                            }
                        } else {
                            if ("IN".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Inputs");
                            } else if ("INS".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Input Services");
                            } else if ("CG".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Capital Goods");
                            }
                        }
                       
                        if (StringUtils.isBlank(rowData.getItcEligible())
                                        || "Inputs".equalsIgnoreCase(rowData.getImportType())
                                        || "IN".equalsIgnoreCase(rowData.getImportType())
                                        || "Input Services".equalsIgnoreCase(rowData.getImportType())
                                        || "INS".equalsIgnoreCase(rowData.getImportType())
                                        || "Capital Goods".equalsIgnoreCase(rowData.getImportType())
                                        || "CG".equalsIgnoreCase(rowData.getImportType())) {
                            rowData.setItcEligible("Eligible");
                        }
                        rowData.setPreGst("n");
                        rowData.setReason("");

                        String sameInDiffMonth = rowData.getInwardNo() + rowData.getGstinOfSupplier();

                        if (StringUtils.isNotBlank(sameInDiffMonth)) {
                            sameInDiffMonth = sameInDiffMonth.toLowerCase();
                        }
                        String[] userGSTN = null;
                        if (Constants.PAN.equals(uploadRequestDTO.getPanOrGstn())) {
                            userGSTN = commonCommunicationDao.getGstinFromDB(uploadRequestDTO.getGstinOrPanList().get(0),
                                            mstDatabseName);
                        } else if (Constants.GSTIN.equals(uploadRequestDTO.getPanOrGstn())) {
                            userGSTN = uploadRequestDTO.getGstinOrPanList()
                                            .toArray(new String[uploadRequestDTO.getGstinOrPanList().size()]);

                        }


                        if (StringUtils.isBlank(rowData.getGstinOfRecipient()) || !Arrays.stream(userGSTN)
                                        .anyMatch(rowData.getGstinOfRecipient()::equalsIgnoreCase)) {
                            markErrorNAddErrorCode(rowData, "|E00520", "");
                        }

                        if (rowData.getFillingPeriod().isBlank()) {
                         	markErrorNAddErrorCode(rowData, ValidationConstant.ERRORCODEE00352, "");
                         }
                        
                        isFpMatchWithFpList(rowData, fpList);

                        

                            String supplierGstnInwardNo = rowData.getGstinOfSupplier() + rowData.getInwardNo();
                            if (StringUtils.isNotBlank(supplierGstnInwardNo)) {
                                supplierGstnInwardNo = supplierGstnInwardNo.toLowerCase();
                            }

                            int isduplicateInvoiceInDiffMonth = 0;
                            if (totalSize < 5000) {
                                isduplicateInvoiceInDiffMonth = commonCommunicationDao.getInwardResultFPCountCDN(
                                                rowData.getGstinOfRecipient(), rowData.getInwardNo(),
                                                rowData.getInwardDate(), rowData.getGstinOfSupplier(), rowData.getFillingPeriod(),yearIdMap.get(rowData.getFillingPeriod()));

                            } else {
                            	
                                // Check invoice already saved in the GSTN
                                String keyCheckInBatchData = rowData.getGstinOfRecipient() + uploadRequestDTO.getBatchNo();
                                List<String> invoiceList = null;
                                if (suppGSTNWiseMap.get(keyCheckInBatchData) == null) {
                                    invoiceList = commonCommunicationDao.getDuplicateFPInDiffMonthCDN(
                                                    rowData.getGstinOfSupplier(), rowData.getGstinOfRecipient(), yearIdMap.get(rowData.getFillingPeriod()),
                                                    fp);
                                    Map<String, String> map = invoiceList.stream()
                                                    .collect(Collectors.toMap(str -> str, str -> str));
                                    suppGSTNWiseMap.put(keyCheckInBatchData, map);
                                    if (suppGSTNWiseMap.get(keyCheckInBatchData).get(supplierGstnInwardNo) != null) {
                                        isduplicateInvoiceInDiffMonth++;
                                    }

                                } else {
                                    Map<String, String> map = suppGSTNWiseMap.get(keyCheckInBatchData);
                                    if (map != null && map.get(supplierGstnInwardNo) != null) {
                                        isduplicateInvoiceInDiffMonth++;
                                    }
                                }
                            }

                            String mapKey = rowData.getInwardNo() + rowData.getGstinOfSupplier();

                            if (StringUtils.isNotBlank(mapKey)) {
                                mapKey = mapKey.toLowerCase();
                            }

                            String itcClaimedKey = rowData.getGstinOfRecipient() + uploadRequestDTO.getBatchNo();
                            if (isduplicateInvoiceInDiffMonth > 0) {
                                markErrorNAddErrorCode(rowData, Constants.COMMUNICATION_ERROR_CODE_O0093, "");
                            }
//                            int isItcClaim = 0;
                            if (yearIdMap.containsKey(rowData.getFillingPeriod())) {
                                rowData.setYearId(yearIdMap.get(rowData.getFillingPeriod()));
                            } else {
                                rowData.setYearId("");
                                markErrorNAddErrorCode(rowData, Constants.EINVOICE_ERROR_CODE_E00514, "");
                            }


                            
                        
                        
                        if (StringUtils.isNotBlank(uom)) {
                            if (!uomList.contains(uom.toUpperCase())) {
                                rowData = logBusinessRulesErrors(rowData, "|E00020", "");
                            }
                        }
//##############################################################################################################						
                        List<InwardInvoiceCDNTemplateDTO> getLatestInvoice = commonCommunicationDao.getinvoiceForInwardCDN(rowData.getGstinOfRecipient(), rowData.getOrgInvoiceNo(),
								rowData.getOrgInvoiceDate(), rowData.getGstinOfSupplier(), fp);
                    

                        
                        String invoiceAvailable = "false";
						String invoiceCategory = "0";
						String importType = "input";
						String gstinCustomer = "";
						String orignalDocType = "";
						String tableNo = "";
						int haveOrginalData = 0;
						if (getLatestInvoice.size() > 0) {
							invoiceAvailable = "true";
							haveOrginalData = 1;
							invoiceCategory = getLatestInvoice.get(0).getOrgInvoiceCategory();
							importType = getLatestInvoice.get(0).getImportType();
							gstinCustomer = getLatestInvoice.get(0).getGstinOfSupplier();
							orignalDocType = getLatestInvoice.get(0).getDocType();
							tableNo = getLatestInvoice.get(0).getTableNo();
						} else {
							invoiceAvailable = "true";
							invoiceCategory = rowData.getOrgInvoiceCategory();
							importType = rowData.getImportType();
							gstinCustomer = rowData.getGstinOfSupplier();

							if ("b2b".equalsIgnoreCase(invoiceCategory)) {

								orignalDocType = "regular tax invoice";
							} else if ("dexp".equalsIgnoreCase(invoiceCategory)) {
								orignalDocType = "deemed export invoice";
							} else if ("rcm".equalsIgnoreCase(invoiceCategory)) {
								orignalDocType = "rcm invoice";
							} else if ("sezwp".equalsIgnoreCase(invoiceCategory) || "sezwop".equalsIgnoreCase(invoiceCategory) || "impgsez".equalsIgnoreCase(invoiceCategory)) {
								orignalDocType = "sez invoice";
							} else if ("isd".equalsIgnoreCase(invoiceCategory)) {
								orignalDocType = "isd invoice";
							} else if ("nil".equalsIgnoreCase(invoiceCategory) || "comp".equalsIgnoreCase(invoiceCategory) || "exm".equalsIgnoreCase(invoiceCategory)
									|| "non".equalsIgnoreCase(invoiceCategory)) {
								orignalDocType = "bill of supply";
							} else if ("impg".equalsIgnoreCase(invoiceCategory) || "imps".equalsIgnoreCase(invoiceCategory)) {
								orignalDocType = "import invoice";
							}
							tableNo = "";
						}
                        
                            rowData.setDocType(einvdocTypeToGstr2Doctype(rowData.getOrgDocType().toUpperCase()));
                            InwardICDNDataTypeValidations invDataTypeCheck = new InwardICDNDataTypeValidations();

                            try {

                                invDataTypeCheck.validateDataType(rowData, uploadRequestDTO);
                                invDataTypeCheck = null;

                                
                                    InwardCDNValidationRules invTemplValidations = new InwardCDNValidationRules();
                                    String dilutedValidation = uploadRequestDTO.getInwardValidationRule();
                                    invTemplValidations.validateRules(rowData, dilutedValidation, invoiceAvailable,
                                                    gstinCustomer, invoiceCategory, haveOrginalData, orignalDocType,
                                                    rowData.getFillingPeriod(), cdnStateCodeMap, cdnPortCodeMap,
                                                    cdnGovtRateMap,tdsSections);
                                
                            } catch (Exception ex) {
                                rowData.setValid(false);
                                rowData.setErrorCodeList(rowData.getErrorCodeList()
                                                .append(ValidationConstant.EINVOICE_ERROR_CODE_DE1000));
                                log.error("Error generated:", ex);
                                log.error(methodName, ex);
                            }

                            if (Constants.ISHSNVALIDATIONALLOWED == 0
                                            && hsnCodeMap.get(rowData.getHsnSacCode()) == null) {
                                rowData.setValid(false);
                                rowData.setErrorCodeList(rowData.getErrorCodeList().append("|E00169"));
                                rowData.setErrorDescriptionList(rowData.getErrorDescriptionList()
                                                .append(""));
                            }

                      
                            

                        
                        String key = new StringBuilder().append(rowData.getGstinOfRecipient())
                                        .append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo()).append(fp)
                                        .toString();

                        if (!rowData.isValid()) {
                            cdnLevelErrorMap.put(key, key);
                        }

                    } catch (Exception ex) {
                        rowData.setValid(false);
                        rowData.setErrorCodeList(rowData.getErrorCodeList()
                                        .append(ValidationConstant.EINVOICE_ERROR_CODE_DE1000));
                        log.error("Error generated:", ex);
                    }
                    validatedList.add(rowData);

                });
            }

        }

        return validatedList;
    }

    /**
     * Einvdoc type to gstr 2 doctype.
     *
     * @param doctype
     *            the doctype
     * @return the string
     */
    private String einvdocTypeToGstr2Doctype(String doctype) {
        String gstr1Doctype = "";
        switch (doctype) {
        case "B2B":
            gstr1Doctype = "Regular Tax Invoice";
            break;
        case "ISD":
            gstr1Doctype = "ISD Invoice";
            break;
        case "RCM":
            gstr1Doctype = "RCM Invoice";
            break;
        case "NIL":
        case "EXM":
        case "NON":
        case "COMP":
            gstr1Doctype = "Bill of supply";
            break;
        case "IMPG":
        case "IMPS":
            gstr1Doctype = "Import Invoice";
            break;
        case "SEZWP":
        case "SEZWOP":
        case "IMPGSEZ":
            gstr1Doctype = "SEZ Invoice";
            break;
        case "DEXP":
            gstr1Doctype = "Deemed Export Invoice";
            break;
        case "CRN":
            gstr1Doctype = "Credit note";
            break;
        case "DBN":
            gstr1Doctype = "Debit note";
            break;
        default:
            gstr1Doctype = doctype;
            break;
        }

        return gstr1Doctype;
    }

    /**
     * Log business rules errors.
     *
     * @param rowData
     *            the row data
     * @param errorCode
     *            the error code
     * @param errorMsg
     *            the error msg
     * @return the inward invoice CDN template DTO
     */
    private InwardInvoiceCDNTemplateDTO logBusinessRulesErrors(InwardInvoiceCDNTemplateDTO rowData, String errorCode,
                    String errorMsg) {
        rowData.setErrorCodeList(rowData.getErrorCodeList().append(errorCode));
        rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(errorMsg));
        rowData.setValid(false);
        return rowData;
    }

    /**
     * Mark error N add error code.
     *
     * @param rowData
     *            the row data
     * @param string
     *            the string
     * @param string2
     *            the string 2
     */
    private void markErrorNAddErrorCode(InwardInvoiceCDNTemplateDTO rowData, String string, String string2) {
        rowData.setValid(false);
        rowData.setErrorCodeList(rowData.getErrorCodeList().append(string));
        rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(string2));

    }

    /**
     * Save cdn success record.
     *
     * @param sucessInvDataList
     *            the sucess inv data list
     * @param validationBO
     *            the validation BO
     * @param dateFormat
     *            the date format
     * @param date
     *            the date
     * @param threadCnt
     *            the thread cnt
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    public void saveCdnSuccessRecord(List<InwardInvoiceCDNTemplateDTO> sucessInvDataList, UploadReqDTO validationBO,
                    DateFormat dateFormat, Date date, int threadCnt) throws VendorInvoiceServerException {
        validationBO.getYear();

        int partion = threadCnt;
        String methodName = "saveCdnSuccessRecord";

        log.info(Constants.LOGMESSAGE, methodName);

        Map<String, String> entityMap = new HashMap<>();

        List<List<InwardInvoiceCDNTemplateDTO>> partList = Lists.partition(sucessInvDataList, partion);

        for (List<InwardInvoiceCDNTemplateDTO> sublist : partList) {

            sublist.forEach(rowdata -> {

                String entityId = "";

                try {

                    if (entityMap.get(rowdata.getGstinOfRecipient()) == null) {
                        entityId = commonCommunicationDao.getEntityId(rowdata.getGstinOfRecipient());
                        entityMap.put(rowdata.getGstinOfRecipient(), entityId);
                    } else {
                        entityId = entityMap.get(rowdata.getGstinOfRecipient());
                    }

                    if (" ".equals(rowdata.getImportType()) || "".equals(rowdata.getImportType())) {
                        rowdata.setImportType("Inputs");
                        if (rowdata.getHsnSacCode().length() > 2
                                        && rowdata.getHsnSacCode().substring(0, 2).equalsIgnoreCase("99")) {
                            rowdata.setImportType("Input Services");
                        }

                    } else {
                        if ("IN".equalsIgnoreCase(rowdata.getImportType())) {
                            rowdata.setImportType("Inputs");
                        } else if ("INS".equalsIgnoreCase(rowdata.getImportType())) {
                            rowdata.setImportType("Input Services");
                        } else if ("CG".equalsIgnoreCase(rowdata.getImportType())) {
                            rowdata.setImportType("Capital Goods");
                        }
                    }

                    if (" ".equals(rowdata.getItcEligible()) || "".equals(rowdata.getItcEligible())) {
                        rowdata.setItcEligible("Eligible");
                    } else if (("Inputs".equalsIgnoreCase(rowdata.getImportType()))
                                    || "IN".equalsIgnoreCase(rowdata.getImportType())) {
                        rowdata.setItcEligible("Eligible");
                    } else if ("Input Services".equalsIgnoreCase(rowdata.getImportType())
                                    || "INS".equalsIgnoreCase(rowdata.getImportType())) {
                        rowdata.setItcEligible("Eligible");
                    } else if ("Capital Goods".equalsIgnoreCase(rowdata.getImportType())
                                    || "CG".equalsIgnoreCase(rowdata.getImportType())) {
                        rowdata.setItcEligible("Eligible");
                    }
                    if ("REV-42&43".equalsIgnoreCase(rowdata.getItcIneligibleReversalIndicator())
                                    || "REV-OTH".equalsIgnoreCase(rowdata.getItcIneligibleReversalIndicator())) {
                        rowdata.setItcEligible("reversal");
                    }
                    if ("INELG-17(5)".equalsIgnoreCase(rowdata.getItcIneligibleReversalIndicator())
                                    || "INELG-OTH".equalsIgnoreCase(rowdata.getItcIneligibleReversalIndicator())) {
                        rowdata.setItcEligible("ineligible");
                    }
                    String invoiceCategory = "0";
                    String importType = "";
                    
                    String taxpayerVendorGstingConcat=rowdata.getGstinOfRecipient()+rowdata.getGstinOfSupplier();
                    
                   if(saveCdnMap.get(taxpayerVendorGstingConcat)!=null)
                   {
                	   if(saveCdnMap.get(taxpayerVendorGstingConcat).get(rowdata.getInwardNo()+rowdata.getInwardDate()+rowdata.getGstinOfSupplier())!=null)
                	   {
                		     String [] fielsList= saveCdnMap.get(taxpayerVendorGstingConcat).get(rowdata.getInwardNo()+rowdata.getInwardDate()+rowdata.getGstinOfSupplier()).split("~");
                		     invoiceCategory = fielsList[1];
                             importType = fielsList[2];    
                		     //doc_type,'~',invoice_category,'~',import_type,'~',table_no,'~',fp
                	   }
                	   else {

                           invoiceCategory = extracted(rowdata, invoiceCategory,importType);
                       
                	   }
                	   
                   }
                   else {
                	   Map<String, String>getSaveCdnMap=commonCommunicationDao
                       .getOrgInvoiceForInwardCDN(rowdata.getGstinOfRecipient(), rowdata.getOrgInvoiceNo(),
                                       rowdata.getOrgInvoiceDate(), rowdata.getGstinOfSupplier(), fp);

                	   saveCdnMap.put(taxpayerVendorGstingConcat, getSaveCdnMap);   
                	   invoiceCategory = extracted(rowdata, invoiceCategory,importType);
				}
                    

                    InwardCDNBDRL inwardCreditDebitBDRL = new InwardCDNBDRL();
                    inwardCreditDebitBDRL.applyBDRL(rowdata, invoiceCategory);

                } catch (Exception ex) {
                    log.error(Constants.LOGERRORMESSAGE, methodName);

                }

            });
        }
        saveCdnMap.clear();
    }
    

    private String extracted(InwardInvoiceCDNTemplateDTO rowdata, String invoiceCategory, String importType) {
		
		importType = rowdata.getImportType();
		   rowdata.getGstinOfSupplier();
		   DroolUtil.hsnCodeCheck(rowdata.getHsnSacCode(), importType);
		   String orgInvoiceCategory = rowdata.getOrgInvoiceCategory();
		   if (orgInvoiceCategory.equalsIgnoreCase("b2b")
		                   || rowdata.getOrgInvoiceCategory().equalsIgnoreCase("isd")
		                   || rowdata.getOrgInvoiceCategory().equalsIgnoreCase("sez")
		                   || rowdata.getOrgInvoiceCategory().equalsIgnoreCase("sezwp")
		                   || rowdata.getOrgInvoiceCategory().equalsIgnoreCase("sezwop")
		                   || rowdata.getOrgInvoiceCategory().equalsIgnoreCase("dexp")) {
		       invoiceCategory = "B2B";
		   } else if ("RCM".equalsIgnoreCase(orgInvoiceCategory)
		                   && (rowdata.getGstinOfSupplier().length() == 15)) {
		       invoiceCategory = "B2B";
		   } else if ("RCM".equalsIgnoreCase(orgInvoiceCategory)
		                   && ("0".equals(rowdata.getGstinOfSupplier())
		                                   || "".equals(rowdata.getGstinOfSupplier())
		                                   || StringUtils.isBlank(rowdata.getGstinOfSupplier()))) {
		       invoiceCategory = "B2BUR";
		   } else if ("IMPS".equalsIgnoreCase(orgInvoiceCategory)) {
		       invoiceCategory = "IMPS";
		   } else if ("IMPGSEZ".equalsIgnoreCase(orgInvoiceCategory)) {
		       invoiceCategory = "IMPGSEZ";
		   } else if ("IMPG".equalsIgnoreCase(orgInvoiceCategory)) {
		       invoiceCategory = "IMPG";
		   } else if ("NIL".equalsIgnoreCase(orgInvoiceCategory)
		                   && Double.parseDouble(rowdata.getNilRatedAmt()) > 0) {
		       invoiceCategory = "Nil rate";
		   } else if ("EXM".equalsIgnoreCase(orgInvoiceCategory)
		                   && Double.parseDouble(rowdata.getExemptedAmt()) > 0) {
		       invoiceCategory = "Exempt";
		   } else if ("COMP".equalsIgnoreCase(orgInvoiceCategory)
		                   && Double.parseDouble(rowdata.getCompositionAmt()) > 0) {
		       invoiceCategory = "Compo";
		   } else if ("NON".equalsIgnoreCase(orgInvoiceCategory)
		                   && Double.parseDouble(rowdata.getNonGstAmt()) > 0) {
		       invoiceCategory = "Non-GST";
		   }

		   if ("b2b".equalsIgnoreCase(invoiceCategory)) {
		   } else if ("rcm".equalsIgnoreCase(invoiceCategory)) {
		   } else if ("sezwp".equalsIgnoreCase(invoiceCategory)
		                   || "sezwop".equalsIgnoreCase(invoiceCategory)
		                   || "impgsez".equalsIgnoreCase(invoiceCategory)) {
		   } else if ("isd".equalsIgnoreCase(invoiceCategory)) {
		   } else if ("nil".equalsIgnoreCase(invoiceCategory) || "comp".equalsIgnoreCase(invoiceCategory)
		                   || "exm".equalsIgnoreCase(invoiceCategory)
		                   || "non".equalsIgnoreCase(invoiceCategory)) {
		   } else if ("impg".equalsIgnoreCase(invoiceCategory)
		                   || "imps".equalsIgnoreCase(invoiceCategory)) {
		   }
		   if ("isd".equalsIgnoreCase(rowdata.getOrgInvoiceCategory())) {
		   }
		return invoiceCategory;
	}

	/**
     * Manual validate and save data.
     *
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param rowINVPoJoList
     *            the row INV po jo list
     * @param rowCRNPoJoList
     *            the row CRN po jo list
     * @return the list
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
	public List<InwardInvoiceCDNTemplateDTO> manualValidateAndSaveData(UploadReqDTO uploadRequestDTO,
                    List<InwardInvoiceCDNTemplateDTO> rowINVPoJoList, List<InwardInvoiceCDNTemplateDTO> rowCRNPoJoList,List<PaymentDetails>paymentDetails,List<TdsDetails> tdsDetails) 
                    		throws IOException, VendorInvoiceServerException {

        String methodName = "validateAndSaveData";
        rowINVSuccessPoJoList = new ArrayList<>();
        rowCRNSuccessPoJoList = new ArrayList<>();
        rowInvErrorPoJoList = new ArrayList<>();
        rowCdnErrorPoJoList = new ArrayList<>();
        rowDocErrorPojoList = new ArrayList<>();
        try {

            commonCommunicationDao.setErrorDiscriptionForErrorList();
            yearIdMap = commonCommunicationDao.getYearId();
            if (!rowINVPoJoList.isEmpty()) {
                startProcessingInvInvoiceDetailsData(rowINVPoJoList, uploadRequestDTO);
            }
            if (!rowCRNPoJoList.isEmpty()) {
                startProcessingCrnInvoiceDetilsData(rowCRNPoJoList, uploadRequestDTO);
            }

            rowCdnErrorPoJoList.addAll(rowDocErrorPojoList);
            csvWriterService.writeSuccessNErrorDataInCSVFile(uploadRequestDTO, rowCRNSuccessPoJoList,
                            rowINVSuccessPoJoList, rowInvErrorPoJoList, rowCdnErrorPoJoList);
            String csvInvSuccessFilePath = CommonUtils.getINVSuccessFilePath(uploadRequestDTO, tempFolder);
            String csvCdnSuccessFilePath = CommonUtils.getCDNSuccessFilePath(uploadRequestDTO, tempFolder);
            if (!rowINVSuccessPoJoList.isEmpty() || !rowCRNSuccessPoJoList.isEmpty()) {
                commonCommunicationDao.gstInvoiceDetailsInvCdnInsert(csvInvSuccessFilePath, csvCdnSuccessFilePath,
                                Constants.SUCCESS_INV_TABLE, Constants.SUCCESS_CDN_TABLE);

            }

            // Exception Handling and Updating in the exception_log table in
            // Database
            Map<String, String> codesMap = commonDao.getErrorCodesDescription();
           

            CommonUtils.deleteTempFiles(tempFolder, uploadRequestDTO);
           
        
        if (!rowInvErrorPoJoList.isEmpty() && "INV".equals(rowINVPoJoList.get(0).getExcelDocType())) {
        	rowINVPoJoList.forEach(rowData->
        	{
        		rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(getErrorCodeDescription(rowData,rowData.getErrorCodeList().toString(), codesMap)));
        	});
            return rowInvErrorPoJoList;
        } else if ((!rowCdnErrorPoJoList.isEmpty() && "CRN".equals(rowCRNPoJoList.get(0).getExcelDocType()))
                        || (!rowCdnErrorPoJoList.isEmpty() && "DBN".equals(rowCRNPoJoList.get(0).getExcelDocType()))) {
        	rowCdnErrorPoJoList.forEach(rowData->
        	{
        		rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(getErrorCodeDescription(rowData,rowData.getErrorCodeList().toString(), codesMap)));
        	});
            return rowCdnErrorPoJoList;
        } else {
            return new ArrayList<>();

        }
        } catch (Exception ex) {
            log.error(Constants.PROCESSINGFILEEXCEPTIONLOG + uploadRequestDTO.getBatchNo(), ex);
            logIntoToExceptionTable(uploadRequestDTO, ex, methodName);
            throw new VendorInvoiceServerException(Constants.PROCESSINGFILEEXCEPTIONLOG);

            
        }
    }
    
    
    String getErrorCodeDescription(InwardInvoiceCDNTemplateDTO rowData,String codes, Map<String, String> errorCodeMap) {

        List<String>descriptionList=new ArrayList<>();
        String code = codes.replace("|", ",");
        String[] errorCodeList = code.split(",");
        
        String newErrorCode=code.substring(1);
        newErrorCode=newErrorCode.replace("|", ",");
        String[] newErrorCodeList=newErrorCode.split(",");
        String errorStringCodeList=String.join("|", newErrorCodeList); 
        if (errorCodeList.length > 1) {
            for (int i = 1; i < errorCodeList.length; i++) {
                String description = errorCodeMap.get(errorCodeList[i].trim());
                descriptionList.add(description);

            }
        }
        rowData.setErrorCode(errorStringCodeList);
        return String.join("|", descriptionList);
    }

    /**
     * Start processing crn invoice detils data.
     *
     * @param rowCRNPoJoList
     *            the row CRN po jo list
     * @param uploadRequestDTO
     *            the upload request DTO
     */
    private void startProcessingCrnInvoiceDetilsData(List<InwardInvoiceCDNTemplateDTO> rowCRNPoJoList,
                    UploadReqDTO uploadRequestDTO) {
        List<InwardInvoiceCDNTemplateDTO> validatedList = null;
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        boolean isJavaRulesEnables = Boolean.TRUE;

        cdnStateCodeMap = commonCommunicationDao.getStateCodeList();
        cdnPortCodeMap = commonCommunicationDao.getPortCodeList();
        cdnGovtRateMap = commonCommunicationDao.getGovtRateList();
        tdsSections = commonCommunicationDao.getTdsSectionList();
        try {
            if (rowCRNPoJoList.size() > 0) {
                validatedList = validateFrontEndInwardData(rowCRNPoJoList, uploadRequestDTO, isJavaRulesEnables);
            }
        } catch (Exception ex) {
            log.error("Error generated:", ex);
            log.error("Error in " + "startProcessingCrnData");
        }
        if (validatedList != null && !validatedList.isEmpty()) {
            validatedList.forEach(rowData -> {
                try {
                    transformObjetsNCheckItemLevelErrorCDN(rowCRNSuccessPoJoList, rowCdnErrorPoJoList, rowData,
                                    uploadRequestDTO);
                    saveCdnSuccessRecord(rowCRNSuccessPoJoList, uploadRequestDTO, dateFormat, date,
                                    Constants.THREADCOUNT);
                } catch (Exception | Error e) {

                }
            });
        }

    }

    private List<InwardInvoiceCDNTemplateDTO> validateFrontEndInwardData(
			List<InwardInvoiceCDNTemplateDTO> rowCRNPoJoList, UploadReqDTO uploadRequestDTO,
			boolean isJavaRulesEnables) {
        CopyOnWriteArrayList<InwardInvoiceCDNTemplateDTO> validatedList = new CopyOnWriteArrayList<InwardInvoiceCDNTemplateDTO>();
        List<List<InwardInvoiceCDNTemplateDTO>> partList = Lists.partition(rowCRNPoJoList, Constants.THREADCOUNT);
        Map<String, List<String>> invoiceExistInFpMap = new HashMap<String, List<String>>();
        Map<String, String> hsnCodeMap = commonCommunicationDao.getHsnCodeList();
        List<String> uomList = commonCommunicationDao.getUomQuery();
        int totalProcessedRec = 0;
        for (List<InwardInvoiceCDNTemplateDTO> sublist : partList) {

            totalProcessedRec = totalProcessedRec + sublist.size();

            List<InwardInvoiceCDNTemplateDTO> rulesValidatedsublist = runInvoiceDetailsCRNParallalProcessingValidations(
                            sublist, uploadRequestDTO, isJavaRulesEnables, invoiceExistInFpMap, hsnCodeMap, uomList);

            rulesValidatedsublist.forEach(rowData -> {

                Boolean isInvDiluted = DroolUtil.checkIfDiluted(uploadRequestDTO.getInwardValidationRule(),
                                ErrorCodes.INVOICEHAVESAMEDOCNO); // Ask why it
                                                                  // is added

                try {


                         cdnMarkLineLevelError(rowData, uploadRequestDTO);
                	

                   
                        cdnMarkDocNoLevelError(rowData, uploadRequestDTO);
                    

                } catch (Exception ex) {

                    rowData.setValid(false);
                    rowData.setErrorCodeList(
                                    rowData.getErrorCodeList().append(ValidationConstant.EINVOICE_ERROR_CODE_DE1000));
                    log.error("Error generated:", ex);
                }
                validatedList.add(rowData);
            });
        }
        return validatedList;
    }

	/**
     * Validate invoice details CDN.
     *
     * @param rowCRNPoJoList
     *            the row CRN po jo list
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param isJavaRulesEnables
     *            the is java rules enables
     * @return the list
     */
    private List<InwardInvoiceCDNTemplateDTO> validateInvoiceDetailsCDN(
                    List<InwardInvoiceCDNTemplateDTO> rowCRNPoJoList, UploadReqDTO uploadRequestDTO,
                    boolean isJavaRulesEnables) {
        CopyOnWriteArrayList<InwardInvoiceCDNTemplateDTO> validatedList = new CopyOnWriteArrayList<InwardInvoiceCDNTemplateDTO>();
        List<List<InwardInvoiceCDNTemplateDTO>> partList = Lists.partition(rowCRNPoJoList, Constants.THREADCOUNT);
        Map<String, List<String>> invoiceExistInFpMap = new HashMap<String, List<String>>();
        Map<String, String> hsnCodeMap = commonCommunicationDao.getHsnCodeList();
        List<String> uomList = commonCommunicationDao.getUomQuery();
        int totalProcessedRec = 0;
        for (List<InwardInvoiceCDNTemplateDTO> sublist : partList) {

            totalProcessedRec = totalProcessedRec + sublist.size();

            List<InwardInvoiceCDNTemplateDTO> rulesValidatedsublist = runInvoiceDetailsCRNParallalProcessingValidations(
                            sublist, uploadRequestDTO, isJavaRulesEnables, invoiceExistInFpMap, hsnCodeMap, uomList);

            rulesValidatedsublist.forEach(rowData -> {

                Boolean isInvDiluted = DroolUtil.checkIfDiluted(uploadRequestDTO.getInwardValidationRule(),
                                ErrorCodes.INVOICEHAVESAMEDOCNO); // Ask why it
                                                                  // is added

                try {

                	if(rowData.isValid()) {
                         cdnMarkLineLevelError(rowData, uploadRequestDTO);
                	}

                    if (rowData.isValid()) {
                        cdnMarkDocNoLevelError(rowData, uploadRequestDTO);
                    }

                } catch (Exception ex) {

                    rowData.setValid(false);
                    rowData.setErrorCodeList(
                                    rowData.getErrorCodeList().append(ValidationConstant.EINVOICE_ERROR_CODE_DE1000));
                    log.error("Error generated:", ex);
                }
                validatedList.add(rowData);
            });
        }
        return validatedList;
    }

    /**
     * Run invoice details CRN parallal processing validations.
     *
     * @param sublist
     *            the sublist
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param isJavaRulesEnables
     *            the is java rules enables
     * @param invoiceExistInFpMap
     *            the invoice exist in fp map
     * @param hsnCodeMap
     *            the hsn code map
     * @param uomList
     *            the uom list
     * @return the list
     */
    private List<InwardInvoiceCDNTemplateDTO> runInvoiceDetailsCRNParallalProcessingValidations(
                    List<InwardInvoiceCDNTemplateDTO> sublist, UploadReqDTO uploadRequestDTO,
                    boolean isJavaRulesEnables, Map<String, List<String>> invoiceExistInFpMap,
                    Map<String, String> hsnCodeMap, List<String> uomList) {
        List<List<InwardInvoiceCDNTemplateDTO>> partList = Lists.partition(sublist, Constants.THREADCOUNT);
        List<InwardInvoiceCDNTemplateDTO> validatedList = new ArrayList<>(sublist.size());
        Map<String, Map<String, String>> suppGSTNWiseMap = new HashMap<String, Map<String, String>>();
        new HashMap<String, Map<String, String>>();
        for (List<InwardInvoiceCDNTemplateDTO> devidedList : partList) {
            if (true) {
                devidedList.forEach(rowData -> {
                    try {
                        String s = rowData.getUom();
                        if (!StringUtils.isBlank(rowData.getImportType())
                                        && !inputTypeList.contains(rowData.getImportType())) {
                            rowData = logBusinessRulesErrors(rowData, "|I50032", "");
                        }
                        if (StringUtils.isBlank(rowData.getImportType()) || "0".equals(rowData.getImportType())) {
                            rowData.setImportType("Inputs");
                            if (rowData.getHsnSacCode() != null && rowData.getHsnSacCode().length() > 2
                                            && "99".equalsIgnoreCase(rowData.getHsnSacCode().substring(0, 2))) {
                                rowData.setImportType("Input Services");
                            }
                        } else {
                            if ("IN".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Inputs");
                            } else if ("INS".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Input Services");
                            } else if ("CG".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Capital Goods");
                            }
                        }

                        if (yearIdMap.containsKey(rowData.getFillingPeriod())) {
                            rowData.setYearId(yearIdMap.get(rowData.getFillingPeriod()));
                        } else {
                            rowData.setYearId("");
                            markErrorNAddErrorCode(rowData, Constants.EINVOICE_ERROR_CODE_E00514, "");
                        }

                        if (StringUtils.isBlank(rowData.getItcEligible())
                                        || "Inputs".equalsIgnoreCase(rowData.getImportType())
                                        || "IN".equalsIgnoreCase(rowData.getImportType())
                                        || "Input Services".equalsIgnoreCase(rowData.getImportType())
                                        || "INS".equalsIgnoreCase(rowData.getImportType())
                                        || "Capital Goods".equalsIgnoreCase(rowData.getImportType())
                                        || "CG".equalsIgnoreCase(rowData.getImportType())) {
                            rowData.setItcEligible("Eligible");
                        }
                        rowData.setPreGst("n");
                        rowData.setReason("");

                        String sameInDiffMonth = rowData.getInwardNo() + rowData.getGstinOfSupplier();

                        if (StringUtils.isNotBlank(sameInDiffMonth)) {
                            sameInDiffMonth = sameInDiffMonth.toLowerCase();
                        }

                        int diffrenceFPExist = 0;

                        String diffrenceFPExistKey = new StringBuilder().append(rowData.getGstinOfRecipient())
                                        .append("~").append(fp).append("~").append(yearId).toString();

                        List<String> invoiceListByNotInFP = null;
                        String keyCheckInBatchData = rowData.getGstinOfSupplier() + yearId + fp + "~"
                                        + rowData.getGstinOfRecipient();

                        if (invoiceExistInFpMap.get(diffrenceFPExistKey) == null) {

                            invoiceListByNotInFP = commonCommunicationDao.getDuplicateInwardCdnInDiffFP(uploadRequestDTO.getYear(), rowData.getFillingPeriod(),
                                    rowData.getGstinOfRecipient(), mstDatabseName, trnDatabaseName);

                            Map<String, String> map = invoiceListByNotInFP.stream()
                                            .collect(Collectors.toMap(str -> str, str -> str));
                            suppGSTNWiseMap.put(keyCheckInBatchData, map);
                            invoiceExistInFpMap.put(diffrenceFPExistKey, invoiceListByNotInFP);

                            if (suppGSTNWiseMap.get(keyCheckInBatchData).get(sameInDiffMonth) != null) {
                                diffrenceFPExist++;
                            }

                        } else {

                            Map<String, String> map = suppGSTNWiseMap.get(keyCheckInBatchData);
                            if (map != null && map.get(sameInDiffMonth) != null) {
                                diffrenceFPExist++;
                            }
                        }

                        if (diffrenceFPExist > 0) {
                            rowData = logBusinessRulesErrors(rowData, Constants.COMMUNICATION_ERROR_CODE_O0093, "");
                        }
                        int isExistCount = 0;

                        String mapKey = rowData.getInwardNo() + rowData.getGstinOfSupplier();

                        if (StringUtils.isNotBlank(mapKey)) {
                            mapKey = mapKey.toLowerCase();
                        }

                        if (isExistCount > 0) {
                            rowData = logBusinessRulesErrors(rowData, Constants.COMMUNICATION_ERRORCODE_E00253, "");
                        }

                        String uom = rowData.getUom();
						if (StringUtils.isNotBlank(uom)) {
                            if (!uomList.contains(uom.toUpperCase())) {
                                rowData = logBusinessRulesErrors(rowData, "|E00020", "");
                            }
                        }
					

                    

                            String invoiceAvailable = "false";
                            String invoiceCategory = "0";
                            String gstinCustomer = "";
                            String orignalDocType = "";
                            int haveOrginalData = 0;
                            invoiceAvailable = "true";
                            invoiceCategory = rowData.getOrgInvoiceCategory();
                            rowData.getImportType();
                            gstinCustomer = rowData.getGstinOfSupplier();

                            if ("b2b".equalsIgnoreCase(invoiceCategory)) {

                                orignalDocType = "regular tax invoice";
                            } else if ("dexp".equalsIgnoreCase(invoiceCategory)) {
                                orignalDocType = "deemed export invoice";
                            } else if ("rcm".equalsIgnoreCase(invoiceCategory)) {
                                orignalDocType = "rcm invoice";
                            } else if ("sezwp".equalsIgnoreCase(invoiceCategory)
                                            || "sezwop".equalsIgnoreCase(invoiceCategory)
                                            || "impgsez".equalsIgnoreCase(invoiceCategory)) {
                                orignalDocType = "sez invoice";
                            } else if ("isd".equalsIgnoreCase(invoiceCategory)) {
                                orignalDocType = "isd invoice";
                            } else if ("nil".equalsIgnoreCase(invoiceCategory)
                                            || "comp".equalsIgnoreCase(invoiceCategory)
                                            || "exm".equalsIgnoreCase(invoiceCategory)
                                            || "non".equalsIgnoreCase(invoiceCategory)) {
                                orignalDocType = "bill of supply";
                            } else if ("impg".equalsIgnoreCase(invoiceCategory)
                                            || "imps".equalsIgnoreCase(invoiceCategory)) {
                                orignalDocType = "import invoice";
                            }

                            rowData.setDocType(einvdocTypeToGstr2Doctype(rowData.getOrgDocType().toUpperCase()));
                            InwardICDNDataTypeValidations invDataTypeCheck = new InwardICDNDataTypeValidations();

                            try {

                                invDataTypeCheck.validateDataType(rowData, uploadRequestDTO);
                                invDataTypeCheck = null;

                                    InwardCDNValidationRules invTemplValidations = new InwardCDNValidationRules();
                                    String dilutedValidation = uploadRequestDTO.getInwardValidationRule();
                                    invTemplValidations.validateRules(rowData, dilutedValidation, invoiceAvailable,
                                                    gstinCustomer, invoiceCategory, haveOrginalData, orignalDocType,
                                                    rowData.getFillingPeriod(), cdnStateCodeMap, cdnPortCodeMap,
                                                    cdnGovtRateMap,tdsSections);
                                
                            } catch (Exception ex) {
                                rowData.setValid(false);
                                rowData.setErrorCodeList(rowData.getErrorCodeList()
                                                .append(ValidationConstant.EINVOICE_ERROR_CODE_DE1000));
                                log.error("Error generated:", ex);
                            }

                            if (Constants.ISHSNVALIDATIONALLOWED == 0
                                            && hsnCodeMap.get(rowData.getHsnSacCode()) == null) {
                                rowData.setValid(false);
                                rowData.setErrorCodeList(rowData.getErrorCodeList().append("|E00169"));
                                rowData.setErrorDescriptionList(rowData.getErrorDescriptionList()
                                                .append(""));
                            }

                        

                            

                        
                        String key = new StringBuilder().append(rowData.getGstinOfRecipient())
                                        .append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo()).append(fp)
                                        .toString();

                        if (!rowData.isValid()) {
                            cdnLevelErrorMap.put(key, key);
                        }

                    } catch (Exception ex) {
                        log.error("Error generated:", ex);
                        rowData.setValid(false);
                        rowData.setErrorCodeList(rowData.getErrorCodeList()
                                        .append(ValidationConstant.EINVOICE_ERROR_CODE_DE1000));
                    }
                    validatedList.add(rowData);

                });
            }

        }

        return validatedList;
    }

    /**
     * Start processing inv invoice details data.
     *
     * @param invList
     *            the inv list
     * @param uploadRequestDTO
     *            the upload request DTO
     */
    private void startProcessingInvInvoiceDetailsData(List<InwardInvoiceCDNTemplateDTO> invList,
                    UploadReqDTO uploadRequestDTO) {
        List<InwardInvoiceCDNTemplateDTO> validatedList = null;
        String methodName = "startProcessingInvoiceData";
        boolean isJavaRulesEnables = Boolean.TRUE;
        stateCodeMap = commonCommunicationDao.getStateCodeList();
        portCodeMap = commonCommunicationDao.getPortCodeList();
        govtRateMap = commonCommunicationDao.getGovtRateList();
        tdsSections = commonCommunicationDao.getTdsSectionList();
        validatedList = validateInvoicesDetails(invList, uploadRequestDTO, isJavaRulesEnables);
        if (validatedList != null && !validatedList.isEmpty()) {
            validatedList.forEach(invRowData -> {
                try {
                    transformObjetsNCheckItemLevelError(rowINVSuccessPoJoList, rowInvErrorPoJoList, invRowData,
                                    uploadRequestDTO);

                    rowINVSuccessPoJoList.forEach(rowData -> {

                        try {

                            if ("urp".equalsIgnoreCase(rowData.getGstinOfSupplier())) {
                                rowData.setGstinOfSupplier("0");
                            }

                            rowData.setDocType(AppUtil
                                            .einvdocTypeToGstr2Doctype(rowData.getOrgInvoiceCategory().toUpperCase()));
                            if (StringUtils.isBlank(rowData.getImportType())) {
                                rowData.setImportType("Inputs");
                                if (rowData.getHsnSacCode().length() > 2
                                                && rowData.getHsnSacCode().substring(0, 2).equalsIgnoreCase("99")) {
                                    rowData.setImportType("Input Services");
                                }

                                
                            } else {
                                if ("IN".equalsIgnoreCase(rowData.getImportType())) {
                                    rowData.setImportType("Inputs");
                                } else if ("INS".equalsIgnoreCase(rowData.getImportType())) {
                                    rowData.setImportType("Input Services");
                                } else if ("CG".equalsIgnoreCase(rowData.getImportType())) {
                                    rowData.setImportType("Capital Goods");
                                }
                            }

                            if (yearIdMap.containsKey(rowData.getFillingPeriod())) {
                                rowData.setYearId(yearIdMap.get(rowData.getFillingPeriod()));
                            } else {
                                rowData.setYearId("");
                                markErrorNAddErrorCode(rowData, Constants.EINVOICE_ERROR_CODE_E00514, "");
                            }
                            if (StringUtils.isBlank(rowData.getItcEligible())) {
                                rowData.setItcEligible("Eligible");
                            } else if ("Inputs".equalsIgnoreCase(rowData.getImportType())
                                            || "IN".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setItcEligible("Eligible");
                            } else if ("Input Services".equalsIgnoreCase(rowData.getImportType())
                                            || "INS".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setItcEligible("Eligible");
                            } else if ("Capital Goods".equalsIgnoreCase(rowData.getImportType())
                                            || "CG".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setItcEligible("Eligible");
                            }

                            if ("REV-42&43".equalsIgnoreCase(rowData.getItcIneligibleReversalIndicator()) || "REV-OTH"
                                            .equalsIgnoreCase(rowData.getItcIneligibleReversalIndicator())) {
                                rowData.setItcEligible("reversal");
                            }

                            if ("INELG-17(5)".equalsIgnoreCase(rowData.getItcIneligibleReversalIndicator())
                                            || "INELG-OTH".equalsIgnoreCase(
                                                            rowData.getItcIneligibleReversalIndicator())) {
                                rowData.setItcEligible("ineligible");
                            }

                            InwardITCInvoiceBDRL inwardITCInvoiceBDRL = new InwardITCInvoiceBDRL();
                            inwardITCInvoiceBDRL.applyBDRL(rowData);

                        } catch (Exception ex) {

                            log.error("Error generated:", ex);
                            log.error("error in ", methodName, ex);
                        }
                    });

                } catch (Exception | Error ex) {
                    log.error("Error generated:", ex);
                    log.error("Error in" + "startProcessingInvoiceData");
                }
            });
        }

    }

    /**
     * Validate invoices details.
     *
     * @param invList
     *            the inv list
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param isJavaRulesEnables
     *            the is java rules enables
     * @return the list
     */
    private List<InwardInvoiceCDNTemplateDTO> validateInvoicesDetails(List<InwardInvoiceCDNTemplateDTO> invList,
                    UploadReqDTO uploadRequestDTO, boolean isJavaRulesEnables) {
        int totalSize = invList.size();
        boolean isInvDiluted = checkIfDiluted(uploadRequestDTO);
        CopyOnWriteArrayList<InwardInvoiceCDNTemplateDTO> validatedList = new CopyOnWriteArrayList<InwardInvoiceCDNTemplateDTO>();
        Map<String, Map<String, String>> suppGSTNWiseMap = new ConcurrentHashMap<String, Map<String, String>>();
        Map<String, Map<String, String>> invoiceExistInFpMap = new ConcurrentHashMap<String, Map<String, String>>();
        Map<String, Map<String, String>> invoiceExistInPreFpMap = new ConcurrentHashMap<String, Map<String, String>>();
        Map<String, Map<String, String>> ictCclaimedListMap = new ConcurrentHashMap<String, Map<String, String>>();
        Map<String, Map<String, String>> ictCclaimedCDNListMap = new ConcurrentHashMap<String, Map<String, String>>();

        List<List<InwardInvoiceCDNTemplateDTO>> partList = Lists.partition(invList, Constants.THREADCOUNT);
        fp = new StringBuilder().append(uploadRequestDTO).append(uploadRequestDTO.getYear()).toString();
        int totalProcessedRec = 0;
        // Get year ID
        // yearId = commonCommunicationDao.getFPYear(fp);
        List<String> uomList = commonCommunicationDao.getUomQuery();
        for (List<InwardInvoiceCDNTemplateDTO> sublist : partList) {

            totalProcessedRec = totalProcessedRec + sublist.size();

            List<InwardInvoiceCDNTemplateDTO> rulesValidatedsublist = runInvoiceDetailsParallalProcessingValidations(
                            sublist, uploadRequestDTO, isJavaRulesEnables);
            if (rulesValidatedsublist != null && !rulesValidatedsublist.isEmpty()) {
                rulesValidatedsublist.forEach(rowData -> {
                    // new method

                    try {

                        // Invoice + Supplier GSTN + Recipients wise values
                        // should be same
                    	
                            markLineLevelError(rowData, uploadRequestDTO);
                    	


                            markDocNoLevelError(rowData);
                        

                        rowData.setDocType(AppUtil
                                        .einvdocTypeToGstr2Doctype(rowData.getOrgInvoiceCategory().toUpperCase()));

                        if ("urp".equalsIgnoreCase(rowData.getGstinOfSupplier())) {
                            rowData.setGstinOfSupplier("0");
                        }
                        if (StringUtils.isBlank(rowData.getImportType()) || "0".equals(rowData.getImportType())) {
                            rowData.setImportType("Inputs");
                            if (StringUtils.isNotBlank(rowData.getHsnSacCode()) && rowData.getHsnSacCode().length() > 2
                                            && "99".equalsIgnoreCase(rowData.getHsnSacCode().substring(0, 2))) {
                                rowData.setImportType("Input Services");
                            }
                        } else {
                            if ("IN".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Inputs");
                            } else if ("INS".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Input Services");
                            } else if ("CG".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Capital Goods");
                            }
                        }

                        if (StringUtils.isBlank(rowData.getItcEligible())
                                        || "Inputs".equalsIgnoreCase(rowData.getImportType())
                                        || "IN".equalsIgnoreCase(rowData.getImportType())
                                        || "Input Services".equalsIgnoreCase(rowData.getImportType())
                                        || "INS".equalsIgnoreCase(rowData.getImportType())
                                        || "Capital Goods".equalsIgnoreCase(rowData.getImportType())
                                        || "CG".equalsIgnoreCase(rowData.getImportType())) {
                            rowData.setItcEligible("Eligible");
                        }

                        if (StringUtils.isNotBlank(rowData.getUom())) {

                            if (!uomList.isEmpty() && !uomList.contains(rowData.getUom().toUpperCase())) {
                                markErrorNAddErrorCode(rowData, "|E00020", "");
                            }
                        }

                        
                            String supplierGstnInwardNo = rowData.getGstinOfSupplier() + rowData.getInwardNo();
                            if (StringUtils.isNotBlank(supplierGstnInwardNo)) {
                                supplierGstnInwardNo = supplierGstnInwardNo.toLowerCase();
                            }

                            int isduplicateInvoiceInDiffMonth = 0;
                            if (totalSize < 5000) {
                                isduplicateInvoiceInDiffMonth = commonCommunicationDao.getInwardResultFPCount(
                                                rowData.getGstinOfRecipient(), rowData.getInwardNo(),
                                                rowData.getInwardDate(), rowData.getGstinOfSupplier(), rowData.getFillingPeriod(), uploadRequestDTO.getYear());

                            } else {
                                // Check invoice already saved in the GSTN
                                String keyCheckInBatchData = rowData.getGstinOfRecipient()
                                                + uploadRequestDTO.getBatchNo();
                                List<String> invoiceList = null;
                                if (suppGSTNWiseMap.get(keyCheckInBatchData) == null) {
                                    invoiceList = commonCommunicationDao.getDuplicateFPInDiffMonth(
                                                    rowData.getGstinOfSupplier(), rowData.getGstinOfRecipient(), yearId,
                                                    fp);
                                    Map<String, String> map = invoiceList.stream()
                                                    .collect(Collectors.toMap(str -> str, str -> str));
                                    suppGSTNWiseMap.put(keyCheckInBatchData, map);
                                    if (suppGSTNWiseMap.get(keyCheckInBatchData).get(supplierGstnInwardNo) != null) {
                                        isduplicateInvoiceInDiffMonth++;
                                    }

                                } else {
                                    Map<String, String> map = suppGSTNWiseMap.get(keyCheckInBatchData);
                                    if (map != null && map.get(supplierGstnInwardNo) != null) {
                                        isduplicateInvoiceInDiffMonth++;
                                    }
                                }
                            }

                            String mapKey = rowData.getInwardNo() + rowData.getGstinOfSupplier();

                            if (StringUtils.isNotBlank(mapKey)) {
                                mapKey = mapKey.toLowerCase();
                            }

                            String itcClaimedKey = rowData.getGstinOfRecipient() + uploadRequestDTO.getBatchNo();
                            if (isduplicateInvoiceInDiffMonth > 0) {
                                markErrorNAddErrorCode(rowData, Constants.COMMUNICATION_ERROR_CODE_O0093, "");
                            }


                            
                        

                    } catch (Exception | Error ex) {
                        log.error("Error generated:", ex);
                        log.error("Error in " + "validateInvoices" + ex);
                        markErrorNAddErrorCode(rowData, ValidationConstant.EINVOICE_ERROR_CODE_DE1000, ex.getMessage());
                    }

                    String itemLevelErrorkey = rowData.getGstinOfRecipient() + rowData.getGstinOfSupplier()
                                    + rowData.getInwardNo();

                    if (!rowData.isValid() && itemLevelErrorMap.get(itemLevelErrorkey) == null) {
                        itemLevelErrorMap.put(itemLevelErrorkey, itemLevelErrorkey);
                    }

                    validatedList.add(rowData);
                    rowData = null;

                });
            }
        }

        uomList.clear();
        suppGSTNWiseMap.clear();
        invoiceExistInFpMap.clear();
        invoiceExistInPreFpMap.clear();
        ictCclaimedListMap.clear();

        ictCclaimedCDNListMap.clear();
        return validatedList;
    }

    /**
     * Run invoice details parallal processing validations.
     *
     * @param sublist
     *            the sublist
     * @param uploadRequestDTO
     *            the upload request DTO
     * @param isJavaRulesEnables
     *            the is java rules enables
     * @return the list
     */
    private List<InwardInvoiceCDNTemplateDTO> runInvoiceDetailsParallalProcessingValidations(
                    List<InwardInvoiceCDNTemplateDTO> sublist,UploadReqDTO uploadRequestDTO,
                    boolean isJavaRulesEnables) {
        List<List<InwardInvoiceCDNTemplateDTO>> partList = Lists.partition(sublist, Constants.THREADCOUNT);

        List<InwardInvoiceCDNTemplateDTO> validatedList = new ArrayList<>(sublist.size());
        for (List<InwardInvoiceCDNTemplateDTO> devidedList : partList) {
            if (isJavaRulesEnables) {
                devidedList.forEach(rowData -> {

                    rowData.setValid(true);

                    if (!StringUtils.isBlank(rowData.getImportType())
                                    && !inputTypeList.contains(rowData.getImportType())) {
                        markErrorNAddErrorCode(rowData, "|I50032", "");
                    }

                    try {

                        if (StringUtils.isBlank(rowData.getImportType()) || "0".equals(rowData.getImportType())) {
                            rowData.setImportType("Inputs");
                            if (StringUtils.isNotBlank(rowData.getHsnSacCode()) && rowData.getHsnSacCode().length() > 2
                                            && "99".equalsIgnoreCase(rowData.getHsnSacCode().substring(0, 2))) {
                                rowData.setImportType("Input Services");
                            }
                        }

                        else {
                            if ("IN".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Inputs");
                            } else if ("INS".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Input Services");
                            } else if ("CG".equalsIgnoreCase(rowData.getImportType())) {
                                rowData.setImportType("Capital Goods");
                            }
                        }

                        if (StringUtils.isBlank(rowData.getItcEligible())
                                        || "Inputs".equalsIgnoreCase(rowData.getImportType())
                                        || "IN".equalsIgnoreCase(rowData.getImportType())
                                        || "Input Services".equalsIgnoreCase(rowData.getImportType())
                                        || "INS".equalsIgnoreCase(rowData.getImportType())
                                        || "Capital Goods".equalsIgnoreCase(rowData.getImportType())
                                        || "CG".equalsIgnoreCase(rowData.getImportType())) {
                            rowData.setItcEligible("Eligible");
                        }

                        if (!(rowData.getDocType().equalsIgnoreCase("inv")
                                        || rowData.getDocType().equalsIgnoreCase("crn")
                                        || rowData.getDocType().equalsIgnoreCase("dbn"))) {
                            rowData.setErrorCodeList(rowData.getErrorCodeList().append("|E00013"));
                            
                            rowData.setValid(false);
                        }

                        rowData.setDocType(einvdocTypeToGstr2Doctype(rowData.getOrgInvoiceCategory().toUpperCase()));

                        InwardINVDataTypeValidations invDataTypeCheck = new InwardINVDataTypeValidations();
                        invDataTypeCheck.validateDataType(rowData);
                        invDataTypeCheck = null;


                        
                            InwardINVValidationRules invTemplValidations = new InwardINVValidationRules();
                            String dilutedValidation = uploadRequestDTO.getInwardValidationRule();
                           
                            invTemplValidations.validateRules(rowData, dilutedValidation, stateCodeMap, portCodeMap,
                                            govtRateMap,tdsSections);
                        

                        invDataTypeCheck = null;
                    } catch (Exception ex) {
                        log.error("Error in runParallalProcessingValidations" , ex);
                      
                        markErrorNAddErrorCode(rowData, ValidationConstant.EINVOICE_ERROR_CODE_DE1000, "");
                    }
                    validatedList.add(rowData);
                });
            }
        }

        return validatedList;
    }

    /**
     * Checks if is fp match with fp list.
     *
     * @param rowdata
     *            the rowdata
     * @param fpList
     *            the fp list
     */
    private void isFpMatchWithFpList(InwardInvoiceCDNTemplateDTO rowdata, String[] fpList) {

        boolean fp = StringUtils.isNotBlank(rowdata.getFillingPeriod()) && rowdata.getFillingPeriod().length() == 6
                        && rowdata.getFillingPeriod().matches("\\d+");
        if (fp && Arrays.stream(fpList).noneMatch(rowdata.getFillingPeriod()::equalsIgnoreCase)) {
            markErrorNAddErrorCode(rowdata, ValidationConstant.ERROR_CODE_E00353, "");
        }

    }

}
    
