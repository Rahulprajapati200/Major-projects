package com.bdo.bvms.common.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class BaseReqDTO extends PageReqDTO {
	 int userId;

	    String bearerToken;

	    int entityId;

	    int userTypeId;

	    String entityTypId;

	    String ipAddress;

}
