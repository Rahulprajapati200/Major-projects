package com.bdo.bvms.common.service.impl;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.exceptions.VendorMasterBusinessException;
import com.bdo.bvms.common.service.ICommonExcelService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CommonExcelServiceImpl implements ICommonExcelService {

    @Override
    public List<String> getExcelTemplateHeaderList(File file, int headerRowNo) {
        List<String> headersList = new ArrayList<>();
        final String methodName = "";
        log.info(Constants.LOGMESSAGE, methodName);
        try {
            XSSFWorkbook wb = null;
            try (FileInputStream fis = new FileInputStream(file)) {
                wb = new XSSFWorkbook(fis);
            } // obtaining bytes from the file

            XSSFSheet sheet = wb.getSheetAt(0); // creating a Sheet object to
                                                // retrieve object
            List<Row> list = new ArrayList<>();
            Iterator<Row> rowIterator = sheet.rowIterator();
            rowIterator.forEachRemaining(list::add);
            Row row = list.get(headerRowNo);
            Iterator<Cell> cellIterator = row.cellIterator();
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                String key = getCellValue(cell);
                headersList.add(key);
            }
        } catch (Exception e) {
            log.error(Constants.LOGERRORMESSAGE, methodName);
            throw new VendorMasterBusinessException("Error while reading headers from the file " + file.getName(), e);
        }
        return headersList;
    }

    public static String getCellValue(Cell cell) {
        switch (cell.getCellType()) {
        case STRING: // field that represents string cell type
            return cell.getStringCellValue();
        case NUMERIC: // field that represents number cell type
            return cell.getNumericCellValue() + "";
        default:
            return "";
        }
    }

    @Override
    public Map<String, List<String>> readCustomTemplateSampleData(File file) {
        Workbook workbook = null;
        String methodName = "";
        Map<String, List<String>> previewMap = new LinkedHashMap<>();
        try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file))) {
            if (FilenameUtils.getExtension(file.getName()).endsWith(Constants.VENODR_DETAIL_TEMPLATE_FILE_TYPE_XLSX)) {
                workbook = new XSSFWorkbook(bis);
            } else {
                workbook = new HSSFWorkbook(bis);
            }
            Sheet sheet = workbook.getSheetAt(Constants.VENDOR_MASTER_TEMPLATE_SHEET_NO);
            Iterator<Row> itr = sheet.iterator();

            DataFormatter dataFormatter = new DataFormatter();
            int lastIndex = 0;
            // populate map with headers and empty list
            if (itr.hasNext()) {
                Row row = itr.next();
                lastIndex = row.getLastCellNum();
                Iterator<Cell> cellIterator = row.cellIterator();
                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();
                    previewMap.put(getCellValue(cell), new ArrayList<>());
                }
            }

            Iterator<List<String>> columnsIterator;
            // populate lists
            for (int i = 0; i < Math.min(sheet.getPhysicalNumberOfRows() - 1, 5); i++) {

                // get the list iterator every row to start from first list
                columnsIterator = previewMap.values().iterator();
                if (!itr.hasNext()) {
                    continue;
                }
                Row row = itr.next();
                for (int j = 0; j < lastIndex; j++) {
                    columnsIterator.next()
                                    .add(row.getCell(j) == null ? "" : dataFormatter.formatCellValue((row.getCell(j))));
                }
            }
        } catch (Exception e) {
            log.error(Constants.LOGERRORMESSAGE, methodName);
            throw new VendorMasterBusinessException("Error while reading vendor master details template data", e);
        } finally {
            workbook = null;
        }
        return previewMap;
    }

}
