package com.bdo.bvms.common.tds.serviceimpl;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.constant.StringConstant;
import com.bdo.bvms.common.constant.ValidationConstant;
import com.bdo.bvms.common.dao.CustomTemplateRepo;
import com.bdo.bvms.common.dao.InwardRegisterDao;
import com.bdo.bvms.common.dao.UploadTransDao;
import com.bdo.bvms.common.dto.ExceptionLogDTO;
import com.bdo.bvms.common.dto.InwardInvoiceCDNTemplateDTO;
import com.bdo.bvms.common.dto.PaymentDetails;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;
import com.bdo.bvms.common.exceptions.InvalidTemplateHeaderException;
import com.bdo.bvms.common.exceptions.InvoiceTemplateUploadException;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;
import com.bdo.bvms.common.tds.service.ReadCustomTdsDetailTemplate;
import com.bdo.bvms.common.util.AppUtil;
import com.bdo.bvms.common.util.CommonUtils;
import com.monitorjbl.xlsx.StreamingReader;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class ReadCustomTdsDetailTemplateImpl implements ReadCustomTdsDetailTemplate{

	

	@Value("${bvms.cloud.temp.file.download.path}")
	String tempFolder;

	Set<String>sftpSet =new HashSet<>();
	
	@Autowired
	CustomTemplateRepo customeTemplateRepo;
	
	@Autowired
	UploadTransDao uploadTransDao;
	
	@Autowired
	InwardRegisterDao commonCommunicationDao;
	
	Row headerRow = null;
	
	Map<String, Integer> colNameIndexMap = new HashMap<>();
	
	
	@Override
	public void readCustomTemplate(UploadReqDTO uploadRequestDTO, List<TdsDetails> paymentDetailsTemplateDTOList)
			throws InvoiceTemplateUploadException {
		
		StringBuilder fileName = new StringBuilder().append(tempFolder)
				.append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadRequestDTO.getBatchNo())
				.append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
				.append(uploadRequestDTO.getFileType());

		Map<String, Object> rowCountWithHeader = new HashMap<>();
		Map<String, String> customTemplateHeaderMappings = CommonUtils.getCustomTemplateHeaderMappings(uploadRequestDTO,
				customeTemplateRepo);
		try {
			try (InputStream inputStream = new FileInputStream(new File(fileName.toString()));
					BufferedInputStream br = new BufferedInputStream(inputStream)) {
				// getting HeaderRowIndexs , coumnsDataRow ,RowCount
				rowCountWithHeader = getRowCustomCountWithHeader(inputStream, uploadRequestDTO);
			}
		} catch (Exception e2) {
			uploadTransDao.updateProcessStatus(uploadRequestDTO.getBatchNo(),
					Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
			ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();

			String methodName1 = "getExcelEWayDataList";

			exceptionLogDTO.setUserId(uploadRequestDTO.getId());
			exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
			exceptionLogDTO.setFunctionName(methodName1);
			exceptionLogDTO.setErrorMessage(e2.getMessage());
			exceptionLogDTO.setErrorCause(Constants.NOTCONTAINPROPERDATA);
			exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
			exceptionLogDTO.setCreatedAt(LocalDateTime.now());

			commonCommunicationDao.updateExceptionLogTable(exceptionLogDTO);

			throw new InvoiceTemplateUploadException(e2.getMessage());
		}

		headerRow = (Row) rowCountWithHeader.get(Constants.DATA_ROW);

		try {
			colNameIndexMap = AppUtil.getColumnNameIndexMap(headerRow);

		} catch (Exception ex) {

			log.error("Exception ", ex);

			uploadTransDao.updateProcessStatus(uploadRequestDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);

			

			throw new InvoiceTemplateUploadException(ex.getMessage(), ex.getCause());
		}

		// throw exception and Update in Exception Log table as per Batch Number
		if (Constants.TDS_TEMPLATE_HEADER_COUNT != colNameIndexMap.size()) {
			uploadTransDao.updateProcessStatus(uploadRequestDTO.getBatchNo(),
					Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);

			throw new InvalidTemplateHeaderException(StringConstant.HEADERCOUNTERRORMESSAGE + uploadRequestDTO.getBatchNo());

		}

		try (InputStream in = new FileInputStream(new File(fileName.toString()));
				BufferedInputStream bis = new BufferedInputStream(in);
				Workbook workbook = StreamingReader.builder().open(bis);) {

			Sheet sheet = workbook.getSheetAt(0);

			sheet.forEach(row -> {
				TdsDetails rowObj = new TdsDetails();
				if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 0) {
					rowObj.setExcelRowId(row.getRowNum());
					try {
						// reading Excel Template
						rowObj.setValid(true);
						rowObj = readTemplateRecord(row, colNameIndexMap, uploadRequestDTO, customTemplateHeaderMappings);
						 if (rowObj.getPeriodFilingTdsReturn().length() == 5) {
							 rowObj.setPeriodFilingTdsReturn(Constants.ZEROVALUE + rowObj.getPeriodFilingTdsReturn());
			                }

					} catch (Exception e) {
						log.error("Error generated while reading xls ", e);
						markErrorNAddErrorCode(rowObj, ValidationConstant.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
					}
					
					setTaxpayerPan(rowObj);
	                
	                
	                fixFilingPeriodSizeTo6(rowObj);
					paymentDetailsTemplateDTOList.add(rowObj);
				}
			});

			
		} catch (Exception exception) {
			throw new InvoiceTemplateUploadException(exception.getMessage(), exception);
		}

		
	}


	private void fixFilingPeriodSizeTo6(TdsDetails xlsRow) {

		if (xlsRow.getPeriodFilingTdsReturn().length() == 5) {
			xlsRow.setPeriodFilingTdsReturn(Constants.ZEROVALUE + xlsRow.getPeriodFilingTdsReturn());
		}
	
		if (xlsRow.getFilingPeriod().length() == 5) {
			xlsRow.setFilingPeriod(Constants.ZEROVALUE + xlsRow.getFilingPeriod());
		}
	}


	private void setTaxpayerPan(TdsDetails xlsRow) {
		if (StringUtils.isNotBlank(xlsRow.getGstinUinOfRecipient()) && xlsRow.getGstinUinOfRecipient().length() == 15) {
			xlsRow.setPanOfRecipient(xlsRow.getGstinUinOfRecipient().substring(2, 12));

		} else {
			xlsRow.setPanOfRecipient("");

		}
	}


	private void markErrorNAddErrorCode(TdsDetails rowData, String errorCode, String errorMessage) {
        log.info("Entering markErrorNAddErrorCode Method ");
        rowData.setValid(false);
        rowData.setErrorCodeList(rowData.getErrorCodeList().append(errorCode));
        rowData.setErrorDescriptionList(rowData.getErrorDescriptionList().append(errorMessage));
    }


	private Map<String, Object> getRowCustomCountWithHeader(InputStream fis, UploadReqDTO uploadDTO) throws VendorInvoiceServerException {
		Map<String, Object> dataMap = new HashMap<>();
		int totalRowCount = 0;
		try (InputStream is = new BufferedInputStream(fis); Workbook workbook = StreamingReader.builder().open(is);) {

			Sheet sheet = workbook.getSheetAt(0);
			for (Row row : sheet) {
				if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 0) {
					totalRowCount++;
				} else if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() <= 0 && totalRowCount == 0) {

					Row coumnsDataRow = null;
					coumnsDataRow = row;
					dataMap.put("headerRowIndex", row.getRowNum());
					dataMap.put("coumnsDataRow", coumnsDataRow);

				}

			}
			dataMap.put("RowCount", totalRowCount);
			return dataMap;
		} catch (Exception ex) {
			throw new VendorInvoiceServerException(StringConstant.HEADERCOUNTERRORMESSAGE + uploadDTO.getBatchNo());

		}

	}


	private TdsDetails readTemplateRecord(Row row, Map<String, Integer> colNameIndexMap2, UploadReqDTO uploadDTO,
			Map<String, String> columnMap) {

		TdsDetails xlsRow = new TdsDetails();
		log.info("Reading Cell from excel Rows field wise");

		try {

			if (colNameIndexMap2.size() != columnMap.size()) {
				uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),
						Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);
			}
		
			xlsRow.setValid(true);
			xlsRow.setExcelRowId(row.getRowNum());

			String customHeaderName = columnMap.get(Constants.COLUMN_PAN_RECIPIENT);
			Integer idxForPan = colNameIndexMap.get(customHeaderName);
			xlsRow.setPanOfRecipient(AppUtil.getCellValue(row.getCell(idxForPan)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
		    customHeaderName = columnMap.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT);
			Integer idxForGstinReceipient = colNameIndexMap.get(customHeaderName);
			xlsRow.setGstinUinOfRecipient(AppUtil.getCellValue(row.getCell(idxForGstinReceipient)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_DOC_TYPE);
			Integer idxForDocType = colNameIndexMap.get(customHeaderName);
			xlsRow.setDocType(AppUtil.getCellValue(row.getCell(idxForDocType)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			
			customHeaderName = columnMap.get(Constants.COLUMN_VENDOR_CODE_ERP);
			Integer idxForVendorCodeErp = colNameIndexMap.get(customHeaderName);
			xlsRow.setVendorCodeErp(AppUtil.getCellValue(row.getCell(idxForVendorCodeErp)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			
			customHeaderName = columnMap.get(Constants.COLUMN_GSTIN_OF_SUPPLIER);
			Integer idxForGstinSupplier = colNameIndexMap.get(customHeaderName);
			xlsRow.setGstinOfSupplier(AppUtil.getCellValue(row.getCell(idxForGstinSupplier)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_PAN_OF_SUPPLIER);
			Integer idxForPanSupplier = colNameIndexMap.get(customHeaderName);
			xlsRow.setPanOfSupplier(AppUtil.getCellValue(row.getCell(idxForPanSupplier)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			
			customHeaderName = columnMap.get(Constants.COLUMN_SUPPLIER_NAME);
			Integer idxForSupplierName = colNameIndexMap.get(customHeaderName);
			xlsRow.setSupplierName(AppUtil.getCellValue(row.getCell(idxForSupplierName)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_DOC_NO);
			Integer idxForDocNo = colNameIndexMap.get(customHeaderName);
			xlsRow.setDocNo(AppUtil.getCellValue(row.getCell(idxForDocNo)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_DOC_DATE);
			Integer idxForDocDate = colNameIndexMap.get(customHeaderName);
			xlsRow.setDocDate(AppUtil.getCellValue(row.getCell(idxForDocDate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			
			customHeaderName = columnMap.get(Constants.COLUMN_INWARD_NO);
			Integer idxForInwardNo = colNameIndexMap.get(customHeaderName);
			xlsRow.setInwardNo(AppUtil.getCellValue(row.getCell(idxForInwardNo)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_INWARD_DATE);
			Integer idxForInwardDate = colNameIndexMap.get(customHeaderName);
			xlsRow.setInwardAate(AppUtil.getCellValue(row.getCell(idxForInwardDate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_ASS_AMOUNT);
			Integer idxForAssAmount = colNameIndexMap.get(customHeaderName);
			xlsRow.setOrgAssAmount(AppUtil.getCellValue(row.getCell(idxForAssAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			xlsRow.setAssAmt(AppUtil.getCellValue(row.getCell(idxForAssAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			if(!isNumeric(xlsRow.getAssAmt()))
			{
				if(StringUtils.isBlank(xlsRow.getAssAmt()))
            	{
					xlsRow.setAssAmt("0.0");
            	}
            	else
            	{
            		xlsRow.setAssAmt("0.0");
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00588, Constants.BLANK);
            	}
			}
			
			customHeaderName = columnMap.get(Constants.TDS_SECTION);
			Integer idxForTdsSection = colNameIndexMap.get(customHeaderName);
			xlsRow.setTdsSection(AppUtil.getCellValue(row.getCell(idxForTdsSection)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.TDS_RATE);
			Integer idxForTdsRate = colNameIndexMap.get(customHeaderName);
			xlsRow.setOrgTdsRate(AppUtil.getCellValue(row.getCell(idxForTdsRate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
			xlsRow.setTdsRate(AppUtil.getCellValue(row.getCell(idxForTdsRate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			if(!isNumeric(xlsRow.getTdsRate()))
			{
				if(StringUtils.isBlank(xlsRow.getTdsRate()))
	        	{
					xlsRow.setTdsRate("0.0");
	        	}
	        	else
	        	{
	        		xlsRow.setTdsRate("0.0");
	        		markErrorNAddErrorCode(xlsRow, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00563, Constants.BLANK);
	        	}
			}
			customHeaderName = columnMap.get(Constants.TDS_TAX_AMOUNT);
			Integer idxForTdsTaxAmount = colNameIndexMap.get(customHeaderName);
			xlsRow.setOrgTdsTaxAmount(AppUtil.getCellValue(row.getCell(idxForTdsTaxAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
			xlsRow.setTdsTaxAmount(AppUtil.getCellValue(row.getCell(idxForTdsTaxAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			if(!isNumeric(xlsRow.getTdsTaxAmount()))
			{
				if(StringUtils.isBlank(xlsRow.getTdsTaxAmount()))
            	{
					xlsRow.setTdsTaxAmount("0.0");
            	}
            	else
            	{
            		xlsRow.setTdsTaxAmount("0.0");
            		markErrorNAddErrorCode(xlsRow, ValidationConstant.EINVOICE_ERROR_CODE_E00528, Constants.BLANK);
            	}
			}
			
			customHeaderName = columnMap.get(Constants.GROSS_AMOUNT);
			Integer idxForGrossAmount = colNameIndexMap.get(customHeaderName);
			xlsRow.setOrgGrossAmount(AppUtil.getCellValue(row.getCell(idxForGrossAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			xlsRow.setGrossAmount(AppUtil.getCellValue(row.getCell(idxForGrossAmount)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			if(!isNumeric(xlsRow.getGrossAmount()))
			{
				if(StringUtils.isBlank(xlsRow.getGrossAmount()))
            	{
					xlsRow.setGrossAmount("0.0");
            	}
            	else
            	{
            		xlsRow.setGrossAmount("0.0");
            		markErrorNAddErrorCode(xlsRow, Constants.EINVOICE_ERROR_CODE_E00039, Constants.BLANK);	
            	}
			}
			
			customHeaderName = columnMap.get(Constants.PAYMENT_DATE);
			Integer idxForDateOfPayment = colNameIndexMap.get(customHeaderName);
			xlsRow.setDateofPayment(AppUtil.getCellValue(row.getCell(idxForDateOfPayment)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.PAYMENT_REF_NO);
			Integer indexPaymentRefNo = colNameIndexMap.get(customHeaderName);
			xlsRow.setPaymentRefNo(AppUtil.getCellValue(row.getCell(indexPaymentRefNo))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			

			customHeaderName = columnMap.get(Constants.PAYMENT_AMOUNT);
			Integer indexPaymentAmount = colNameIndexMap.get(customHeaderName);
			xlsRow.setOrgPaymentAmount(AppUtil.getCellValue(row.getCell(indexPaymentAmount))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			xlsRow.setPaymentAmount(AppUtil.getCellValue(row.getCell(indexPaymentAmount))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			if(!isNumeric(xlsRow.getPaymentAmount()))
			{
				if(StringUtils.isBlank(xlsRow.getPaymentAmount()))
            	{
					xlsRow.setPaymentAmount("0.0");
            	}
            	else
            	{
            		xlsRow.setPaymentAmount("0.0");
            		markErrorNAddErrorCode(xlsRow, ValidationConstant.EINVOICE_ERROR_CODE_I50031, Constants.BLANK);
            	}
			}
			
			customHeaderName = columnMap.get(Constants.CHALLAN_DATE);
			Integer indexForChallanDate = colNameIndexMap.get(customHeaderName);
			xlsRow.setChallanDate(AppUtil.getCellValue(row.getCell(indexForChallanDate)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.CHALLAN_NUMBER);
			Integer indexForChallanNo = colNameIndexMap.get(customHeaderName);
			xlsRow.setChallanNo(AppUtil.getCellValue(row.getCell(indexForChallanNo)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.CHALLAN_AMOUNT);
			Integer indexForChallanAmt = colNameIndexMap.get(customHeaderName);
			xlsRow.setOrgChallanAmount(AppUtil.getCellValue(row.getCell(indexForChallanAmt)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
			xlsRow.setChallanAmount(AppUtil.getCellValue(row.getCell(indexForChallanAmt)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			if(!isNumeric(xlsRow.getChallanAmount()))
			{
				if(StringUtils.isBlank(xlsRow.getChallanAmount()))
            	{
					xlsRow.setChallanAmount("0.0");
            	}
            	else
            	{
            		xlsRow.setChallanAmount("0.0");
            		markErrorNAddErrorCode(xlsRow, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00531, Constants.BLANK);
            	}
			}
			
			customHeaderName = columnMap.get(Constants.PERIOD_OF_FILLING);
			Integer indexForPeridOfFiling = colNameIndexMap.get(customHeaderName);
			xlsRow.setPeriodFilingTdsReturn(AppUtil.getCellValue(row.getCell(indexForPeridOfFiling)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.FILLING_PERIOD);
			Integer idxFilingPeriod = colNameIndexMap.get(customHeaderName);
			xlsRow.setFilingPeriod(AppUtil.getCellValue(row.getCell(idxFilingPeriod)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			
			customHeaderName = columnMap.get(Constants.INVOICE_AGAINST_PROV_ADV);
			Integer indexForInvoiceAgainstProvAdv = colNameIndexMap.get(customHeaderName);
			xlsRow.setInvoiceAgainstProvAdv(AppUtil.getCellValue(row.getCell(indexForInvoiceAgainstProvAdv)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


			customHeaderName = columnMap.get(Constants.INWARD_DATE_PROV_ADV);
			Integer indexForInwardDateProvAdv = colNameIndexMap.get(customHeaderName);
			xlsRow.setInwardDateprovAdv(AppUtil.getCellValue(row.getCell(indexForInwardDateProvAdv))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
			
			customHeaderName = columnMap.get(Constants.INWARD_NO_PROV_ADV);
			Integer indexForInwardNoProvAdv = colNameIndexMap.get(customHeaderName);
			xlsRow.setInwardNoProvAdv(AppUtil.getCellValue(row.getCell(indexForInwardNoProvAdv))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
			customHeaderName = columnMap.get(Constants.AMOUNT_OF_PROV_ADV);
			Integer indexForAmountOfProvAdv = colNameIndexMap.get(customHeaderName);
			xlsRow.setOrgAmountofProvAdv(AppUtil.getCellValue(row.getCell(indexForAmountOfProvAdv))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			xlsRow.setAmountofProvAdv(AppUtil.getCellValue(row.getCell(indexForAmountOfProvAdv))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			if(!isNumeric(xlsRow.getAmountofProvAdv()))
			{
				if(StringUtils.isBlank(xlsRow.getAmountofProvAdv()))
            	{
					xlsRow.setAmountofProvAdv("0.0");
            	}
            	else
            	{
            		xlsRow.setAmountofProvAdv("0.0");
            		markErrorNAddErrorCode(xlsRow, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00536, Constants.BLANK);
            	}
			}
			
			customHeaderName = columnMap.get(Constants.BAL_OUTSTANDING);
			Integer indexForBalOutstanding = colNameIndexMap.get(customHeaderName);
			xlsRow.setOrgBalOutstanding(AppUtil.getCellValue(row.getCell(indexForBalOutstanding))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			xlsRow.setBalOutstanding(AppUtil.getCellValue(row.getCell(indexForBalOutstanding))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			if(!isNumeric(xlsRow.getBalOutstanding()))
			{
				xlsRow.setBalOutstanding("0.0");
				if(StringUtils.isBlank(xlsRow.getBalOutstanding()))
            	{
					xlsRow.setBalOutstanding("0.0");
            	}
            	else
            	{
            		xlsRow.setBalOutstanding("0.0");
            		markErrorNAddErrorCode(xlsRow, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00595, Constants.BLANK);
            	}
			}
		
			
			customHeaderName = columnMap.get(Constants.COLUMN_DEBIT_GL_ID);
			Integer indexForDebitGlId = colNameIndexMap.get(customHeaderName);
			xlsRow.setDebitglId(AppUtil.getCellValue(row.getCell(indexForDebitGlId))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
			customHeaderName = columnMap.get(Constants.COLUMN_DEBIT_GL_NAME);
			Integer indexForDebitGlName = colNameIndexMap.get(customHeaderName);
			xlsRow.setDebitglName(AppUtil.getCellValue(row.getCell(indexForDebitGlName))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
			customHeaderName = columnMap.get(Constants.COLUMN_CREDIT_GL_ID);
			Integer indexForCreditGlId = colNameIndexMap.get(customHeaderName);
			xlsRow.setCreditglId(AppUtil.getCellValue(row.getCell(indexForCreditGlId))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
			customHeaderName = columnMap.get(Constants.COLUMN_CREDIT_GL_NAME);
			Integer indexForCreditGlName = colNameIndexMap.get(customHeaderName);
			xlsRow.setCreditglName(AppUtil.getCellValue(row.getCell(indexForCreditGlName))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));
			
			customHeaderName = columnMap.get(Constants.COLUMN_UDF_1);
			Integer idxForUdf1 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf1(AppUtil.getCellValue(row.getCell(idxForUdf1))
					.replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_2);
			Integer idxForUdf2 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf2(AppUtil.getCellValue(row.getCell(idxForUdf2)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_3);
			Integer idxForUdf3 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf3(AppUtil.getCellValue(row.getCell(idxForUdf3)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


			customHeaderName = columnMap.get(Constants.COLUMN_UDF_4);
			Integer idxForUdf4 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf4(AppUtil.getCellValue(row.getCell(idxForUdf4)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_5);
			Integer idxForUdf5 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf5(AppUtil.getCellValue(row.getCell(idxForUdf5)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_6);
			Integer idxForUdf6 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf6(AppUtil.getCellValue(row.getCell(idxForUdf6)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_7);
			Integer idxForUdf7 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf7(AppUtil.getCellValue(row.getCell(idxForUdf7)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_8);
			Integer idxForUdf8 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf8(AppUtil.getCellValue(row.getCell(idxForUdf8)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_9);
			Integer idxForUdf9 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf9(AppUtil.getCellValue(row.getCell(idxForUdf9)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_10);
			Integer idxForUdf10 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf10(AppUtil.getCellValue(row.getCell(idxForUdf10)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_11);
			Integer idxForUdf11 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf11(AppUtil.getCellValue(row.getCell(idxForUdf11)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_12);
			Integer idxForUdf12 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf12(AppUtil.getCellValue(row.getCell(idxForUdf12)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_13);
			Integer idxForUdf13 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf13(AppUtil.getCellValue(row.getCell(idxForUdf13)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_14);
			Integer idxForUdf14 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf14(AppUtil.getCellValue(row.getCell(idxForUdf14)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_15);
			Integer idxForUdf15 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf15(AppUtil.getCellValue(row.getCell(idxForUdf15)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_16);
			Integer idxForUdf16 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf16(AppUtil.getCellValue(row.getCell(idxForUdf16)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_17);
			Integer idxForUdf17 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf17(AppUtil.getCellValue(row.getCell(idxForUdf17)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_18);
			Integer idxForUdf18 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf18(AppUtil.getCellValue(row.getCell(idxForUdf18)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_19);
			Integer idxForUdf19 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf19(AppUtil.getCellValue(row.getCell(idxForUdf19)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));

			customHeaderName = columnMap.get(Constants.COLUMN_UDF_20);
			Integer idxForUdf20 = colNameIndexMap.get(customHeaderName);
			xlsRow.setUdf20(AppUtil.getCellValue(row.getCell(idxForUdf20)).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE).replace("\\", "\\\\"));


		} catch (Exception ex) {
			// Mark as not Valid object if Exception occur
			log.error("Error generated while reading xls ", ex);
			markErrorNAddErrorCode(xlsRow, ValidationConstant.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
			ExceptionLogDTO exceptionLogDto = new ExceptionLogDTO();
			exceptionLogDto.setUserId(uploadDTO.getUploadBy());
			exceptionLogDto.setScreenName(Constants.INVOICEINTEGRATION);
			exceptionLogDto.setFunctionName("readTemplateRecord");
			exceptionLogDto.setErrorMessage(ex.getMessage());
			exceptionLogDto.setErrorCause(ex.getCause().getMessage());
			exceptionLogDto.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
			exceptionLogDto.setCreatedAt(LocalDateTime.now());

			commonCommunicationDao.updateExceptionLogTable(exceptionLogDto);

			log.error("Errro occured while reading row " + row.getRowNum() + " for batch No. " + ex);
		}
		return xlsRow;
	}

	
	public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }


	@Override
	public void getInwardDataListCDV(UploadReqDTO uploadReqDTO, Map<String, String> customTemplateHeaderMappings,
			char delimiter, List<TdsDetails> tdsDetailsTemplateDTOList) throws VendorInvoiceServerException {


        Iterable<CSVRecord> records = null;
       
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadReqDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(uploadReqDTO.getFileType());

        File file = new File(fileName.toString());
        Path path = file.toPath();

        Map<String, Integer> columnIndexMap = new HashMap<>();

        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String headerLine = reader.readLine();
            String[] headers = headerLine.split(",");

            Map<String, String> customTemplateMap = new HashMap<>();
            String columnNameNotMatchedWithTemplate = "";
            for (Entry<String, String> map : customTemplateHeaderMappings.entrySet()) {

                byte[] bytes = map.getValue().trim().getBytes();
                String str = new String(bytes, StandardCharsets.UTF_8);

                customTemplateMap.put(str, str);
            }

            for (int cnt = 0; cnt <= headers.length - 1; cnt++) {
                byte[] bytes = headers[cnt].trim().getBytes();
                String str = new String(bytes, StandardCharsets.UTF_8).replaceAll("[^a-zA-Z0-9\\s+_-]", "");
                columnIndexMap.put(str, cnt);
                if (!str.trim().equals(customTemplateMap.get(str))) {
                    if ("".equals(columnNameNotMatchedWithTemplate)) {
                        columnNameNotMatchedWithTemplate = columnNameNotMatchedWithTemplate + headers[cnt];
                    } else {
                        columnNameNotMatchedWithTemplate = columnNameNotMatchedWithTemplate + "," + headers[cnt];
                    }

                }

            }

            if (columnNameNotMatchedWithTemplate.length() > 2) {
                log.error("Uploaded file(s) some columns does not matching with defined template");
                uploadTransDao.updateProcessStatus(uploadReqDTO.getBatchNo(),
                                Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);
                throw new VendorInvoiceServerException(
                                "Uploaded file(s) some columns does not matching with defined template,column(s) are "
                                                + columnNameNotMatchedWithTemplate);
            }

            records = CSVFormat.DEFAULT.withDelimiter(delimiter).withAllowMissingColumnNames(true).parse(reader);

            sftpSet = new HashSet<>();
            for (CSVRecord csvRecord : records) {

                boolean isEmptyRow = true;
                for (String value : csvRecord) {
                    if (!value.trim().isEmpty()) {
                        isEmptyRow = false;
                        break;
                    }
                }

                if (!isEmptyRow) {
                    readCsvCustomRecord(uploadReqDTO, csvRecord, customTemplateHeaderMappings,tdsDetailsTemplateDTOList,
                                    columnIndexMap);
                }

            }
            if("ftps".equals(uploadReqDTO.getUploadSource()))
            {
            	uploadReqDTO.setMonth(new ArrayList<>(sftpSet));
            }

        } catch (Exception e) {
            log.error("Error in getEinvoiceDataListCDV method ", e);
            if (e.getMessage().contains("matching with defined template,column(s)")) {
                throw new VendorInvoiceServerException(e.getMessage());
            } else {
                throw new VendorInvoiceServerException("Error while reading custom template for vendor details import ",
                                e);
            }
        } finally {
            records = null;
        }
        if ("ftps".equals(uploadReqDTO.getUploadType()) || uploadReqDTO.getFp().isEmpty()) {
        	uploadReqDTO.setMonth(new ArrayList<>(sftpSet));
        	uploadTransDao.updateFpLog(uploadReqDTO.getMonth(), uploadReqDTO);
        }
     
	
		
	}


	private void readCsvCustomRecord(UploadReqDTO uploadReqDTO, CSVRecord csvRecord,
			Map<String, String> customTemplateHeaderMappings, List<TdsDetails> tdsDetailsTemplateDTOList, Map<String, Integer> columnIndexMap) {
		

		TdsDetails vendorUploadStage1 = new TdsDetails();
		vendorUploadStage1.setValid(true);
		String taxpayerGSTCustomHeaderName = customTemplateHeaderMappings.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT);
		vendorUploadStage1.setGstinUinOfRecipient(csvRecord.get(columnIndexMap.get(taxpayerGSTCustomHeaderName)));

		

//        xlsRow.setValid(true);
//        xlsRow.setExcelRowId(row.getRowNum());
		
		
		
		String setPanOfRecipient = customTemplateHeaderMappings.get(Constants.COLUMN_PAN_RECIPIENT);
		vendorUploadStage1.setPanOfRecipient(csvRecord.get(columnIndexMap.get(setPanOfRecipient)));

        String setGstinUinOfRecipient = customTemplateHeaderMappings.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT);
		vendorUploadStage1.setGstinUinOfRecipient(csvRecord.get(columnIndexMap.get(setGstinUinOfRecipient)));
 
        String setDocType = customTemplateHeaderMappings.get(Constants.DOC_TYPE);
		vendorUploadStage1.setDocType(csvRecord.get(columnIndexMap.get(setDocType)));

        String setVendorCodeErp = customTemplateHeaderMappings.get(Constants.COLUMN_VENDOR_CODE_ERP);
		vendorUploadStage1.setVendorCodeErp(csvRecord.get(columnIndexMap.get(setVendorCodeErp)));

        String setGstinOfSupplier = customTemplateHeaderMappings.get(Constants.COLUMN_GSTIN_OF_SUPPLIER);
		vendorUploadStage1.setGstinOfSupplier(csvRecord.get(columnIndexMap.get(setGstinOfSupplier)));

        String setPanOfSupplier = customTemplateHeaderMappings.get(Constants.COLUMN_PAN_OF_SUPPLIER);
		vendorUploadStage1.setPanOfSupplier(csvRecord.get(columnIndexMap.get(setPanOfSupplier)));

        String setSupplierName = customTemplateHeaderMappings.get(Constants.COLUMN_SUPPLIER_NAME);
		vendorUploadStage1.setSupplierName(csvRecord.get(columnIndexMap.get(setSupplierName)));

      
        String setDocNo = customTemplateHeaderMappings.get(Constants.COLUMN_DOC_NO);
		vendorUploadStage1.setDocNo(csvRecord.get(columnIndexMap.get(setDocNo)));
       
		String setDocDate = customTemplateHeaderMappings.get(Constants.COLUMN_DOC_DATE);
		vendorUploadStage1.setDocDate(csvRecord.get(columnIndexMap.get(setDocDate)));

        String setInwardNo = customTemplateHeaderMappings.get(Constants.COLUMN_INWARD_NO);
		vendorUploadStage1.setInwardNo(csvRecord.get(columnIndexMap.get(setInwardNo)));

        String setInwardAate = customTemplateHeaderMappings.get(Constants.COLUMN_INWARD_DATE);
		vendorUploadStage1.setInwardAate(csvRecord.get(columnIndexMap.get(setInwardAate)));

        String setOrgAssAmount = customTemplateHeaderMappings.get(Constants.COLUMN_ASS_AMOUNT);
		vendorUploadStage1.setOrgAssAmount(csvRecord.get(columnIndexMap.get(setOrgAssAmount)));

		 String setAssAmt = customTemplateHeaderMappings.get(Constants.COLUMN_ASS_AMOUNT);
		vendorUploadStage1.setAssAmt(csvRecord.get(columnIndexMap.get(setAssAmt)));

		if(!isNumeric(vendorUploadStage1.getAssAmt()))
		{
			if(StringUtils.isBlank(vendorUploadStage1.getAssAmt()))
        	{
        	    vendorUploadStage1.setAssAmt("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setAssAmt("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00588, Constants.BLANK);
        	}
		}
        String setTdsSection = customTemplateHeaderMappings.get(Constants.TDS_SECTION);
		vendorUploadStage1.setTdsSection(csvRecord.get(columnIndexMap.get(setTdsSection)));

         String setOrgTdsRate = customTemplateHeaderMappings.get(Constants.TDS_RATE);
		vendorUploadStage1.setOrgTdsRate(csvRecord.get(columnIndexMap.get(setOrgTdsRate)));

        String setTdsRate = customTemplateHeaderMappings.get(Constants.TDS_RATE);
		vendorUploadStage1.setTdsRate(csvRecord.get(columnIndexMap.get(setTdsRate)));

		if(!isNumeric(vendorUploadStage1.getTdsRate()))
		{
			if(StringUtils.isBlank(vendorUploadStage1.getTdsRate()))
        	{
        	    vendorUploadStage1.setTdsRate("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setTdsRate("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00563, Constants.BLANK);
        	}
		}
        String setOrgTdsTaxAmount = customTemplateHeaderMappings.get(Constants.TDS_TAX_AMOUNT);
		vendorUploadStage1.setOrgTdsTaxAmount(csvRecord.get(columnIndexMap.get(setOrgTdsTaxAmount)));

		
        String setTdsTaxAmount = customTemplateHeaderMappings.get(Constants.TDS_TAX_AMOUNT);
		vendorUploadStage1.setTdsTaxAmount(csvRecord.get(columnIndexMap.get(setTdsTaxAmount)));

		if(!isNumeric(vendorUploadStage1.getTdsTaxAmount()))
		{
			if(StringUtils.isBlank(vendorUploadStage1.getTdsTaxAmount()))
        	{
        	    vendorUploadStage1.setTdsTaxAmount("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setTdsTaxAmount("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, ValidationConstant.EINVOICE_ERROR_CODE_E00528, Constants.BLANK);
        	}
		}
        String setOrgGrossAmount = customTemplateHeaderMappings.get(Constants.GROSS_AMOUNT);
		vendorUploadStage1.setOrgGrossAmount(csvRecord.get(columnIndexMap.get(setOrgGrossAmount)));

        String setGrossAmount = customTemplateHeaderMappings.get(Constants.GROSS_AMOUNT);
		vendorUploadStage1.setGrossAmount(csvRecord.get(columnIndexMap.get(setGrossAmount)));

		if(!isNumeric(vendorUploadStage1.getGrossAmount()))
		{
			if(StringUtils.isBlank(vendorUploadStage1.getGrossAmount()))
        	{
				vendorUploadStage1.setGrossAmount("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setGrossAmount("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, Constants.EINVOICE_ERROR_CODE_E00039, Constants.BLANK);	
        	}
			
		}
		
        String setDateofPayment = customTemplateHeaderMappings.get(Constants.DATE_OF_PAYMENT);
		vendorUploadStage1.setDateofPayment(csvRecord.get(columnIndexMap.get(setDateofPayment)));

       String setInvoiceAgainstProvAdv = customTemplateHeaderMappings.get(Constants.INVOICE_AGAINST_PROV_ADV);
		vendorUploadStage1.setInvoiceAgainstProvAdv(csvRecord.get(columnIndexMap.get(setInvoiceAgainstProvAdv)));

       String setInwardNoProvAdv = customTemplateHeaderMappings.get(Constants.INWARD_NO_PROV_ADV);
		vendorUploadStage1.setInwardNoProvAdv(csvRecord.get(columnIndexMap.get(setInwardNoProvAdv)));

                
        String setOrgPaymentAmount = customTemplateHeaderMappings.get(Constants.PAYMENT_AMOUNT);
		vendorUploadStage1.setOrgPaymentAmount(csvRecord.get(columnIndexMap.get(setOrgPaymentAmount)));

        
        String setPaymentAmount = customTemplateHeaderMappings.get(Constants.PAYMENT_AMOUNT);
		vendorUploadStage1.setPaymentAmount(csvRecord.get(columnIndexMap.get(setPaymentAmount)));

		if(!isNumeric(vendorUploadStage1.getPaymentAmount()))
		{
			if(StringUtils.isBlank(vendorUploadStage1.getPaymentAmount()))
        	{
        	    vendorUploadStage1.setPaymentAmount("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setPaymentAmount("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, ValidationConstant.EINVOICE_ERROR_CODE_I50031, Constants.BLANK);
        	}
		}
                
        String setPaymentRefNo = customTemplateHeaderMappings.get(Constants.PAYMENT_REF_NO);
		vendorUploadStage1.setPaymentRefNo(csvRecord.get(columnIndexMap.get(setPaymentRefNo)));

        String setChallanAmount = customTemplateHeaderMappings.get(Constants.CHALLAN_AMOUNT);
		vendorUploadStage1.setChallanAmount(csvRecord.get(columnIndexMap.get(setChallanAmount)));

      String setOrgChallanAmount = customTemplateHeaderMappings.get(Constants.CHALLAN_AMOUNT);
		vendorUploadStage1.setOrgChallanAmount(csvRecord.get(columnIndexMap.get(setOrgChallanAmount)));

       
        if(!isNumeric(vendorUploadStage1.getPaymentAmount()))
		{
        	if(StringUtils.isBlank(vendorUploadStage1.getPaymentAmount()))
        	{
        	    vendorUploadStage1.setPaymentAmount("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setPaymentAmount("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, ValidationConstant.EINVOICE_ERROR_CODE_I50031, Constants.BLANK);
        	}
		}
        String setChallanNo = customTemplateHeaderMappings.get(Constants.CHALLAN_NUMBER);
		vendorUploadStage1.setChallanNo(csvRecord.get(columnIndexMap.get(setChallanNo)));

      
        String setChallanDate = customTemplateHeaderMappings.get(Constants.CHALLAN_DATE);
		vendorUploadStage1.setChallanDate(csvRecord.get(columnIndexMap.get(setChallanDate)));

        String setPeriodFilingTdsReturn = customTemplateHeaderMappings.get(Constants.PERIOD_OF_FILLING);
		vendorUploadStage1.setPeriodFilingTdsReturn(csvRecord.get(columnIndexMap.get(setPeriodFilingTdsReturn)));

      
        String setInwardDateprovAdv = customTemplateHeaderMappings.get(Constants.INWARD_DATE_PROV_ADV);
		vendorUploadStage1.setInwardDateprovAdv(csvRecord.get(columnIndexMap.get(setInwardDateprovAdv)));

          String setOrgAmountofProvAdv = customTemplateHeaderMappings.get(Constants.AMOUNT_OF_PROV_ADV);
		vendorUploadStage1.setOrgAmountofProvAdv(csvRecord.get(columnIndexMap.get(setOrgAmountofProvAdv)));

         String setAmountofProvAdv = customTemplateHeaderMappings.get(Constants.AMOUNT_OF_PROV_ADV);
		vendorUploadStage1.setAmountofProvAdv(csvRecord.get(columnIndexMap.get(setAmountofProvAdv)));

		if(!isNumeric(vendorUploadStage1.getAmountofProvAdv()))
		{
			if(StringUtils.isBlank(vendorUploadStage1.getAmountofProvAdv()))
        	{
        	    vendorUploadStage1.setAmountofProvAdv("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setAmountofProvAdv("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00536, Constants.BLANK);
        	}
		}
		
        String setOrgBalOutstanding = customTemplateHeaderMappings.get(Constants.BAL_OUTSTANDING);
		vendorUploadStage1.setOrgBalOutstanding(csvRecord.get(columnIndexMap.get(setOrgBalOutstanding)));

         String setBalOutstanding = customTemplateHeaderMappings.get(Constants.BAL_OUTSTANDING);
		vendorUploadStage1.setBalOutstanding(csvRecord.get(columnIndexMap.get(setBalOutstanding)));

		if(!isNumeric(vendorUploadStage1.getBalOutstanding()))
		{
			if(StringUtils.isBlank(vendorUploadStage1.getBalOutstanding()))
        	{
        	    vendorUploadStage1.setBalOutstanding("0.0");
        	}
        	else
        	{
        		vendorUploadStage1.setBalOutstanding("0.0");
        		markErrorNAddErrorCode(vendorUploadStage1, ValidationConstant.VENDOR_COMMON_VALIDATION_CODE_E00595, Constants.BLANK);
        	}
		}
        String setCreditglId = customTemplateHeaderMappings.get(Constants.COLUMN_CREDIT_GL_ID);
		vendorUploadStage1.setCreditglId(csvRecord.get(columnIndexMap.get(setCreditglId)));

        String setCreditglName = customTemplateHeaderMappings.get(Constants.COLUMN_CREDIT_GL_NAME);
		vendorUploadStage1.setCreditglName(csvRecord.get(columnIndexMap.get(setCreditglName)));

      
        String setDebitglId = customTemplateHeaderMappings.get(Constants.COLUMN_DEBIT_GL_ID);
		vendorUploadStage1.setDebitglId(csvRecord.get(columnIndexMap.get(setDebitglId)));

		String setDebitglName = customTemplateHeaderMappings.get(Constants.COLUMN_DEBIT_GL_NAME);
		vendorUploadStage1.setDebitglName(csvRecord.get(columnIndexMap.get(setDebitglName)));

	 
		String setFilingPeriod = customTemplateHeaderMappings.get(Constants.FILLING_PERIOD);
		vendorUploadStage1.setFilingPeriod(csvRecord.get(columnIndexMap.get(setFilingPeriod)));

	
		String setUdf1 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_1);
		vendorUploadStage1.setUdf1(csvRecord.get(columnIndexMap.get(setUdf1)));

	    String setUdf2 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_2);
		vendorUploadStage1.setUdf2(csvRecord.get(columnIndexMap.get(setUdf2)));

		String setUdf3 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_3);
		vendorUploadStage1.setUdf3(csvRecord.get(columnIndexMap.get(setUdf3)));

	    String setUdf4 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_4);
		vendorUploadStage1.setUdf4(csvRecord.get(columnIndexMap.get(setUdf4)));

		String setUdf5 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_5);
		vendorUploadStage1.setUdf5(csvRecord.get(columnIndexMap.get(setUdf5)));

		String setUdf6 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_6);
		vendorUploadStage1.setUdf6(csvRecord.get(columnIndexMap.get(setUdf6)));

		String setUdf7 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_7);
		vendorUploadStage1.setUdf7(csvRecord.get(columnIndexMap.get(setUdf7)));

		String setUdf8 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_8);
		vendorUploadStage1.setUdf8(csvRecord.get(columnIndexMap.get(setUdf8)));

		String setUdf9 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_9);
		vendorUploadStage1.setUdf9(csvRecord.get(columnIndexMap.get(setUdf9)));

		String setUdf10 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_10);
		vendorUploadStage1.setUdf10(csvRecord.get(columnIndexMap.get(setUdf10)));

		 
        
		String setUdf11 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_11);
		vendorUploadStage1.setUdf11(csvRecord.get(columnIndexMap.get(setUdf11)));

		String setUdf12 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_12);
		vendorUploadStage1.setUdf12(csvRecord.get(columnIndexMap.get(setUdf12)));

		String setUdf13 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_13);
		vendorUploadStage1.setUdf13(csvRecord.get(columnIndexMap.get(setUdf13)));

		String setUdf14 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_14);
		vendorUploadStage1.setUdf14(csvRecord.get(columnIndexMap.get(setUdf14)));

		String setUdf15 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_15);
		vendorUploadStage1.setUdf15(csvRecord.get(columnIndexMap.get(setUdf15)));

		String setUdf16 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_16);
		vendorUploadStage1.setUdf16(csvRecord.get(columnIndexMap.get(setUdf16)));

		String setUdf17 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_17);
		vendorUploadStage1.setUdf17(csvRecord.get(columnIndexMap.get(setUdf17)));

		String setUdf18 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_18);
		vendorUploadStage1.setUdf18(csvRecord.get(columnIndexMap.get(setUdf18)));

		String setUdf19 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_19);
		vendorUploadStage1.setUdf19(csvRecord.get(columnIndexMap.get(setUdf19)));
		String setUdf20 = customTemplateHeaderMappings.get(Constants.COLUMN_UDF_20);
		vendorUploadStage1.setUdf20(csvRecord.get(columnIndexMap.get(setUdf20)));
		
		tdsDetailsTemplateDTOList.add(vendorUploadStage1);
		

    
		
		
	}
	
}
