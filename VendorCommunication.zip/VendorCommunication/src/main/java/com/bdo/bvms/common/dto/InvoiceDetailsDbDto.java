package com.bdo.bvms.common.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InvoiceDetailsDbDto {

	private String id;
	private String taxpayergstin;
	private String docType;
	private String tranType;
	private String vendorgstin;
	private String vendorlegalname;
	private String vendortradename;
	private String invoiceno;
	private String invoicedate;
	private String taxable;
	private String pos;
	private String invoicevalue;
	private String inputType;
	private String itcIneligibleReversalIndicator;
	private String itcIneligibleReversalPercentage;
	private String supplierStateCode;
	private String description;
	private String hsn;
	private String qty;
	private String rate;
	private String unit;
	 private String gst;
	private String igst;
	private String igstRate;
	 private String cgst;
	 private String cgstRate;
	private String sgst;
	private String sgstRate;
	private String cess;
	private String cessRate;
	 private String totalitemvalue;
}
