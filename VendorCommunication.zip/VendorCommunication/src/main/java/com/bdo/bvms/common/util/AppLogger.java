package com.bdo.bvms.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bdo.bvms.common.constant.Constants;


/**
 * FileType: java Author : anka Created On : 02/11/2017 6:56:39 PM Copy Rights :
 * Anka Technology Solutions Pvt. Ltd.
 */
public class AppLogger {

    private static final Logger logger = LoggerFactory.getLogger(AppLogger.class);

    /**
     * This method will log all the messages to the destinations specified in
     * the configuration file of Log4j.
     *
     * @param errorLevel
     *            (String)
     * @param processCode
     *            (String)
     * @param errorDetails
     *            (String)
     * @param processDetails
     *            (String)
     */
    public static void logMessage(String errorLevel, String className, String methodName, String errorDetails) {

        String errorMessage = errorDetails;

        if ("DEBUG".equalsIgnoreCase(errorLevel)) {
            logger.info(className, Constants.COLON, methodName, Constants.COLON, errorMessage);
        } else if ("INFO".equalsIgnoreCase(errorLevel)) {
            logger.error(className, Constants.COLON, methodName, Constants.COLON, errorMessage);
        } else if ("WARN".equalsIgnoreCase(errorLevel)) {
            logger.error(className, Constants.COLON, methodName, Constants.COLON, errorMessage);
        } else if ("ERROR".equalsIgnoreCase(errorLevel)) {
            logger.error(className, Constants.COLON, methodName, Constants.COLON, errorMessage);
        } else if ("FATAL".equalsIgnoreCase(errorLevel)) {
            logger.error(className, Constants.COLON, methodName, Constants.COLON, errorMessage);
        }
    }

    public static void info(String className, String methodName, String errorMessage) {
        StringBuilder msg = new StringBuilder();
        msg.append(Constants.COLON);
        msg.append(className);
        msg.append(Constants.COLON);
        msg.append(methodName);
        msg.append(Constants.COLON);
        msg.append(errorMessage);

        if (logger.isInfoEnabled()) {
            logger.info(msg.toString());
        }

    }

    public static void process(String errorMessage) {
        logger.info(errorMessage);
    }

    public static void debug(String className, String methodName, String errorMessage) {
        logger.error(className, Constants.COLON, methodName, Constants.COLON, errorMessage);
    }

    public static void warn(String className, String methodName, String errorMessage) {
        logger.error(className, Constants.COLON, methodName, Constants.COLON, errorMessage);
    }

    public static void error(String className, String methodName, String errorMessage) {
        StringBuilder msg = new StringBuilder();
        msg.append(Constants.COLON);
        msg.append(className);
        msg.append(Constants.COLON);
        msg.append(methodName);
        msg.append(Constants.COLON);
        msg.append(errorMessage);

        if (logger.isInfoEnabled()) {
            logger.error(msg.toString());
        }

    }

    public static void fatal(String className, String methodName, String errorMessage) {
        logger.error(className, Constants.COLON, methodName, Constants.COLON, errorMessage);
    }

    public static boolean isInfoEnables() {
        return logger.isInfoEnabled();
    }

    public static boolean isErrorEnables() {
        return logger.isErrorEnabled();
    }

    public static boolean isDebugEnabled() {
        return logger.isDebugEnabled();
    }

    protected AppLogger() {

    }

}
