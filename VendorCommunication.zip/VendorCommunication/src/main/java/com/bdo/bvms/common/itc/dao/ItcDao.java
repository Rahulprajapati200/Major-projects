package com.bdo.bvms.common.itc.dao;

import java.util.List;

import com.bdo.bvms.common.dto.ItcDto;
import com.bdo.bvms.common.dto.PaymentResponseBean;
import com.bdo.bvms.common.dto.TdsDetails;
import com.bdo.bvms.common.dto.UploadReqDTO;

public interface ItcDao {

	PaymentResponseBean gstInwardInvCdnInsert(String csvPaymentSuccessFilePath, String csvPaymentErrorFilePath,
			String successTdsTable, String failureTdsTable);

	List<ItcDto> getItcErrorDataListWithErrorCode(UploadReqDTO uploadReqDTO);

	int checkIfInvoiceDetailExits(ItcDto rowData);

	void updateItcDetailsInInward(List<ItcDto> sucessItcDtoTemplateDTOsList);

	int getInwardResultFPCount(String gstinUinOfRecipient, String inwardNo, String inwardDate, String gstinOfSupplier,
			String filingPeriod, String string);

	List<String> getDuplicateFPInDiffMonth(String gstinOfSupplier, String gstinUinOfRecipient, String string,
			String filingPeriod);

}
