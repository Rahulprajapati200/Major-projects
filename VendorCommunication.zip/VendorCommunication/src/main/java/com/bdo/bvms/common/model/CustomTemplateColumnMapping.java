package com.bdo.bvms.common.model;

import java.util.Date;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class CustomTemplateColumnMapping {

	Integer id;
	Integer amCustomTemplateNameId;
	@EqualsAndHashCode.Include
	String templateColumn;
	Integer pldTemplateId;
	String pan;
	Integer entityId;
	Integer amTemplateColumnConfigurationId;
	@EqualsAndHashCode.Include	
	Boolean isAutoMap;
	Date createdAt;
	Integer createdBy;
	Date modifiedAt;
	Integer modifiedBy;
	
}
