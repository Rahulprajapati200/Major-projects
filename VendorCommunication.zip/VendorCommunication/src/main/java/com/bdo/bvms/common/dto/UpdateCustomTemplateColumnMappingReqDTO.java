package com.bdo.bvms.common.dto;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class UpdateCustomTemplateColumnMappingReqDTO {

	@NotBlank(message = "{templateColumn.notBlank}")
	String templateColumn;
	
	@NotNull(message = "{customTemplateColumnMappingId.notNull}")
	Integer customTemplateColumnMappingId;
	
	@NotNull(message = "{isAutoMap.notNull}")
	Boolean isAutoMap;
	
	List<@Valid UpdateCustomTemplateColumnValueMappingReqDTO> updateCustomTemplateColumnValueMapping ;
	
}

