package com.bdo.bvms.common.itc.service;

import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;

public interface UploadNDownloadItcAzureFile {

	void uploadITCErrorFile(UploadReqDTO uploadReqDTO, AzureConnectionCredentialsDTO storageCredentials);

}
