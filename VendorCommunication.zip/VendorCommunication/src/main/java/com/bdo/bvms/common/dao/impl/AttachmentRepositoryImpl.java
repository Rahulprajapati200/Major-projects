package com.bdo.bvms.common.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.constant.Constants;
import com.bdo.bvms.common.dao.AttachmentRepository;
import com.bdo.bvms.common.dto.AttachmentListDto;
import com.bdo.bvms.common.dto.AttacmentReqDTO;
import com.bdo.bvms.common.dto.GstinAttachments;
import com.bdo.bvms.common.dto.SearchVendorDetailsReqDTO;
import com.bdo.bvms.common.dto.SystemParameter;
import com.bdo.bvms.common.dto.TaxpayerVendor;
import com.bdo.bvms.common.dto.WorkflowScreenTabChanges;
import com.bdo.bvms.common.dto.WorkflowScreenTabChangesArchived;
import com.bdo.bvms.common.sql.TransactionSQL;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class AttachmentRepositoryImpl implements AttachmentRepository {

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Value("${mst.database-name}")
    private String mstDatabaseName;

    @Value("${txn.database-name}")
    private String trnDatabaseName;

    @Override
    public List<AttachmentListDto> getAttachmentList(AttacmentReqDTO attacmentReqDTO) {
    	
    	
        String attachmentSql = TransactionSQL.getAttachmentSql(mstDatabaseName, trnDatabaseName,
                        attacmentReqDTO.getCommunicationRefId());

        String fileUrlSql=TransactionSQL.getFileUrlSql(mstDatabaseName);
        
        String fileUrl=jdbcTemplateMst.queryForObject(fileUrlSql,String.class);
        
        String blobNameSql=TransactionSQL.getBlobName(mstDatabaseName);
        
        String blobName=jdbcTemplateMst.queryForObject(blobNameSql,String.class);
        
        try {
            return jdbcTemplateTrn.query(attachmentSql, new ResultSetExtractor<List<AttachmentListDto>>() {

                public List<AttachmentListDto> extractData(ResultSet rs) throws SQLException, DataAccessException {
                    List<AttachmentListDto> attachmentListDto = new ArrayList<>();
                    while (rs.next()) {
                        AttachmentListDto attachmentDto = new AttachmentListDto();
                        attachmentDto.setName(rs.getString("name"));
                        attachmentDto.setCreatedAt(rs.getString(Constants.CREATED_AT));
                        attachmentDto.setPath(rs.getString("path"));
                        attachmentDto.setSize(rs.getString("size"));
                        attachmentDto.setModuleId(rs.getInt("pld_module_id"));
                        attachmentDto.setFileExtension(FilenameUtils.getExtension(rs.getString("path")));
                        attachmentDto.setFileUrl(fileUrl+Constants.FORWORDSLASH+blobName);
                        attachmentListDto.add(attachmentDto);
                    }
                    return attachmentListDto;

                }

            }, attacmentReqDTO.getCommunicationRefId(), attacmentReqDTO.getModuleId());
        } catch (Exception ex) {
            log.error("Error generated:", ex);
            return new ArrayList<>();
        }

    }

    @Override
    public Page<GstinAttachments> searchAttachments(Pageable paging,
                    @Valid SearchVendorDetailsReqDTO searchVendorDetailsReqDTO) {

        Integer count = countSearchAttachments(searchVendorDetailsReqDTO);
        if (count != 0) {
            return new PageImpl<>(jdbcTemplateTrn.query(TransactionSQL.searchAttachmentsSql(mstDatabaseName),
                            new RowMapper<GstinAttachments>() {

                                public GstinAttachments mapRow(ResultSet rs, int rowNum) throws SQLException {
                                    return GstinAttachments.builder().id(rs.getInt("id")).tvcrId(rs.getInt("tvcr_id"))
                                                    .taxPayerGstin(rs.getString("tax_payer_gstin"))
                                                    .vendorGstin(rs.getString("vendor_gstin"))
                                                    .name(rs.getString("name")).path(rs.getString("path"))
                                                    .pldDocumentType(rs.getInt("pld_document_type"))
                                                    .documentType(rs.getString("document_type"))
                                                    .createdAt(rs.getDate("created_at"))
                                                    .modifiedAt(rs.getDate("modified_at"))
                                                    .createdBy(rs.getInt("created_by"))
                                                    .modifiedBy(rs.getInt("modified_by"))
                                                    .createdByEmail(rs.getString("created_by_email"))
                                                    .createdByName(rs.getString("created_by_name"))
                                                    .modifiedByEmail(rs.getString("modified_by_email"))
                                                    .modifiedByName(rs.getString("modified_by_name"))
                                                    .remarks(rs.getString("remarks")).build();
                                }
                            }, Constants.PICKUP_MASTER_ATTACHMENT_TYPE, searchVendorDetailsReqDTO.getTaxpayerGstin(),
                            searchVendorDetailsReqDTO.getVendorGstin(), paging.getPageSize(), paging.getOffset()),
                            paging, count);
        }
        return null;
    }

    private Integer countSearchAttachments(SearchVendorDetailsReqDTO searchVendorDetailsReqDTO) {
        return jdbcTemplateTrn.queryForObject(TransactionSQL.COUNT_SEARCH_ATTACHMENTS_SQL, Integer.class,
                        searchVendorDetailsReqDTO.getTaxpayerGstin(), searchVendorDetailsReqDTO.getVendorGstin());
    }

    @Override
    public SystemParameter searchSystemParameter(SystemParameter systemParameter) {
        return jdbcTemplateMst.queryForObject(TransactionSQL.GET_SYSTEM_PARAMETER, new RowMapper<SystemParameter>() {

            public SystemParameter mapRow(ResultSet rs, int rowNum) throws SQLException {
                return SystemParameter.builder()
                                .keyName(rs.getObject("KeyNAME") == null ? null : rs.getString("KeyNAME"))
                                .keyValue(rs.getObject("KeyVALUE") == null ? null : rs.getString("KeyVALUE")).build();
            }
        }, systemParameter.getKeyName());
    }

    @Override
    public TaxpayerVendor searchMasters(TaxpayerVendor taxpayerVendor, int dataVersion) {
        return jdbcTemplateTrn.queryForObject(TransactionSQL.SEARCH_MASTERS_SQL, new RowMapper<TaxpayerVendor>() {

            public TaxpayerVendor mapRow(ResultSet rs, int rowNum) throws SQLException {
                return TaxpayerVendor.builder().id(rs.getInt("id")).childRelationId(rs.getInt("child_relation_id"))
                                .pldDataVersion(rs.getInt("pld_data_version"))
                                .companyLegalName(rs.getString(Constants.COMPANYLEGALNAME))
                                .companyTradeName(rs.getString("company_trade_name"))
                                .vendorCodeErp(rs.getString("vendor_code_erp")).panVendor(rs.getString("pan_vendor"))
                                .createdAt(rs.getDate("created_at")).build();

            }

        }, taxpayerVendor.getGstinTaxpayer(), taxpayerVendor.getGstinVendor(), dataVersion);
    }

    @Override
    public WorkflowScreenTabChanges checkIfWorkflowScreenTabChangesExists(
                    WorkflowScreenTabChanges workflowScreenTabChanges) {
        return jdbcTemplateTrn.queryForObject(TransactionSQL.CHECK_IF_WORKFLOW_SCREEN_TAB_CHANGES_EXISTS_SQL,
                        new RowMapper<WorkflowScreenTabChanges>() {

                            public WorkflowScreenTabChanges mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return WorkflowScreenTabChanges.builder().id(rs.getInt("id"))
                                                .address(rs.getInt("address")).attachments(rs.getInt("attachments"))
                                                .bank(rs.getInt("bank")).contact(rs.getInt("contact"))
                                                .master(rs.getInt("master")).pldModuleId(rs.getInt("pld_module_id"))
                                                .tvcrid(rs.getInt("tvcr_id")).updatedAt(rs.getDate("updated_at"))
                                                .updatedBy(rs.getInt("updated_by")).build();
                            }

                        }, workflowScreenTabChanges.getTvcrid());
    }

    @Override
    public Integer insertWorkflowScreenTabChanges(WorkflowScreenTabChanges workflowScreenTabChanges,
                    String columnName) {
        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                            TransactionSQL.insertWorkFlowScreenTabChangesSql(columnName),
                            Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, workflowScreenTabChanges.getTvcrid());
            ps.setObject(2, workflowScreenTabChanges.getPldModuleId());
            ps.setObject(3, Constants.WORKFLOW_SCREEN_TAB_CHANGES_STATUS_ACTIVE);
            // ps.setObject(4, workflowScreenTabChanges.getUpdatedAt());
            ps.setObject(4, workflowScreenTabChanges.getUpdatedBy());
            return ps;
        }, keyHolder);
        if (keyHolder.getKey() == null) {
            return null;
        } else {
            Number key = keyHolder.getKey();
            return key == null ? null : key.intValue();

        }
    }

    @Override
    public Integer archiveWorkflowScreenTabChanges(WorkflowScreenTabChangesArchived workflowScreenTabChangesArchived) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                            TransactionSQL.INSERT_WORKFLOW_SCREEN_TAB_CHANGES_ARCHIVED_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1, workflowScreenTabChangesArchived.getWorkflowScreenTabChangesId());
            ps.setObject(2, workflowScreenTabChangesArchived.getTvcrid());
            ps.setObject(3, workflowScreenTabChangesArchived.getMaster());
            ps.setObject(4, workflowScreenTabChangesArchived.getContact());
            ps.setObject(5, workflowScreenTabChangesArchived.getBank());
            ps.setObject(6, workflowScreenTabChangesArchived.getAddress());
            ps.setObject(7, workflowScreenTabChangesArchived.getAttachments());
            ps.setObject(8, workflowScreenTabChangesArchived.getUpdatedAt());
            ps.setObject(9, workflowScreenTabChangesArchived.getUpdatedBy());
            return ps;
        }, keyHolder);
        if (keyHolder.getKey() == null) {
            return null;
        } else {
            Number key = keyHolder.getKey();
            return key == null ? null : key.intValue();

        }
    }

    @Override
    public Integer updateWorkflowScreenTabChanges(WorkflowScreenTabChanges workflowScreenTabChanges,
                    String columnName) {
        return jdbcTemplateTrn.update(TransactionSQL.updateWorkflowScreenTabChangesSql(columnName),
                        Constants.WORKFLOW_SCREEN_TAB_CHANGES_STATUS_ACTIVE, workflowScreenTabChanges.getUpdatedBy(),
                        workflowScreenTabChanges.getTvcrid());
    }

    @Override
    public Integer addVendorAttachments(GstinAttachments gstinAttachments) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(TransactionSQL.INSERT_VENDOR_ATTACHMENTS_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, gstinAttachments.getCommunicationRefId());
            ps.setString(2, gstinAttachments.getName());
            ps.setObject(3, gstinAttachments.getPldDocumentType());
            ps.setString(4, gstinAttachments.getPath());
            ps.setObject(5, gstinAttachments.getSize());
            ps.setObject(6, gstinAttachments.getCreatedBy());
            ps.setObject(7, gstinAttachments.getRemarks());
            ps.setString(8, gstinAttachments.getPldModuleId());
            return ps;
        }, keyHolder);
        if (keyHolder.getKey() == null) {
            return null;
        } else {
            Number key = keyHolder.getKey();
            return key == null ? null : key.intValue();
        }
    }
    
   
}
