package com.bdo.bvms.common.service;

import com.bdo.bvms.common.dto.InwardInvoiceCDNReqDTO;

public interface ProcessUploadService {

	String uploadAndProcessFile(InwardInvoiceCDNReqDTO uploadRequestDTO);

}
