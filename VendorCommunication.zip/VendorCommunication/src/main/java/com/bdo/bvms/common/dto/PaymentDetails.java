package com.bdo.bvms.common.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PaymentDetails {
	
	private int paymentId;
	private String amountofPayment;
	private String orgAmountofPayment;
	private String paymentRefNo;
	private String dateOfPayment;
	private String invAgainstProv;
	private String inwardNoProvAdv;
	private String inwardDateProvAdv;
	private String inwardAmountProvAdv; 
	private String balanceOutstanding;
	
	private String gstinUinOfRecipient;
	private String panOfRecipient;
	private String panOfSupplier;
	private String docType;
	private String gstinOfSupplier;	
	private String supplierName;	
	private String inwardNo;	
	private String inwardDate;
	private String filingPeriod;
		
	private String udf1;	
	private String udf2;	
	private String udf3;
	private String udf4;
	private String udf5;	
	private String udf6;	
	private String udf7;	
	private String udf8;	
	private String udf9;
	private String udf10;	
	private String udf11;	
	private String udf12;
	private String udf13;
	private String udf14;	
	private String udf15;	
	private String udf16;
	private String udf17;
	private String udf18;
	private String udf19;	
	private String udf20;
	private int excelRowId;
	private boolean valid;
	private StringBuilder errorCodeList=new StringBuilder();
	private StringBuilder errorDescriptionList=new StringBuilder();
	
	private String errorCode;
	

	
	
}
