package com.bdo.bvms.common.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class UploadReqDTO extends JsonToObjDTO{

	    private int id;
	    private String batchNo;
	    //private String fileName;
	    private int tenantId;
	    private String jsonReq;
	    private int processStatus;
	    private String fileSize;
	    private int uploadBy;
	    private String uploadType;
	    private String fileType;
	    private int uploadLogId;
	    private String inwardValidationRule;
	    private String sourceMode="Excel";
	    private String userGstin;
	    private String fpRange;
	    private int userId;
	    private String isCustomTemplate;
	    private String customTemplateId;
	    private String uploadSource;
	    private String fp;
}
