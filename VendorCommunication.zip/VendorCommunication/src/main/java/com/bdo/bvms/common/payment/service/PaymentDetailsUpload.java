package com.bdo.bvms.common.payment.service;

import com.bdo.bvms.common.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.common.dto.UploadReqDTO;

public interface PaymentDetailsUpload {
	 String validateAndSavePaymentDetails(UploadReqDTO uploadReqDTO, AzureConnectionCredentialsDTO storageCredentials);

	void addInNotification(UploadReqDTO uploadRequestDTO);
}
