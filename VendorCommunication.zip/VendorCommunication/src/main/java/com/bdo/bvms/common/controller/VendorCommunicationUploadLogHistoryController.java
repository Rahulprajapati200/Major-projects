package com.bdo.bvms.common.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;

import com.bdo.bvms.common.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.common.dto.UploadHistoryResponseDTO;
import com.bdo.bvms.common.exceptions.VendorInvoiceServerException;

public interface VendorCommunicationUploadLogHistoryController {

    ResponseEntity<UploadHistoryResponseDTO> logHistory(HttpServletRequest request, UploadHistoryRequestDTO requestDTO)
                    throws VendorInvoiceServerException;

}
