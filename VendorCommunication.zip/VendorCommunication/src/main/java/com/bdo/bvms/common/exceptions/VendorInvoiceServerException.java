/**
 * Copyright (C) 2022
 * File          : 
 * Author        : BDO
 * Company       : BDO
 * Date Created  : 07-Sept-2022
 * Description   : Handle the business logic exceptions
 **/
package com.bdo.bvms.common.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * The Class BusinessException.
 */
@ResponseStatus(value = HttpStatus.PRECONDITION_FAILED)
public class VendorInvoiceServerException extends Exception {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new business exception.
	 *
	 * @param message the message
	 */
	public VendorInvoiceServerException(String message) {
        super(message);
    }

    /**
     * Instantiates a new business exception.
     *
     * @param message the message
     * @param cause the cause
     */
    public VendorInvoiceServerException(String message, Throwable cause) {
    	    	
        super(message, cause);
    }

   
    
    
}
