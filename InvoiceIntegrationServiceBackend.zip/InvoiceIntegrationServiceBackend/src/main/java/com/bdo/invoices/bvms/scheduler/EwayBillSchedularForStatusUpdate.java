package com.bdo.invoices.bvms.scheduler;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.bdo.bvms.ewaybill.api.GetEwayBillApiDao;
import com.bdo.bvms.ewaybill.api.dto.SchedularLogDto;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class EwayBillSchedularForStatusUpdate {
	
	@Autowired
    GetEwayBillApiDao getEwayBillApiDaoImpl;

    
//	  @Scheduled(fixedDelay =90000)
	@Scheduled(cron = "0 1 21 * * ?")
	 public void jobForExpiredStatus() throws InvoiceIntegrationEWBException {
		String toDateFormat = "dd-MM-yyyy";
        String fromDateFormat = "yyyy-MM-dd";
        LocalDate localDate = LocalDate.now();
        String expDate = DateUtil.convertDateFormat(fromDateFormat, toDateFormat, String.valueOf(localDate.minusDays(1)));
        SchedularLogDto schedularLog = new SchedularLogDto();
        schedularLog.setSchedularCallFor("Ewaybill Status Update to Expired");
        int id = getEwayBillApiDaoImpl.insertToSchedularLog(schedularLog);
        schedularLog.setId(id);
        try {
        	getEwayBillApiDaoImpl.updateEwbStatusToExpired(expDate);
        	schedularLog.setIsSucess("1");
            getEwayBillApiDaoImpl.updateSchedularLog(schedularLog);
        }catch(Exception ex){
        	schedularLog.setIsSucess("0");
            schedularLog.setErrorRemarks(ex.getMessage());
            getEwayBillApiDaoImpl.updateSchedularLog(schedularLog);
        }	 
		 
	 }
	
//       @Scheduled(fixedDelay =90000)
	 @Scheduled(cron = "0 1 20 * * ?")
	 public void jobForDiscardedStatus() throws InvoiceIntegrationEWBException {
		String toDateFormat = "dd-MM-yyyy";
        String fromDateFormat = "yyyy-MM-dd";
        LocalDate localDate = LocalDate.now();
        String disDate = DateUtil.convertDateFormat(fromDateFormat, toDateFormat, String.valueOf(localDate.minusDays(12)));
        SchedularLogDto schedularLog = new SchedularLogDto();
        schedularLog.setSchedularCallFor("Ewaybill Status Update to Discarded");
        int id = getEwayBillApiDaoImpl.insertToSchedularLog(schedularLog);
        schedularLog.setId(id);
        try {
        	getEwayBillApiDaoImpl.updateEwbStatusToDiscarded(disDate);
        	schedularLog.setIsSucess("1");
            getEwayBillApiDaoImpl.updateSchedularLog(schedularLog);
        }catch(Exception ex){
        	schedularLog.setIsSucess("0");
            schedularLog.setErrorRemarks(ex.getMessage());
            getEwayBillApiDaoImpl.updateSchedularLog(schedularLog);
        }
		 
		 
	 }

}
