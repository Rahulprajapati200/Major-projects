package com.bdo.invoices.sftp.upload.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class SftpFileDetailsDto {

    int id;
    String batchedFileName;
    String sftpPath;
    String templateType;
    String panNo;
    String customTemplateId;
    String originalFileName;
    String uploadType;
    String userId;
}
