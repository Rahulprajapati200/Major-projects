package com.bdo.invoices.sftp.upload.service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;

import com.bdo.bvms.invoices.custom.exception.AzureUploadDownloadException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceSavedataOnUploadException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.invoices.sftp.upload.dto.SftpFileDetailsDto;
import com.bdo.invoices.sftp.upload.dto.SftpUploadRequestDTO;
import com.microsoft.azure.storage.StorageException;

public interface SftpUploadService {
	String getBatchNo(SftpUploadRequestDTO reqDto);
	
	void downloadFileFromSftpCloud(String fileExt, String fileNameOriginal)
			throws InvalidKeyException, URISyntaxException, StorageException, IOException;
	
	String uploadAndProcessFile(SftpFileDetailsDto fileDetailsDto, SftpUploadRequestDTO reqDto)
			throws VendorInvoiceSavedataOnUploadException, VendorInvoiceServerException, AzureUploadDownloadException;



}
