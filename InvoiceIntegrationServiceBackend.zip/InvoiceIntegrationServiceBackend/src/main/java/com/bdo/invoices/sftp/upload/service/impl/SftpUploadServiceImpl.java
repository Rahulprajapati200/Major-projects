package com.bdo.invoices.sftp.upload.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.EinvoiceDataTemplateUpload;
import com.bdo.bvms.einvoice.service.EwayBillUploadDataService;
import com.bdo.bvms.einvoice.service.UploadLogService;
import com.bdo.bvms.einvoice.service.UploadNDownloadFileService;
import com.bdo.bvms.invoices.config.AzureClientProvider;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.AzureUploadDownloadException;
import com.bdo.bvms.invoices.custom.exception.InvalidTemplateHeaderException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceSavedataOnUploadException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.UploadLogDto;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.dto.UploadStageLogDto;

import com.bdo.invoices.sftp.upload.dao.SftpUploadDao;
import com.bdo.invoices.sftp.upload.dto.SftpFileDetailsDto;
import com.bdo.invoices.sftp.upload.dto.SftpUploadRequestDTO;
import com.bdo.invoices.sftp.upload.service.SftpUploadService;
import com.google.common.io.Files;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.file.CloudFileClient;
import com.microsoft.azure.storage.file.CloudFileDirectory;
import com.microsoft.azure.storage.file.CloudFileShare;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class SftpUploadServiceImpl implements SftpUploadService {

    CloudFileClient fileClient;
    CloudFileShare share;
    CloudFileDirectory rootDir;
    CloudStorageAccount storageAccount;

    @Value("${temp.folder.path}")
    String tempFolder;

    @Autowired
    CommonDao commonDao;
    
    @Autowired
	UploadTransDao uploadTransDao;
    
    @Autowired
	UploadLogService uploadLogService;
    
    @Autowired
	UploadNDownloadFileService uploadFileService;
    
    @Autowired
    public AzureClientProvider client;
    
    @Autowired
    public UploadTransDao uploadDao;
    
    @Autowired
	EinvoiceDataTemplateUpload einvoiceDataTemplateUpload;
    
    @Autowired
	EwayBillUploadDataService ewayBillReadDataService;
    
    @Autowired
    private MessageSource messageSource;

    @Autowired
    private SftpUploadDao sftpUploadDao;

    public static final String sftpConnectionString = "DefaultEndpointsProtocol=https;AccountName=bvmssftpdevsa;AccountKey=VFaJvWQP1dvhg7LETBMegjh1RyzD3Tob9uOaN84cjNl5rcOTvQpPLVibz8KEe1ZbL9InWmeFxBXC+ASt68/WeQ==;EndpointSuffix=core.windows.net";
    public static final String sftpContainerName = "dev-bvms-sftp-connector";

    @Override
    public void downloadFileFromSftpCloud(String fileExt ,String fileNameOriginal)
                    throws InvalidKeyException, URISyntaxException, StorageException, IOException {

        storageAccount = CloudStorageAccount.parse(sftpUploadDao.getSftpConnectionStringFromDB());
        // Create the Azure Files client.
        fileClient = storageAccount.createCloudFileClient();
        // Get a reference to the file share
        share = fileClient.getShareReference(sftpUploadDao.getSftpContainerNameFromDB());
        // Get a reference to the root directory for the share.
        rootDir = share.getRootDirectoryReference();
       
        rootDir.getFileReference(fileNameOriginal).downloadToFile(tempFolder + "/" + fileNameOriginal);
    }

    @Override
    public String uploadAndProcessFile(SftpFileDetailsDto fileDetailsDto,SftpUploadRequestDTO reqDto) throws VendorInvoiceSavedataOnUploadException, VendorInvoiceServerException, AzureUploadDownloadException {
       
    	
    	try{
        
        reqDto.setBatchNo(reqDto.getBatchNo());
        
        String fileExt="";
       
        String originalFileName=fileDetailsDto.getBatchedFileName();
		if (StringUtils.isNotBlank(originalFileName)) {
			 fileExt = Files.getFileExtension(originalFileName);
			reqDto.setFileType(fileExt);
		}
		String fileName = new StringBuilder().append(reqDto.getBatchNo()).append(Constants.UNSERSCORE_BASE)
                .append(Constants.DOTSEPARATOR).append(fileExt).toString();
		
		File original=new File(tempFolder+System.getProperty(Constants.FILESEPERATOR)+fileName);
		reqDto.setGstinOrPan("0");
		reqDto.setFileType(fileExt);
		reqDto.setCustomtemplateID(fileDetailsDto.getCustomTemplateId());
		if ("".equals(reqDto.getTemplatetypepldCode())) {
			reqDto.setTemplatetypepldCode(
					Integer.toString(uploadTransDao.updatePldCode(fileDetailsDto.getCustomTemplateId())));
		}
		reqDto.setModuleID(Constants.MODULEIDINVOICEUPLOAD);
		reqDto.setGstinOrPanList(fileDetailsDto.getPanNo());
		saveInUploadLog(original, reqDto);
		int uploadLogId = uploadLogService.getUploadLogId(reqDto.getBatchNo());

		AzureConnectionCredentialsDTO storageCredentials = commonDao.getAzureCredentialFromDB(reqDto.getEntityId(), "blob");
		uploadFileToAzureBlob(original, reqDto, storageCredentials);
		
		reqDto.setLogId(uploadLogId);
		UploadReqDTO uploadReqDTO = new UploadReqDTO();
		uploadReqDTO.setUplodSource(fileDetailsDto.getUploadType());
		setUploadReqDto(reqDto,uploadReqDTO);
		saveInStageLog(reqDto, uploadLogId);
		
		if (StringUtils.isBlank(originalFileName)) {
			uploadTransDao.updateProcessStatusWithRemarks(reqDto.getBatchNo(),
					Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, "Invalid file type");
			return Constants.FILEFORMATNOTALLOWED;

		}
		
		if (!(fileExt.equals(reqDto.getFileType()))) {
			uploadTransDao.updateProcessStatusWithRemarks(reqDto.getBatchNo(),
					Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, "Please choose valid file type");

			return Constants.FILETYPENOTCORRECT;
		}
		
    	
    	if (Constants.CSV.equals(fileExt) || Constants.XLSX.equals(fileExt) || Constants.XLS.equals(fileExt)
				|| Constants.PDF.equals(fileExt) || Constants.PNG.equals(fileExt)
				|| Constants.JPG.equals(fileExt)) {

			if (Constants.E_INVOICE_CODE.equalsIgnoreCase(uploadReqDTO.getUploadType())) {
				einvoiceDataTemplateUpload.validateAndSaveData(uploadReqDTO, storageCredentials);
			} else if (Constants.E_WAY_BILL_CODE.equalsIgnoreCase(uploadReqDTO.getUploadType())) {
				ewayBillReadDataService.validateNSaveData(uploadReqDTO, storageCredentials);
			} else if (Constants.INVOICE_CODE.equalsIgnoreCase(uploadReqDTO.getUploadType())) {
				einvoiceDataTemplateUpload.validateAndSaveData(uploadReqDTO, storageCredentials);

			} else {
				uploadTransDao.updateProcessStatusWithRemarks(uploadReqDTO.getBatchNo(),
						Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, "Template Invalid");
				return Constants.INVALIDTEMPLATETYPE;
			}

		} else {
			uploadTransDao.updateProcessStatusWithRemarks(uploadReqDTO.getBatchNo(),
					Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, "Invalid file type");
			return Constants.FILEFORMATNOTALLOWED;
		}       
    } catch (VendorInvoiceSavedataOnUploadException | AzureUploadDownloadException
			| InvalidTemplateHeaderException e) {
		uploadTransDao.updateProcessStatusWithRemarks(fileDetailsDto.getBatchedFileName().split(".")[0], Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL,
				e.getMessage());
		throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                LocaleContextHolder.getLocale()));
	}
	catch (Exception e) {
		// Add entry in the exception log table
		
		log.error("Error occured while uplaoding template for bacthno.:" + fileDetailsDto.getBatchedFileName().split(".")[0], e);
		uploadTransDao.updateProcessStatusWithRemarks(fileDetailsDto.getBatchedFileName().split(".")[0], Constants.UPLOAD_INVOICES_PLD_STATUS_ERROR,
				e.getMessage());
		uploadTransDao.updateProcessStatus(fileDetailsDto.getBatchedFileName().split(".")[0], Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
		throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                LocaleContextHolder.getLocale()));
		// UploadStageLog also need to be updated****
	}
    	return Constants.FILEUPLOADEPROGRESS;
    	
    }

    
	
    @Override
	public String getBatchNo(SftpUploadRequestDTO reqDto) {
		StringBuilder batchNo = new StringBuilder();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(Constants.DD_MM);

        String currentDate = simpleDateFormat.format(new Date());

        Long currentTimestamp = new Timestamp(System.currentTimeMillis()).getTime();

        batchNo.append(reqDto.getTemplatetypepldCode() + Constants.UNDERSCORE + reqDto.getUserId()
                        + Constants.UNDERSCORE + reqDto.getEntityId() + Constants.UNDERSCORE + currentDate
                        + Constants.UNDERSCORE + currentTimestamp + Constants.UNDERSCORE
                        + generateRandonAlphabeticString(Constants.RANDOMNUM));

        return batchNo.toString();
	}

	private String generateRandonAlphabeticString(int length) {

	        if (length < 6) {
	            length = 6;
	        }

	        final char[] allAllowed = "abcdefghijklmnopqrstuvwxyzABCDEFGJKLMNPRSTUVWXYZ0123456789".toCharArray();

	        SecureRandom random = new SecureRandom();

	        StringBuilder password = new StringBuilder();

	        for (int i = 0; i < length; i++) {
	            password.append(allAllowed[random.nextInt(allAllowed.length)]);
	        }

	        return password.toString();

	    }



	private void setUploadReqDto(SftpUploadRequestDTO reqDto, UploadReqDTO uploadReqDTO) {

		uploadReqDTO.setFileType(reqDto.getFileType());
		uploadReqDTO.setPo(reqDto.getPo());
		uploadReqDTO.setPoDate(reqDto.getPoDate());
		uploadReqDTO.setGstinOrPanList(new ArrayList<>(Arrays.asList(reqDto.getGstinOrPanList())));
		uploadReqDTO.setUploadType(reqDto.getTemplatetypepldCode());
		uploadReqDTO.setTemplateType(reqDto.getTemplatetypepldCode());
		uploadReqDTO.setPanOrGstn(reqDto.getGstinOrPan());
		uploadReqDTO.setFp(reqDto.getFp());
		uploadReqDTO.setBatchNo(reqDto.getBatchNo());
		uploadReqDTO.setUploadLogId(reqDto.getLogId());
		uploadReqDTO.setId(reqDto.getUserId());
		uploadReqDTO.setVendorGstin(reqDto.getVendorGstin());
		uploadReqDTO.setInvoiceNo(reqDto.getInvoiceNo());
		uploadReqDTO.setInvoiceDate(reqDto.getInvoiceDate());
		uploadReqDTO.setDocType(reqDto.getDocType());
		uploadReqDTO.setIsCustomTemplate(reqDto.getIsCustomTemplate());
		uploadReqDTO.setCustomTemplateId(reqDto.getCustomtemplateID());
		uploadReqDTO.setUserId(reqDto.getUserId());
	
	}

	private void saveInStageLog(SftpUploadRequestDTO reqDto, int uploadLogId) {


        UploadStageLogDto uploadStageLogDto = new UploadStageLogDto();
        uploadStageLogDto.setUploadLogId(uploadLogId);
        uploadStageLogDto.setCreatedBy(reqDto.getUserId());
        uploadStageLogDto.setBatchNo(reqDto.getBatchNo());
        uploadStageLogDto.setProcessStage(Constants.PROCESS_STAGE_FILE_UPLOAD);

        uploadStageLogDto.setProcessState(Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED);

        Timestamp createdAt = Timestamp.from(Instant.now());
        uploadStageLogDto.setCreatedAt(createdAt);
        try {

            uploadTransDao.insertUploadStageLog(uploadStageLogDto);

        } catch (Exception ex) {
            log.error(ex + " : " + ex.getMessage());

        }

    
		
	}

	private String uploadFileToAzureBlob(File original, SftpUploadRequestDTO reqDto,
			AzureConnectionCredentialsDTO storageCredentials) throws AzureUploadDownloadException {
		if (log.isInfoEnabled()) {
            log.info("Class:" + this.getClass().toString() + ", method :uploadFileToAzureBlob");
        }

        try {

            if (original != null && original.length() > 0) {

                String fileType = FilenameUtils.getExtension(original.getName());

                String fileName = new StringBuilder().append(reqDto.getBatchNo()).append(Constants.UNSERSCORE_BASE)
                                .append(Constants.DOTSEPARATOR).append(fileType).toString();
                                
                try (InputStream input = new FileInputStream(original);) {
                    client.getClient(storageCredentials).blobName(fileName).buildClient().upload(input,
                    		original.length());
                }
                                
            }

        } catch (Exception ex) {
            // write code update TX uplaod log = Done
            log.error("Error in uploadFileToAzureBlob Method", ex);
            uploadDao.updateProcessStatus(reqDto.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            throw new AzureUploadDownloadException("File storage service is down");
        }

        return reqDto.getBatchNo();
		
	}

	private void saveInUploadLog(File original, SftpUploadRequestDTO reqDto) throws VendorInvoiceSavedataOnUploadException {
		
		UploadLogDto uploadLog = new UploadLogDto();

        if (Constants.PAN.equals(reqDto.getGstinOrPan())) {
            uploadLog.setTaxpayerPan(reqDto.getGstinOrPanList());
            uploadLog.setTaxpayerGstin("");
        } else if (Constants.GSTIN.equals(reqDto.getGstinOrPan())) {
            uploadLog.setTaxpayerGstin(String.join(",", reqDto.getGstinOrPanList()));
            uploadLog.setTaxpayerPan("");
        }

        uploadLog.setTemplateType(reqDto.getTemplatetypepldCode());
        uploadLog.setFileSize(original.length()/1024);
        uploadLog.setFileName(original.getName());
        uploadLog.setBatchNo(reqDto.getBatchNo());
        uploadLog.setPaBatchNo(reqDto.getPaBatchNo());
        uploadLog.setPldUploadStatus(Constants.UPLOAD_INVOICES_PLD_STATUS_INPROGRESS);
        //uploadLog.setFp(String.join(",", reqDto.getFp()));
        uploadLog.setFileType(reqDto.getFileType());
        uploadLog.setPldUploadSource(Integer.toString(reqDto.getModuleID()));
        if (StringUtils.isBlank(reqDto.getCustomtemplateID())
                        || "".equals(reqDto.getCustomtemplateID())) {
        	reqDto.setCustomtemplateID("0");
        }
        uploadLog.setCustomTemplateId(Integer.valueOf(reqDto.getCustomtemplateID()));
        uploadLog.setEntityId(reqDto.getEntityId());
        uploadLog.setCustomTemplate("1".equals(reqDto.getIsCustomTemplate()));
        uploadLog.setId(reqDto.getUserId());
        uploadLog.setUploadStartTime(Timestamp.from(Instant.now()));
        uploadLog.setBaseFileLocation(reqDto.getBatchNo() + Constants.BASE_DOT + reqDto.getFileType());
        uploadLog.setCreatedBy(String.valueOf(reqDto.getUserId()));

        try {

            uploadTransDao.uploadTxLogDetails(uploadLog);

        } catch (Exception ex) {
            log.error(ex + " Error come in uploading file related data into database ",ex);
            //TODO add entry in the exception log
            throw new VendorInvoiceSavedataOnUploadException("Unable to start upload process");

        }

		
	}

}
