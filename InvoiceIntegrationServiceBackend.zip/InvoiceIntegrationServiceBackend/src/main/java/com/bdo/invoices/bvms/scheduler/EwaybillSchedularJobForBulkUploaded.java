package com.bdo.invoices.bvms.scheduler;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.bdo.bvms.ewaybill.api.GetEwayBillApiDao;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.ewaybill.api.dto.SchedularLogDto;
import com.bdo.bvms.ewaybill.api.impl.GetEwayBillDetailsServiceImpl;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.EwayBillheaderDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class EwaybillSchedularJobForBulkUploaded {
	
    @Autowired
    GetEwayBillApiDao getEwayBillApiDaoImpl;

    @Autowired
    UploadTransDao uploadTransDao;

    @Autowired
    GetEwayBillDetailsServiceImpl getEwayBillDetailsServiceImpl;
    
    @Value("${mst.database-name}")
    String mstDatabseName;

//    @Scheduled(fixedDelay =90000)
    @Scheduled(cron = "0 0/30 * * * *")
    public void jobForGetEwbBulkUploaded() throws InvoiceIntegrationEWBException {

    	int id;
        List<GetEwayBillReqDTO> taxpayerGstinList = getEwayBillApiDaoImpl
                        .getTaxpayerListFromInvoiceEwaybillDetailsTable();
        Set<String> setOfBatchNo = new HashSet<>();
        EwayBillheaderDTO ewayBillheaderDTO = new EwayBillheaderDTO();
        
     
        SchedularLogDto schedularLog = new SchedularLogDto();
        schedularLog.setSchedularCallFor("Get Ewaybill Details by Ewaybill No");

        // get ewaybill details
        for (GetEwayBillReqDTO reqDto : taxpayerGstinList) {
            if (!StringUtils.isEmpty(reqDto.getEwaybillNo())) {
                log.info("fetching ewaybill details for taxpayer gstin :" + reqDto.getTaxpayerGstin()
                                + " and ewaybillNo: " + reqDto.getEwaybillNo());
                ewayBillheaderDTO = new EwayBillheaderDTO();
                
                // insert into schedular log
                schedularLog.setTaxpayerGstin(reqDto.getTaxpayerGstin());
                id = getEwayBillApiDaoImpl.insertToSchedularLog(schedularLog);
                schedularLog.setId(id);
                
                setOfBatchNo.add(reqDto.getBatchNo());

                try {
                	ewayBillheaderDTO = getEwayBillDetailsServiceImpl.getEwayBillDetails(reqDto);
                    getEwayBillApiDaoImpl.updateEwaybillFetchedDetails(reqDto.getEwaybillNo(),ewayBillheaderDTO);
                    schedularLog.setIsSucess("1");
                    getEwayBillApiDaoImpl.updateSchedularLog(schedularLog);

                } catch (Exception ex) {
                    log.error("error found during Get ewaybill data for taxpayer gstin: " + reqDto.getTaxpayerGstin()
                                    + " and ewaybillNo: " + reqDto.getEwaybillNo() + "|| Error Message>> "
                                    + ex.getMessage());
                    
                    getEwayBillApiDaoImpl.updateEwaybillReFetchedCount(reqDto.getId());
                    schedularLog.setIsSucess("0");
                    schedularLog.setErrorRemarks(ex.getMessage());
                    getEwayBillApiDaoImpl.updateSchedularLog(schedularLog);
                }
            }

        }
        Iterator<String> it = setOfBatchNo.iterator();

        while (it.hasNext()) {
            // insert success records into invoice header table
            uploadTransDao.writeInvoiceDetailsToInvoiceHeader(it.next(), 0,0,mstDatabseName);

        }

        setOfBatchNo.clear();
        taxpayerGstinList.clear();

    }

}
