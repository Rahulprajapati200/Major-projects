package com.bdo.invoices.sftp.upload.dao;

import java.util.List;

import com.bdo.invoices.sftp.upload.dto.SftpFileDetailsDto;

public interface SftpUploadDao {

    List<SftpFileDetailsDto> getSftpFileDetails();
   
	int getUserId(SftpFileDetailsDto sftpFileDetailsDto);

	int getEntityId(SftpFileDetailsDto sftpFileDetailsDto);

	void updateSftpPending();

	String getSftpConnectionStringFromDB();

	String getSftpContainerNameFromDB();

	String getSftpUploadUrl();

}
