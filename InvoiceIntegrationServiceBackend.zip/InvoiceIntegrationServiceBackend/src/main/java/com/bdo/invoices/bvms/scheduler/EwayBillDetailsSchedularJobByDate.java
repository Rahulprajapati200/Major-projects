package com.bdo.invoices.bvms.scheduler;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.bdo.bvms.ewaybill.api.GetEwayBillApiDao;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.ewaybill.api.dto.SchedularLogDto;
import com.bdo.bvms.ewaybill.api.impl.GetEwayBillDetailsByDateServiceImpl;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class EwayBillDetailsSchedularJobByDate {

    @Autowired
    GetEwayBillApiDao getEwayBillApiDaoImpl;

    @Autowired
    GetEwayBillDetailsByDateServiceImpl getEwayBillDetailsByDateServiceImpl;
    

//     @Scheduled(fixedDelay =90000)
    @Scheduled(cron = "0 1 4 * * ?")
    public void jobForEwbByDate() throws InvoiceIntegrationEWBException {

    	int id;
        String toDateFormat = "dd-MM-yyyy";
        String fromDateFormat = "yyyy-MM-dd";
        LocalDate localDate = LocalDate.now();
        String date = DateUtil.convertDateFormat(fromDateFormat, toDateFormat, String.valueOf(localDate.minusDays(1)));
        List<String> taxpayerGstinList = getEwayBillApiDaoImpl.getTaxpayerListFromEntityMaster();
        
        SchedularLogDto schedularLog = new SchedularLogDto();
        schedularLog.setSchedularCallFor("Get By Date Ewaybill Call");

        // generate ewaybill details for previous day
        for (String taxpayerGstin : taxpayerGstinList) {

	            GetEwayBillReqDTO reqDto = new GetEwayBillReqDTO();
	            reqDto.setTaxpayerGstin(taxpayerGstin);
		        if(log.isDebugEnabled()) {
		              log.debug("Started get by date e-Way bill call for gstin:" +taxpayerGstin+ " date: "+date );
		         }
		        

		        //get list of users to send notification
		        List<Integer> userIdList = getEwayBillApiDaoImpl.getUserIdBasedOnGstin(taxpayerGstin) ; 
		        
		        getEwayBillApiDaoImpl.commonPostNotification(Constants.VENDORUPLOADMSTID,
	            		Constants.GET_EWAYBILL_BY_DATE_INPROGRESS + taxpayerGstin +" and Date- "+date+ " Automatically",
                        Constants.NOTIFICATION_INITIATED,userIdList);
                       
		        
	            // insert into schedular log
	            schedularLog.setTaxpayerGstin(taxpayerGstin);
	            schedularLog.setEwaybillDate(date);
	            id = getEwayBillApiDaoImpl.insertToSchedularLog(schedularLog);
	            schedularLog.setId(id);
	            reqDto.setEwaybillDate(date);
	            reqDto.setIsCallFromSchedular("1");
	            
	            try {
	                getEwayBillDetailsByDateServiceImpl.getEwayBillDetails(reqDto);
	                schedularLog.setIsSucess("1");
	                getEwayBillApiDaoImpl.updateSchedularLog(schedularLog);
	                
	                getEwayBillApiDaoImpl.commonPostNotification(Constants.VENDORUPLOADMSTID,
	                		Constants.GET_EWAYBILL_BY_DATE_SUCCESS + taxpayerGstin +" and Date- "+date+ " Automatically",
	                        Constants.NOTIFICATION_SUCCESS,userIdList);
	                        
	            } catch (Exception ex) {
	               
	                log.error("No data for taxpayer gstin: " + reqDto.getTaxpayerGstin() + " for By Date e-Way bill date: "
	                                + reqDto.getEwaybillDate() + "|| Error Message>> ", ex);
	                
	                getEwayBillApiDaoImpl.commonPostNotification(Constants.VENDORUPLOADMSTID,
	                		Constants.GET_EWAYBILL_BY_DATE_FAILED + taxpayerGstin +" and Date- "+date+ " Automatically",
	                        Constants.NOTIFICATION_ERROR,userIdList);
	                        
	                schedularLog.setIsSucess("0");
	                schedularLog.setErrorRemarks(ex.getMessage());
	                getEwayBillApiDaoImpl.updateSchedularLog(schedularLog);
	            }
	            
	            if(log.isDebugEnabled()) {
	            	
	            	log.debug("Completed get By Date e-Way bill call for gstin: " +taxpayerGstin+" date: "+date );
	            }

	        }
        taxpayerGstinList.clear();

    }
}
