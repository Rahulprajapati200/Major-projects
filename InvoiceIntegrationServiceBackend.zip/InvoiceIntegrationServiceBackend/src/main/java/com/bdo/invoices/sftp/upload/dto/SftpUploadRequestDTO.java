package com.bdo.invoices.sftp.upload.dto;

import java.util.List;

import com.bdo.bvms.invoices.dto.BaseReqDTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SftpUploadRequestDTO extends BaseReqDTO{
	String gstinOrPan;
    String fileType;
    String templatetypepldCode;
    List<String> fp;

    String po;
    String poDate;
    String gstinOrPanList;
    int moduleID;
    String customtemplateID;
    String isCustomTemplate;
    
    String vendorGstin;
    String invoiceNo;
    String invoiceDate;
    String batchNo;
    String paBatchNo;
    String docType;
    int logId;
}
