package com.bdo.invoices.sftp.upload.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.taxpayer.sql.MasterSQL;
import com.bdo.bvms.invoices.util.EncryptionUtils;
import com.bdo.invoices.sftp.upload.dao.SftpUploadDao;
import com.bdo.invoices.sftp.upload.dto.SftpFileDetailsDto;
import com.bdo.invoices.sftp.upload.sql.SftpUploadSql;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class SftpUploadDaoImpl implements SftpUploadDao {

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Value("${mst.database-name}")
    String mstDatabseName;

    String loginId;

    @Override
    public List<SftpFileDetailsDto> getSftpFileDetails() {

        String query = SftpUploadSql.GET_PENDING_SFTP_FILES_UPLOAD_DETAILS;
        return jdbcTemplateTrn.query(query, new ResultSetExtractor<List<SftpFileDetailsDto>>() {

            List<SftpFileDetailsDto> dataList = new ArrayList<SftpFileDetailsDto>();

            @Override
            public List<SftpFileDetailsDto> extractData(ResultSet rs) throws SQLException, DataAccessException {
                while (rs.next()) {
                    SftpFileDetailsDto data = new SftpFileDetailsDto();
                    data.setId(rs.getInt("ID"));
                    data.setSftpPath(rs.getString("SFTP_PATH"));
                    data.setBatchedFileName(rs.getString("BATCHED_FILENAME"));
                    data.setPanNo(rs.getString("PANNO"));
                    data.setTemplateType(rs.getString("template_type"));
                    data.setCustomTemplateId(rs.getString("custom_templateid"));
                    data.setOriginalFileName(rs.getString("CLIENT_FILENAME"));
                    data.setUploadType(rs.getString("dc_type"));
                    data.setUserId(rs.getString("user_id"));
                    dataList.add(data);
                }
                return dataList;
            }
        });
    }

    @Override
    public int getUserId(SftpFileDetailsDto sftpFileDetailsDto) {
        String appKey = jdbcTemplateMst.queryForObject(MasterSQL.GET_APP_KEY, String.class,
                        Constants.ENCRYPTION_APP_KEY);
        String userId = sftpFileDetailsDto.getUserId();

        try {
            loginId = EncryptionUtils.encrypt(appKey, userId);
        } catch (Exception e) {
            log.error("error coming at the time of decripting login ID.");
        }

        String query = SftpUploadSql.getUserIdQuery(mstDatabseName, loginId);
        return jdbcTemplateMst.queryForObject(query, Integer.class, loginId);

    }

    @Override
    public int getEntityId(SftpFileDetailsDto sftpFileDetailsDto) {
        String query = SftpUploadSql.getModuleId(mstDatabseName);
        return jdbcTemplateMst.queryForObject(query, Integer.class, sftpFileDetailsDto.getPanNo());
    }

    @Override
    public void updateSftpPending() {
        String query = SftpUploadSql.updateQuery();
        jdbcTemplateTrn.update(query, Constants.SUCCESS, Constants.PENDING);
    }

    @Override
    public String getSftpConnectionStringFromDB() {
        String query = "select KeyVALUE from system_parameter where KeyNAME= 'sftpConnectionString'";
        return jdbcTemplateMst.queryForObject(query, String.class);
    }

    @Override
    public String getSftpContainerNameFromDB() {
        String query = "select KeyVALUE from system_parameter where KeyNAME= 'sftpContainerName'";
        return jdbcTemplateMst.queryForObject(query, String.class);
    }

	@Override
	public String getSftpUploadUrl() {
        String query = "select KeyVALUE from system_parameter where KeyNAME= 'InvoiceIntegrationDSName'";
        return jdbcTemplateMst.queryForObject(query, String.class);
    }
}
