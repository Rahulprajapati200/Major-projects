package com.bdo.invoices.sftp.upload.scheduler;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.bdo.bvms.einvoice.vendor.service.UploadNDownloadFileService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.dto.APIResponseDTO;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.invoices.sftp.upload.dao.SftpUploadDao;
import com.bdo.invoices.sftp.upload.dto.SftpFileDetailsDto;
import com.bdo.invoices.sftp.upload.service.SftpUploadService;
import com.google.common.io.Files;
import com.microsoft.azure.storage.StorageException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SftpUploadSchedularJob {

	@Autowired
	SftpUploadDao sftpUploadDao;

	@Autowired
	SftpUploadService sftpUploadService;

	@Autowired
	UploadNDownloadFileService uploadFileService;

	@Value("${temp.folder.path}")
	String tempFolder;

	//@Scheduled(fixedDelay = 2000000, initialDelay = 1000)
	public void getFileFromSftp() throws InvalidKeyException, URISyntaxException, StorageException, IOException {
		log.info("getFileFromSftp method started");
		List<SftpFileDetailsDto> fileDetails = sftpUploadDao.getSftpFileDetails();
		sftpUploadDao.updateSftpPending();
		RestTemplate restTemplate = new RestTemplate();
		
		String uploadUrl=sftpUploadDao.getSftpUploadUrl()+"/invoice/upload-file";
		for(SftpFileDetailsDto sftpFileDetailsDto :fileDetails ) {
			sftpUploadService.downloadFileFromSftpCloud(Files.getFileExtension(sftpFileDetailsDto.getBatchedFileName()),sftpFileDetailsDto.getBatchedFileName());
			MultiValueMap<String,Object> multipartRequest = new LinkedMultiValueMap<>(); 
			File originalFile=new File(tempFolder + "/" + sftpFileDetailsDto.getBatchedFileName());
			
			multipartRequest.add("file",new FileInputStream(originalFile));
			
			multipartRequest.add("userId", sftpUploadDao.getUserId(fileDetails.get(0)));
			
			multipartRequest.add("entityId", sftpUploadDao.getEntityId(sftpFileDetailsDto));
			if("0".equals(sftpFileDetailsDto.getCustomTemplateId())) 
	        {
	        if(sftpFileDetailsDto.getTemplateType().contains("E_INVOICE") ||sftpFileDetailsDto.getTemplateType().contains("EINVOICE"))
	        {
	        	multipartRequest.add("templatetypepldCode", "20");
	        	multipartRequest.add("isCustomTemplate", "0");
	        	
	        }
	        else if(sftpFileDetailsDto.getTemplateType().contains("EWAY"))
	        {
	        	multipartRequest.add("templatetypepldCode", "21");
	        	multipartRequest.add("isCustomTemplate", "0");
	        }
	        else if(sftpFileDetailsDto.getTemplateType().contains("INVOICE"))
	        {
	        	multipartRequest.add("templatetypepldCode", "332");
	        	multipartRequest.add("isCustomTemplate", "0");
	        }
	        else if(sftpFileDetailsDto.getTemplateType().contains("OCR"))
	        {
	        	multipartRequest.add("templatetypepldCode", "");
	        	multipartRequest.add("isCustomTemplate", "0");
	        }
	        }
	        else
	        {
	        	multipartRequest.add("templatetypepldCode", "");
	        	multipartRequest.add("isCustomTemplate", "1");
	        	multipartRequest.add("customtemplateID", sftpFileDetailsDto.getCustomTemplateId());
	        }
			try {
				
				
				multipartRequest.add("gstinOrPan", "0");
				multipartRequest.add("gstinOrPanList", sftpFileDetailsDto.getPanNo());
				multipartRequest.add("moduleID", Constants.MODULEIDINVOICEUPLOAD);
				multipartRequest.add("uploadSftpSource", "1");
				multipartRequest.add("sftpFileName", sftpFileDetailsDto.getBatchedFileName());
				HttpHeaders requestHeaders = new HttpHeaders();
				requestHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);//Main request's headers

				HttpHeaders requestHeadersAttachment = new HttpHeaders();
				requestHeadersAttachment.setContentType(MediaType.parseMediaType("application/vnd.ms-excel"));// extract mediatype from file extension
				HttpEntity<ByteArrayResource> attachmentPart;
				byte[] arr=new byte[(int)originalFile.length()];
				ByteArrayResource fileAsResource = new ByteArrayResource(arr){
				    @Override
				    public String getFilename(){
				        return sftpFileDetailsDto.getBatchedFileName();
				    }
				};
				
				attachmentPart = new HttpEntity<>(fileAsResource,requestHeadersAttachment);

				multipartRequest.set("file",attachmentPart);


				HttpHeaders requestHeadersJSON = new HttpHeaders();
				requestHeadersJSON.setContentType(MediaType.APPLICATION_JSON);
				UploadRequestDTO requestBody = new UploadRequestDTO();
				
				HttpEntity<UploadRequestDTO> requestEntityJSON = new HttpEntity<>(requestBody, requestHeadersJSON);

				multipartRequest.set("emp",requestEntityJSON);

				HttpEntity<MultiValueMap<String,Object>> requestEntity = new HttpEntity<>(multipartRequest,requestHeaders);//final request 

				restTemplate.exchange(uploadUrl,HttpMethod.POST,requestEntity,APIResponseDTO.class);		
			    
				
			} catch (Exception e) {
				log.error(e.getMessage());
			}

		}
	}

}
