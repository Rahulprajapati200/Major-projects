package com.bdo.bvms.urp.service.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.websocket.server.ServerEndpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdo.bvms.einvoice.service.CustomColumnService;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.UrpListDataResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.urp.dao.UrpDataListDao;
import com.bdo.bvms.urp.service.GetUrpDetailsService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class GetUrpDetailsServiceImpl implements GetUrpDetailsService {

	@Autowired
	UrpDataListDao urpDataListDao;
	
	@Autowired
    CustomColumnService customColumnService;
	
	@Override
	public Map<String, Object> getUrpDetailsDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
			String gstinNewList, String monthList) throws VendorInvoiceServerException {

        Map<String, Object> data;
        try {
            data = new LinkedHashMap<>();
            int totalCount = 0;

            data.put("ColumnData", customColumnService.getCustomGridColumns(vendorInvoiceRequestDTO));

            List<UrpListDataResDTO> dataResList = urpDataListDao
                            .getUrpDataList(vendorInvoiceRequestDTO, gstinNewList, monthList);
            data.put("Data", dataResList);

            if (!dataResList.isEmpty()) {
                totalCount = dataResList.get(0).getTotalCount();
            }
            data.put("totalPageElements", totalCount);

            data.put("status", "");

        } catch (Exception e) {
            log.error("error coming at the time of getting data of 'columnData' and 'Data' in processed Invoice tab",
                            e.getCause());
            throw new VendorInvoiceServerException(e.getMessage());
        }

        return data;

    }

}
