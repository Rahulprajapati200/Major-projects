package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OcrInvoiceDetailObjectDTO {

    int id;
    String ocrInvId;
    String pldOcrConfidenceId;
    String productCode;
    String description;
    String quantity;
    String unit;
    String unitPrice;
    String amount;
    String cgstAmt;
    String cgstP;
    String sgstAmt;
    String sgstP;
    String igstAmt;
    String igstP;
    String cessAmt;
    String cessP;
    String ugstAmt;
    String ugstP;
    String tcsAmt;
    String tcsP;
    String vatAmt;
    String vatP;
    String totalAmt;

}
