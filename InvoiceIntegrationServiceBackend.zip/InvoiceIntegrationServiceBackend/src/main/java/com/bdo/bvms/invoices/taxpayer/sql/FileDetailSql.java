package com.bdo.bvms.invoices.taxpayer.sql;

public class FileDetailSql {
	
	FileDetailSql(){
		
	}

    public static final String FILEDETAILSQUERY = "INSERT INTO filedetail"
                    + "(pan,gstin,financial_period,po_details,file_type,file_name,"
                    + "file_path,batch_no,status,uploaded_by,uploaded_on) values" + "(?,?,?,?,?,?,?,?,?,?,?)";

}
