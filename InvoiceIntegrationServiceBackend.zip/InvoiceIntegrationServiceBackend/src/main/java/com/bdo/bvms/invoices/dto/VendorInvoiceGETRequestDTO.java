package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class VendorInvoiceGETRequestDTO extends PageReqDTO {

    String taxpayerGstin;
    String ewaybillNo;
    String ewaybillDate;
    int getTypeID;
    int isGet;

}
