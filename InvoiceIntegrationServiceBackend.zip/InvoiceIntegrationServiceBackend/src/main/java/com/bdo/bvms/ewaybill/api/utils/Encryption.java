package com.bdo.bvms.ewaybill.api.utils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.json.JSONObject;
import org.springframework.util.ResourceUtils;

import com.bdo.bvms.invoices.constant.Constants;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class Encryption.
 */
@Slf4j
public class Encryption {

    /** The decrypt cipher. */
    private static Cipher decryptCipher;

    /** The keygen. */
    private static KeyGenerator keygen;
    static {
        try {

            decryptCipher = Cipher.getInstance(Constants.AES_ECB_PKC_PADDING);
            keygen = KeyGenerator.getInstance(Constants.AES);
            keygen.init(256);
        } catch (NoSuchAlgorithmException | javax.crypto.NoSuchPaddingException e) {
            log.error("Error occured while execute getBdoAuthKey function:", e);

        }
    }

    /**
     * Encrypt text with public key.
     *
     * @param msg
     *            the msg
     * @param key
     *            the key
     * @return the string
     * @throws IllegalBlockSizeException
     *             the illegal block size exception
     * @throws BadPaddingException
     *             the bad padding exception
     * @throws InvalidKeyException
     *             the invalid key exception
     * @throws NoSuchAlgorithmException
     *             the no such algorithm exception
     * @throws NoSuchPaddingException
     *             the no such padding exception
     */
    public static String encryptTextWithPublicKey(String msg, PublicKey key) throws IllegalBlockSizeException,
                    BadPaddingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException {
        Cipher cipher = Cipher.getInstance(Constants.RSA);
        cipher.init(1, key);
        return Base64.getEncoder().encodeToString(cipher.doFinal(msg.getBytes(StandardCharsets.UTF_8)));
    }

    /**
     * Gets the public.
     *
     * @param filename
     *            the filename
     * @return the public
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws NoSuchAlgorithmException
     *             the no such algorithm exception
     * @throws InvalidKeySpecException
     *             the invalid key spec exception
     */
    public static PublicKey getPublic(String filename)
                    throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
        File f = ResourceUtils.getFile(filename);
        byte[] keyBytes = Files.readAllBytes(f.toPath());
        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance(Constants.RSA);
        return kf.generatePublic(spec);
    }

    /**
     * Decrypt SEK.
     *
     * @param appkey
     *            the appkey
     * @param sek
     *            the sek
     * @return the string
     */
    public static String decryptSEK(String appkey, String sek) {
        try {
            byte[] appKeyBytes = appkey.getBytes(StandardCharsets.UTF_8);
            byte[] decryptedTextBytes = decrypt(sek, appKeyBytes);
            return Base64.getEncoder().encodeToString(decryptedTextBytes);
        } catch (Exception e) {
            log.error("error in decryptSEK method", e);
            return e.getMessage();
        }
    }

    /**
     * Decrypt response.
     *
     * @param encryptedResponseData
     *            the encrypted response data
     * @param decryptedSek
     *            the decrypted sek
     * @return the string
     */
    public static String decryptResponse(String encryptedResponseData, String decryptedSek) {
        try {
            byte[] encKeyBytes = Base64.getDecoder().decode(decryptedSek.replaceAll(" ", "+").trim());
            byte[] decryptedTextBytes = decrypt(encryptedResponseData, encKeyBytes);
            return new String(decryptedTextBytes);
        } catch (Exception e) {
            log.error("error in decryptResponse method", e);
            return e.getMessage();
        }
    }

    /**
     * Decrypt.
     *
     * @param plainText
     *            the plain text
     * @param secret
     *            the secret
     * @return the byte[]
     * @throws InvalidKeyException
     *             the invalid key exception
     * @throws IllegalBlockSizeException
     *             the illegal block size exception
     * @throws BadPaddingException
     *             the bad padding exception
     */
    public static byte[] decrypt(String plainText, byte[] secret)
                    throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        SecretKeySpec sk = new SecretKeySpec(secret, Constants.AES);
        decryptCipher.init(2, sk);
        return decryptCipher.doFinal(Base64.getDecoder().decode(plainText));
    }

    /**
     * Decrypt get api response data.
     *
     * @param encryptedResponseData
     *            the encrypted response data
     * @param decryptedSek
     *            the decrypted sek
     * @return the string
     * @throws InvalidKeyException
     *             the invalid key exception
     * @throws IllegalBlockSizeException
     *             the illegal block size exception
     * @throws BadPaddingException
     *             the bad padding exception
     */
    public static String decryptGetApiResponseData(String encryptedResponseData, String decryptedSek)
                    throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        try {
            JSONObject jsonobj = new JSONObject(encryptedResponseData);
            String resData = jsonobj.getString("data");
            String resrek = jsonobj.getString("rek");
            String decRek = decryptRek(decryptedSek, resrek);
            return decryptResponseDataRek(decRek, resData);
        } catch (Exception e) {
            log.error("error in decryptGetApiResponseData method", e);
            return e.getMessage();
        }
    }

    /**
     * Decrypt response data rek.
     *
     * @param decRek
     *            the dec rek
     * @param data
     *            the data
     * @return the string
     * @throws InvalidKeyException
     *             the invalid key exception
     * @throws IllegalBlockSizeException
     *             the illegal block size exception
     * @throws BadPaddingException
     *             the bad padding exception
     */
    public static String decryptResponseDataRek(String decRek, String data)
                    throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        byte[] encKeyBytes = Base64.getDecoder().decode(decRek.replaceAll(" ", "+").trim());
        byte[] decryptedTextBytes = decrypt(data, encKeyBytes);
        return new String(decryptedTextBytes);
    }

    /**
     * Decrypt rek.
     *
     * @param decryptedSek
     *            the decrypted sek
     * @param resRek
     *            the res rek
     * @return the string
     * @throws InvalidKeyException
     *             the invalid key exception
     * @throws IllegalBlockSizeException
     *             the illegal block size exception
     * @throws BadPaddingException
     *             the bad padding exception
     */
    public static String decryptRek(String decryptedSek, String resRek)
                    throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        byte[] encKeyBytes = Base64.getDecoder().decode(decryptedSek.replaceAll(" ", "+").trim());
        byte[] decryptedTextBytes2 = decrypt(resRek, encKeyBytes);
        return Base64.getEncoder().encodeToString(decryptedTextBytes2);
    }
    public static void main(String[] args) {   
    	
    	String data=decryptSEK("BV+UxY4GSveVk933N+ek86gQH2s2Aj7V2O6dxD+O6Co=", "eyJpdiI6IkM2bmF6T0RvMlhFVWpCcVcwQmM3Y3c9PSIsInZhbHVlIjoiWnlvWk1WT2RZRUpvcFgyendGWCtQZz09IiwibWFjIjoiNWU5NzJhYTBkZThhYzA1NDIxNDgzY2U1YTdmYTQzN2I3NTA3MWNmZDI1NDgzYjI0ZGY4NzUyNjcwYzVkNjVkZSIsInRhZyI6IiJ9");
    	
    	//String data=decryptResponse("eyJpdiI6IkM2bmF6T0RvMlhFVWpCcVcwQmM3Y3c9PSIsInZhbHVlIjoiWnlvWk1WT2RZRUpvcFgyendGWCtQZz09IiwibWFjIjoiNWU5NzJhYTBkZThhYzA1NDIxNDgzY2U1YTdmYTQzN2I3NTA3MWNmZDI1NDgzYjI0ZGY4NzUyNjcwYzVkNjVkZSIsInRhZyI6IiJ9", "BV+UxY4GSveVk933N+ek86gQH2s2Aj7V2O6dxD+O6Co=");
    	System.out.println(data);
    
    }

}
