package com.bdo.bvms.einvoice.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.VendorInvoiceRejectedDataListService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.VendorInvoiceConstants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceRejectedDataListDao;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.RejectedResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceColumnsNameResponseDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class VendorInvoiceRejectedDataListServiceImpl implements VendorInvoiceRejectedDataListService {

    @Autowired
    CommonDao commonDao;

    int id;
    @Autowired
    VendorInvoiceRejectedDataListDao vendorInvoiceRejectedDataListDao;

    @Override
    public Map<String, Object> getRejectedDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
                    String monthList) throws VendorInvoiceServerException {

        Map<String, Object> data;
        try {
            data = new LinkedHashMap<>();

            // add total count of rejected.
            data.put("totalPageElements", getRejectedTotalCount(vendorInvoiceRequestDTO, gstinNewList, monthList));
            // Here we get data of column data (columns we use to store data of
            // database) and store it into map.
            data.put("ColumnData", getRejectedColumnNames(vendorInvoiceRequestDTO));
            // Here we get rejected grid data in form of list and store
            // it
            // into map.
            data.put("Data", getRejectedDataList(vendorInvoiceRequestDTO, gstinNewList, monthList));
        } catch (Exception e) {
            log.error("error coming at the time of getting data of 'columnData' and 'Data' in Rejected  tab",
                            e.getCause());
            throw new VendorInvoiceServerException(e.getMessage());
        }

        return data;

    }

    @Override
    public int getRejectedTotalCount(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
                    String monthList) {

        return 0;
    }

    @Override
    public List<RejectedResDTO> getRejectedDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {

        return new ArrayList<>();
    }

    @Override
    public List<VendorInvoiceColumnsNameResponseDTO> getRejectedColumnNames(
                    VendorInvoiceRequestDTO vendorInvoiceRequestDTO) throws VendorInvoiceServerException {
        int idOfHeaders = 1;
        List<VendorInvoiceColumnsNameResponseDTO> vendorInvoiceColumnsList = new ArrayList<>();
        // here we add values of column data to the list of string.

        try {
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.TAXPAYER_GSTIN));
            vendorInvoiceColumnsList.add(
                            new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++, VendorInvoiceConstants.DATA_TYPE));
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.VENDOR_GSTIN));
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.VENDOR_LEGAL_NAME));
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.VENDOR_TRADE_NAME));
            vendorInvoiceColumnsList.add(
                            new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++, VendorInvoiceConstants.INVOICE_NO));
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.INVOICE_DATE));
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.EWAY_BILL_NO));
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.EWAY_BILL_DATE));
            vendorInvoiceColumnsList.add(
                            new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++, VendorInvoiceConstants.UPLOAD_DATE));
            vendorInvoiceColumnsList.add(
                            new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++, VendorInvoiceConstants.UPLOAD_BY));
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.REJECTED_DATE));
            vendorInvoiceColumnsList.add(
                            new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++, VendorInvoiceConstants.REJECTED_BY));
            vendorInvoiceColumnsList
                            .add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders, VendorInvoiceConstants.ACTION));

        } catch (Exception e) {
            log.error("Exception come at the time of getting 'columnData' in Rejected  tab.", e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
            exceptionLogDTO.setFunctionName("getRejectedColumnNames");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException(
                            "Exception come at the time of getting 'columnData' in Rejected  tab.");
        }

        return vendorInvoiceColumnsList;

    }

}
