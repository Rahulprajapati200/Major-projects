package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EinvoiceQrscanReqDTO {

    private String sellerGstin;
    private String buyerGstin;
    private String docNo;
    private String docTyp;
    private String docDt;
    private String totInvVal;
    private int itemCnt;
    private String mainHsnCode;
    private String irn;
    private String irnDt;
    private String uploadSource;
}
