package com.bdo.bvms.invoices.dao;

import java.util.List;

import com.bdo.bvms.invoices.dto.Gstr2aResponseDTO;
import com.bdo.bvms.invoices.dto.Gstr2HeaderDTOForForceSync;
import com.bdo.bvms.invoices.dto.Gstr2aSyncUnsyncDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsReqDTO;

public interface SyncOperationDataListDao {

    List<Gstr2aSyncUnsyncDTO> getUnsyncDataList(InvoiceDetailsReqDTO invoiceDetailsReqDTO, int getTypepldCode);

    List<Gstr2aSyncUnsyncDTO> getsyncData(InvoiceDetailsReqDTO invoiceDetailsReqDTO, int getTypepldCode);

    int getCountUnsyncDataList(InvoiceDetailsReqDTO invoiceDetailsReqDTO, int getTypepldCode);

    Gstr2HeaderDTOForForceSync getInvoiceHeaderDetailsForForceSync(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

}
