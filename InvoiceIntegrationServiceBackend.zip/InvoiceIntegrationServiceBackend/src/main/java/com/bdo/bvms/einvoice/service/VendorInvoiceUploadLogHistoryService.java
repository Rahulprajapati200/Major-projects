package com.bdo.bvms.einvoice.service;

import java.util.List;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.invoices.dto.UploadLogHistoryResDataDto;

public interface VendorInvoiceUploadLogHistoryService {

    List<UploadLogHistoryResDataDto> getHistoryList(UploadHistoryRequestDTO uploadHistoryRequestDTO)
                    throws VendorInvoiceServerException;

    void writeInvoiceDetailsToInvoiceHeader();

}
