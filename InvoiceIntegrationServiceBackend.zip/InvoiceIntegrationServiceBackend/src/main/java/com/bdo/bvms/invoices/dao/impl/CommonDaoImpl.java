package com.bdo.bvms.invoices.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.invoices.taxpayer.sql.MasterSQL;
import com.bdo.bvms.invoices.taxpayer.sql.TransactionSQL;
import com.bdo.bvms.ocr.SQL.FileOcrSql;
import com.microsoft.azure.storage.core.Base64;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class CommonDaoImpl.
 */
@Repository
@Slf4j
public class CommonDaoImpl implements CommonDao {

    /** The jdbc template mst. */
    @Autowired
    JdbcTemplate jdbcTemplateMst;

    /** The jdbc template trn. */
    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    /** The mst databse name. */
    @Value("${mst.database-name}")
    String mstDBName;

    /**
     * Gets the error code map.
     *
     * @return the error code map
     */
    @Override
    public HashMap<String, String> getErrorCodeMap() {
        HashMap<String, String> mapRet = new HashMap<>();
        jdbcTemplateMst.query(MasterSQL.GET_ERRORCODE_AND_SHORTDESCRIPTION,
                        new ResultSetExtractor<Map<String, String>>() {

                            @Override
                            public Map<String, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                while (rs.next()) {
                                    mapRet.put(rs.getString(Constants.ERRORCODE),
                                                    rs.getString(Constants.SHORTDESCRIPTION));
                                }
                                return mapRet;
                            }
                        });
        return mapRet;

    }

    /**
     * Gets the description from DB.
     *
     * @param mapRet
     *            the map ret
     * @param data
     *            the data
     * @return the description from DB
     */
    @Override
    public String getDescriptionFromDB(HashMap<String, String> mapRet, EInvoiceTemplateDTO data) {
        String discription = Constants.BLANK;

        String code = data.getErrorCodeList().toString().replace(Constants.PIPESEPERATOR, Constants.COMMASEPERATOR);
        String[] errorCodeList = code.split(Constants.COMMASEPERATOR);
        if (errorCodeList.length > 1) {
            for (int i = 1; i < errorCodeList.length; i++) {
                String singleDis = mapRet.get(errorCodeList[i]);
                discription = Constants.BLANK + Constants.PIPESEPERATOR + singleDis;
            }
        }
        return discription;
    }

    /**
     * Update exception log table.
     *
     * @param exceptionLogDTO
     *            the exception log DTO
     */
    @Override
    public void updateExceptionLogTable(ExceptionLogDTO exceptionLogDTO) {
        jdbcTemplateTrn.update(TransactionSQL.INSERT_EXCEPTION_LOG, exceptionLogDTO.getScreenName(),
                        exceptionLogDTO.getFunctionName(), exceptionLogDTO.getErrorMessage(),
                        exceptionLogDTO.getErrorCause(), exceptionLogDTO.getLineNo(), exceptionLogDTO.getUserId(),
                        exceptionLogDTO.getCreatedAt(), exceptionLogDTO.getRequestedAt(),
                        exceptionLogDTO.getRequestedBy());
    }

    /**
     * Gets the gstin from DB.
     *
     * @param pan
     *            the pan
     * @param dbName
     *            the db name
     * @return the gstin from DB
     */
    @Override
    public String[] getGstinFromDB(String pan, String dbName) {

        return jdbcTemplateTrn.queryForList(MasterSQL.getTaxpayerGstinFromDbSql(dbName), String.class,
                        Base64.encode(pan.getBytes())).toArray(new String[0]);

    }

    /**
     * Gets the months from DB.
     *
     * @param yearId
     *            the year id
     * @return the months from DB
     */
    @Override
    public String[] getMonthsFromDB(String yearId) {

        return jdbcTemplateMst.queryForList(MasterSQL.getMonthFromDbSql(mstDBName), String.class, yearId)
                        .toArray(new String[0]);

    }

    /**
     * Gets the azure credential from DB.
     *
     * @param entityId
     *            the entity id
     * @param blob
     *            the blob
     * @return the azure credential from DB
     */
    @Override
    public AzureConnectionCredentialsDTO getAzureCredentialFromDB(int entityId, String blob) {

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

//        return jdbcTemplateMst.queryForObject(MasterSQL.GET_AZURE_CREDENTIAL_FROM_DB,
//                        new BeanPropertyRowMapper<AzureConnectionCredentialsDTO>(AzureConnectionCredentialsDTO.class),
//                        entityId, blob);

        Map<String, Object> results = jdbcTemplateMst.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall(MasterSQL.GET_AZURE_CREDENTIAL_FROM_DB_PROC_CALL);
                cs.setInt(1, entityId);
                return cs;
            }
        }, parameters);

        List<Map<String, Object>> resultset = (List<Map<String, Object>>) results.get("#result-set-1");
        if (resultset.isEmpty()) {
            return null;
        }

        AzureConnectionCredentialsDTO azureCred = new AzureConnectionCredentialsDTO();
        azureCred.setUrl(String.valueOf(resultset.get(0).get("url")));
        azureCred.setContainerName(String.valueOf(resultset.get(0).get("container_name")));

        return azureCred;

    }

    /**
     * Check invoice already saved.
     *
     * @param gstinOfSupplier
     *            the gstin of supplier
     * @param inwardNo
     *            the inward no
     * @param inwardDate
     *            the inward date
     * @param fp
     *            the fp
     * @param pFyCheck
     *            the fy check
     * @param yearId
     *            the year id
     * @return the integer
     */
    @Override
    public Integer checkInvoiceAlreadySaved(String gstinOfSupplier, String inwardNo, String inwardDate, String fp,
                    String pFyCheck, String yearId) {
        try {

            String sqlstr = "";
            if ("0".equals(pFyCheck)) {

                sqlstr = "select count(1) from invoice_eway_bill_details where gstin_of_supplier = '" + gstinOfSupplier
                                + "' and filling_period! = '" + fp + "' " + "and  inward_no = '" + inwardNo + "'";
            } else {
                sqlstr = " select count(1) from invoice_eway_bill_details where gstin_of_supplier = '" + gstinOfSupplier
                                + "' and filling_period in (select fp FROM " + mstDBName
                                + ".sm_return_periods where year_id != '" + yearId + "')  and inward_no = '" + inwardNo
                                + "'" + " AND inward_date=" + "'" + inwardDate + "'";
            }

            return jdbcTemplateTrn.queryForObject(sqlstr, Integer.class);

        } catch (Exception ex) {
            log.error("Error occured while execute checkInvoiceAlreadySaved function:", ex);
            return 0;
        }
    }

    /**
     * Gets the batch data uploaded in previous FP.
     *
     * @param gstinOfSupplier
     *            the gstin of supplier
     * @param fp
     *            the fp
     * @param yearId
     *            the year id
     * @return the batch data uploaded in previous FP
     */
    @Override
    public List<String> getBatchDataUploadedInPreviousFP(String gstinOfSupplier, String fp, String yearId) {
        return jdbcTemplateTrn.queryForList(MasterSQL.getBatchUploadInPrevFp(mstDBName), String.class, gstinOfSupplier,
                        yearId);

    }

    /**
     * Gets the grid data for sync pending.
     *
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @param gstinNewList
     *            the gstin new list
     * @param monthList
     *            the month list
     * @return the grid data for sync pending
     */
    @Override
    public Map<String, Object> getGridDataForSyncPending(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList, String whereCon) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall("{call vendor_invoice_tab_sync_pending(?,?,?,?,?,?,?,?,?)}");
                cs.setString(1, gstinNewList);
                cs.setString(2, monthList);
                cs.setInt(3, vendorInvoiceRequestDTO.getPeriodTypeCD());
                cs.setString(4, whereCon);
                cs.setInt(5, vendorInvoiceRequestDTO.getUserId());
                cs.setString(6, mstDBName);
                cs.setString(7, vendorInvoiceRequestDTO.getSortFilter());
                cs.setInt(8, vendorInvoiceRequestDTO.getSize());
                cs.setInt(9, vendorInvoiceRequestDTO.getPage() * vendorInvoiceRequestDTO.getSize());

                return cs;
            }
        }, parameters);
    }

    /**
     * Gets the grid data for approval pending.
     *
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @param gstinNewList
     *            the gstin new list
     * @param monthList
     *            the month list
     * @return the grid data for approval pending
     */
    @Override
    public Map<String, Object> getGridDataForApprovalPending(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList, String whereCon) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con
                                .prepareCall("{call vendor_upload_approval_pending_rejected(?,?,?,?,?,?,?,?,?,?,?)}");
                cs.setString(1, vendorInvoiceRequestDTO.getGstinOrPan());

                cs.setString(2, gstinNewList);
                cs.setString(3, monthList);
                cs.setInt(4, vendorInvoiceRequestDTO.getPeriodTypeCD());
                cs.setInt(5, vendorInvoiceRequestDTO.getUserId());
                cs.setString(6, "4".equals(vendorInvoiceRequestDTO.getTabId()) ? "11" : "33");
                cs.setString(7, mstDBName);
                cs.setString(8, whereCon);
                cs.setString(9, vendorInvoiceRequestDTO.getSortFilter());
                cs.setInt(10, 10);
                cs.setInt(11, vendorInvoiceRequestDTO.getSize() * vendorInvoiceRequestDTO.getPage());

                return cs;
            }
        }, parameters);
    }

    /**
     * Gets the grid data pending for user input.
     *
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @param gstinNewList
     *            the gstin new list
     * @param monthList
     *            the month list
     * @return the grid data pending for user input
     */
    @Override
    public Map<String, Object> getGridDataPendingForUserInput(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList, String whereCon) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con
                                .prepareCall("{call vendor_invoice_tab_pending_for_user_input(?,?,?,?,?,?,?,?,?)}");
                cs.setString(1, gstinNewList);
                cs.setString(2, monthList);
                cs.setInt(3, vendorInvoiceRequestDTO.getPeriodTypeCD());
                cs.setString(4, whereCon);
                cs.setInt(5, vendorInvoiceRequestDTO.getUserId());
                cs.setString(6, vendorInvoiceRequestDTO.getSortFilter());
                cs.setString(7, mstDBName);
                cs.setInt(8, vendorInvoiceRequestDTO.getSize());
                cs.setInt(9, vendorInvoiceRequestDTO.getPage() * vendorInvoiceRequestDTO.getSize());

                return cs;
            }
        }, parameters);
    }

    /**
     * Gets the year id from fp.
     *
     * @param fillingPeriod
     *            the filling period
     * @return the year id from fp
     */
    @Override
    public int getYearIdFromFp(String fillingPeriod) {
        String sql = "select return_period_id from sm_return_periods where fp=?";
        return jdbcTemplateMst.update(sql, fillingPeriod);

    }

    /**
     * Gets the grid data processed invoice.
     *
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @param gstinNewList
     *            the gstin new list
     * @param monthList
     *            the month list
     * @return the grid data processed invoice
     */
    @Override
    public Map<String, Object> getGridDataProcessedInvoice(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList, String whereCon) {

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));
        if ("".equals(vendorInvoiceRequestDTO.getActionKey())) {
            vendorInvoiceRequestDTO.setActionKey("0");
        }
        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con
                                .prepareCall("{call vendor_invoice_tab_processed_invoice(?,?,?,?,?,?,?,?,?,?,?,?)}");
                cs.setString(1, gstinNewList);
                cs.setString(2, monthList);
                cs.setInt(3, vendorInvoiceRequestDTO.getPeriodTypeCD());
                cs.setInt(4, vendorInvoiceRequestDTO.getBookedStatus());
                cs.setInt(5, vendorInvoiceRequestDTO.getIsActionCenter());
                cs.setString(6, vendorInvoiceRequestDTO.getActionKey());
                cs.setString(7, whereCon);
                cs.setInt(8, vendorInvoiceRequestDTO.getUserId());
                cs.setString(9, mstDBName);
                cs.setString(10, vendorInvoiceRequestDTO.getSortFilter());
                cs.setInt(11, vendorInvoiceRequestDTO.getSize());
                cs.setInt(12, vendorInvoiceRequestDTO.getPage() * vendorInvoiceRequestDTO.getSize());

                return cs;
            }
        }, parameters);
    }

    /**
     * Gets the grid data by procedure.
     *
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @param gstinNewList
     *            the gstin new list
     * @param monthList
     *            the month list
     * @return the grid data by procedure
     */
    @Override
    public Map<String, Object> getGridDataByProcedure(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) {

        return new HashMap<>();
    }

    /**
     * Gets the year id.
     *
     * @return the year id
     */
    @Override
    public HashMap<String, String> getYearId() {
        HashMap<String, String> mapRet = new HashMap<>();
        jdbcTemplateMst.query(MasterSQL.YEARIDQUERY, new ResultSetExtractor<Map<String, String>>() {

            @Override
            public Map<String, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
                while (rs.next()) {
                    mapRet.put(rs.getString(Constants.FP), rs.getString(Constants.YEAR_ID));
                }
                return mapRet;
            }
        });
        return mapRet;

    }

    @Override
    public Map<String, String> getSchreeAliasMap(VendorInvoiceRequestDTO vendorInvoiceRequestDTO) {

        HashMap<String, String> alishMap = new HashMap<>();
        jdbcTemplateMst.query(MasterSQL.GETALIASHQUERY, new ResultSetExtractor<Map<String, String>>() {

            @Override
            public Map<String, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
                while (rs.next()) {
                    alishMap.put(rs.getString(Constants.COLUMN_SCREEN_NAME),
                                    rs.getString(Constants.ADVANCE_SEARCH_COLUMN_NAME));
                }
                return alishMap;
            }

        }, Constants.MODULEIDINVOICEUPLOAD, vendorInvoiceRequestDTO.getTabId());
        return alishMap;
    }

    /**
     * Gets the grid data for ocr details.
     *
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @param gstinNewList
     *            the gstin new list
     * @param monthList
     *            the month list
     * @return the grid data for ocr details
     */
    @Override
    public Map<String, Object> getGridDataForOcrDetails(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList,String monthList,String whereCond) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall(FileOcrSql.GET_OCR_DATA_PROC);
                cs.setString(1, gstinNewList);
                cs.setString(2, vendorInvoiceRequestDTO.getOcrSubTab());
                cs.setInt(3, vendorInvoiceRequestDTO.getUserId());
                cs.setString(4, monthList);
                cs.setString(5, mstDBName);
                cs.setString(6, Constants.TAXPAYER_OCR_SCREEN_NAME);
                cs.setInt(7, vendorInvoiceRequestDTO.getSize());
                cs.setInt(8, vendorInvoiceRequestDTO.getPage() * vendorInvoiceRequestDTO.getSize());
                cs.setString(9, whereCond);
                
               
                return cs;
            }
        }, parameters);
    }
    
    
    @Override
    public String getSystemParameterCredential(String keyName) {
        return jdbcTemplateMst.queryForObject(MasterSQL.GET_SYSTEM_PARAMETER_CREDENTIAL,String.class,keyName);
    }

	@Override
	public Map<String, Object> getGridDataUrp(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
			String monthList, String whereCondition) {

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));
        if ("".equals(vendorInvoiceRequestDTO.getActionKey())) {
            vendorInvoiceRequestDTO.setActionKey("0");
        }
        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con
                                .prepareCall("{call vendor_invoice_urp_ocr_details(?,?,?,?,?,?,?,?,?,?)}");
                cs.setString(1, gstinNewList);
                cs.setInt(2, vendorInvoiceRequestDTO.getBookedStatus());
                cs.setInt(3, vendorInvoiceRequestDTO.getUserId());
                cs.setString(4, monthList);
                cs.setString(5, mstDBName);
                cs.setString(6, Constants.URP_SCREEN_NAME);
                cs.setString(7, vendorInvoiceRequestDTO.getSortFilter());
                cs.setInt(8, 50);
                cs.setInt(9, vendorInvoiceRequestDTO.getPage() * vendorInvoiceRequestDTO.getSize());
                cs.setString(10,whereCondition); 
               
                return cs;
            }
        }, parameters);
    }

	
	@Override
	public String getEntityId(String gstin) {
		
		 String sql = "select entity_id from am_entity_master where from_base64(gstin)=?";
		 try {
	     return jdbcTemplateMst.queryForObject(sql,String.class, gstin);
		 } catch (Exception e) {
			return "0";
		}
	}

}

