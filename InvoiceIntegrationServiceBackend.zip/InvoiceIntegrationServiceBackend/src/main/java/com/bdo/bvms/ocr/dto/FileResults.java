package com.bdo.bvms.ocr.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class FileResults {

	@JsonProperty("FileName")
	String fileName;
	
	@JsonProperty("FileUID")
	String fileUid;
	
	@JsonProperty("HeaderItem")
	HeaderItem headerItem;
	
	@JsonProperty("LineItems")
	List<LineItems> lineItems;
	
	@JsonProperty("FileConfidenceScore")
	FileConfidenceScore fileConfidenceScore;
}
