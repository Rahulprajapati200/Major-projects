package com.bdo.bvms.einvoice.service.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.VendorInvoiceProcessedDataListService;
import com.bdo.bvms.einvoice.service.VendorJourneyDataListService;
import com.bdo.bvms.envoices.service.VendorDataListService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.VendorInvoiceConstants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.vendor.ocr.service.VendorJourneyGetOcrDetailsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class VendorDataListServiceImpl implements VendorDataListService {

    @Autowired
    CommonDao commonDao;

    String gstinList;
    String fpList;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Autowired
    VendorJourneyDataListService vendorJourneyDataListService;

    @Autowired
    VendorInvoiceProcessedDataListService vendorInvoiceProcessedDataListService;
    
    @Autowired
    VendorJourneyGetOcrDetailsService getOcrDetailsService;
    
    @Autowired
    private MessageSource messageSource;

    @Override
    public Map<String, Object> getDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO)
                    throws VendorInvoiceServerException {

        String gstinNewList = getGstinList(vendorInvoiceRequestDTO);

        String monthList = getMonthList(vendorInvoiceRequestDTO);
        if (StringUtils.isNotBlank(vendorInvoiceRequestDTO.getSortFilter()) && vendorInvoiceRequestDTO.getSortFilter().contains("date")) {
			String[] aliasCondition = vendorInvoiceRequestDTO.getSortFilter().split(" ");
			StringBuilder sortFilterString = new StringBuilder();
			sortFilterString.append("str_to_date(").append(aliasCondition[0] + ",").append('"')
					.append("%d-%m-%Y").append('"').append(") ").append(aliasCondition[1]);
			vendorInvoiceRequestDTO.setSortFilter(sortFilterString.toString());
		}
        
        if (VendorInvoiceConstants.TOTAL_DOCUMENTS.equals(vendorInvoiceRequestDTO.getTabId())) {

            try {
				
                return vendorJourneyDataListService.gettotalDocumentsDataGrid(vendorInvoiceRequestDTO, gstinNewList,
                                monthList);
            } catch (Exception e) {
                log.error("Error in getDataGrid method", e);
                throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                        LocaleContextHolder.getLocale()));
            }

        } else if (VendorInvoiceConstants.DRAFT_DOCUMENTS.equals(vendorInvoiceRequestDTO.getTabId())) {

            try {

                return vendorJourneyDataListService.getdraftDocumentsDataGrid(vendorInvoiceRequestDTO, gstinNewList,
                                monthList);
            } catch (Exception e) {
                log.error("Error in getDataGrid method", e);
                throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                        LocaleContextHolder.getLocale()));
            }

        } else if (VendorInvoiceConstants.SUBMITTED_PENDING_APPROVAL_DOCUMENTS
                        .equals(vendorInvoiceRequestDTO.getTabId())) {

            try {
                vendorInvoiceRequestDTO.setTabId("11");
                return vendorJourneyDataListService.getsubmittedPendingApprovalDocumentsDataGrid(
                                vendorInvoiceRequestDTO, gstinNewList, monthList);
            } catch (Exception e) {
                log.error("Error in getDataGrid method", e);
                throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                        LocaleContextHolder.getLocale()));
            }

        } else if (VendorInvoiceConstants.APPROVED_DOCUMENTS.equals(vendorInvoiceRequestDTO.getTabId())) {

            try {
            	
                vendorInvoiceRequestDTO.setTabId("22");
                return vendorJourneyDataListService.getapprovedDocumentsDataGrid(vendorInvoiceRequestDTO, gstinNewList,
                                monthList);
            } catch (Exception e) {
                log.error("Error in getDataGrid method", e);
                throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                        LocaleContextHolder.getLocale()));
            }

        } else if (VendorInvoiceConstants.REJECTED_DOCUMENTS.equals(vendorInvoiceRequestDTO.getTabId())) {

            try {
                vendorInvoiceRequestDTO.setTabId("33");
                return vendorJourneyDataListService.getrejectedDocumentsDataGrid(vendorInvoiceRequestDTO, gstinNewList,
                                monthList);
            } catch (Exception e) {
                log.error("Error in getDataGrid method", e);
                throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                        LocaleContextHolder.getLocale()));
            }

        }
        else if (VendorInvoiceConstants.OCR_TAB.equals(vendorInvoiceRequestDTO.getTabId())) {

            return getOcrDetailsService.getOcrDetailsDataGrid(vendorInvoiceRequestDTO,
                    gstinNewList, monthList);

        }

        return new HashMap<>();
    }

    public String getMonthList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO) {

        if (Constants.FPYEAR.equals(vendorInvoiceRequestDTO.getYearOrMonth())) {

            // here we get all month into a string array according to single
            // year
            // from database.
            String[] monthArray = commonDao.getMonthsFromDB(vendorInvoiceRequestDTO.getYearOrMonthList().get(0));
            // here we convert months string array into the string.
            fpList = Arrays.toString(monthArray);

        } else if (Constants.FPMONTH.equals(vendorInvoiceRequestDTO.getYearOrMonth())) {
            // here we get month list from request body and convert it into
            // string
            fpList = vendorInvoiceRequestDTO.getYearOrMonthList().toString();
        }
        return fpList.replace("[", "").replace("]", "").replace("{", "").replace("}", "").replace(" ", "");

    }

    private String getGstinList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO) {
        if (Constants.PAN.equals(vendorInvoiceRequestDTO.getGstinOrPan())) {

            // here we get all GSTIN into a string array according to single pan
            // from database.
            String[] gstinArray = commonDao.getGstinFromDB(vendorInvoiceRequestDTO.getGstinOrPanList().get(0),
                            mstDatabseName);
            // here we convert GSTIN string array into the string.
            gstinList = Arrays.toString(gstinArray);

        } else if (Constants.GSTIN.equals(vendorInvoiceRequestDTO.getGstinOrPan())) {
            // here we get GSTIN list from request body and convert it into
            // string
            gstinList = vendorInvoiceRequestDTO.getGstinOrPanList().toString();
        }
        return gstinList.replace("[", "").replace("]", "").replace("{", "").replace("}", "").replace(" ", "");

    }

    private String getPanOrGstinList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO) {
        if (Constants.PAN.equals(vendorInvoiceRequestDTO.getGstinOrPan())) {

            // here we get all GSTIN into a string array according to single pan
            // from database.

            // here we convert GSTIN string array into the string.
            gstinList = vendorInvoiceRequestDTO.getGstinOrPanList().toString();

        } else if (Constants.GSTIN.equals(vendorInvoiceRequestDTO.getGstinOrPan())) {
            // here we get GSTIN list from request body and convert it into
            // string
            gstinList = vendorInvoiceRequestDTO.getGstinOrPanList().toString();
        }
        return gstinList.replace("[", "").replace("]", "").replace("{", "").replace("}", "").replace(" ", "");

    }

    @Override
    public Map<String, Object> getProcessedInvoiceDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO)
                    throws VendorInvoiceServerException {

        String gstinNewList = getGstinList(vendorInvoiceRequestDTO);

        String monthList = getMonthList(vendorInvoiceRequestDTO);
        if (StringUtils.isNotBlank(vendorInvoiceRequestDTO.getSortFilter()) && vendorInvoiceRequestDTO.getSortFilter().contains("date")) {
			String[] aliasCondition = vendorInvoiceRequestDTO.getSortFilter().split(" ");
			StringBuilder sortFilterString = new StringBuilder();
			sortFilterString.append("str_to_date(").append(aliasCondition[0] + ",").append('"')
					.append("%d-%m-%Y").append('"').append(") ").append(aliasCondition[1]);
			vendorInvoiceRequestDTO.setSortFilter(sortFilterString.toString());
		}
        try {

            return vendorJourneyDataListService.getProcessedDataGrid(vendorInvoiceRequestDTO, gstinNewList, monthList);
        } catch (VendorInvoiceServerException e) {
            log.error("Error in getProcessedInvoiceDataList method", e);
            throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                    LocaleContextHolder.getLocale()));
        }

    }

}
