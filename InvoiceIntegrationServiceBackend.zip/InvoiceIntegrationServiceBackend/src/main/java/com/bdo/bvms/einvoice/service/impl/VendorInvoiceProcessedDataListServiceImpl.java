package com.bdo.bvms.einvoice.service.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.CustomColumnService;
import com.bdo.bvms.einvoice.service.VendorInvoiceProcessedDataListService;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceProcessedDataListDao;
import com.bdo.bvms.invoices.dto.ProcessedListDataResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class VendorInvoiceProcessedDataListServiceImpl implements VendorInvoiceProcessedDataListService {

    @Autowired
    CommonDao commonDao;

    @Autowired
    CustomColumnService customColumnService;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Value("${mst.database-name}")
    String mstDatabseName;

    int id = 0;
    int idOfHeaders = 1;
    @Autowired
    VendorInvoiceProcessedDataListDao vendorInvoiceProcessedDataListDao;

    @Override
    public Map<String, Object> getProcessedDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {

        Map<String, Object> data;
        try {
            data = new LinkedHashMap<>();
            int totalCount = 0;

            data.put("ColumnData", customColumnService.getCustomGridColumns(vendorInvoiceRequestDTO));

            List<ProcessedListDataResDTO> dataResList = vendorInvoiceProcessedDataListDao
                            .getProcessedInvoiceDataList(vendorInvoiceRequestDTO, gstinNewList, monthList);
            data.put("Data", dataResList);

            if (!dataResList.isEmpty()) {
                totalCount = dataResList.get(0).getTotalCount();
            }
            data.put("totalPageElements", totalCount);

            data.put("status", "");

        } catch (Exception e) {
            log.error("error coming at the time of getting data of 'columnData' and 'Data' in processed Invoice tab",
                            e.getCause());
            throw new VendorInvoiceServerException(e.getMessage());
        }

        return data;

    }

}
