package com.bdo.bvms.invoices.constant;

public class VendorInvoiceConstants {

    VendorInvoiceConstants() {

    }

    public static final String TAXPAYER_GSTIN = "taxpayerGstin";
    public static final String DATA_TYPE = "dataType";
    public static final String VENDOR_GSTIN = "vendorGstin";
    public static final String VENDOR_LEGAL_NAME = "vendorLegalName";
    public static final String VENDOR_TRADE_NAME = "vendorTradeName";
    public static final String INVOICE_NO = "invoiceNo";
    public static final String INVOICE_DATE = "invoiceDate";
    public static final String EWAY_BILL_NO = "ewayBillNo";
    public static final String EWAY_BILL_DATE = "ewayBillDate";
    public static final String PO_NUMBER = "poNumber";
    public static final String GRN_NUMBER = "grnNumber";
    public static final String UPLOAD_DATE = "uploadDate";
    public static final String ACTION = "action";
    public static final String SYNC_WITH_GSTR_2A = "syncWithGstr2a";
    public static final String SYNC_WITH_GSTR_2B = "syncWithGstr2b";
    public static final String SYNC_WITH_EWAY_BILL = "syncWithEWayBill";
    public static final String TAXABLE_VALUE = "taxableValue";
    public static final String IGST = "igst";
    public static final String CGST = "cgst";
    public static final String SGST = "sgst";
    public static final String CESS = "cess";
    public static final String INVOICE_VALUE = "invoiceValue";
    public static final String QR_CODE_VALID = "qrCodeValid";
    public static final String TOTAL_PO = "totalPo";
    public static final String DETAILS_UPLOAD_DATE = "detailsUploadDate";
    public static final String LAST_SYNC_DATE = "lastSyncDate";
    public static final String BOOKED_IN_ERP = "bookedInErp";
    public static final String UPLOAD_BY = "uploadBy";
    public static final String REJECTED_DATE = "rejectedDate";
    public static final String REJECTED_BY = "rejectedBy";
    public static final String PROCESSED_INVOICE = "1";
    public static final String PENDING_FOR_USER_INPUT = "2";
    public static final String APPROVAL_PENDING = "4";
    public static final String REJECTED = "5";
    public static final String SYNC_PENDING = "3";
    public static final String VENDOR_INVOICE_TEMPLATE_NAME = "VendorInvoice.xlsx";
    public static final String TOTAL_DOCUMENTS = "1";
    public static final String DRAFT_DOCUMENTS = "2";
    public static final String SUBMITTED_PENDING_APPROVAL_DOCUMENTS = "3";
    public static final String APPROVED_DOCUMENTS = "4";
    public static final String REJECTED_DOCUMENTS = "5";

    public static final String APPROVAL_PENDING_TAB = "11";
    public static final String REJECTED_TAB = "33";
    public static final String INVITETRACKINGMODULEID = "165";
    public static final String VENDOR_INVOICE_PLD_MODULE_ID = "65";
    public static final String VENDOR_INVOICE_PLD_WF_TYPE_ID = "159";
    public static final String OCR_TAB = "6";
    
    public static final String RESPONSE_DATA_OBJECT = "ResponceDataObject";
    public static final String FILE_RESULTS = "FileResults";
    public static final String HEADER_ITEM = "HeaderItem";
    public static final String LINE_ITEMS = "LineItems";
    public static final String FILE_CONFIDENCE_SCORE = "FileConfidenceScore";
    public static final String OCR_NOT_STARTED_PLD = "248";
    public static final String OCR_STOPPED_PLD = "251";
    public static final String OCR_REJECTED_PLD = "317";
    public static final String PLD_OCR_STATUS_IN_PROGRESS = "249";
    public static final String PLD_OCR_STATUS_IN_REVIEW = "250";
    public static final String OCR_PULL_STATUS_PENDING = "Pending";
    public static final Integer OCR_MST_ID_NO_OF_LINE_ITEM = 58;
    public static final Integer OCR_MST_ID_SERIAL_NO = 32;
    public static final Integer OCR_MST_ID_POS = 164;
    public static final String STATE_NAME = "State Name";
	public static final String URP_TAB = "7";
}
