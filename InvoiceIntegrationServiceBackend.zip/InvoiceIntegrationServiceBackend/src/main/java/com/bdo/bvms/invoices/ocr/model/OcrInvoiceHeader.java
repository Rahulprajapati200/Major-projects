package com.bdo.bvms.invoices.ocr.model;

import java.util.Date;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class OcrInvoiceHeader {

    Integer id;
    Integer pldOcrConfidenceId;
    String customerName;
    String customerGstin;
    String customerAddress;
    String supplierName;
    String supplierGstin;
    String supplierAddress;
    Integer vendorCode;
    String invoiceNo;
    String poNumber;
    Double cgstAmt;
    Double cgstP;
    Double sgstAmt;
    Double sgstP;
    Double igstAmt;
    Double igstP;
    Double cessAmt;
    Double cessP;
    Double ugstAmt;
    Double ugstP;
    Double tcsAmt;
    Double tcsP;
    Double vatAmt;
    Double vatP;
    Double totalAmt;
    Date invoiceDate;
    String fileName;
    String docType;
    String batchNo;
    int isTaxpayer;
    String fp;
    String fileType;
    int pldOcrStatus;
}
