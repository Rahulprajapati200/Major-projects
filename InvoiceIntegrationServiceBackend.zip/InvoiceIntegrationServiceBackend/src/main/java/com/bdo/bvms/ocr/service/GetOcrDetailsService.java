package com.bdo.bvms.ocr.service;

import java.util.List;
import java.util.Map;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.ocr.dto.OcrResponseDto;

public interface GetOcrDetailsService {


	Map<String, Object> getOcrDetailsDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
			String monthList) throws VendorInvoiceServerException;

}
