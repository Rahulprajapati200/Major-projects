package com.bdo.bvms.einvoice.service;

import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceSavedataOnUploadException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;

/**
 * The Interface UploadLogService.
 */
public interface UploadLogService {

    /**
     * Save in upload log.
     *
     * @param apiRequestDTO the api request DTO
     * @param batchNo the batch no
     * @throws VendorInvoiceServerException the invoice integration server exception
     * @throws VendorInvoiceSavedataOnUploadException 
     */
      void saveInUploadLog(MultipartFile childFile, UploadRequestDTO uploadRequestDTO, String batchNo)
			throws VendorInvoiceServerException, VendorInvoiceSavedataOnUploadException;


    /**
     * Save in upload stage log.
     *
     * @param apiRequestDTO the api request DTO
     * @param uploadReqDTO the upload req DTO
     */
    void saveInUploadStageLog(UploadRequestDTO apiRequestDTO, UploadReqDTO uploadReqDTO);

    /**
     * Gets the upload log id.
     *
     * @param batchNo the batch no
     * @return the upload log id
     * @throws VendorInvoiceServerException the invoice integration server exception
     */
    int getUploadLogId(String batchNo) throws VendorInvoiceServerException;

	}
