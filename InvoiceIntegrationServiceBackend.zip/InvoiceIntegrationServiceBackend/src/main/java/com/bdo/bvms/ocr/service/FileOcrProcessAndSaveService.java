package com.bdo.bvms.ocr.service;

import java.sql.BatchUpdateException;
import java.util.List;
import java.util.Map;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.ocr.dto.FileResults;
import com.bdo.bvms.ocr.dto.OcrBatchResponseReqDto;
import com.bdo.bvms.ocr.dto.OcrTriggerRequestDto;

public interface FileOcrProcessAndSaveService {

	void saveOCRDataResponseToDb(Map<String, Object> responceDataObject, Integer fileId)
			throws VendorInvoiceServerException, BatchUpdateException;

	Map<String, Object> getOcrComplianceIssue(Integer fileId) throws VendorInvoiceServerException;

	void ocrUploadTrigger(OcrTriggerRequestDto ocrTriggerRequestDto) throws VendorInvoiceServerException;
}
