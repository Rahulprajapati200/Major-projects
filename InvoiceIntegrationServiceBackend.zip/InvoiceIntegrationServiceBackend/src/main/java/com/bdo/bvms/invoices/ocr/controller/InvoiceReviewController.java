package com.bdo.bvms.invoices.ocr.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.ParseException;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.bvms.invoices.constant.InvoiceOcrReviewConstant;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.custom.exception.VendorMasterBusinessException;
import com.bdo.bvms.invoices.dto.APIResponseDTO;
import com.bdo.bvms.invoices.ocr.dao.OcrInvoiceReviewRequestDTO;
import com.bdo.bvms.invoices.ocr.dao.OcrStatusUpdateRequestDto;
import com.bdo.bvms.invoices.ocr.model.OcrVerticalMap;
import com.bdo.bvms.invoices.ocr.service.IInvoiceReviewService;
import com.bdo.bvms.ocr.dto.OcrComplianceReqDto;
import com.bdo.bvms.ocr.dto.OcrTriggerRequestDto;
import com.bdo.bvms.ocr.dto.VendorCodeAutoTagReqDto;
import com.bdo.bvms.ocr.service.FileOcrProcessAndSaveService;

@RestController
@RequestMapping("/invoice")
@Validated
public class InvoiceReviewController {

    /** The vendor master service impl. */
    @Autowired
    private IInvoiceReviewService invoiceReviewServiceImpl;
    
    @Autowired
    FileOcrProcessAndSaveService fileOcrProcessAndSaveService;

    
    @PostMapping(value = "/ocrInvoiceReview")
    public ResponseEntity<APIResponseDTO> searchOcrDetails(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid OcrInvoiceReviewRequestDTO ocrInvoiceReviewRequestDTO)
                    throws VendorMasterBusinessException {
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(invoiceReviewServiceImpl.ocrInvoiceReview(ocrInvoiceReviewRequestDTO))
                        .message(null).tag(httpServletRequest.getRequestURI()).build());
    }
    
    
    @PostMapping(value = "/reviewInvoiceFile")
    public ResponseEntity<Resource> reviewInvoiceFile(HttpServletRequest httpServletRequest,
                    @RequestBody @Valid OcrInvoiceReviewRequestDTO ocrInvoiceReviewRequestDTO)
                    throws VendorMasterBusinessException, IOException {

        File file = invoiceReviewServiceImpl.reviewInvoiceFile(ocrInvoiceReviewRequestDTO);
        Long length = file.length();
        String fileName = file.getName();
        ByteArrayResource resource = null;

        resource = new ByteArrayResource(Files.readAllBytes(file.toPath()));

        Files.deleteIfExists(file.toPath());

        HttpHeaders headers = new HttpHeaders();
        headers.add(InvoiceOcrReviewConstant.HEADERS_FILENAME, fileName);
        headers.add(InvoiceOcrReviewConstant.ACCESS_CONTROL_EXPOSE_HEADERS, InvoiceOcrReviewConstant.HEADERS_FILENAME); // header
        return ResponseEntity.ok().headers(headers).contentLength(length)
                        .contentType(MediaType.APPLICATION_OCTET_STREAM).body(resource);
    }
    
    @PostMapping(value = "/updateOCRInvoiceDetails")
    public ResponseEntity<APIResponseDTO> updateOCRInvoiceDetails(HttpServletRequest httpServletRequest, @RequestBody OcrInvoiceReviewRequestDTO ocrInvoiceReviewRequestDTO)
                    throws  VendorInvoiceServerException {
        String response = invoiceReviewServiceImpl.updateOCRInvoiceDetails(ocrInvoiceReviewRequestDTO);
        if(response.equals("Invoice No already Exist!")) {
        	return ResponseEntity.ok().body(APIResponseDTO.builder().status(0)
                    .data(null)
                    .message(response).tag(httpServletRequest.getRequestURI()).build());
        }
        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
                        .data(null)
                        .message(response).tag(httpServletRequest.getRequestURI()).build());
    }
    
    
    @PostMapping(value = "/ocrStatusSubmission")
    public ResponseEntity<APIResponseDTO> ocrStatusSubmission(HttpServletRequest httpServletRequest, @RequestBody OcrStatusUpdateRequestDto ocrStatusUpdateRequestDto)
                    throws VendorMasterBusinessException, VendorInvoiceServerException {
    		
	        String response = invoiceReviewServiceImpl.ocrStatusSubmission(ocrStatusUpdateRequestDto);
	        
	        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
	                        .data(null)
	                        .message(response).tag(httpServletRequest.getRequestURI()).build());
    	
      }
    
    @PostMapping(value = "/getComplianceSummary")
    public ResponseEntity<APIResponseDTO> getComplianceIssuesSummary(HttpServletRequest httpServletRequest, @RequestBody OcrComplianceReqDto ocrComplianceReqDto)
                    throws VendorMasterBusinessException, VendorInvoiceServerException {
    		
	        Map<String, Object> response = fileOcrProcessAndSaveService.getOcrComplianceIssue(ocrComplianceReqDto.getFileId());
	        
	        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
	                        .data(response)
	                        .message("data get successfully").tag(httpServletRequest.getRequestURI()).build());
    	
      }
    
    @PostMapping(value = "/ocr_trigger")
    public ResponseEntity<APIResponseDTO> ocrUploadTrigger(HttpServletRequest httpServletRequest, @RequestBody OcrTriggerRequestDto ocrTriggerRequestDto)
                    throws VendorMasterBusinessException, VendorInvoiceServerException {
    		
	        fileOcrProcessAndSaveService.ocrUploadTrigger(ocrTriggerRequestDto);
	        
	        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
	                        .data(null)
	                        .message("OCR Triggered Successfully").tag(httpServletRequest.getRequestURI()).build());
    	
      }
    
    @PostMapping(value = "/updateOcrStatus")
    public ResponseEntity<APIResponseDTO> updateOcrStatus(HttpServletRequest httpServletRequest, @RequestBody OcrStatusUpdateRequestDto ocrStatusUpdateRequestDto)
                    throws VendorMasterBusinessException, VendorInvoiceServerException {
    		
	        String response = invoiceReviewServiceImpl.updateOcrStatus(ocrStatusUpdateRequestDto);
	        
	        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
	                        .data(null)
	                        .message(response).tag(httpServletRequest.getRequestURI()).build());
    	
      }
    
    @PostMapping(value = "/getVendorCodeErp")
    public ResponseEntity<APIResponseDTO> getVendorCodeErp(HttpServletRequest httpServletRequest, @RequestBody VendorCodeAutoTagReqDto reqDto)
                    throws VendorMasterBusinessException {
    		
	        String vendorCode = invoiceReviewServiceImpl.fetchVendorCode(reqDto);
	        
	        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
	                        .data(vendorCode)
	                        .message(null).tag(httpServletRequest.getRequestURI()).build());
    	
      }

}
