package com.bdo.bvms.ocr.service;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;

public interface InvoiceOcrFileUploadService {

	void readAndSaveUnprocessedData(UploadReqDTO uploadDTO, AzureConnectionCredentialsDTO map) throws VendorInvoiceServerException;

	
}
