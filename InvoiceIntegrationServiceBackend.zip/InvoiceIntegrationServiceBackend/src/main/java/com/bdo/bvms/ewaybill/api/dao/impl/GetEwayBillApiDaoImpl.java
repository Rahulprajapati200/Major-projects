package com.bdo.bvms.ewaybill.api.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.ewaybill.api.GetEwayBillApiDao;
import com.bdo.bvms.ewaybill.api.dto.BDOAuthDTO;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.ewaybill.api.dto.InvoiceDetailDTO;
import com.bdo.bvms.ewaybill.api.dto.NicAuthResponseDTO;
import com.bdo.bvms.ewaybill.api.dto.SchedularLogDto;
import com.bdo.bvms.ewaybill.api.dto.TaxpayerDetailsDTO;
import com.bdo.bvms.ewaybill.api.sql.Transactions;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.VendorInvoiceConstants;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.EWBGenByOtherPartyDTO;
import com.bdo.bvms.invoices.dto.EwayBillVehiclesDTO;
import com.bdo.bvms.invoices.dto.EwayBillheaderDTO;
import com.bdo.bvms.invoices.util.DateUtil;
import com.bdo.bvms.ocr.SQL.FileOcrSql;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class GetEwayBillApiDaoImpl implements GetEwayBillApiDao {

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Override
    public String getBdoAuthKey() {

        try {
            return jdbcTemplateTrn.queryForObject(Transactions.GET_EXPIRY_DATE_BDO_AUTH, String.class);
        } catch (Exception ex) {
            log.error("Error occured while execute getBdoAuthKey function:", ex);
            return null;
        }
    }

    @Override
    public NicAuthResponseDTO getNicAuthKey(String taxpayerGstin) {

        try {
            return jdbcTemplateTrn.queryForObject(Transactions.GET_NIC_AUTH_DATA,
                            BeanPropertyRowMapper.newInstance(NicAuthResponseDTO.class), taxpayerGstin);
        } catch (Exception ex) {
            log.error("Exception generated ::", ex);
            return null;
        }
    }

    @Override
    public int getBdoAuthId(String bdoAuthKey) {

        try {
            return jdbcTemplateTrn.queryForObject(Transactions.GET_BDO_AUTH_ID, int.class, bdoAuthKey);
        } catch (Exception ex) {
            log.error("Exception generated ::", ex);
            return 0;
        }
    }

    @Override
    public String getBdoAuthToken() {

        return jdbcTemplateMst.queryForObject(Transactions.GET_BDO_AUTH_TOKEN, String.class, Constants.BDO_EWB_AUTH);
    }

    @Override
    public Integer insertToEwayBillHeader(int ewbApiCallLogId, EwayBillheaderDTO ewayBillheaderInfo)
                    throws InvoiceIntegrationEWBException {
    	ewayBillheaderInfo.setSubSupplyDesc(getSubSupplyTypeDesc(ewayBillheaderInfo.getSubSupplyType().trim()));

        List<Long> ewbIdList = checkEwbHeaderDetailByEwbNo(ewayBillheaderInfo.getEwbNo());
        if (!ewbIdList.isEmpty() && ewbIdList != null ) {
            String idListString = ewbIdList.toString().replace("[", "(").replace("]", ")");
            insertRecordsFromEwbHeaderToArchivedAllreadyExists(idListString);
            insertRecordsFromEwbItemDetailsToArchivedAllreadyExists(idListString);
            insertRecordsFromEwbVehicalDetailsToArchivedAllreadyExists(idListString);
            deleteRecordsFromEwbHeaderAllreadyExists(idListString);
            deleteRecordsFromEwbItemDetailsAllreadyExists(idListString);
            deleteRecordsFromEwbVehicalDetailsAllreadyExists(idListString);

        }
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(Transactions.INSERT_INTO_EWAYBILL_HEADER,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, ewayBillheaderInfo.getEwbNo());
            ps.setString(2, DateUtil.convertDateFormattoScreen2(ewayBillheaderInfo.getEwayBillDate()));
            ps.setString(3, ewayBillheaderInfo.getUserGstin());
            ps.setString(4, ewayBillheaderInfo.getSupplyType());
            ps.setString(5, ewayBillheaderInfo.getDocType());
            ps.setString(6, ewayBillheaderInfo.getDocNo());
            ps.setString(7, ewayBillheaderInfo.getFromGstin());
            ps.setString(8, ewayBillheaderInfo.getToGstin());
            ps.setString(9, ewayBillheaderInfo.getFromAddr1());
            ps.setString(10, ewayBillheaderInfo.getFromAddr2());
            ps.setString(11, ewayBillheaderInfo.getFromPlace());
            ps.setString(12, ewayBillheaderInfo.getFromPincode());
            ps.setString(13, ewayBillheaderInfo.getFromStateCode());
            ps.setString(14, ewayBillheaderInfo.getToTrdName());
            ps.setString(15, ewayBillheaderInfo.getToAddr1());
            ps.setString(16, ewayBillheaderInfo.getToAddr2());

            ps.setString(17, ewayBillheaderInfo.getToPlace());
            ps.setString(18, ewayBillheaderInfo.getToPincode());
            ps.setString(19, ewayBillheaderInfo.getToStateCode());
            ps.setString(20, ewayBillheaderInfo.getTotalValue());
            ps.setString(21, ewayBillheaderInfo.getTotInvValue());
            ps.setString(22, ewayBillheaderInfo.getCgstValue());
            ps.setString(23, ewayBillheaderInfo.getSgstValue());
            ps.setString(24, ewayBillheaderInfo.getIgstValue());
            ps.setString(25, ewayBillheaderInfo.getCessValue());
            ps.setString(26, ewayBillheaderInfo.getTransporterId());
            ps.setString(27, ewayBillheaderInfo.getTransporterName());
            ps.setString(28, ewayBillheaderInfo.getStatus());
            ps.setString(29, ewayBillheaderInfo.getActualDist());
            ps.setString(30, ewayBillheaderInfo.getNoValidDays());
            ps.setString(31, ewayBillheaderInfo.getValidUpto());
            ps.setString(32, ewayBillheaderInfo.getExtendedTimes());

            ps.setString(33, ewayBillheaderInfo.getRejectStatus());
            ps.setString(34, ewayBillheaderInfo.getVehicleType());
            ps.setString(35, ewayBillheaderInfo.getActFromStateCode());
            ps.setString(36, ewayBillheaderInfo.getActToStateCode());
            ps.setString(37, ewayBillheaderInfo.getTransactionType());
            ps.setString(38, ewayBillheaderInfo.getOtherValue());
            ps.setString(39, ewayBillheaderInfo.getCessNonAdvolValue());
            ps.setInt(40, ewbApiCallLogId);
            ps.setInt(41, ewayBillheaderInfo.getItemList().isEmpty() ? 3 : 1);
            ps.setString(42, DateUtil.convertDateFormattoScreen2(ewayBillheaderInfo.getDocDate()));
            ps.setString(43, DateUtil.convertDateToFillingPeriod(ewayBillheaderInfo.getEwayBillDate()));
            ps.setString(44, DateUtil.convertDateToFillingPeriod(ewayBillheaderInfo.getDocDate()));
            ps.setInt(45, getYearIdByFp(DateUtil.convertDateToFillingPeriod(ewayBillheaderInfo.getEwayBillDate())));
            
            ps.setString(46, ewayBillheaderInfo.getIsFrezzed());
            ps.setString(47, ewayBillheaderInfo.getItemGetErrorDescription());
            ps.setString(48, ewayBillheaderInfo.getUuidNo());
            ps.setString(49, ewayBillheaderInfo.getPoNo());
            ps.setString(50, ewayBillheaderInfo.getPoDate());
            ps.setString(51, ewayBillheaderInfo.getGrnNo());
            ps.setString(52, ewayBillheaderInfo.getGrnDate());
            ps.setString(53, ewayBillheaderInfo.getFromTrdName());
            ps.setString(54, ewayBillheaderInfo.getGenMode());
            ps.setString(55, ewayBillheaderInfo.getSubSupplyType());
            ps.setString(56, ewayBillheaderInfo.getSubSupplyDesc());
            ps.setString(57, ewayBillheaderInfo.getHsncode());
            ps.setString(58, ewayBillheaderInfo.getHsndesc());
            
            return ps;
        }, keyHolder);
        if (keyHolder.getKey() == null) {
            return null;
        } else {
            Number key = keyHolder.getKey();
            return key == null ? null : key.intValue();
        }
    }
    
    private String getSubSupplyTypeDesc(String subSupplyType) {
    	 
	    	        if("1".equals(subSupplyType)){   
	    	            return "Supply";
	    	        }
    	            else if("2".equals(subSupplyType)) {
    	        	return "Import";
    	            }
    	            else if("3".equals(subSupplyType)) {
    	        	return "Export";
    	            }
    	            else if("4".equals(subSupplyType)){   
    	        	  return "Job Work";  
    	          }
    	            else if("5".equals(subSupplyType)) {
        	        	return "For Own Use";
        	            }
        	            else if("6".equals(subSupplyType)) {
        	        	return "Job work returns";
        	            }
        	            else if("7".equals(subSupplyType)){   
        	        	  return "Sales return";  
        	          }
        	            
        	             else if("8".equals(subSupplyType)) {
            	        	return "Others";
            	            }
            	            else if("9".equals(subSupplyType)) {
            	        	return "SKD/CKD/Lots";
            	            }
            	            else if("10".equals(subSupplyType)){   
            	        	  return "Line Sales";  
            	          }
            	            else if("11".equals(subSupplyType)) {
                	        	return "Recipient Not Known";
                	            }
                	    else if("12".equals(subSupplyType)){   
                	        	  return "Exhibition or Fairs";  
                	          }
	    	        	else {
	    	        	return null;
	    	        	}

    }
    

    @Override
    public void insertToEwayBillItemDetails(List<com.bdo.bvms.invoices.dto.EWayBillItemsDTO> itemList, Integer id) {
        jdbcTemplateTrn.batchUpdate(Transactions.INSERT_INTO_EWAYBILL_ITEM_DETAILS, itemList, 100,
                        (PreparedStatement ps, com.bdo.bvms.invoices.dto.EWayBillItemsDTO item) -> {
                            ps.setInt(1, id);
                            ps.setLong(2, Long.valueOf(item.getItemNo()));
                            ps.setLong(3, Long.valueOf(item.getProductId()));
                            ps.setString(4, item.getProductName());
                            ps.setString(5, item.getProductDesc());
                            ps.setString(6, item.getHsnCode());
                            ps.setString(7, item.getQuantity());
                            ps.setString(8, item.getQtyUnit());
                            ps.setString(9, item.getCgstRate());
                            ps.setString(10, item.getSgstRate());
                            ps.setString(11, item.getIgstRate());
                            ps.setString(12, item.getCessRate());
                            ps.setString(13, item.getCessNonAdvol());
                            ps.setString(14, item.getTaxableAmount());
                        });
    }

    @Override
    public void insertToEwayBillVehicleDetails(List<EwayBillVehiclesDTO> vehicleList, Integer ewbId) {
        jdbcTemplateTrn.batchUpdate(Transactions.INSERT_INTO_EWAYBILL_VEHICLE_DETAILS, vehicleList, 100,
                        (PreparedStatement ps, EwayBillVehiclesDTO item) -> {
                            ps.setInt(1, ewbId);
                            ps.setString(2, item.getUpdMode());
                            ps.setString(3, item.getVehicleNo());
                            ps.setString(4, item.getFromPlace());
                            ps.setString(5, item.getFromState());
                            ps.setString(6, item.getTripshtNo());
                            ps.setString(7, item.getUserGSTINTransin());
                            ps.setString(8, item.getEnteredDate() == null ? null
                                            : item.getEnteredDate().substring(0, 10));
                            ps.setString(9, item.getTransMode());
                            ps.setString(10, item.getTransDocNo());
                            ps.setString(11, item.getGroupNo());
                            ps.setString(12, item.getTransDocDate() == null ? null
                                            : item.getTransDocDate().substring(0, 10));

                        });
    }

    @Override
    public TaxpayerDetailsDTO getTaxpayerDetailsFromEntityMaster(String taxpayerGstin)
                    throws InvoiceIntegrationEWBException {

        return jdbcTemplateMst.queryForObject(Transactions.getTaxpayerEntityMaster(taxpayerGstin),
                        BeanPropertyRowMapper.newInstance(TaxpayerDetailsDTO.class));

    }

    @Override
    public String getBdoAuthUrl() {

        return jdbcTemplateMst.queryForObject(Transactions.GET_BDO_AUTH_URL, String.class);

    }

    @Override
    public String getNicAuthUrl() {

        return jdbcTemplateMst.queryForObject(Transactions.GET_NIC_AUTH_URL, String.class);

    }

    @Override
    public String getEwayBillApiUrl() {

        return jdbcTemplateMst.queryForObject(Transactions.GET_EWB_API_URL, String.class);

    }

    @Override
    public String getEwayBillOtherPartyApiUrl() {

        return jdbcTemplateMst.queryForObject(Transactions.GET_EWB_API_OTHER_PARTY_URL, String.class);

    }

    @Override
    public String getEwayBillByDateApiUrl() {

        return jdbcTemplateMst.queryForObject(Transactions.GET_EWB_API_BY_DATE_URL, String.class);

    }

    @Override
    public String getEwayBillAppKey() {

        return jdbcTemplateMst.queryForObject(Transactions.GET_EWB_APP_KEY, String.class);

    }

    @Override
    public String getEwayBillClientId() {

        return jdbcTemplateMst.queryForObject(Transactions.GET_EWB_CLIENT_ID, String.class);

    }

    @Override
    public String getEwayBillClientSecretEncrypted() {

        return jdbcTemplateMst.queryForObject(Transactions.GET_EWB_CLIENT_SECRET_ENCRYPTED, String.class);

    }

    @Override
    public void updateEwayBillApiCallLog(int isSuccess,String errorDesc,int getStatus,int successCount,int id) {
        jdbcTemplateTrn.update(Transactions.UPDATE_EWB_API_CALL_LOG_STATUS, isSuccess,errorDesc,getStatus,successCount,id);

    }

    @Override
    public Integer insertToEwayBillApiCall(NicAuthResponseDTO nicAuthResponseDTO, String taxpayerGstin,
                    GetEwayBillReqDTO getEwayBillReqDTO, String errorDesc, int pldGetType, String responseBody,int getStatus)
                    throws InvoiceIntegrationEWBException {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(Transactions.INSERT_INTO_EWAYBILL_API_CALL_LOG,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, nicAuthResponseDTO.getId());
            ps.setInt(2, pldGetType);
            ps.setString(3, taxpayerGstin);
            ps.setString(4, getEwayBillReqDTO.getEwaybillNo());
            ps.setString(5, getEwayBillReqDTO.getEwaybillDate());
            ps.setString(6, nicAuthResponseDTO.getNicAuthToken());
            ps.setInt(7, errorDesc == null ? 1 : 0);
            ps.setString(8, errorDesc);
            ps.setString(9, responseBody);
            ps.setInt(10, getEwayBillReqDTO.getSuccessCount());
            ps.setInt(11, getEwayBillReqDTO.getUserId());
            ps.setString(12, getEwayBillReqDTO.getIsCallFromSchedular());
            ps.setInt(13, getStatus);

            return ps;
        }, keyHolder);
        if (keyHolder.getKey() == null) {
            return null;
        } else {
            Number key = keyHolder.getKey();
            return key == null ? null : key.intValue();
        }
    }

    @Override
    public void insertToEwayBillHeaderFromEWBOtherParty(List<EWBGenByOtherPartyDTO> data, int ewbApiCallLogId)
                    throws VendorInvoiceServerException {

        jdbcTemplateTrn.batchUpdate(Transactions.INSERT_INTO_EWAYBILL_HEADER_FROM_EWB_OTHER_PARTY, data, 100,
                        (PreparedStatement ps, com.bdo.bvms.invoices.dto.EWBGenByOtherPartyDTO item) -> {
                            ps.setString(1, item.getEwbNo());
                            ps.setString(2, item.getEwayBillDate());
                            ps.setString(3, item.getDocNo());
                            ps.setString(4, item.getFromGstin());
                            ps.setString(5, item.getToGstin());
                            ps.setString(6, item.getToTradeName());
                            ps.setString(7, item.getTotInvValue());
                            ps.setString(8, item.getStatus());
                            ps.setString(9, item.getRejectStatus());
                            ps.setInt(10, ewbApiCallLogId);

                        });
    }

    @Override
    public void insertToBdoAuthApiCall(BDOAuthDTO bdoAuthDTO) throws InvoiceIntegrationEWBException {

        jdbcTemplateTrn.update(Transactions.INSERT_INTO_EWAYBILL_BDO_AUTH, bdoAuthDTO.getBdoAuthToken(),
                        bdoAuthDTO.getExpiry(), bdoAuthDTO.getStatus(), bdoAuthDTO.getPlayLoad(),
                        bdoAuthDTO.getIsException(), bdoAuthDTO.getErrorDescription());

    }

    @Override
    public int insertIntoExternalApiCallLog(NicAuthResponseDTO nicAuthResponseDTO)
                    throws InvoiceIntegrationEWBException {

        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(Transactions.INSERT_INTO_EXTERNAL_API_CALL_LOG,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, nicAuthResponseDTO.getBdoAuthId());
            ps.setInt(2, nicAuthResponseDTO.getApiId());
            ps.setString(3, nicAuthResponseDTO.getInHeader());
            ps.setString(4, nicAuthResponseDTO.getInData());
            ps.setString(5, nicAuthResponseDTO.getNicSek());
            ps.setString(6, nicAuthResponseDTO.getNicAuthToken());
            ps.setString(7, nicAuthResponseDTO.getIsException());
            ps.setString(8, nicAuthResponseDTO.getErrorDescription());
            ps.setString(9, nicAuthResponseDTO.getTaxpayerGstin());

            return ps;
        }, keyHolder);
        if (keyHolder.getKey() == null) {
            return 0;
        } else {
            Number key = keyHolder.getKey();
            return key == null ? null : key.intValue();
        }

    }
    
    @Override
    public void updateExternalApiCallLogSuccess(NicAuthResponseDTO nicAuthResponseDTO) {
    	jdbcTemplateTrn.update(Transactions.UPDATE_EXTERNAL_API_CALL_LOG_SUCCESS,nicAuthResponseDTO.getNicSek(),nicAuthResponseDTO.getNicAuthToken(),nicAuthResponseDTO.getId());
    }

    @Override
    public void updateExternalApiCallLogFail(NicAuthResponseDTO nicAuthResponseDTO) {
    	jdbcTemplateTrn.update(Transactions.UPDATE_EXTERNAL_API_CALL_LOG_FAIL,nicAuthResponseDTO.getIsException(),nicAuthResponseDTO.getErrorDescription(),nicAuthResponseDTO.getId());
    }
    
    @Override
    public void insertToInvoiceDetail(List<InvoiceDetailDTO> data) throws InvoiceIntegrationEWBException {

        jdbcTemplateTrn.batchUpdate(Transactions.INSERT_INTO_INVOICE_DETAIL, data, 100,
                        (PreparedStatement ps, InvoiceDetailDTO item) -> {
                            ps.setString(1, item.getTaxpayerPan());
                            ps.setString(2, item.getTaxpayerGstin());
                            ps.setString(3, item.getVendorPan());
                            ps.setString(4, item.getVendorGstin());
                            ps.setString(5, item.getTaxableValue());
                            ps.setString(6, item.getIgst());
                            ps.setString(7, item.getCgst());
                            ps.setString(8, item.getSgst());
                            ps.setString(9, item.getCess());
                            ps.setString(10, item.getInvoiceValue());
                            ps.setString(11, item.getEwaybillNo());
                            ps.setString(12, String.valueOf(item.getEwaybillDate()));
                            ps.setInt(13, item.getPldGetType());
                            ps.setString(14, String.valueOf(item.getSyncStatus()));
                            ps.setString(15, item.getReturnPeriod());
                            ps.setInt(16, item.getYearId());
                            ps.setString(17, item.getDocReturnPeriod());
                            ps.setInt(18, item.getDocYearId());
                            ps.setString(19, item.getCategory());
                            ps.setString(20, item.getNoteType());
                            ps.setString(21, String.valueOf(item.getCreatedOn()));
                            ps.setInt(22, item.getCreatedBy());
                            ps.setString(23, item.getInvoiceNo());
                            ps.setString(24, item.getInvoiceDate());

                        });

    }

    @Override
    public Integer getYearIdByFp(String fp) {

        try {
            return jdbcTemplateMst.queryForObject(Transactions.GET_YEAR_ID_BY_FP, int.class, fp);
        } catch (Exception e) {
            log.error("Exception generated ::", e);
            return null;
        }

    }

    @Override
    public List<String> getTaxpayerListFromEntityMaster() {

        try {
            return jdbcTemplateMst.queryForList(Transactions.GET_TAXPAYER_GSTIN_LIST_FROM_ENTITY_MASTER, String.class);
        } catch (Exception e) {
            log.error("Exception generated ::", e);
            return null;
        }

    }

    @Override
    public List<GetEwayBillReqDTO> getTaxpayerListFromInvoiceEwaybillDetailsTable() {

        try {
            return jdbcTemplateTrn.query(Transactions.GET_TAXPAYER_GSTIN_LIST_FROM_INVOICE_EWAYBILL_DETAILS,
                            new BeanPropertyRowMapper<GetEwayBillReqDTO>(GetEwayBillReqDTO.class));
        } catch (Exception e) {
            log.error("Exception generated ::", e);
            return null;
        }

    }

    @Override
    public void updateEwaybillFetchedDetails(String ewbNo, EwayBillheaderDTO header) {

        try {
        	Integer itemCount = header.getItemList() !=null ? header.getItemList().size() : 0;
        	EwayBillheaderDTO updatedDetails = new EwayBillheaderDTO();
        	updatedDetails.setEwayBillDate(DateUtil.convertDateFormattoScreen2(header.getEwayBillDate()));       
        	updatedDetails.setDocNo(header.getDocNo());
        	updatedDetails.setDocDate(DateUtil.convertDateFormattoScreen2(header.getDocDate()));
        	updatedDetails.setDocType(header.getDocType());
        	updatedDetails.setValidUpto(DateUtil.convertDateFormattoScreen2(StringUtils.isEmpty(header.getValidUpto()) ? null
                            : header.getValidUpto().substring(0, 10)));
        	updatedDetails.setTotInvValue(header.getTotInvValue());
            jdbcTemplateTrn.update(Transactions.UPDATE_FLAG_EWB_DETAILS_FETCHED,updatedDetails.getDocType(),updatedDetails.getDocNo(),updatedDetails.getDocDate(),
            		itemCount,updatedDetails.getTotInvValue(),updatedDetails.getValidUpto(),updatedDetails.getEwayBillDate(),header.getFromGstin(),updatedDetails.getEwayBillDate(), ewbNo);
        } catch (Exception e) {
            log.error("Exception generated in updateEwaybillFetchedDetails::", e);
        }

    }

    @Override
    public void updateEwaybillReFetchedCount(int id) {

        try {
            jdbcTemplateTrn.update(Transactions.UPDATE_EWB_RE_FETCH_COUNT, id);
        } catch (Exception e) {
            log.error("Exception generated in updateEwaybillReFetchedCount::", e);
        }

    }

    /*
     * @Override public int markBDOKeyInactive(String key) { return
     * jdbcTemplateTrn.update(Transactions.UPDATE_BDO_KEY_INACTIVE, key);
     * 
     * }
     */

    @Override
    public int markNICKeyInactive(String gstin, String sek) {
        return jdbcTemplateTrn.update(Transactions.UPDATE_NIC_KEY_INACTIVE, gstin, sek);

    }

    @Override
    public List<GetEwayBillReqDTO> getFailedTaxpayerEwBToReprocess() {
        return jdbcTemplateTrn.query(Transactions.GET_FAILED_TAXPAYER_EWB_LIST_TO_REPROCESS,
                        new BeanPropertyRowMapper<GetEwayBillReqDTO>(GetEwayBillReqDTO.class));

    }

    @Override
    public List<String> getTaxpayerGstinListByPan(String pan) {
        return jdbcTemplateMst.queryForList(Transactions.GET_TAXPAYER_GSTIN_LIST, String.class, pan);

    }

    private List<Long> checkEwbHeaderDetailByEwbNo(String ewbNo) {

        return jdbcTemplateTrn.queryForList(Transactions.CHECK_EWB_HEADER_DETAIL_BY_EWB_NO, long.class, ewbNo);

    }

    private void insertRecordsFromEwbHeaderToArchivedAllreadyExists(String idListString) {

        jdbcTemplateTrn.update(Transactions.insertEwbHeaderDetailsToArchived(idListString));

    }

    private void insertRecordsFromEwbItemDetailsToArchivedAllreadyExists(String idListString) {

        jdbcTemplateTrn.update(Transactions.insertEwbItemDetailsToArchived(idListString));

    }

    private void insertRecordsFromEwbVehicalDetailsToArchivedAllreadyExists(String idListString) {

        jdbcTemplateTrn.update(Transactions.insertEwbVehicalDetailsToArchived(idListString));

    }

    private void deleteRecordsFromEwbHeaderAllreadyExists(String idListString) {

        jdbcTemplateTrn.update(Transactions.deleteEwbRecordsFromEwbHeaderAllreadyExists(idListString));

    }

    private void deleteRecordsFromEwbItemDetailsAllreadyExists(String idListString) {

        jdbcTemplateTrn.update(Transactions.deleteEwbRecordsFromEwbItemDetailsAllreadyExists(idListString));

    }

    public void deleteRecordsFromEwbVehicalDetailsAllreadyExists(String idListString) {

        jdbcTemplateTrn.update(Transactions.deleteEwbRecordsFromVehicalDetailsAllreadyExists(idListString));

    }
    
    @Override
    public int insertToSchedularLog(SchedularLogDto schedularLogDto) throws InvoiceIntegrationEWBException {
    	
    	KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(Transactions.INSERT_INTO_SCHEDULAR_LOG,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, schedularLogDto.getSchedularCallFor());
            ps.setString(2, schedularLogDto.getTaxpayerGstin());
            ps.setString(3, schedularLogDto.getEwaybillDate());
            return ps;
        }, keyHolder);
        if (keyHolder.getKey() == null) {
            return 0;
        } else {
            Number key = keyHolder.getKey();
            return key == null ? null : key.intValue();
        }

    }
    
    @Override
    public void updateSchedularLog(SchedularLogDto schedularLogDto) throws InvoiceIntegrationEWBException {

        jdbcTemplateTrn.update(Transactions.UPDATE_SCHEDULAR_LOG, schedularLogDto.getIsSucess(),schedularLogDto.getErrorRemarks(), schedularLogDto.getId());

    }
    
    @Override
    public List<Integer> getUserIdBasedOnGstin(String gstin) throws InvoiceIntegrationEWBException {

            return jdbcTemplateMst.queryForList(Transactions.GET_USERID_BY_GSTIN_ROLE_MAPPING,Integer.class,gstin,gstin);
        
    }
    
    @Override
    public void commonPostNotification(int vendoruploadmstid, String notificationDesc, String notificationCode,List<Integer> userIdList) {
    	userIdList.forEach(userId -> {
    	    List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

    	    jdbcTemplateTrn.call(con -> {
    	        CallableStatement cs = con.prepareCall("{call common_post_notification(?,?,?,?,?,?,?)}");
    	        if (cs != null) {
    	            cs.setInt(1, vendoruploadmstid);
    	            cs.setString(2, notificationDesc);
    	            cs.setInt(3, userId);
    	            cs.setInt(4, userId);
    	            cs.setInt(5, 0);
    	            cs.setString(6, mstDatabseName);
    	            cs.setString(7, notificationCode);
    	        }
    	        return cs;
    	    }, parameters);
    	});

    }
    
    @Override
    public void updateEwbStatusToExpired(String expDate){

        jdbcTemplateTrn.update(Transactions.UPDATE_EWB_STATUS_TO_EXPIRED,Constants.EXPIRED,expDate);

    }
   
    @Override
    public void updateEwbStatusToDiscarded(String disDate){

        jdbcTemplateTrn.update(Transactions.UPDATE_EWB_STATUS_TO_DISCARDED,Constants.DISCARDED,disDate);

    }

}
