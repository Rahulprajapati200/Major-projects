package com.bdo.bvms.invoices.dto;

import java.time.LocalDateTime;

import com.bdo.bvms.invoices.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class DraftDocumentsDTO {

    private int id;
    private String companyGstin;
    private String dataType;
    private String customerGstin;
    private String customerLegalName;
    private String customerTradeName;
    private String invoiceNo;
    private String invoiceDate;
    private String ewayBillNo;
    private String ewayBillDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
    private LocalDateTime uploadedOn;

    private String uploadedBy;
    private String documentStatus;
    private String action;
    private int totalCount;
    private String docType;
    private String irnVerified;
    private String supplyType;
}
