package com.bdo.bvms.urp.dao;

import java.util.List;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.PowerAutomateRequestBody;
import com.bdo.bvms.invoices.dto.UrpListDataResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface UrpDataListDao {

	List<UrpListDataResDTO> getUrpDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
			String monthList) throws VendorInvoiceServerException;

	void updateEmailDocumentReceivedPullLog(String powerAutoJson);

	void updateEmailDocumentReceivedErrorLog(PowerAutomateRequestBody powerAutomateRequestBody,String message);

}
