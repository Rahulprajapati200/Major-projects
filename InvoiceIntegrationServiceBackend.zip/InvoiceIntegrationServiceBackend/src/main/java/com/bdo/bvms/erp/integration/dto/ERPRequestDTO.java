package com.bdo.bvms.erp.integration.dto;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ERPRequestDTO {
	
	String appKey;
	
	String clientSecret;


}
