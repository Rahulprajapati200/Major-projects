package com.bdo.bvms.invoices.dao.impl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceSyncDataListDao;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.SyncPendingResponseDataDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.invoices.taxpayer.sql.TransactionSQL;
import com.bdo.bvms.invoices.util.CommonUtils;
import com.bdo.bvms.invoices.util.NumberUtils;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class VendorInvoiceSyncDataListDaoImpl implements VendorInvoiceSyncDataListDao {

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Autowired
    CommonDao commonDao;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Override
    public List<SyncPendingResponseDataDTO> getSyncPendingDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {

        try {
            Map<String, String> screenAliasMap = commonDao.getSchreeAliasMap(vendorInvoiceRequestDTO);
            String whereCondition = CommonUtils.getWhereCondition(vendorInvoiceRequestDTO.getAdvanceFilter(),
                            screenAliasMap);
            Map<String, Object> out = commonDao.getGridDataForSyncPending(vendorInvoiceRequestDTO, gstinNewList,
                            monthList, whereCondition);
            List<SyncPendingResponseDataDTO> dataResList = new ArrayList<>();
            List<Map<String, Object>> results = (List<Map<String, Object>>) out.get("#result-set-" + 1);
            if (results.isEmpty()) {
                return dataResList;
            }

            results.forEach(u -> {

                SyncPendingResponseDataDTO dataRes = new SyncPendingResponseDataDTO();
                dataRes.setId(Integer.valueOf(u.get("id").toString()));
                dataRes.setTaxpayerPan(checkNullValue((String) u.get("taxpayer_pan")));
                dataRes.setTaxpayerGstin(checkNullValue((String) u.get("taxpayer_gstin")));
                dataRes.setVendorPan(checkNullValue((String) u.get("vendor_pan")));
                dataRes.setVendorGstin(checkNullValue((String) u.get("vendor_gstin")));
                dataRes.setVendorLegalName(checkNullValue((String) u.get("vendor_legal_name")));
                dataRes.setVendorTradeName(checkNullValue((String) u.get("vendor_trade_name")));
                dataRes.setInvoiceNo(checkNullValue((String) u.get("invoice_no")));
                dataRes.setInvoiceDate(checkNullValue((String) u.get("invoice_date")));
                dataRes.setSyncWithGstr2a((String) u.get("sync_with_gstr2a"));
                dataRes.setSyncWithGstr2b((String) u.get("sync_with_gstr2b"));
                dataRes.setSyncWithEwayBill((String) u.get("sync_with_eway_bill"));
                dataRes.setTaxableValue(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("taxable_value")));
                dataRes.setIgst(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("igst")));
                dataRes.setSgst(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("sgst")));
                dataRes.setCess(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("cess")));
                dataRes.setInvoiceValue(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("invoice_value")));
                dataRes.setQrCodeValid((Boolean) u.get("qr_code_valid"));
                dataRes.setEwayBillNo(checkNullValue((String) u.get("eway_bill_no")));
                dataRes.setEwayBillDate(checkNullValue((String) u.get("eway_bill_date")));
                dataRes.setPoNumber(checkNullValue((String) u.get("po_number")));
                dataRes.setGrnNumber(checkNullValue((String) u.get("grn_no")));
                dataRes.setUploadDate((LocalDateTime) u.get("details_upload_date"));
                dataRes.setLastSyncDate((LocalDateTime) u.get("last_synced_date"));
                dataRes.setSyncStatus((Boolean) u.get("sync_status"));
                dataRes.setBookedErp((Boolean) u.get("booked_erp"));
                dataRes.setGetType(checkNullValue((String) u.get("get_type")));
                dataRes.setBatchNo(checkNullValue((String) u.get("batch_no")));
                dataRes.setFileType(checkNullValue((String) u.get("file_type")));
                dataRes.setTotalCount(Integer.valueOf(u.get("total_count").toString()));
                dataRes.setSupplyType(checkNullValue((String) u.get("supply_type")));
                dataRes.setDocType(checkNullValue((String) u.get("doc_type")));
                dataRes.setIrnVerified(checkNullValue((String) u.get("status")));
                dataRes.setIsTaxpayerUploaded((String)u.get("is_taxpayer_uploaded"));
                dataRes.setVendorCodeErp(checkNullValue((String) u.get("vendor_code_erp")));
                dataRes.setOcrFileId(u.get("ocr_header_file_id") != null ? Integer.valueOf(u.get("ocr_header_file_id").toString()) : null);
                dataResList.add(dataRes);

            });

            return dataResList;
        } catch (DataAccessException e) {
            log.info("Error occures at the time of fetching data from database", e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATIONGRIDDATA);
            exceptionLogDTO.setFunctionName("getSyncPendingDataList");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming
            // in this function to getting data from database.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException("Error occures at the time of fetching data from database",
                            e.getCause());

        }

    }

    private static String checkNullValue(String value) {
        if (StringUtils.isEmpty(value)) {
            return "-";
        } else {
            return value;
        }
    }

    @Override
    public int getTotalCount(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList, String monthList) {

        // Here we get query for getting Sync pending grid data from database.
        String query = TransactionSQL.getSyncTotalCount(mstDatabseName, gstinNewList, monthList);

        return jdbcTemplateTrn.queryForObject(query, Integer.class);
    }

}