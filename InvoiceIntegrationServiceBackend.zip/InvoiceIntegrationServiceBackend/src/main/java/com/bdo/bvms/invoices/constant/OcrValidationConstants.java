package com.bdo.bvms.invoices.constant;

public class OcrValidationConstants {
	OcrValidationConstants(){
		
	}
	public static final int PLD_COMPLIANCE_VALIDATION = 2;
	public static final int PLD_EXTRACTION_VALIDATION = 1;
	public static final String TAXPAYER_GSTIN = "bill_to_gstin";
	public static final String VENDOR_GSTIN = "vendor_gstin";
	public static final String TAXPAYER_PAN = "taxpayer_pan_number";
	public static final String VENDOR_PAN = "vendor_pan_number";
	public static final String DESCRIPTION = "description";
	public static final String QUANTITY = "quantity";
	public static final String UOM = "unit";
	
	public static final String CGST_AMT = "cgst_amt";
	public static final String IGST_AMT = "igst_amt";
	public static final String SGST_AMT = "sgst_amt";
	public static final String CESS_AMT = "cess_amt";
	public static final String INVOICE_NO = "invoice_no";
	public static final String TOTAL_INV_MAOUNT = "total_inv_amount";
	public static final String TOTAL_TAXABLE = "taxable_amount";
	public static final String TAXABLE_VALUE = "amount";
	public static final String HSN_CODE = "hsn_code";
	public static final String SGST_P = "sgst_p";
	public static final String CGST_P = "cgst_p";
	public static final String IGST_P = "igst_p";
	public static final String CESS_P = "cess_p";
	public static final String RATE = "rate";
	public static final String TDS = "tds";
	public static final String POS = "pos";
	public static final String OCR_ERROR_CODE_CE001 = "CE001";

	public static final String OCR_ERROR_CODE_CE002 = "CE002";
	
	public static final String OCR_ERROR_CODE_CE003 = "CE003";

	public static final String OCR_ERROR_CODE_CE004 = "CE004";
	public static final String OCR_ERROR_CODE_CE005 = "CE005";

	public static final String OCR_ERROR_CODE_CE006 = "CE006";
	
	public static final String OCR_ERROR_CODE_CE007 = "CE007";

	public static final String OCR_ERROR_CODE_CE008 = "CE008";
	
	public static final String OCR_ERROR_CODE_CE009 = "CE009";

	public static final String OCR_ERROR_CODE_CE010 = "CE010";
	public static final String OCR_ERROR_CODE_CE011 = "CE011";

	public static final String OCR_ERROR_CODE_CE012 = "CE012";
	
	public static final String OCR_ERROR_CODE_CE013 = "CE013";
	public static final String OCR_ERROR_CODE_CE014 = "CE014";

	public static final String OCR_ERROR_CODE_CE015 = "CE015";
	
	public static final String OCR_ERROR_CODE_CE016 = "CE016";

	public static final String OCR_ERROR_CODE_CE017 = "CE017";
	
	public static final String OCR_ERROR_CODE_CE018 = "CE018";

	public static final String OCR_ERROR_CODE_CE019 = "CE019";
	public static final String OCR_ERROR_CODE_CE020 = "CE020";

	public static final String OCR_ERROR_CODE_CE021 = "CE021";
	
	public static final String OCR_ERROR_CODE_CE022 = "CE022";

	public static final String OCR_ERROR_CODE_CE023 = "CE023";
	
	public static final String OCR_ERROR_CODE_CE024 = "CE024";

	public static final String OCR_ERROR_CODE_CE025 = "CE025";
	public static final String OCR_ERROR_CODE_CE026 = "CE026";

	public static final String OCR_ERROR_CODE_CE027 = "CE027";
	
    public static final String OCR_ERROR_CODE_CE028 = "CE028";
	
	public static final String OCR_ERROR_CODE_CE029 = "CE029";

	public static final String OCR_ERROR_CODE_CE030 = "CE030";
	public static final String OCR_ERROR_CODE_CE031 = "CE031";

	public static final String OCR_ERROR_CODE_CE032 = "CE032";
    public static final String OCR_ERROR_CODE_CE033 = "CE033";
	
    public static final String OCR_ERROR_CODE_CE034 = "CE034";
	
	public static final String OCR_ERROR_CODE_CE035 = "CE035";

	public static final String OCR_ERROR_CODE_CE036 = "CE036";
	public static final String OCR_ERROR_CODE_CE037 = "CE037";

	public static final String OCR_ERROR_CODE_CE038 = "CE038";
	public static final String OCR_ERROR_CODE_CE039 = "CE039";
	public static final String OCR_ERROR_CODE_CE040 = "CE040";
	public static final String OCR_ERROR_CODE_CE041 = "CE041";
	public static final String OCR_ERROR_CODE_CE042 = "CE042";
	public static final String OCR_ERROR_CODE_CE043 = "CE043";
	public static final String OCR_ERROR_CODE_CE044 = "CE044";
	public static final String OCR_ERROR_CODE_CE045 = "CE045";

	public static final String ERROR_CODE_E00291 = "|E00291";

}
