package com.bdo.bvms.common.service;

import java.io.IOException;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.PowerAutomateRequestBody;

public interface UrpMailFileUploadService {

	public String callUploadUriService(PowerAutomateRequestBody powerAutomateRequestBody) throws IOException, VendorInvoiceServerException;
}
