package com.bdo.bvms.ocr.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.FileOcrCustomException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EncodeFileBytesToStringUtil {
	
	
	
	private EncodeFileBytesToStringUtil() {}


	public static String encode(String fileName,String tempFolder) throws FileOcrCustomException {
		byte[] pdfBytes;
	     String filePath = new StringBuilder().append(tempFolder)
           .append(System.getProperty(Constants.FILESEPERATOR)).append(fileName).toString();
		try {
            pdfBytes = Files.readAllBytes(Paths.get(filePath));
            return Base64.getEncoder().encodeToString(pdfBytes);
        } catch (Exception e) {
        	log.error("error found in reading file",e);
            throw new FileOcrCustomException("error found in reading file",e);
        }
		finally {
			FileUtils.deleteQuietly(new File(filePath));
		}
	}

}
