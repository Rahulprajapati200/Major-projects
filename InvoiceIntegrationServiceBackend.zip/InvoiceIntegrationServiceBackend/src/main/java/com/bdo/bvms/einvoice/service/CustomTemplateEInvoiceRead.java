package com.bdo.bvms.einvoice.service;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;

import com.bdo.bvms.invoices.custom.exception.InvoiceTemplateUploadException;
import com.bdo.bvms.invoices.custom.exception.ReadInvoiceCustomTemplate;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;

/**
 * The Interface CustomTemplateEInvoiceRead.
 */
public interface CustomTemplateEInvoiceRead {

    /**
     * Gets the einvoice data list.
     *
     * @param uploadDTO
     *            the upload DTO
     * @return the einvoice data list
     * @throws InvoiceTemplateUploadException
     *             the invoice template upload exception
     * @throws NumberFormatException
     *             the number format exception
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     * @throws ReadInvoiceCustomTemplate
     */
    List<EInvoiceTemplateDTO> getEinvoiceDataList(UploadReqDTO uploadDTO)
                    throws NumberFormatException, ReadInvoiceCustomTemplate;

    /**
     * Gets the einvoice data list CDV.
     *
     * @param uploadDTO
     *            the upload DTO
     * @param customTemplateHeaderMappings
     *            the custom template header mappings
     * @param delimiter
     *            the delimiter
     * @return the einvoice data list CDV
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     * @throws FileNotFoundException
     */
    List<EInvoiceTemplateDTO> getEinvoiceDataListCDV(UploadReqDTO uploadDTO,
                    Map<String, String> customTemplateHeaderMappings, char delimiter)
                    throws VendorInvoiceServerException, FileNotFoundException;

}
