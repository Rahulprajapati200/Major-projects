package com.bdo.bvms.ocr.repository.impl;

import java.sql.Array;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;
import com.bdo.bvms.ewaybill.api.dto.InvoiceDetailDTO;
import com.bdo.bvms.ewaybill.api.sql.Transactions;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.InvoiceOcrReviewConstant;
import com.bdo.bvms.invoices.constant.OcrValidationConstants;
import com.bdo.bvms.invoices.constant.VendorInvoiceConstants;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.invoices.dto.UploadLogDto;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.ocr.model.OcrInvoiceHeader;
import com.bdo.bvms.invoices.ocr.model.OcrVerticalMap;
import com.bdo.bvms.invoices.taxpayer.sql.LogSQL;
import com.bdo.bvms.invoices.taxpayer.sql.TransactionSQL;
import com.bdo.bvms.invoices.util.DateUtil;
import com.bdo.bvms.invoices.vendor.sql.OcrInvoiceReviewSql;
import com.bdo.bvms.ocr.SQL.FileOcrSql;
import com.bdo.bvms.ocr.dto.OcrComplianceErrorDto;
import com.bdo.bvms.ocr.dto.OcrPullLogDto;
import com.bdo.bvms.ocr.dto.OcrPushLogDto;
import com.bdo.bvms.ocr.dto.OcrVerticalDataObj;
import com.bdo.bvms.ocr.repository.FileOcrProcessAndSaveRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class FileOcrProcessAndSaveRepositoryImpl implements FileOcrProcessAndSaveRepository {

	public static final String CLASSNAME = "FileOcrProcessAndSaveRepositoryImpl";
	@Autowired
	private JdbcTemplate jdbcTemplateTrn;
	@Autowired
    private JdbcTemplate jdbcTemplateMst;

	@Override
	public LinkedHashMap<String, Integer> getOCRFieldConfigMap(int isLineItem) {

		return jdbcTemplateTrn.query(FileOcrSql.GET_OCR_CONFIG_MAP,
				new ResultSetExtractor<LinkedHashMap<String, Integer>>() {
					@Override
					public LinkedHashMap<String, Integer> extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						LinkedHashMap<String, Integer> mapRet = new LinkedHashMap<>();
						while (rs.next()) {
							mapRet.put(rs.getString("ocr_extracted_data_key"), rs.getInt("id"));
						}
						return mapRet;
					}
				},isLineItem);

	}

	@Override
	public void saveToOcrVerticalData(List<OcrVerticalDataObj> data)
			throws BatchUpdateException, VendorInvoiceServerException {
		String methodname = "saveToOcrVerticalData";
		log.info("Classname: " + CLASSNAME + " Methodname: " + methodname + " Started");
		String sql = FileOcrSql.INSERT_INTO_OCR_VERTICAL_DATA;
		int batchSize = 200;

		for (int i = 0; i < data.size(); i += batchSize) {
			final List<OcrVerticalDataObj> batchRecords = data.subList(i, Math.min(i + batchSize, data.size()));
         
			jdbcTemplateTrn.batchUpdate(sql, new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int j) throws SQLException {
					log.info("setting values for record: " + j);
					OcrVerticalDataObj item = batchRecords.get(j);
					ps.setInt(1, item.getFileId());
					ps.setInt(2, 0);
					ps.setInt(3, item.getOcrFieldMstId());
					ps.setString(4, item.getOcrExtractedValue());
					ps.setString(5, item.getOcrConfidenceLevel());
					ps.setInt(6, item.getIsTaxpayer());
					ps.setString(7, item.getFileName());
					ps.setInt(8, item.getIsHeader());
					ps.setInt(9, item.getLineNo());
					ps.setInt(10, 0);
				}

				@Override
				public int getBatchSize() {
					return batchRecords.size();
				}
			});
		}
		log.info("Classname: " + CLASSNAME + " Methodname: " + methodname + " Completed");
	}

	@Override
	public LinkedHashMap<Integer, String> getFilesToProcessOcr() {
		return jdbcTemplateTrn.query(FileOcrSql.GET_FILE_FOR_OCR,
				new ResultSetExtractor<LinkedHashMap<Integer, String>>() {
					@Override
					public LinkedHashMap<Integer, String> extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						LinkedHashMap<Integer, String> mapRet = new LinkedHashMap<>();
						while (rs.next()) {
							mapRet.put(rs.getInt("file_id"), rs.getString("base_file_location"));
						}
						return mapRet;
					}
				},VendorInvoiceConstants.OCR_NOT_STARTED_PLD);

	}
	
	 @Override
	    public void insertToInvoiceEwayBillDetails(List<EInvoiceTemplateDTO> data,UploadReqDTO uploadDTO) throws VendorInvoiceServerException {

	        jdbcTemplateTrn.batchUpdate(FileOcrSql.INSERT_TO_INVOICE_EWB_DETAILS_TABLE, data, 100,
	                        (PreparedStatement ps, EInvoiceTemplateDTO item) -> {
	                            ps.setString(1, item.getGstinUinOfRecipient());
	                            ps.setString(2, item.getPanOfRecipient());
	                            ps.setInt(3, getYearIdByFp(item.getFillingPeriod()));
	                            ps.setString(4, item.getDocType());
	                            ps.setString(5, item.getInwardNo());
	                            ps.setString(6, item.getInwardDate());
	                            ps.setString(7, item.getGstinOfSupplier());
	                            ps.setString(8, item.getPurchaseOrderNumber());
	                            ps.setString(9, item.getPurchaseOrderDate());
	                            ps.setString(10, uploadDTO.getUploadType());
	                            ps.setString(11, item.getFillingPeriod());
	                            ps.setString(12, Timestamp.from(Instant.now()).toString());
	                            ps.setInt(13, 1);
	                            ps.setString(14, uploadDTO.getBatchNo());
	                            ps.setInt(15, 1);

	                        });
	 }
	 
	 @Override
	 public Integer getYearIdByFp(String fp) {

	        try {
	            return jdbcTemplateMst.queryForObject(Transactions.GET_YEAR_ID_BY_FP, int.class, fp);
	        } catch (Exception e) {
	            log.error("Exception generated ::", e);
	            return null;
	        }

	    }


	 @Override
		public Integer insertIntoOCRPushLog(OcrPushLogDto ocrPushLogDto) {
		 KeyHolder keyHolder = new GeneratedKeyHolder();
		 jdbcTemplateTrn.update(connection -> {
	            PreparedStatement ps = connection.prepareStatement(FileOcrSql.INSERT_TO_OCR_PUSH_LOG,
	                            Statement.RETURN_GENERATED_KEYS);
	            ps.setInt(1, ocrPushLogDto.getFileId());
	            ps.setString(2, ocrPushLogDto.getBatchNo());
	            ps.setString(3, ocrPushLogDto.getAckNo());
	            ps.setString(4, ocrPushLogDto.getReqOn());
	            ps.setString(5, ocrPushLogDto.getReqHeader());
	            ps.setString(6, ocrPushLogDto.getReqSource());
	            ps.setString(7, ocrPushLogDto.getUrl());
	            ps.setString(8, "ocr_header");
	            ps.setString(9, ocrPushLogDto.getPayload());
	            ps.setString(10, ocrPushLogDto.getRecievedOn());

	            return ps;
	        }, keyHolder);
	        if (keyHolder.getKey() == null) {
	            return null;
	        } else {
	            Number key = keyHolder.getKey();
	            return key == null ? null : key.intValue();
	        }
		}
	 
	 
	 @Override
		public Integer insertIntoOCRPullLog(OcrPullLogDto ocrPullLogDto) {
		 KeyHolder keyHolder = new GeneratedKeyHolder();
	        jdbcTemplateTrn.update(connection -> {
	            PreparedStatement ps = connection.prepareStatement(FileOcrSql.INSERT_TO_OCR_PULL_LOG,
	                            Statement.RETURN_GENERATED_KEYS);
	            ps.setString(1, ocrPullLogDto.getAckNo());
	            ps.setString(2, ocrPullLogDto.getBatchNo());
	            ps.setString(3, ocrPullLogDto.getOcrExtractedData());
	            ps.setInt(4, ocrPullLogDto.getFileId());
	            ps.setString(5, null);
	            ps.setString(6, ocrPullLogDto.getReqOn());
	            ps.setString(7, ocrPullLogDto.getRecievedOn());
	            ps.setString(8, ocrPullLogDto.getStatus());
	            ps.setString(9, ocrPullLogDto.getErrorDesc());
	            return ps;
	        }, keyHolder);
	        if (keyHolder.getKey() == null) {
	            return null;
	        } else {
	            Number key = keyHolder.getKey();
	            return key == null ? null : key.intValue();
	        }
		}
	 
	 
	 @Override
	    public void updateOcrStatus(Integer fileId,int lockForOcr,String ocrStatus) {
            StringBuilder query = FileOcrSql.updateOcrStatus();
            if(lockForOcr == 0 && VendorInvoiceConstants.OCR_NOT_STARTED_PLD.equals(ocrStatus)) {
            	query.append(",retry_count = (COALESCE(retry_count,0)+1) ");
            }
            query.append(" where file_id =? ");
	        jdbcTemplateTrn.update(query.toString(), ocrStatus,lockForOcr,fileId);

	    }
	 
	 
	 @Override
		public LinkedHashMap<Integer, String> getFilesToPullOcr() {
			return jdbcTemplateTrn.query(FileOcrSql.GET_OCR_PULL_PENDING,
					new ResultSetExtractor<LinkedHashMap<Integer, String>>() {
						@Override
						public LinkedHashMap<Integer, String> extractData(ResultSet rs)
								throws SQLException, DataAccessException {
							LinkedHashMap<Integer, String> mapRet = new LinkedHashMap<>();
							while (rs.next()) {
								mapRet.put(rs.getInt("file_id"), rs.getString("ack_no"));
							}
							return mapRet;
						}
					},VendorInvoiceConstants.OCR_PULL_STATUS_PENDING);

		}
	 
	 @Override
		public void updateOcrPullLog(OcrPullLogDto ocrPullLogDto) {
		 jdbcTemplateTrn.update(FileOcrSql.UPDATE_OCR_PULL_LOG, ocrPullLogDto.getOcrExtractedData(), ocrPullLogDto.getPayload(), ocrPullLogDto.getReqOn(),ocrPullLogDto.getRecievedOn(),
                 ocrPullLogDto.getStatus(), ocrPullLogDto.getErrorDesc(),ocrPullLogDto.getFileId());
		
		}
	 
	 @Override
	    public Integer insertVerticalMapArchive(Integer fileId) {

	        return jdbcTemplateTrn.update(connection -> {
	            PreparedStatement ps = connection.prepareStatement(FileOcrSql.INSERT_VERTICAL_MAP_ARCHIVE_SQL,
	                            Statement.RETURN_GENERATED_KEYS);
	            ps.setObject(1, fileId);
	            return ps;
	        });
	    }
	 
	 @Override
	    public Integer deleteVerticalMapDetails(Integer fileId) {
	        return jdbcTemplateTrn.update(connection -> {
	            PreparedStatement ps = connection.prepareStatement(FileOcrSql.DELETE_VERTICAL_MAP_SQL,
	                            Statement.RETURN_GENERATED_KEYS);
	            ps.setObject(1, fileId);
	            return ps;
	        });
	    }
	 
	 @Override
	  public void insertIntoComplianceErrorTable(List<OcrComplianceErrorDto> data) throws VendorInvoiceServerException {

	        jdbcTemplateTrn.batchUpdate(FileOcrSql.INSERT_TO_OCR_COMPLIANCE_ERROR, data, 100,
	                        (PreparedStatement ps, OcrComplianceErrorDto item) -> {
	                            ps.setString(1, item.getErrorCode());
	                            ps.setInt(2, item.getFileId());
	                            ps.setInt(3, item.getOcrMstId());
	                            ps.setInt(4, item.getLineNo());
	                            ps.setInt(5, item.getPldErrorType());
	                            

	                        });
	 }
	 
	 @Override
	    public List<OcrComplianceErrorDto> getOcrComplianceValidation(int fileId,int errorType) {
		        return jdbcTemplateTrn.query(FileOcrSql.GET_COMPLIANCE_ERROR_ISSUES,
		        		new RowMapper<OcrComplianceErrorDto>() {
		            public OcrComplianceErrorDto mapRow(ResultSet rs, int rowNum)
		                            throws SQLException {
		                return OcrComplianceErrorDto.builder()
		                		        .errorCode(rs.getString("error_code"))
		                		        .errorDesc(rs.getString("error_desc"))
		                		        .riskCategory(rs.getInt("risk_catagory"))
		                		        .lineNo(rs.getInt("line_no"))
		                		        .pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
		            }
		        },fileId,errorType);
	    	}
	 
	 
	 @Override
	 public List<UploadReqDTO> getUploadHstoryByBatchNo(String batchNos) {
		 String query = FileOcrSql.getUploadHistoryByBatchNo(batchNos);
		 return jdbcTemplateTrn.query(query, new ResultSetExtractor<List<UploadReqDTO>>() {

             // here we get upload history data from database.
             public List<UploadReqDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
                 List<UploadReqDTO> uploadReqDTOList = new ArrayList<>();
                 while (rs.next()) {
                	 UploadReqDTO uploadReqDTO = new UploadReqDTO();
                	 uploadReqDTO.setFp(new ArrayList<>(Arrays.asList(rs.getString("fp"))));
                	 uploadReqDTO.setGstinOrPanList(new ArrayList<>(Arrays.asList(rs.getString("taxpayer_gstin"))));
                	 uploadReqDTO.setBatchNo(rs.getString("batch_no"));
                	 uploadReqDTOList.add(uploadReqDTO);
                 }
                 return uploadReqDTOList;
             }

         });
	 
	 }
	 
	 @Override
	    public Integer deleteFromInvoiceHeader(String batchNo) {
	        return jdbcTemplateTrn.update(connection -> {
	            PreparedStatement ps = connection.prepareStatement(FileOcrSql.DELETE_INVOICE_HEADER_SQL,
	                            Statement.RETURN_GENERATED_KEYS);
	            ps.setObject(1, batchNo);
	            return ps;
	        });
	    }
	 
	 @Override
	    public Integer deleteFromInvoiceEWBDetails(String batchNo) {
	        return jdbcTemplateTrn.update(connection -> {
	            PreparedStatement ps = connection.prepareStatement(FileOcrSql.DELETE_INVOICE_EWB_DETAILS_SQL,
	                            Statement.RETURN_GENERATED_KEYS);
	            ps.setObject(1, batchNo);
	            return ps;
	        });
	    }
	 
	 @Override
	    public String getStateCodeByStateName(String stateName) {
	        List<String> stateCodes = jdbcTemplateMst.queryForList(FileOcrSql.GET_STATE_CODE_BY_STATENAME_SQL,String.class, VendorInvoiceConstants.STATE_NAME,stateName);
	        if(!stateCodes.isEmpty()) {
	        	return stateCodes.get(0);
	        }
	        else {
	        	return "";
	        }
	    }
	 
}
