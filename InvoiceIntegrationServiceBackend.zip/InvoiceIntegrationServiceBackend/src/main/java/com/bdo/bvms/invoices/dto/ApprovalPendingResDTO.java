package com.bdo.bvms.invoices.dto;

import java.time.LocalDateTime;

import com.bdo.bvms.invoices.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class ApprovalPendingResDTO {

    int id;
    String taxpayerGstin;
    String getType;
    String vendorGstin;
    String vendorLegalName;
    String vendorTradeName;
    String invoiceNo;
    String invoiceDate;
    String ewayBillNo;
    String ewayBillDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
    LocalDateTime uploadDate;
    String uploadedBy;
    String batchNo;
    String documentStatus;
    String action;
    long isDuplicate;

    int totalCount;
    Long wfMstId;
    String docType;
    String irnVerified;
    String supplyType;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
    LocalDateTime rejectedDate;
    String rejectedBy;
    String fileType;
    String poNumber;
    String grnNumber;
    String vendorCodeErp;

}
