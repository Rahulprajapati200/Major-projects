package com.bdo.bvms.ewaybill.api.impl;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.bdo.bvms.ewaybill.api.GetEwayBillApiDao;
import com.bdo.bvms.ewaybill.api.dto.BDOAuthDTO;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.ewaybill.api.dto.NicAuthResponseDTO;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EWayBillBDOAuthentication {

    public static final String CLASSNAME = "EWayBillBDOAuthentication";

    @Autowired
    GetEwayBillApiDao getEwayBillApiDaoImpl;

    static RestTemplate restTemplate = new RestTemplate();

    public String bdoAuthEWB(String clientId, String clientSecKey, GetEwayBillReqDTO getEwayBillReqDTO, int pldGetType)
                    throws InvoiceIntegrationEWBException {

        String methodName = "bdoAuthEWB";

        log.info("className: " + CLASSNAME + " methodName: " + methodName + "started");

        String bdoAuthURL = getEwayBillApiDaoImpl.getBdoAuthUrl();
        String bdoAuthKey = getEwayBillApiDaoImpl.getBdoAuthKey();
        JSONObject bdoAuthRes = null;

        if (StringUtils.isBlank(bdoAuthKey)) {
            JSONObject bdoAuthJSONRequest = new JSONObject();

            bdoAuthJSONRequest.put("clientid", clientId);
            bdoAuthJSONRequest.put("clientsecretencrypted", clientSecKey);

            HttpHeaders bdoAuthHeaders = new HttpHeaders();
            bdoAuthHeaders.setContentType(MediaType.APPLICATION_JSON);

            try {
                HttpEntity<String> entity = new HttpEntity<String>(bdoAuthJSONRequest.toString(), bdoAuthHeaders);
                bdoAuthRes = new JSONObject(restTemplate.postForObject(bdoAuthURL, entity, String.class));

                BDOAuthDTO bdoAuthDTO = new BDOAuthDTO();
                if (bdoAuthDTO != null) {

                    bdoAuthDTO.setBdoAuthToken(bdoAuthRes.get("bdo_auth_token").toString());
                    bdoAuthDTO.setStatus(bdoAuthRes.get("status").toString());
                    bdoAuthDTO.setPlayLoad(bdoAuthJSONRequest.toString());
                    bdoAuthDTO.setExpiry(DateUtil.convertDateFormat(Constants.DATE_FORMAT_E_MMM_DD_HH_MM_SS_ZONE_YEAR,
                                    Constants.DATE_FORMAT_YYYY_MM_DD_HH_MM_SS, bdoAuthRes.get("expiry").toString()));

                    getEwayBillApiDaoImpl.insertToBdoAuthApiCall(bdoAuthDTO);
                    log.info("className: " + CLASSNAME + " methodName: " + methodName + "completed");
                    return (String) bdoAuthRes.get("bdo_auth_token");
                }

            } catch (Exception e) {
                log.error("Error generated in the method bdoAuthEWB:::", e);
                BDOAuthDTO bdoAuthDTO = new BDOAuthDTO();
                bdoAuthDTO.setStatus("0");
                bdoAuthDTO.setPlayLoad(bdoAuthJSONRequest.toString());
                bdoAuthDTO.setErrorDescription(e.getMessage());
                bdoAuthDTO.setIsException("1");
                getEwayBillApiDaoImpl.insertToBdoAuthApiCall(bdoAuthDTO);

                if (bdoAuthRes != null) {
                    getEwayBillApiDaoImpl.insertToEwayBillApiCall(new NicAuthResponseDTO(),
                                    getEwayBillReqDTO.getTaxpayerGstin(), getEwayBillReqDTO, e.getMessage(), pldGetType,
                                    bdoAuthRes.toString(),Constants.EWB_GET_STATUS_FAIL);
                } else {
                    getEwayBillApiDaoImpl.insertToEwayBillApiCall(new NicAuthResponseDTO(),
                                    getEwayBillReqDTO.getTaxpayerGstin(), getEwayBillReqDTO, e.getMessage(), pldGetType,
                                    null,Constants.EWB_GET_STATUS_FAIL);
                }

                if (e instanceof JSONException) {
                    // markBDOKeyInactive(bdoAuthKey);
                    throw new InvoiceIntegrationEWBException("Basic Authentication failed , please retry");
                } else if (e.getMessage().indexOf("Hystrix Readed time out") > 0) {
                    throw new InvoiceIntegrationEWBException(
                                    "BDO Authentication service is not responding , please retry after some time");
                }

                throw new InvoiceIntegrationEWBException(e.getMessage());

            }

        }

        log.info("className: " + CLASSNAME + " methodName: " + methodName + "completed");
        return bdoAuthKey;

    }

    /*
     * public int markBDOKeyInactive(String key) { return
     * getEwayBillApiDaoImpl.markBDOKeyInactive(key); }
     */

    public int markNICKeyInactive(String gstin, String sek) {
        return getEwayBillApiDaoImpl.markNICKeyInactive(gstin, sek);
    }

}
