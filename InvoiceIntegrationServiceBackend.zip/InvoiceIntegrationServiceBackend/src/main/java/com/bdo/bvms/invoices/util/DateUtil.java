package com.bdo.bvms.invoices.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DateUtil {

    private DateUtil() {

    }

    public static final String DATEFOEMATTERFORUI = "dd-MM-yyyy";

    public static final String DATETIMEFORMATTERFORUI = "dd-MM-yyyy HH:mm:ss";

    public static final String DATETIMEFORMATTERFORDB = "yyyy-MM-dd HH:mm:ss";
    public static final String DATEFORMATTERFORDB = "yyyy-MM-dd";
    public static final String DATEFORMATTEREWAYBILLDATE = "E MMM dd HH:mm:ss Z yyyy";

    public static final String DATEFOEMATTERHAVINGBACKSLASH = "dd/MM/yyyy";

    public static String getFormatedDate(String date) {

        String returnDate = date;

        if (StringUtils.isBlank(date)) {
            return returnDate;
        }

        String datePatternyyyymmddDash = "\\d{4}-\\d{1,2}-\\d{1,2}";
        String datePatternddmmyyyyDash = "\\d{1,2}-\\d{1,2}-\\d{4}";
        String datePatternddmmyyyySlash = "\\d{1,2}/\\d{1,2}/\\d{4}";
        String datePatternyyyymmddSlash = "\\d{4}/\\d{1,2}/\\d{1,2}";
        String datePatternyyyymmmddDash = "\\d{4}-\\d{1,2}-\\d{1,2}";
        String datePatternddmmmyyyyDash = "\\d{1,2}-\\d{1,2}-\\d{4}";
        String datePatternddmmmyyyySlash = "\\d{1,2}/\\d{1,2}/\\d{4}";
        String datePatternyyyymmmddSlash = "\\d{4}/\\d{1,2}/\\d{1,2}";

        if (date.matches(datePatternyyyymmddDash)) {
            if (date.contains("-")) {
                String[] splitedDate = date.split("-");
                returnDate = splitedDate[0] + "-" + splitedDate[1] + "-" + splitedDate[2];
            }
        } else if (date.matches(datePatternddmmyyyyDash)) {

            if (date.contains("-")) {
                String[] splitedDate = date.split("-");
                returnDate = splitedDate[0] + "-" + splitedDate[1] + "-" + splitedDate[2];
            }

        } else if (date.matches(datePatternddmmyyyySlash)) {

            if (date.contains("/")) {
                String[] splitedDate = date.split("/");
                returnDate = splitedDate[0] + "-" + splitedDate[1] + "-" + splitedDate[2];
            }
        } else if (date.matches(datePatternyyyymmddSlash)) {

            if (date.contains("/")) {
                String[] splitedDate = date.split("/");
                returnDate = splitedDate[2] + "-" + splitedDate[1] + "-" + splitedDate[0];
            }
        } else if (date.matches(datePatternyyyymmmddDash)) {
            if (date.contains("-")) {
                String[] splitedDate = date.split("-");
                returnDate = splitedDate[0] + "-" + getMonth(splitedDate[1]) + "-" + splitedDate[2];
            }
        } else if (date.matches(datePatternddmmmyyyyDash)) {

            if (date.contains("-")) {
                String[] splitedDate = date.split("-");
                returnDate = splitedDate[0] + "-" + getMonth(splitedDate[1]) + "-" + splitedDate[2];
            }

        } else if (date.matches(datePatternddmmmyyyySlash)) {

            if (date.contains("/")) {
                String[] splitedDate = date.split("/");
                returnDate = splitedDate[0] + "-" + getMonth(splitedDate[1]) + "-" + splitedDate[2];
            }
        } else if (date.matches(datePatternyyyymmmddSlash) && date.contains("/")) {

            String[] splitedDate = date.split("/");
            returnDate = splitedDate[2] + "-" + getMonth(splitedDate[1]) + "-" + splitedDate[0];
        }

        return returnDate;
    }

    static String getMonth(String monthName) {

        String monthNo = "";
        if ("Jan".equals(monthName)) {
            monthNo = "01";
        } else if ("Feb".equals(monthName)) {
            monthNo = "02";
        } else if ("Mar".equals(monthName)) {
            monthNo = "03";
        } else if ("Apr".equals(monthName)) {
            monthNo = "04";
        } else if ("May".equals(monthName)) {
            monthNo = "05";
        } else if ("Jun".equals(monthName)) {
            monthNo = "06";
        } else if ("Jul".equals(monthName)) {
            monthNo = "07";
        } else if ("Aug".equals(monthName)) {
            monthNo = "08";
        } else if ("Sep".equals(monthName)) {
            monthNo = "09";
        } else if ("Oct".equals(monthName)) {
            monthNo = "10";
        } else if ("Nov".equals(monthName)) {
            monthNo = "11";
        } else if ("dec".equals(monthName)) {
            monthNo = "12";
        }
        return monthNo;
    }

    public static String convertDateToString(Date date, String formatter) {
        if (date == null || StringUtils.isAllBlank(formatter)) {
            return null;
        }

        // Converts the string
        // format to date object
        DateFormat df = new SimpleDateFormat(formatter);

        // Convert the date into a
        // string using format() method
        String dateToString = df.format(date);

        // Return the result
        return (dateToString);
    }

    public static String convertDBtoScreen(String strdate) {
        if (StringUtils.isNoneBlank(strdate)) {
            SimpleDateFormat fromFormatter = new SimpleDateFormat(DATETIMEFORMATTERFORDB);
            SimpleDateFormat toFormatter = new SimpleDateFormat(DATETIMEFORMATTERFORUI);
            try {
                Date date = fromFormatter.parse(strdate);
                return toFormatter.format(date);
            } catch (ParseException ex) {
                log.error("Error occured while execute convertDBtoScreen function:", ex);
                return strdate;
            }
        } else {
            return strdate;
        }

    }

    public static String convertLocalDateTimeIntoStringFormat(LocalDateTime strdate1) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        if (strdate1 == null) {
            return "-";
        }

        String strdate = strdate1.format(formatter);
        if (StringUtils.isNoneBlank(strdate)) {
            SimpleDateFormat fromFormatter = new SimpleDateFormat(DATETIMEFORMATTERFORDB);
            SimpleDateFormat toFormatter = new SimpleDateFormat(DATETIMEFORMATTERFORUI);
            try {
                Date date = fromFormatter.parse(strdate);
                return toFormatter.format(date);
            } catch (ParseException ex) {
                log.error("Error occured while execute convertDBtoScreen function:", ex);
                return strdate;
            }
        } else {
            return strdate;
        }

    }

    public static String convertDateFormattoScreen1(String strdate) {
        if (StringUtils.isNoneBlank(strdate)) {
            SimpleDateFormat fromFormatter = new SimpleDateFormat(DATETIMEFORMATTERFORDB);
            SimpleDateFormat toFormatter = new SimpleDateFormat(DATEFOEMATTERFORUI);
            try {
                Date date = fromFormatter.parse(strdate);
                return toFormatter.format(date);
            } catch (ParseException ex) {
                log.error("Error occured while execute convertDateFormattoScreen1 function:", ex);
                return strdate;
            }
        } else {
            return strdate;
        }

    }

    public static String convertDateFormattoScreen2(String strdate) {
        if (StringUtils.isNoneBlank(strdate)) {
            try {
                return strdate.replace("/", "-");
            } catch (Exception ex) {
                log.error("Error occured while execute convertDateFormattoScreen2 function:", ex);
                return strdate;
            }
        } else {
            return strdate;
        }

    }

    public static String convertDateFormattoUiToEwbOtherPartyApi(String strdate) {
        if (StringUtils.isNoneBlank(strdate)) {
            try {
                return strdate.replace("-", "/");
            } catch (Exception ex) {
                log.error("Error occured while execute convertDateFormattoUiToEwbOtherPartyApi function:", ex);
                return strdate;
            }
        } else {
            return strdate;
        }

    }

    public static String convertDateToFillingPeriod(String strdate) {
        if (StringUtils.isNoneBlank(strdate)) {
            try {
                return (strdate.replace("/", "")).replace("-", "").substring(2);
            } catch (Exception ex) {
                log.error("Error occured while execute convertDateToFillingPeriod function:", ex);
                return strdate;
            }
        } else {
            return strdate;
        }

    }

    public static String convertDateFormatType3(String strdate) {
        if (StringUtils.isNoneBlank(strdate)) {
            SimpleDateFormat fromFormatter = new SimpleDateFormat(DATEFORMATTEREWAYBILLDATE);
            SimpleDateFormat toFormatter = new SimpleDateFormat(DATEFOEMATTERFORUI);
            try {
                Date date = fromFormatter.parse(strdate);
                return toFormatter.format(date);
            } catch (ParseException ex) {
                log.error("Error occured while execute convertDateFormatType3 function:", ex);
                return strdate;
            }
        } else {
            return strdate;
        }
    }

    public static String convertDateFormatType4(String strdate) {
        if (StringUtils.isNoneBlank(strdate)) {
            SimpleDateFormat fromFormatter = new SimpleDateFormat(DATEFORMATTERFORDB);
            SimpleDateFormat toFormatter = new SimpleDateFormat(DATEFOEMATTERHAVINGBACKSLASH);
            try {
                Date date = fromFormatter.parse(strdate);
                return toFormatter.format(date);
            } catch (ParseException ex) {
                log.error("Error occured while execute convertDateFormatType4 function:", ex);
                return strdate;
            }
        } else {
            return strdate;
        }
    }

    public static String convertDateFormat(String fromDateFormat, String toDateFormat, String dateValue) {
        DateFormat formatter = new SimpleDateFormat(fromDateFormat);
        DateFormat formatTo = new SimpleDateFormat(toDateFormat);
        Date date = null;
        try {
            date = (Date) formatter.parse(dateValue);
        } catch (ParseException e) {
            log.error("Error occured while execute convertDateFormat function:", e);

        }
        return formatTo.format(date);

    }

    public static Timestamp convertDateFormatToTimestamp(String fromDateFormat, String dateValue) {
        DateFormat formatter = new SimpleDateFormat(fromDateFormat);

        Timestamp date = null;
        try {
            date = (Timestamp) formatter.parse(dateValue);
        } catch (ParseException e) {
            log.error("Error occured while execute convertDateFormatToTimestamp function:", e);

        }
        return date;

    }

}