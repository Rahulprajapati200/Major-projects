package com.bdo.bvms.invoices.dao;

import java.util.List;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.ProcessedListDataResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface VendorInvoiceProcessedDataListDao {

    List<ProcessedListDataResDTO> getProcessedInvoiceDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException;

}
