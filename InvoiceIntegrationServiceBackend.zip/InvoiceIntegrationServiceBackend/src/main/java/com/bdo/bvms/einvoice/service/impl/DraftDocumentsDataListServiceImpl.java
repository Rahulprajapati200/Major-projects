package com.bdo.bvms.einvoice.service.impl;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.DraftDocumentsDataListService;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.VendorJourneyDataListDao;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class DraftDocumentsDataListServiceImpl implements DraftDocumentsDataListService {

	@Autowired
	VendorJourneyDataListDao vendorJourneyDataListDao;

	@Override
	public Map<String, Object> getdraftDocumentsDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
			String gstinNewList, String monthList) throws VendorInvoiceServerException {
		Map<String, Object> data;
		try {
			data = new LinkedHashMap<>();
			int totalCount = 0;

			data.put("totalPageElements", totalCount);

		} catch (Exception e) {
			log.error("Exception in getdraftDocumentsDataGrid", e);
			throw new VendorInvoiceServerException(e.getMessage());
		}

		return data;

	}

}
