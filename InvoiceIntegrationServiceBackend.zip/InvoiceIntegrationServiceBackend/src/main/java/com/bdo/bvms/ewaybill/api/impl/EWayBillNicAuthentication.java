package com.bdo.bvms.ewaybill.api.impl;

import java.io.File;
import java.security.PublicKey;
import java.util.Base64;
import java.util.Collections;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import com.bdo.bvms.einvoice.vendor.service.UploadNDownloadFileService;
import com.bdo.bvms.ewaybill.api.GetEwayBillApiDao;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.ewaybill.api.dto.NicAuthResponseDTO;
import com.bdo.bvms.ewaybill.api.dto.TaxpayerDetailsDTO;
import com.bdo.bvms.ewaybill.api.utils.Encryption;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.vendor.dao.CommonDao;

import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EWayBillNicAuthentication {

    public static final String CLASSNAME = "EWayBillNicAuthentication";

    @Autowired
    GetEwayBillApiDao getEwayBillApiDaoImpl;

    @Autowired
    CommonDao vendorJourneyCommonDao;

    @Autowired
    UploadNDownloadFileService uploadFileService;

    @Autowired
    EWayBillBDOAuthentication eWayBillBDOAuthentication;

    @Value("${temp.folder.path}")
    String tempFolder;

    static RestTemplate restTemplate = new RestTemplate();

    /**
     * Nic auth EWB.
     *
     * @param bdoAuthkey
     *            the bdo authkey
     * @param clientId
     *            the client id
     * @param clientSecretenCrypted
     *            the client secreten crypted
     * @param getEwayBillReqDTO
     *            the get eway bill req DTO
     * @param pldGetType
     *            the pld get type
     * @param taxpayerDetails
     *            the taxpayer details
     * @return the nic auth response DTO
     * @throws InvoiceIntegrationEWBException
     *             the invoice integration EWB exception
     */
    public NicAuthResponseDTO nicAuthEWB(String bdoAuthkey, String clientId, String clientSecretenCrypted,
                    GetEwayBillReqDTO getEwayBillReqDTO, int pldGetType, TaxpayerDetailsDTO taxpayerDetails)
                    throws InvoiceIntegrationEWBException {
         
    	NicAuthResponseDTO nicAuthResponseDTO = new NicAuthResponseDTO();
        JSONObject nicResponce = null;
        String methodName = "nicAuthEWB";
        log.info("className: " + CLASSNAME + " methodName: " + methodName + "started");
        int id ;
        try {
            String appKey = getEwayBillApiDaoImpl.getEwayBillAppKey();
            String nicAuthURL = getEwayBillApiDaoImpl.getNicAuthUrl();

            NicAuthResponseDTO nicAuthDBResponse = getEwayBillApiDaoImpl
                            .getNicAuthKey(getEwayBillReqDTO.getTaxpayerGstin());
            if (nicAuthDBResponse != null && nicAuthDBResponse.getNicAuthToken() != null) {

                log.info("className: " + CLASSNAME + " methodName: " + methodName + "completed");
                return nicAuthDBResponse;

            }

            String sandboxFileName = "";
            if (StringUtils.isNotBlank(tempFolder)) {
                sandboxFileName = new StringBuilder()
                                .append(tempFolder + File.separator + Constants.SANDBOX_KEY_FILENAME).toString();
            }
            File fle = new File(sandboxFileName);
            if (!fle.exists()) {
                AzureConnectionCredentialsDTO storageCredentials = vendorJourneyCommonDao.getAzureCredentialFromDB(getEwayBillReqDTO.getEntityId(),
                                "blob");
                uploadFileService.downloadFileFromAzureBlob(Constants.SANDBOX_KEY_FILENAME, tempFolder,
                                storageCredentials);
            }
            HttpHeaders bdoAuthHeaders = new HttpHeaders();

            HttpHeaders nicAuthenticationHeader = new HttpHeaders();
            nicAuthenticationHeader.set("ClientId", clientId);
            nicAuthenticationHeader.set("client-secret", clientSecretenCrypted);

            nicAuthenticationHeader.set("bdo_auth_token", bdoAuthkey);

            nicAuthenticationHeader.set("Gstin", getEwayBillReqDTO.getTaxpayerGstin());

            JSONObject nicAuthenticationRequest = new JSONObject();
            nicAuthenticationRequest.put("action", Constants.ACTION_TOKEN);
            nicAuthenticationRequest.put("username", taxpayerDetails.getEwbUsername());

            nicAuthenticationRequest.put("password", taxpayerDetails.getEwbPassword());

            nicAuthenticationRequest.put("app_key", Base64.getEncoder().encodeToString(appKey.getBytes()));

            File file = ResourceUtils.getFile(sandboxFileName);
            String encodedString = Base64.getEncoder().encodeToString(nicAuthenticationRequest.toString().getBytes());

            PublicKey publicKey = Encryption.getPublic(file.getPath());
            String dataForNICAuth = Encryption.encryptTextWithPublicKey(encodedString, publicKey);

            JSONObject nicAuthReqBody = new JSONObject();
            nicAuthReqBody.put("Data", dataForNICAuth);

            bdoAuthHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            
            if(log.isDebugEnabled()) {
            log.debug(nicAuthReqBody.toString());
            }
            nicAuthResponseDTO.setInHeader(nicAuthenticationHeader.toString());
            nicAuthResponseDTO.setInData(nicAuthReqBody.toString());
            nicAuthResponseDTO.setBdoAuthId(getEwayBillApiDaoImpl.getBdoAuthId(bdoAuthkey));

            nicAuthResponseDTO.setTaxpayerGstin(getEwayBillReqDTO.getTaxpayerGstin());
            id = getEwayBillApiDaoImpl.insertIntoExternalApiCallLog(nicAuthResponseDTO);
            nicAuthResponseDTO.setId(id);

            HttpEntity<String> httpEntity = new HttpEntity<>(nicAuthReqBody.toString(), nicAuthenticationHeader);

            ResponseEntity<String> response = restTemplate.exchange(nicAuthURL, HttpMethod.POST, httpEntity,
                            String.class);
            if(response.toString().contains("BDO AUTHTOKEN IS NOT VALID")) {
            	throw new InvoiceIntegrationEWBException("Nic Authentication failed for taxpayerGstin "+getEwayBillReqDTO.getTaxpayerGstin()+" , Kindly contact to administrator");
            }
            
            if(log.isDebugEnabled()) {
            log.debug(response.toString());
            }
            nicResponce = new JSONObject(response.getBody());           
            if (nicResponce != null) {
                nicAuthResponseDTO.setNicAuthToken(nicResponce.getString("authtoken").toString());
                nicAuthResponseDTO.setNicSek(nicResponce.getString("sek"));
            }
            
            getEwayBillApiDaoImpl.updateExternalApiCallLogSuccess(nicAuthResponseDTO);
            
            log.info("className: " + CLASSNAME + " methodName: " + methodName + "completed");
            return nicAuthResponseDTO;
        } catch (Exception e) {
            log.error("Error occured while execute getNicAuthKey function:", e);

            nicAuthResponseDTO.setIsException("1");
            nicAuthResponseDTO.setErrorDescription(e.getMessage());
            getEwayBillApiDaoImpl.updateExternalApiCallLogFail(nicAuthResponseDTO);

            if (nicResponce != null) {
                getEwayBillApiDaoImpl.insertToEwayBillApiCall(nicAuthResponseDTO, getEwayBillReqDTO.getTaxpayerGstin(),
                                getEwayBillReqDTO, "Nic Authentication failed", pldGetType, nicResponce.toString(),Constants.EWB_GET_STATUS_FAIL);
            } else {
                getEwayBillApiDaoImpl.insertToEwayBillApiCall(nicAuthResponseDTO, getEwayBillReqDTO.getTaxpayerGstin(),
                                getEwayBillReqDTO, "Nic Authentication failed", pldGetType, null,Constants.EWB_GET_STATUS_FAIL);
            }
            if (e instanceof JSONException) {
                // eWayBillBDOAuthentication.markBDOKeyInactive(bdoAuthkey);
                eWayBillBDOAuthentication.markNICKeyInactive(getEwayBillReqDTO.getTaxpayerGstin(),
                                nicAuthResponseDTO.getNicSek());
                throw new InvoiceIntegrationEWBException("Nic Authentication failed for taxpayerGstin "
                                + getEwayBillReqDTO.getTaxpayerGstin() + " , Kindly contact to administrator");
            }
            throw new InvoiceIntegrationEWBException(e.getMessage());

        }

    }

}
