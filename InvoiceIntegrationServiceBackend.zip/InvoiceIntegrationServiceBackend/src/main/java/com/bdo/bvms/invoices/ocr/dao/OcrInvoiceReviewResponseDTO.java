package com.bdo.bvms.invoices.ocr.dao;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class OcrInvoiceReviewResponseDTO {
	
    Integer verticalMapId;
    Integer fileId;
    Integer ocrVendorTemplateMstId;
    Integer ocrFieldMstId;
    String ocrExtractedValue;
    Integer ocrAccuracyLvl;
    Integer ocrAccuracyLvlValue;
    Integer lineNo;
    Integer isHeader;
    String labelName;
    Integer minLength;
    Integer maxLength;
    String regexStr;
    String type;
    Integer dataTypeId;
    Boolean isMandatory;
    Integer riskCategory;
    Boolean isAmountField;
    int order;
    

}
