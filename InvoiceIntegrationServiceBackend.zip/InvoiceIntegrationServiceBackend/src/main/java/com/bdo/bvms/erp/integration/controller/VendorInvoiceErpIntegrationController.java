package com.bdo.bvms.erp.integration.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.erp.integration.dto.APIResponseDTO;
import com.bdo.bvms.erp.integration.dto.ERPAPIResponseDTO;
import com.bdo.bvms.erp.integration.dto.ERPRequestDTO;
import com.bdo.bvms.erp.integration.dto.ErpInvoiceIntegrationRequestDto;
import com.bdo.bvms.erp.integration.service.VendorInvoiceErpIntegrationService;
import com.bdo.bvms.invoices.custom.exception.AzureUploadDownloadException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceSavedataOnUploadException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;

import lombok.extern.slf4j.Slf4j;


@RestController
@RequestMapping("/ws/api")
public class VendorInvoiceErpIntegrationController {

	
	    @Autowired
	    VendorInvoiceErpIntegrationService vendorInvoiceErpIntegrationService;
	 
	    @PostMapping(value = "/upload_file_for_ocr",produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<Object> uploadFileForOcr(HttpServletRequest httpServletRequest,@RequestBody ErpInvoiceIntegrationRequestDto reqDto) throws VendorInvoiceServerException, AzureUploadDownloadException, VendorInvoiceSavedataOnUploadException {
	    	ERPRequestDTO dbERPDetailsDto=vendorInvoiceErpIntegrationService.getdbErpDetails();
	    	if(!reqDto.getAppKey().equals(dbERPDetailsDto.getAppKey()) || !reqDto.getClientSecret().equals(dbERPDetailsDto.getClientSecret()))
	    	{
	    		return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
	                     .acknowledgementNo(null)
	                    .message("Invalid App Key or Client Secret").tag(httpServletRequest.getRequestURI()).build());
	    	}
	        return ResponseEntity.ok().body(ERPAPIResponseDTO.builder().status(1)
	                        .data(vendorInvoiceErpIntegrationService.processForOcrFileUpload(reqDto))
	                        .message("File Uploaded Successfully").tag(httpServletRequest.getRequestURI()).build());


	    }
	    
	    @PostMapping(value = "/fetch_ocr_invoice_details_with_line_items",produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<Object> uploadFileForOcr(HttpServletRequest httpServletRequest,
	    		@RequestParam(required = true) String appKey,@RequestParam(required = true) String clientSecret,
	    		@RequestParam(required = true) String ackNo) {
	    	ERPRequestDTO dbERPDetailsDto=vendorInvoiceErpIntegrationService.getdbErpDetails();
	    	if(!appKey.equals(dbERPDetailsDto.getAppKey()) || !clientSecret.equals(dbERPDetailsDto.getClientSecret()))
	    	{
	    		return ResponseEntity.ok().body(APIResponseDTO.builder().status(1)
	                     .acknowledgementNo(null)
	                    .message("Invalid App Key or Client Secret").tag(httpServletRequest.getRequestURI()).build());
	    	}
	        return ResponseEntity.ok().body(ERPAPIResponseDTO.builder().status(1)
	                        .data(vendorInvoiceErpIntegrationService.getVendorinvoiceJson(ackNo))
	                        .message(null).tag(httpServletRequest.getRequestURI()).build());


	    }
}
