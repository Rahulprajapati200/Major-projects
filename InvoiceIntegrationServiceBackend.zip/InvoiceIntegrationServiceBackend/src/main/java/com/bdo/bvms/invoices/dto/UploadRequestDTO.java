package com.bdo.bvms.invoices.dto;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
public class UploadRequestDTO extends BaseReqDTO {

    String gstinOrPan;
    MultipartFile[] file;
    String fileType;
    String templatetypepldCode;
    List<String> fp;

    String po;
    String poDate;
    List<String> gstinOrPanList;
    int moduleID;
    String customtemplateID;
    String isCustomTemplate;

    String vendorGstin;
    String invoiceNo;
    String invoiceDate;
    String paBatchNo;
    String docType;
    
    String sftpBatchedFilename;
    String uploadSftpSource;
    String sftpFileName;
    
    String isVendorPan;
    String vendorPanOrGstin;
    String vendorCode;
}
