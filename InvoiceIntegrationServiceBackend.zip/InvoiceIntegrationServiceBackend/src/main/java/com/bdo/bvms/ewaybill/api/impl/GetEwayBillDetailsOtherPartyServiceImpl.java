package com.bdo.bvms.ewaybill.api.impl;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.bdo.bvms.ewaybill.api.GetEwayBillApiDao;
import com.bdo.bvms.ewaybill.api.GetEwayBillDetailsService;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.ewaybill.api.dto.NicAuthResponseDTO;
import com.bdo.bvms.ewaybill.api.dto.TaxpayerDetailsDTO;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.dto.EWBGenByOtherPartyDTO;
import com.bdo.bvms.invoices.dto.EWBGenByOtherPartyResponseDTO;
import com.bdo.bvms.invoices.dto.EwayBillheaderDTO;
import com.bdo.bvms.invoices.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class GetEwayBillDetailsOtherPartyServiceImpl {

    RestTemplate restTemplate = new RestTemplate();

    @Autowired
    EWayBillBDOAuthentication eWayBillBDOAuthentication;

    @Autowired
    EWayBillNicAuthentication eWayBillNicAuthentication;

    @Autowired
    GetEwayBillApiDao getEwayBillApiDaoImpl;

    @Autowired
    GetEwayBillDetailsService getEwayBillDetailsServiceImpl;

    @Autowired
    GetEwayBillApiDao getEwayBillApiDao;

    @Autowired
    GetEwayBillInvoiceDetailServiceImpl getEwayBillInvoiceDetailServiceImpl;

    public void getEwayBillDetails(GetEwayBillReqDTO reqDto) throws InvoiceIntegrationEWBException {

        EWBGenByOtherPartyResponseDTO resDto = null;

        String clientId = getEwayBillApiDaoImpl.getEwayBillClientId();
        String clientSeckey = getEwayBillApiDaoImpl.getEwayBillClientSecretEncrypted();
        String appKey = getEwayBillApiDaoImpl.getEwayBillAppKey();

        String eWayBillOfOtherPartyApiBaseURL = getEwayBillApiDaoImpl.getEwayBillOtherPartyApiUrl();
        String eWayBillOfOtherPartyApiURL = eWayBillOfOtherPartyApiBaseURL + "?date="
                        + DateUtil.convertDateFormattoUiToEwbOtherPartyApi(reqDto.getEwaybillDate());

        String eWayBillApiBaseURL = getEwayBillApiDaoImpl.getEwayBillApiUrl();

        TaxpayerDetailsDTO taxpayerDetails = getEwayBillApiDaoImpl
                        .getTaxpayerDetailsFromEntityMaster(reqDto.getTaxpayerGstin());

        String bdoAuthKey = eWayBillBDOAuthentication.bdoAuthEWB(clientId, clientSeckey, reqDto,
                        Constants.GET_EWAYBILL_OTHER_PARTY_PLD_CODE);

        NicAuthResponseDTO nicAuthResponseDTO = eWayBillNicAuthentication.nicAuthEWB(bdoAuthKey, clientId, clientSeckey,
                        reqDto, Constants.GET_EWAYBILL_OTHER_PARTY_PLD_CODE, taxpayerDetails);

        EwayBillGeneratedOnYouByOtherParty otherPartyDataAPI = new EwayBillGeneratedOnYouByOtherParty();

        try {
            resDto = otherPartyDataAPI.ewayBillGeneratedOnYouByOtherPartyAPI(appKey, reqDto.getTaxpayerGstin(),
                            clientId, clientSeckey, eWayBillOfOtherPartyApiURL, restTemplate, bdoAuthKey,
                            nicAuthResponseDTO.getNicAuthToken(), nicAuthResponseDTO.getNicSek());
        } catch (Exception e) {
        	 log.error("Error occured in operation::", e);
        	 getEwayBillApiDao.insertToEwayBillApiCall(nicAuthResponseDTO, reqDto.getTaxpayerGstin(), reqDto,
                     "Basic Auth Failed", Constants.GET_EWAYBILL_OTHER_PARTY_PLD_CODE, null,Constants.EWB_GET_STATUS_FAIL);
            if (e instanceof JSONException) {
                eWayBillBDOAuthentication.markNICKeyInactive(reqDto.getTaxpayerGstin(), nicAuthResponseDTO.getNicSek());
                throw new InvoiceIntegrationEWBException("Basic Authentication failed , please retry");
            }

            throw new InvoiceIntegrationEWBException(e.getMessage());
        }

        if (StringUtils.isNotEmpty(resDto.getError())) {

            if ("Invalid auth token".equalsIgnoreCase(resDto.getError())) {
                eWayBillBDOAuthentication.markNICKeyInactive(reqDto.getTaxpayerGstin(), nicAuthResponseDTO.getNicSek());
            }

            getEwayBillApiDao.insertToEwayBillApiCall(nicAuthResponseDTO, reqDto.getTaxpayerGstin(), reqDto,
                            resDto.getError(), Constants.GET_EWAYBILL_OTHER_PARTY_PLD_CODE, resDto.getApiResponse(),Constants.EWB_GET_STATUS_FAIL);

            throw new InvoiceIntegrationEWBException(resDto.getError());

        }

        int ewbApiCallLogId = getEwayBillApiDaoImpl.insertToEwayBillApiCall(nicAuthResponseDTO,
                        reqDto.getTaxpayerGstin(), reqDto, null, Constants.GET_EWAYBILL_OTHER_PARTY_PLD_CODE,
                        resDto.getApiResponse(),Constants.EWB_GET_STATUS_INPROGRESS);

        String eWayBillApiURL = null;
        int noOfSuccessRecords = 0;

        for (EWBGenByOtherPartyDTO d : resDto.getEwbGenByOtherPartysList()) {

            /* for eway bill api details */

            eWayBillApiURL = eWayBillApiBaseURL + "?ewbNo= " + d.getEwbNo();

            EWayBillDetailsApi ewayBillApi = new EWayBillDetailsApi();

            EwayBillheaderDTO ewayBillheaderInfo = ewayBillApi.getEwayBillDetailsAPI(appKey, reqDto.getTaxpayerGstin(),
                            clientId, clientSeckey, eWayBillApiURL, restTemplate, bdoAuthKey,
                            nicAuthResponseDTO.getNicAuthToken(), nicAuthResponseDTO.getNicSek());

            if (reqDto.getTaxpayerGstin().equals(ewayBillheaderInfo.getToGstin())) {
            	noOfSuccessRecords++;
            	ewayBillheaderInfo.setHsncode(d.getHsnCode());
            	ewayBillheaderInfo.setHsndesc(d.getHsnDesc());
                int id = getEwayBillApiDaoImpl.insertToEwayBillHeader(ewbApiCallLogId, ewayBillheaderInfo);

                getEwayBillApiDaoImpl.insertToEwayBillItemDetails(ewayBillheaderInfo.getItemList(), id);
               
                if (ewayBillheaderInfo.getVehiclListDetails() != null
                                && !ewayBillheaderInfo.getVehiclListDetails().isEmpty()) {
                    getEwayBillApiDao.insertToEwayBillVehicleDetails(ewayBillheaderInfo.getVehiclListDetails(), id);
                }

                // insert data to invoice detail
                getEwayBillInvoiceDetailServiceImpl.saveGetEwayBillDetailsToInvoiceDetail(ewayBillheaderInfo,
                                reqDto.getUserId());
            }
        }
      //UPDATE EWB API LOG STATUS
        if(noOfSuccessRecords == 0){
            getEwayBillApiDaoImpl.updateEwayBillApiCallLog(0,Constants.TAXPAYER_GSTIN_NOT_MATCHED,Constants.EWB_GET_STATUS_FAIL,noOfSuccessRecords,ewbApiCallLogId);
        }
        else {
        	getEwayBillApiDaoImpl.updateEwayBillApiCallLog(1,null,Constants.EWB_GET_STATUS_SUCCESS,noOfSuccessRecords,ewbApiCallLogId);
        }
    }

}
