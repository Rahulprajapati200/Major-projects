package com.bdo.bvms.einvoice.service;

import java.util.List;
import java.util.Map;

import com.bdo.bvms.invoices.dto.EInvoiceItemDetailsDTO;
import com.bdo.bvms.invoices.dto.InvoiceReadyDTO;

/**
 * The Interface ProcessedInvoiceService.
 */
public interface ProcessedInvoiceService {

    /**
     * Input grid.
     *
     * @param request the request
     * @return the list
     */
    List<InvoiceReadyDTO> inputGrid(Map<String, Object> request);

    /**
     * Po item details.
     *
     * @param itemDetail the item detail
     * @return the map
     */
    Map<String, Object> poItemDetails(Map<String, Object> itemDetail);

    /**
     * E invoice item detail.
     *
     * @param eInvoiceDetail the e invoice detail
     * @return the list
     */
    List<EInvoiceItemDetailsDTO> eInvoiceItemDetail(Map<String, Object> eInvoiceDetail);

    /**
     * Gstr 2 b item details.
     *
     * @param gst2bDetail the gst 2 b detail
     * @return the list
     */
    List<EInvoiceItemDetailsDTO> gstr2bItemDetails(Map<String, Object> gst2bDetail);

    /**
     * E way item details.
     *
     * @param request the request
     * @return the map
     */
    Map<String, Object> eWayItemDetails(Map<String, Object> request);

}
