package com.bdo.bvms.invoices.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.azure.storage.blob.BlobClientBuilder;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AzureClientProvider {

    static final Logger logger = LoggerFactory.getLogger(AzureClientProvider.class);
    
    private static final String CLASSNAME = "AzureConnectionValidation";

    @Autowired
    CommonDao commonDao;

    public BlobClientBuilder getClient(AzureConnectionCredentialsDTO connectionString) {
        final String methodName = "getClient";
        try {
        	
            BlobClientBuilder client = new BlobClientBuilder();
            client.connectionString(connectionString.getUrl());
            client.containerName(connectionString.getContainerName());
            return client;
        } catch (Exception e) {
            log.error(CLASSNAME, methodName, e + "");
        }
        return null;
    }

}
