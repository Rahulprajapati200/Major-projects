package com.bdo.bvms.einvoice.service;

import java.util.Map;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface VendorInvoicePendingForUserInputDataListService {

    Map<String, Object> getPendingInputDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinList,
                    String monthList) throws VendorInvoiceServerException;

}
