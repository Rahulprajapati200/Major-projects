
package com.bdo.bvms.einvoice.service.impl;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.ParseException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bdo.bvms.einvoice.service.CustomTemplateEWayBillRead;
import com.bdo.bvms.einvoice.service.EwayBillUploadDataService;
import com.bdo.bvms.einvoice.service.UploadLogService;
import com.bdo.bvms.einvoice.service.VendorInvoiceUploadLogHistoryService;
import com.bdo.bvms.ewaybill.api.GetEwayBillApiDao;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.StringConstant;
import com.bdo.bvms.invoices.constant.ValidationConstants;
import com.bdo.bvms.invoices.custom.exception.CsvWriteException;
import com.bdo.bvms.invoices.custom.exception.InvalidTemplateHeaderException;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.custom.exception.InvoiceTemplateUploadException;
import com.bdo.bvms.invoices.custom.exception.ReadInvoiceCustomTemplate;
import com.bdo.bvms.invoices.custom.exception.ReadInvoicePojoListException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.CustomTemplateRepo;
import com.bdo.bvms.invoices.dao.EInvoiceDao;
import com.bdo.bvms.invoices.dao.UploadMasterDao;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.EWayBillDTO;
import com.bdo.bvms.invoices.dto.EwayBillheaderDTO;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.ResponseBean;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceGrnMappingCrudDTO;
import com.bdo.bvms.invoices.taxpayer.sql.LogSQL;
import com.bdo.bvms.invoices.taxpayer.validationrule.EwayBillAlreadySyncedValidation;
import com.bdo.bvms.invoices.taxpayer.validationrule.EwayBillDataTypeValidation;
import com.bdo.bvms.invoices.util.AppUtil;
import com.bdo.bvms.invoices.util.CommonUtils;
import com.bdo.bvms.invoices.util.DateUtil;
import com.csvreader.CsvReader;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.monitorjbl.xlsx.StreamingReader;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class EwayBillUploadDataServiceImpl.
 */
@Service
@Slf4j
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class EwayBillUploadDataServiceImpl implements EwayBillUploadDataService {

    public static final String CLASSNAME = "EwayBillUploadDataServiceImpl";

    @Autowired
    EwayBillPdfOrJpgUploadProcess ewayBillPdfOrJpgUploadProcess;

    @Autowired
    GetEwayBillApiDao getEwayBillApiDao;

    /** The e invoice dao. */
    @Autowired
    EInvoiceDao eInvoiceDao;

    /** The mst databse name. */
    @Value("${mst.database-name}")
    String mstDatabseName;

    /** The custom template repo. */
    @Autowired
    CustomTemplateRepo customTemplateRepo;

    /** The upload trans dao. */
    @Autowired
    UploadTransDao uploadTransDao;

    /** The custom template E way bill read. */
    @Autowired
    CustomTemplateEWayBillRead customTemplateEWayBillRead;

    /** The common dao. */
    @Autowired
    CommonDao commonDao;

    /** The upload log service. */
    @Autowired
    UploadLogService uploadLogService;

    /** The upload N download file service impl. */
    @Autowired
    UploadNDownloadFileServiceImpl uploadNDownloadFileServiceImpl;

    /** The vendor invoice upload log history service. */
    @Autowired
    VendorInvoiceUploadLogHistoryService vendorInvoiceUploadLogHistoryService;

    /** The upload master dao. */
    @Autowired
    UploadMasterDao uploadMasterDao;

    @Autowired
    EwayBillAlreadySyncedValidation ewayBillAlreadySyncedValidation;

    /** The inward INV data type validations. */
    EwayBillDataTypeValidation inwardINVDataTypeValidations = new EwayBillDataTypeValidation();

    /** The header row. */
    Row headerRow;

    /** The e way gstin list from DB. */
    String[] eWayGstinListFromDB;

    /** The col name index map. */
    Map<String, Integer> colNameIndexMap = new HashMap<>();

    /** The duplicate row map. */
    Map<String, Integer> duplicateRowMap = new HashMap<>();

    /** The year id map. */
    Map<String, String> yearIdMap = new HashMap<>();

    /** The temp folder. */
    @Value("${temp.folder.path}")
    String tempFolder;

    List<VendorInvoiceGrnMappingCrudDTO> vendorInvoiceGrnMappingCrudDTOList = new ArrayList<>();

    Set<String> sftpFpMap = new HashSet<>();

    /**
     * Validate N save data.
     *
     * @param uploadDTO
     *            the upload DTO
     * @param map
     *            the map
     * @return the string
     * @throws InvoiceTemplateUploadException
     *             the invoice template upload exception
     */
    @Async
    @Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
    @Override
    public String validateNSaveData(UploadReqDTO uploadDTO, AzureConnectionCredentialsDTO map) {

        String methodName = "validateNSaveData";

        uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_PROCESSING,
                        Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadDTO);
        uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_INPROGRESS);
        uploadTransDao.commonPostNotification(Constants.VENDORUPLOADMSTID,
                        Constants.E_WAY_BILL_FILE_IN_PROGRESS + uploadDTO.getBatchNo(), uploadDTO.getUserId(),
                        uploadDTO.getUserId(), uploadDTO.getUserId(), mstDatabseName, Constants.NOTIFICATION_INITIATED);
        List<EWayBillDTO> rowToPoJoList = new ArrayList<>();

        // these functions will convert excel file or csv file to the list of
        // objects.

        try {

            if (Constants.XLSX.equalsIgnoreCase(uploadDTO.getFileType())) {
                if (uploadDTO.getIsCustomTemplate().equals(Constants.ISDEFAULTTEMPLATE)) {
                    rowToPoJoList = getExcelEWayDataList(uploadDTO);
                } else if (uploadDTO.getIsCustomTemplate().equals(Constants.ISCUSTOMETEMPLATE)) {
                    rowToPoJoList = customTemplateEWayBillRead.getEinvoiceDataList(uploadDTO);
                }
            } else if (Constants.CSV.equalsIgnoreCase(uploadDTO.getFileType())) {
                if (uploadDTO.getIsCustomTemplate().equals(Constants.ISDEFAULTTEMPLATE)) {
                    rowToPoJoList = getCsvEWayBillDataList(uploadDTO);
                } else if (uploadDTO.getIsCustomTemplate().equals(Constants.ISCUSTOMETEMPLATE)) {
                    Map<String, String> customTemplateHeaderMappings = CommonUtils
                                    .getCustomTemplateHeaderMappings(uploadDTO, customTemplateRepo);
                    rowToPoJoList = customTemplateEWayBillRead.getEWayDataListCDV(uploadDTO,
                                    customTemplateHeaderMappings, Constants.DELIMITER);

                }
            } else if (Constants.PDF.equalsIgnoreCase(uploadDTO.getFileType())
                            || Constants.JPG.equalsIgnoreCase(uploadDTO.getFileType())) {
                rowToPoJoList = new ArrayList<>();

                List<EwayBillheaderDTO> ewaybillheaderList = ewayBillPdfOrJpgUploadProcess
                                .pdfEwayBillProcess(uploadDTO);

                ewayBillPdfOrJpgUploadProcess.saveEwayBillDetails(ewaybillheaderList, uploadDTO.getId());

                for (EwayBillheaderDTO header : ewaybillheaderList) {
                	EWayBillDTO eWayBillDTO = new EWayBillDTO();
                    if(StringUtils.isBlank(header.getErrorCode())) {
		                eWayBillDTO.setTaxpayerGstin(header.getToGstin());
		                eWayBillDTO.setEWayBillNo(header.getEwbNo());
		                eWayBillDTO.setTaxpayerPan(header.getToGstin().substring(2, 12));
		                eWayBillDTO.setEWayBillDate(DateUtil.convertDateFormattoScreen2(header.getEwayBillDate()));
		                eWayBillDTO.setEWayBillValidTill(DateUtil
		                                .convertDateFormattoScreen2(StringUtils.isEmpty(header.getValidUpto()) ? null
		                                                : header.getValidUpto().substring(0, 10)));
		                eWayBillDTO.setVendorGstin(header.getFromGstin());
		                eWayBillDTO.setFillingPeriod(uploadDTO.getFp().get(0));
		                String yearId = String.valueOf(getEwayBillApiDao
		                                .getYearIdByFp(DateUtil.convertDateToFillingPeriod(header.getEwayBillDate())));
		                eWayBillDTO.setYearId(yearId);
		                eWayBillDTO.setIsValid(1);
		                eWayBillDTO.setDocType(header.getDocType());
		                eWayBillDTO.setInwardNo(header.getDocNo());
		                eWayBillDTO.setInwardDate(DateUtil.convertDateFormattoScreen2(header.getDocDate()));
		                eWayBillDTO.setItemCount(header.getItemList().size());
		                eWayBillDTO.setTotalInvoiceAmt(header.getTotInvValue());
		                eWayBillDTO.setEwbGenOn(DateUtil.convertDateFormattoScreen2(header.getEwayBillDate()));
		                eWayBillDTO.setEwbGenBy(header.getFromGstin());
		                eWayBillDTO.setQrPageNo(header.getQrPageNo());
                    }
                    else {
                    	eWayBillDTO.setQrPageNo(header.getQrPageNo());
                    	eWayBillDTO.setIsValid(0);
                    	eWayBillDTO.setErrorCodeList(eWayBillDTO.getErrorCodeList().append(header.getErrorCode()));
                    }
                     rowToPoJoList.add(eWayBillDTO);
                }

            } else {

                return Constants.FILEFORMATNOTALLOWED;
            }
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_PROCESSING,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadDTO);
            // updating time Stamp in upload_log table
            uploadTransDao.updateTimeStamp(LogSQL.UPDATE_VALIDATION_START_TIME_STAMP, uploadDTO);

            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_VALIDATION,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadDTO);

            // this function is used to validate list of objects.
            validatePojoList(rowToPoJoList, uploadDTO);

            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_VALIDATION,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadDTO);

            // this query will update the upload stage and upload state values
            // in upload stage log.

            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_COMPLETED,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadDTO);

            // getting file Path Using CommonUtil method
            String csvSuccessFilePath = CommonUtils.getSuccessFilePath(uploadDTO, tempFolder);
            String csvErrorFilePath = CommonUtils.getErrorFilePath(uploadDTO, tempFolder);

            // inserting data from CSV to Database
            ResponseBean responseBean = eInvoiceDao.gstInwardInvCdnInsert(csvSuccessFilePath, csvErrorFilePath,
                            Constants.INVOICE_EWAY_BILL_DETAILS, Constants.E_WAY_TEMPLATE_FAILURE);

            // update success and Error Count (Valid and not valid data) in
            // Database
            uploadTransDao.updateErrorNSuccessCountAndTotalCount(responseBean, uploadDTO.getBatchNo());

            File file = new File(csvErrorFilePath);
            if (file.exists()) {
                FileUtils.deleteQuietly(file);
            }
            List<EWayBillDTO> errorlist = null;
            errorlist = uploadTransDao.getErrorData(uploadDTO.getBatchNo());

            // here new error list is generated with the error description which
            // is coming from database.

            List<EWayBillDTO> newErrorList = uploadMasterDao.getNewErrorList(errorlist);

            if (!errorlist.isEmpty() && (Constants.PDF.equalsIgnoreCase(uploadDTO.getFileType())
                            || Constants.JPG.equalsIgnoreCase(uploadDTO.getFileType()))) {

                uploadTransDao.updateProcessStatusWithRemarks(uploadDTO.getBatchNo(),
                                Constants.UPLOAD_INVOICES_PLD_STATUS_ERROR,
                                uploadTransDao.getEwayBillErrorMessage(newErrorList));
            } else if (!errorlist.isEmpty()) {
                InputStream newInvalidInputStream = eWayBillExcelNewInValidDataToCSV(newErrorList);
                Files.copy(newInvalidInputStream, Paths.get(csvErrorFilePath));

                // In this function error file is to be uploaded on azure.
                uploadNDownloadFileServiceImpl.uploadErrorFile(uploadDTO, map);
            }

            File errorFile = new File(csvErrorFilePath);
            if (errorFile.exists()) {

                uploadTransDao.updateErrorFileName(uploadDTO.getBatchNo(),
                                uploadDTO.getBatchNo() + Constants.ERROR_DOT_CSV);
            }
            uploadTransDao.updateTimeStamp(LogSQL.UPDATE_VALIDATION_FINAL_TIME_STAMP, uploadDTO);

            if (!errorlist.isEmpty()) {
                uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_ERROR);

                uploadTransDao.commonPostNotification(Constants.VENDORUPLOADMSTID,
                                Constants.E_WAY_BILL_FILE_UPLOAD_ERROR + uploadDTO.getBatchNo(), uploadDTO.getUserId(),
                                uploadDTO.getUserId(), uploadDTO.getUserId(), mstDatabseName,
                                Constants.NOTIFICATION_ERROR);
            } else {
                uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),
                                Constants.UPLOAD_INVOICES_PLD_STATUS_COMPLETED);

                uploadTransDao.commonPostNotification(Constants.VENDORUPLOADMSTID,
                                Constants.EWAYBILLFILEUPLOADED + uploadDTO.getBatchNo(), uploadDTO.getUserId(),
                                uploadDTO.getUserId(), uploadDTO.getUserId(), mstDatabseName,
                                Constants.NOTIFICATION_SUCCESS);
            }

            uploadTransDao.writeInvoiceDetailsToInvoiceHeader(uploadDTO.getBatchNo(), 1, uploadDTO.getUserId(),
                            mstDatabseName);
            ObjectMapper mapper = new ObjectMapper();
            String json = "";
            json += vendorInvoiceGrnMappingCrudDTOList.size() == 1
                            ? mapper.writeValueAsString(vendorInvoiceGrnMappingCrudDTOList).substring(1,
                                            mapper.writeValueAsString(vendorInvoiceGrnMappingCrudDTOList).length() - 1)
                            : mapper.writeValueAsString(vendorInvoiceGrnMappingCrudDTOList);
            uploadTransDao.poGrnMapping(uploadDTO, json);
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_COMPLETED,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadDTO);
            

		    } catch (InvalidTemplateHeaderException ex) {
		        uploadTransDao.updateProcessStatusWithRemarks(uploadDTO.getBatchNo(),
		                        Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE, ex.getMessage());
		        uploadTransDao.commonPostNotification(Constants.VENDORUPLOADMSTID, Constants.INVALID_TEMPLATE,
		                        uploadDTO.getUserId(), uploadDTO.getUserId(), uploadDTO.getUserId(), mstDatabseName,
		                        Constants.NOTIFICATION_FAILED);
		    } catch (ReadInvoicePojoListException | VendorInvoiceServerException | ReadInvoiceCustomTemplate |InvoiceIntegrationEWBException ex) {
		        uploadTransDao.updateProcessStatusWithRemarks(uploadDTO.getBatchNo(),
		                Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, ex.getMessage());
		                 uploadTransDao.commonPostNotification(Constants.VENDORUPLOADMSTID,
		                Constants.FAILED + uploadDTO.getBatchNo(), uploadDTO.getUserId(), uploadDTO.getUserId(),
		                uploadDTO.getUserId(), mstDatabseName, Constants.NOTIFICATION_FAILED);
		     }

          catch (Exception ex) {
            log.error("Error generated while uploading templates for batch no:" + uploadDTO.getBatchNo(),
                            ex.getMessage(), ex);

            if (!(StringConstant.HEADERCOUNTERRORMESSAGE + uploadDTO.getBatchNo()).equals(ex.getMessage())) {

                uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            }

            logIntoToExceptionTable(uploadDTO, ex, "validateNSaveData");

        }
        finally {
        	deleteTempFiles(tempFolder, uploadDTO);
		}
        return Constants.FILEUPLOADEDSUCCESSFUL;

    }

    /**
     * Delete temp files.
     *
     * @param tempFolder
     *            the temp folder
     * @param uploadDTO
     *            the upload DTO
     */
    private void deleteTempFiles(String tempFolder, UploadReqDTO uploadDTO) {

        File baseFile = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR) + uploadDTO.getBatchNo()
                        + Constants.UNSERSCORE_BASE + Constants.DOTSEPARATOR + uploadDTO.getFileType());
        if (baseFile.exists()) {
            FileUtils.deleteQuietly(baseFile);
        }
        File errorFile = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR) + uploadDTO.getBatchNo()
                        + Constants.ERROR_DOT_CSV);
        if (errorFile.exists()) {
            FileUtils.deleteQuietly(errorFile);
        }
        File successFile = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR) + uploadDTO.getBatchNo()
                        + Constants.SUCCESS_DOT_CSV);
        if (successFile.exists()) {
            FileUtils.deleteQuietly(successFile);
        }

    }

    /**
     * Validate pojo list.
     *
     * @param eWayBillDTO
     *            the e way bill DTO
     * @param uploadDTO
     *            the upload DTO
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     * @throws CsvWriteException
     */
    // this function is used to validate list of objects.
    private void validatePojoList(List<EWayBillDTO> eWayBillDTO, UploadReqDTO uploadDTO)
                    throws IOException, CsvWriteException, VendorInvoiceServerException {
        /** The e way bill validated data list. */
        List<EWayBillDTO> eWayBillValidatedDataList = new ArrayList<>();

        /** The e way bill success data. */
        List<EWayBillDTO> eWayBillSuccessData = new ArrayList<>();

        /** The e way bill error data. */
        List<EWayBillDTO> eWayBillErrorData = new ArrayList<>();

        Map<String, Map<String, String>> suppGSTNWiseMap = new ConcurrentHashMap<String, Map<String, String>>();
        Map<String, Map<String, String>> approvalValidationMap = new ConcurrentHashMap<String, Map<String, String>>();
        if (Constants.PAN.equals(uploadDTO.getPanOrGstn())) {
            eWayGstinListFromDB = commonDao.getGstinFromDB(uploadDTO.getGstinOrPanList().get(0), mstDatabseName);
        } else if (Constants.GSTIN.equals(uploadDTO.getPanOrGstn())) {
            eWayGstinListFromDB = uploadDTO.getGstinOrPanList()
                            .toArray(new String[uploadDTO.getGstinOrPanList().size()]);

        }
        yearIdMap = commonDao.getYearId();
        eWayBillDTO.forEach(eWayBillDtoObject -> {

            try {
                if ((Constants.VALIDCONSTANTS).equals(eWayBillDtoObject.getIsValid())) {

                    markDocNoLevelError(eWayBillDtoObject);
                    inwardINVDataTypeValidations.validateDataType(eWayBillDtoObject, eWayGstinListFromDB,
                                    uploadDTO.getFp().toArray(new String[uploadDTO.getFp().size()]),
                                    uploadDTO.getFileType());

                    if ((Constants.VALIDCONSTANTS).equals(eWayBillDtoObject.getIsValid())) {

                        String supplierGstnInwardNo = eWayBillDtoObject.getVendorGstin()
                                        + eWayBillDtoObject.getEWayBillNo();
                        if (StringUtils.isNotBlank(supplierGstnInwardNo)) {
                            supplierGstnInwardNo = supplierGstnInwardNo.toLowerCase();
                        }

                        int isduplicateInvoiceInDiffMonth = 0;
                        // Check invoice already saved in the GSTN
                        String keyCheckInBatchData = eWayBillDtoObject.getTaxpayerGstin() + uploadDTO.getBatchNo();
                        List<String> invoiceList = null;
                        if (suppGSTNWiseMap.get(keyCheckInBatchData) == null) {
                            invoiceList = uploadTransDao.getEWayDuplicateFPInDiffMonthFP(
                                            eWayBillDtoObject.getVendorGstin(), eWayBillDtoObject.getTaxpayerGstin(),
                                            eWayBillDtoObject.getFillingPeriod());
                            invoiceList.remove(null);
                            Map<String, String> map = invoiceList.stream()
                                            .collect(Collectors.toMap(str -> str, str -> str));
                            suppGSTNWiseMap.put(keyCheckInBatchData, map);
                            if (suppGSTNWiseMap.get(keyCheckInBatchData).get(supplierGstnInwardNo) != null) {
                                isduplicateInvoiceInDiffMonth++;
                            }

                        } else {
                            Map<String, String> map = suppGSTNWiseMap.get(keyCheckInBatchData);
                            if (map != null && map.get(supplierGstnInwardNo) != null) {
                                isduplicateInvoiceInDiffMonth++;
                            }
                        }
                        if (isduplicateInvoiceInDiffMonth > 0) {

                            markErrorNAddErrorCode(eWayBillDtoObject, "|O0093",
                                            "|Duplicate invoice in differernt month");
                        }
                    }

                    // check record is already Approved or not
                    if ((Constants.VALIDCONSTANTS).equals(eWayBillDtoObject.getIsValid())) {
                        String keyDataToApprovalCheck = eWayBillDtoObject.getTaxpayerGstin()
                                        + eWayBillDtoObject.getVendorGstin() + eWayBillDtoObject.getEWayBillNo();
                        List<String> invoiceHeaderCrId = new ArrayList<>();
                        int isAlreadyApproved = 0;
                        if (approvalValidationMap.get(eWayBillDtoObject.getTaxpayerGstin()) == null) {
                            invoiceHeaderCrId = uploadTransDao
                                            .getEWBAlreadyApproved(eWayBillDtoObject.getTaxpayerGstin());
                            Map<String, String> map = invoiceHeaderCrId.stream()
                                            .collect(Collectors.toMap(str -> str, str -> str));

                            approvalValidationMap.put(eWayBillDtoObject.getTaxpayerGstin(), map);
                            if (approvalValidationMap.get(eWayBillDtoObject.getTaxpayerGstin())
                                            .get(keyDataToApprovalCheck) != null) {
                                isAlreadyApproved = 1;
                            }
                        } else {
                            if (approvalValidationMap.get(eWayBillDtoObject.getTaxpayerGstin())
                                            .get(keyDataToApprovalCheck) != null) {
                                isAlreadyApproved = 1;
                            }
                        }

                        if (isAlreadyApproved > 0) {

                            markErrorNAddErrorCode(eWayBillDtoObject, ValidationConstants.EINVOICE_ERROR_CODE_O0090,
                                            Constants.BLANK);
                        }

                    }

                    if (yearIdMap.containsKey(eWayBillDtoObject.getFillingPeriod())) {
                        eWayBillDtoObject.setYearId(yearIdMap.get(eWayBillDtoObject.getFillingPeriod()));
                    } else {
                        eWayBillDtoObject.setYearId("");
                        markErrorNAddErrorCode(eWayBillDtoObject, ValidationConstants.EINVOICE_ERROR_CODE_E00514, "");
                    }

                }
                eWayBillValidatedDataList.add(eWayBillDtoObject);
            }

            catch (ParseException e) {

                log.error("Paerse Error in ValidatePojoList method", e);

            }

        });

        /* validate already synced/processed in erp */
        List<EWayBillDTO> validatedUpdatedList = new ArrayList<>();
        validatedUpdatedList = ewayBillAlreadySyncedValidation.validateAlreadySyncedStatus(eWayBillValidatedDataList);
        validatedUpdatedList.forEach(eWayBillDtoObject -> {

            if (eWayBillDtoObject.getIsValid() == 1) {
                eWayBillSuccessData.add(eWayBillDtoObject);
            } else {
                eWayBillErrorData.add(eWayBillDtoObject);
            }
        });

        try {
            if (!eWayBillSuccessData.isEmpty()) {
                InputStream validInputStream = eWayBillExcelValidDataToCSV(eWayBillSuccessData, uploadDTO);
                Files.copy(validInputStream, Paths.get(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                + uploadDTO.getBatchNo() + Constants.SUCCESS_DOT_CSV));

            }
            if (!eWayBillErrorData.isEmpty()) {
                InputStream inValidInputStream1 = eWayBillExcelInValidDataToCSV(eWayBillErrorData, uploadDTO);
                Files.copy(inValidInputStream1, Paths.get(tempFolder + System.getProperty(Constants.FILESEPERATOR)
                                + uploadDTO.getBatchNo() + Constants.ERROR_DOT_CSV));
            }
        } catch (Exception e) {
            if (!e.getMessage().contains("CSV File")) {
                throw new CsvWriteException(e.getMessage());
            }
            throw new CsvWriteException(e.getMessage());
        }

    }

    /**
     * E way bill excel valid data to CSV.
     *
     * @param excelData
     *            the excel data
     * @param uploadReqDTO
     *            the upload req DTO
     * @return the byte array input stream
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws CsvWriteException
     */
    private ByteArrayInputStream eWayBillExcelValidDataToCSV(List<EWayBillDTO> excelData, UploadReqDTO uploadReqDTO)
                    throws IOException, CsvWriteException {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format)) {
            csvPrinter.printRecord("id", Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT, Constants.TAXPAYER_PAN,
                            Constants.YEAR_ID, Constants.COLUMN_DOC_TYPE, Constants.COLUMN_INWARD_NO,
                            Constants.COLUMN_INWARD_DATE, Constants.COLUMN_GSTIN_OF_SUPPLIER, Constants.COLUMN_HSN_CODE,
                            Constants.ITEMCOUNT, Constants.COLUMN_TOTAL_INVOICE_AMOUNT,
                            Constants.COLUMN_PURCHASE_ORDER_NO, Constants.COLUMN_PURCHASE_ORDER_DATE,
                            Constants.COLUMN_IRN, Constants.COLUMN_IRN_DATE, Constants.COLUMN_EWAY_BILL_VALID,
                            Constants.TEMPLATE_TYPE, Constants.FILLING_PERIOD, Constants.COLUMN_UDF_1,
                            Constants.COLUMN_UDF_2, Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4,
                            Constants.COLUMN_UDF_5, Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7,
                            Constants.COLUMN_UDF_8, Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10,
                            Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13,
                            Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16,
                            Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19,
                            Constants.COLUMN_UDF_20, Constants.ROWVERSION, Constants.COLUMN_STATUS,
                            Constants.COLUMN_BATCH_NO, Constants.COLUMN_EWAY_BILL_NO, Constants.COLUMN_EWAY_BILL_DATE,
                            Constants.EWB_DETAILS_FETCH_STATUS, Constants.EWB_DETAILS_FETCHED_AT,
                            Constants.EWB_DETAILS_FETCHED_COUNT, Constants.GENERATED_ON, Constants.GENERATED_BY);
            int id = 0;
            for (EWayBillDTO eWayBillTemplateDTO : excelData) {
                id++;
                vendorInvoiceGrnMappingCrudDTOList.add(CommonUtils.setVendorInvoiceGrnMappingCrudDTO(id,
                                eWayBillTemplateDTO, vendorInvoiceGrnMappingCrudDTOList));
                List<Object> data = Arrays.asList("", eWayBillTemplateDTO.getTaxpayerGstin(),
                                eWayBillTemplateDTO.getTaxpayerPan(), eWayBillTemplateDTO.getYearId(),
                                eWayBillTemplateDTO.getDocType(),

                                eWayBillTemplateDTO.getInwardNo(), eWayBillTemplateDTO.getInwardDate(),
                                eWayBillTemplateDTO.getVendorGstin(), Constants.BLANK,
                                eWayBillTemplateDTO.getItemCount(), eWayBillTemplateDTO.getTotalInvoiceAmt(),
                                eWayBillTemplateDTO.getPoNo(), eWayBillTemplateDTO.getPoDate(), Constants.BLANK,
                                Constants.BLANK, eWayBillTemplateDTO.getEWayBillValidTill(),
                                uploadReqDTO.getUploadType(), eWayBillTemplateDTO.getFillingPeriod(),
                                eWayBillTemplateDTO.getUdf1(), eWayBillTemplateDTO.getUdf2(),
                                eWayBillTemplateDTO.getUdf3(), eWayBillTemplateDTO.getUdf4(),
                                eWayBillTemplateDTO.getUdf5(), eWayBillTemplateDTO.getUdf6(),
                                eWayBillTemplateDTO.getUdf7(), eWayBillTemplateDTO.getUdf8(),
                                eWayBillTemplateDTO.getUdf9(), eWayBillTemplateDTO.getUdf10(),
                                eWayBillTemplateDTO.getUdf11(), eWayBillTemplateDTO.getUdf12(),
                                eWayBillTemplateDTO.getUdf13(), eWayBillTemplateDTO.getUdf14(),
                                eWayBillTemplateDTO.getUdf15(), eWayBillTemplateDTO.getUdf16(),
                                eWayBillTemplateDTO.getUdf17(), eWayBillTemplateDTO.getUdf18(),
                                eWayBillTemplateDTO.getUdf19(), eWayBillTemplateDTO.getUdf20(),
                                Timestamp.from(Instant.now()), eWayBillTemplateDTO.getIsValid(),
                                uploadReqDTO.getBatchNo(), eWayBillTemplateDTO.getEWayBillNo(),
                                eWayBillTemplateDTO.getEWayBillDate(), 0, null, 0, eWayBillTemplateDTO.getEwbGenOn(),
                                eWayBillTemplateDTO.getEwbGenBy());

                csvPrinter.printRecord(data);
            }

            csvPrinter.flush();
        } catch (Exception e) {
            throw new CsvWriteException("Error while Writing CSV File");
        }

        return new ByteArrayInputStream(out.toByteArray());

    }

    /**
     * E way bill excel in valid data to CSV.
     *
     * @param excelData
     *            the excel data
     * @param uploadReqDTO
     *            the upload req DTO
     * @return the byte array input stream
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws CsvWriteException
     */
    private ByteArrayInputStream eWayBillExcelInValidDataToCSV(List<EWayBillDTO> excelData, UploadReqDTO uploadReqDTO)
                    throws IOException, CsvWriteException {

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format)) {
            csvPrinter.printRecord(Constants.COLUMN_ID, Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT, Constants.TAXPAYER_PAN,
                            Constants.COLUMN_EWAY_BILL_NO, Constants.COLUMN_EWAY_BILL_DATE,
                            Constants.COLUMN_EWAY_BILL_VALID, Constants.COLUMN_GSTIN_OF_SUPPLIER,
                            Constants.COLUMN_PURCHASE_ORDER_NO, Constants.COLUMN_PURCHASE_ORDER_DATE,
                            Constants.FILLING_PERIOD, Constants.COLUMN_UDF_1, Constants.COLUMN_UDF_2,
                            Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4, Constants.COLUMN_UDF_5,
                            Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7, Constants.COLUMN_UDF_8,
                            Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10, Constants.COLUMN_UDF_11,
                            Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13, Constants.COLUMN_UDF_14,
                            Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16, Constants.COLUMN_UDF_17,
                            Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19, Constants.COLUMN_UDF_20,
                            Constants.ROWVERSION, Constants.COLUMN_STATUS, Constants.COLUMN_BATCH_NO,
                            Constants.COLUMN_ERROR_CODE,"QR_Page_Number");

            for (EWayBillDTO eWayBillTemplateDTO : excelData) {

                List<Object> data = Arrays.asList("", eWayBillTemplateDTO.getTaxpayerGstin(),
                                eWayBillTemplateDTO.getTaxpayerPan(), eWayBillTemplateDTO.getEWayBillNo(),
                                eWayBillTemplateDTO.getEWayBillDate(), eWayBillTemplateDTO.getEWayBillValidTill(),
                                eWayBillTemplateDTO.getVendorGstin(), eWayBillTemplateDTO.getPoNo(),
                                eWayBillTemplateDTO.getPoDate(), eWayBillTemplateDTO.getFillingPeriod(),
                                eWayBillTemplateDTO.getUdf1(), eWayBillTemplateDTO.getUdf2(),
                                eWayBillTemplateDTO.getUdf3(), eWayBillTemplateDTO.getUdf4(),
                                eWayBillTemplateDTO.getUdf5(), eWayBillTemplateDTO.getUdf6(),
                                eWayBillTemplateDTO.getUdf7(), eWayBillTemplateDTO.getUdf8(),
                                eWayBillTemplateDTO.getUdf9(), eWayBillTemplateDTO.getUdf10(),
                                eWayBillTemplateDTO.getUdf11(), eWayBillTemplateDTO.getUdf12(),
                                eWayBillTemplateDTO.getUdf13(), eWayBillTemplateDTO.getUdf14(),
                                eWayBillTemplateDTO.getUdf15(), eWayBillTemplateDTO.getUdf16(),
                                eWayBillTemplateDTO.getUdf17(), eWayBillTemplateDTO.getUdf18(),
                                eWayBillTemplateDTO.getUdf19(), eWayBillTemplateDTO.getUdf20(),
                                Timestamp.from(Instant.now()), eWayBillTemplateDTO.getIsValid(),
                                uploadReqDTO.getBatchNo(), eWayBillTemplateDTO.getErrorCodeList(),eWayBillTemplateDTO.getQrPageNo());

                csvPrinter.printRecord(data);
            }

            csvPrinter.flush();
        } catch (Exception e) {
            throw new CsvWriteException("Error while Writing CSV File");
        }
        return new ByteArrayInputStream(out.toByteArray());

    }

    /**
     * Gets the excel E way data list.
     *
     * @param uploadDTO
     *            the upload DTO
     * @return the excel E way data list
     * @throws InvoiceTemplateUploadException
     *             the invoice template upload exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     * @throws ReadInvoicePojoListException
     */
    @Override
    public List<EWayBillDTO> getExcelEWayDataList(UploadReqDTO uploadDTO)
                    throws IOException, InvalidTemplateHeaderException, ReadInvoicePojoListException {
        String methodName = "getExcelEWayDataList";
        List<EWayBillDTO> eWayBilldataList = new ArrayList<>();
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(Constants.DOTSEPARATOR)
                        .append(uploadDTO.getFileType());

        Map<String, Object> rowCountWithHeader = new HashMap<>();

        try {
            try (InputStream inputStream = new FileInputStream(new File(fileName.toString()));
                            BufferedInputStream br = new BufferedInputStream(inputStream)) {
                rowCountWithHeader = getRowCountWithHeader(inputStream);
            }
        } catch (Exception ex) {
            log.error("Error in method getExcelEWayDataList", ex);
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();

            String methodName1 = "getExcelEWayDataList";

            exceptionLogDTO.setUserId(uploadDTO.getId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
            exceptionLogDTO.setFunctionName(methodName1);
            exceptionLogDTO.setErrorMessage(ex.getMessage());
            exceptionLogDTO.setErrorCause(Constants.NOTCONTAINPROPERDATA);
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());

            commonDao.updateExceptionLogTable(exceptionLogDTO);

            throw new ReadInvoicePojoListException(ex.getMessage(), ex.getCause());
        }

        headerRow = (Row) rowCountWithHeader.get(Constants.DATA_ROW);

        try {
            colNameIndexMap = AppUtil.getColumnNameIndexMap(headerRow);
        } catch (Exception ex) {
            log.error("Error in getExcelEWayDataList method", ex);
            logIntoToExceptionTable(uploadDTO, ex, methodName);

            throw new ReadInvoicePojoListException(ex.getMessage());
        }

        if (Constants.E_WAY_BILL_TEMPLATE_COLUMN_COUNT != colNameIndexMap.size()) {

            uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),

                            Constants.UPLOAD_INVOICES_STATUS_INVALIDTEMPLATE);

            throw new InvalidTemplateHeaderException(StringConstant.HEADERCOUNTERRORMESSAGE + uploadDTO.getBatchNo());

        }

        int totalRows = (int) rowCountWithHeader.get(Constants.ROWCOUNT);
        uploadTransDao.updateCount(LogSQL.UPDATE_TOTAL_COUNT_TXUPLOADLOGS_SQL, totalRows, uploadDTO);

        try (InputStream in = new FileInputStream(new File(fileName.toString()));
                        BufferedInputStream bis = new BufferedInputStream(in);
                        Workbook workbook = StreamingReader.builder().open(bis);) {
            Sheet sheet = workbook.getSheetAt(0);
            sftpFpMap = new HashSet<>();
            sheet.forEach(row -> {
                EWayBillDTO rowObj = new EWayBillDTO();
                if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 1) {
                    rowObj.setExcelRowId(row.getRowNum());
                    try {
                        rowObj = readTemplateRecord(row, colNameIndexMap);
                        rowObj.setIsValid(1);

                    } catch (Exception e) {
                        log.error("Error in method getExcelEWayDataList", e);
                        markErrorNAddErrorCode(rowObj, ValidationConstants.EINVOICE_ERROR_CODE_DE1000, "");
                    }
                    if (rowObj.getFillingPeriod().length() == 5) {
                        rowObj.setFillingPeriod(Constants.ZEROVALUE + rowObj.getFillingPeriod());
                    }
                    if (StringUtils.isNotBlank(rowObj.getTaxpayerGstin()) && rowObj.getTaxpayerGstin().length() == 15) {
                        rowObj.setTaxpayerPan(rowObj.getTaxpayerGstin().substring(2, 12));
                    } else {
                        rowObj.setTaxpayerPan("");
                    }
                    if (StringUtils.isNotBlank(rowObj.getFillingPeriod())) {
                        sftpFpMap.add(rowObj.getFillingPeriod());
                    }
                    eWayBilldataList.add(rowObj);
                }
            });
            if ("ftps".equals(uploadDTO.getUplodSource())) {
                uploadDTO.setFp(new ArrayList<>(sftpFpMap));
                uploadTransDao.updateFpLog(uploadDTO.getFp(), uploadDTO);
            }

        } catch (Exception e) {
            throw new ReadInvoicePojoListException("Error in reading Stream to get Row Data");
        }

        return eWayBilldataList;
    }

    /**
     * Gets the row count with header.
     *
     * @param fis
     *            the fis
     * @return the row count with header
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws ReadInvoicePojoListException
     */
    public Map<String, Object> getRowCountWithHeader(InputStream fis) throws IOException, ReadInvoicePojoListException {
        Map<String, Object> dataMap = new HashMap<>();

        BufferedInputStream bis = null;

        bis = new BufferedInputStream(fis);

        int totalRowCount = 0;

        try (InputStream is = bis; Workbook workbook = StreamingReader.builder().open(is);) {
            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {

                if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 1) {
                    totalRowCount++;
                } else if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() <= 1 && totalRowCount == 0) {

                    Row coumnsDataRow = null;
                    coumnsDataRow = row;
                    dataMap.put("headerRowIndex", row.getRowNum());
                    dataMap.put("coumnsDataRow", coumnsDataRow);

                }

            }
            dataMap.put("RowCount", totalRowCount);

        } catch (Exception e) {
            log.error("Error in getting Row count with header", e);
            throw new ReadInvoicePojoListException("Error in getting Row count with header");
        }

        return dataMap;
    }

    /**
     * Mark error N add error code.
     *
     * @param rowData
     *            the row data
     * @param errorCode
     *            the error code
     * @param errorMessage
     *            the error message
     */
    private void markErrorNAddErrorCode(EWayBillDTO rowData, String errorCode, String errorMessage) {

        rowData.setIsValid(0);
        rowData.setErrorCodeList(rowData.getErrorCodeList().append(errorCode));
        rowData.setErrorDiscriptionList(rowData.getErrorDiscriptionList().append(errorMessage));
    }

    /**
     * Read template record.
     *
     * @param row
     *            the row
     * @param colNameIndexMap
     *            the col name index map
     * @return the e way bill DTO
     * @throws ParseException
     *             the parse exception
     */
    private EWayBillDTO readTemplateRecord(Row row, Map<String, Integer> colNameIndexMap) throws ParseException {
        EWayBillDTO xlsRow = new EWayBillDTO();

        try {
            xlsRow.setTaxpayerGstin(AppUtil
                            .getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setEWayBillNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_EWAY_BILL_NO)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setEWayBillDate(
                            AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_EWAY_BILL_DATE)))
                                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setFillingPeriod(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.FILLING_PERIOD)))
                            .replaceAll("[\n\r]", " "));

            xlsRow.setEWayBillValidTill(
                            AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_EWAY_BILL_VALID)))
                                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setVendorGstin(
                            AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_GSTIN_OF_SUPPLIER)))
                                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setPoNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_PURCHASE_ORDER_NO)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setPoDate(
                            AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_PURCHASE_ORDER_DATE)))
                                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf1(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_1)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf2(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_2)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf3(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_3)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf4(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_4)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf5(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_5)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf6(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_6)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf7(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_7)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf8(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_8)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf9(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_9)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf10(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_10)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf11(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_11)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf12(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_12)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf13(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_13)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf14(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_14)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf15(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_15)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf16(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_16)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf17(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_17)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf18(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_18)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf19(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_19)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf20(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_20)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));

        } catch (Exception ex) {
            markErrorNAddErrorCode(xlsRow, ValidationConstants.EINVOICE_ERROR_CODE_DE1000, "");
            log.error("Errro occured while reading row " + row.getRowNum() + " for batch No. " + ex);

        }

        return xlsRow;
    }
    // this function convert the csv file to list of objects.

    /**
     * Gets the csv E way bill data list.
     *
     * @param uploadDTO
     *            the upload DTO
     * @return the csv E way bill data list
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public List<EWayBillDTO> getCsvEWayBillDataList(UploadReqDTO uploadDTO) throws IOException {
        List<EWayBillDTO> eWayRawData = new ArrayList<>();
        int cnt = 0;
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(Constants.FILESEPERATOR)).append(uploadDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(Constants.DOTSEPARATOR)
                        .append(uploadDTO.getFileType());

        CsvReader eWayBill = new CsvReader(new FileReader(fileName.toString()));
        CsvReader readHeaderCount = new CsvReader(new FileReader(fileName.toString()));
        // Add code if header is missing then mark as invalid template
        String[] indexHeaders1 = AppUtil.getHeaders(readHeaderCount);
        if (Constants.E_WAY_BILL_TEMPLATE_COLUMN_COUNT != indexHeaders1.length) {
            uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);

            throw new InvalidTemplateHeaderException(StringConstant.HEADERCOUNTERRORMESSAGE + uploadDTO.getBatchNo());
        }
        sftpFpMap = new HashSet<>();
        eWayBill.readHeaders();
        while (eWayBill.readRecord()) {
            EWayBillDTO eWayDto = new EWayBillDTO();
            try {

                cnt++;
                if (cnt > 0) {
                    eWayDto.setIsValid(1);
                    eWayDto.setTaxpayerGstin(eWayBill.get(0).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    eWayDto.setEWayBillNo(eWayBill.get(Constants.COLUMN_EWAY_BILL_NO)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    eWayDto.setEWayBillDate(eWayBill.get(Constants.COLUMN_EWAY_BILL_DATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    eWayDto.setFillingPeriod(eWayBill.get(Constants.FILLING_PERIOD).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setEWayBillValidTill(eWayBill.get(Constants.COLUMN_EWAY_BILL_VALID)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    eWayDto.setVendorGstin(eWayBill.get(Constants.COLUMN_GSTIN_OF_SUPPLIER)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    eWayDto.setPoNo(eWayBill.get(Constants.COLUMN_PURCHASE_ORDER_NO)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    eWayDto.setPoDate(eWayBill.get(Constants.COLUMN_PURCHASE_ORDER_DATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    eWayDto.setUdf1(eWayBill.get(Constants.COLUMN_UDF_1).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf2(eWayBill.get(Constants.COLUMN_UDF_2).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf3(eWayBill.get(Constants.COLUMN_UDF_3).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf4(eWayBill.get(Constants.COLUMN_UDF_4).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf5(eWayBill.get(Constants.COLUMN_UDF_5).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf6(eWayBill.get(Constants.COLUMN_UDF_6).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf7(eWayBill.get(Constants.COLUMN_UDF_7).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf8(eWayBill.get(Constants.COLUMN_UDF_8).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf9(eWayBill.get(Constants.COLUMN_UDF_9).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf10(eWayBill.get(Constants.COLUMN_UDF_10).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf11(eWayBill.get(Constants.COLUMN_UDF_11).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf12(eWayBill.get(Constants.COLUMN_UDF_12).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf13(eWayBill.get(Constants.COLUMN_UDF_13).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf14(eWayBill.get(Constants.COLUMN_UDF_14).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf15(eWayBill.get(Constants.COLUMN_UDF_15).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf16(eWayBill.get(Constants.COLUMN_UDF_16).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf17(eWayBill.get(Constants.COLUMN_UDF_17).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf18(eWayBill.get(Constants.COLUMN_UDF_18).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf19(eWayBill.get(Constants.COLUMN_UDF_19).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    eWayDto.setUdf20(eWayBill.get(Constants.COLUMN_UDF_20).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    if (eWayDto.getFillingPeriod().length() == 5) {
                        eWayDto.setFillingPeriod(Constants.ZEROVALUE + eWayDto.getFillingPeriod());
                    }
                    if (StringUtils.isNotBlank(eWayDto.getTaxpayerGstin())
                                    && eWayDto.getTaxpayerGstin().length() == 15) {
                        eWayDto.setTaxpayerPan(eWayDto.getTaxpayerGstin().substring(2, 12));
                    } else {
                        eWayDto.setTaxpayerPan("");
                    }
                    if (StringUtils.isNotBlank(eWayDto.getFillingPeriod())) {
                        sftpFpMap.add(eWayDto.getFillingPeriod());
                    }
                    eWayRawData.add(eWayDto);
                }
            } catch (Exception ex) {
                log.error("Error in method getCsvEWayBillDataList", ex);
                markErrorNAddErrorCode(eWayDto, ValidationConstants.EINVOICE_ERROR_CODE_DE1000, Constants.DATA_ERROR);
            }
        }
        if ("ftps".equals(uploadDTO.getUplodSource())) {
            uploadDTO.setFp(new ArrayList<>(sftpFpMap));
            uploadTransDao.updateFpLog(uploadDTO.getFp(), uploadDTO);
        }
        return eWayRawData;
    }

    /**
     * Log into to exception table.
     *
     * @param uploadDTO
     *            the upload DTO
     * @param ex
     *            the ex
     * @param functionName
     *            the function name
     */
    private void logIntoToExceptionTable(UploadReqDTO uploadDTO, Exception ex, String functionName) {
        ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
        exceptionLogDTO.setUserId(uploadDTO.getId());
        exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
        exceptionLogDTO.setFunctionName(functionName);
        exceptionLogDTO.setErrorMessage(ex.getMessage());
        exceptionLogDTO.setErrorCause(Constants.NOTCONTAINPROPERDATA);
        exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
        exceptionLogDTO.setCreatedAt(LocalDateTime.now());

        commonDao.updateExceptionLogTable(exceptionLogDTO);
    }

    /**
     * E way bill excel new in valid data to CSV.
     *
     * @param dataList
     *            the data list
     * @return the byte array input stream
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws CsvWriteException
     */
    public static ByteArrayInputStream eWayBillExcelNewInValidDataToCSV(List<EWayBillDTO> dataList)
                    throws IOException, CsvWriteException {

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format)) {
            csvPrinter.printRecord(Constants.COLUMN_ERROR_CODE, Constants.ERROR_DESCRIPTION,
                            Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT, Constants.COLUMN_EWAY_BILL_NO,
                            Constants.COLUMN_EWAY_BILL_DATE, Constants.FILLING_PERIOD, Constants.COLUMN_EWAY_BILL_VALID,
                            Constants.COLUMN_GSTIN_OF_SUPPLIER, Constants.COLUMN_PURCHASE_ORDER_NO,
                            Constants.COLUMN_PURCHASE_ORDER_DATE, Constants.COLUMN_UDF_1, Constants.COLUMN_UDF_2,
                            Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4, Constants.COLUMN_UDF_5,
                            Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7, Constants.COLUMN_UDF_8,
                            Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10, Constants.COLUMN_UDF_11,
                            Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13, Constants.COLUMN_UDF_14,
                            Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16, Constants.COLUMN_UDF_17,
                            Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19, Constants.COLUMN_UDF_20);

            for (EWayBillDTO eWayBillTemplateDTO : dataList) {

                List<Object> data = Arrays.asList(eWayBillTemplateDTO.getErrorCodeList(),
                                eWayBillTemplateDTO.getErrorDiscriptionList(), eWayBillTemplateDTO.getTaxpayerGstin(),
                                eWayBillTemplateDTO.getEWayBillNo(), eWayBillTemplateDTO.getEWayBillDate(),
                                eWayBillTemplateDTO.getFillingPeriod(), eWayBillTemplateDTO.getEWayBillValidTill(),
                                eWayBillTemplateDTO.getVendorGstin(), eWayBillTemplateDTO.getPoNo(),
                                eWayBillTemplateDTO.getPoDate(), eWayBillTemplateDTO.getUdf1(),
                                eWayBillTemplateDTO.getUdf2(), eWayBillTemplateDTO.getUdf3(),
                                eWayBillTemplateDTO.getUdf4(), eWayBillTemplateDTO.getUdf5(),
                                eWayBillTemplateDTO.getUdf6(), eWayBillTemplateDTO.getUdf7(),
                                eWayBillTemplateDTO.getUdf8(), eWayBillTemplateDTO.getUdf9(),
                                eWayBillTemplateDTO.getUdf10(), eWayBillTemplateDTO.getUdf11(),
                                eWayBillTemplateDTO.getUdf12(), eWayBillTemplateDTO.getUdf13(),
                                eWayBillTemplateDTO.getUdf14(), eWayBillTemplateDTO.getUdf15(),
                                eWayBillTemplateDTO.getUdf16(), eWayBillTemplateDTO.getUdf17(),
                                eWayBillTemplateDTO.getUdf18(), eWayBillTemplateDTO.getUdf19(),
                                eWayBillTemplateDTO.getUdf20()

                );

                csvPrinter.printRecord(data);
            }

            csvPrinter.flush();
        } catch (Exception e) {
            throw new CsvWriteException("Error in Writing Csv File");
        }

        return new ByteArrayInputStream(out.toByteArray());

    }

    /**
     * Mark doc no level error.
     *
     * @param rowData
     *            the row data
     */
    private void markDocNoLevelError(EWayBillDTO rowData) {

        // Checking item level Error start
        String lineItemLevelErrorkey = new StringBuilder().append(rowData.getTaxpayerGstin())
                        .append(rowData.getVendorGstin()).append(rowData.getEWayBillNo()).toString();

        if (duplicateRowMap.get(lineItemLevelErrorkey) == null) {
            duplicateRowMap.put(lineItemLevelErrorkey, 1);
        } else {
            duplicateRowMap.put(lineItemLevelErrorkey, duplicateRowMap.get(lineItemLevelErrorkey) + 1);

        }
        if (duplicateRowMap.get(lineItemLevelErrorkey) > 1) {
            markErrorNAddErrorCode(rowData, ValidationConstants.ERROR_CODE_E00511, "");
        }

    }

    /**
     * Mark error N add error code.
     *
     * @param rowdata
     *            the rowdata
     * @param errorCode
     *            the error code
     */
    // This function is call to add error messages in the EWayBillDTO fields.
    private void markErrorNAddErrorCode(EWayBillDTO rowdata, String errorCode) {

        rowdata.setErrorCodeList(rowdata.getErrorCodeList().append(errorCode));
        rowdata.setIsValid(0);
    }

}
