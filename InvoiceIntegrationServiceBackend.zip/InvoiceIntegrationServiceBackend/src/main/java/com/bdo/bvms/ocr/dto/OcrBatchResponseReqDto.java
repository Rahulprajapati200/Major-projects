package com.bdo.bvms.ocr.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OcrBatchResponseReqDto {
	@JsonProperty("BatchId")
	int batchId;
	
	@JsonProperty("BatchUID")
	String batchUId;
	
	@JsonProperty("BatchUploadStartTime")
	String batchUploadStartTime;
	
	@JsonProperty("Status")
	String status;
	
	@JsonProperty("files")
	List<Files> files;
	
	
	
	
	
	
	

}
