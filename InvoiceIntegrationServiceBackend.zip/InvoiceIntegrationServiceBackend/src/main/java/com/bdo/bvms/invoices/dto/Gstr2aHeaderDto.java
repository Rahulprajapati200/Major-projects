package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class Gstr2aHeaderDto {
	String taxpayerGstin;
	String vendorGstin;
    String docNo;
    String vendorLegalName;
    String vendorTradeName;
    String invDate;
    String docType;
    String invoiceType;
    String fileType;
    String source;
    String batchNo;
    String pos;
    
    String delinkFlag;
    
    String grossTotal;

    String gstr1FilingStatus;
    
    String gstr3FilingStatus;

    String dateSupplierCancelllation;

    String dateFilingGstrSupplier;
    
    String filingPeriodGstrSupplier; 
    
    
    String amendmentReturnPeriod;

    String amendmentType;

    String itcAvailability;
    String differentialRate;
    
    String itcAvailabilityReason; 
    String gstr2bFp;
    String itcUnavailabilityReason;
    String sourceType;
    String irn;
    String irnGeneratedDate;

}
