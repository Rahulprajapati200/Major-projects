package com.bdo.bvms.invoices.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BaseReqDTO {

    int userId;

    String bearerToken;

    int entityId;

    int userTypeId;

    String entityTypId;

    String ipAddress;

}
