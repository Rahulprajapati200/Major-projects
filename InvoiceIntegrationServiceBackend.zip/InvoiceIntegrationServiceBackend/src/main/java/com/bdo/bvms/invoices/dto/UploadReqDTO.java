package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UploadReqDTO extends JsonToObjectDTO {

    private int id;
    private String batchNo;
    private String fileName;
    private int tenantId;
    private String jsonReq;
    private int processStatus;
    private String fileSize;
    private int uploadBy;
    private String uploadType;
    private int uploadLogId;
    private String vendorGstin;
    private String invoiceNo;
    private String invoiceDate;
    private String docType;
    private String isCustomTemplate;
    private String customTemplateId;
    private int userId;
    private String uplodSource;
    
    private String isVendorPan;
    private String vendorPanOrGstin;
    private String vendorCode;

}
