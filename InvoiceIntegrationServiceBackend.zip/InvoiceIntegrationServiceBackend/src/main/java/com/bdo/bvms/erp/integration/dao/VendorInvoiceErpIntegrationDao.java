package com.bdo.bvms.erp.integration.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import org.json.JSONArray;

public interface VendorInvoiceErpIntegrationDao {

	Map<String, Object> getErpInvoiceDataParentProcCall(String ackNo) throws SQLException;

	void updateErpCommunicationLog(JSONArray responseJson, int id) throws IOException;

	int insertErpCommunicationLog(String requestJson, String apiName) throws IOException;

	String getErpDbDetails();

	String getErpSecretDetail();

	void updateErpRequestLog(String payloadJson, String batchNo, Long key);

	Long insertIntoErpRequestLog(String reqJson, String reqFor);

}
