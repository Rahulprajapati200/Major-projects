package com.bdo.bvms.invoices.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.dao.CustomTemplateRepo;
import com.bdo.bvms.invoices.taxpayer.sql.MasterSQL;

@Repository
public class CustomTemplateDaoImpl implements CustomTemplateRepo {

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Override
    public Map<String, String> searchCustomTemplateHeaderMappings(int customTemplateId) {
        return jdbcTemplateMst.query(MasterSQL.GET_CUSTOM_TEMPLATE_HEADER_MAPPING_SQL,
                        new ResultSetExtractor<Map<String, String>>() {

                            @Override
                            public Map<String, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                Map<String, String> mapRet = new HashMap<>();
                                while (rs.next()) {
                                    mapRet.put(rs.getString("standardHeader"), rs.getString("customHeader"));
                                }
                                return mapRet;
                            }
                        }, customTemplateId);
    }

}
