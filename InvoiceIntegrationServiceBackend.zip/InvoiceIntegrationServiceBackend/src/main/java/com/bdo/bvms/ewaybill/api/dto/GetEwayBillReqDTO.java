package com.bdo.bvms.ewaybill.api.dto;

import com.bdo.bvms.invoices.dto.BaseReqDTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class GetEwayBillReqDTO extends BaseReqDTO {

    int id;
    String taxpayerGstin;
    String ewaybillNo;
    String ewaybillDate;
    String requestType;
    String batchNo;
    String isCallFromSchedular;
    int successCount;

}
