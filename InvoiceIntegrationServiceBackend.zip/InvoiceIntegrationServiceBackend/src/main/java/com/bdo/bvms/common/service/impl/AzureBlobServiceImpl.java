package com.bdo.bvms.common.service.impl;

import org.springframework.stereotype.Component;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import com.bdo.bvms.common.service.IAzureBlobService;
import com.bdo.bvms.invoices.ocr.model.EntityCloudCredentials;

@Component
public class AzureBlobServiceImpl implements IAzureBlobService{

	
            @Override
            public  BlobClient getBlobClientWithEndPoint(EntityCloudCredentials entityCloudCredentials, String fileName) {
                BlobContainerClient blobContainerClient = new BlobContainerClientBuilder()
                                .endpoint(entityCloudCredentials.getUrl()).containerName(entityCloudCredentials.getContainerName()).buildClient();
                return blobContainerClient.getBlobClient(fileName);
            }

	
}
