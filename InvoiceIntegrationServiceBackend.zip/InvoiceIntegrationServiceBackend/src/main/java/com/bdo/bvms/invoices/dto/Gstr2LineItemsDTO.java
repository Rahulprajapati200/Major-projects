package com.bdo.bvms.invoices.dto;

import java.math.BigDecimal;

import com.bdo.bvms.invoices.util.NumberUtils;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class Gstr2LineItemsDTO {

   
    String taxableAmount;
  
    String ratePercent;

    String igstAmount;

    String cgstAmount;

    String sgstAmount;

    String cessAmount;
    String igstRate;

    String sgstRate;

    String cgstRate;

    String cessRate;

    String totalTax;
    
    String reversecharge;

}
