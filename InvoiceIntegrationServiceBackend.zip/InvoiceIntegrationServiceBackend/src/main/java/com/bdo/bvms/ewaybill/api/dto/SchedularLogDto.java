package com.bdo.bvms.ewaybill.api.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class SchedularLogDto {
	
	int id;
	String schedularCallFor;
	String taxpayerGstin;
	String ewaybillDate;
	String isSucess;
	String errorRemarks;
	String isStartedBySupportTeam;
	

}
