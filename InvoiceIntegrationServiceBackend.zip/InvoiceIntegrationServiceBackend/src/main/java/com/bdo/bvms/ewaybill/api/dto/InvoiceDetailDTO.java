package com.bdo.bvms.ewaybill.api.dto;

import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class InvoiceDetailDTO {

    String taxpayerGstin;
    String taxpayerPan;
    String vendorGstin;
    String vendorPan;
    String ewaybillNo;
    String ewaybillDate;
    String taxableValue;
    String invoiceValue;
    String cgst;
    String sgst;
    String igst;
    String cess;
    int pldGetType;
    int syncStatus;
    String returnPeriod;
    int yearId;
    String docReturnPeriod;
    int docYearId;
    String category;
    String noteType;
    Timestamp createdOn;
    int createdBy;
    String invoiceNo;
    String invoiceDate;

}
