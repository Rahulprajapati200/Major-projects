package com.bdo.bvms.invoices.dto;

import java.io.Serializable;

/**
 *FileType: java
 *Author : anka
 *Created On : 02/11/2017 6:56:39 PM
 *Copy Rights : Anka Technology Solutions Pvt. Ltd.
 */
public class BVMSError implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer rowId;
	private String egstErrorCode;
	private String egstErrorCodeDiscription;
	public Integer getRowId() {
		return rowId;
	}
	public void setRowId(Integer rowId) {
		this.rowId = rowId;
	}
	public String getEGSTErrorCode() {
		return egstErrorCode;
	}
	public void setEGSTErrorCode(String eGSTErrorCode) {
		egstErrorCode = eGSTErrorCode;
	}
	public String getEGSTErrorDiscription() {
		return egstErrorCodeDiscription;
	}
	public void setEGSTErrorDiscription(String eGSTErrorDiscription) {
		egstErrorCodeDiscription = eGSTErrorDiscription;
	}
	

}
