package com.bdo.bvms.invoices.dao;

import java.util.List;
import java.util.Map;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.ProcessedListDataResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface VendorJourneyDataListDao {

    Map<String, Object> gettotalDocumentsDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
                    String monthList) throws VendorInvoiceServerException;

    Map<String, Object> getdraftDocumentsDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
                    String monthList) throws VendorInvoiceServerException;

    Map<String, Object> getsubmittedPendingApprovalDocumentsDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException;

    Map<String, Object> getApprovedDocumentsDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException;

    Map<String, Object> getRejectedDocumentsDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException;

    List<ProcessedListDataResDTO> getProcessedInvoiceDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException;

}
