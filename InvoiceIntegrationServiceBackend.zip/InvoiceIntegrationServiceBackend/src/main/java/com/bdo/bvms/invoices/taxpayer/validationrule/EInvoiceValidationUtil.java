package com.bdo.bvms.invoices.taxpayer.validationrule;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.invoices.constant.Constants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EInvoiceValidationUtil {

    public boolean checkInvoiceLength13(String value) {
        boolean isvalid = true;
        if (value != null && value.length() > 13) {
            isvalid = false;
        }

        return isvalid;
    }

    public boolean checkUDFLength(String udfx) {
        if (udfx.length() > 200) {
            return (udfx.length() > 200);
        }
        return false;

    }

    public boolean checkFuturePeriod(String fp) {
        String year = StringUtils.right(fp, 4);
        String month = StringUtils.left(fp, 2);

        StringBuilder yearMonth = new StringBuilder(year + "-" + month);
        YearMonth yearMonthParsed = YearMonth.parse(yearMonth);
        SimpleDateFormat sdformat = new SimpleDateFormat(Constants.YEARMONTH);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");

        // Format this year-month
        YearMonth ym = YearMonth.now();

        try {
            if (StringUtils.isBlank(yearMonth)) {
                return true;
            }
            if (StringUtils.isBlank(yearMonth)) {
                return true;
            }
            Date d1 = sdformat.parse(yearMonthParsed.format(formatter));
            Date d2 = sdformat.parse(ym.format(formatter));

            if (d1.compareTo(d2) > 0) {
                return true;
            }

        } catch (ParseException e) {
            log.error("Error occured while execute checkFuturePeriod function:", e);
            return true;
        }
        return false;
    }

    public boolean isValidInvoiceDate(String value) {

        if (StringUtils.isBlank(value) || value.matches(Constants.NONVALIDDATEFORMAT) || value.equals("0")
                        || value.equals("") || value.equals("-")) {
            return false;
        } else {
            try {
                if (value.indexOf("-") >= 1) {
                    return validateDates(value);
                } else {
                    String[] parts = value.split("/");
                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        int date = Integer.parseInt(parts[0]);
                        int month = Integer.parseInt(parts[1]);
                        int year = Integer.parseInt(parts[2]);
                        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                            Calendar c = Calendar.getInstance();
                            c.set(Calendar.DAY_OF_MONTH, date);
                            c.set(Calendar.MONTH, month - 1);
                            c.set(Calendar.YEAR, year);

                            return checkDateWithDateFormat2(value);
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                }
            } catch (Exception ex) {
                log.error("Error occured while execute isValidInvoiceDate function:", ex);
                return false;
            }
        }
    }

    private boolean checkDate(String value) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATEFORMATE1);
            formatter.setLenient(false);
            formatter.parse(value);
            return true;

        } catch (ParseException e) {
            log.error("Error occured while execute checkDate function:", e);
            return false;
        }
    }

    public boolean isValidPurchaseOrderDate(String value) {

        if (StringUtils.isBlank(value) || value.matches(Constants.NONVALIDDATEFORMAT) || "0".equals(value)
                        || value.equals("") || value.equals("-")) {
            return false;
        } else {
            try {
                if (value.indexOf("-") >= 1) {
                    return validateDates(value);
                } else {
                    String[] parts = value.split("/");
                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        int date = Integer.parseInt(parts[0]);
                        int month = Integer.parseInt(parts[1]);
                        int year = Integer.parseInt(parts[2]);
                        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                            Calendar c = Calendar.getInstance();
                            c.set(Calendar.DAY_OF_MONTH, date);
                            c.set(Calendar.MONTH, month - 1);
                            c.set(Calendar.YEAR, year);

                            return checkDateWithDateFormat2(value);
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                }
            } catch (Exception ex) {
                log.error("Error occured while execute isValidPurchaseOrderDate function:", ex);
                return false;
            }
        }
    }

    private boolean checkDateWithDateFormat2(String value) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATEFORMATE2);
            formatter.setLenient(false);
            formatter.parse(value);
            return true;

        } catch (ParseException e) {
            log.error("Error occured while execute checkDateWithDateFormat2 function:", e);
            return false;
        }
    }

    public boolean isValidIRNDate(String value) {

        if (StringUtils.isBlank(value) || value.matches(Constants.NONVALIDDATEFORMAT) || value.equals("0")
                        || value.equals("") || value.equals("-")) {
            return false;
        } else {
            return checkDateValidation(value);
        }
    }

    public boolean checkIfDiluted(String dilutedValidationString, String errorID) {
        if (StringUtils.isBlank(dilutedValidationString)) {
            return false;
        } else {
            return dilutedValidationString.contains(errorID);
        }
    }

    public boolean validGSTIN(String gstin) {

        try {

            if (!"0".equals(gstin)) {
                String gstinFormateRegex = "[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[Z]{1}[0-9a-zA-Z]{1}";

                String tdsREGEX = "[0-9]{2}[a-zA-Z]{4}[a-zA-Z0-9]{1}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[D]{1}[0-9a-zA-Z]{1}";

                boolean isValidFormat = false;

                if (gstin.length() < 15) {
                    return isValidFormat;
                }

                if (checkPattern(gstin, gstinFormateRegex) || checkPattern(gstin, tdsREGEX)) {
                    isValidFormat = verifyCheckDigit(gstin);
                }
                return isValidFormat;

            }

        } catch (Exception ex) {
            log.error("Error occured while execute validGSTIN function:", ex);
            return false;
        }

        return true;
    }

    public boolean checkPattern(String inputval, String regxpatrn) {
        boolean result = false;
        if ((inputval.trim()).matches(regxpatrn)) {
            result = true;
        }
        return result;
    }

    public boolean verifyCheckDigit(String gstinWCheckDigit) {
        Boolean isCDValid = false;
        String newGstninWCheckDigit = getGSTINWithCheckDigit(
                        gstinWCheckDigit.substring(0, gstinWCheckDigit.length() - 1));
        if (gstinWCheckDigit.trim().equals(newGstninWCheckDigit)) {
            isCDValid = true;
        }

        return isCDValid;
    }

    public String getGSTINWithCheckDigit(String gstinWOCheckDigit) {

        int factor = 2;
        int sum = 0;
        int checkCodePoint = 0;
        char[] cpChars;
        char[] inputChars;

        if (gstinWOCheckDigit == null) {

            return "";
        }
        cpChars = Constants.GSTN_CODE_POINT_CHARS.toCharArray();
        inputChars = gstinWOCheckDigit.trim().toUpperCase().toCharArray();

        int mod = cpChars.length;
        for (int i = inputChars.length - 1; i >= 0; i--) {
            int codePoint = -1;

            for (int j = 0; j < cpChars.length; j++) {
                if (cpChars[j] == inputChars[i]) {
                    codePoint = j;
                }
            }
            int digit = factor * codePoint;
            factor = (factor == 2) ? 1 : 2;
            digit = (digit / mod) + (digit % mod);
            sum += digit;
        }
        checkCodePoint = (mod - (sum % mod)) % mod;

        return gstinWOCheckDigit + cpChars[checkCodePoint];

    }

    public boolean isAlphanumeric(String s) {

        boolean validInvoice = true;
        if (StringUtils.isBlank(s)) {
            validInvoice = false;
        }

        if (validInvoice) {

            Pattern p = Pattern.compile("[^0-9A-Za-z ]");
            Matcher m = p.matcher(s);
            if (m.find()) {
                validInvoice = false;
            }
        }
        return validInvoice;
    }

    public boolean isAlphanumericwithoutSpace(String s) {

        boolean validInvoice = true;
        if (StringUtils.isBlank(s)) {
            validInvoice = false;
        }

        if (validInvoice) {

            Pattern p = Pattern.compile("[^0-9A-Za-z]");
            Matcher m = p.matcher(s);
            if (m.find()) {
                validInvoice = false;
            }
        }
        return validInvoice;
    }

    public boolean containsNumbersOnly(String source, Integer typeChk) {
        boolean result = false;
        if (StringUtils.isNotBlank(source)) {
            source = source.trim();
            try {
                if (typeChk == 1) {
                    Pattern pattern;
                    pattern = Pattern.compile("[0-9.]+"); // correct pattern for
                                                          // both float and
                                                          // integer. execute

                    result = pattern.matcher(source).matches();

                    return result;
                } else {
                    Double.parseDouble(source);
                    return true;
                }

            } catch (Exception ex) {
                log.error("Error occured while execute containsNumbersOnly function:", ex);
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean onlyNumericMainHsnCode(String value) {

        boolean isvalid = true;
        if (StringUtils.isBlank(value)) {
            isvalid = false;
        } else {
            Pattern p = Pattern.compile("\\D");
            Matcher m = p.matcher(value);

            if (m.find()) {
                isvalid = false;
            }
        }
        return isvalid;

    }

    public boolean checkDocumentNumber(String docNo) {
        boolean result = true;

        if (StringUtils.isBlank(docNo) || "0".equals(docNo)) {
            result = false;
        }

        if (result) {

            Pattern p = Pattern.compile(Constants.DOCREGEX);
            Matcher m = p.matcher(docNo);
            if (m.find()) {
                result = false;
            } else {
                result = true;
            }
        }
        return result;

    }

    public boolean twoDecimalCheck(String value) {
        boolean isValid = true;
        try {

            if (!value.replace(",", "").matches(Constants.TWODECIMALREGEX)) {
                isValid = false;
            }

        } catch (Exception ex) {
            log.error("Error occured while execute twoDecimalCheck function:", ex);
            return false;
        }
        return isValid;

    }

    public boolean onlyNumeric(String value) {
        boolean isValid = true;
        if (org.apache.commons.lang3.StringUtils.isBlank(value)) {
            isValid = false;
        } else {
            Pattern p = Pattern.compile("[^0-9.]+");
            Matcher m = p.matcher(value.replace(",", ""));

            if (m.find()) {
                isValid = false;
            }

        }

        return isValid;
    }

    //
    public boolean twoDecimalHsnCheckBlank(String value) {
        boolean validData = true;
        if (StringUtils.isBlank(value)) {
            validData = false;
        }
        if (validData && !value.matches(Constants.TWODECIMALHSNCHECKBLANK)) {

            validData = false;
        }
        return validData;
    }

    // function to validate date
    public boolean isValidinwardDate(String value) {

        if (StringUtils.isBlank(value) || value.matches(Constants.NONVALIDDATEFORMAT) || "0".equals(value)
                        || "-".equals(value)) {
            return false;
        } else {
            return checkDateValidation(value);
        }
    }

    private boolean checkDateValidation(String value) {
        try {
            if (value.indexOf("-") >= 1) {
                return validateDates(value);
            } else {
                String[] parts = value.split("/");

                if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                    int date = Integer.parseInt(parts[0]);
                    int month = Integer.parseInt(parts[1]);
                    int year = Integer.parseInt(parts[2]);
                    if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                        Calendar c = Calendar.getInstance();
                        c.set(Calendar.DAY_OF_MONTH, date);
                        c.set(Calendar.MONTH, month - 1);
                        c.set(Calendar.YEAR, year);

                        return checkDate(value);
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            }
        } catch (Exception ex) {
            log.error("Error occured while execute checkDateValidation function:", ex);
            return false;

        }
    }

    private boolean validateDates(String value) {
        String[] parts = value.split("-");

        if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
            int date = Integer.parseInt(parts[0]);
            int month = Integer.parseInt(parts[1]);
            int year = Integer.parseInt(parts[2]);
            if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

                Calendar c = Calendar.getInstance();
                c.set(Calendar.DAY_OF_MONTH, date);
                c.set(Calendar.MONTH, month - 1);
                c.set(Calendar.YEAR, year);

                return checkDate(value);

            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean check16CharacterLength(String value) {
        return is16CharOrNot(value);

    }

    private boolean is16CharOrNot(String value) {
        boolean isValid = Boolean.TRUE;
        if (StringUtils.isNotBlank(value) && !"0".equals(value) && value.length() > 16) {
            isValid = Boolean.FALSE;
            return isValid;

        }

        return isValid;
    }

    public boolean isInvoiceNoExist(String invoiceNo) {
        return isValidOrNot(invoiceNo);
    }

    private boolean isValidOrNot(String invoiceNo) {
        boolean isValid = Boolean.TRUE;
        if ("".equals(invoiceNo) || "0".equals(invoiceNo) || StringUtils.isBlank(invoiceNo)
                        || StringUtils.isEmpty(invoiceNo)) {
            isValid = Boolean.FALSE;
            return isValid;

        }

        return isValid;
    }

    public boolean isSpecialCharExistInInvoiceNo(String invoiceNo) {

        boolean validInvoice = true;

        if (StringUtils.isBlank(invoiceNo) || "0".equals(invoiceNo)) {
            validInvoice = false;
        }

        if (validInvoice) {
            Pattern p = Pattern.compile("[^0-9A-Za-z/-]");
            Matcher m = p.matcher(invoiceNo);
            if (m.find()) {
                validInvoice = false;
            } else {
                validInvoice = true;
            }
        }
        return validInvoice;
    }

    // E-way bill Date cannot be before 1st July 2017

    public boolean isValidDateRange(String geteWayBillDate) {
        SimpleDateFormat sdformat = new SimpleDateFormat(Constants.DATEFORMATE1);
        try {
            if (StringUtils.isBlank(geteWayBillDate)) {
                return false;
            }
            Date d1 = sdformat.parse("01-07-2017");
            Date d2 = sdformat.parse(geteWayBillDate);

            if (d1.compareTo(d2) > 0) {

                return false;
            }

        } catch (ParseException e) {
            log.error("Error occured while execute isValidDateRange function:", e);

            return false;
        }
        return true;
    }

    // E-way bill Date cannot be future date

    public boolean ifFutureDate(String geteWayBillDate) {
        boolean valid = true;

        try {
            SimpleDateFormat sdformat = new SimpleDateFormat(Constants.DATEFORMATE1);

            Date currentDate = new Date();
            Date localDate = null;
            if (StringUtils.isBlank(geteWayBillDate)) {
                valid = Boolean.FALSE;
            }

            localDate = sdformat.parse(geteWayBillDate);

            if (localDate.compareTo(currentDate) > 0) {
                valid = Boolean.FALSE;
            }

        } catch (Exception ex) {
            log.error("Error occured while execute ifFutureDate function:", ex);
            return false;
        }

        return valid;

    }

    // Purchase Order Date cannot exceed docDate

    public boolean ifExceedDate(String poDate, String docDate) {
        SimpleDateFormat sdformat = new SimpleDateFormat(Constants.DATEFORMATE1);
        try {
            if (StringUtils.isBlank(docDate)) {
                return false;
            }
            if (StringUtils.isBlank(poDate)) {
                return false;
            }
            Date d1 = sdformat.parse(poDate);
            Date d2 = sdformat.parse(docDate);

            if (d1.compareTo(d2) > 0) {

                return false;
            }

        } catch (ParseException e) {
            log.error("Error occured while execute ifExceedDate function:", e);

            return false;
        }
        return true;
    }

    // total Invoice Amount should be greater the 5 CR

    public boolean isValidHsn(String s, String hsnConf) {
        if (Double.parseDouble(hsnConf) != 1) {
            if ("".equals(s) || "0".equals(s)) {
                return true;
            } else if (s.length() > 8) {
                return false;
            }

        }
        return true;

    }

    // function for Hsn code not start with 99 then PO will be mandatory

    public boolean isHsnAsPerPO(String hsnCode, String po) {
        boolean isValid = Boolean.TRUE;
        if (!StringUtils.isBlank(hsnCode)) {
            String first2SubStrHsn = hsnCode.substring(0, 2);

            if (!StringUtils.isBlank(hsnCode) && !first2SubStrHsn.equals("99") && ("".equals(po) || "0".equals(po))) {
                isValid = Boolean.FALSE;
                return isValid;
            }
        }
        return isValid;
    }

    public boolean checkFPExceedsInwardDate(String fp, String inwardDate) {

        String yearFP = StringUtils.right(fp, 4);
        String monthFP = StringUtils.left(fp, 2);

        StringBuilder yearMonthFP = new StringBuilder(yearFP + "-" + monthFP);
        YearMonth yearMonthParsedFP = YearMonth.parse(yearMonthFP);
        String yearInwardDate = StringUtils.right(inwardDate, 4);
        String monthInwardDate = inwardDate.substring(3, 5);

        StringBuilder yearMonthInwardDate = new StringBuilder(yearInwardDate + "-" + monthInwardDate);
        YearMonth yearMonthParsedInwardDate = YearMonth.parse(yearMonthInwardDate);

        SimpleDateFormat sdformat = new SimpleDateFormat(Constants.YEARMONTH);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");

        try {
            if (StringUtils.isBlank(yearMonthFP)) {
                return true;
            }
            if (StringUtils.isBlank(yearMonthInwardDate)) {
                return true;
            }
            Date d2 = sdformat.parse(yearMonthParsedFP.format(formatter));
            Date d1 = sdformat.parse(yearMonthParsedInwardDate.format(formatter));

            if (d1.compareTo(d2) > 0) {
                return true;
            }

        } catch (ParseException e) {
            log.error("Error occured while execute checkFPExceedsInwardDate function:", e);
            return true;
        }

        return false;
    }

}
