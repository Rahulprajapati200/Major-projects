package com.bdo.bvms.ewaybill.api.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EWayBillItemsDTO {
	
String itemNo;
String  productId;
String  productName;
String  productDesc;
String hsnCode;
String quantity;
String qtyUnit;
String cgstRate;
String sgstRate;
String igstRate;
String cessRate;
String cessNonAdvol;
String taxableAmount;

}
