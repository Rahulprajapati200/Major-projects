package com.bdo.bvms.einvoice.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.bvms.einvoice.service.VendorInvoiceVendorDetailsService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.VendorInvoiceDetailsRepository;
import com.bdo.bvms.invoices.dto.InvoiceDetailsReqDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsResponseDto;
import com.bdo.bvms.invoices.dto.InvoicePrimaryDetail;
import com.bdo.bvms.invoices.util.ExcelUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class VendorInvoiceVendorDetailsServiceImpl.
 */
@Service
@Slf4j
public class VendorInvoiceVendorDetailsServiceImpl implements VendorInvoiceVendorDetailsService {

    /** The vendor invoice details repository. */
    @Autowired
    VendorInvoiceDetailsRepository vendorInvoiceDetailsRepository;

    /** The temp folder. */
    @Value("${temp.folder.path}")
    String tempFolder;

    /**
     * Gets the download invoice details.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the download invoice details
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    @Override
    public File getDownloadInvoiceDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO)
                    throws VendorInvoiceServerException, IOException {

        InvoiceDetailsResponseDto invoiceDetailsResponseDto = new InvoiceDetailsResponseDto();

        // get basic invoice details by id
        InvoicePrimaryDetail invDetail = vendorInvoiceDetailsRepository.getInvoicePrimaryDetails(invoiceDetailsReqDTO);

        // re-set request dto
        invoiceDetailsReqDTO.setTaxpayerGstin(invDetail.getTaxpayerGstin());
        invoiceDetailsReqDTO.setVendorGstin(invDetail.getVendorGstin());
        invoiceDetailsReqDTO.setInvoiceno(invDetail.getInvoiceNo());
        invoiceDetailsReqDTO.setInvoicedate(invDetail.getInvoiceDate());
        invoiceDetailsReqDTO.setEwbno(invDetail.getEwayBillNo());
        invoiceDetailsReqDTO.setEwbdate(invDetail.getEwayBillDate());

        invoiceDetailsResponseDto
                        .setEInvoiceDTO(vendorInvoiceDetailsRepository.getEInvoiceDetails(invoiceDetailsReqDTO));

        invoiceDetailsResponseDto
                        .setEwayBillDetailDTO(vendorInvoiceDetailsRepository.getEwayBillDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto.setGoodReceiptNoteDTO(
                        vendorInvoiceDetailsRepository.getGoodReceiptNoteDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto.setPurchaseOrderDTO(
                        vendorInvoiceDetailsRepository.getPurchaseOrderDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto
                        .setGetGstr2aDTO(vendorInvoiceDetailsRepository.getGetGstr2aDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto
                        .setGetGstr2bDTO(vendorInvoiceDetailsRepository.getGetGstr2bDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto
                        .setGetEWayBillDTO(vendorInvoiceDetailsRepository.getGetEWayBillDetails(invoiceDetailsReqDTO));

        return downloadInvoiceDetails(invoiceDetailsResponseDto);

    }

    /*
     * public static final String COMPANY_GSTIN = "Company Gstin"; public static
     * final String CUSTOMER_GSTIN = "Customer Gstin";
     */
    /**
     * Download invoice details.
     *
     * @param invoiceDetailsResponseDto
     *            the invoice details response dto
     * @return the file
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    private File downloadInvoiceDetails(InvoiceDetailsResponseDto invoiceDetailsResponseDto) throws IOException {

        String[] vendorInvoiceAllHeaders = { Constants.CUSTOMER_GSTIN, Constants.COMPANY_GSTIN, Constants.IRN,
                Constants.IRN_DATE, Constants.DOC_DATE, Constants.TOTAL_INVOICE_AMT, Constants.DOC_TYPE,
                Constants.NO_OF_LINE_ITEM, Constants.HSN_CODE, Constants.BATCH_NO_HEADING, Constants.E_WAY_BILL_NO,
                Constants.E_WAY_BILL_DATE, Constants.BILL_VALID_DATE, Constants.GENERATED_ON, Constants.GENERATED_BY,
                Constants.PO_NO, Constants.PO_DATE, Constants.GRN_NO, Constants.GRN_DATE, Constants.TAXABLE_AMOUNT,
                Constants.POS, Constants.IGST_AMOUNT, Constants.CGST_AMOUNT, Constants.SGST_AMOUNT,
                Constants.CESS_AMOUNT, Constants.INV_VALUE, Constants.INVOICE_NO, Constants.INVOICE_DATE,
                Constants.DEFAULTSYNCSTATUS, Constants.FORCESYNCSTATUS, Constants.STATUS };

        Map<String, String> eInvoiceData = new HashMap<>();

        eInvoiceData.put(Constants.CUSTOMER_GSTIN, invoiceDetailsResponseDto.getEInvoiceDTO().getTaxpayerGstin());
        eInvoiceData.put(Constants.COMPANY_GSTIN, invoiceDetailsResponseDto.getEInvoiceDTO().getVendorGstin());

        eInvoiceData.put(Constants.IRN, invoiceDetailsResponseDto.getEInvoiceDTO().getIrnNo());
        eInvoiceData.put(Constants.IRN_DATE, invoiceDetailsResponseDto.getEInvoiceDTO().getIrnDate());
        eInvoiceData.put(Constants.DOC_DATE, invoiceDetailsResponseDto.getEInvoiceDTO().getDocDate());
        eInvoiceData.put(Constants.TOTAL_INVOICE_AMT,
                        String.valueOf(invoiceDetailsResponseDto.getEInvoiceDTO().getTotalInvoiceValue()));
        eInvoiceData.put(Constants.INVOICE_NO, invoiceDetailsResponseDto.getEInvoiceDTO().getInvoiceNo());
        eInvoiceData.put(Constants.INVOICE_DATE, invoiceDetailsResponseDto.getEInvoiceDTO().getInvoiceDate());
        eInvoiceData.put(Constants.DOC_TYPE, invoiceDetailsResponseDto.getEInvoiceDTO().getDocType());
        eInvoiceData.put(Constants.NO_OF_LINE_ITEM,
                        String.valueOf(invoiceDetailsResponseDto.getEInvoiceDTO().getNoOfLIneItem()));
        eInvoiceData.put(Constants.HSN_CODE, invoiceDetailsResponseDto.getEInvoiceDTO().getHsnCode());
        eInvoiceData.put(Constants.BATCH_NO_HEADING, invoiceDetailsResponseDto.getEInvoiceDTO().getBatchNo());

        Map<String, String> eWayBillData = new HashMap<>();

        eWayBillData.put(Constants.CUSTOMER_GSTIN, invoiceDetailsResponseDto.getEwayBillDetailDTO().getTaxpayerGstin());
        eWayBillData.put(Constants.COMPANY_GSTIN, invoiceDetailsResponseDto.getEwayBillDetailDTO().getTaxpayerGstin());
        // eWayBillData.put(Constants.TITLE,
        // invoiceDetailsResponseDto.getEwayBillDetailDTO().getTitle());
        eWayBillData.put(Constants.E_WAY_BILL_NO, invoiceDetailsResponseDto.getEwayBillDetailDTO().getEwbNo());
        eWayBillData.put(Constants.E_WAY_BILL_DATE, invoiceDetailsResponseDto.getEwayBillDetailDTO().getEwbDate());
        eWayBillData.put(Constants.BILL_VALID_DATE, invoiceDetailsResponseDto.getEwayBillDetailDTO().getValidTill());
        eWayBillData.put(Constants.BATCH_NO_HEADING, invoiceDetailsResponseDto.getEwayBillDetailDTO().getBatchNo());
        eWayBillData.put(Constants.GENERATED_ON, invoiceDetailsResponseDto.getEwayBillDetailDTO().getGeneratedOn());
        eWayBillData.put(Constants.GENERATED_BY, invoiceDetailsResponseDto.getEwayBillDetailDTO().getGeneratedBy());

        Map<String, String> purchaseOrder = new HashMap<>();

        purchaseOrder.put(Constants.CUSTOMER_GSTIN, invoiceDetailsResponseDto.getPurchaseOrderDTO().getTaxpayerGstin());
        purchaseOrder.put(Constants.COMPANY_GSTIN, invoiceDetailsResponseDto.getPurchaseOrderDTO().getVendorGstin());
        // purchaseOrder.put(Constants.TITLE,
        // invoiceDetailsResponseDto.getPurchaseOrderDTO().getTitle());
        purchaseOrder.put(Constants.PO_NO, invoiceDetailsResponseDto.getPurchaseOrderDTO().getPoNo());
        purchaseOrder.put(Constants.PO_DATE, invoiceDetailsResponseDto.getPurchaseOrderDTO().getPoDate());

        Map<String, String> goodRecieiptNote = new HashMap<>();
        goodRecieiptNote.put(Constants.CUSTOMER_GSTIN,
                        invoiceDetailsResponseDto.getGoodReceiptNoteDTO().getTaxpayerGstin());
        goodRecieiptNote.put(Constants.COMPANY_GSTIN,
                        invoiceDetailsResponseDto.getGoodReceiptNoteDTO().getVendorGstin());
        // goodRecieiptNote.put(Constants.TITLE,
        // invoiceDetailsResponseDto.getGoodReceiptNoteDTO().getTitle());
        goodRecieiptNote.put(Constants.GRN_NO, invoiceDetailsResponseDto.getGoodReceiptNoteDTO().getGrnNo());
        goodRecieiptNote.put(Constants.GRN_DATE, invoiceDetailsResponseDto.getGoodReceiptNoteDTO().getGrnDate());

        Map<String, String> getGstr2aData = new HashMap<>();

        getGstr2aData.put(Constants.CUSTOMER_GSTIN, invoiceDetailsResponseDto.getGetGstr2aDTO().getTaxpayerGstin());
        getGstr2aData.put(Constants.COMPANY_GSTIN, invoiceDetailsResponseDto.getGetGstr2aDTO().getVendorGstin());
        // getGstr2aData.put(Constants.TITLE,
        // invoiceDetailsResponseDto.getGetGstr2aDTO().getTitle());
        getGstr2aData.put(Constants.TAXABLE_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2aDTO().getTaxableAmount()));
        getGstr2aData.put(Constants.POS, invoiceDetailsResponseDto.getGetGstr2aDTO().getPlaceSupply());
        getGstr2aData.put(Constants.IGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2aDTO().getIgstAmount()));
        getGstr2aData.put(Constants.CGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2aDTO().getCgstAmount()));
        getGstr2aData.put(Constants.SGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2aDTO().getSgstAmount()));
        getGstr2aData.put(Constants.CESS_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2aDTO().getCessAmount()));
        getGstr2aData.put(Constants.INV_VALUE,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2aDTO().getInvoiceValue()));
        getGstr2aData.put(Constants.INVOICE_NO, invoiceDetailsResponseDto.getGetGstr2aDTO().getInvoiceNo());
        getGstr2aData.put(Constants.INVOICE_DATE, invoiceDetailsResponseDto.getGetGstr2aDTO().getInvoiceDate());
        getGstr2aData.put(Constants.IS_SYNC, invoiceDetailsResponseDto.getGetGstr2aDTO().isSync() ? "Yes" : "No");
        getGstr2aData.put(Constants.DEFAULTSYNCSTATUS,
                        invoiceDetailsResponseDto.getGetGstr2aDTO().isDefaultSyncStatus() ? "Yes" : "No");
        getGstr2aData.put(Constants.FORCESYNCSTATUS,
                        invoiceDetailsResponseDto.getGetGstr2aDTO().isForceSyncStatus() ? "Yes" : "No");

        Map<String, String> getGstr2bData = new HashMap<>();

        getGstr2bData.put(Constants.CUSTOMER_GSTIN, invoiceDetailsResponseDto.getGetGstr2bDTO().getTaxpayerGstin());
        getGstr2bData.put(Constants.COMPANY_GSTIN, invoiceDetailsResponseDto.getGetGstr2bDTO().getVendorGstin());

        getGstr2bData.put(Constants.TAXABLE_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2bDTO().getTaxableAmount()));
        getGstr2bData.put(Constants.POS, invoiceDetailsResponseDto.getGetGstr2bDTO().getPlaceSupply());
        getGstr2bData.put(Constants.IGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2bDTO().getIgstAmount()));
        getGstr2bData.put(Constants.CGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2bDTO().getCgstAmount()));
        getGstr2bData.put(Constants.SGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2bDTO().getSgstAmount()));
        getGstr2bData.put(Constants.CESS_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2bDTO().getCessAmount()));
        getGstr2bData.put(Constants.INV_VALUE,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2bDTO().getInvoiceValue()));
        getGstr2bData.put(Constants.INVOICE_NO, invoiceDetailsResponseDto.getGetGstr2bDTO().getInvoiceNo());
        getGstr2bData.put(Constants.INVOICE_DATE, invoiceDetailsResponseDto.getGetGstr2bDTO().getInvoiceDate());
        getGstr2bData.put(Constants.DEFAULTSYNCSTATUS,
                        invoiceDetailsResponseDto.getGetGstr2bDTO().isDefaultSyncStatus() ? "Yes" : "No");
        getGstr2bData.put(Constants.FORCESYNCSTATUS,
                        invoiceDetailsResponseDto.getGetGstr2bDTO().isForceSyncStatus() ? "Yes" : "No");

        Map<String, String> getGetEWayBillData = new HashMap<>();

        getGetEWayBillData.put(Constants.CUSTOMER_GSTIN,
                        invoiceDetailsResponseDto.getGetEWayBillDTO().getTaxpayerGstin());
        getGetEWayBillData.put(Constants.COMPANY_GSTIN, invoiceDetailsResponseDto.getGetEWayBillDTO().getVendorGstin());

        getGetEWayBillData.put(Constants.TAXABLE_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetEWayBillDTO().getTaxableAmount()));
        getGetEWayBillData.put(Constants.POS, invoiceDetailsResponseDto.getGetEWayBillDTO().getPlaceSupply());
        getGetEWayBillData.put(Constants.IGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetEWayBillDTO().getIgstAmount()));
        getGetEWayBillData.put(Constants.CGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetEWayBillDTO().getCgstAmount()));
        getGetEWayBillData.put(Constants.SGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetEWayBillDTO().getSgstAmount()));
        getGetEWayBillData.put(Constants.CESS_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetEWayBillDTO().getCessAmount()));
        getGetEWayBillData.put(Constants.INV_VALUE,
                        String.valueOf(invoiceDetailsResponseDto.getGetEWayBillDTO().getInvValue()));
        getGetEWayBillData.put(Constants.INVOICE_NO, invoiceDetailsResponseDto.getGetEWayBillDTO().getInvoiceNo());
        getGetEWayBillData.put(Constants.INVOICE_DATE, invoiceDetailsResponseDto.getGetEWayBillDTO().getInvoiceDate());
        getGetEWayBillData.put(Constants.E_WAY_BILL_NO, invoiceDetailsResponseDto.getGetEWayBillDTO().getEwbNo());
        getGetEWayBillData.put(Constants.E_WAY_BILL_DATE, invoiceDetailsResponseDto.getGetEWayBillDTO().getEwbDate());
        getGetEWayBillData.put(Constants.STATUS,
                        invoiceDetailsResponseDto.getGetEWayBillDTO().isStatus() ? "Yes" : "No");
        getGetEWayBillData.put(Constants.DEFAULTSYNCSTATUS,
                        invoiceDetailsResponseDto.getGetEWayBillDTO().isDefaultSyncStatus() ? "Yes" : "No");
        getGetEWayBillData.put(Constants.FORCESYNCSTATUS,
                        invoiceDetailsResponseDto.getGetEWayBillDTO().isForceSyncStatus() ? "Yes" : "No");

        try (XSSFWorkbook wb = new XSSFWorkbook()) {

            XSSFSheet sheet = wb.createSheet(Constants.INVOICE_DETAILS_HEADING);
            ExcelUtils.setFilterAndFredgeHeader(sheet, new CellRangeAddress(1, 1, 0, 31));
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 31));
            Map<String, Object> bothHeadersStyles = ExcelUtils.getHeadersStyles(wb, sheet);
            CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles.get(Constants.HEADERCELLSTYLE1);
            CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles.get(Constants.HEADERCELLSTYLE2);
            CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles.get(Constants.HEADERCELLSTYLE3);

            Row row0 = sheet.createRow(0);
            Cell headerCell = row0.createCell(0);
            headerCell.setCellValue(Constants.INVOICE_DETAILS_HEADING);
            headerCell.setCellStyle(headerCellStyle1);

            Row row1 = sheet.createRow(1);
            Row row2 = sheet.createRow(2);
            Row row3 = sheet.createRow(3);
            Row row4 = sheet.createRow(4);
            Row row5 = sheet.createRow(5);
            Row row6 = sheet.createRow(6);
            Row row7 = sheet.createRow(7);
            Row row8 = sheet.createRow(8);
            int index = 1;

            Cell cell0 = row1.createCell(0);
            cell0.setCellValue("Data Type");
            cell0.setCellStyle(headerCellStyle2);
            Cell cell1 = row2.createCell(0);
            cell1.setCellValue("e-Invoice");
            cell1.setCellStyle(headerCellStyle3);
            Cell cell2 = row3.createCell(0);
            cell2.setCellValue("e-Way Bill");
            cell2.setCellStyle(headerCellStyle3);
            Cell cell3 = row4.createCell(0);
            cell3.setCellValue("Purchase Order");
            cell3.setCellStyle(headerCellStyle3);
            Cell cell4 = row5.createCell(0);
            cell4.setCellValue("Goods Receipt Note");
            cell4.setCellStyle(headerCellStyle3);
            Cell cell5 = row6.createCell(0);
            cell5.setCellValue("GET GSTR2A");
            cell5.setCellStyle(headerCellStyle3);
            Cell cell6 = row7.createCell(0);
            cell6.setCellValue("GET GSTR2B");
            cell6.setCellStyle(headerCellStyle3);
            Cell cell7 = row8.createCell(0);
            cell7.setCellValue("GET e-Way Bill");
            cell7.setCellStyle(headerCellStyle3);

            for (String header : vendorInvoiceAllHeaders) {

                Cell headercell = row1.createCell(index);
                headercell.setCellValue(header);
                headercell.setCellStyle(headerCellStyle2);

                String eInvoiceDataAccToHeader = eInvoiceData.get(header);
                Cell eInvoicecell = row2.createCell(index);
                eInvoicecell.setCellValue(eInvoiceDataAccToHeader);
                eInvoicecell.setCellStyle(headerCellStyle3);

                String eWayDataAccToHeader = eWayBillData.get(header);
                Cell eWaycell = row3.createCell(index);
                eWaycell.setCellValue(eWayDataAccToHeader);
                eWaycell.setCellStyle(headerCellStyle3);

                String purchaseOrderAccToHeader = purchaseOrder.get(header);
                Cell purchaseOrdercell = row4.createCell(index);
                purchaseOrdercell.setCellValue(purchaseOrderAccToHeader);
                purchaseOrdercell.setCellStyle(headerCellStyle3);

                String goodReceiptNoteDataAccToHeader = goodRecieiptNote.get(header);
                Cell goodReceiptNotecell = row5.createCell(index);
                goodReceiptNotecell.setCellValue(goodReceiptNoteDataAccToHeader);
                goodReceiptNotecell.setCellStyle(headerCellStyle3);

                String gstr2aDataAccToHeader = getGstr2aData.get(header);
                Cell gstr2acell = row6.createCell(index);
                gstr2acell.setCellValue(gstr2aDataAccToHeader);
                gstr2acell.setCellStyle(headerCellStyle3);

                String gstr2bDataAccToHeader = getGstr2bData.get(header);
                Cell gstr2bcell = row7.createCell(index);
                gstr2bcell.setCellValue(gstr2bDataAccToHeader);
                gstr2bcell.setCellStyle(headerCellStyle3);

                String getEwayBillDataAccToHeader = getGetEWayBillData.get(header);
                Cell getEWayBillcell = row8.createCell(index);
                getEWayBillcell.setCellValue(getEwayBillDataAccToHeader);
                getEWayBillcell.setCellStyle(headerCellStyle3);

                index++;

            }
            for (int i = 0; i <= 31; i++) {
                sheet.autoSizeColumn(i);
            }

            String tempfilePath = new StringBuilder().append(tempFolder).append(File.separator)
                            .append(ExcelUtils.getReportsExcelFileName(Constants.INVOICE_DETAILS,
                                            new Timestamp(System.currentTimeMillis())))
                            .toString();

            if (StringUtils.isBlank(tempFolder)) {
                tempfilePath = new StringBuilder().append(ExcelUtils.getReportsExcelFileName(Constants.INVOICE_DETAILS,
                                new Timestamp(System.currentTimeMillis()))).toString();
            }

            File file = new File(tempfilePath);

            if (file.exists()) {
                FileUtils.deleteQuietly(file);
            }
            try (FileOutputStream out = new FileOutputStream(file)) {
                wb.write(out);
                out.close();
            }

            return file;
        }

    }

}
