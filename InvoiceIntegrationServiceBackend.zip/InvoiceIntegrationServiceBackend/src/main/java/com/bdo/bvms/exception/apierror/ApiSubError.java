package com.bdo.bvms.exception.apierror;

public abstract class ApiSubError {

    @Override
    public String toString() {

        return super.toString();
    }

}