package com.bdo.bvms.invoices.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.dao.SyncOperationDataListDao;
import com.bdo.bvms.invoices.dto.Gstr2aResponseDTO;
import com.bdo.bvms.invoices.dto.Gstr2HeaderDTOForForceSync;
import com.bdo.bvms.invoices.dto.Gstr2aSyncUnsyncDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsReqDTO;
import com.bdo.bvms.invoices.taxpayer.sql.TransactionSQL;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class SyncOperationDataListDaoImpl implements SyncOperationDataListDao {

    @Autowired
    private JdbcTemplate jdbcTemplateTrn;

    @Override
    public List<Gstr2aSyncUnsyncDTO> getUnsyncDataList(InvoiceDetailsReqDTO invoiceDetailsReqDTO, int getTypepldCode) {

        List<Gstr2aSyncUnsyncDTO> lineItemList = jdbcTemplateTrn.query(TransactionSQL.SEARCH_UNSYNC_DATALIST,
                        BeanPropertyRowMapper.newInstance(Gstr2aSyncUnsyncDTO.class),
                        invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                        "%" + invoiceDetailsReqDTO.getSearchKey() + "%", getTypepldCode, invoiceDetailsReqDTO.getSize(),
                        invoiceDetailsReqDTO.getPage() * invoiceDetailsReqDTO.getSize());

        return lineItemList;

    }

    @Override
    public List<Gstr2aSyncUnsyncDTO> getsyncData(InvoiceDetailsReqDTO invoiceDetailsReqDTO, int getTypepldCode) {

        List<Gstr2aSyncUnsyncDTO> lineItemList = jdbcTemplateTrn.query(TransactionSQL.SEARCH_SYNC_DATALIST,
                        BeanPropertyRowMapper.newInstance(Gstr2aSyncUnsyncDTO.class),invoiceDetailsReqDTO.getId(),
                        invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                         getTypepldCode);

        return lineItemList;
    }

    @Override
    public int getCountUnsyncDataList(InvoiceDetailsReqDTO invoiceDetailsReqDTO, int getTypepldCode) {

        return jdbcTemplateTrn.queryForObject(TransactionSQL.GET_COUNT_UNSYNC_DATALIST, Integer.class,
                        invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                        "%" + invoiceDetailsReqDTO.getSearchKey() + "%", getTypepldCode);

    }

	@Override
	public Gstr2HeaderDTOForForceSync getInvoiceHeaderDetailsForForceSync(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {
		 try {
	            return jdbcTemplateTrn.queryForObject(
	                            TransactionSQL.searchInvoiceHeaderForceSyncSql(invoiceDetailsReqDTO.getTabId()),
	                            BeanPropertyRowMapper.newInstance(Gstr2HeaderDTOForForceSync.class),
	                            invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
	                            invoiceDetailsReqDTO.getInvoiceno(), invoiceDetailsReqDTO.getInvoicedate(),invoiceDetailsReqDTO.getId());
	        } catch (Exception e) {
	            log.error("Error occured while execute getInvoiceHeaderDetails function:", e.getMessage());
	            return new Gstr2HeaderDTOForForceSync();
	        }
		
	}

}
