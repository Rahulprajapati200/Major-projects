package com.bdo.bvms.einvoice.service;

import java.io.IOException;

import com.bdo.bvms.invoices.custom.exception.AzureUploadDownloadException;
import com.bdo.bvms.invoices.dto.UploadReqDTO;

public interface InvoiceOcrFileMetaDataCloudStore {


	void saveFileMetaDataToAzure(UploadReqDTO uploadDTO) throws IOException, AzureUploadDownloadException;

}
