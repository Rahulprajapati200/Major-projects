package com.bdo.bvms.invoices.taxpayer.sql;

import org.springframework.beans.factory.annotation.Value;

public class MasterSQL {

    @Value("${txn.database-name}")
    static String tranDb;

    @Value("${mst.database-name}")
    static String mstDb;

    MasterSQL() {
    }

    public static final String GET_ERRORCODE_AND_SHORTDESCRIPTION = "SELECT ErrorCode,ShortDescription FROM bvms_error";
    public static final String GET_ID_HSNCODE = "select id, hsn_sac_code as hsn_code from sm_hsn_sac_master ";
    public static final String GET_AM_ENTITY_GSTIN_LIST_QYERY = "SELECT distinct to_base64(gstin) FROM " + mstDb
                    + ".am_entity_master where pan=to_base64(";
    public static final String GET_AZURE_CREDENTIAL_FROM_DB = "select url,container_name from sm_entity_cloud_credentials where entity_id=? AND type=?";

    public static final String GET_AZURE_CREDENTIAL_FROM_DB_PROC_CALL = new String(
                    "{ call GET_CLOUD_STORAGE_CREDENTIALS (?) }");

    public static final String GET_CUSTOM_TEMPLATE_HEADER_MAPPING_SQL = new StringBuilder(
                    "SELECT  cc.column_name as standardHeader , cm.template_column as customHeader \n")
                                    .append(" FROM am_template_column_configuration cc ")
                                    .append(" INNER JOIN   am_custom_template_column_mapping cm ON cc.id = cm.am_template_column_configuration_id\n")
                                    .append(" where cm.custom_template_name_id=? order by cc.order_no  ").toString();
    public static final String YEARIDQUERY = "SELECT fp,year_id FROM sm_return_periods";

    public static final String GETALIASHQUERY = "select column_screen_name,advance_search_column_name from sm_grid_customize_column where \r\n"
                    + "pld_module_id=? and tab_id=? and is_advance_search=1;";

    public static String getTaxpayerGstinFromDbSql(String dbName) {
        return "select distinct from_base64(gstin) from " + dbName
                        + ".am_entity_master where pan=? and is_active=1 and draft_status=1 and entity_status=1";
    }

    public static String getVendorGstinFromDbSql() {
        return "select gstin_vendor from taxpayer_vendors where pan_vendor=?";
    }

    public static String getMonthFromDbSql(String mstDatabseName) {
        return "Select fp from " + mstDatabseName + ".sm_return_periods where year_id=?";
    }

    public static String getBatchUploadInPrevFp(String mstDatabseName) {
        return "select distinct lower(concat(inward_no,inward_date)) from invoice_eway_bill_details where gstin_of_supplier =? and filling_period in (select fp FROM "
                        + mstDatabseName + ".sm_return_periods where year_id !=?)";
    }

    public static final String GET_SYSTEM_PARAMETER_CREDENTIAL = "SELECT keyValue FROM system_parameter where KeyName = ?";

    public static String getFpYear(String mstDatabseName) {
        return "select year_id FROM " + mstDatabseName + ".sm_return_periods where fp=?";

    }

    public static final String GET_APP_KEY = new StringBuilder(
                    "select KeyVALUE from system_parameter where KeyNAME= ? ").toString();

    public static final String GET_MAIL_BY_USER_ID = new StringBuilder(
                    "select login_id as email from am_user_master where user_id=?").toString();

}
