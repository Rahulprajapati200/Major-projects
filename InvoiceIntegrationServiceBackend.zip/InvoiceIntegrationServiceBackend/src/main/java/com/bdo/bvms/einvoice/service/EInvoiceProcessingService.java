package com.bdo.bvms.einvoice.service;

import java.util.List;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.ResponseBean;
import com.bdo.bvms.invoices.dto.UploadReqDTO;

/**
 * The Interface EInvoiceProcessingService.
 */
public interface EInvoiceProcessingService {

    /**
     * Gets the success data list.
     *
     * @return the success data list
     */
    List<EInvoiceTemplateDTO> getSuccessDataList();

    /**
     * Gets the error data list.
     *
     * @return the error data list
     */
    List<EInvoiceTemplateDTO> getErrorDataList();

    /**
     * Start processing invoice data.
     *
     * @param cdnList
     *            the cdn list
     * @param vbo
     *            the vbo
     * @param threadCnt
     *            the thread cnt
     * @return the response bean
     * @throws Exception
     */
    ResponseBean startProcessingInvoiceData(List<EInvoiceTemplateDTO> cdnList, UploadReqDTO vbo, int threadCnt)
                    throws VendorInvoiceServerException;

}
