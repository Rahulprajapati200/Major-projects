package com.bdo.bvms.ocr.repository;

import java.sql.BatchUpdateException;
import java.util.LinkedHashMap;
import java.util.List;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.ocr.model.OcrInvoiceHeader;
import com.bdo.bvms.invoices.ocr.model.OcrVerticalMap;
import com.bdo.bvms.ocr.dto.OcrComplianceErrorDto;
import com.bdo.bvms.ocr.dto.OcrPullLogDto;
import com.bdo.bvms.ocr.dto.OcrPushLogDto;
import com.bdo.bvms.ocr.dto.OcrVerticalDataObj;

public interface FileOcrProcessAndSaveRepository {

	LinkedHashMap<String, Integer> getOCRFieldConfigMap(int isLineItem);

	void saveToOcrVerticalData(List<OcrVerticalDataObj> data) throws VendorInvoiceServerException, BatchUpdateException;

	LinkedHashMap<Integer, String> getFilesToProcessOcr();

	void insertToInvoiceEwayBillDetails(List<EInvoiceTemplateDTO> data,UploadReqDTO uploadDTO) throws VendorInvoiceServerException;

	Integer getYearIdByFp(String fp);

	Integer insertIntoOCRPullLog(OcrPullLogDto ocrPullLogDto);

	Integer insertIntoOCRPushLog(OcrPushLogDto ocrPushLogDto);

	void updateOcrStatus(Integer fileId, int lockFoOcr, String ocrStatus);

	LinkedHashMap<Integer, String> getFilesToPullOcr();

	void updateOcrPullLog(OcrPullLogDto ocrPullLogDto);

	Integer deleteVerticalMapDetails(Integer fileId);

	Integer insertVerticalMapArchive(Integer fileId);

	void insertIntoComplianceErrorTable(List<OcrComplianceErrorDto> OcrComplianceErrorList)
			throws VendorInvoiceServerException;

   List<OcrComplianceErrorDto> getOcrComplianceValidation(int fileId, int errorType);


  List<UploadReqDTO> getUploadHstoryByBatchNo(String batchNos);

   Integer deleteFromInvoiceHeader(String batchNo);

  Integer deleteFromInvoiceEWBDetails(String batchNo);

String getStateCodeByStateName(String stateName);



}
