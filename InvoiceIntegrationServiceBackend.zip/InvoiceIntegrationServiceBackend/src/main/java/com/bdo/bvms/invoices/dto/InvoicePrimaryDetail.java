package com.bdo.bvms.invoices.dto;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@Getter
@Setter
public class InvoicePrimaryDetail {

    String taxpayerGstin;
    String vendorGstin;
    String invoiceNo;
    String invoiceDate;
    String ewayBillNo;
    String ewayBillDate;
    Integer ocrHeaderId;
    String vendorPan;
    String vendorCodeErp;

}
