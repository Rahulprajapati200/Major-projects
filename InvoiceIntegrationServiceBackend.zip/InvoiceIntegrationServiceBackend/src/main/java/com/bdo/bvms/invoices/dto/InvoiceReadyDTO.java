package com.bdo.bvms.invoices.dto;

public class InvoiceReadyDTO {

    private String taxpayerGstin;
    private String vendorGstin;
    private String vendorLegalName;
    private String vendorTradeName;
    private String invoiceNo;
    private String invoiceDate;
    private String syncGstr2a;
    private String syncGstr2b;
    private String syncEWayBill;
    private String taxableValue;
    private String igst;
    private String cgst;
    private String sgst;
    private String cess;
    private String invoiceValue;
    private String eWayBillNo;
    private String eWayBillDate;
    private String poNumber;
    private String totalPo;
    private String grnNumber;
    private String detailsUploadDate;
    private String mainHsnCode;
    private String itemCount;
    private String irnNumber;
    private String qrCodeValid;
    private String lstSyncedDate;
    private String bookedErp;

   

    public String getTaxpayerGstin() {
        return taxpayerGstin;
    }

    public void setTaxpayerGstin(String taxpayerGstin) {
        this.taxpayerGstin = taxpayerGstin;
    }

    public String getVendorGstin() {
        return vendorGstin;
    }

    public void setVendorGstin(String vendorGstin) {
        this.vendorGstin = vendorGstin;
    }

    public String getVendorLegalName() {
        return vendorLegalName;
    }

    public void setVendorLegalName(String vendorLegalName) {
        this.vendorLegalName = vendorLegalName;
    }

    public String getVendorTradeName() {
        return vendorTradeName;
    }

    public void setVendorTradeName(String vendorTradeName) {
        this.vendorTradeName = vendorTradeName;
    }

    public String getInvoiceNo() {
        return invoiceNo;
    }

    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getSyncGstr2a() {
        return syncGstr2a;
    }

    public void setSyncGstr2a(String syncGstr2a) {
        this.syncGstr2a = syncGstr2a;
    }

    public String getSyncGstr2b() {
        return syncGstr2b;
    }

    public void setSyncGstr2b(String syncGstr2b) {
        this.syncGstr2b = syncGstr2b;
    }

    public String getSyncEWayBill() {
        return syncEWayBill;
    }

    public void setSyncEWayBill(String syncEWayBill) {
        this.syncEWayBill = syncEWayBill;
    }

    public String getTaxableValue() {
        return taxableValue;
    }

    public void setTaxableValue(String taxableValue) {
        this.taxableValue = taxableValue;
    }

    public String getIgst() {
        return igst;
    }

    public void setIgst(String igst) {
        this.igst = igst;
    }

    public String getCgst() {
        return cgst;
    }

    public void setCgst(String cgst) {
        this.cgst = cgst;
    }

    public String getSgst() {
        return sgst;
    }

    public void setSgst(String sgst) {
        this.sgst = sgst;
    }

    public String getCess() {
        return cess;
    }

    public void setCess(String cess) {
        this.cess = cess;
    }

    public String getInvoiceValue() {
        return invoiceValue;
    }

    public void setInvoiceValue(String invoiceValue) {
        this.invoiceValue = invoiceValue;
    }

    public String geteWayBillNo() {
        return eWayBillNo;
    }

    public void seteWayBillNo(String eWayBillNo) {
        this.eWayBillNo = eWayBillNo;
    }

    public String geteWayBillDate() {
        return eWayBillDate;
    }

    public void seteWayBillDate(String eWayBillDate) {
        this.eWayBillDate = eWayBillDate;
    }

    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    public String getTotalPo() {
        return totalPo;
    }

    public void setTotalPo(String totalPo) {
        this.totalPo = totalPo;
    }

    public String getGrnNumber() {
        return grnNumber;
    }

    public void setGrnNumber(String grnNumber) {
        this.grnNumber = grnNumber;
    }

    public String getDetailsUploadDate() {
        return detailsUploadDate;
    }

    public void setDetailsUploadDate(String detailsUploadDate) {
        this.detailsUploadDate = detailsUploadDate;
    }

    public String getMainHsnCode() {
        return mainHsnCode;
    }

    public void setMainHsnCode(String mainHsnCode) {
        this.mainHsnCode = mainHsnCode;
    }

    public String getItemCount() {
        return itemCount;
    }

    public void setItemCount(String itemCount) {
        this.itemCount = itemCount;
    }

    public String getIrnNumber() {
        return irnNumber;
    }

    public void setIrnNumber(String irnNumber) {
        this.irnNumber = irnNumber;
    }

    public String getQrCodeValid() {
        return qrCodeValid;
    }

    public void setQrCodeValid(String qrCodeValid) {
        this.qrCodeValid = qrCodeValid;
    }

    public String getLstSyncedDate() {
        return lstSyncedDate;
    }

    public void setLstSyncedDate(String lstSyncedDate) {
        this.lstSyncedDate = lstSyncedDate;
    }

    public String getBookedErp() {
        return bookedErp;
    }

    public void setBookedErp(String bookedErp) {
        this.bookedErp = bookedErp;
    }

    @Override
    public String toString() {
        return "InvoiceReadyDTO [taxpayerGstin=" + taxpayerGstin + ", vendorGstin=" + vendorGstin + ", vendorLegalName="
                        + vendorLegalName + ", vendorTradeName=" + vendorTradeName + ", invoiceNo=" + invoiceNo
                        + ", invoiceDate=" + invoiceDate + ", syncGstr2a=" + syncGstr2a + ", syncGstr2b=" + syncGstr2b
                        + ", syncEWayBill=" + syncEWayBill + ", taxableValue=" + taxableValue + ", igst=" + igst
                        + ", cgst=" + cgst + ", sgst=" + sgst + ", cess=" + cess + ", invoiceValue=" + invoiceValue
                        + ", eWayBillNo=" + eWayBillNo + ", eWayBillDate=" + eWayBillDate + ", poNumber=" + poNumber
                        + ", totalPo=" + totalPo + ", grnNumber=" + grnNumber + ", detailsUploadDate="
                        + detailsUploadDate + ", mainHsnCode=" + mainHsnCode + ", itemCount=" + itemCount
                        + ", irnNumber=" + irnNumber + ", qrCodeValid=" + qrCodeValid + ", lstSyncedDate="
                        + lstSyncedDate + ", bookedErp=" + bookedErp + "]";
    }

}
