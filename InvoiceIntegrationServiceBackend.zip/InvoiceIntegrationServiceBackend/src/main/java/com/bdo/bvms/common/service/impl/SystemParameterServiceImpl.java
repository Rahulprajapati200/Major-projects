package com.bdo.bvms.common.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.repository.ISystemParameterRepository;
import com.bdo.bvms.common.service.ISystemParameterService;
import com.bdo.bvms.invoices.custom.exception.ResourceNotFoundException;
import com.bdo.bvms.invoices.ocr.dao.SearchSystemParameterResDTO;
import com.bdo.bvms.invoices.ocr.model.SystemParameter;
import com.bdo.bvms.taxpayer.request.dto.SearchSystemParameterReqDTO;

@Service

public class SystemParameterServiceImpl implements ISystemParameterService{

    @Autowired
    private ISystemParameterRepository systemParameterRepositoryImpl;
    
    @Override
    public SearchSystemParameterResDTO searchSystemParameter(SearchSystemParameterReqDTO searchSystemParameterReqDTO) {
        SystemParameter systemParameter = null;
        try {
            systemParameter = systemParameterRepositoryImpl.searchSystemParameter(
                            SystemParameter.builder().keyName(searchSystemParameterReqDTO.getKeyName()).build());
        } catch (EmptyResultDataAccessException e) {
            throw new ResourceNotFoundException(SearchSystemParameterReqDTO.class, "keyName",
                            searchSystemParameterReqDTO.getKeyName());
        }
        return SearchSystemParameterResDTO.builder().keyName(systemParameter.getKeyName())
                        .keyValue(systemParameter.getKeyValue()).build();
    }
    
}
