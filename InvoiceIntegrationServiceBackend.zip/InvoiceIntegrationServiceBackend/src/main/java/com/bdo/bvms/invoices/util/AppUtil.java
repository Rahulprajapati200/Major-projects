package com.bdo.bvms.invoices.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.springframework.beans.factory.annotation.Autowired;

import com.bdo.bvms.einvoice.service.UploadLogService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.ReadInvoicePojoListException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.csvreader.CsvReader;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AppUtil {

    @Autowired
    static UploadLogService uploadLogService;

    @Autowired
    static CommonDao commonDao;

    private AppUtil() {

    }

    public static String getCellValue(Cell cell) {
        String strCellValue = Constants.BLANK;

        try {

            if (cell != null) {

                strCellValue = switchOnCellTypeValue(cell, strCellValue);
            }

        } catch (Exception ex) {
            log.error("Error occured while execute getCellValue function:", ex);
            strCellValue = switchOnCellTypeValue(cell, strCellValue);
        }
        return strCellValue;
    }

    private static String switchOnCellTypeValue(Cell cell, String strCellValue) {
        switch (cell.getCellType()) {
        case STRING:
            strCellValue = cell.getStringCellValue().replaceAll(Constants.LINERETURNTAB, Constants.SPACE);
            break;
        case FORMULA:
            switch (cell.getCachedFormulaResultType()) {
            case BOOLEAN:
                strCellValue = Boolean.toString(cell.getBooleanCellValue());
                break;
            case NUMERIC:
                strCellValue = NumberToTextConverter.toText(cell.getNumericCellValue());
                break;
            case STRING:

                strCellValue = cell.getRichStringCellValue().getString().replaceAll(Constants.LINERETURNTAB,
                                Constants.SPACE);
                break;
            default:
            }

            break;
        case NUMERIC:
            if (DateUtil.isCellDateFormatted(cell)) {
                SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.VALIDDATEFORMAT);
                strCellValue = dateFormat.format(cell.getDateCellValue());

            } else {
                strCellValue = NumberToTextConverter.toText(cell.getNumericCellValue());
            }
            break;
        case BOOLEAN:
            strCellValue = Boolean.toString(cell.getBooleanCellValue());
            break;
        case BLANK:
            strCellValue = Constants.BLANK;
            break;
        default:

        }
        return strCellValue;
    }

    public static Map<String, Integer> getColumnNameIndexMap(Row coumnsDataRow) throws ReadInvoicePojoListException {

        Map<String, Integer> colNameIndexMap = new HashMap<>();
        try {
            colNameIndexMap = new java.util.HashMap<>();
            // map
            int minColIx = coumnsDataRow.getFirstCellNum(); // get the first
                                                            // column
            // index for a row
            int maxColIx = coumnsDataRow.getLastCellNum(); // get the last
                                                           // column
            // index for a row
            Cell cell;
            for (int colIx = minColIx; colIx < maxColIx; colIx++) { // loop from
                // first to last
                // index
                cell = coumnsDataRow.getCell(colIx); // get the cell

                if (cell.getCellType() == CellType.NUMERIC) {
                    colNameIndexMap.put(String.valueOf(cell.getNumericCellValue()), cell.getColumnIndex());
                } else {
                    colNameIndexMap.put(cell.getStringCellValue().replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE),
                                    cell.getColumnIndex());
                }

            }
        } catch (Exception e) {
            log.error("Error occured while execute getColumnNameIndexMap function:", e);
            throw new ReadInvoicePojoListException("Error occured while getting ColumnNameIndexMap :", e.getCause());
        }
        return colNameIndexMap;
    }

    public static Boolean isNotBlank(Row row) {
        int cellCount;
        Cell cell;
        for (cellCount = row.getFirstCellNum(); cellCount <= row.getLastCellNum(); cellCount++) {
            cell = row.getCell(cellCount);
            if (cell != null && row.getCell(cellCount).getCellType() != CellType.BLANK) {
                return true;
            }
        }
        return false;
    }

    public static List<String> getColumnNameList(Row coumnsDataRow) {

        List<String> headerList = new ArrayList<>();
        int minColIx = coumnsDataRow.getFirstCellNum(); // get the first column
        // index for a row
        int maxColIx = coumnsDataRow.getLastCellNum(); // get the last column
        // index for a row
        Cell cell;
        for (int colIx = minColIx; colIx < maxColIx; colIx++) { // loop from

            cell = coumnsDataRow.getCell(colIx); // get the cell

            if (cell.getCellType() == CellType.NUMERIC) {
                headerList.add(String.valueOf(cell.getNumericCellValue()));
            } else {
                headerList.add(cell.getStringCellValue());
            }
        }
        return headerList;
    }

    public static void createTempFolder(String tempFolder) {
        File file = new File(tempFolder);
        if (!file.exists()) {
            file.mkdir();
        }
    }

    public static String[] getHeaders(CsvReader products) throws IOException {
        String[] data = null;

        while (products.readRecord()) {
            if (products.getCurrentRecord() == 0) {
                data = products.getValues();
                break;
            }

        }

        return data;
    }

}
