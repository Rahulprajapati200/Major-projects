package com.bdo.bvms.ewaybill.api;

import com.bdo.bvms.invoices.dto.EwayBillheaderDTO;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;


public interface GetEwayBillDetailsService {

	EwayBillheaderDTO getEwayBillDetails(GetEwayBillReqDTO reqDto) throws InvoiceIntegrationEWBException;

}