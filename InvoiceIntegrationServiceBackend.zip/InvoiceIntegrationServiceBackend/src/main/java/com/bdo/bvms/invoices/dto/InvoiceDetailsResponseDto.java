package com.bdo.bvms.invoices.dto;


import com.bdo.bvms.ocr.dto.OcrDetail;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class InvoiceDetailsResponseDto {

    String baseData;
    EInvoiceDTO eInvoiceDTO;
    EwayBillDetailDTO ewayBillDetailDTO;
    PurchaseOrderDTO purchaseOrderDTO;
    GoodReceiptNoteDTO goodReceiptNoteDTO;
    GetGstr2aDTO getGstr2aDTO;
    GetGstr2bDTO getGstr2bDTO;
    GetEWayBillDTO getEWayBillDTO;
    OcrDetail ocrDetail;

}
