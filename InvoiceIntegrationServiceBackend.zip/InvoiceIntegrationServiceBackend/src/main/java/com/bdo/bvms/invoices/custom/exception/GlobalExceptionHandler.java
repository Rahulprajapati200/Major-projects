package com.bdo.bvms.invoices.custom.exception;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.NOT_FOUND;

import java.sql.SQLException;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import com.bdo.bvms.exception.apierror.ApiError;
import lombok.extern.slf4j.Slf4j;

@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	/**
	 * Handles ResourceNotFoundException.
	 *
	 * @param ex the ResourceNotFoundException
	 * @return the ApiError object
	 */
	@ExceptionHandler(ResourceNotFoundException.class)
	protected ResponseEntity<Object> handleResourceNotFoundException(ResourceNotFoundException ex) {
		log.error("Error::",ex);
		ApiError apiError = new ApiError(NOT_FOUND);
		String errorMsg=setErrorMessage(ex);
		apiError.setMessage(errorMsg);
		apiError.setDebugMessage(ex.getMessage());
		
		return buildResponseEntity(apiError);
	}

	
	/**
	 * Handle MissingServletRequestParameterException. Triggered when a 'required' request parameter is missing.
	 *
	 * @param ex      MissingServletRequestParameterException
	 * @param headers HttpHeaders
	 * @param status  HttpStatus
	 * @param request WebRequest
	 * @return the ApiError object
	 */
	@Override
	protected ResponseEntity<Object> handleMissingServletRequestParameter(
			MissingServletRequestParameterException ex, 
			HttpHeaders headers, 
			HttpStatus status, 
			WebRequest request) {
		
		String errorMsg=setErrorMessage(ex);
		log.error("Error::",ex);
		
		return buildResponseEntity(new ApiError(BAD_REQUEST, errorMsg, ex));
	}

	/**
	 * Handle HttpMediaTypeNotSupportedException. Says that the specified request media type (Content type) is not supported!. This one triggers when JSON is invalid as well.
	 *
	 * @param ex      HttpMediaTypeNotSupportedException
	 * @param headers HttpHeaders
	 * @param status  HttpStatus
	 * @param request WebRequest
	 * @return the ApiError object
	 */
	@Override
	protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(
			HttpMediaTypeNotSupportedException ex,
			HttpHeaders headers,
			HttpStatus status,
			WebRequest request) {
		StringBuilder builder = new StringBuilder();
		builder.append(ex.getContentType());
		builder.append("media type is not supported. Supported media types are ");
		ex.getSupportedMediaTypes().forEach(t -> builder.append(t).append(", "));
		
		return buildResponseEntity(new ApiError(HttpStatus.UNSUPPORTED_MEDIA_TYPE, builder.substring(0, builder.length() - 2), ex));
	}

	/**
	 * Handle HttpRequestMethodNotSupportedException. Triggered when an unsupported Request Method in invoked.
	 *
	 * @param ex      HttpRequestMethodNotSupportedException
	 * @param headers HttpHeaders
	 * @param status  HttpStatus
	 * @param request WebRequest
	 * @return the ApiError object
	 */
	@Override
	protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(
			HttpRequestMethodNotSupportedException ex,
			HttpHeaders headers,
			HttpStatus status,
			WebRequest request) {
		StringBuilder builder = new StringBuilder();
		builder.append(ex.getMethod());
		builder.append(" method is not supported for this request.");
		
		return buildResponseEntity(new ApiError(HttpStatus.METHOD_NOT_ALLOWED, builder.substring(0, builder.length() - 2), ex));
	}	

	/**
	 * Handle HttpMessageNotReadableException. Happens when request JSON is malformed.
	 *
	 * @param ex      HttpMessageNotReadableException
	 * @param headers HttpHeaders
	 * @param status  HttpStatus
	 * @param request WebRequest
	 * @return the ApiError object
	 */
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
		ServletWebRequest servletWebRequest = (ServletWebRequest) request;
		log.error("{} to {}", servletWebRequest.getHttpMethod(), servletWebRequest.getRequest().getServletPath());
		
		String error = "Malformed JSON request";        
		return buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
	}

	/**
	 * Handle HttpMessageNotWritableException.
	 * 
	 *
	 * @param ex      HttpMessageNotWritableException
	 * @param headers HttpHeaders
	 * @param status  HttpStatus
	 * @param request WebRequest
	 * @return the ApiError object
	 */
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotWritable(HttpMessageNotWritableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
		String errorMsg=setErrorMessage(ex);
		log.error("Error::",ex);
		//String error = "Error writing JSON output";
		return buildResponseEntity(new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, errorMsg, ex));
	}

	/**
	 * Handle NoHandlerFoundException. 
	 * DispatcherServlet send, by default, a 404 response if there is no handler for a particular request! 
	 * So, to override the default behavior of our Servlet and throw NoHandlerFoundException instead, we need to add the some properties to application.properties file!
	 * (No example of this being thrown in the code)
	 *
	 * @param ex
	 * @param headers
	 * @param status
	 * @param request
	 * @return
	 */
	@Override
	protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
		ApiError apiError = new ApiError(BAD_REQUEST);
		
		String errorMsg=setErrorMessage(ex);
		log.error("Error::",ex);
		apiError.setMessage(String.format(errorMsg, ex.getHttpMethod(), ex.getRequestURL()));
		apiError.setDebugMessage(ex.getMessage());
		
		return buildResponseEntity(apiError);
	}

	/**
	 * Handle Exception, handle generic Exception.class. Thrown when a method parameter has the wrong type! Example: GET http://localhost:8080/customers/adsdada
	 * (No example of this being thrown in the code)
	 *
	 * @param ex the Exception
	 * @return the ApiError object
	 */
	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	protected ResponseEntity<Object> handleMethodArgumentTypeMismatch(MethodArgumentTypeMismatchException ex, WebRequest request) {
		
		ApiError apiError = new ApiError(BAD_REQUEST);

		String errorMsg=setErrorMessage(ex);
		apiError.setMessage(errorMsg);
		apiError.setDebugMessage(ex.getMessage());
		log.error("Error::",ex);
				
		return buildResponseEntity(apiError);
	}

	/**
	 * Handle DataAccessException, inspects the cause for different DB causes.
	 * (No example of this being thrown in the code)
	 *
	 * @param ex the DataAccessException
	 * @return the ApiError object*/

	@ExceptionHandler(DataAccessException.class)
	public ResponseEntity<Object> handleDatabaseException(DataAccessException ex, WebRequest request) { 
		ApiError apiError = new ApiError(NOT_FOUND);
		String errorMsg=setErrorMessage(ex);
		apiError.setMessage(errorMsg);
		apiError.setDebugMessage(ex.getMessage());
		log.error("Error::",ex);
		return buildResponseEntity(apiError);		
	}
	
	
	@ExceptionHandler(InvoiceTemplateUploadException.class)
	protected ResponseEntity<Object> invoiceTemplateUploadExceptionHandler(MethodArgumentTypeMismatchException ex, WebRequest request) {
		
		ApiError apiError = new ApiError(BAD_REQUEST);
		String errorMsg=setErrorMessage(ex);
		apiError.setMessage(errorMsg);		
		apiError.setDebugMessage(ex.getMessage());		
		log.error("Error occured while uplaod invoice integration related files", ex);		
		return buildResponseEntity(apiError);
	}
	
	@ExceptionHandler(InvoiceIntegrationEWBException.class)
	protected ResponseEntity<Object> VendorInvoiceServerExceptionExceptionHandler(Exception ex, WebRequest request) {
		
		log.error("Error:::",ex );
		ApiError apiError = new ApiError(BAD_REQUEST);
		apiError.setDebugMessage(ex.getMessage());
		String errorMsg=setErrorMessage(ex);
		apiError.setMessage(errorMsg);
		apiError.setDebugMessage(ex.getMessage());
	
		return buildResponseEntity(apiError);
	}	
	
	

	/**
	 * Handle any Exception.
	 * 
	 * @param ex      Exception
	 * @param request WebRequest
	 * @return the ApiError object
	 */
	@ExceptionHandler({ Exception.class })
	public ResponseEntity<Object> handleAll(Exception ex, WebRequest request) {
		log.error("Error:::",ex );
		ApiError apiError = new ApiError(BAD_REQUEST);
		apiError.setDebugMessage(ex.getMessage());
		String errorMsg=setErrorMessage(ex);
		apiError.setMessage(errorMsg);
		apiError.setDebugMessage(ex.getMessage());	
		return buildResponseEntity(apiError);
	}
	
	/**
	 * Handle any Exception.
	 * 
	 * @param ex      Exception
	 * @param request WebRequest
	 * @return the ApiError object
	 */
	@ExceptionHandler({ VendorInvoiceServerException.class })
	public ResponseEntity<Object> handleVendorinvoiceExceptionAll(Exception ex, WebRequest request) {
		log.error("SQL Exception:::",ex );
		ApiError apiError = new ApiError(BAD_REQUEST);
		apiError.setDebugMessage(ex.getMessage());
		String errorMsg=setErrorMessage(ex);
		apiError.setMessage(errorMsg);
		apiError.setDebugMessage(ex.getMessage());	
		return buildResponseEntity(apiError);
	}
	
	@ExceptionHandler({DataIntegrityViolationException.class })
	public ResponseEntity<Object> handleDataIntegrityViolationExceptionException(Exception ex, WebRequest request) {
		log.error("SQL Exception:::",ex );
		ApiError apiError = new ApiError(BAD_REQUEST);
		apiError.setDebugMessage(ex.getMessage());
		String errorMsg=setErrorMessage(ex);
		apiError.setMessage(errorMsg);
		apiError.setDebugMessage(ex.getMessage());	
		return buildResponseEntity(apiError);
	}
	
	
	
	/**
	 * Handle any Exception.
	 * 
	 * @param ex      Exception
	 * @param request WebRequest
	 * @return the ApiError object
	 */
	@ExceptionHandler({ SQLException.class })
	public ResponseEntity<Object> handleSQLExceptionAll(Exception ex, WebRequest request) {
		log.error("SQL Exception:::",ex );
		ApiError apiError = new ApiError(BAD_REQUEST);
		apiError.setDebugMessage(ex.getMessage());
		String errorMsg=setErrorMessage(ex);
		apiError.setMessage(errorMsg);
		apiError.setDebugMessage(ex.getMessage());	
		return buildResponseEntity(apiError);
	}
	
	

	private ResponseEntity<Object> buildResponseEntity(ApiError apiError) {
		return new ResponseEntity<>(apiError, apiError.getHttpStatus());
	}

	 String setErrorMessage(Exception ex) {
			String errorMsg=ex.getMessage();
	        if(errorMsg.contains("Exception")) {
	        	errorMsg="Something went wrong, Kindly contact to Support Team.";
	        }
			return errorMsg;
		}
}