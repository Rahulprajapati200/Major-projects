package com.bdo.bvms.invoices.dto;

import java.math.BigDecimal;

import com.bdo.bvms.invoices.util.NumberUtils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Gstr2aSyncUnsyncDTO {

    int id;
    Boolean status;
    String vendorGstin;
    String taxpayerGstin;
    String docType;
    String fileType;
    String hsnCode;
    String invoiceNo;
    String invoiceDate;
    String taxableValue;
    String igst;
    String cgst;
    String sgst;
    String totalInvoiceValue;
    String catagory;
    String irnNo;
    String irnDate;

    public void setTaxableValue(BigDecimal value) {
        this.taxableValue = NumberUtils.getFormattedGrouppedNumber(value);

    }

    public void setIgst(BigDecimal value) {
        this.igst = NumberUtils.getFormattedGrouppedNumber(value);

    }

    public void setCgst(BigDecimal value) {
        this.cgst = NumberUtils.getFormattedGrouppedNumber(value);

    }

    public void setSgst(BigDecimal value) {
        this.sgst = NumberUtils.getFormattedGrouppedNumber(value);

    }

    public void setTotalInvoiceValue(BigDecimal value) {
        this.totalInvoiceValue = NumberUtils.getFormattedGrouppedNumber(value);

    }

}
