package com.bdo.bvms.einvoice.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.einvoice.service.EinvoiceDataTemplateUpload;
import com.bdo.bvms.einvoice.service.EwayBillUploadDataService;
import com.bdo.bvms.einvoice.service.ProcessUploadService;
import com.bdo.bvms.einvoice.service.UploadLogService;
import com.bdo.bvms.einvoice.service.UploadNDownloadFileService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.AzureUploadDownloadException;
import com.bdo.bvms.invoices.custom.exception.InvalidTemplateHeaderException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceSavedataOnUploadException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.EInvoiceDao;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.bvms.invoices.util.AppUtil;
import com.bdo.bvms.invoices.util.CommonUtils;
import com.bdo.bvms.ocr.service.InvoiceOcrFileUploadService;
import com.bdo.bvms.urp.service.UrpInvoiceUploadService;
import com.bdo.invoices.sftp.upload.service.SftpUploadService;
import com.google.common.io.Files;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProcessUploadServiceImpl implements ProcessUploadService {

	@Autowired
	EinvoiceDataTemplateUpload einvoiceDataTemplateUpload;

	@Autowired
	EInvoiceDao eInvoiceDao;

	@Autowired
	UploadTransDao uploadTransDao;

	@Autowired
	EwayBillUploadDataService ewayBillReadDataService;

	@Autowired
	EinvoiceDataTemplateUploadImpl dataUpload;

	@Autowired
	UploadNDownloadFileService uploadFileService;

	@Autowired
	UploadLogService uploadLogService;
	
	@Autowired
	InvoiceOcrFileUploadService invoiceOcrFileUploadService;
	
	@Autowired
	UrpInvoiceUploadService urpInvoiceUploadService;

	@Value("${temp.folder.path}")
	String tempFolder;

	String fileStatus;

	@Autowired
	CommonDao commonDao;
	
    @Autowired
    private MessageSource messageSource;

    SftpUploadService sftpUploadService;
    
	@Override
	public String uploadAndProcessFile(UploadRequestDTO uploadRequestDTO) throws VendorInvoiceServerException {
		String parentBatchNo = CommonUtils.getBatchNo(uploadRequestDTO);
        uploadRequestDTO.setPaBatchNo(parentBatchNo);
        
		try {
			for (MultipartFile childFile : uploadRequestDTO.getFile()) {
				String batchNo = CommonUtils.getBatchNo(uploadRequestDTO);

				try {

					String originalFileName = childFile.getOriginalFilename();
					String fileName;
					String fileExt = "";

					if (StringUtils.isNotBlank(originalFileName)) {
						fileExt = Files.getFileExtension(originalFileName);
						uploadRequestDTO.setFileType(fileExt);
					}
                    
					UploadReqDTO uploadReqDTO = new UploadReqDTO();

					if ("".equals(uploadRequestDTO.getTemplatetypepldCode())) {
						uploadRequestDTO.setTemplatetypepldCode(
								Integer.toString(uploadTransDao.updatePldCode(uploadRequestDTO.getCustomtemplateID())));
					}
					uploadTransDao.insertStageNState(Constants.PROCESS_STAGE_FILE_UPLOAD,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadRequestDTO,batchNo);
					uploadLogService.saveInUploadLog(childFile, uploadRequestDTO, batchNo);

					int uploadLogId = uploadLogService.getUploadLogId(batchNo);

					fileName = new StringBuilder().append(batchNo).append(Constants.UNSERSCORE_BASE)
							.append(Constants.DOTSEPARATOR).append(fileExt).toString();
					
					AzureConnectionCredentialsDTO storageCredentials = commonDao.getAzureCredentialFromDB(uploadRequestDTO.getEntityId(), "blob");
					if("1".equals(uploadRequestDTO.getUploadSftpSource()))
					{
						uploadFileService.uploadSftpFileToAzureBlob(uploadRequestDTO, batchNo, storageCredentials);
						uploadReqDTO.setUplodSource("ftps");
					}
					else
					{
					    uploadFileService.uploadFileToAzureBlob(childFile, uploadRequestDTO, batchNo, storageCredentials);
					}
					AppUtil.createTempFolder(tempFolder);
                    
					uploadFileService.downloadFileFromAzureBlob(fileName, tempFolder, storageCredentials, uploadReqDTO);
                    
					setUploadDto(uploadRequestDTO, batchNo, uploadReqDTO, uploadLogId);
					if (StringUtils.isBlank(childFile.getOriginalFilename())) {
						uploadTransDao.updateProcessStatusWithRemarks(batchNo,
								Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, "Invalid file type");
						log.error("Original File is Blank for this File:" + batchNo);
						return Constants.FILEFORMATNOTALLOWED;

					}
					if (!(fileExt.equals(uploadRequestDTO.getFileType()))) {
						uploadTransDao.updateProcessStatusWithRemarks(batchNo,
								Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, "Please choose valid file type");

						return Constants.FILETYPENOTCORRECT;
					}

					if (Constants.CSV.equalsIgnoreCase(fileExt) || Constants.XLSX.equalsIgnoreCase(fileExt) || Constants.XLS.equalsIgnoreCase(fileExt)
							|| Constants.PDF.equalsIgnoreCase(fileExt) || Constants.PNG.equalsIgnoreCase(fileExt)
							|| Constants.JPG.equalsIgnoreCase(fileExt)) {

						if (Constants.E_INVOICE_CODE.equalsIgnoreCase(uploadReqDTO.getUploadType())) {
							einvoiceDataTemplateUpload.validateAndSaveData(uploadReqDTO, storageCredentials);
						} else if (Constants.E_WAY_BILL_CODE.equalsIgnoreCase(uploadReqDTO.getUploadType())) {
							ewayBillReadDataService.validateNSaveData(uploadReqDTO, storageCredentials);
						} else if (Constants.INVOICE_CODE.equalsIgnoreCase(uploadReqDTO.getUploadType())) {
							if(uploadReqDTO.getIsVendorPan().equals("0")) {
							  einvoiceDataTemplateUpload.validateAndSaveData(uploadReqDTO, storageCredentials);
							}
							else {
								urpInvoiceUploadService.readAndSaveUnprocessedData(uploadReqDTO, storageCredentials);
							}

						}
						// extended case for INVOICE OCR/E-INVOICE OCR
						else if(Constants.INVOICE_OCR_CODE.equalsIgnoreCase(uploadReqDTO.getUploadType())){
							invoiceOcrFileUploadService.readAndSaveUnprocessedData(uploadReqDTO, storageCredentials);
						}
						else {
							uploadTransDao.updateProcessStatusWithRemarks(batchNo,
									Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, "Template Invalid");
							return Constants.INVALIDTEMPLATETYPE;
						}

					} else {
						uploadTransDao.updateProcessStatusWithRemarks(batchNo,
								Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, "Invalid file type");
						return Constants.FILEFORMATNOTALLOWED;
					}

				} catch (VendorInvoiceSavedataOnUploadException | AzureUploadDownloadException
						| InvalidTemplateHeaderException e) {
					uploadTransDao.updateProcessStatusWithRemarks(batchNo, Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL,
							e.getMessage());
					throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                            LocaleContextHolder.getLocale()));
				}
				catch (Exception e) {
					// Add entry in the exception log table
					log.error("Error occured while uplaoding template for bacthno.:" + batchNo, e);
					uploadTransDao.updateProcessStatusWithRemarks(batchNo, Constants.UPLOAD_INVOICES_PLD_STATUS_ERROR,
							e.getMessage());
					uploadTransDao.updateProcessStatus(batchNo, Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
					throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                            LocaleContextHolder.getLocale()));
					// UploadStageLog also need to be updated****
				}
			}
		} catch (Exception e) {
			log.error("Error occured while uplaoding template for bacthno.:" + parentBatchNo, e);
			throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                    LocaleContextHolder.getLocale()));
		}
		return Constants.FILEUPLOADEPROGRESS;
	}
	
	private void setUploadDto(UploadRequestDTO uploadRequestDTO, String batchNo, UploadReqDTO uploadReqDTO,
			int uploadLogId) {
		uploadReqDTO.setFileType(uploadRequestDTO.getFileType());
		uploadReqDTO.setPo(uploadRequestDTO.getPo());
		uploadReqDTO.setPoDate(uploadRequestDTO.getPoDate());
		uploadReqDTO.setGstinOrPanList(uploadRequestDTO.getGstinOrPanList());
		uploadReqDTO.setUploadType(uploadRequestDTO.getTemplatetypepldCode());
		uploadReqDTO.setTemplateType(uploadRequestDTO.getTemplatetypepldCode());
		uploadReqDTO.setPanOrGstn(uploadRequestDTO.getGstinOrPan());
		uploadReqDTO.setFp(uploadRequestDTO.getFp());
		uploadReqDTO.setBatchNo(batchNo);
		uploadReqDTO.setUploadLogId(uploadLogId);
		uploadReqDTO.setId(uploadRequestDTO.getUserId());
		uploadReqDTO.setVendorPanOrGstin(uploadRequestDTO.getVendorPanOrGstin());
		uploadReqDTO.setVendorCode(uploadRequestDTO.getVendorCode());
		uploadReqDTO.setIsVendorPan(uploadRequestDTO.getIsVendorPan());
		uploadReqDTO.setInvoiceNo(uploadRequestDTO.getInvoiceNo());
		uploadReqDTO.setInvoiceDate(uploadRequestDTO.getInvoiceDate());
		uploadReqDTO.setDocType(uploadRequestDTO.getDocType());
		uploadReqDTO.setIsCustomTemplate(uploadRequestDTO.getIsCustomTemplate());
		uploadReqDTO.setCustomTemplateId(uploadRequestDTO.getCustomtemplateID());
		uploadReqDTO.setGstinOrPanList(uploadRequestDTO.getGstinOrPanList());
		uploadReqDTO.setUserId(uploadRequestDTO.getUserId());
		uploadLogService.saveInUploadStageLog(uploadRequestDTO, uploadReqDTO);
	}
}
