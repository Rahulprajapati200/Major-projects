package com.bdo.bvms.ewaybill.api.demo.impl;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bdo.bvms.ewaybill.api.GetEwayBillApiDao;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.ewaybill.api.dto.NicAuthResponseDTO;
import com.bdo.bvms.ewaybill.api.dto.TaxpayerDetailsDTO;
import com.bdo.bvms.ewaybill.api.impl.EWayBillBDOAuthentication;
import com.bdo.bvms.ewaybill.api.impl.EWayBillDetailsApi;
import com.bdo.bvms.ewaybill.api.impl.EWayBillNicAuthentication;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.dto.EwayBillheaderDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class GetEwayBillDemo {
	
	RestTemplate restTemplate = new RestTemplate();

    @Autowired
    EWayBillBDOAuthentication eWayBillBDOAuthentication;

    @Autowired
    EWayBillNicAuthentication eWayBillNicAuthentication;
	
	 @Autowired
	 GetEwayBillApiDao getEwayBillApiDao;
	 

    public EwayBillheaderDTO callForGetEwaybillDetailsDemo(GetEwayBillReqDTO reqDto) throws InvoiceIntegrationEWBException {

    	try {
    		String clientId = getEwayBillApiDao.getEwayBillClientId();
            String seckey = getEwayBillApiDao.getEwayBillClientSecretEncrypted();
    		String appKey = getEwayBillApiDao.getEwayBillAppKey();
            String eWayBillApiBaseURL = getEwayBillApiDao.getEwayBillApiUrl();
            String eWayBillApiURL = eWayBillApiBaseURL + "?ewbNo= " + reqDto.getEwaybillNo();
            EwayBillheaderDTO ewayBillheaderInfo = null;

            // Get username and password
            TaxpayerDetailsDTO taxpayerDetails = getEwayBillApiDao
                            .getTaxpayerDetailsFromEntityMaster(reqDto.getTaxpayerGstin());

            // get bdo auth token
            String bdoAuthKey = eWayBillBDOAuthentication.bdoAuthEWB(clientId, seckey, reqDto,
                            Constants.GET_EWAYBILL_PLD_CODE);

            //get nic auth token
            NicAuthResponseDTO nicAuthResponseDTO = null;
            nicAuthResponseDTO = eWayBillNicAuthentication.nicAuthEWB(bdoAuthKey, clientId, seckey, reqDto,
                                Constants.GET_EWAYBILL_PLD_CODE, taxpayerDetails);
            

            // get ewaybill details
             EWayBillDetailsApi ewayBillApi = new EWayBillDetailsApi();
             ewayBillheaderInfo = ewayBillApi.getEwayBillDetailsAPI(appKey, reqDto.getTaxpayerGstin(), clientId, seckey,
                                eWayBillApiURL, restTemplate, bdoAuthKey, nicAuthResponseDTO.getNicAuthToken(),
                                nicAuthResponseDTO.getNicSek());
         
                return ewayBillheaderInfo;
    	     }
                catch (Exception e) {
                    log.error("something went wrong", e);
                    throw new InvoiceIntegrationEWBException("Data not found");
                }
        

    }
}
