package com.bdo.bvms.invoices.dto;

import java.time.LocalDateTime;

import com.bdo.bvms.invoices.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class SyncPendingResponseDataDTO {

    @JsonFormat
    int id;
    String taxpayerGstin;
    String taxpayerPan;
    String vendorGstin;
    String vendorPan;
    String vendorLegalName;
    String vendorTradeName;
    String invoiceNo;
    String invoiceDate;
//    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    String syncWithGstr2a;
//    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    String syncWithGstr2b;
//    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    String syncWithEwayBill;
    String taxableValue;
    String igst;
    String sgst;
    String cess;
    String invoiceValue;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    Boolean qrCodeValid;
    String ewayBillNo;
    String ewayBillDate;
    String poNumber;
    String grnNumber;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    Boolean syncStatus;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
    LocalDateTime uploadDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
    LocalDateTime lastSyncDate;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    Boolean bookedErp;
    String getType;
    String batchNo;
    String fileType;
    int totalCount;
    String docType;
    String irnVerified;
    String supplyType;
    Integer ocrFileId;
    String isTaxpayerUploaded;
    String vendorCodeErp;

}
