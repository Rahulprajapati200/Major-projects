package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Gstr2HeaderDTOForForceSync {
	
	String taxpayerGstin;

    String vendorGstin;

    String invNo;

    String vendorLegalName;
    
    String vendorTradeName;

    String invDate;

    String docType;

    String source;

    String batchNo;
    
    String fileType;
    

}
