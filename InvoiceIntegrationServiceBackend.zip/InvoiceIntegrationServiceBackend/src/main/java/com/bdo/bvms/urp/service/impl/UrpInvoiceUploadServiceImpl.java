package com.bdo.bvms.urp.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.ResponseBean;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.ocr.repository.FileOcrProcessAndSaveRepository;
import com.bdo.bvms.urp.dao.UrpInvoiceUploadDao;
import com.bdo.bvms.urp.service.UrpInvoiceUploadService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UrpInvoiceUploadServiceImpl implements UrpInvoiceUploadService{

    
	public static final  String CLASSNAME = "UrpInvoiceUploadServiceImpl";
	
	@Autowired
    UploadTransDao uploadTransDao;
	
	@Value("${mst.database-name}")
    String mstDatabseName;
	
	 @Value("${temp.folder.path}")
	 String tempFolder;
	
	@Autowired
	UrpInvoiceUploadDao urpInvoiceUploadDao;
	
	@Autowired
    private MessageSource messageSource;
	
	@Override
	@Async
    public void readAndSaveUnprocessedData(UploadReqDTO uploadDTO, AzureConnectionCredentialsDTO map) throws VendorInvoiceServerException {
		String methodname = "readAndSaveUnprocessedData";
		 log.info("Classname: "+ CLASSNAME +" Methodname: "+ methodname+ " Started");
		   List<EInvoiceTemplateDTO> dataList = new ArrayList<>();

	        EInvoiceTemplateDTO invoice = new EInvoiceTemplateDTO();
	        uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_INPROGRESS);
	        try {
	        	
	        	if(!uploadDTO.getGstinOrPanList().isEmpty() && uploadDTO.getGstinOrPanList().get(0).length()>18 ){
	        		throw new VendorInvoiceServerException("Multiple Taxpayer GSTN can not be selected for OCR operation");		        		
	        	}	        	

	            invoice = new EInvoiceTemplateDTO();
	            invoice.setGstinUinOfRecipient(uploadDTO.getGstinOrPanList().get(0));
	            invoice.setGstinOfSupplier("URP");
	            invoice.setDocType(uploadDTO.getDocType());
	            invoice.setInwardNo(uploadDTO.getInvoiceNo());
	            invoice.setInwardDate(uploadDTO.getInvoiceDate());
	            invoice.setFillingPeriod(uploadDTO.getFp().get(0));
	            invoice.setPurchaseOrderDate(uploadDTO.getPoDate());
	            invoice.setPurchaseOrderNumber(uploadDTO.getPo());

	            if (StringUtils.isNotBlank(invoice.getGstinUinOfRecipient())
	                            && invoice.getGstinUinOfRecipient().length() == 15) {
	                invoice.setPanOfRecipient(invoice.getGstinUinOfRecipient().substring(2, 12));
	            } else {
	                invoice.setPanOfRecipient("");
	            }

	            dataList.add(invoice);
	            
	            urpInvoiceUploadDao.insertToUrpOcrHeader(dataList,uploadDTO);
	            
	            // update success and Error Count (Valid and not valid data) in Database
	            ResponseBean responseBean = new ResponseBean();
	            responseBean.setSuccessCount(1);
	            responseBean.setErrorCount(0);
	            uploadTransDao.updateErrorNSuccessCountAndTotalCount(responseBean, uploadDTO.getBatchNo());
	            
	            //update status in upload_log as success
	            uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),Constants.UPLOAD_INVOICES_PLD_STATUS_COMPLETED);
	            log.info("Classname: "+ CLASSNAME +" Methodname: "+ methodname+ " Completed");

	        } catch (Exception ex) {
	        	  log.error("Error generated in readAndSaveUnprocessedData:: ", ex);
		           
	        	if("Multiple Taxpayer GSTN can not be selected for OCR operation".equals(ex.getMessage())) {
	        		 uploadTransDao.updateProcessStatusWithRemarks(uploadDTO.getBatchNo(),
	                            Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, ex.getMessage());
	        	}else {
	        		  log.error("Error generated in readAndSaveUnprocessedData:: ", ex);
	        		  uploadTransDao.updateProcessStatusWithRemarks(uploadDTO.getBatchNo(),
	                            Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, messageSource.getMessage("iis.upload.standard.error", null,
	    	                            LocaleContextHolder.getLocale()));
	        	}

	          

	            throw new VendorInvoiceServerException("Something went wrong, try again later");
	        }
	        finally {
	        	deleteTempFiles(tempFolder, uploadDTO);
			}
		
	}
	
   void deleteTempFiles(String tempFolder,UploadReqDTO uploadDTO)
	{
		File baseFile = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR) + uploadDTO.getBatchNo()
				+ Constants.UNSERSCORE_BASE + Constants.DOTSEPARATOR + uploadDTO.getFileType());
		if (baseFile.exists()) {
			FileUtils.deleteQuietly(baseFile);
		}
	}

  



}
