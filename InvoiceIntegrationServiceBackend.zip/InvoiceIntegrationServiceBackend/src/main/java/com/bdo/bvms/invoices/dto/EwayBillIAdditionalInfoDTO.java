package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EwayBillIAdditionalInfoDTO {

    String updatemode;
    String groupNo;
    String tripsheetNo;
    String ewbNo;
    String ewbDate;
    String genmode;
    String validUpto;
    String extendedTimes;
    String rejectStatus;
    String status;
    String noValidDays;

}
