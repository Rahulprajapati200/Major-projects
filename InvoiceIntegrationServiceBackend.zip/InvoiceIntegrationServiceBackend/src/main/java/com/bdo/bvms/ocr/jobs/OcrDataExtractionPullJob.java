package com.bdo.bvms.ocr.jobs;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bdo.bvms.einvoice.service.UploadNDownloadFileService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.VendorInvoiceConstants;
import com.bdo.bvms.invoices.custom.exception.FileOcrCustomException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.ocr.dto.OcrPullLogDto;
import com.bdo.bvms.ocr.repository.FileOcrProcessAndSaveRepository;
import com.bdo.bvms.ocr.service.FileOcrProcessAndSaveService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class OcrDataExtractionPullJob {
	@Value("${temp.folder.path}")
	String tempFolder;
	@Autowired
	FileOcrProcessAndSaveRepository fileOcrProcessAndSaveRepository;
	@Autowired
	CommonDao commonDao;
	 @Autowired
	 FileOcrProcessAndSaveService fileOcrProcessAndSaveService;

	@Autowired
	UploadNDownloadFileService uploadFileService;

	RestTemplate restTemplate = new RestTemplate();
	ObjectMapper mapper = new ObjectMapper();

	@Async
	@Scheduled(fixedDelay = 30000)
	public void ocrPullJob() throws FileOcrCustomException {
		JSONObject resultSet = null;
		LinkedHashMap<Integer, String> pendingFiles = fileOcrProcessAndSaveRepository.getFilesToPullOcr();
		String pullUrl = commonDao.getSystemParameterCredential(Constants.OCR_PULL_URL);
		String apiKey = commonDao.getSystemParameterCredential(Constants.OCR_API_KEY);
		for (Entry<Integer, String> keyValue : pendingFiles.entrySet()) {
			OcrPullLogDto ocrPullLogDto = new OcrPullLogDto();
			JSONObject batchResultJSONRequest = new JSONObject();
			String requestedOn = "";
			String recievedOn  = "";
		try {
			log.info("OCR pull process for File Id: " + keyValue.getKey() +" Started");
			batchResultJSONRequest.put("BatchUID", keyValue.getValue());
			HttpHeaders batchResultHeaders = new HttpHeaders();
			batchResultHeaders.setContentType(MediaType.APPLICATION_JSON);
			batchResultHeaders.add("APIKey",apiKey);
			batchResultHeaders.add("Module", "");
			HttpEntity<String> entity = new HttpEntity<String>(batchResultJSONRequest.toString(), batchResultHeaders);
			requestedOn = Timestamp.from(Instant.now()).toString();
			resultSet = new JSONObject(restTemplate.postForObject(pullUrl, entity, String.class));
			recievedOn = Timestamp.from(Instant.now()).toString();
			log.debug(resultSet.toString());
			Map<String, Object> batchResultResponse = mapper.readValue(resultSet.toString(),new TypeReference<Map<String, Object>>(){});
			Map<String, Object> responceDataObject  = mapper.convertValue(batchResultResponse.get(VendorInvoiceConstants.RESPONSE_DATA_OBJECT), new TypeReference<Map<String, Object>>(){});
			if(responceDataObject.get("Status") != null && ((String)responceDataObject.get("Status")).contains("Batch is Under Process")) {
				log.info("Batch is Under Process for File Id: " + keyValue.getKey());
			}
			else {
				ocrPullLogDto = OcrPullLogDto.builder()
			    		.fileId(keyValue.getKey())
			    		.reqOn(requestedOn)
			    		.recievedOn(recievedOn)
			    		.status("Success")
			    		.payload(batchResultJSONRequest.toString())
			    		.ocrExtractedData(resultSet.toString())
                        .build(); 
			    fileOcrProcessAndSaveRepository.updateOcrPullLog(ocrPullLogDto);
			    fileOcrProcessAndSaveService.saveOCRDataResponseToDb(responceDataObject,keyValue.getKey());
			    log.info("OCR pull process for File Id: " + keyValue.getKey() +" Completed");
			}
		} catch (Exception e) {
			log.error("Exception found in OcrDataExtractionPullJob for File Id: " + keyValue.getKey(), e);
			 ocrPullLogDto = OcrPullLogDto.builder()
					 .fileId(keyValue.getKey())
			    		.reqOn(requestedOn)
			    		.recievedOn(recievedOn)
			    		.status("Error")
			    		.payload(batchResultJSONRequest.toString())
			    		.ocrExtractedData(resultSet.toString())
			    		.errorDesc(e.getMessage())
                     .build();
			 fileOcrProcessAndSaveRepository.updateOcrPullLog(ocrPullLogDto);
		}

	}
	}
}
