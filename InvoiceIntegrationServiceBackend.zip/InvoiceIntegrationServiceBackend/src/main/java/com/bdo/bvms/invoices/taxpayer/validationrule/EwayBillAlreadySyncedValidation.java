package com.bdo.bvms.invoices.taxpayer.validationrule;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.ValidationConstants;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.EWayBillDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EwayBillAlreadySyncedValidation {

    @Autowired
    UploadTransDao uploadTransDao;

    public List<EWayBillDTO> validateAlreadySyncedStatus(List<EWayBillDTO> dataList) {

        log.info("Entered into validateAlreadySyncedStatus method");
        Map<String, Map<String, String>> syncedValidationMap = new ConcurrentHashMap<String, Map<String, String>>();
        List<EWayBillDTO> validatedList = new ArrayList<>();
        dataList.forEach(rowData -> {
            try {
                if ((Constants.VALIDCONSTANTS).equals(rowData.getIsValid())) {
                    int isSynced = 0;
                    String taxpayerGstinVendorGstin = rowData.getTaxpayerGstin() + rowData.getVendorGstin();
                    String keyDataTocheck = rowData.getTaxpayerGstin() + rowData.getVendorGstin()
                                    + rowData.getEWayBillNo();
                    List<String> ewbHeaderCrId = new ArrayList<>();
                    if (syncedValidationMap.get(taxpayerGstinVendorGstin) == null) {
                        ewbHeaderCrId = uploadTransDao.getEWBAlreadySynced(rowData.getTaxpayerGstin(),
                                        rowData.getVendorGstin());
                        Map<String, String> map = ewbHeaderCrId.stream()
                                        .collect(Collectors.toMap(str -> str, str -> str));

                        syncedValidationMap.put(taxpayerGstinVendorGstin, map);
                        if (syncedValidationMap.get(taxpayerGstinVendorGstin).get(keyDataTocheck) != null) {
                            isSynced = 1;
                        }
                    } else {
                        if (syncedValidationMap.get(taxpayerGstinVendorGstin).get(keyDataTocheck) != null) {
                            isSynced = 1;
                        }
                    }

                    if (isSynced > 0) {

                        markErrorNAddErrorCode(rowData, ValidationConstants.EINVOICE_ERROR_CODE_O0091, Constants.BLANK);
                    }

                }

                validatedList.add(rowData);

            } catch (Exception | Error e) {

                log.error("Error Occured while validation row " + rowData.getExcelRowId(), e);

                markErrorNAddErrorCode(rowData, ValidationConstants.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);

            }

        });

        return validatedList;

    }

    private void markErrorNAddErrorCode(EWayBillDTO rowData, String errorCode, String errorMessage) {

        rowData.setIsValid(0);
        rowData.setErrorCodeList(rowData.getErrorCodeList().append(errorCode));
        rowData.setErrorDiscriptionList(rowData.getErrorDiscriptionList().append(errorMessage));
    }

}
