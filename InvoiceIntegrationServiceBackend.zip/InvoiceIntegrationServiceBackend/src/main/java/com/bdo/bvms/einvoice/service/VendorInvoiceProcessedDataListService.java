package com.bdo.bvms.einvoice.service;

import java.util.Map;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface VendorInvoiceProcessedDataListService {

    Map<String, Object> getProcessedDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
                    String monthList) throws VendorInvoiceServerException;

}
