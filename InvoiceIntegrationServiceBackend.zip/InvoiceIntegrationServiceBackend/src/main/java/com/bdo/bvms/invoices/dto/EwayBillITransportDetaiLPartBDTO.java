package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EwayBillITransportDetaiLPartBDTO {

    String modeofTransport;
    String vehicleType;
    String vehicleNo;
    String transportDocno;
    String transportDate;
}
