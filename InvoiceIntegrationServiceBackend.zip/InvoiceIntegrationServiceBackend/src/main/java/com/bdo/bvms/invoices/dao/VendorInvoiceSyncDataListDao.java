package com.bdo.bvms.invoices.dao;

import java.util.List;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.SyncPendingResponseDataDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface VendorInvoiceSyncDataListDao {

    List<SyncPendingResponseDataDTO> getSyncPendingDataList(VendorInvoiceRequestDTO syncPendingRequest,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException;

    int getTotalCount(VendorInvoiceRequestDTO syncPendingRequest, String gstinNewList, String monthList);

}
