package com.bdo.bvms.invoices.ocr.dao;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.bdo.bvms.invoices.dto.BaseReqDTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class UpdateOCRInvoiceDetailsReqDTO extends BaseReqDTO {
    
    //nullable
    Integer verticalMapId;
    
    //non nullable
	@NotNull(message = "{ocrMasterFieldId.notNull}")
    Integer ocrFieldMstId;
    
	@NotEmpty(message = "{updatedValue.notNull}")
    String updatedValue;
    
//	@NotNull(message = "{isHeader.notNull}")
//    Boolean isHeader;
	
    Integer ocrVendorTemplateMstId;
	
	Integer lineNo;
    
}
