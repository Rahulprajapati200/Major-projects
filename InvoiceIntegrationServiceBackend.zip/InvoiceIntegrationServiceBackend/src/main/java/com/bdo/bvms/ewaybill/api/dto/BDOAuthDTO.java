package com.bdo.bvms.ewaybill.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class BDOAuthDTO {

    String bdoAuthToken;
    String status;
    String expiry;
    String playLoad;
    String isException;
    String errorDescription;

}
