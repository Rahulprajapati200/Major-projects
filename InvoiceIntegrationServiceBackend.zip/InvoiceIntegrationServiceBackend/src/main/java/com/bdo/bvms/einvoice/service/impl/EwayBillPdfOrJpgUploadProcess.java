package com.bdo.bvms.einvoice.service.impl;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.bdo.bvms.ewaybill.api.GetEwayBillApiDao;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.ewaybill.api.dto.NicAuthResponseDTO;
import com.bdo.bvms.ewaybill.api.dto.TaxpayerDetailsDTO;
import com.bdo.bvms.ewaybill.api.impl.EWayBillBDOAuthentication;
import com.bdo.bvms.ewaybill.api.impl.EWayBillDetailsApi;
import com.bdo.bvms.ewaybill.api.impl.EWayBillNicAuthentication;
import com.bdo.bvms.ewaybill.api.impl.GetEwayBillInvoiceDetailServiceImpl;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.ValidationConstants;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.EwayBillheaderDTO;
import com.bdo.bvms.invoices.dto.QrEwayBillData;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EwayBillPdfOrJpgUploadProcess {

	public static final String CLASSNAME = "EwayBillPdfOrJpgUploadProcess";

	@Value("${temp.folder.path}")
	String tempFolder;

	RestTemplate restTemplate = new RestTemplate();

	@Autowired
	UploadTransDao uploadTransDao;

	@Autowired
	EWayBillBDOAuthentication eWayBillBDOAuthentication;

	@Autowired
	EWayBillNicAuthentication eWayBillNicAuthentication;

	@Autowired
	GetEwayBillInvoiceDetailServiceImpl getEwayBillInvoiceDetailServiceImpl;

	@Autowired
	GetEwayBillApiDao getEwayBillApiDao;

	@Autowired
	CommonDao commonDao;

	@Autowired
	private MessageSource messageSource;

	public List<EwayBillheaderDTO> pdfEwayBillProcess(UploadReqDTO uploadDTO)
			throws IOException, VendorInvoiceServerException, InvoiceIntegrationEWBException {

		List<EwayBillheaderDTO> eWayBillHeaderList = new ArrayList<>();
		List<QrEwayBillData> ewaybillNoList = new ArrayList<>();
		try {
			ewaybillNoList = getEwayBillNoFromPdf(uploadDTO);

		} catch (Exception ex) {

			log.error("Error in getEwayBillNoFromPdf method", ex);
			uploadTransDao.updateProcessStatusWithRemarks(uploadDTO.getBatchNo(),
					Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, ex.getMessage());
		    if (ex.getMessage()
					.equals(messageSource.getMessage("upload.qr.scan.error", null, LocaleContextHolder.getLocale()))) {
				throw new VendorInvoiceServerException(ex.getMessage());

			}  else if (ex.getMessage().equals(
					messageSource.getMessage("upload.qr.scan.api.exception", null, LocaleContextHolder.getLocale()))) {
				throw new VendorInvoiceServerException(ex.getMessage());

			} else {
				throw new VendorInvoiceServerException(
						messageSource.getMessage("iis.upload.standard.error", null, LocaleContextHolder.getLocale()));
			}
		}

	    String gstin = uploadDTO.getGstinOrPanList().get(0);
			for (QrEwayBillData qrEwayBillData : ewaybillNoList) {
				if(qrEwayBillData.getEwaybillNo().equals("INVALID")) {
					EwayBillheaderDTO ewayBillheaderInfo = new EwayBillheaderDTO();
					ewayBillheaderInfo.setQrPageNo(qrEwayBillData.getPageNumber());
					ewayBillheaderInfo.setErrorCode(ValidationConstants.EINVOICE_ERROR_CODE_E00585);
					eWayBillHeaderList.add(ewayBillheaderInfo);
				}
				else {
					GetEwayBillReqDTO ewayBillCallDto = new GetEwayBillReqDTO();
					ewayBillCallDto.setTaxpayerGstin(gstin);
					ewayBillCallDto.setEwaybillNo(qrEwayBillData.getEwaybillNo());
					ewayBillCallDto.setUserId(uploadDTO.getId());
					try {
						EwayBillheaderDTO ewayBillheaderInfo = getEwayBillDetailsByEwbNo(ewayBillCallDto);
						if (ewayBillheaderInfo != null) {
							ewayBillheaderInfo.setQrPageNo(qrEwayBillData.getPageNumber());
							eWayBillHeaderList.add(ewayBillheaderInfo);
						} 
					} catch (Exception ex) {
						log.error(ex.getMessage());
						throw new InvoiceIntegrationEWBException(ex.getMessage());
					}
				}
			}

		if (eWayBillHeaderList.isEmpty()) {
			log.error("No data found during Get E-way bill call to nic portal");
			throw new InvoiceIntegrationEWBException("No data found during Get E-way bill call to nic portal");
		}
		return eWayBillHeaderList;
	}

	@Async
	public void saveEwayBillDetails(List<EwayBillheaderDTO> ewayBillheaderInfoList, int userId)
			throws InvoiceIntegrationEWBException {

		for (EwayBillheaderDTO header : ewayBillheaderInfoList) {
			if(StringUtils.isBlank(header.getError())){
				int id = getEwayBillApiDao.insertToEwayBillHeader(header.getEwbApiCallLogId(), header);
	
				getEwayBillApiDao.insertToEwayBillItemDetails(header.getItemList(), id);
	
				getEwayBillApiDao.insertToEwayBillVehicleDetails(header.getVehiclListDetails(), id);
	
				// insert data to invoice detail
				getEwayBillInvoiceDetailServiceImpl.saveGetEwayBillDetailsToInvoiceDetail(header, userId);
			}

		}

	}

	private List<QrEwayBillData> getEwayBillNoFromPdf(UploadReqDTO uploadDTO) throws IOException, VendorInvoiceServerException {

		String fileName = new StringBuilder().append(tempFolder).append(System.getProperty(Constants.FILESEPERATOR))
				.append(uploadDTO.getBatchNo()).append(Constants.UNSERSCORE_BASE).append(Constants.DOTSEPARATOR)
				.append(uploadDTO.getFileType()).toString();
		List<QrEwayBillData> ewaybillNoList = new ArrayList<>();
		ObjectMapper objectMapper = new ObjectMapper();
		JSONObject qrScanRes = null;
		qrScanRes = scanPDFImageQR(fileName, uploadDTO);
		JSONArray resultArray = qrScanRes.getJSONArray(Constants.RESULT);

		if (resultArray == null || resultArray.isEmpty()) {
			String remarkMessage = messageSource.getMessage("upload.qr.scan.error", null,
					LocaleContextHolder.getLocale());
			log.error(remarkMessage);
			throw new VendorInvoiceServerException(remarkMessage);
		}
		List<Map<String, Object>> resultSet = objectMapper.readValue(resultArray.toString(), List.class);
	
		// check no qr scanned
		if (resultSet.isEmpty()) {
			String remarkMessage = messageSource.getMessage("upload.qr.scan.error", null,
					LocaleContextHolder.getLocale());
			log.error(remarkMessage);
			throw new VendorInvoiceServerException(remarkMessage);
		}
		else {
			uploadTransDao.updateQRScanFlag(uploadDTO.getBatchNo(), 1);
			for (Map<?, ?> data : resultSet) {
				QrEwayBillData qrEwayBillData = new QrEwayBillData();
				qrEwayBillData.setPageNumber(String.valueOf(data.get(Constants.QR_PAGE_NUMBER)) );
                if (data.get(Constants.EWAYBILL_NO) != null && StringUtils.isNotBlank(String.valueOf(data.get(Constants.EWAYBILL_NO)))) {
					String ewayBillNo = String.valueOf(data.get(Constants.EWAYBILL_NO));
					qrEwayBillData.setEwaybillNo(ewayBillNo);
				} else if (data.get("QRCODE") != null) {
					String ewbNo = "";
					String qrString = (String) data.get("QRCODE");

					String[] words = qrString.split(" ");

					for (int i = 0; i <= words.length-1; i++) {

						if(words[i].length()>=12 && NumberUtils.isParsable(words[i])) {
							ewbNo = words[i];
						}
					}
					qrEwayBillData.setEwaybillNo(ewbNo);

				} 
				else {
					qrEwayBillData.setEwaybillNo("INVALID");
				}
                ewaybillNoList.add(qrEwayBillData);
			}
		}

		return ewaybillNoList;
	}

	private EwayBillheaderDTO getEwayBillDetailsByEwbNo(GetEwayBillReqDTO reqDto)
			throws InvoiceIntegrationEWBException {
		
		String clientId = getEwayBillApiDao.getEwayBillClientId();
		String seckey = getEwayBillApiDao.getEwayBillClientSecretEncrypted();
		String appKey = getEwayBillApiDao.getEwayBillAppKey();
		String eWayBillApiBaseURL = getEwayBillApiDao.getEwayBillApiUrl();
		String eWayBillApiURL = eWayBillApiBaseURL + "?ewbNo= " + reqDto.getEwaybillNo();
		EwayBillheaderDTO ewayBillheaderInfo = new EwayBillheaderDTO();

		TaxpayerDetailsDTO taxpayerDetails = getEwayBillApiDao
				.getTaxpayerDetailsFromEntityMaster(reqDto.getTaxpayerGstin());

		String bdoAuthKey = null;
		try {
			 bdoAuthKey = eWayBillBDOAuthentication.bdoAuthEWB(clientId, seckey, reqDto,
						Constants.GET_EWAYBILL_PLD_CODE);
					 }
		catch(Exception e) {
			 log.error("BDO Authentication failed",e);
			 throw new InvoiceIntegrationEWBException("BDO Authentication failed");
		}

		NicAuthResponseDTO nicAuthResponseDTO = new NicAuthResponseDTO();
		try {;
			nicAuthResponseDTO = eWayBillNicAuthentication.nicAuthEWB(bdoAuthKey, clientId, seckey, reqDto,
					Constants.GET_EWAYBILL_PLD_CODE, taxpayerDetails);
		} catch (Exception e) {
			log.error("nic authentication failed for taxpayerGstin" + reqDto.getTaxpayerGstin(), e);
			nicAuthResponseDTO.setIsException("1");
			nicAuthResponseDTO.setErrorDescription(e.getMessage());
			throw new InvoiceIntegrationEWBException("NIC Authentication failed for GSTIN :"+reqDto.getTaxpayerGstin());
		}

		EWayBillDetailsApi ewayBillApi = new EWayBillDetailsApi();

		try {
            if (nicAuthResponseDTO != null) {
				ewayBillheaderInfo = ewayBillApi.getEwayBillDetailsAPI(appKey, reqDto.getTaxpayerGstin(), clientId,
						seckey, eWayBillApiURL, restTemplate, bdoAuthKey, nicAuthResponseDTO.getNicAuthToken(),
						nicAuthResponseDTO.getNicSek());
			}
		} catch (Exception e) {
			log.error("Error in getEwayBillDetailsByEwbNo method for " + reqDto.getEwaybillNo(), e);
			ewayBillheaderInfo.setError("Getting error from NIC portal.");
			ewayBillheaderInfo.setErrorCode(ValidationConstants.GET_EWB_ERROR_CODE_GE0001);
			eWayBillBDOAuthentication.markNICKeyInactive(reqDto.getTaxpayerGstin(), nicAuthResponseDTO.getNicSek());

         }

		int ewbApiCallLogId = 0;

		if (ewayBillheaderInfo != null && StringUtils.isNotEmpty(ewayBillheaderInfo.getError())) {

			if (nicAuthResponseDTO != null
					&& Constants.INVALID_AUTH_TOKEN.equalsIgnoreCase(ewayBillheaderInfo.getError())) {
				eWayBillBDOAuthentication.markNICKeyInactive(reqDto.getTaxpayerGstin(), nicAuthResponseDTO.getNicSek());
			}

			getEwayBillApiDao.insertToEwayBillApiCall(nicAuthResponseDTO, reqDto.getTaxpayerGstin(), reqDto,
					ewayBillheaderInfo.getError(), Constants.GET_EWAYBILL_PLD_CODE, ewayBillheaderInfo.getApiResponse(),
					Constants.EWB_GET_STATUS_FAIL);
			log.error("Getting Error in GET ewaybill detail for : " + reqDto.getEwaybillNo());
			log.error(ewayBillheaderInfo.getError());
			ewayBillheaderInfo.setErrorCode(ValidationConstants.GET_EWB_ERROR_CODE_GE0002);

		}

		else {
			if (ewayBillheaderInfo != null) {
				reqDto.setSuccessCount(1);
				ewbApiCallLogId = getEwayBillApiDao.insertToEwayBillApiCall(nicAuthResponseDTO,
						reqDto.getTaxpayerGstin(), reqDto, null, Constants.GET_EWAYBILL_PLD_CODE,
						ewayBillheaderInfo.getApiResponse(), Constants.EWB_GET_STATUS_SUCCESS);
				ewayBillheaderInfo.setEwbApiCallLogId(ewbApiCallLogId);

			}
		}
		return ewayBillheaderInfo;

	}

	private JSONObject scanPDFImageQR(String fileName, UploadReqDTO uploadDTO) throws VendorInvoiceServerException {
		JSONObject qrScanRes = null;
		MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("file", new FileSystemResource(fileName));
		HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body);
		String serverUrl = commonDao.getSystemParameterCredential(Constants.EWB_SCAN_URL);

		uploadTransDao.insertIntoQRExecutionLog(uploadDTO, null, LocalDateTime.now(), null);
		restTemplate = new RestTemplate();
		try {
			qrScanRes = new JSONObject(restTemplate.postForObject(serverUrl, requestEntity, String.class));
			uploadTransDao.insertIntoQRExecutionLog(uploadDTO, qrScanRes.toString(), null, LocalDateTime.now());
			return qrScanRes;
		} catch (Exception ex) {
			String remarkMessage = messageSource.getMessage("upload.qr.scan.api.exception", null,
					LocaleContextHolder.getLocale());
			log.error(remarkMessage);

			throw new VendorInvoiceServerException(remarkMessage);
		}

	}

}
