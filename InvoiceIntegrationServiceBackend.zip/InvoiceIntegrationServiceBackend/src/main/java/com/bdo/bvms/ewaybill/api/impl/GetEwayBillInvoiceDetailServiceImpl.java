package com.bdo.bvms.ewaybill.api.impl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.ewaybill.api.GetEwayBillApiDao;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.ewaybill.api.dto.InvoiceDetailDTO;
import com.bdo.bvms.ewaybill.api.sql.Transactions;
import com.bdo.bvms.invoices.dto.EWBGenByOtherPartyDTO;
import com.bdo.bvms.invoices.dto.EwayBillheaderDTO;
import com.bdo.bvms.invoices.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class GetEwayBillInvoiceDetailServiceImpl {

    @Autowired
    GetEwayBillApiDao getEwayBillApiDaoImpl;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    public void saveGetEwayBillDetailsToInvoiceDetail(EwayBillheaderDTO ewayBillheaderInfo, int userId) {
        int checkEwbExistCount = checkEwbDetailIdByEWbNo(ewayBillheaderInfo.getEwbNo());
        if (checkEwbExistCount > 0) {
            insertRecordsFromInvoiceDetailToArchivedAllreadyExists(ewayBillheaderInfo.getEwbNo());
            deleteRecordsAllreadyExists(ewayBillheaderInfo.getEwbNo());
        }

        InvoiceDetailDTO invoiceDetailDTO = new InvoiceDetailDTO();
        invoiceDetailDTO.setTaxpayerGstin(ewayBillheaderInfo.getToGstin());
        invoiceDetailDTO.setTaxpayerPan(ewayBillheaderInfo.getToGstin().substring(2, 12));
        invoiceDetailDTO.setVendorGstin(ewayBillheaderInfo.getFromGstin());
        invoiceDetailDTO.setVendorPan(ewayBillheaderInfo.getFromGstin().substring(2, 12));
        invoiceDetailDTO.setEwaybillNo(ewayBillheaderInfo.getEwbNo());
        invoiceDetailDTO.setEwaybillDate(DateUtil.convertDateFormattoScreen2(ewayBillheaderInfo.getEwayBillDate()));
        invoiceDetailDTO.setTaxableValue(ewayBillheaderInfo.getTotalValue());
        invoiceDetailDTO.setInvoiceValue(ewayBillheaderInfo.getTotInvValue());
        invoiceDetailDTO.setSgst(ewayBillheaderInfo.getSgstValue());
        invoiceDetailDTO.setCgst(ewayBillheaderInfo.getCgstValue());
        invoiceDetailDTO.setIgst(ewayBillheaderInfo.getIgstValue());
        invoiceDetailDTO.setCess(ewayBillheaderInfo.getCessValue());
        invoiceDetailDTO.setPldGetType(125);
        invoiceDetailDTO.setSyncStatus(0);
        invoiceDetailDTO.setReturnPeriod(null);
        invoiceDetailDTO.setYearId(0);
        invoiceDetailDTO.setDocReturnPeriod(null);
        invoiceDetailDTO.setDocYearId(0);
        invoiceDetailDTO.setCategory(null);
        invoiceDetailDTO.setNoteType(null);
        invoiceDetailDTO.setCreatedBy(userId);
        invoiceDetailDTO.setCreatedOn(Timestamp.from(Instant.now()));
        invoiceDetailDTO.setReturnPeriod(DateUtil.convertDateToFillingPeriod(ewayBillheaderInfo.getEwayBillDate()));
        invoiceDetailDTO.setDocReturnPeriod(DateUtil.convertDateToFillingPeriod(ewayBillheaderInfo.getDocDate()));
        invoiceDetailDTO.setYearId(getYearIdByFp(invoiceDetailDTO.getReturnPeriod()));
        invoiceDetailDTO.setDocYearId(getYearIdByFp(invoiceDetailDTO.getDocReturnPeriod()));
        invoiceDetailDTO.setInvoiceNo(ewayBillheaderInfo.getDocNo());
        invoiceDetailDTO.setInvoiceDate(DateUtil.convertDateFormattoScreen2(ewayBillheaderInfo.getDocDate()));
        List<InvoiceDetailDTO> invoiceDetailDataList = new ArrayList<>();
        invoiceDetailDataList.add(invoiceDetailDTO);

        try {

            getEwayBillApiDaoImpl.insertToInvoiceDetail(invoiceDetailDataList);

        } catch (Exception ex) {
            log.error("Error occured while saving EWB details in the invoice header table", ex);

        }
    }

    public void saveGetEwayBillDetailsOtherPartyToInvoiceDetail(List<EWBGenByOtherPartyDTO> data,
                    GetEwayBillReqDTO getEwayBillReqDTO) {

        List<InvoiceDetailDTO> invoiceDetailDataList = new ArrayList<>();

        for (EWBGenByOtherPartyDTO ewayBillheaderInfo : data) {

            InvoiceDetailDTO invoiceDetailDTO = new InvoiceDetailDTO();

            invoiceDetailDTO.setTaxpayerGstin(getEwayBillReqDTO.getTaxpayerGstin());
            invoiceDetailDTO.setTaxpayerPan(" ");
            invoiceDetailDTO.setVendorGstin(" ");
            invoiceDetailDTO.setVendorPan("");
            invoiceDetailDTO.setEwaybillNo(getEwayBillReqDTO.getEwaybillNo());
            invoiceDetailDTO.setEwaybillDate(getEwayBillReqDTO.getEwaybillDate());
            invoiceDetailDTO.setTaxableValue("");
            invoiceDetailDTO.setInvoiceValue(ewayBillheaderInfo.getTotInvValue());
            invoiceDetailDTO.setSgst("");
            invoiceDetailDTO.setCgst("");
            invoiceDetailDTO.setIgst("");
            invoiceDetailDTO.setCess("");
            invoiceDetailDTO.setPldGetType(125);
            invoiceDetailDTO.setSyncStatus(0);
            invoiceDetailDTO.setReturnPeriod(null);
            invoiceDetailDTO.setYearId(0);
            invoiceDetailDTO.setDocReturnPeriod(null);
            invoiceDetailDTO.setDocYearId(0);
            invoiceDetailDTO.setCategory(null);
            invoiceDetailDTO.setNoteType(null);
            invoiceDetailDTO.setCreatedBy(getEwayBillReqDTO.getUserId());
            invoiceDetailDTO.setCreatedOn(Timestamp.from(Instant.now()));
            invoiceDetailDTO.setReturnPeriod(DateUtil.convertDateToFillingPeriod(ewayBillheaderInfo.getEwayBillDate()));
            invoiceDetailDTO.setDocReturnPeriod(DateUtil.convertDateToFillingPeriod(ewayBillheaderInfo.getDocDate()));
            invoiceDetailDTO.setYearId(getYearIdByFp(invoiceDetailDTO.getReturnPeriod()));
            invoiceDetailDTO.setDocYearId(getYearIdByFp(invoiceDetailDTO.getDocReturnPeriod()));

            invoiceDetailDataList.add(invoiceDetailDTO);
        }
        try {

            getEwayBillApiDaoImpl.insertToInvoiceDetail(invoiceDetailDataList);

        } catch (Exception ex) {
            log.error(ex.getMessage());

        }
    }

    public int checkEwbDetailIdByEWbNo(String ewbNo) {

        return jdbcTemplateTrn.queryForObject(Transactions.CHECK_EWB_DETAIL_BY_EWB_NO, int.class, ewbNo);

    }

    public void deleteRecordsAllreadyExists(String ewbNo) {

        jdbcTemplateTrn.update(Transactions.DELETE_EWB_RECORDS_ALLREADY_EXISTS, ewbNo);

    }

    public Integer getYearIdByFp(String fp) {

        try {
            return jdbcTemplateMst.queryForObject(Transactions.GET_YEAR_ID_BY_FP, int.class, fp);
        } catch (Exception e) {
            log.error("Exception generated ::", e);
            return null;
        }

    }

    private void insertRecordsFromInvoiceDetailToArchivedAllreadyExists(String ewbNo) {

        jdbcTemplateTrn.update(Transactions.insertInvoiceDetailToArchived(), ewbNo);

    }

}
