package com.bdo.bvms.einvoice.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.bdo.bvms.einvoice.service.ServiceCall;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.APIResponseDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ServiceCallImpl implements ServiceCall {

    @Autowired
    private RestTemplate restTemplate;

    @SuppressWarnings("unchecked")
    @Override
    public <T> ResponseEntity<T> callPostToDo(String requestURL, HttpEntity<Map<String, Integer>> entity,
                    Class<APIResponseDTO> responseType) throws VendorInvoiceServerException {
        ResponseEntity<T> response = null;
        int callmaid = 0;
        int maxcall = 2;
        while (callmaid < maxcall) {
            try {
                response = (ResponseEntity<T>) restTemplate.exchange(requestURL, HttpMethod.POST, entity, responseType);
                callmaid = maxcall;
            } catch (ResourceAccessException rae) {
                log.error("Error in callPostToDo Method", rae);
                try {
                    if ((callmaid < maxcall - 1)) {
                        Thread.currentThread();
                        Thread.sleep(10000);
                        callmaid++;
                    } else
                        throw rae;
                } catch (InterruptedException e) {
                    log.error("Error in callPostToDo Method", e);
                    log.warn("Interrupted!", e);
                    Thread.currentThread().interrupt();
                    throw new VendorInvoiceServerException("An error occured while calling url " + requestURL, e);
                }
            } catch (Exception e) {
                log.error("Error in callPostToDo Method", e);
                throw new VendorInvoiceServerException("An error occured while calling url " + requestURL, e);
            }
        }
        return response;
    }

}
