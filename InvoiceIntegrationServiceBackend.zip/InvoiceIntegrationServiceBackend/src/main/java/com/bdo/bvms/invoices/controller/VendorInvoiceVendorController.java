package com.bdo.bvms.invoices.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.APIResponseDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsReqDTO;
import com.bdo.bvms.invoices.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.invoices.dto.UploadHistoryResponseDTO;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceResponseDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceSubmitOrRemoveReqDTO;
import com.bdo.bvms.invoices.dto.VendorJourneyInvoiceGetDetailsReqDTO;

public interface VendorInvoiceVendorController {

    ResponseEntity<APIResponseDTO> uploadFile(HttpServletRequest request, UploadRequestDTO uploadRequestDTO)
                    throws VendorInvoiceServerException;

    ResponseEntity<UploadHistoryResponseDTO> logHistory(HttpServletRequest request, UploadHistoryRequestDTO requestDTO)
                    throws VendorInvoiceServerException;

    ResponseEntity<VendorInvoiceResponseDTO> getDataList(HttpServletRequest request,
                    VendorInvoiceRequestDTO vendorInvoiceRequestDTO) throws VendorInvoiceServerException;

    ResponseEntity<VendorInvoiceResponseDTO> getInvoiceDetails(HttpServletRequest request,
                    VendorJourneyInvoiceGetDetailsReqDTO vendorJourneyInvoiceGetDetailsReqDTO)
                    throws VendorInvoiceServerException;

    ResponseEntity<VendorInvoiceResponseDTO> getSubmitOrRemove(HttpServletRequest request,
                    VendorInvoiceSubmitOrRemoveReqDTO vendorInvoiceSubmitOrRemoveReqDTO)
                    throws VendorInvoiceServerException;

    ResponseEntity<VendorInvoiceResponseDTO> getProcessedInvoiceDataList(HttpServletRequest request,
                    VendorInvoiceRequestDTO vendorInvoiceRequestDTO) throws VendorInvoiceServerException;

    /**
     * Gets the download invoice details.
     *
     * @param request
     *            the request
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the download invoice details
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    ResponseEntity<Resource> getDownloadInvoiceDetails(HttpServletRequest request,
                    InvoiceDetailsReqDTO invoiceDetailsReqDTO) throws VendorInvoiceServerException, IOException;

}
