package com.bdo.bvms.common.repository;

import com.bdo.bvms.invoices.ocr.model.SystemParameter;

public interface ISystemParameterRepository {

    SystemParameter searchSystemParameter(SystemParameter systemParameter);

}
