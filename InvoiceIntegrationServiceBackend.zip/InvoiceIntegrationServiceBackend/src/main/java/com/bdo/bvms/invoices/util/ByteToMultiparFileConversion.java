package com.bdo.bvms.invoices.util;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
public class ByteToMultiparFileConversion {

    public static CommonsMultipartFile convert(byte[] bytes, String fileName) throws IOException {
        // Create a CommonsFileItem
        FileItem fileItem = new DiskFileItem(
                "file", // Form field name
                "application/octet-stream", // Content type
                false, // Whether to store the file on disk
                fileName, // File name
                bytes.length, // File size
                null // File repository (null means use the default temporary directory)
        );

        // Copy the byte array to the input stream of the FileItem
        try (InputStream inputStream = new ByteArrayInputStream(bytes)) {
            fileItem.getOutputStream().write(bytes);
        }

        // Create a CommonsMultipartFile from the FileItem
        return new CommonsMultipartFile(fileItem);
    }
}
