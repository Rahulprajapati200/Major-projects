package com.bdo.bvms.common.repository;

import java.util.LinkedHashMap;

public interface IPickupMasterRepository {


    LinkedHashMap<String, Integer> getPickupListDetailsMapSortOrder(String pickupMasterName);

}
