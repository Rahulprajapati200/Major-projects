package com.bdo.bvms.invoices.constant;

public class ValidationConstants {

    ValidationConstants() {

    }

    public static final String EINVOICE_ERROR_CODE_E00274 = "|E00274";

    public static final String EINVOICE_ERROR_CODE_E00275 = "|E00275";

    public static final String EINVOICE_ERROR_CODE_E00170 = "|E00170";
    public static final String EINVOICE_ERROR_CODE_I50119 = "|I50119";
    public static final String EINVOICE_ERROR_CODE_E00153 = "|E00153";
    public static final String EINVOICE_ERROR_CODE_E00273 = "|E00273";
    public static final String EINVOICE_ERROR_CODE_E00032 = "|E00032";
    public static final String EINVOICE_ERROR_CODE_E00098 = "|E00098";
    public static final String EINVOICE_ERROR_CODE_E00097 = "|E00097";
    public static final String EINVOICE_ERROR_CODE_II50118 = "|I50118";
    public static final String EINVOICE_ERROR_CODE_E00164 = "|E00164";
    public static final String EINVOICE_ERROR_CODE_E00045 = "|E00045";
    public static final String EINVOICE_ERROR_CODE_E00031 = "|E00031";
    public static final String EINVOICE_ERROR_CODE_E00271 = "|E00271";
    public static final String EINVOICE_ERROR_CODE_E00030 = "|E00030";
    public static final String EINVOICE_ERROR_CODE_E00054 = "E00054";
    public static final String EWAY_ERROR_CODE_E00214 = "|E00214";
    public static final String EWAY_ERROR_CODE_E00286 = "|E00286";
    public static final String EWAY_ERROR_CODE_E00014 = "|E00014";
    public static final String EWAY_ERROR_CODE_E00102 = "|E00102";
    public static final String EWAY_ERROR_CODE_E00277 = "|E00277";
    public static final String EWAY_ERROR_CODE_E00283 = "|E00283";
    public static final String EWAY_ERROR_CODE_E00278 = "|E00278";
    public static final String EWAY_ERROR_CODE_E00288 = "|E00288";
    public static final String EWAY_ERROR_CODE_E00290 = "|E00290";
    public static final String EWAY_ERROR_CODE_E00292 = "|E00292";
    public static final String EWAY_ERROR_CODE_E00279 = "|E00279";
    public static final String EWAY_ERROR_CODE_E00280 = "|E00280";
    public static final String EWAY_ERROR_CODE_E00281 = "|E00281";
    public static final String EWAY_ERROR_CODE_E00287 = "|E00287";
    public static final String EWAY_ERROR_CODE_E00282 = "|E00282";
    public static final String EWAY_ERROR_CODE_E00289 = "|E00289";
    public static final String EWAY_ERROR_CODE_E00291 = "|E00291";
    public static final String ERROR_CODE_E00293 = "|E00293";
    public static final String ERROR_CODE_E00294 = "|E00294";
    public static final String ERROR_CODE_E00295 = "|E00295";
    public static final String ERROR_CODE_E00296 = "|E00296";
    public static final String ERROR_CODE_E00297 = "|E00297";
    public static final String ERROR_CODE_E00298 = "|E00298";
    public static final String ERROR_CODE_E00299 = "|E00299";
    public static final String ERROR_CODE_E00300 = "|E00300";
    public static final String ERROR_CODE_E00301 = "|E00301";
    public static final String ERROR_CODE_E00302 = "|E00302";
    public static final String ERROR_CODE_E00303 = "|E00303";
    public static final String ERROR_CODE_E00304 = "|E00304";
    public static final String ERROR_CODE_E00305 = "|E00305";
    public static final String ERROR_CODE_E00306 = "|E00306";
    public static final String ERROR_CODE_E00307 = "|E00307";
    public static final String ERROR_CODE_E00308 = "|E00308";
    public static final String ERROR_CODE_E00309 = "|E00309";
    public static final String ERROR_CODE_E00310 = "|E00310";
    public static final String ERROR_CODE_E00311 = "|E00311";
    public static final String ERROR_CODE_E00312 = "|E00312";
    public static final String ERROR_CODE_E00257 = "|E00257";
    public static final String ERROR_CODE_E00258 = "|E00258";
    public static final String ERROR_CODE_E00259 = "|E00259";
    public static final String ERROR_CODE_E00102 = "|E00102";
    public static final String ERROR_CODE_E00510 = "|E00510";
    public static final String ERROR_CODE_E00511 = "|E00511";
    public static final String ERROR_CODE_E00260 = "|E00260";
    public static final String ERROR_CODE_E00261 = "|E00261";
    public static final String ERROR_CODE_E00313 = "|E00313";
    public static final String ERROR_CODE_E00314 = "|E00314";
    public static final String ERROR_CODE_E00315 = "|E00315";
    public static final String ERROR_CODE_E00262 = "|E00262";
    public static final String ERROR_CODE_E00263 = "|E00263";
    public static final String ERROR_CODE_E00264 = "|E00264";
    public static final String ERROR_CODE_E00316 = "|E00316";
    public static final String ERROR_CODE_E00317 = "|E00317";
    public static final String ERROR_CODE_E00318 = "|E00318";
    public static final String ERROR_CODE_E00265 = "|E00265";
    public static final String ERROR_CODE_E00266 = "|E00266";
    public static final String ERROR_CODE_E00267 = "|E00267";
    public static final String ERROR_CODE_E00319 = "|E00319";
    public static final String ERROR_CODE_E00320 = "|E00320";
    public static final String ERROR_CODE_E00268 = "|E00268";
    public static final String ERROR_CODE_E00269 = "|E00269";
    public static final String ERROR_CODE_E00270 = "|E00270";
    public static final String ERROR_CODE_E00271 = "|E00271";
    public static final String ERROR_CODE_E00272 = "|E00272";
    public static final String ERROR_CODE_E00273 = "|E00273";
    public static final String ERROR_CODE_E00114 = "|E00114";
    public static final String ERROR_CODE_E00276 = "|E00276";
    public static final String ERROR_CODE_E00284 = "|E00284";
    public static final String ERROR_CODE_E00321 = "|E00321";
    public static final String ERROR_CODE_E00324 = "|E00324";
    public static final String ERROR_CODE_E00537 = "|E00537";
    public static final String ERROR_CODE_E00546 = "|E00546";
    public static final String ERROR_CODE_E00547 = "|E00547";
    public static final String ERROR_CODE_E00558 = "|E00558";
    public static final String ERROR_CODE_E00548 = "|E00548";
    public static final String ERROR_CODE_E00539 = "|E00539";
    public static final String ERROR_CODE_E00549 = "|E00549";
    public static final String ERROR_CODE_E00540 = "|E00540";
    public static final String ERROR_CODE_E00550 = "|E00550";
    public static final String ERROR_CODE_E00541 = "|E00541";
    public static final String ERROR_CODE_E00551 = "|E00551";
    public static final String ERROR_CODE_E00542 = "|E00542";
    public static final String ERROR_CODE_E00552 = "|E00552";
    public static final String ERROR_CODE_E00543 = "|E00543";
    public static final String ERROR_CODE_E00553 = "|E00553";
    public static final String ERROR_CODE_E00544 = "|E00544";
    public static final String ERROR_CODE_E00554 = "|E00554";
    public static final String ERROR_CODE_E00545 = "|E00545";
    public static final String ERROR_CODE_E00556 = "|E00556";
    public static final String ERROR_CODE_E00555 = "|E00555";

    public static final String EWAY_ERROR_CODE_E00285 = "|E00285";
    public static final String ERROR_CODE_E00322 = "|E00322";
    public static final String EINVOICE_ERROR_CODE_E00323 = "|E00323";
    public static final String EINVOICE_ERROR_CODE_DE1000 = "|DE1000";
    public static final String EINVOICE_ERROR_CODE_O0091 = "|O0091";
    public static final String EINVOICE_ERROR_CODE_O0090 = "|O0090";
    public static final String EINVOICE_ERROR_CODE_E00101 = "|E00101";
    public static final String EINVOICE_ERROR_CODE_E00513 = "|E00513";
    public static final String EINVOICE_ERROR_CODE_E00585 = "|E00585";
    public static final String EINVOICE_ERROR_CODE_E00523 = "|E00523";
    public static final String EINVOICE_ERROR_CODE_E00524 = "|E00524";
    public static final String EINVOICE_ERROR_CODE_E00525 = "|E00525";
    public static final String EINVOICE_ERROR_CODE_E00514 = "|E00514";

    public static final Object EINVOICE_ERROR_CODE_E00169 = "|E00169";

    public static final String ERROR_CODE_E00349 = "|E00349";

    public static final String EWAY_ERROR_CODE_E00266 = "|E00266";

    public static final String EWAY_ERROR_CODE_E00265 = "|E00265";

    public static final String EWAY_ERROR_CODE_E00269 = "|E00269";

    public static final String EWAY_ERROR_CODE_E00268 = "|E00268";

    public static final String ERROR_CODE_E00351 = "|E00351";

    public static final String ERROR_CODE_E00350 = "|E00350";

    public static final String ERROR_CODE_E00352 = "|E00352";

    public static final String ERROR_CODE_E00353 = "|E00353";

    public static final String ERROR_CODE_E00354 = "|E00354";

    public static final String ERROR_CODE_O0093 = "|O0093";

    public static final String ERROR_CODE_E00087 = "|E00087";

    public static final String ERROR_CODE_E00355 = "|E00355";

    public static final String ERROR_CODE_E00356 = "|E00356";

    public static final String ERROR_CODE_E00515 = "|E00515";

    public static final String EINVOICE_ERROR_CODE_E00352 = "|E00514";

    public static final String ERROR_CODE_E00564 = "|E00564";

    public static final String ERROR_CODE_E00291 = "|E00291";

	public static final String ERROR_CODE_E00586 = "|E00586";
	
	public static final String GET_EWB_ERROR_CODE_GE0001 = "|GE0001";
	public static final String GET_EWB_ERROR_CODE_GE0002 = "|GE0002";

}
