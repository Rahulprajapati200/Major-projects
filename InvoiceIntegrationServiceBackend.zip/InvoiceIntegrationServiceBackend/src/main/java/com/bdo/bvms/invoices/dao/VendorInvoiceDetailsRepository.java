package com.bdo.bvms.invoices.dao;

import java.util.List;

import javax.validation.Valid;

import com.bdo.bvms.invoices.dto.EInvoiceDTO;
import com.bdo.bvms.invoices.dto.EWBViewDTO;
import com.bdo.bvms.invoices.dto.EWBViewResponseDTO;
import com.bdo.bvms.invoices.dto.EwayBillBasicInfoBillingAddressDTO;
import com.bdo.bvms.invoices.dto.EwayBillBasicInfoHeaderDTO;
import com.bdo.bvms.invoices.dto.EwayBillBasicInfoShipingAddressDTO;
import com.bdo.bvms.invoices.dto.EwayBillDetailDTO;
import com.bdo.bvms.invoices.dto.EwayBillIAdditionalInfoDTO;
import com.bdo.bvms.invoices.dto.EwayBillITransportDetaiLPartADTO;
import com.bdo.bvms.invoices.dto.EwayBillITransportDetaiLPartBDTO;
import com.bdo.bvms.invoices.dto.EwayBillItemDetailsHeaderDTO;
import com.bdo.bvms.invoices.dto.EwayBillItemDetailsListDTO;
import com.bdo.bvms.invoices.dto.GetEWayBillDTO;
import com.bdo.bvms.invoices.dto.GetEwayBillDetailsRequestDTO;
import com.bdo.bvms.invoices.dto.GetGstr2aDTO;
import com.bdo.bvms.invoices.dto.GetGstr2bDTO;
import com.bdo.bvms.invoices.dto.GoodReceiptNoteDTO;
import com.bdo.bvms.invoices.dto.Gstr2aResponseDTO;
import com.bdo.bvms.invoices.dto.Gstr2LineItemsDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsReqDTO;
import com.bdo.bvms.invoices.dto.InvoicePrimaryDetail;
import com.bdo.bvms.invoices.dto.PurchaseOrderDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceGETRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceGetResponseDTO;
import com.bdo.bvms.invoices.dto.WfApproveOrRejectDTO;
import com.bdo.bvms.ocr.dto.OcrDetail;

public interface VendorInvoiceDetailsRepository {

    EwayBillDetailDTO getEwayBillDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

    EInvoiceDTO getEInvoiceDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

    PurchaseOrderDTO getPurchaseOrderDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

    GoodReceiptNoteDTO getGoodReceiptNoteDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

    GetGstr2aDTO getGetGstr2aDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

    GetGstr2bDTO getGetGstr2bDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

    GetEWayBillDTO getGetEWayBillDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

    List<Gstr2aResponseDTO> getGstr2aDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

    List<Gstr2LineItemsDTO> getGstr2aLineItemsList(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

    List<Gstr2LineItemsDTO> getGstr2bLineItemsList(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

    int getCountGstr2aLineItems(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

    int getCountGstr2bLineItems(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

    EwayBillBasicInfoHeaderDTO getEwayBillBasicInfoHeaderData(String ewbNo);

    EwayBillBasicInfoBillingAddressDTO getEwayBillBasicInfoBillToDetails(String ewbNo);

    EwayBillBasicInfoBillingAddressDTO getEwayBillBasicInfoBillFromDetails(String ewbNo);

    EwayBillBasicInfoShipingAddressDTO getEwayBillBasicInfoDispatchFromDetails(String ewbNo);

    EwayBillBasicInfoShipingAddressDTO getEwayBillBasicInfoShipToDetails(String ewbNo);

    EwayBillItemDetailsHeaderDTO getEwayBillItemDetailsHeaderData(String ewbNo);

    EwayBillITransportDetaiLPartADTO getEwayBillITransportDetaiLPartAData(String ewbNo);

    EwayBillITransportDetaiLPartBDTO getEwayBillITransportDetaiLPartBData(String ewbNo);

    EwayBillIAdditionalInfoDTO getEwayBillIAdditionalInfoData(String ewbNo);

    List<VendorInvoiceGetResponseDTO> getGetExistingEWBdetails(VendorInvoiceGETRequestDTO vendorInvoiceGETRequestDTO);

    List<EWBViewResponseDTO> getEwaybillView(EWBViewDTO ewbViewDTO);

    int getEwaybillViewCount(EWBViewDTO ewbViewDTO);

    int getGetEwayBillOnUICount(VendorInvoiceGETRequestDTO vendorInvoiceGETRequestDTO);

    int getEwayBillItemDetailsListDataCount(GetEwayBillDetailsRequestDTO getEwayBillDetailsRequestDTO);

    List<EwayBillItemDetailsListDTO> getEwayBillItemDetailsListData(
                    GetEwayBillDetailsRequestDTO getEwayBillDetailsRequestDTO);

    String sendWfApprovedOrRegectDataToDb(@Valid WfApproveOrRejectDTO wfApproveOrRejectDTO);

    Integer getBaseDocument(InvoicePrimaryDetail invDetail);

    InvoicePrimaryDetail getInvoicePrimaryDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

	/**
	 * Gets the gets the gstr 2 b details.
	 *
	 * @param invoiceDetailsReqDTO
	 *            the invoice details req DTO
	 * @return the gets the gstr 2 b details
	 */
	OcrDetail getOcrDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO);

}
