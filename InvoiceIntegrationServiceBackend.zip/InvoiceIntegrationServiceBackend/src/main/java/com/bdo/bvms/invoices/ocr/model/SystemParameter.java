package com.bdo.bvms.invoices.ocr.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class SystemParameter {

    String keyName;
    String keyValue;
    String descrip;
    
    
}
