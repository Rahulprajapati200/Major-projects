
package com.bdo.bvms.common.sql;

// TODO: Auto-generated Javadoc
/**
 * The Class TaxpayerSql.
 */
public class CommonSql {

    /**
     * Instantiates a new taxpayer sql.
     */
    CommonSql() {

    }

    /** The Constant GET_PICKUP_LIST_DETAILS_MAP_SQL. */
    public static final String GET_PICKUP_LIST_DETAILS_MAP_SQL = new StringBuilder(
                    "Select pld.name as `name`, pld.code as `code`  from sm_pickup_list_details pld ").append(
                                    "INNER JOIN sm_pickup_master  pm ON pm.pickup_master_id = pld.sm_pick_mst_id ")
                                    .append("where pm.name= ? order by pld.sort_order").toString();

/** The Constant GET_SYSTEM_PARAMETER. */
    public static final String GET_SYSTEM_PARAMETER = new StringBuilder(
                    "select KeyNAME,KeyVALUE,DESCRIP,otp_validity_duration,user_id from system_parameter where KeyNAME = ?")
                                    .toString();

public static final String UPDATE_URP_TABLE = "INSERT into email_document_received_pull_log(json_received) VALUES(?)";

public static final String UPDATE_ERROR_TABLE = "INSERT into email_document_received_error_log(user_id,entity_id,taxpayer_gstin,email_from,received_on,error_message,is_vendor,created_at,created_by)"
		+ " VALUES(?,?,?,?,now(),?,?,now(),?)";
    
}
