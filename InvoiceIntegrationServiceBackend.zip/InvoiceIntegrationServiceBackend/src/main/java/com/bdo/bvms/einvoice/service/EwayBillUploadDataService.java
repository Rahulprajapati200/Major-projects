package com.bdo.bvms.einvoice.service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.text.ParseException;
import java.util.List;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.custom.exception.InvoiceTemplateUploadException;
import com.bdo.bvms.invoices.custom.exception.ReadInvoicePojoListException;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.EWayBillDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.microsoft.azure.storage.StorageException;

/**
 * The Interface EwayBillReadDataService.
 */
public interface EwayBillUploadDataService {

    /**
     * Read source excel.
     *
     * @param vbo
     *            the vbo
     * @return the response bean
     * @throws InvalidKeyException
     *             the invalid key exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws URISyntaxException
     *             the URI syntax exception
     * @throws StorageException
     *             the storage exception
     * @throws BDOException
     *             the BDO exception
     * @throws ParseException
     *             the parse exception
     * @throws InvoiceTemplateUploadException
     * @throws BVMSException
     * @throws Exception
     */
    String validateNSaveData(UploadReqDTO vbo, AzureConnectionCredentialsDTO map) throws InvoiceTemplateUploadException;

    List<EWayBillDTO> getExcelEWayDataList(UploadReqDTO uploadDTO)
                    throws InvoiceTemplateUploadException, IOException, ReadInvoicePojoListException;

}
