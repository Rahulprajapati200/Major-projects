package com.bdo.bvms.invoices.dto;

import org.springframework.data.relational.core.mapping.Column;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EWBViewResponseDTO {

    int id;
    @Column("status")
    String status;
    @Column("ewb_no")
    String ewbNo;
    @Column("doc_no")
    String docNo;
    @Column("from_name")
    String fromName;
    @Column("from_gstin")
    String fromGstin;
    @Column("totInvValue")
    String totInvValue;

}
