package com.bdo.bvms.invoices.dto;

import java.math.BigDecimal;

import com.bdo.bvms.invoices.util.NumberUtils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Gstr2aResponseDTO {

    String taxpayerGstin;

    String vendorGstin;

    String invNo;

    String vendorLegalName;
    String vendorTradeName;

    String invDate;

    String docType;
    String invoiceType;
    
    String fileType;

    String source;

    String batchNo;
    
    String pos;
    
    String delinkFlag;
    
    String grossTotal;

    String gstr1FilingStatus;
    
    String gstr3FilingStatus;

    String dateSupplierCancelllation;

    String dateFilingGstrSupplier;
    
    String filingPeriodGstrSupplier; 
    
    
    String amendmentReturnPeriod;

    String amendmentType;

    String itcAvailability;
    String itcUnavailabilityReason;
    String sourceType;
    String gstr2bFp;
    String irn;
    String irnGeneratedDate;
    String igstRate;
    String taxableAmount;

    String sgstRate;

    String cgstRate;

    String cessRate;
    String igstAmount;

    String cgstAmount;

    String sgstAmount;

    String cessAmount;

    String totalItemValue;
    
    String differentialRate;
    
    String reversecharge;
    
    String totalTax;
    
    public void setTaxableAmount(BigDecimal value) {
        this.taxableAmount = NumberUtils.getFormattedGrouppedNumber(value);
    }
    
    public void setDifferentialRate(BigDecimal value) {
        this.differentialRate = NumberUtils.getFormattedGrouppedNumber(value);
    }


    public void setIgstAmount(BigDecimal value) {
        this.igstAmount = NumberUtils.getFormattedGrouppedNumber(value);
    }

    public void setCgstAmount(BigDecimal value) {
        this.cgstAmount = NumberUtils.getFormattedGrouppedNumber(value);
    }

    public void setCessAmount(BigDecimal value) {
        this.cessAmount = NumberUtils.getFormattedGrouppedNumber(value);
    }

    public void setTotalItemValue(BigDecimal value) {
        this.totalItemValue = NumberUtils.getFormattedGrouppedNumber(value);
    }

    public void setSgstAmount(BigDecimal value) {
        this.sgstAmount = NumberUtils.getFormattedGrouppedNumber(value);
    }


}
