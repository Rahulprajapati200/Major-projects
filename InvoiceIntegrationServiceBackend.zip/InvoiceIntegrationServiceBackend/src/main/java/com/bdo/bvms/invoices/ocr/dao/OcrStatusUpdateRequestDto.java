package com.bdo.bvms.invoices.ocr.dao;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.bdo.bvms.invoices.dto.BaseDTO;
import com.bdo.bvms.invoices.dto.BaseReqDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OcrStatusUpdateRequestDto  extends BaseReqDTO {
	List<Integer> idList;
	List<String> taxpayerGstinList;
	@NotNull(message = "{fileId.notNull}")
	Integer action;          
	@NotNull(message = "{fileId.notNull}")
    Integer isTaxpayer;
	

}
