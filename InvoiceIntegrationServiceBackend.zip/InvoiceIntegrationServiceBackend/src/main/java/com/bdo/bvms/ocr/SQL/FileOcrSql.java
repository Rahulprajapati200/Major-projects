package com.bdo.bvms.ocr.SQL;

public class FileOcrSql {

	public static final String GET_OCR_DATA_PROC = "call vendor_invoice_ocr_details(?,?,?,?,?,?,?,?,?)";

	public static final String GET_OCR_CONFIG_MAP = "SELECT id,ocr_extracted_data_key FROM ocr_field_config where is_line_item = ? AND ocr_extracted_data_key is not null";

	public static final String INSERT_INTO_OCR_VERTICAL_DATA = "INSERT INTO ocr_vertical_data (file_id, ocr_vendor_template_mst_id, ocr_field_mst_id, ocr_extracted_value, ocr_accuracy_lvl, is_taxpayer,file_path, is_header, line_no,created_at, created_by)VALUES (?,?,?,?,?,?,?,?,?,now(),?)";

	public static final String GET_FILE_FOR_OCR = "SELECT OH.file_id,UL.base_file_location  FROM ocr_header OH JOIN upload_log UL ON OH.batch_no = UL.batch_no  WHERE OH.pld_ocr_status = ? and COALESCE(OH.is_lock_for_ocr,0) = 0  and COALESCE(OH.retry_count,0) < 5";

	public static final String INSERT_TO_INVOICE_EWB_DETAILS_TABLE = "INSERT INTO invoice_eway_bill_details (gstin_uin_of_recipient, pan_of_recipient, year_id, doc_type, inward_no, inward_date, gstin_of_supplier, purchase_order_no, purchase_order_date,template_type, filling_period, row_version, is_valid, batch_no,is_ocr_applicable)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	public static final String INSERT_TO_OCR_PUSH_LOG = "INSERT INTO vendor_invoice_ocr_push_log (file_id, batch_no, ack_no, req_send_on, request_header, requested_source, URL, ref_table_name, payload, received_on) VALUES (?,?,?,?,?,?,?,?,?,?)";

	public static final String INSERT_TO_OCR_PULL_LOG = "INSERT INTO vendor_invoice_ocr_pull_log (ack_no, batch_no, ocr_extracted_data, file_id, payload, requested_on, received_on, status, error_desc) VALUES (?,?,?,?,?,?,?,?,?)";

	public static StringBuilder updateOcrStatus() {
		return new StringBuilder("update ocr_header set pld_ocr_status =?,is_lock_for_ocr=? ");
	}

	public static final String GET_OCR_PULL_PENDING = "SELECT ack_no,file_id FROM vendor_invoice_ocr_pull_log WHERE status =?";

	public static final String UPDATE_OCR_PULL_LOG = "UPDATE vendor_invoice_ocr_pull_log SET ocr_extracted_data=?, payload=?, requested_on=?, received_on=?,status=?,error_desc=? WHERE file_id = ?";

	public static final String INSERT_VERTICAL_MAP_ARCHIVE_SQL = new StringBuilder(
			"INSERT INTO ocr_vertical_data_archived\r\n")
			.append("(ocr_vertical_map_id, file_id, ocr_vendor_template_mst_id, ocr_field_mst_id,ocr_extracted_value, ocr_accuracy_lvl,\r\n")
			.append("is_taxpayer, created_at, created_by, file_path, is_header, line_no)\r\n")
			.append("SELECT id, file_id, ocr_vendor_template_mst_id, ocr_field_mst_id, ocr_extracted_value, ocr_accuracy_lvl,\r\n")
			.append(" is_taxpayer,created_at, created_by,file_path, is_header, line_no FROM ocr_vertical_data \r\n")
			.append(" where file_id = ? ").toString();

	public static final String DELETE_VERTICAL_MAP_SQL = "delete FROM ocr_vertical_data WHERE file_id = ? ";

	public static final String INSERT_TO_OCR_COMPLIANCE_ERROR = "INSERT INTO ocr_extraction_and_compliance_error(error_code, file_id, ocr_field_mst_id,line_no,error_type) VALUES(?,?,?,?,?)";

	public static final String GET_COMPLIANCE_ERROR_ISSUES = "SELECT oce.error_code,cvr.error_desc,cvr.risk_catagory,line_no from ocr_extraction_and_compliance_error oce JOIN ocr_compliance_validation_rules cvr ON oce.error_code = cvr.error_code where oce.file_id=? and oce.error_type = ?";

	public static final String getUploadHistoryByBatchNo(String batchNos) {
		return new StringBuilder("SELECT taxpayer_gstin,fp,batch_no FROM upload_log WHERE batch_no in " + batchNos)
				.toString();
	}
	
	public static final String DELETE_INVOICE_HEADER_SQL = "delete FROM invoice_header WHERE batch_no = ? ";
	
	public static final String DELETE_INVOICE_EWB_DETAILS_SQL = "delete FROM invoice_eway_bill_details WHERE batch_no = ? ";
	
	public static final String GET_STATE_CODE_BY_STATENAME_SQL = "SELECT item_code FROM sm_country_state_city where description = ? and name = ? ";

}
