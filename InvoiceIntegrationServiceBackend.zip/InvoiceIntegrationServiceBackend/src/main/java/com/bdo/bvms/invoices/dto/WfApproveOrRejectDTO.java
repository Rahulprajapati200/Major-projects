package com.bdo.bvms.invoices.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class WfApproveOrRejectDTO extends PageReqDTO {

    private int requestType;
    private String remarks;

    private List<Integer> ids;

}
