package com.bdo.bvms.invoices.controller;

import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.BatchUpdateException;
import java.text.ParseException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;

import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.custom.exception.InvoiceTemplateUploadException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.APIResponseDTO;
import com.bdo.bvms.invoices.dto.EWBViewDTO;
import com.bdo.bvms.invoices.dto.GetEwayBillDetailsRequestDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsReqDTO;
import com.bdo.bvms.invoices.dto.PowerAutomateRequestBody;
import com.bdo.bvms.invoices.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.invoices.dto.UploadHistoryResponseDTO;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceGETRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceResponseDTO;
import com.bdo.bvms.invoices.dto.WfApproveOrRejectDTO;
import com.bdo.bvms.ocr.dto.OcrBatchResponseReqDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.microsoft.azure.storage.StorageException;

public interface VendorInvoiceTaxpayerController {

    ResponseEntity<APIResponseDTO> uploadFile(HttpServletRequest httpServletRequest,
                    @ModelAttribute UploadRequestDTO apiRequestDTO) throws VendorInvoiceServerException,
                    InvoiceTemplateUploadException, URISyntaxException, StorageException, ParseException;

    ResponseEntity<VendorInvoiceResponseDTO> getDataList(HttpServletRequest request,
                    VendorInvoiceRequestDTO vendorInvoiceRequestDTO) throws VendorInvoiceServerException;

    ResponseEntity<UploadHistoryResponseDTO> logHistory(HttpServletRequest request, UploadHistoryRequestDTO requestDTO)
                    throws VendorInvoiceServerException;

    ResponseEntity<VendorInvoiceResponseDTO> getInvoiceDetails(HttpServletRequest request,
                    InvoiceDetailsReqDTO invoiceDetailsReqDTO) throws VendorInvoiceServerException;

    ResponseEntity<VendorInvoiceResponseDTO> getInvoiceLineItemViewDetails(HttpServletRequest request,
                    InvoiceDetailsReqDTO invoiceDetailsReqDTO) throws VendorInvoiceServerException;

    ResponseEntity<Resource> getDownloadInvoiceDetails(HttpServletRequest request,
                    InvoiceDetailsReqDTO invoiceDetailsReqDTO) throws VendorInvoiceServerException, IOException;

    ResponseEntity<VendorInvoiceResponseDTO> getWayBillViewDetails(HttpServletRequest request,
                    GetEwayBillDetailsRequestDTO getEwayBillDetailsRequestDTO) throws InvoiceIntegrationEWBException;

    ResponseEntity<VendorInvoiceResponseDTO> getGetEwayBillDataOnUI(HttpServletRequest request,
                    VendorInvoiceGETRequestDTO vendorInvoiceGETRequestDTO) throws InvoiceIntegrationEWBException;

    public ResponseEntity<VendorInvoiceResponseDTO> getewaybillView(HttpServletRequest request,
                    @RequestBody EWBViewDTO eWBViewDTO) throws InvoiceIntegrationEWBException;

    ResponseEntity<APIResponseDTO> wfApproveOrReject(HttpServletRequest httpServletRequest,
                    WfApproveOrRejectDTO wfApproveOrRejectDTO) throws VendorInvoiceServerException;

	Object getGetEwayBillDetailsDemo(HttpServletRequest request,
			VendorInvoiceGETRequestDTO reqDto) throws InvoiceIntegrationEWBException;

	ResponseEntity<APIResponseDTO> callUrpUploadService(HttpServletRequest request, PowerAutomateRequestBody powerAutomateRequestBody) throws IOException, VendorInvoiceServerException;


}
