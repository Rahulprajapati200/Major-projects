package com.bdo.bvms.ewaybill.api.impl;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.json.JSONObject;
import org.springframework.util.ResourceUtils;

import com.bdo.bvms.invoices.constant.Constants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Encryption {

    private static Cipher decryptCipher;
    private static KeyGenerator keygen;
    static {
        try {

            decryptCipher = Cipher.getInstance(Constants.AES_ECB_PKC_PADDING);
            keygen = KeyGenerator.getInstance(Constants.AES);
            keygen.init(256);
        } catch (NoSuchAlgorithmException | javax.crypto.NoSuchPaddingException e) {
            log.error("Error occured while execute Encryption function:", e);

        }
    }

    public static String encryptTextWithPublicKey(String msg, PublicKey key) throws IllegalBlockSizeException,
                    BadPaddingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException {
        Cipher cipher = Cipher.getInstance(Constants.RSA);
        cipher.init(1, key);
        return Base64.getEncoder().encodeToString(cipher.doFinal(msg.getBytes(StandardCharsets.UTF_8)));
    }

    public static PublicKey getPublic(String filename)
                    throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
        File f = ResourceUtils.getFile(filename);
        byte[] keyBytes = Files.readAllBytes(f.toPath());
        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance(Constants.RSA);
        return kf.generatePublic(spec);
    }

    public static String decryptSEK(String appkey, String sek) {
        try {
            byte[] appKeyBytes = appkey.getBytes(StandardCharsets.UTF_8);
            byte[] decryptedTextBytes = decrypt(sek, appKeyBytes);
            return Base64.getEncoder().encodeToString(decryptedTextBytes);
        } catch (Exception e) {
            log.error("error in decryptSEK method", e);
            return e.getMessage();
        }
    }

    public static String decryptResponse(String encryptedResponseData, String decryptedSek) {
        try {
            byte[] encKeyBytes = Base64.getDecoder().decode(decryptedSek.replaceAll(" ", "+").trim());
            byte[] decryptedTextBytes = decrypt(encryptedResponseData, encKeyBytes);
            return new String(decryptedTextBytes);
        } catch (Exception e) {
            log.error("error in decryptResponse method", e);
            return e.getMessage();
        }
    }

    public static byte[] decrypt(String plainText, byte[] secret)
                    throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        SecretKeySpec sk = new SecretKeySpec(secret, Constants.AES);
        decryptCipher.init(2, sk);
        return decryptCipher.doFinal(Base64.getDecoder().decode(plainText));
    }

    public static String decryptGetApiResponseData(String encryptedResponseData, String decryptedSek)
                    throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        try {
            JSONObject jsonobj = new JSONObject(encryptedResponseData);
            String resData = jsonobj.getString("data");
            String resrek = jsonobj.getString("rek");
            String decRek = decryptRek(decryptedSek, resrek);
            return decryptResponseDataRek(decRek, resData);
        } catch (Exception e) {
            log.error("error in decryptGetApiResponseData method", e);
            return e.getMessage();
        }
    }

    public static String decryptResponseDataRek(String decRek, String data)
                    throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        byte[] encKeyBytes = Base64.getDecoder().decode(decRek.replaceAll(" ", "+").trim());
        byte[] decryptedTextBytes = decrypt(data, encKeyBytes);
        return new String(decryptedTextBytes);
    }

    public static String decryptRek(String decryptedSek, String resRek)
                    throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        byte[] encKeyBytes = Base64.getDecoder().decode(decryptedSek.replaceAll(" ", "+").trim());
        byte[] decryptedTextBytes2 = decrypt(resRek, encKeyBytes);
        return Base64.getEncoder().encodeToString(decryptedTextBytes2);
    }

}
