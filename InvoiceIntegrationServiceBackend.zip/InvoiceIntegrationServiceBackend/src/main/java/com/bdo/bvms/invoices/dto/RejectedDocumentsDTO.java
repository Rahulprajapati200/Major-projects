package com.bdo.bvms.invoices.dto;

import java.time.LocalDateTime;

import com.bdo.bvms.invoices.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RejectedDocumentsDTO {

    private int id;
    private String companyGstin;
    private String dataType;
    private String customerGstin;
    private String customerLegalName;
    private String customerTradeName;
    private String invoiceNo;
    private String invoiceDate;
    private String ewayBillNo;
    private String ewayBillDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
    private LocalDateTime submittedOn;

    private String submittedBy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
    private LocalDateTime rejectedOn;

    private String documentStatus;
    private String action;
    private int totalCount;
    private Long wfMstId;
}
