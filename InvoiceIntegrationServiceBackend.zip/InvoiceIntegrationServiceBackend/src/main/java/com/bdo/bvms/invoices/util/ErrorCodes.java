package com.bdo.bvms.invoices.util;

public class ErrorCodes {
	ErrorCodes(){
		
	}

    public static final String INTERSTATECHECK = "40";
    public static final String INTRASTATECHECK = "41";
    public static final String TAXCALCULATIONWITHOUTDIFF = "102";
    public static final String TAXCALCULATIONWITHDIFF = "103";
    public static final String INVOICEHAVESAMEDOCNO = "275";
}
