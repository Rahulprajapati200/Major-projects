package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EInvoiceTemplateDTO {

    private String gstinUinOfRecipient;
    private String panOfRecipient;
    private String docType;
    private String inwardNo;
    private String fillingPeriod;
    private String inwardDate;
    private String gstinOfSupplier;
    private String mainHSNCode;
    private String totalInvoiceValue;
    private String purchaseOrderNumber;
    private String purchaseOrderDate;
    private Integer itemCount;
    private String irn;
    private String irnDate;
    private String udf1;
    private String udf2;
    private String udf3;
    private String udf4;
    private String udf5;
    private String udf6;
    private String udf7;
    private String udf8;
    private String udf9;
    private String udf10;
    private String udf11;
    private String udf12;
    private String udf13;
    private String udf14;
    private String udf15;
    private String udf16;
    private String udf17;
    private String udf18;
    private String udf19;
    private String udf20;
    private StringBuilder errorCodeList = new StringBuilder();
    private StringBuilder errorDiscriptionList = new StringBuilder();
    private String rowVersion;
    private int excelRowId;
    boolean isValid;
    private String yearId;
    private String qrPageNo;

}
