package com.bdo.bvms.ocr.jobs;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bdo.bvms.einvoice.service.UploadNDownloadFileService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.VendorInvoiceConstants;
import com.bdo.bvms.invoices.custom.exception.AzureUploadDownloadException;
import com.bdo.bvms.invoices.custom.exception.FileOcrCustomException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.ocr.dto.OcrPullLogDto;
import com.bdo.bvms.ocr.dto.OcrPushLogDto;
import com.bdo.bvms.ocr.repository.FileOcrProcessAndSaveRepository;
import com.bdo.bvms.ocr.util.EncodeFileBytesToStringUtil;
import com.bdo.invoices.bvms.scheduler.EwayBillDetailsSchedularJobByDate;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class OcrDataExtractionPushJob {

	@Value("${temp.folder.path}")
	String tempFolder;
	@Autowired
	FileOcrProcessAndSaveRepository fileOcrProcessAndSaveRepository;
	@Autowired
	CommonDao commonDao;

	@Autowired
	UploadNDownloadFileService uploadFileService;

	RestTemplate restTemplate = new RestTemplate();
	ObjectMapper mapper = new ObjectMapper();

	@Async
	@Scheduled(fixedDelay = 5000)
	public void ocrPushJob() throws FileOcrCustomException, AzureUploadDownloadException {
		
		log.info("Started ocrPushJob at "+LocalDateTime.now());
		JSONObject resultSet = null;
		ArrayList<LinkedHashMap<String, String>> reqFilesList = new ArrayList<>();
		String pushUrl = commonDao.getSystemParameterCredential(Constants.OCR_PUSH_URL);
		String apiKey = commonDao.getSystemParameterCredential(Constants.OCR_API_KEY);
		LinkedHashMap<Integer, String> unProcessedFile = fileOcrProcessAndSaveRepository.getFilesToProcessOcr();
		AzureConnectionCredentialsDTO storageCredentials = commonDao.getAzureCredentialFromDB(0, "blob");
		for (Entry<Integer, String> keyValue : unProcessedFile.entrySet()) {
			try {
				log.info("OCR push process for File Id: " + keyValue.getKey() +" Started");
				String batchNo = (keyValue.getValue().split("_base"))[0];
				OcrPushLogDto ocrPushLogDto = new OcrPushLogDto();
				OcrPullLogDto ocrPullLogDto = new OcrPullLogDto();
				fileOcrProcessAndSaveRepository.updateOcrStatus(keyValue.getKey(), 1, VendorInvoiceConstants.PLD_OCR_STATUS_IN_PROGRESS);
				if (!StringUtils.isBlank(keyValue.getValue())) {
					uploadFileService.downloadFileFromAzureBlob(keyValue.getValue(), tempFolder, storageCredentials,
							new UploadReqDTO());
					LinkedHashMap<String, String> reqFiles = new LinkedHashMap<>();
					reqFiles.put("FileName", keyValue.getValue());
					reqFiles.put("UserFileID", String.valueOf(keyValue.getKey()));
					reqFiles.put("FileContent", EncodeFileBytesToStringUtil.encode(keyValue.getValue(), tempFolder));
					reqFilesList.add(reqFiles);
				}
				JSONObject batchUploadJSONRequest = new JSONObject();
				batchUploadJSONRequest.put("Files", reqFilesList);
				HttpHeaders batchUploadHeaders = new HttpHeaders();
				batchUploadHeaders.setContentType(MediaType.APPLICATION_JSON);
				batchUploadHeaders.add("APIKey",apiKey);
				batchUploadHeaders.add("Module", "");
				HttpEntity<String> entity = new HttpEntity<String>(batchUploadJSONRequest.toString(),
						batchUploadHeaders);
				String requestedOn = Timestamp.from(Instant.now()).toString();
				resultSet = new JSONObject(restTemplate.postForObject(pushUrl, entity, String.class));
				Map<String, Object> batchUploadResponse = mapper.readValue(resultSet.toString(),new TypeReference<Map<String, Object>>(){});
				Map<String, Object> responceDataObject  = mapper.convertValue(batchUploadResponse.get(VendorInvoiceConstants.RESPONSE_DATA_OBJECT), new TypeReference<Map<String, Object>>(){});
				String batchUid = (String)responceDataObject.get("BatchUID");
				ocrPushLogDto = OcrPushLogDto.builder()
								.batchNo(batchNo)
								.fileId(keyValue.getKey())
								.url(pushUrl)
								.reqSource("VCA")
								.reqHeader(batchUploadHeaders.toString())
								.reqOn(requestedOn)
								.recievedOn(Timestamp.from(Instant.now()).toString())
								.payload(batchUploadJSONRequest.toString())
								.ackNo(batchUid)
								.build();
				fileOcrProcessAndSaveRepository.insertIntoOCRPushLog(ocrPushLogDto);
			
				ocrPullLogDto = OcrPullLogDto.builder()
                                .ackNo(batchUid)
                                .batchNo(batchNo)
                                .status("Pending")
                                .fileId(keyValue.getKey())
                                .build();
				fileOcrProcessAndSaveRepository.insertIntoOCRPullLog(ocrPullLogDto);
                log.info("OCR push process for File Id: " + keyValue.getKey() +" Completed");
			} catch (AzureUploadDownloadException e) {
				log.error("File storage service is down", e);
				fileOcrProcessAndSaveRepository.updateOcrStatus(keyValue.getKey(), 0, VendorInvoiceConstants.OCR_NOT_STARTED_PLD);
			} catch (Exception e) {
				log.error("Exception found in OcrDataExtractionPushJob", e);
				fileOcrProcessAndSaveRepository.updateOcrStatus(keyValue.getKey(), 0, VendorInvoiceConstants.OCR_NOT_STARTED_PLD);
			}
			finally {
				reqFilesList.clear();
			}
		}
	}
}
