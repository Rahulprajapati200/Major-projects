package com.bdo.bvms.invoices.dao;

import java.util.List;

import com.bdo.bvms.invoices.dto.UploadReqDTO;

public interface UploadDao {

    public List<UploadReqDTO> getBatchDetails(String tenantId);

    int updateBatchLog(String batchNo);

    int updateAgainBatchLog(String batchNo);

}
