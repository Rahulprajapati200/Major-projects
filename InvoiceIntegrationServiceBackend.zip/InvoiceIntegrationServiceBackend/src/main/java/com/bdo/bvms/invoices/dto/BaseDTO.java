package com.bdo.bvms.invoices.dto;

import java.io.Serializable;
import java.util.Date;

public abstract class BaseDTO implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	protected Integer status;
	protected String ipAddress;
	protected Long createdBy;
	protected Date createdDate;
	protected Long updatedBy;
	protected Date updatedDate;
	protected String createdByName;
	protected String updatedByName;
	protected String sUserName;
	protected String sUserID;
	protected String sCreateDate;
	protected String sUpdateDate;
	protected String exceptionCode;

	/** The start index. */
	private String startIndex;

	public void setExceptionCode(String exceptionCode) {
		this.exceptionCode = exceptionCode;
	}

	/**
	 * Parameterized Constructor
	 * 
	 * @param ip_address
	 * @param createdBy
	 * @param createdDate
	 * @param updatedBy
	 * @param updatedDate
	 */
	protected BaseDTO(String ipAddress, Long createdBy, Date createdDate, Long updatedBy, Date updatedDate) {

		this.ipAddress = ipAddress;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.updatedBy = updatedBy;
		this.updatedDate = updatedDate;

	}

	public String getsCreateDate() {
		return sCreateDate;
	}

	public void setsCreateDate(String sCreateDate) {
		this.sCreateDate = sCreateDate;
	}

	public String getsUpdateDate() {
		return sUpdateDate;
	}

	public void setsUpdateDate(String sUpdateDate) {
		this.sUpdateDate = sUpdateDate;
	}

	public String getCreatedByName() {
		return createdByName;
	}

	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}

	public String getUpdatedByName() {
		return updatedByName;
	}

	public void setUpdatedByName(String updatedByName) {
		this.updatedByName = updatedByName;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getsUserName() {
		return sUserName;
	}

	public void setsUserName(String sUserName) {
		this.sUserName = sUserName;
	}

	public String getsUserID() {
		return sUserID;
	}

	public void setsUserID(String sUserID) {
		this.sUserID = sUserID;
	}

	public String getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(String startIndex) {
		this.startIndex = startIndex;
	}

	@Override
	public String toString() {
		return "BaseDTO [status=" + status + ", ipAddress=" + ipAddress + ", createdBy=" + createdBy + ", createdDate="
				+ createdDate + ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + ", createdByName="
				+ createdByName + ", updatedByName=" + updatedByName + ", sUserName=" + sUserName + ", sUserID="
				+ sUserID + ", sCreateDate=" + sCreateDate + ", sUpdateDate=" + sUpdateDate + "]";
	}

}
