package com.bdo.bvms.einvoice.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.bdo.bvms.invoices.custom.exception.InvalidTemplateHeaderException;
import com.bdo.bvms.invoices.custom.exception.InvoiceTemplateUploadException;
import com.bdo.bvms.invoices.custom.exception.ReadInvoicePojoListException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;

/**
 * The Interface EinvoiceDataTemplateUpload.
 */
public interface EinvoiceDataTemplateUpload {

    /**
     * Gets the einvoice data list.
     *
     * @param uploadDTO
     *            the upload DTO
     * @return the einvoice data list
     * @throws IOException
     * @throws ReadInvoicePojoListException 
     * @throws FileNotFoundException
     * @throws BDOException
     * @throws Exception
     *             the exception
     */
    List<EInvoiceTemplateDTO> getEinvoiceDataList(UploadReqDTO uploadDTO)
                    throws InvalidTemplateHeaderException,IOException, ReadInvoicePojoListException;

    /**
     * Validate N save xls data.
     *
     * @param uploadDto
     *            the upload dto
     * @throws InvoiceTemplateUploadException
     */
    String validateAndSaveData(UploadReqDTO uploadDto, AzureConnectionCredentialsDTO map)
                    throws InvoiceTemplateUploadException;

}
