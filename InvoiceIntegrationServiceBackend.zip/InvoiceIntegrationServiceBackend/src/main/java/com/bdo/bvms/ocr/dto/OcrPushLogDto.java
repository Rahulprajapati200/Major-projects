package com.bdo.bvms.ocr.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OcrPushLogDto {
	Integer fileId;
	String batchNo;
	String ackNo;
	String reqHeader;
	String reqSource;
	String url;
	String payload;
	String reqOn;
	String recievedOn;
}
