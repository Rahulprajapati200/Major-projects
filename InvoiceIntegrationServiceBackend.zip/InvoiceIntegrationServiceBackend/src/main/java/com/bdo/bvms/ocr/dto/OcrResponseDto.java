package com.bdo.bvms.ocr.dto;

import java.time.LocalDateTime;

import com.bdo.bvms.invoices.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OcrResponseDto {
	
	int id;
	String taxpayerGstin;
	String vendorGstin;
	String ewayBillNo;
	String ewaybillDate;
	String invoiceNo;
	String invoiceDate;
	String dataType;
	String invoiceType;
	String poNo;
	Integer fileId;
	String ocrStatus;
	String batchNo;
	String vendorName;
	String ocrVerification;
	String uploadedBy;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
	LocalDateTime uploadedOn;
	String taxableAmount;
	String igst;
	String cgst;
	String sgst;
	String cess;
	String invoiceValue;
	String irnNo;
	String irnDate;
	Integer extraction;
	Integer compliance;
	String fileName;
	String isTaxpayerUploaded;
	int totalCount;
	String vendorCodeErp;

}
