package com.bdo.bvms.ocr.dto;

import java.time.LocalDateTime;

import org.springframework.data.relational.core.mapping.Column;

import com.bdo.bvms.invoices.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OcrDetail {
	
	int id;
	String taxpayerGstin;
	String vendorGstin;
	String ewaybillNo;
	String ewaybillDate;
	String invoiceNo;
	String invoiceDate;
	String dataType;
	String invoiceType;
	String poNo;
    String igstAmount = "0.00";

    String cgstAmount = "0.00";

    String sgstAmount = "0.00";

    String cessAmount = "0.00";
    String invoiceValue = "0.00";
	String irnNo;
	String irnDate;
    String vendorName;
    String taxableAmount;
    String fileName;
    String poDate;
    int compliance;
    int extraction;

}
