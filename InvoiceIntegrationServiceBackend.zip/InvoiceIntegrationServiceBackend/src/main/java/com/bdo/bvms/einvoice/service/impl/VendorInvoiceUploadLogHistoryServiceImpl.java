package com.bdo.bvms.einvoice.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.VendorInvoiceUploadLogHistoryService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceUploadLogHistoryDao;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.invoices.dto.UploadLogDto;
import com.bdo.bvms.invoices.dto.UploadLogHistoryResDataDto;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class VendorInvoiceUploadLogHistoryServiceImpl implements VendorInvoiceUploadLogHistoryService {

    @Autowired
    VendorInvoiceUploadLogHistoryDao vendorInvoiceUploadLogHistoryDao;

    @Autowired
    CommonDao commonDao;

    @Override
    public List<UploadLogHistoryResDataDto> getHistoryList(UploadHistoryRequestDTO uploadHistoryRequestDTO)
                    throws VendorInvoiceServerException {

        Page<UploadLogDto> pagedResult = null;
        try {

            // Here we get History upload Data from repository layer.
            pagedResult = vendorInvoiceUploadLogHistoryDao.getHistoryList(uploadHistoryRequestDTO);
            
        } catch (Exception e) {
            log.error("Exception Generated", e);
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();

            String methodName1 = "getHistoryList";

            exceptionLogDTO.setUserId(uploadHistoryRequestDTO.getModuleID());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
            exceptionLogDTO.setFunctionName(methodName1);
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in getting data from database.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException(e.getMessage(), e.getCause());
        }

        return pagedResult.getContent().stream().map(uploadLog -> UploadLogHistoryResDataDto.builder()
                        .taxpayerPan(uploadLog.getTaxpayerPan()).taxpayerGstin(uploadLog.getTaxpayerGstin())
                        .financialPeriod(uploadLog.getFp()).uploadedDate(uploadLog.getCreatedAt())
                        .uploadedBy(uploadLog.getCreatedBy()).dataType(uploadLog.getTemplateType())
                        .fileName(uploadLog.getFileName()).fileType(uploadLog.getFileType())
                        .totalCount(uploadLog.getTotalCount()).successCount(uploadLog.getSuccessCount())
                        .errorCount(uploadLog.getErrorCount()).status(uploadLog.getPldUploadStatus())
                        .baseFile(uploadLog.getBaseFileLocation()).errorFile(uploadLog.getErrorFileLocation())
                        .remarks(uploadLog.getRemarks()).uploadSource(uploadLog.getUploadSource())
                        .parentBatchNo(uploadLog.getPaBatchNo()).isQrScan(uploadLog.getIsQRScan()).pldOcrStatus(uploadLog.getPldOcrStatus())
                        .batchNo(uploadLog.getBatchNo()).customeOrDefault(uploadLog.isCustomTemplate() ? 1 : 0).build())
                        .collect(Collectors.toList());

    }

    @Override
    public void writeInvoiceDetailsToInvoiceHeader() {
        try {

            vendorInvoiceUploadLogHistoryDao.writeInvoiceDetailsToInvoiceHeader();

        } catch (Exception ex) {
            log.error(ex + " Error come in inserting related data into database " + ex.getMessage());

        }
    }

}
