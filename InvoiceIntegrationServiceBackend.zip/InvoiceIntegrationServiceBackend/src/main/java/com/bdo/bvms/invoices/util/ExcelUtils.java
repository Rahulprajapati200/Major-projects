package com.bdo.bvms.invoices.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.bdo.bvms.invoices.constant.Constants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExcelUtils {

    public static Map<String, Object> getHeadersStyles(XSSFWorkbook workbook, XSSFSheet sheet) {

        Map<String, Object> headersStyles = new HashMap<>();

        XSSFColor blueColor = new XSSFColor(new java.awt.Color(2, 165, 226));
        XSSFColor greyColor = new XSSFColor(new java.awt.Color(242, 242, 242));
        XSSFColor borderColor = new XSSFColor(new java.awt.Color(192, 192, 192));

        ///////////////////////////////////////////////////// Upper Header
        ///////////////////////////////////////////////////// Styles//////////////////////////////////////////////////////////////////

        Font headerFont1 = workbook.createFont();
        headerFont1.setColor(IndexedColors.WHITE.index);
        ((XSSFFont) headerFont1).setBold(true);
        headerFont1.setFontHeightInPoints((short) 14);
        XSSFCellStyle headerCellStyle1 = workbook.createCellStyle();
        headerCellStyle1.setFillForegroundColor(blueColor);
        headerCellStyle1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerCellStyle1.setAlignment(HorizontalAlignment.LEFT);

        headerCellStyle1.setFont(headerFont1);

        //////////////////////////////// Lower Header
        //////////////////////////////// Styles///////////////////////////////////////////////////

        Font headerFont2 = workbook.createFont();
        headerFont2.setColor(IndexedColors.BLACK.index);
        ((XSSFFont) headerFont2).setBold(true);
        headerFont2.setFontHeightInPoints((short) 12);
        XSSFCellStyle headerCellStyle2 = workbook.createCellStyle();
        headerCellStyle2.setFillForegroundColor(greyColor);
        headerCellStyle2.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerCellStyle2.setAlignment(HorizontalAlignment.LEFT);

        headerCellStyle2.setBorderTop(BorderStyle.THIN);
        headerCellStyle2.setTopBorderColor(borderColor);
        headerCellStyle2.setBorderBottom(BorderStyle.THIN);
        headerCellStyle2.setBottomBorderColor(borderColor);
        headerCellStyle2.setBorderLeft(BorderStyle.THIN);
        headerCellStyle2.setLeftBorderColor(borderColor);
        headerCellStyle2.setBorderRight(BorderStyle.THIN);
        headerCellStyle2.setRightBorderColor(borderColor);
        headerCellStyle2.setFont(headerFont2);

        ///////////////////////////// Remaining Columns
        ///////////////////////////// Styles//////////////////////////////////

        Font headerFont3 = workbook.createFont();
        headerFont3.setFontHeightInPoints((short) 11);
        XSSFCellStyle headerCellStyle3 = workbook.createCellStyle();
        headerCellStyle3.setFillForegroundColor(IndexedColors.WHITE.index);

        headerCellStyle3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerCellStyle3.setAlignment(HorizontalAlignment.LEFT);
        headerCellStyle3.setBorderTop(BorderStyle.THIN);
        headerCellStyle3.setTopBorderColor(borderColor);
        headerCellStyle3.setBorderBottom(BorderStyle.THIN);
        headerCellStyle3.setBottomBorderColor(borderColor);
        headerCellStyle3.setBorderLeft(BorderStyle.THIN);
        headerCellStyle3.setLeftBorderColor(borderColor);
        headerCellStyle3.setBorderRight(BorderStyle.THIN);
        headerCellStyle3.setRightBorderColor(borderColor);
        headerCellStyle3.setFont(headerFont3);

        headersStyles.put(Constants.HEADERCELLSTYLE1, headerCellStyle1);
        headersStyles.put(Constants.HEADERCELLSTYLE2, headerCellStyle2);
        headersStyles.put(Constants.HEADERCELLSTYLE3, headerCellStyle3);

        return headersStyles;
    }

    public static void setFilterAndFredgeHeader(XSSFSheet sheet, CellRangeAddress range) {
        sheet.setDisplayGridlines(false);
        sheet.createFreezePane(0, 2);
        sheet.setAutoFilter(range);
    }

    public static String getReportsExcelFileName(String reportName, Timestamp timeStamp) {
        DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
        String newTimeStamp = dateFormat.format(timeStamp).replace(":", "").replace("-", "").replace(" ", "");
        String newReportName = reportName.replace(" ", "_");

        return new StringBuilder(newReportName).append("_").append(newTimeStamp).append(Constants.DOT_XLSX).toString();
    }

}
