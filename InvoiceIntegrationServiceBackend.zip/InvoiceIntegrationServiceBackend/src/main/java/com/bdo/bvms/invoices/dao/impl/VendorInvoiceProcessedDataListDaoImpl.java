package com.bdo.bvms.invoices.dao.impl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceProcessedDataListDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceSyncDataListDao;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.ProcessedListDataResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.invoices.util.CommonUtils;
import com.bdo.bvms.invoices.util.NumberUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class VendorInvoiceProcessedDataListDaoImpl.
 */
@Repository

/** The Constant log. */
@Slf4j
public class VendorInvoiceProcessedDataListDaoImpl implements VendorInvoiceProcessedDataListDao {

    /** The vendor invoice sync data list dao. */
    @Autowired
    VendorInvoiceSyncDataListDao vendorInvoiceSyncDataListDao;

    /** The common dao. */

    @Autowired
    CommonDao commonDao;

    /** The jdbc template trn. */
    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    /**
     * Gets the processed invoice data list.
     *
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @param gstinNewList
     *            the gstin new list
     * @param monthList
     *            the month list
     * @return the processed invoice data list
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    public List<ProcessedListDataResDTO> getProcessedInvoiceDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {
        try {
            Map<String, String> screenAliasMap = commonDao.getSchreeAliasMap(vendorInvoiceRequestDTO);
            String whereCondition = CommonUtils.getWhereCondition(vendorInvoiceRequestDTO.getAdvanceFilter(),
                            screenAliasMap);
            Map<String, Object> out = commonDao.getGridDataProcessedInvoice(vendorInvoiceRequestDTO, gstinNewList,
                            monthList, whereCondition);
            List<ProcessedListDataResDTO> dataResList = new ArrayList<>();
            Integer totalCount = ((List<Map<String, Integer>>) out.get("#result-set-" + 2)).get(0).get("total_count");
            List<Map<String, Object>> results = (List<Map<String, Object>>) out.get("#result-set-" + 1);
            if (totalCount == null || totalCount == 0) {
                return dataResList;
            }
            results.forEach(u -> {
                ProcessedListDataResDTO dataRes = new ProcessedListDataResDTO();
                dataRes.setId(Integer.valueOf(u.get("id").toString()));
                dataRes.setTaxpayerPan(checkNullValue((String) u.get("taxpayer_pan")));
                dataRes.setTaxpayerGstin(checkNullValue((String) u.get("taxpayer_gstin")));
                dataRes.setVendorPan(checkNullValue((String) u.get("vendor_pan")));
                dataRes.setVendorGstin(checkNullValue((String) u.get("vendor_gstin")));
                dataRes.setVendorLegalName(checkNullValue((String) u.get("vendor_legal_name")));
                dataRes.setVendorTradeName(checkNullValue((String) u.get("vendor_trade_name")));
                dataRes.setInvoiceNo(checkNullValue((String) u.get("invoice_no")));
                dataRes.setInvoiceDate(checkNullValue((String) u.get("invoice_date")));
                dataRes.setSyncWithGstr2a((String) u.get("sync_with_gstr2a"));
                dataRes.setSyncWithGstr2b((String) u.get("sync_with_gstr2b"));
                dataRes.setSyncWithEwayBill((String) u.get("sync_with_eway_bill"));
                dataRes.setTaxableValue(checkNullValue(String.valueOf(u.get("taxable_value"))));
                dataRes.setIgst(checkNullValue(String.valueOf(u.get("igst"))));
                dataRes.setSgst(checkNullValue(String.valueOf(u.get("sgst"))));
                dataRes.setCgst(checkNullValue(String.valueOf(u.get("cgst"))));
                dataRes.setCess(checkNullValue(String.valueOf(u.get("cess"))));
                dataRes.setInvoiceValue(checkNullValue(String.valueOf(u.get("invoice_value"))));
                dataRes.setQrCodeValid(String.valueOf(u.get("qr_code_valid")));
                dataRes.setEwayBillNo(checkNullValue((String) u.get("eway_bill_no")));
                dataRes.setEwayBillDate(checkNullValue((String) u.get("eway_bill_date")));
                dataRes.setPoNumber(checkNullValue((String) u.get("po_number")));
                dataRes.setGrnNumber(checkNullValue((String) u.get("grn_no")));
                dataRes.setUploadDate((LocalDateTime) u.get("details_upload_date"));
                dataRes.setLastSyncDate((LocalDateTime) u.get("last_synced_date"));
                dataRes.setSyncStatus((u.get("sync_status")).toString().equals("1")?Boolean.TRUE:Boolean.FALSE);
                dataRes.setBookedErp(checkNullValue((String) u.get("booked_erp")));
                dataRes.setGetType(checkNullValue((String) u.get("get_type")));
                dataRes.setBatchNo(checkNullValue((String) u.get("batch_no")));
                dataRes.setFileType(checkNullValue((String) u.get("file_type")));
                dataRes.setTotalCount(totalCount);
                dataRes.setPrimarySync(checkNullValue(String.valueOf (u.get("configured_get_type_on_inv_sync"))));
                dataRes.setPrimarySyncOn((LocalDateTime) (u.get("first_sync_on")));
                dataRes.setDocType(checkNullValue((String) u.get("doc_type")));
                dataRes.setSupplyType(checkNullValue((String) u.get("category")));
                dataRes.setForceSync(checkNullValue(String.valueOf(u.get("is_forced_sync"))));
                //dataRes.setTotalPOCount((Integer) (u.get("purchase_order_count")));
                dataRes.setIrnVerified(checkNullValue((String) u.get("status")));
                dataRes.setVendorCodeErp(checkNullValue((String) u.get("vendor_code_erp")));
                dataResList.add(dataRes);
            });

            return dataResList;
        } catch (DataAccessException e) {
            log.info("Error occurs at the time of fetching data from database in Processed invoice tab.", e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATIONGRIDDATA);
            exceptionLogDTO.setFunctionName("getProcessedInvoiceDataList");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming
            // in this function to getting data from database.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException(
                            "Error coming at the time of getting data from database in Processed invoice tab.",
                            e.getCause());

        }
    }

    /**
     * Check null value.
     *
     * @param value
     *            the value
     * @return the string
     */
    private static String checkNullValue(String value) {
        if (StringUtils.isEmpty(value)) {
            return "-";
        } 
        else if("null".equalsIgnoreCase(value))
        {
        	return "-";
        }
        else {
            return value;
        }
    }

    private static String checkNullValue(Integer value) {
        if (value == null || value == 0) {
            return "No";
        } else if (value == 1) {
            return "Yes";
        } else {
            return "No";
        }
    }

}
