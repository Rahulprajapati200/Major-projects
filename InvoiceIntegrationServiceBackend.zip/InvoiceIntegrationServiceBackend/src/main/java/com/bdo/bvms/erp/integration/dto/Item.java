package com.bdo.bvms.erp.integration.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Item {

    Object slNo;
    String prdDesc;
    String isServc;
    String hsnCd;
    BchDtls bchDtls;

    String barcde;
    Object qty;
    Object freeQty;
    String unit;
    Object unitPrice;
    Object totAmt;
    Long discount;
    Object preTaxVal;
    Object assAmt;
    Object igstRt;
    Object igstAmt;
    Object cgstRt;
    Object cgstAmt;
    Object sgstRt;
    Object sgstAmt;
    Object cesRt;
    Object cesAmt;
    Long cesNonAdvlAmt;
    Long stateCesRt;
    Long stateCesAmt;
    Long stateCesNonAdvlAmt;
    Long othChrg;
    Object totItemVal;
    String ordLineRef;
    String orgCntry;
    String prdSlNo;
    List<AttribDtls> attribDtls = new ArrayList<AttribDtls>();

}
