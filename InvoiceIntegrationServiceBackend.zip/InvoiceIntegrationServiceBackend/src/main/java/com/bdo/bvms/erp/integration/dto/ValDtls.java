package com.bdo.bvms.erp.integration.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ValDtls {

    private Object assVal;
    private Object cgstVal;
    private Object sgstVal;
    private Object igstVal;
    private Object cesVal;
    private Long stCesVal;
    private Long discount;
    private Long othChrg;
    private Long rndOffAmt;
    private Object totInvVal;
    private Long totInvValFc;
}
