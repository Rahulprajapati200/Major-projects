package com.bdo.bvms.einvoice.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.CustomColumnService;
import com.bdo.bvms.invoices.constant.VendorInvoiceConstants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceSyncDataListDao;
import com.bdo.bvms.invoices.dto.InvoiceGridCustomColumnDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.invoices.taxpayer.sql.TransactionSQL;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class CustomColumnServiceImpl implements CustomColumnService {

    @Autowired
    VendorInvoiceSyncDataListDao vendorInvoiceSyncDataListDao;

    @Autowired
    CommonDao commonDao;

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Override
    public List<InvoiceGridCustomColumnDTO> getCustomGridColumns(VendorInvoiceRequestDTO vendorInvoiceRequestDTO)
                    throws VendorInvoiceServerException {
        Map<String, String> columnDtoMap = new HashMap<>();
        columnDtoMap.put("id", "id");
        columnDtoMap.put("taxpayer_gstin", "taxpayerGstin");
        columnDtoMap.put("customer_gstin", "taxpayerGstin");
        columnDtoMap.put("taxpayer_pan", "taxpayerPan");
        columnDtoMap.put("vendor_gstin", "vendorGstin");
        columnDtoMap.put("vendor_pan", "vendorPan");
        columnDtoMap.put("taxpayer_name", "taxpayerName");
        columnDtoMap.put("vendor_name", "vendorName");
        columnDtoMap.put("company_legal_name", "vendorLegalName");
        columnDtoMap.put("company_trade_name", "vendorTradeName");
        
        columnDtoMap.put("invoice_no", "invoiceNo");
        columnDtoMap.put("invoice_date", "invoiceDate");
        columnDtoMap.put("sync_with_gstr2a", "syncWithGstr2a");
        columnDtoMap.put("sync_with_gstr2b", "syncWithGstr2b");
        columnDtoMap.put("sync_with_eway_bill", "syncWithEwayBill");
        columnDtoMap.put("taxable_value", "taxableValue");
        columnDtoMap.put("taxable_amount", "taxableAmount");
        columnDtoMap.put("igst", "igst");
        columnDtoMap.put("cgst", "cgst");
        columnDtoMap.put("sgst", "sgst");
        columnDtoMap.put("cess", "cess");
        columnDtoMap.put("igst_amt", "igst");
        columnDtoMap.put("cgst_amt", "cgst");
        columnDtoMap.put("sgst_amt", "sgst");
        columnDtoMap.put("cess_amt", "cess");
        columnDtoMap.put("invoice_value", "invoiceValue");
        columnDtoMap.put("total_inv_amount", "invoiceValue");
        columnDtoMap.put("qr_code_valid", "qrCodeValid");
        columnDtoMap.put("eway_bill_no", "ewayBillNo");
        columnDtoMap.put("eway_bill_date", "ewayBillDate");
        columnDtoMap.put("purchase_order_no", "poNumber");
        columnDtoMap.put("grn_no", "grnNumber");
        columnDtoMap.put("sync_status", "syncStatus");
        columnDtoMap.put("created_on", "uploadDate");
        columnDtoMap.put("last_synced_on", "lastSyncDate");
        columnDtoMap.put("booked_in_erp", "bookedErp");
        columnDtoMap.put("pld_get_type", "getType");
        columnDtoMap.put("batch_no", "batchNo");
        columnDtoMap.put("po_number", "poNumber");
        columnDtoMap.put("irn_no", "irnNo");
        columnDtoMap.put("irn_date", "irnDate");
        columnDtoMap.put("po_date", "poDate");
        columnDtoMap.put("document_type", "invoiceType");
        columnDtoMap.put("data_type", "dataType");
        columnDtoMap.put("doc_type", "docType");
        columnDtoMap.put("category", "supplyType");
        columnDtoMap.put("uploaded_by", "uploadedBy");
        columnDtoMap.put("uploadedBy", "uploadedBy");
        columnDtoMap.put("uploaded_on", "uploadedOn");
        columnDtoMap.put("responded_on", "rejectedDate");
        columnDtoMap.put("action_by", "rejectedBy");
        columnDtoMap.put("file_id", "fileId");
        columnDtoMap.put("total_count", "totalCount");
        columnDtoMap.put("file_type", "fileType");
        //columnDtoMap.put("purchase_order_count", "totalPOCount");
        columnDtoMap.put("inv_detail_first_sync_id", "primarySync");
        columnDtoMap.put("first_sync_on", "primarySyncOn");
        columnDtoMap.put("status", "irnVerified");
        columnDtoMap.put("is_forced_sync", "forceSync");
        columnDtoMap.put("ocr_extration_error", "extraction");
        columnDtoMap.put("compliance_extration_error", "compliance");
        columnDtoMap.put("file_name", "fileName");
        columnDtoMap.put("vendor_code_erp", "vendorCodeErp");
        
        
        int count = jdbcTemplateTrn.queryForObject(TransactionSQL.getColumnCountForUser(mstDatabseName), Integer.class,
                        vendorInvoiceRequestDTO.getTabId(), vendorInvoiceRequestDTO.getUserId());

        StringBuilder sql = TransactionSQL.getCustomizedColumnNames(mstDatabseName, count, vendorInvoiceRequestDTO.getUserId(),
                        vendorInvoiceRequestDTO.getTabId());
        if(VendorInvoiceConstants.OCR_TAB.equals(vendorInvoiceRequestDTO.getTabId())) {
        	if("1".equals(vendorInvoiceRequestDTO.getOcrSubTab())) {
        	   sql.append(" AND grid.tab_name = 'OCR_IN_PROGRESS' ");
        	}
        	else if("2".equals(vendorInvoiceRequestDTO.getOcrSubTab())) {
         	   sql.append(" AND grid.tab_name = 'OCR_REVIEW' ");
         	}
        	else {
        		sql.append(" AND grid.tab_name = 'OCR' ");
        	}
         }
		    if(count > 0) {
		    	sql.append(" order by cm.sort_order");
		    }
		    else {
		        sql.append(" order by grid.sort_order");
		    }
        return jdbcTemplateTrn.query(sql.toString(), new RowMapper<InvoiceGridCustomColumnDTO>() {

            public InvoiceGridCustomColumnDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
                InvoiceGridCustomColumnDTO col = new InvoiceGridCustomColumnDTO();
                col.setKey(rs.getString("column_screen_name"));
                col.setName(rs.getString("table_column_name"));
                col.setField(columnDtoMap.get(rs.getString("table_column_name")));
                col.setColumnWidth(rs.getInt("column_width"));
                col.setAlias(rs.getString("advance_search_column_name"));
                return col;
            }
        });

    }

}
