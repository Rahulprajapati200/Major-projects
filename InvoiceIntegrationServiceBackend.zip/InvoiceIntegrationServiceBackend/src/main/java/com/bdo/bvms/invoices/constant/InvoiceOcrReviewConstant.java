package com.bdo.bvms.invoices.constant;

public final class InvoiceOcrReviewConstant {

    InvoiceOcrReviewConstant() {

    }
    
    public static final String ACCESS_CONTROL_EXPOSE_HEADERS = "Access-Control-Expose-Headers";

    public static final String HEADERS_FILENAME = "fileName";

    public static final String SYSTEM_PARAMETER_AZURE_BASE_URL = "Azure_storage_base_url";

    public static final String SYSTEM_PARAMETER_CONTAINER_NAME = "container name";
    
    public static final String OCR_TAB_NAME = "ocr_tab_name";
    
    public static final String PLD_OCR_DATA_TYPE = "OCR_data_type";


    public static final String OCR_INV_HEADER_TABLE_NAME = "ocr_header";
    
    public static final String OCR_INV_DETAILS_TABLE_NAME = "ocr_invoice_details";
    
    
    public static final String VERTICAL_MAP_ID = "vertical_map_id";
    public static final String UPDATED_VALUE = "updated_value";
    
    public static final String PLD_OCR_STATUS_REJECTED = "303";
    public static final String PLD_OCR_STATUS_ON_HOLD = "302";
    public static final String PLD_OCR_STATUS_ACCEPT = "313";
    public static final String PLD_OCR_STATUS_ACCEPT_AND_MOVE_PROCESSED_INVOICE = "311";
    public static final String PLD_OCR_STATUS_ACCEPT_AND_MOVE_SYNC_PENDING = "312";
    public static final String PLD_OCR_STATUS_ACCEPT_AND_MOVE_URP = "313";
    
    public static final String PLD_OCR_STATUS_COMPLETED = "250";
    public static final String PLD_OCR_STATUS_VERIFIED = "252";
    
    public static final int PLD_OCR_TAB_CODE_LINE_ITEM = 295;
    
    public static final int PLD_OCR_TAB_CODE_GENERAL = 271;
    public static final String PLD_OCR_TAB_NAME_GENERAL = "General";
    public static final int PLD_OCR_TAB_CODE_SUPPLIER_DETAIL = 272;
    public static final int PLD_OCR_TAB_CODE_COMPANY_DETAIL = 273;
    
    public static final String TAXPAYER_JOURNEY = "TP";
    
    public static final String VENDOR_JOURNEY = "VJ";
    
    public static final int OCR_FIELD_MST_ID_PONO = 2;
    public static final int OCR_FIELD_MST_ID_TAXPAYER_GSTIN= 178;
    public static final int OCR_FIELD_MST_ID_VENDOR_GSTIN= 168;
    public static final int OCR_FIELD_MST_ID_VENDOR_PAN= 25;
    public static final int OCR_FIELD_MST_ID_VENDOR_CODE= 18;
    
    
    
}

