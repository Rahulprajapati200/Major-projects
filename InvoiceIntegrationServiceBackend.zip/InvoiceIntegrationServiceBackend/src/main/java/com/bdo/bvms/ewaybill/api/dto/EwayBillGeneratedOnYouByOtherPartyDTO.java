package com.bdo.bvms.ewaybill.api.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EwayBillGeneratedOnYouByOtherPartyDTO {
	
	String ewbNo;
	String ewayBillDate;
	String genMode;
	String genGstin;
	String docNo;
	String docDate;
	String fromGstin;
	String fromTradeName;
	String toGstin;
	String toTradeName;
	String totInvValue;
	String hsnCode;
	String hsnDesc;
	String status;
	String rejectStatus;

}
