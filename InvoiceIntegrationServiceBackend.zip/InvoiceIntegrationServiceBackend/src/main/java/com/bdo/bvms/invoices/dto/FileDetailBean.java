package com.bdo.bvms.invoices.dto;

import java.util.Date;

public class FileDetailBean {

    private String pan;
    private String gstin;
    private String financialPeriod;
    private String poDetails;
    private String fileType;
    private String fileName;
    private String filePath;
    private String batchNo;
    private boolean status;
    private int uploadedBy;
    private Date uploadedOn;

   

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getGstin() {
        return gstin;
    }

    public void setGstin(String gstin) {
        this.gstin = gstin;
    }

    public String getFinancialPeriod() {
        return financialPeriod;
    }

    public void setFinancialPeriod(String financialPeriod) {
        this.financialPeriod = financialPeriod;
    }

    public String getPoDetails() {
        return poDetails;
    }

    public void setPoDetails(String poDetails) {
        this.poDetails = poDetails;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getUploadedBy() {
        return uploadedBy;
    }

    public void setUploadedBy(int uploadedBy) {
        this.uploadedBy = uploadedBy;
    }

    public Date getUploadedOn() {
        return uploadedOn;
    }

    public void setUploadedOn(Date uploadedOn) {
        this.uploadedOn = uploadedOn;
    }

    @Override
    public String toString() {
        return "FileDetailBean [pan=" + pan + ", gstin=" + gstin + ", financialPeriod=" + financialPeriod
                        + ", poDetails=" + poDetails + ", fileType=" + fileType + ", fileName=" + fileName
                        + ", filePath=" + filePath + ", batchNo=" + batchNo + ", status=" + status + ", uploadedBy="
                        + uploadedBy + ", uploadedOn=" + uploadedOn + "]";
    }

}
