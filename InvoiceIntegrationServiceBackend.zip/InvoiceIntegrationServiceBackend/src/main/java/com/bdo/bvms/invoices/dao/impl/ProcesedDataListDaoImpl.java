package com.bdo.bvms.invoices.dao.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.ProcesedDataListDao;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.ProcessedListDataResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class ProcesedDataListDaoImpl implements ProcesedDataListDao {

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Autowired
    CommonDao commonDao;

    @Value("${mst.database-name}")
    String mstDatabseName;

    String gstinList;

    @Override
    public Page<ProcessedListDataResDTO> processedDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO)
                    throws VendorInvoiceServerException {

        if (Constants.PAN.equals(vendorInvoiceRequestDTO.getGstinOrPan())) {

            // here we get all GSTIN into a string array according to single pan
            // from database.
            String[] gstinArray = commonDao.getGstinFromDB(vendorInvoiceRequestDTO.getGstinOrPanList().get(0),
                            mstDatabseName);
            // here we convert GSTIN string array into the string.
            gstinList = Arrays.toString(gstinArray);

        } else if (Constants.GSTIN.equals(vendorInvoiceRequestDTO.getGstinOrPan())) {
            // here we get GSTIN list from request body and convert it into
            // string
            gstinList = vendorInvoiceRequestDTO.getGstinOrPanList().toString();
        }

        List<ProcessedListDataResDTO> processedInvoiceDataList = new ArrayList<>();
        try {

        } catch (DataAccessException e) {
            log.info("Error coming at the time of getting data from database in Processed invoice", e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
            exceptionLogDTO.setFunctionName("processedDataList");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming
            // in this function to getting data from database.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException(
                            "Error coming at the time of getting data from database in Processed invoice",
                            e.getCause());

        }
        if (!processedInvoiceDataList.isEmpty()) {

            return new PageImpl<>(processedInvoiceDataList);
        } else {

            return null;
        }
    }

}
