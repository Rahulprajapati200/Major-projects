package com.bdo.bvms.ewaybill.api.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.bdo.bvms.invoices.constant.EWBErrorCodesConstants;
import com.bdo.bvms.invoices.dto.EWBGenByDateDTO;
import com.bdo.bvms.invoices.dto.EWBGenByDateResponseDTO;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EwayBillGeneratedByDate {

    public EWBGenByDateResponseDTO ewayBillGeneratedByDate(String appKey, String taxPayerGSTN, String clientId,
                    String clientSecretenCrypted, String eWayBillApi, RestTemplate restTemplate,
                    String bdoASPAuthenticatedInfo, String authtoken, String sek) {

        EWBGenByDateResponseDTO resDto = new EWBGenByDateResponseDTO();
        List<EWBGenByDateDTO> data = null;
        HttpHeaders eWayBillAuthHeader = new HttpHeaders();

        eWayBillAuthHeader.set("ClientId", clientId);
        eWayBillAuthHeader.set("client-secret", clientSecretenCrypted);
        eWayBillAuthHeader.set("bdo_auth_token", bdoASPAuthenticatedInfo);
        eWayBillAuthHeader.set("Gstin", taxPayerGSTN);
        eWayBillAuthHeader.set("authtoken", authtoken);

        HttpEntity<Void> requestEntity = new HttpEntity<>(eWayBillAuthHeader);

        ResponseEntity<String> responseEntity = restTemplate.exchange(eWayBillApi, HttpMethod.GET, requestEntity,
                        String.class);

        JSONObject response = new JSONObject(responseEntity.getBody());

        if ("0".equals(response.get("status"))) {
            String errorDesc = EWBErrorCodesConstants.getEWBErrroDescription(response.get("error").toString());
            resDto.setError(errorDesc);
            resDto.setApiResponse(response.toString());
            resDto.setEwbGenByDateList(new ArrayList<>());

        } else {
            String finalData = null;
            try {
                String decryptSEK = Encryption.decryptSEK(appKey, sek);
                finalData = Encryption.decryptGetApiResponseData(response.toString(), decryptSEK);
                ObjectMapper mapper = new ObjectMapper();
                data = Arrays.asList(mapper.readValue(finalData, EWBGenByDateDTO[].class));
                resDto.setApiResponse(response.toString());
                resDto.setError(null);
                resDto.setEwbGenByDateList(data);

            } catch (Exception e) {
                log.error("Exception generated::", e);

            }
        }

        return resDto;
    }

}
