package com.bdo.bvms.invoices.util;

import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.bvms.invoices.vendor.dao.CustomTemplateRepo;

public class VendorCommonUtils {

    VendorCommonUtils() {

    }

    /**
     * Gets the error file path.
     *
     * @param uploadDTO
     *            the upload DTO
     * @param tempFolder
     *            the temp folder
     * @return the error file path
     */
    public static String getErrorFilePath(UploadReqDTO uploadDTO, String tempFolder) {
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(Constants.FILESEPERATOR))
                        .append(uploadDTO.getBatchNo() + Constants.ERROR_DOT_CSV);
        return fileName.toString();
    }

    /**
     * Gets the success file path.
     *
     * @param uploadDTO
     *            the upload DTO
     * @param tempFolder
     *            the temp folder
     * @return the success file path
     */
    // System.getProperty(Constants.FILESEPERATOR)
    public static String getSuccessFilePath(UploadReqDTO uploadDTO, String tempFolder) {
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(Constants.FILESEPERATOR))
                        .append(uploadDTO.getBatchNo() + Constants.SUCCESS_DOT_CSV);
        return fileName.toString();
    }

    /**
     * Gets the column name list.
     *
     * @param coumnsDataRow
     *            the coumns data row
     * @return the column name list
     */
    public static List<String> getColumnNameList(Row coumnsDataRow) {

        List<String> headerList = new ArrayList<>();
        int minColIx = coumnsDataRow.getFirstCellNum(); // get the first column
        // index for a row
        int maxColIx = coumnsDataRow.getLastCellNum(); // get the last column
        // index for a row
        Cell cell;
        for (int colIx = minColIx; colIx < maxColIx; colIx++) { // loop from
            // first to last
            // index
            cell = coumnsDataRow.getCell(colIx); // get the cell

            if (cell.getCellType() == CellType.NUMERIC) {
                headerList.add(String.valueOf(cell.getNumericCellValue()));
            } else {
                headerList.add(cell.getStringCellValue());
            }

        }
        return headerList;
    }

    /**
     * Gets the batch no.
     *
     * @param uploadRequestDTO
     *            the upload request DTO
     * @return the batch no
     */
    public static String getBatchNo(UploadRequestDTO uploadRequestDTO) {

        StringBuilder batchNo = new StringBuilder();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(Constants.DD_MM);

        String currentDate = simpleDateFormat.format(new Date());

        Long currentTimestamp = new Timestamp(System.currentTimeMillis()).getTime();

        batchNo.append(uploadRequestDTO.getTemplatetypepldCode() + Constants.UNDERSCORE + uploadRequestDTO.getUserId()
                        + Constants.UNDERSCORE + uploadRequestDTO.getEntityId() + Constants.UNDERSCORE + currentDate
                        + Constants.UNDERSCORE + currentTimestamp + Constants.UNDERSCORE
                        + generateRandonAlphabeticString(Constants.RANDOMNUM));

        return batchNo.toString();

    }

    /**
     * Gets the custom template header mappings.
     *
     * @param uploadDTO
     *            the upload DTO
     * @param customTemplateRepo
     *            the custom template repo
     * @return the custom template header mappings
     */
    public static Map<String, String> getCustomTemplateHeaderMappings(UploadReqDTO uploadDTO,
                    CustomTemplateRepo customTemplateRepo) {
        if (uploadDTO.getIsCustomTemplate().equals(Constants.ISCUSTOMETEMPLATE)) {
            // HardCoding
            return getCustomTemplateHeaderMappings(Integer.parseInt(uploadDTO.getCustomTemplateId()),
                            customTemplateRepo);
        }
        return Collections.emptyMap();
    }

    public static Map<String, String> getVendorCustomTemplateHeaderMappings(UploadReqDTO uploadDTO,
                    CustomTemplateRepo customTemplateRepo) {
        if (uploadDTO.getIsCustomTemplate().equals(Constants.ISCUSTOMETEMPLATE)) {
            // HardCoding
            return getCustomTemplateHeaderMappings(Integer.parseInt(uploadDTO.getCustomTemplateId()),
                            customTemplateRepo);
        }
        return Collections.emptyMap();
    }

    /**
     * Gets the custom template header mappings.
     *
     * @param customTemplateId
     *            the custom template id
     * @param customTemplateRepo
     *            the custom template repo
     * @return the custom template header mappings
     */
    private static Map<String, String> getCustomTemplateHeaderMappings(int customTemplateId,
                    CustomTemplateRepo customTemplateRepo) {

        return customTemplateRepo.searchCustomTemplateHeaderMappings(customTemplateId);
    }

    /**
     * Generate randon alphabetic string.
     *
     * @param length
     *            the length
     * @return the string
     */
    public static String generateRandonAlphabeticString(int length) {

        if (length < 6) {
            length = 6;
        }

        final char[] allAllowed = "abcdefghijklmnopqrstuvwxyzABCDEFGJKLMNPRSTUVWXYZ0123456789".toCharArray();

        SecureRandom random = new SecureRandom();

        StringBuilder password = new StringBuilder();

        for (int i = 0; i < length; i++) {
            password.append(allAllowed[random.nextInt(allAllowed.length)]);
        }

        return password.toString();

    }

}
