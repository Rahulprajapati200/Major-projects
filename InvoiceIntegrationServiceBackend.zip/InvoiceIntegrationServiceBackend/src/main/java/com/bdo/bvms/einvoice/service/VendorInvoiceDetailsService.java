package com.bdo.bvms.einvoice.service;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import javax.validation.Valid;

import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.EWBViewDTO;
import com.bdo.bvms.invoices.dto.GetEwayBillDetailsRequestDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsReqDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsResponseDto;
import com.bdo.bvms.invoices.dto.VendorInvoiceGETRequestDTO;
import com.bdo.bvms.invoices.dto.WfApproveOrRejectDTO;
import com.bdo.bvms.ocr.dto.OcrBatchResponseReqDto;

public interface VendorInvoiceDetailsService {

    InvoiceDetailsResponseDto getInvoiceDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO)
                    throws VendorInvoiceServerException;

    Object getInvoiceLineItemViewDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO) throws VendorInvoiceServerException;

    File getDownloadInvoiceDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO)
                    throws VendorInvoiceServerException, IOException;

    Map<String, Object> getForceSyncList(InvoiceDetailsReqDTO invoiceDetailsReqDTO) throws VendorInvoiceServerException;

    Object getGetEwayBillViewDetails(GetEwayBillDetailsRequestDTO getEwayBillDetailsRequestDTO)
                    throws InvoiceIntegrationEWBException;

    Object getGetExistingEWBDetails(VendorInvoiceGETRequestDTO vendorInvoiceGETRequestDTO)
                    throws InvoiceIntegrationEWBException;

    Object getEwaybillView(EWBViewDTO ewbViewDTO) throws InvoiceIntegrationEWBException;

    String sendWfApproveOrReject(@Valid WfApproveOrRejectDTO wfApproveOrRejectDTO);


    /**
     * Async call for get ewaybill data from govt ewb api
     *
     * @param vendorInvoiceGETRequestDTO
     *            the vendor invoice GET request DTO
     * @throws InvoiceIntegrationEWBException
     *             the invoice integration EWB exception
     */
    String callForGetEwaybillDetailsByDate(GetEwayBillReqDTO reqDto);

    String callForGetEwaybillDetailsOtherParty(GetEwayBillReqDTO reqDto);

    String callForGetEwaybillDetails(GetEwayBillReqDTO reqDto) throws InvoiceIntegrationEWBException;
}
