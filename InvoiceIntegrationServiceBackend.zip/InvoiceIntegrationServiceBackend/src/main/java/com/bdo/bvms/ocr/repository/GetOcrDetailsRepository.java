package com.bdo.bvms.ocr.repository;

import java.util.List;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.ocr.dto.OcrResponseDto;

public interface GetOcrDetailsRepository {


	List<OcrResponseDto> getOcrDetails(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
			String monthList) throws VendorInvoiceServerException;


}
