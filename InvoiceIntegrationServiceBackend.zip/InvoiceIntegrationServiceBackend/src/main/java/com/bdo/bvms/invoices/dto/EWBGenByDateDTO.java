package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EWBGenByDateDTO {

    String ewbNo;
    String ewbDate;
    String status;
    String genGstin;
    String docNo;
    String docDate;
    String delPinCode;
    String delStateCode;
    String delPlace;
    String validUpto;
    String extendedTimes;
    String rejectStatus;

}
