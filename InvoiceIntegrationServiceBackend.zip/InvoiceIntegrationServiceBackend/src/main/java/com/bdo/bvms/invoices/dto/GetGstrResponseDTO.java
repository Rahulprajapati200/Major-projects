package com.bdo.bvms.invoices.dto;

import org.springframework.data.relational.core.mapping.Column;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class GetGstrResponseDTO {

    String taxpayerGstin;

    String vendorGstin;

    String title;

    Long taxableValue;

    String placeSupply;

    long igst;

    long cgst;

    long sgst;

    long cess;

    long invoiceValue;

    String invoiceNo;

    String invoiceDate;

    boolean syncStatus;

    @Column(value = "defaultSyncStatus")
    boolean defaultSyncStatus;

    @Column(value = "forcesyncstatus")
    boolean forceSyncStatus;
}
