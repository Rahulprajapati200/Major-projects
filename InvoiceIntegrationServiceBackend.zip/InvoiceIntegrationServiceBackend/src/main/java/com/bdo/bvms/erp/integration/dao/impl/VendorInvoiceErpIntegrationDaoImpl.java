package com.bdo.bvms.erp.integration.dao.impl;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.erp.integration.dao.VendorInvoiceErpIntegrationDao;
import com.bdo.bvms.ewaybill.api.sql.Transactions;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class VendorInvoiceErpIntegrationDaoImpl implements  VendorInvoiceErpIntegrationDao{
	
	@Autowired
    JdbcTemplate jdbcTemplateTrn;
	
	@Autowired
	JdbcTemplate jdbcTemplateMst;

    CallableStatement cs = null;
	
	
	@Override
    public Map<String, Object> getErpInvoiceDataParentProcCall(String ackNo) throws SQLException {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));
        Map<String, Object> results = new HashMap<>();
        try {
            results = jdbcTemplateTrn.call(new CallableStatementCreator() {

                @Override
                public CallableStatement createCallableStatement(Connection con) throws SQLException {
                    try {
                        cs = con.prepareCall("{CALL erp_invoice_extact_pdf_ocrdata_output(?)}");
                        cs.setString(1, ackNo);
                        return cs;
                    } catch (SQLException e) {
                        if (cs != null) {
                            cs.close();
                        }
                        throw e;
                    }
                }
            }, parameters);

        } finally {
            if (cs != null) {
                cs.close();
            }
        }

        return results;
    }
	
	
	@Override
    public int insertErpCommunicationLog(String requestJson, String apiName)
                    throws IOException {
        String sql = "INSERT INTO erp_communication_log (request_json_from_erp, api_name, requested_at)VALUES (?,?,now())";
        JSONObject jsonData = new JSONObject(requestJson);

        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1, jsonData.toString());
            ps.setString(2, apiName);
            return ps;
        }, keyHolder);

        if (keyHolder.getKey() == null) {
            return 0;
        } else {
            Number key = keyHolder.getKey();
            return key == null ? 0 : key.intValue();
        }

    }
    
    
    @Override
    public void updateErpCommunicationLog(JSONArray responseJson,int id) throws IOException {
        String sql = "update erp_communication_log set response_json_from_vca =?,response_at=now() where id=?";

        jdbcTemplateTrn.update(sql,responseJson.toString(),id );

    }
    
	
	@Override
	public String getErpDbDetails() {
		String query="select KeyVALUE from system_parameter where KeyNAME= 'erp-app-key' limit 1";
		return jdbcTemplateMst.queryForObject(query,String.class);
	}

	@Override
	public String getErpSecretDetail() {
		String query="select KeyVALUE from system_parameter where KeyNAME= 'client-erp-secret' limit 1";
		return jdbcTemplateMst.queryForObject(query,String.class);
	}
	

    @Override
    public Long insertIntoErpRequestLog(String reqJson,String reqFor) {

        // Create a KeyHolder to retrieve generated keys
        KeyHolder keyHolder = new GeneratedKeyHolder();
        String sql = "INSERT INTO erp_request_log ( requested_json, requested_on,req_for)VALUES (?,now(),?)";

        jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(sql,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, reqJson);
            ps.setString(2, reqFor);
            return ps;
        }, keyHolder);

        // Retrieve the generated keys (if any)
        Number key = null;
        try {
            key = keyHolder.getKey();
        } catch (InvalidDataAccessApiUsageException e) {
            log.error("Error in getting generated key. ", e);
        }

        // Retrieve the generated keys (if any)
        if (key != null) {

            return key.longValue();
        }
        return null;

    }
    
    @Override
    public void updateErpRequestLog(String payloadJson, String batchNo, Long key) {

    	String sql = "update erp_request_log set payload =?,batch_no=? where id=?";
        jdbcTemplateTrn.update(sql, payloadJson, batchNo, key);

    }


}
