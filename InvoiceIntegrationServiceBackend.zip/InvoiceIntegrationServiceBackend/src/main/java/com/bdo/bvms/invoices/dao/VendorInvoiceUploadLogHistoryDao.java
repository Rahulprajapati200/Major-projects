package com.bdo.bvms.invoices.dao;

import org.springframework.data.domain.Page;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.invoices.dto.UploadLogDto;

public interface VendorInvoiceUploadLogHistoryDao {

    Page<UploadLogDto> getHistoryList(UploadHistoryRequestDTO uploadHistoryRequestDTO)
                    throws VendorInvoiceServerException;

    void writeInvoiceDetailsToInvoiceHeader() throws VendorInvoiceServerException;

}
