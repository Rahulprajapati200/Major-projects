package com.bdo.bvms.ewaybill.api.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class NicAuthResponseDTO {

    int id;
    String nicAuthToken;
    String taxpayerGstin;
    int apiId;
    int bdoAuthId;
    String nicSek;
    String inHeader;
    String inData;
    String expiry;
    String isException;
    String errorDescription;

}
