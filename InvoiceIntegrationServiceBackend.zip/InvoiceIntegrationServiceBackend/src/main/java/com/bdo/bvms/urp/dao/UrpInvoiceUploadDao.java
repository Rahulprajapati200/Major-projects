package com.bdo.bvms.urp.dao;

import java.util.List;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;

public interface UrpInvoiceUploadDao {

	void insertToUrpOcrHeader(List<EInvoiceTemplateDTO> data, UploadReqDTO uploadDTO)
			throws VendorInvoiceServerException;

	Integer getYearIdByFp(String fp);

}
