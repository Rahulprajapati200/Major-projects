
package com.bdo.bvms.invoices.constant;

/**
 * The Class StringConstant.
 */
public class StringConstant {

    StringConstant() {

    }

    public static final String PROCESSCOMPLETEDSTATUS = "Completed";
    public static final String FILESEPARATOR = "file.separator";
    public static final String DOTSEPARATOR = ".";
    public static final String HEADERCOUNTERRORMESSAGE = "Invalid Header or Header count is not matching for batch no.";
    public static final String ERRORCAUSE = "Header Mismatch";
    public static final String ROWCOUNT = "RowCount";

    public static final char COMMASEPERATOR = ',';

    public static final String ZERO = "0";
    public static final String ONE = "1";

    public static final String STRINGCOMMASEPERATOR = ",";

}
