package com.bdo.bvms.ocr.service.impl;

import java.sql.BatchUpdateException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bdo.bvms.invoices.constant.InvoiceOcrReviewConstant;
import com.bdo.bvms.invoices.constant.OcrValidationConstants;
import com.bdo.bvms.invoices.constant.VendorInvoiceConstants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.ocr.model.OcrInvoiceHeader;
import com.bdo.bvms.invoices.ocr.model.OcrVerticalMap;
import com.bdo.bvms.invoices.ocr.repository.IInvoiceReviewRepository;
import com.bdo.bvms.ocr.dto.OcrComplianceErrorDto;
import com.bdo.bvms.ocr.dto.OcrTriggerRequestDto;
import com.bdo.bvms.ocr.dto.OcrVerticalDataObj;
import com.bdo.bvms.ocr.repository.FileOcrProcessAndSaveRepository;
import com.bdo.bvms.ocr.service.FileOcrProcessAndSaveService;
import com.bdo.bvms.ocr.service.InvoiceOcrFileUploadService;
import com.bdo.bvms.ocr.validations.OcrValidationCheck;
import com.bdo.bvms.util.StringUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FileOcrProcessAndSaveServiceImpl implements FileOcrProcessAndSaveService{
	public static final  String CLASSNAME = "FileOcrProcessAndSaveServiceImpl";

	@Autowired
	FileOcrProcessAndSaveRepository fileOcrProcessAndSaveRepository;
	
	@Autowired
	IInvoiceReviewRepository iInvoiceReviewRepository;
	
	@Autowired
	InvoiceOcrFileUploadService invoiceOcrFileUploadService;

	@Override
	@Async
	public void saveOCRDataResponseToDb(Map<String, Object> responceDataObject,Integer fileId) throws VendorInvoiceServerException, BatchUpdateException {
		String methodname = "saveOCRDataResponseToDb";
		List<OcrVerticalDataObj> ocrVerticalDataObjList = new ArrayList<>();
		Map<Integer, String> ocrMasterFieldColumnMapping = null;
		OcrValidationCheck ocrValidationCheck = new OcrValidationCheck();
	 try {	
		 log.info("Classname: "+ CLASSNAME +" Methodname: "+ methodname+ " Started");
		LinkedHashMap<String,Integer> ocrHeaderFieldConfigMap = fileOcrProcessAndSaveRepository.getOCRFieldConfigMap(0);
		LinkedHashMap<String,Integer> ocrLineItemFieldConfigMap = fileOcrProcessAndSaveRepository.getOCRFieldConfigMap(1);
		ocrMasterFieldColumnMapping = iInvoiceReviewRepository.getOcrInvoiceReviewMasterFieldColumnMapping();
		ObjectMapper objectMapper = new ObjectMapper();
		List<Map<String, Object>> fileResults = objectMapper.convertValue(responceDataObject.get(VendorInvoiceConstants.FILE_RESULTS), new TypeReference<List<Map<String, Object>>>() {});
		if(fileResults == null || fileResults.isEmpty()) {
			log.error("FileResults is Empty");
			fileOcrProcessAndSaveRepository.updateOcrStatus(fileId, 0, VendorInvoiceConstants.OCR_NOT_STARTED_PLD);
			return ;
			
		}
		for(Map<String, Object> fileRes : fileResults) {

			Map<String, Object> confidenceScore  = objectMapper.convertValue(fileRes.get(VendorInvoiceConstants.FILE_CONFIDENCE_SCORE), new TypeReference<Map<String, Object>>(){});
		   
			//read ocr header data
            readOcrHeaderData(fileRes,ocrHeaderFieldConfigMap,ocrVerticalDataObjList,confidenceScore,fileId,ocrMasterFieldColumnMapping);

            //read ocr line item details
            readOcrLineItemData(fileRes,ocrLineItemFieldConfigMap,ocrVerticalDataObjList,confidenceScore,fileId,ocrMasterFieldColumnMapping);				
			
		}

		OcrVerticalMap ocrVerticalMap = OcrVerticalMap.builder().fileId(fileId).build();
		fileOcrProcessAndSaveRepository.insertVerticalMapArchive(fileId);
		fileOcrProcessAndSaveRepository.deleteVerticalMapDetails(fileId);
		List<OcrComplianceErrorDto> ocrComplianceErrorList =  ocrValidationCheck.validateRules(ocrVerticalDataObjList);
		//delete previous compliance issues
		iInvoiceReviewRepository.deleteComplianceValidations(ocrVerticalMap);
		//insert compliance error
		fileOcrProcessAndSaveRepository.insertIntoComplianceErrorTable(ocrComplianceErrorList);
		
		
		//TODO : remove these when idp provide these columns
        OcrVerticalDataObj newHeader1 = new OcrVerticalDataObj();
        newHeader1.setOcrFieldMstId(182);
        newHeader1.setFileId(fileId);
        newHeader1.setFileName("");		
        newHeader1.setOcrExtractedValue("");
        newHeader1.setOcrConfidenceLevel("0");
        newHeader1.setIsHeader(1);
        newHeader1.setColumnName("rcm_applicable");
		ocrVerticalDataObjList.add(newHeader1);
		
		OcrVerticalDataObj newHeader2 = new OcrVerticalDataObj();
        newHeader2.setOcrFieldMstId(183);
        newHeader2.setFileId(fileId);
        newHeader2.setFileName("");		
        newHeader2.setOcrExtractedValue("");
        newHeader2.setOcrConfidenceLevel("0");
        newHeader2.setIsHeader(1);
        newHeader2.setColumnName("sales_price_total");
		ocrVerticalDataObjList.add(newHeader2);
		
		OcrVerticalDataObj newHeader3 = new OcrVerticalDataObj();
        newHeader3.setOcrFieldMstId(184);
        newHeader3.setFileId(fileId);
        newHeader3.setFileName("");		
        newHeader3.setOcrExtractedValue("");
        newHeader3.setOcrConfidenceLevel("0");
        newHeader3.setIsHeader(1);
        newHeader3.setColumnName("discount_total");
		ocrVerticalDataObjList.add(newHeader3);
		
		OcrVerticalDataObj newHeader4 = new OcrVerticalDataObj();
        newHeader4.setOcrFieldMstId(185);
        newHeader4.setFileId(fileId);
        newHeader4.setFileName("");		
        newHeader4.setOcrExtractedValue("");
        newHeader4.setOcrConfidenceLevel("0");
        newHeader4.setIsHeader(1);
        newHeader4.setColumnName("other_charges_at_invoice_level");
		ocrVerticalDataObjList.add(newHeader4);
		
		OcrVerticalDataObj newHeader5 = new OcrVerticalDataObj();
        newHeader5.setOcrFieldMstId(18);
        newHeader5.setFileId(fileId);
        newHeader5.setFileName("");		
        newHeader5.setOcrExtractedValue("");
        newHeader5.setOcrConfidenceLevel("0");
        newHeader5.setIsHeader(1);
        newHeader5.setColumnName("vendor_code");
		ocrVerticalDataObjList.add(newHeader5);
		
		OcrVerticalDataObj newHeader6 = new OcrVerticalDataObj();
		newHeader6.setOcrFieldMstId(165);
		newHeader6.setFileId(fileId);
		newHeader6.setFileName("");		
		newHeader6.setOcrExtractedValue("");
		newHeader6.setOcrConfidenceLevel("0");
		newHeader6.setIsHeader(1);
		newHeader6.setColumnName("tds");
		ocrVerticalDataObjList.add(newHeader6);
		
		
        OcrVerticalDataObj ocrVerticalDataObj1 = new OcrVerticalDataObj();
		
		ocrVerticalDataObj1.setOcrFieldMstId(181);
		ocrVerticalDataObj1.setFileId(fileId);
		ocrVerticalDataObj1.setFileName("");		
		ocrVerticalDataObj1.setOcrExtractedValue("");
		ocrVerticalDataObj1.setOcrConfidenceLevel("0");
		ocrVerticalDataObj1.setIsHeader(1);
		ocrVerticalDataObj1.setColumnName("sum_of_all_item");
		ocrVerticalDataObjList.add(ocrVerticalDataObj1);
		
		
	    fileOcrProcessAndSaveRepository.saveToOcrVerticalData(ocrVerticalDataObjList); 
	    
	    List<String> headerColumnList =  ocrVerticalDataObjList.stream()
		    		.filter(obj -> obj.getIsHeader() == 1)
		    		.filter(obj -> !obj.getOcrExtractedValue().isEmpty())
		    		.map(OcrVerticalDataObj::getColumnName)
	                .collect(Collectors.toList());
	    List<String> headerValueList = ocrVerticalDataObjList.stream()
		    		.filter(obj -> obj.getIsHeader() == 1)
		    		.filter(obj -> !obj.getOcrExtractedValue().isEmpty())
		    		.map(OcrVerticalDataObj::getOcrExtractedValue)
	                .collect(Collectors.toList());
	    OcrInvoiceHeader headerDetail = iInvoiceReviewRepository.getInvoiceHeaderByFileId(ocrVerticalMap);
	    headerColumnList.add("file_id");
	    headerValueList.add(String.valueOf(fileId));
	    headerColumnList.add("pld_ocr_status");
	    headerValueList.add(VendorInvoiceConstants.PLD_OCR_STATUS_IN_REVIEW);
	    headerColumnList.add("is_taxpayer_uploaded");
	    headerValueList.add(String.valueOf(headerDetail.getIsTaxpayer()));
	    headerColumnList.add("file_name");
	    headerValueList.add(headerDetail.getFileName());
	    headerColumnList.add("batch_no");
	    headerValueList.add(headerDetail.getBatchNo());
	    headerColumnList.add("ul_file_type");
	    headerValueList.add(headerDetail.getFileType());
	    headerColumnList.add("ul_filing_period");
	    headerValueList.add(headerDetail.getFp());
	    headerColumnList.add("taxpayer_gstin");
	    headerValueList.add(headerDetail.getCustomerGstin());
	    String headerColumnName = StringUtil.join(headerColumnList);
	    StringBuilder headerValues = new StringBuilder();
	    for(String value : headerValueList) {
	    	if(StringUtils.isBlank(value)) {
	    		headerValues.append("'',");
	    	}
	    	else {  
	    	   headerValues.append("'").append(value).append("',");
	    	}
        }
	    headerValues.deleteCharAt(headerValues.length() - 1);
	    
	    if(!VendorInvoiceConstants.OCR_STOPPED_PLD.equals(String.valueOf(headerDetail.getPldOcrStatus()))) {
		    fileOcrProcessAndSaveRepository.updateOcrStatus(fileId, 0, VendorInvoiceConstants.PLD_OCR_STATUS_IN_REVIEW);
		    // Archive and delete
		    updateOcrHeaderDetails(ocrVerticalMap,headerColumnName,headerValues.toString());
	    }
	     log.info("Classname: "+ CLASSNAME +" Methodname: "+ methodname+ " Completed");
		
       }
	 
	 catch(Exception e) {
			log.error("Something went wrong",e);
			fileOcrProcessAndSaveRepository.updateOcrStatus(fileId, 0, VendorInvoiceConstants.OCR_NOT_STARTED_PLD);
			throw new VendorInvoiceServerException("Something went wrong",e);
		}
	}
	
	private void readOcrHeaderData(Map<String, Object> fileRes,LinkedHashMap<String,Integer> ocrFieldConfigMap,List<OcrVerticalDataObj> ocrVerticalDataObjList,Map<String, Object> confidenceScore,Integer fileId,Map<Integer, String>  ocrMasterFieldColumnMapping) {

		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> header  = objectMapper.convertValue(fileRes.get(VendorInvoiceConstants.HEADER_ITEM), new TypeReference<Map<String, Object>>(){});
		Map<String, Object> headerConfidenceScore  = objectMapper.convertValue(confidenceScore.get(VendorInvoiceConstants.HEADER_ITEM), new TypeReference<Map<String, Object>>(){});
		for(Entry<String, Object> keyValue : header.entrySet()) {
			String colName = keyValue.getKey();
			if(ocrFieldConfigMap.containsKey(colName)) {
				OcrVerticalDataObj ocrVerticalDataObj = new OcrVerticalDataObj();
				ocrVerticalDataObj.setFileId(fileId);
				ocrVerticalDataObj.setFileName(fileRes.get("FileName").toString());
				ocrVerticalDataObj.setOcrFieldMstId(ocrFieldConfigMap.get(colName));
				ocrVerticalDataObj.setOcrExtractedValue(header.get(colName).toString());
				ocrVerticalDataObj.setOcrConfidenceLevel(headerConfidenceScore.get(colName).toString());
				ocrVerticalDataObj.setIsHeader(1);
				ocrVerticalDataObj.setColumnName(ocrMasterFieldColumnMapping.get(ocrFieldConfigMap.get(colName)));
				
				//check place of supply field 
				if(VendorInvoiceConstants.OCR_MST_ID_POS.equals(ocrVerticalDataObj.getOcrFieldMstId()) 
						&& ocrVerticalDataObj.getOcrExtractedValue().length() > 2) {
					ocrVerticalDataObj.setOcrExtractedValue(fileOcrProcessAndSaveRepository.getStateCodeByStateName(ocrVerticalDataObj.getOcrExtractedValue()));
				}
				ocrVerticalDataObjList.add(ocrVerticalDataObj);
			}				
		}
		}
		
	
     private void readOcrLineItemData(Map<String, Object> fileRes,LinkedHashMap<String,Integer> ocrFieldConfigMap,List<OcrVerticalDataObj> ocrVerticalDataObjList,Map<String, Object> confidenceScore,Integer fileId,Map<Integer, String>  ocrMasterFieldColumnMapping) {

    		 Integer lineNo = 0;
	    	 ObjectMapper objectMapper = new ObjectMapper();
	    	 Map<String, Map<String, Object>> itemList = objectMapper.convertValue(fileRes.get(VendorInvoiceConstants.LINE_ITEMS), new TypeReference<Map<String, Map<String, Object>>>(){});
	        
	    	 //set no of line item field
	    	 setNoOfLineItemsField(ocrVerticalDataObjList,fileRes,itemList.size(),fileId,ocrMasterFieldColumnMapping);
	         Map<String, Map<String, Object>> itemConfidenceScoreList = objectMapper.convertValue(confidenceScore.get(VendorInvoiceConstants.LINE_ITEMS), new TypeReference<Map<String, Map<String, Object>>>(){});
       
			for(Entry<String, Map<String, Object>> item : itemList.entrySet()) {
				lineNo++;
				setSerialNoForEachLineItem(ocrVerticalDataObjList,fileRes,lineNo,fileId);
				Map<String, Object> itemlevelConfidence = itemConfidenceScoreList.get(String.valueOf(lineNo));
				Map<String, Object> i = item.getValue();
				for(Entry<String, Object> keyValue : i.entrySet()) {
					String colName = keyValue.getKey();
					if(ocrFieldConfigMap.containsKey(colName)) {
					OcrVerticalDataObj ocrVerticalDataObj = new OcrVerticalDataObj();
					ocrVerticalDataObj.setFileId(fileId);
					ocrVerticalDataObj.setFileName(fileRes.get("FileName").toString());
					ocrVerticalDataObj.setOcrFieldMstId(ocrFieldConfigMap.get(colName));
					ocrVerticalDataObj.setOcrExtractedValue(i.get(colName).toString());
					ocrVerticalDataObj.setOcrConfidenceLevel(itemlevelConfidence.get(colName).toString());
					ocrVerticalDataObj.setIsHeader(0);
					ocrVerticalDataObj.setLineNo(lineNo);
					ocrVerticalDataObj.setColumnName(ocrMasterFieldColumnMapping.get(ocrFieldConfigMap.get(colName)));
					ocrVerticalDataObjList.add(ocrVerticalDataObj);
					}
					}
				//TODO : remove these when idp provide these columns
				OcrVerticalDataObj newObj1 = new OcrVerticalDataObj();
				newObj1.setOcrFieldMstId(186);
				newObj1.setFileId(fileId);
				newObj1.setFileName("");		
				newObj1.setOcrExtractedValue("");
				newObj1.setOcrConfidenceLevel("0");
				newObj1.setIsHeader(0);
				newObj1.setLineNo(lineNo);
				newObj1.setColumnName("sales_price");
				ocrVerticalDataObjList.add(newObj1);
				
				OcrVerticalDataObj newObj2 = new OcrVerticalDataObj();
				newObj2.setOcrFieldMstId(187);
				newObj2.setFileId(fileId);
				newObj2.setFileName("");		
				newObj2.setOcrExtractedValue("");
				newObj2.setOcrConfidenceLevel("0");
				newObj2.setIsHeader(0);
				newObj2.setLineNo(lineNo);
				newObj2.setColumnName("discount");
				ocrVerticalDataObjList.add(newObj2);
				
				OcrVerticalDataObj newObj3 = new OcrVerticalDataObj();
				newObj3.setOcrFieldMstId(188);
				newObj3.setFileId(fileId);
				newObj3.setFileName("");		
				newObj3.setOcrExtractedValue("");
				newObj3.setOcrConfidenceLevel("0");
				newObj3.setIsHeader(0);
				newObj3.setLineNo(lineNo);
				newObj3.setColumnName("other_charges_at_item_level");
				ocrVerticalDataObjList.add(newObj3);
				
				}
         
	}
     
     private void setNoOfLineItemsField(List<OcrVerticalDataObj> ocrVerticalDataObjList,Map<String, Object> fileRes,Integer size,Integer fileId,Map<Integer, String> ocrMasterFieldColumnMapping) {
    	 
    	 OcrVerticalDataObj ocrVerticalDataObj = new OcrVerticalDataObj();
			ocrVerticalDataObj.setFileId(fileId);
			ocrVerticalDataObj.setFileName(fileRes.get("FileName").toString());
			ocrVerticalDataObj.setOcrFieldMstId(VendorInvoiceConstants.OCR_MST_ID_NO_OF_LINE_ITEM);
			ocrVerticalDataObj.setOcrExtractedValue(String.valueOf(size));
			ocrVerticalDataObj.setOcrConfidenceLevel("100");
			ocrVerticalDataObj.setIsHeader(1);
			ocrVerticalDataObj.setLineNo(0);
			ocrVerticalDataObj.setColumnName(ocrMasterFieldColumnMapping.get(VendorInvoiceConstants.OCR_MST_ID_NO_OF_LINE_ITEM));
			ocrVerticalDataObjList.add(ocrVerticalDataObj);
    	 
     }
     
   private void setSerialNoForEachLineItem(List<OcrVerticalDataObj> ocrVerticalDataObjList,Map<String, Object> fileRes,int lineNo,Integer fileId) {
    	 
    	 OcrVerticalDataObj ocrVerticalDataObj = new OcrVerticalDataObj();
			ocrVerticalDataObj.setFileId(fileId);
			ocrVerticalDataObj.setFileName(fileRes.get("FileName").toString());
			ocrVerticalDataObj.setOcrFieldMstId(VendorInvoiceConstants.OCR_MST_ID_SERIAL_NO);
			ocrVerticalDataObj.setOcrExtractedValue(String.valueOf(lineNo));
			ocrVerticalDataObj.setOcrConfidenceLevel("100");
			ocrVerticalDataObj.setIsHeader(0);
			ocrVerticalDataObj.setLineNo(lineNo);
			ocrVerticalDataObjList.add(ocrVerticalDataObj);
    	 
     }
   
   @Override
   public Map<String, Object> getOcrComplianceIssue(Integer fileId) throws VendorInvoiceServerException {
	   try {
		   HashMap<String, Object> resultSet = new LinkedHashMap<String, Object>() ; ;
		   HashMap<String, Object> complianceIssueMapping = new LinkedHashMap<String, Object>() ;
		   HashMap<String, Object> extractionIssueMapping = new LinkedHashMap<String, Object>() ;
		   List<OcrComplianceErrorDto> complianceIssues = fileOcrProcessAndSaveRepository.getOcrComplianceValidation(fileId, OcrValidationConstants.PLD_COMPLIANCE_VALIDATION);
		   List<OcrComplianceErrorDto> extractionIssues = fileOcrProcessAndSaveRepository.getOcrComplianceValidation(fileId, OcrValidationConstants.PLD_EXTRACTION_VALIDATION);
		   
		   // Filter the list based on risk_catagory values 1 and 2
	        List<OcrComplianceErrorDto> complianceHighRiskIssues = complianceIssues.stream()
														            .filter(obj -> obj.getRiskCategory() == 1)
														            .collect(Collectors.toList());
	        
	        List<OcrComplianceErrorDto> complianceLowRiskIssues = complianceIssues.stream()
														            .filter(obj -> obj.getRiskCategory() == 2)
														            .collect(Collectors.toList());
	        
	        List<OcrComplianceErrorDto> extractionHighRiskIssues = extractionIssues.stream()
														            .filter(obj -> obj.getRiskCategory() == 1)
														            .collect(Collectors.toList());

            List<OcrComplianceErrorDto> extractionLowRiskIssues = extractionIssues.stream()
														            .filter(obj -> obj.getRiskCategory() == 2)
														            .collect(Collectors.toList());
		   complianceIssueMapping.put("low_risk_count", complianceLowRiskIssues.size());
		   complianceIssueMapping.put("high_risk_count", complianceHighRiskIssues.size());
		   complianceIssueMapping.put("high_risk_list", complianceHighRiskIssues);
		   complianceIssueMapping.put("low_risk_list", complianceLowRiskIssues);
		   extractionIssueMapping.put("low_risk_count", extractionLowRiskIssues.size());
		   extractionIssueMapping.put("high_risk_count", extractionHighRiskIssues.size());
		   extractionIssueMapping.put("high_risk_list", extractionHighRiskIssues);
		   extractionIssueMapping.put("low_risk_list", extractionLowRiskIssues);
		   resultSet.put("Compliance", complianceIssueMapping);
		   resultSet.put("Extraction", extractionIssueMapping);
		   return resultSet;
	   }
	   catch(Exception ex) {
		   log.error("Something went wrong",ex);
		   throw new VendorInvoiceServerException("Something went wrong");
	   }
	   
   }
   
   
   @Override
   public void ocrUploadTrigger(OcrTriggerRequestDto ocrTriggerRequestDto) throws VendorInvoiceServerException {
	   String batchNos = listToString(ocrTriggerRequestDto.getBatchNoList());
	   List<UploadReqDTO> uploadReqDTOList = fileOcrProcessAndSaveRepository.getUploadHstoryByBatchNo(batchNos);
	   if(uploadReqDTOList.isEmpty()){
		   log.error("Batch No does not exists");
		   throw new VendorInvoiceServerException("Batch No does not exists");
	   }   
	   
	   if(ocrTriggerRequestDto.getTriggerFromUpload() == 0) {
		   fileOcrProcessAndSaveRepository.deleteFromInvoiceHeader(ocrTriggerRequestDto.getBatchNoList().get(0)); 
		   fileOcrProcessAndSaveRepository.deleteFromInvoiceEWBDetails(ocrTriggerRequestDto.getBatchNoList().get(0));
		   
	   }
	   try {
		  for(UploadReqDTO obj : uploadReqDTOList) {
	       invoiceOcrFileUploadService.readAndSaveUnprocessedData(obj,new AzureConnectionCredentialsDTO());
		  }
	   }
	   catch(Exception ex) {
		   log.error("Something went wrong",ex);
		   throw new VendorInvoiceServerException("Something went wrong");
	   } 
   }
   
   private void updateOcrHeaderDetails(OcrVerticalMap ocrVerticalMap,String headerColumnName,String headerValues) throws VendorInvoiceServerException {
	   
	   try {
		    iInvoiceReviewRepository.insertOcrInvoiceDetailsArchive(ocrVerticalMap);
		    iInvoiceReviewRepository.deleteOcrInvoiceDetails(ocrVerticalMap);
		    iInvoiceReviewRepository.insertOcrInvoiceHeaderArchive(ocrVerticalMap);
            // iInvoiceReviewRepository.deleteOcrInvoiceHeader(ocrVerticalMap);
		    iInvoiceReviewRepository.updateOcrHeaderDetails(headerColumnName, headerValues, InvoiceOcrReviewConstant.OCR_INV_HEADER_TABLE_NAME,ocrVerticalMap);
	   }
	   catch(Exception e) {
		   log.error("Something went wrong",e);
		   throw new VendorInvoiceServerException("Something went wrong");
	   }
	   
   }
   
   private String listToString(List<String> list) {
	   if(list.isEmpty()) {
		   return "";
	   }
	   StringBuilder str = new StringBuilder();
	   str.append("(");
	   for(String s : list) {
		   str.append("'").append(s).append("',");
	   }
	   str.deleteCharAt(str.length() - 1);
	   str.append(")");
	   return str.toString();
	   
   }
   
   

   
     
     
	

}
