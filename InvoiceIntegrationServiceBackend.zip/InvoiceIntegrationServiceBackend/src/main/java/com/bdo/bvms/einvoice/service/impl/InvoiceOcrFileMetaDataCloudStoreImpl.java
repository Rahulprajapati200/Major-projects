package com.bdo.bvms.einvoice.service.impl;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.bdo.bvms.einvoice.service.InvoiceOcrFileMetaDataCloudStore;
import com.bdo.bvms.einvoice.service.UploadNDownloadFileService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.AzureUploadDownloadException;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class InvoiceOcrFileMetaDataCloudStoreImpl implements InvoiceOcrFileMetaDataCloudStore {
	
	@Autowired
	UploadNDownloadFileService uploadFileService;
	
	@Autowired
    public UploadTransDao uploadDao;
	
	 @Value("${temp.folder.path}")
	    String tempFolder;
	
	@Override
	public void saveFileMetaDataToAzure(UploadReqDTO uploadDTO) throws IOException, AzureUploadDownloadException {
		
		if (log.isInfoEnabled()) {
            log.info("Class:" + this.getClass().toString() + ", method :saveFileMetaDataToAzure");
        }
		
		JSONObject fileMetaData = new JSONObject();
		String fileName = new StringBuilder().append(tempFolder)
                .append(System.getProperty(Constants.FILESEPERATOR)).append(uploadDTO.getBatchNo())
                .append(Constants.UNSERSCORE_BASE).append(Constants.DOTSEPARATOR)
                .append(uploadDTO.getFileType()).toString();
		String jsonFileName = new StringBuilder().append(tempFolder)
                .append(System.getProperty(Constants.FILESEPERATOR)).append(uploadDTO.getBatchNo()).append(Constants.DOTSEPARATOR)
                .append(Constants.JSON).toString();
		
		File baseFile = new File(fileName);
		File jsonFile = new File(jsonFileName);
		byte[] bytes = FileUtils.readFileToByteArray(baseFile);
		String bts = "";
		for(byte b : bytes) {
			bts = bts + String.valueOf(b);
		}
		
		fileMetaData.put("fileName",baseFile.getName());
		fileMetaData.put("fileSize", FileUtils.sizeOf(baseFile));
		fileMetaData.put("fileBytes", bts);
		
		FileWriter fr = new FileWriter(jsonFile);
		try {
		fr.write(fileMetaData.toString());
		fr.close();
		uploadJsonFileToAzure(jsonFile);
		if (log.isInfoEnabled()) {
            log.info("Class:" + this.getClass().toString() + ", method :saveFileMetaDataToAzure: file saved to azure successfully");
        }
		}
		catch (Exception ex) {
            log.error("Error in uploadFileToAzureBlob Method", ex);
            uploadDao.updateProcessStatus(uploadDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            throw new AzureUploadDownloadException("File storage service is down");
        }
		finally {
			fr.close();
		}
		
		
		
		
	}
	
	private void uploadJsonFileToAzure(File jsonFile) throws AzureUploadDownloadException {
		String url = "DefaultEndpointsProtocol=https;AccountName=bdobytestream;AccountKey=lkzPvbTV1pbdxYrBguK25t8gYhSJ3rbJsHXOzN3mgcDjKhdcya2B+2RwEL6gn9OCfNoJshdwRAa1+ASt8EA6qA==;EndpointSuffix=core.windows.net";
        BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().connectionString(url).buildClient();
        String containerName = "localinvbytestream";
        BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(containerName);
        BlobClient blobClient = containerClient.getBlobClient(jsonFile.getName());
        blobClient.uploadFromFile(tempFolder+"/"+jsonFile.getName(), true);
	
        
	}

}
