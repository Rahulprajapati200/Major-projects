package com.bdo.bvms.invoices.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class VendorInvoiceGrnMappingCrudDTO {
	int id;
    String taxpayerGstin;
    String vendorGstin;
    String invoiceNo; 
    String invoiceDate;
    String eWayBillDate;
    String eWayBillNo;
    List<PoDetails> poDetails =new ArrayList<>();
    List<GrnDetails> grnDetails=new ArrayList<>(); 
}
