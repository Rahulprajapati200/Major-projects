package com.bdo.bvms.ewaybill.api;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.bdo.bvms.ewaybill.api.dto.BDOAuthDTO;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.ewaybill.api.dto.InvoiceDetailDTO;
import com.bdo.bvms.ewaybill.api.dto.NicAuthResponseDTO;
import com.bdo.bvms.ewaybill.api.dto.SchedularLogDto;
import com.bdo.bvms.ewaybill.api.dto.TaxpayerDetailsDTO;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.EWBGenByOtherPartyDTO;
import com.bdo.bvms.invoices.dto.EwayBillVehiclesDTO;
import com.bdo.bvms.invoices.dto.EwayBillheaderDTO;

public interface GetEwayBillApiDao {

    String getBdoAuthKey();

    int getBdoAuthId(String bdoAuthKey);

    String getBdoAuthToken();

    Integer insertToEwayBillHeader(int ewbApiCallLogId, EwayBillheaderDTO ewayBillheaderInfo)
                    throws InvoiceIntegrationEWBException;

    void insertToEwayBillItemDetails(List<com.bdo.bvms.invoices.dto.EWayBillItemsDTO> itemList, Integer id);

    TaxpayerDetailsDTO getTaxpayerDetailsFromEntityMaster(String taxpayerGstin) throws InvoiceIntegrationEWBException;

    String getBdoAuthUrl();

    String getNicAuthUrl();

    String getEwayBillApiUrl();

    String getEwayBillOtherPartyApiUrl();

    String getEwayBillAppKey();

    String getEwayBillClientId();

    String getEwayBillClientSecretEncrypted();

    Integer insertToEwayBillApiCall(NicAuthResponseDTO nicAuthResponseDTO, String taxpayerGstin,
                    GetEwayBillReqDTO getEwayBillReqDTO, String errorDesc, int pldGetType, String responseBody, int getStatus)
                    throws InvoiceIntegrationEWBException;

    void insertToEwayBillHeaderFromEWBOtherParty(List<EWBGenByOtherPartyDTO> data, int ewbApiCallLogId)
                    throws VendorInvoiceServerException;

    void insertToBdoAuthApiCall(BDOAuthDTO bdoAuthDTO) throws InvoiceIntegrationEWBException;

    int insertIntoExternalApiCallLog(NicAuthResponseDTO nicAuthResponseDTO) throws InvoiceIntegrationEWBException;

    void insertToInvoiceDetail(List<InvoiceDetailDTO> data) throws InvoiceIntegrationEWBException;

    Integer getYearIdByFp(String fp);

    List<String> getTaxpayerListFromEntityMaster();

   // int markBDOKeyInactive(String key);

    int markNICKeyInactive(String gstin, String key);

    void insertToEwayBillVehicleDetails(List<EwayBillVehiclesDTO> vehicleList, Integer ewbId);

    List<GetEwayBillReqDTO> getFailedTaxpayerEwBToReprocess();

    NicAuthResponseDTO getNicAuthKey(String taxpayerGstin);

    List<GetEwayBillReqDTO> getTaxpayerListFromInvoiceEwaybillDetailsTable();

    List<String> getTaxpayerGstinListByPan(String pan);


    void updateEwaybillReFetchedCount(int id);

    String getEwayBillByDateApiUrl();

	void updateExternalApiCallLogSuccess(NicAuthResponseDTO nicAuthResponseDTO);

	void updateExternalApiCallLogFail(NicAuthResponseDTO nicAuthResponseDTO);

	int insertToSchedularLog(SchedularLogDto schedularLogDto) throws InvoiceIntegrationEWBException;

	void updateSchedularLog(SchedularLogDto schedularLogDto) throws InvoiceIntegrationEWBException;

	void updateEwaybillFetchedDetails(String ewbNo, EwayBillheaderDTO ewayBillheaderDTO);

	void updateEwayBillApiCallLog(int isSuccess, String errorDesc, int getStatus, int id, int successCount);
	List<Integer> getUserIdBasedOnGstin(String gstin) throws InvoiceIntegrationEWBException;

	void commonPostNotification(int vendoruploadmstid, String notificationDesc, String notificationCode,
			List<Integer> userIdList);

	void updateEwbStatusToExpired(String expDate);

	void updateEwbStatusToDiscarded(String disDate);


}