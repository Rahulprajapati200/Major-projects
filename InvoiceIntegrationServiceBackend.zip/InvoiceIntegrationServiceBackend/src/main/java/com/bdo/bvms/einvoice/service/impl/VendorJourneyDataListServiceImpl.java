package com.bdo.bvms.einvoice.service.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.CustomColumnService;
import com.bdo.bvms.einvoice.service.VendorJourneyDataListService;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.VendorInvoiceProcessedDataListDao;
import com.bdo.bvms.invoices.dao.VendorJourneyDataListDao;
import com.bdo.bvms.invoices.dto.ApprovedDocumentsDTO;
import com.bdo.bvms.invoices.dto.DraftDocumentsDTO;
import com.bdo.bvms.invoices.dto.ProcessedListDataResDTO;
import com.bdo.bvms.invoices.dto.TotalDocumentsDataDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

import lombok.extern.slf4j.Slf4j;

/** The Constant log. */
@Slf4j

@Service
@Transactional
public class VendorJourneyDataListServiceImpl implements VendorJourneyDataListService {

    @Autowired
    VendorJourneyDataListDao vendorJourneyDataListDao;

    @Autowired
    CustomColumnService customColumnService;

    @Autowired
    VendorInvoiceProcessedDataListDao vendorInvoiceProcessedDataListDao;

    @Override
    public Map<String, Object> gettotalDocumentsDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {

        Map<String, Object> data;
        try {
            data = new LinkedHashMap<>();

            Map<String, Object> dataRes = vendorJourneyDataListDao.gettotalDocumentsDataList(vendorInvoiceRequestDTO,
                            gstinNewList, monthList);

            List<TotalDocumentsDataDTO> dataResList = (List<TotalDocumentsDataDTO>) dataRes.get("dataRes");
            data.put("Data", dataResList);

            data.put("totalPageElements", dataRes.get("count"));

        } catch (Exception e) {
            log.error("error coming at the time of getting data of 'columnData' and 'Data' from totalDocumentsDataList",
                            e.getCause());
            throw new VendorInvoiceServerException(e.getMessage());
        }

        return data;

    }

    @Override
    public Map<String, Object> getdraftDocumentsDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {
        Map<String, Object> data;
        try {
            data = new LinkedHashMap<>();

            Map<String, Object> dataRes = vendorJourneyDataListDao.getdraftDocumentsDataList(vendorInvoiceRequestDTO,
                            gstinNewList, monthList);
            List<DraftDocumentsDTO> dataResList = (List<DraftDocumentsDTO>) dataRes.get("dataRes");
            data.put("Data", dataResList);
            data.put("totalPageElements", dataRes.get("count"));

        } catch (Exception e) {

            log.error("error coming at the time of getting data of 'columnData' and 'Data' from draftDocumentsDataGrid tab",
                            e.getCause());
            throw new VendorInvoiceServerException(e.getMessage());
        }

        return data;

    }

    @Override
    public Map<String, Object> getsubmittedPendingApprovalDocumentsDataGrid(
                    VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList, String monthList)
                    throws VendorInvoiceServerException {
        Map<String, Object> data;
        try {
            data = new LinkedHashMap<>();

            Map<String, Object> dataRes = vendorJourneyDataListDao.getsubmittedPendingApprovalDocumentsDataList(
                            vendorInvoiceRequestDTO, gstinNewList, monthList);
            List<DraftDocumentsDTO> dataResList = (List<DraftDocumentsDTO>) dataRes.get("dataRes");
            data.put("Data", dataResList);
            data.put("totalPageElements", dataRes.get("count"));

        } catch (Exception e) {
            log.error("error coming at the time of getting data of 'columnData' and 'Data' from submittedPendingApprovalDocumentsDataList",
                            e.getCause());
            throw new VendorInvoiceServerException(e.getMessage());
        }

        return data;
    }

    @Override
    public Map<String, Object> getapprovedDocumentsDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {
        Map<String, Object> data;
        try {
            data = new LinkedHashMap<>();

            Map<String, Object> dataRes = vendorJourneyDataListDao.getApprovedDocumentsDataList(vendorInvoiceRequestDTO,
                            gstinNewList, monthList);
            List<ApprovedDocumentsDTO> dataResList = (List<ApprovedDocumentsDTO>) dataRes.get("dataRes");
            data.put("Data", dataResList);
            data.put("totalPageElements", dataRes.get("count"));

        } catch (Exception e) {
            log.error("error coming at the time of getting data of 'columnData' and 'Data' from approvedDocumentsDataGrid",
                            e.getCause());
            throw new VendorInvoiceServerException(e.getMessage());
        }

        return data;
    }

    @Override
    public Map<String, Object> getrejectedDocumentsDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {
        Map<String, Object> data;
        try {
            data = new LinkedHashMap<>();

            Map<String, Object> dataRes = vendorJourneyDataListDao.getRejectedDocumentsDataList(vendorInvoiceRequestDTO,
                            gstinNewList, monthList);
            List<ApprovedDocumentsDTO> dataResList = (List<ApprovedDocumentsDTO>) dataRes.get("dataRes");
            data.put("Data", dataResList);
            data.put("totalPageElements", dataRes.get("count"));

        } catch (Exception e) {
            log.error("error coming at the time of getting data of 'columnData' and 'Data' from sync pending tab",
                            e.getCause());
            throw new VendorInvoiceServerException(e.getMessage());
        }

        return data;
    }

    @Override
    public Map<String, Object> getProcessedDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {

        Map<String, Object> data;
        try {
            data = new LinkedHashMap<>();
            int totalCount = 0;

            data.put("ColumnData", customColumnService.getCustomGridColumns(vendorInvoiceRequestDTO));

            List<ProcessedListDataResDTO> dataResList = vendorJourneyDataListDao
                            .getProcessedInvoiceDataList(vendorInvoiceRequestDTO, gstinNewList, monthList);
            data.put("Data", dataResList);

            if (!dataResList.isEmpty()) {
                totalCount = dataResList.get(0).getTotalCount();
            }
            data.put("totalPageElements", totalCount);

            data.put("status", "");

        } catch (Exception e) {
            log.error("error coming at the time of getting data of 'columnData' and 'Data' in processed Invoice tab",
                            e.getCause());
            throw new VendorInvoiceServerException(e.getMessage());
        }

        return data;

    }

}
