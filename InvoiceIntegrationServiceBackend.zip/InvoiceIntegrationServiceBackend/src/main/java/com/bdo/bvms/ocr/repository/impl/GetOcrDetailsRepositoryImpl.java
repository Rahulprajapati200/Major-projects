package com.bdo.bvms.ocr.repository.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.invoices.util.CommonUtils;
import com.bdo.bvms.ocr.dto.OcrResponseDto;
import com.bdo.bvms.ocr.repository.GetOcrDetailsRepository;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class GetOcrDetailsRepositoryImpl implements GetOcrDetailsRepository {

	@Autowired
	JdbcTemplate jdbcTemplateTrn;
	@Autowired
	CommonDao commonDao;

	@Override
	public List<OcrResponseDto> getOcrDetails(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
			String monthList) throws VendorInvoiceServerException {
		try {

			 Map<String, String> screenAliasMap = commonDao.getSchreeAliasMap(vendorInvoiceRequestDTO);
	            String whereCondition = CommonUtils.getWhereCondition(vendorInvoiceRequestDTO.getAdvanceFilter(),
	                            screenAliasMap);
			Map<String, Object> out = commonDao.getGridDataForOcrDetails(vendorInvoiceRequestDTO, gstinNewList,monthList,whereCondition);
			List<OcrResponseDto> dataResList = new ArrayList<>();
			int totalCount = ((List<Map<String, Long>>) out.get("#result-set-" + 2)).get(0).get("total_count")
					.intValue();
			List<Map<String, Object>> results = (List<Map<String, Object>>) out.get("#result-set-" + 1);
			if (results.isEmpty()) {
				return dataResList;
			}

			results.forEach(u -> {

				OcrResponseDto dataRes = new OcrResponseDto();
				dataRes.setId(Integer.valueOf(u.get("id").toString()));
				dataRes.setTaxpayerGstin((String) u.get("taxpayer_gstin"));
				dataRes.setVendorGstin((String) u.get("vendor_gstin"));
				dataRes.setVendorName((String) u.get("vendor_name"));
				dataRes.setDataType((String) u.get("docType"));
				dataRes.setInvoiceType((String) u.get("document_type"));
				dataRes.setInvoiceNo((String) u.get("invoice_no"));
				dataRes.setInvoiceDate((String) u.get("invoice_date"));
				dataRes.setEwayBillNo((String) u.get("eway_bill_no"));
				dataRes.setEwaybillDate((String) u.get("eway_bill_date"));
				dataRes.setIrnNo((String) u.get("irn_no"));
				dataRes.setIrnDate((String) u.get("irn_date"));
				dataRes.setPoNo((String) u.get("po_number"));
				dataRes.setFileId(Integer.valueOf(u.get("file_id").toString()));
				dataRes.setBatchNo((String) u.get("batch_no"));
				dataRes.setOcrStatus((String) u.get("ocr_status"));
				dataRes.setOcrVerification((String) u.get("is_ocr_data_verified"));
				dataRes.setVendorCodeErp((String) u.get("vendor_code_erp"));

				if (u.get("taxable_amount") != null) {
					dataRes.setTaxableAmount(u.get("taxable_amount").toString());
				} else {
					dataRes.setTaxableAmount("0.00");
				}

				if (u.get("igst_amt") != null) {
					dataRes.setIgst(u.get("igst_amt").toString());
				} else {
					dataRes.setIgst("0.00");
				}

				if (u.get("sgst_amt") != null) {
					dataRes.setSgst(u.get("sgst_amt").toString());
				} else {
					dataRes.setSgst("0.00");
				}

				if (u.get("cgst_amt") != null) {
					dataRes.setCgst(u.get("cgst_amt").toString());
				} else {
					dataRes.setCgst("0.00");
				}
				if (u.get("cess_amt") != null) {
					dataRes.setCess(u.get("cess_amt").toString());
				} else {
					dataRes.setCess("0.00");
				}

				if (u.get("total_inv_amount") != null) {
					dataRes.setInvoiceValue(u.get("total_inv_amount").toString());
				} else {
					dataRes.setInvoiceValue("0.00");
				}

				dataRes.setUploadedBy((String) u.get("uploaded_by"));
				dataRes.setUploadedOn((LocalDateTime) u.get("uploaded_on"));
				dataRes.setExtraction(Integer.valueOf(u.get("ocr_extration_error").toString()));
				dataRes.setCompliance(Integer.valueOf(u.get("compliance_extration_error").toString()));
				dataRes.setFileName((String) u.get("file_name"));
				dataRes.setIsTaxpayerUploaded((String) u.get("is_taxpayer_uploaded"));
				dataRes.setTotalCount(totalCount);
				dataResList.add(dataRes);

			});

			return dataResList;
		} catch (Exception e) {
			log.info("Error occures at the time of fetching data from database", e.getCause());
			throw new VendorInvoiceServerException("Something went Wrong, Please Contact with Administrator",
					e.getCause());

		}

	}

}
