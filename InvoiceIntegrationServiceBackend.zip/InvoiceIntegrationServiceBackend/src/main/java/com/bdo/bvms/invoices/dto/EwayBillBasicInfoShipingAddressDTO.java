package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EwayBillBasicInfoShipingAddressDTO {

    String title;
    String address1;
    String address2;
    String state;
    String place;
    String pincode;
}
