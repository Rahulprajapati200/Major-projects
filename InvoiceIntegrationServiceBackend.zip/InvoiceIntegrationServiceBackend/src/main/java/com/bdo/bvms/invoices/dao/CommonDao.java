package com.bdo.bvms.invoices.dao;

import java.util.HashMap;
import java.util.Map;

import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface CommonDao {

    HashMap<String, String> getErrorCodeMap();

    String getDescriptionFromDB(HashMap<String, String> mapRet, EInvoiceTemplateDTO data);

    void updateExceptionLogTable(ExceptionLogDTO exceptionLogDTO);

    String[] getGstinFromDB(String pan, String bdName);

    AzureConnectionCredentialsDTO getAzureCredentialFromDB(int i, String string);

    Integer checkInvoiceAlreadySaved(String gstinOfSupplier, String inwardNo, String inwardDate, String fp,
                    String pFyCheck, String yearId);

    java.util.List<String> getBatchDataUploadedInPreviousFP(String gstinOfSupplier, String fp, String yearId);

    String[] getMonthsFromDB(String yearId);

    Map<String, Object> getGridDataByProcedure(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
                    String monthList);

    Map<String, Object> getGridDataPendingForUserInput(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList,String whereCon);

    Map<String, Object> getGridDataForSyncPending(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
                    String monthList,String whereCon);

    Map<String, Object> getGridDataProcessedInvoice(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList,String whereCon);

    int getYearIdFromFp(String fillingPeriod);

    HashMap<String, String> getYearId();


    Map<String, Object> getGridDataForApprovalPending(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList,String whereCon);

	Map<String, String> getSchreeAliasMap(VendorInvoiceRequestDTO vendorInvoiceRequestDTO);

	Map<String, Object> getGridDataForOcrDetails(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,String monthList,String whereCond);

	String getSystemParameterCredential(String keyName);

	Map<String, Object> getGridDataUrp(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
			String monthList, String whereCondition);

	String getEntityId(String vensorEmail);

	

}
