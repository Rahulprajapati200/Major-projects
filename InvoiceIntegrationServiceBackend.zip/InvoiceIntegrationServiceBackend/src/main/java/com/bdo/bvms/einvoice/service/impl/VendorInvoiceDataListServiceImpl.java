package com.bdo.bvms.einvoice.service.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.VendorInvoiceApprovalPendingDataListService;
import com.bdo.bvms.einvoice.service.VendorInvoiceDataListService;
import com.bdo.bvms.einvoice.service.VendorInvoicePendingForUserInputDataListService;
import com.bdo.bvms.einvoice.service.VendorInvoiceProcessedDataListService;
import com.bdo.bvms.einvoice.service.VendorInvoiceRejectedDataListService;
import com.bdo.bvms.einvoice.service.VendorInvoiceSyncDataListService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.VendorInvoiceConstants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.ocr.service.GetOcrDetailsService;
import com.bdo.bvms.urp.service.GetUrpDetailsService;
import com.bdo.bvms.urp.service.impl.GetUrpDetailsServiceImpl;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class VendorInvoiceDataListServiceImpl implements VendorInvoiceDataListService {

    @Autowired
    VendorInvoiceSyncDataListService vendorInvoiceSyncDataListService;

    @Autowired
    VendorInvoiceProcessedDataListService vendorInvoiceProcessedDataListService;

    @Autowired
    VendorInvoicePendingForUserInputDataListService vendorInvoicePendingForUserInputDataListService;

    @Autowired
    VendorInvoiceApprovalPendingDataListService vendorInvoiceApprovalPendingDataListService;

    @Autowired
    VendorInvoiceRejectedDataListService vendorInvoiceRejectedDataListService;

    @Autowired
    GetOcrDetailsService getOcrDetailsService;

    @Autowired
    CommonDao commonDao;
    String gstinList;
    String fpList;

    @Value("${mst.database-name}")
    String mstDatabseName;
    
    @Autowired
    private MessageSource messageSource;

    @Autowired
    GetUrpDetailsService getUrpDetailsService;

    @Override
    public Map<String, Object> getDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO)
                    throws VendorInvoiceServerException {

        String gstinNewList = getGstinList(vendorInvoiceRequestDTO);

        String monthList = getMonthList(vendorInvoiceRequestDTO);
        if (StringUtils.isNotBlank(vendorInvoiceRequestDTO.getSortFilter()) && vendorInvoiceRequestDTO.getSortFilter().contains("date")) {
			String[] aliasCondition = vendorInvoiceRequestDTO.getSortFilter().split(" ");
			StringBuilder sortFilterString = new StringBuilder();
			sortFilterString.append("str_to_date(").append(aliasCondition[0] + ",").append('"')
					.append("%d-%m-%Y").append('"').append(") ").append(aliasCondition[1]);
			vendorInvoiceRequestDTO.setSortFilter(sortFilterString.toString());
		}
        if (VendorInvoiceConstants.SYNC_PENDING.equals(vendorInvoiceRequestDTO.getTabId())) {

            try {
                return vendorInvoiceSyncDataListService.getSyncPendingDataGrid(vendorInvoiceRequestDTO, gstinNewList,
                                monthList);
            } catch (Exception e) {
                log.error("Error in getDataGrid method", e);
                throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                        LocaleContextHolder.getLocale()));
            }

        } else if (VendorInvoiceConstants.PROCESSED_INVOICE.equals(vendorInvoiceRequestDTO.getTabId())) {

            try {

                return vendorInvoiceProcessedDataListService.getProcessedDataGrid(vendorInvoiceRequestDTO, gstinNewList,
                                monthList);
            } catch (VendorInvoiceServerException e) {
                log.error("Error in getDataGrid method", e);
                throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                        LocaleContextHolder.getLocale()));
            }

        } else if (VendorInvoiceConstants.PENDING_FOR_USER_INPUT.equals(vendorInvoiceRequestDTO.getTabId())) {

            return vendorInvoicePendingForUserInputDataListService.getPendingInputDataGrid(vendorInvoiceRequestDTO,
                            gstinNewList, monthList);

        } else if (VendorInvoiceConstants.APPROVAL_PENDING.equals(vendorInvoiceRequestDTO.getTabId())) {

            return vendorInvoiceApprovalPendingDataListService.getApprovalPendingDataGrid(vendorInvoiceRequestDTO,
                            gstinNewList, monthList);

        } else if (VendorInvoiceConstants.REJECTED.equals(vendorInvoiceRequestDTO.getTabId())) {

            return vendorInvoiceApprovalPendingDataListService.getApprovalPendingDataGrid(vendorInvoiceRequestDTO,
                            gstinNewList, monthList);

        }
        
        else if (VendorInvoiceConstants.OCR_TAB.equals(vendorInvoiceRequestDTO.getTabId())) {

            return getOcrDetailsService.getOcrDetailsDataGrid(vendorInvoiceRequestDTO,
                    gstinNewList, monthList);

        }
        else if (VendorInvoiceConstants.URP_TAB.equals(vendorInvoiceRequestDTO.getTabId())) {

            return getUrpDetailsService.getUrpDetailsDataGrid(vendorInvoiceRequestDTO,
                    gstinNewList, monthList);

        }

        return new HashMap<>();

    }

    @Override
    public String getGstinList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO) {

        if (Constants.PAN.equals(vendorInvoiceRequestDTO.getGstinOrPan())) {

            // here we get all GSTIN into a string array according to single pan
            // from database.
            String[] gstinArray = commonDao.getGstinFromDB(vendorInvoiceRequestDTO.getGstinOrPanList().get(0),
                            mstDatabseName);
            // here we convert GSTIN string array into the string.
            gstinList = Arrays.toString(gstinArray);

        } else if (Constants.GSTIN.equals(vendorInvoiceRequestDTO.getGstinOrPan())) {
            // here we get GSTIN list from request body and convert it into
            // string
            gstinList = vendorInvoiceRequestDTO.getGstinOrPanList().toString();
        }
        return gstinList.replace("[", "").replace("]", "").replace("{", "").replace("}", "").replace(" ", "");

    }

    @Override
    public String getMonthList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO) {

        if (Constants.FPYEAR.equals(vendorInvoiceRequestDTO.getYearOrMonth())) {

            // here we get all month into a string array according to single
            // year
            // from database.
            String[] monthArray = commonDao.getMonthsFromDB(vendorInvoiceRequestDTO.getYearOrMonthList().get(0));
            // here we convert months string array into the string.
            fpList = Arrays.toString(monthArray);

        } else if (Constants.FPMONTH.equals(vendorInvoiceRequestDTO.getYearOrMonth())) {
            // here we get month list from request body and convert it into
            // string
            fpList = vendorInvoiceRequestDTO.getYearOrMonthList().toString();
        }
        return fpList.replace("[", "").replace("]", "").replace("{", "").replace("}", "").replace(" ", "");

    }

}
