package com.bdo.bvms.erp.integration.service;

import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.erp.integration.dto.ERPRequestDTO;
import com.bdo.bvms.erp.integration.dto.ErpInvoiceIntegrationRequestDto;
import com.bdo.bvms.invoices.custom.exception.AzureUploadDownloadException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceSavedataOnUploadException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;

public interface VendorInvoiceErpIntegrationService {

	String processForOcrFileUpload(ErpInvoiceIntegrationRequestDto reqDto) throws AzureUploadDownloadException, VendorInvoiceServerException, VendorInvoiceSavedataOnUploadException;

	Map<String, Object> getVendorinvoiceJson(String ackNo);

	ERPRequestDTO getdbErpDetails();


}