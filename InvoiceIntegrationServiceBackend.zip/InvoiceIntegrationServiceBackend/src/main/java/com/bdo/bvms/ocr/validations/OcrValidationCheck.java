package com.bdo.bvms.ocr.validations;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.invoices.constant.OcrValidationConstants;
import com.bdo.bvms.invoices.constant.ValidationConstants;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.taxpayer.validationrule.EInvoiceValidationUtil;
import com.bdo.bvms.ocr.dto.OcrComplianceErrorDto;
import com.bdo.bvms.ocr.dto.OcrVerticalDataObj;
import com.bdo.bvms.ocr.util.OcrValidationUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OcrValidationCheck {

	public List<OcrComplianceErrorDto> validateRules(List<OcrVerticalDataObj> ocrVerticalDataObjList)
			throws ParseException {
		log.info("Entering validateRules Method");
		List<OcrComplianceErrorDto> ocrComplianceErrorList = new ArrayList<>();
		OcrValidationUtil inwardRules = new OcrValidationUtil();
		for (OcrVerticalDataObj data : ocrVerticalDataObjList) {
			// validation on taxpayer gstin
			if (OcrValidationConstants.TAXPAYER_GSTIN.equals(data.getColumnName())) {
				log.info("Validating taxpayer gstin");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE011)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkForValidGstin(data, inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE001)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on taxpayer pan
			if (OcrValidationConstants.TAXPAYER_PAN.equals(data.getColumnName())) {
				log.info("Validating taxpayer pan");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE027)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkForValidPan(data, inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE028)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on vendor gstin
			else if (OcrValidationConstants.VENDOR_GSTIN.equals(data.getColumnName())) {
				log.info("Validating vendor gstin");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE012)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(!data.getOcrExtractedValue().equalsIgnoreCase("URP") && Boolean.TRUE.equals(checkForValidGstin(data, inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE002)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on taxpayer pan
			if (OcrValidationConstants.VENDOR_PAN.equals(data.getColumnName())) {
				log.info("Validating Vendor pan");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE029)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkForValidPan(data, inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE030)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}

			// validation on description
			else if (OcrValidationConstants.DESCRIPTION.equals(data.getColumnName())) {
				log.info("Validating description");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE003)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}

			// validation on quantity
			else if (OcrValidationConstants.QUANTITY.equals(data.getColumnName())) {
				log.info("Validating quantity");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE013)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkOnlyNumericValueWithTwoDecimalCheck(data, inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE004)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}

			// validation on UOM
			 else if(OcrValidationConstants.UOM.equals(data.getColumnName())) {
				 log.info("Validating UOM");
				 ArrayList<String> uomStanderdList = new ArrayList<>(Arrays.asList(
				            "BAG", "BAL", "BDL", "BKL", "BOU", "BOX", "BTL", "BUN", "CAN",
				            "CBM", "CCM", "CMS", "CTN", "DOZ", "DRM", "GGK", "GMS", "GRS",
				            "GYD", "KGS", "KLR", "KME", "MLT", "MTS", "MTR", "NOS", "PAC",
				            "PCS", "PRS", "QTL", "ROL", "SET", "SQF", "SQM", "SQY", "TBS",
				            "TGM", "THD", "TON", "TUB", "UGS", "UNT", "YDS", "OTH"
				        ));
				 if(Boolean.TRUE.equals(validateBlankField(data))) {
						OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
								.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE014)
								.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
						ocrComplianceErrorList.add(obj);
					}
			
				 else if(Boolean.TRUE.equals(validateUOM(data,uomStanderdList))) {
				    	OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
								.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE005)
								.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
						ocrComplianceErrorList.add(obj);
				    }

			 }

			// validation on sgst amount
			else if (OcrValidationConstants.SGST_AMT.equals(data.getColumnName())) {
				log.info("Validating sgst amount");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE015)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkOnlyNumericValueWithTwoDecimalCheck(data, inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE006)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on cgst amount
			else if (OcrValidationConstants.CGST_AMT.equals(data.getColumnName())) {
				log.info("Validating cgst amount");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE016)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkOnlyNumericValueWithTwoDecimalCheck(data, inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE007)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on igst amount
			else if (OcrValidationConstants.IGST_AMT.equals(data.getColumnName())) {
				log.info("Validating igst amount");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE017)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkOnlyNumericValueWithTwoDecimalCheck(data, inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE008)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on cess amount
			else if (OcrValidationConstants.CESS_AMT.equals(data.getColumnName())) {
				log.info("Validating cess amount");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE018)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkOnlyNumericValueWithTwoDecimalCheck(data, inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE009)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on total invoice amount
			else if (OcrValidationConstants.TOTAL_INV_MAOUNT.equals(data.getColumnName())) {
				log.info("Validating total invoice amount");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE019)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkOnlyNumericValueWithTwoDecimalCheck(data, inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE010)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on total taxable amount
			else if (OcrValidationConstants.TOTAL_TAXABLE.equals(data.getColumnName())) {
				log.info("Validating total taxable amount");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE025)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on item level taxable value
			else if (OcrValidationConstants.TAXABLE_VALUE.equals(data.getColumnName())) {
				log.info("Validating item level taxable value");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE026)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on invoice no
			else if (OcrValidationConstants.INVOICE_NO.equals(data.getColumnName())) {
				log.info("Validating invoice no.");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE020)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkSpecialCharInInvoiceNo(data,inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE021)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
					
				}
				else if(Boolean.TRUE.equals(check16CharacterLength(data,inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE022)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				
				
			}
			
			// validation on hsn code
			else if (OcrValidationConstants.HSN_CODE.equals(data.getColumnName())) {
				log.info("Validating hsn code");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE023)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkHsnCodeMaxLength(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE024)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkOnlyNumericValue(data,inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE031)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on sgst % 
			else if (OcrValidationConstants.SGST_P.equals(data.getColumnName())) {
				log.info("Validating sgst % ");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE032)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkOnlyNumericValueWithTwoDecimalCheck(data,inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE033)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on cgst % 
			else if (OcrValidationConstants.CGST_P.equals(data.getColumnName())) {
				log.info("Validating cgst % ");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE034)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkOnlyNumericValueWithTwoDecimalCheck(data,inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE035)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on igst % 
			else if (OcrValidationConstants.IGST_P.equals(data.getColumnName())) {
				log.info("Validating igst % ");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE036)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkOnlyNumericValueWithTwoDecimalCheck(data,inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE037)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on cess % 
			else if (OcrValidationConstants.CESS_P.equals(data.getColumnName())) {
				log.info("Validating cess %");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE038)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkOnlyNumericValueWithTwoDecimalCheck(data,inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE039)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on item rate
			else if (OcrValidationConstants.RATE.equals(data.getColumnName())) {
				log.info("Validating item rate");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE040)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkOnlyNumericValueWithTwoDecimalCheck(data, inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE041)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on total tds
			else if (OcrValidationConstants.TDS.equals(data.getColumnName())) {
				log.info("Validating total tds");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE042)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
				else if(Boolean.TRUE.equals(checkOnlyNumericValueWithTwoDecimalCheck(data, inwardRules))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE043)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_COMPLIANCE_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}
			
			// validation on place of supply
			else if (OcrValidationConstants.POS.equals(data.getColumnName())) {
				log.info("Validating place of supply ");
				if(Boolean.TRUE.equals(validateBlankField(data))) {
					OcrComplianceErrorDto obj = OcrComplianceErrorDto.builder().ocrMstId(data.getOcrFieldMstId())
							.fileId(data.getFileId()).resolveStatus(0).errorCode(OcrValidationConstants.OCR_ERROR_CODE_CE044)
							.lineNo(data.getLineNo()).pldErrorType(OcrValidationConstants.PLD_EXTRACTION_VALIDATION).build();
					ocrComplianceErrorList.add(obj);
				}
			}

			

		}

		return ocrComplianceErrorList;

	}

	private Boolean checkForValidGstin(OcrVerticalDataObj data, OcrValidationUtil inwardRules) {
		return (!inwardRules.validGSTIN(data.getOcrExtractedValue()));
	}

	private Boolean checkForValidPan(OcrVerticalDataObj data, OcrValidationUtil inwardRules) {
		return (!inwardRules.validPAN(data.getOcrExtractedValue()));
	}
	
	private Boolean validateBlankField(OcrVerticalDataObj data) {
		return StringUtils.isBlank(data.getOcrExtractedValue());
	}

	private Boolean validateUOM(OcrVerticalDataObj data, List<String> uomStanderdList) {
		return (!uomStanderdList.contains(data.getOcrExtractedValue())) ;
	}
	
	private Boolean checkSpecialCharInInvoiceNo(OcrVerticalDataObj data, OcrValidationUtil inwardRules) {
        return (StringUtils.isNotBlank(data.getOcrExtractedValue())
                        && !inwardRules.isSpecialCharExistInInvoiceNo(data.getOcrExtractedValue()));
    }
	
	private Boolean check16CharacterLength(OcrVerticalDataObj data, OcrValidationUtil inwardRules) {
        return (!inwardRules.check16CharacterLength(data.getOcrExtractedValue()));
       
    }
	
	private Boolean checkHsnCodeMaxLength(OcrVerticalDataObj data) {
        return (data.getOcrExtractedValue().length() > 8);
       
    }
	private Boolean checkOnlyNumericValueWithTwoDecimalCheck(OcrVerticalDataObj data,OcrValidationUtil inwardRules) {
        return (!inwardRules.onlyNumericValueWithTwoDecimalCheck(data.getOcrExtractedValue()));
       
    }
	
	private Boolean checkOnlyNumericValue(OcrVerticalDataObj data,OcrValidationUtil inwardRules) {
        return (!inwardRules.onlyNumericMainHsnCode(data.getOcrExtractedValue()));
       
    }

}
