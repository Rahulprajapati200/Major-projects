package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EwayBillItemDetailsListDTO {

    String productName;
    String description;
    String hsnCode;
    String quantity;
    String unit;
    String taxable;
    String cgstRate;
    String sgstRate;
    String igstRate;
    String cessRate;
    String cessNonAdvol;
}
