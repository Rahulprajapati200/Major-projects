package com.bdo.bvms.invoices.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class RejectedResDTO {

    int id;
    String taxpayerGstin;
    String dataType;
    String vendorGstin;
    String vendorLegalName;
    String vendorTradeName;
    String invoiceNo;
    String invoiceDate;
    String ewayBillNo;
    String ewayBillDate;
    String uploadDate;
    String uploadBy;
    String rejectedDate;
    String rejectedBy;
    String action;

}
