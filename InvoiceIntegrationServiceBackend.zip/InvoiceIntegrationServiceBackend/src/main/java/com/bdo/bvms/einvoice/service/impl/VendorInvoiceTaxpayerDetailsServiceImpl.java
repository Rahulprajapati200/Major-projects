package com.bdo.bvms.einvoice.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bdo.bvms.einvoice.service.VendorInvoiceDetailsService;
import com.bdo.bvms.ewaybill.api.GetEwayBillDetailsService;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.ewaybill.api.impl.GetEwayBillDetailsByDateServiceImpl;
import com.bdo.bvms.ewaybill.api.impl.GetEwayBillDetailsOtherPartyServiceImpl;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.SyncOperationDataListDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceDetailsRepository;
import com.bdo.bvms.invoices.dto.EWBViewDTO;
import com.bdo.bvms.invoices.dto.GetEwayBillDetailsRequestDTO;
import com.bdo.bvms.invoices.dto.Gstr2HeaderDTOForForceSync;
import com.bdo.bvms.invoices.dto.Gstr2LineItemsDTO;
import com.bdo.bvms.invoices.dto.Gstr2ViewDetailsDTO;
import com.bdo.bvms.invoices.dto.Gstr2aHeaderDto;
import com.bdo.bvms.invoices.dto.Gstr2aResponseDTO;
import com.bdo.bvms.invoices.dto.Gstr2aSyncUnsyncDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsReqDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsResponseDto;
import com.bdo.bvms.invoices.dto.InvoicePrimaryDetail;
import com.bdo.bvms.invoices.dto.VendorInvoiceGETRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceGetResponseDTO;
import com.bdo.bvms.invoices.dto.WfApproveOrRejectDTO;
import com.bdo.bvms.invoices.util.DateUtil;
import com.bdo.bvms.invoices.util.ExcelUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class VendorInvoiceTaxpayerDetailsServiceImpl.
 */
@Service
@Slf4j
public class VendorInvoiceTaxpayerDetailsServiceImpl implements VendorInvoiceDetailsService {

    /** The vendor invoice details repository. */
    @Autowired
    VendorInvoiceDetailsRepository vendorInvoiceDetailsRepository;

    /** The sync operation data list dao. */
    @Autowired
    SyncOperationDataListDao syncOperationDataListDao;

    /** get ewaybill data by ewaybill no service **/
    @Autowired
    GetEwayBillDetailsService getEwayBillDetailsServiceImpl;

    /** get ewaybill data by other party service **/
    @Autowired
    GetEwayBillDetailsOtherPartyServiceImpl getEwayBillDetailsOtherPartyServiceImpl;

    /** get ewaybill data by date service **/
    @Autowired
    GetEwayBillDetailsByDateServiceImpl getEwayBillDetailsByDateServiceImpl;

    /** The temp folder. */
    @Value("${temp.folder.path}")
    String tempFolder;

    @Autowired
    private MessageSource messageSource;

    /**
     * Gets the invoice details.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the invoice details
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    public InvoiceDetailsResponseDto getInvoiceDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO)
                    throws VendorInvoiceServerException {

        InvoiceDetailsResponseDto invoiceDetailsResponseDto = new InvoiceDetailsResponseDto();

        // get basic invoice details by id
        InvoicePrimaryDetail invDetail = vendorInvoiceDetailsRepository.getInvoicePrimaryDetails(invoiceDetailsReqDTO);

        // get base document
        Integer pldBaseDocument = null;

        if (!"2".equals(invoiceDetailsReqDTO.getTabId())) {
            pldBaseDocument = vendorInvoiceDetailsRepository.getBaseDocument(invDetail);
        }

        // re-set request dto
        invoiceDetailsReqDTO.setTaxpayerGstin(invDetail.getTaxpayerGstin());
        invoiceDetailsReqDTO.setVendorGstin(invDetail.getVendorGstin());
        invoiceDetailsReqDTO.setInvoiceno(invDetail.getInvoiceNo());
        invoiceDetailsReqDTO.setInvoicedate(invDetail.getInvoiceDate());
        invoiceDetailsReqDTO.setEwbno(invDetail.getEwayBillNo());
        invoiceDetailsReqDTO.setEwbdate(invDetail.getEwayBillDate());
        invoiceDetailsReqDTO.setOcrHeaderId(invDetail.getOcrHeaderId());
        invoiceDetailsReqDTO.setVendorPan(invDetail.getVendorPan());
        invoiceDetailsReqDTO.setVendorCodeErp(invDetail.getVendorCodeErp());

        invoiceDetailsResponseDto.setBaseData(String.valueOf(pldBaseDocument));

        invoiceDetailsResponseDto
                        .setEInvoiceDTO(vendorInvoiceDetailsRepository.getEInvoiceDetails(invoiceDetailsReqDTO));

        invoiceDetailsResponseDto
                        .setEwayBillDetailDTO(vendorInvoiceDetailsRepository.getEwayBillDetails(invoiceDetailsReqDTO));

        invoiceDetailsResponseDto.setGoodReceiptNoteDTO(
                        vendorInvoiceDetailsRepository.getGoodReceiptNoteDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto.setPurchaseOrderDTO(
                        vendorInvoiceDetailsRepository.getPurchaseOrderDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto
                        .setGetGstr2aDTO(vendorInvoiceDetailsRepository.getGetGstr2aDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto
                        .setGetGstr2bDTO(vendorInvoiceDetailsRepository.getGetGstr2bDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto
                        .setGetEWayBillDTO(vendorInvoiceDetailsRepository.getGetEWayBillDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto.setOcrDetail(vendorInvoiceDetailsRepository.getOcrDetails(invoiceDetailsReqDTO));
        return invoiceDetailsResponseDto;

    }

    /**
     * Gets the invoice line item view details.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the invoice line item view details
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    public Object getInvoiceLineItemViewDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO)
                    throws VendorInvoiceServerException {
        Gstr2ViewDetailsDTO details = new Gstr2ViewDetailsDTO();

        try {
            List<Gstr2aResponseDTO> gstr2aResponseDTO = vendorInvoiceDetailsRepository
                            .getGstr2aDetails(invoiceDetailsReqDTO);
            Gstr2aHeaderDto header = Gstr2aHeaderDto.builder()
                            .taxpayerGstin(gstr2aResponseDTO.get(0).getTaxpayerGstin())
                            .vendorGstin(gstr2aResponseDTO.get(0).getVendorGstin())
                            .vendorLegalName(gstr2aResponseDTO.get(0).getVendorLegalName())
                            .vendorTradeName(gstr2aResponseDTO.get(0).getVendorTradeName())
                            .docType(gstr2aResponseDTO.get(0).getDocType())
                            .invDate(gstr2aResponseDTO.get(0).getInvDate()).docNo(gstr2aResponseDTO.get(0).getInvNo())
                            .invoiceType(gstr2aResponseDTO.get(0).getInvoiceType())
                            .pos(gstr2aResponseDTO.get(0).getPos()).grossTotal(gstr2aResponseDTO.get(0).getGrossTotal())
                            .gstr1FilingStatus(gstr2aResponseDTO.get(0).getGstr1FilingStatus())
                            .gstr3FilingStatus(gstr2aResponseDTO.get(0).getGstr3FilingStatus())
                            .dateSupplierCancelllation(gstr2aResponseDTO.get(0).getDateSupplierCancelllation())
                            .delinkFlag(gstr2aResponseDTO.get(0).getDelinkFlag())
                            .dateFilingGstrSupplier(gstr2aResponseDTO.get(0).getDateFilingGstrSupplier())
                            .filingPeriodGstrSupplier(gstr2aResponseDTO.get(0).getFilingPeriodGstrSupplier())
                            .amendmentReturnPeriod(gstr2aResponseDTO.get(0).getAmendmentReturnPeriod())
                            .amendmentType(gstr2aResponseDTO.get(0).getAmendmentType())
                            .itcAvailability(gstr2aResponseDTO.get(0).getItcAvailability())
                            .itcUnavailabilityReason(gstr2aResponseDTO.get(0).getItcUnavailabilityReason())
                            .sourceType(gstr2aResponseDTO.get(0).getSourceType())
                            .differentialRate(gstr2aResponseDTO.get(0).getDifferentialRate())
                            .irn(gstr2aResponseDTO.get(0).getIrn())
                            .irnGeneratedDate(gstr2aResponseDTO.get(0).getIrnGeneratedDate())
                            .gstr2bFp(gstr2aResponseDTO.get(0).getGstr2bFp()).build();

            List<Gstr2LineItemsDTO> itemsList = gstr2aResponseDTO.stream()
                            .map(data -> Gstr2LineItemsDTO.builder().taxableAmount(data.getTaxableAmount())
                                            .sgstAmount(data.getSgstAmount()).cgstAmount(data.getCgstAmount())
                                            .igstAmount(data.getIgstAmount()).cessAmount(data.getCessAmount())
                                            .sgstRate(data.getSgstRate()).cgstRate(data.getCgstRate())
                                            .igstRate(data.getIgstRate()).cessRate(data.getCessRate())
                                            .reversecharge(data.getReversecharge()).totalTax(data.getTotalTax())
                                            .build())
                            .collect(Collectors.toList());
            details.setHeaderData(header);
            details.setPage(invoiceDetailsReqDTO.getPage());
            details.setItemList(itemsList);
            details.setTotalElements(vendorInvoiceDetailsRepository.getCountGstr2aLineItems(invoiceDetailsReqDTO));
            return details;
        } catch (IndexOutOfBoundsException ex) {
            log.error("Error occured while execute getGstr2aDetails function:", ex);
            throw new VendorInvoiceServerException("No record found");
        } catch (Exception ex) {
            log.error("Error occured while execute getGstr2aDetails function:", ex);
            throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                            LocaleContextHolder.getLocale()));
        }

    }

    /**
     * Gets the download invoice details.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the download invoice details
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public File getDownloadInvoiceDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO)
                    throws VendorInvoiceServerException, IOException {

        InvoiceDetailsResponseDto invoiceDetailsResponseDto = new InvoiceDetailsResponseDto();

        // get basic invoice details by id
        InvoicePrimaryDetail invDetail = vendorInvoiceDetailsRepository.getInvoicePrimaryDetails(invoiceDetailsReqDTO);

        // re-set request dto
        invoiceDetailsReqDTO.setTaxpayerGstin(invDetail.getTaxpayerGstin());
        invoiceDetailsReqDTO.setVendorGstin(invDetail.getVendorGstin());
        invoiceDetailsReqDTO.setInvoiceno(invDetail.getInvoiceNo());
        invoiceDetailsReqDTO.setInvoicedate(invDetail.getInvoiceDate());
        invoiceDetailsReqDTO.setEwbno(invDetail.getEwayBillNo());
        invoiceDetailsReqDTO.setEwbdate(invDetail.getEwayBillDate());
        invoiceDetailsReqDTO.setOcrHeaderId(invDetail.getOcrHeaderId());

        invoiceDetailsResponseDto
                        .setEInvoiceDTO(vendorInvoiceDetailsRepository.getEInvoiceDetails(invoiceDetailsReqDTO));

        invoiceDetailsResponseDto
                        .setEwayBillDetailDTO(vendorInvoiceDetailsRepository.getEwayBillDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto.setGoodReceiptNoteDTO(
                        vendorInvoiceDetailsRepository.getGoodReceiptNoteDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto.setPurchaseOrderDTO(
                        vendorInvoiceDetailsRepository.getPurchaseOrderDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto
                        .setGetGstr2aDTO(vendorInvoiceDetailsRepository.getGetGstr2aDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto
                        .setGetGstr2bDTO(vendorInvoiceDetailsRepository.getGetGstr2bDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto
                        .setGetEWayBillDTO(vendorInvoiceDetailsRepository.getGetEWayBillDetails(invoiceDetailsReqDTO));
        invoiceDetailsResponseDto.setOcrDetail(vendorInvoiceDetailsRepository.getOcrDetails(invoiceDetailsReqDTO));

        return downloadInvoiceDetails(invoiceDetailsResponseDto);

    }

    /**
     * Download invoice details.
     *
     * @param invoiceDetailsResponseDto
     *            the invoice details response dto
     * @return the file
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    private File downloadInvoiceDetails(InvoiceDetailsResponseDto invoiceDetailsResponseDto) throws IOException {

        String[] vendorInvoiceAllHeaders = { Constants.GSTIN_UIN_OF_RECIPIENT, Constants.GSTIN_OF_SUPPLIER,
                Constants.IRN, Constants.IRN_DATE, Constants.DOC_DATE, Constants.TOTAL_INVOICE_AMT, Constants.DOC_TYPE,
                Constants.NO_OF_LINE_ITEM, Constants.HSN_CODE, Constants.BATCH_NO_HEADING, Constants.E_WAY_BILL_NO,
                Constants.E_WAY_BILL_DATE, Constants.BILL_VALID_DATE, Constants.GENERATED_ON, Constants.GENERATED_BY,
                Constants.PO_NO, Constants.PO_DATE, Constants.GRN_NO, Constants.GRN_DATE, Constants.TAXABLE_AMOUNT,
                Constants.POS, Constants.IGST_AMOUNT, Constants.CGST_AMOUNT, Constants.SGST_AMOUNT,
                Constants.CESS_AMOUNT, Constants.INV_VALUE, Constants.INVOICE_NO, Constants.INVOICE_DATE,
                Constants.DEFAULTSYNCSTATUS, Constants.FORCESYNCSTATUS, Constants.STATUS, Constants.INVOICE_TYPE,
                Constants.VENDOR_NAME, Constants.FILE_NAME_HEADER, Constants.EXTRACTION, Constants.COMPLIANCE };

        Map<String, String> eInvoiceData = new HashMap<>();

        eInvoiceData.put(Constants.GSTIN_UIN_OF_RECIPIENT,
                        invoiceDetailsResponseDto.getEInvoiceDTO().getTaxpayerGstin());
        eInvoiceData.put(Constants.GSTIN_OF_SUPPLIER, invoiceDetailsResponseDto.getEInvoiceDTO().getVendorGstin());

        eInvoiceData.put(Constants.IRN, invoiceDetailsResponseDto.getEInvoiceDTO().getIrnNo());
        eInvoiceData.put(Constants.IRN_DATE, invoiceDetailsResponseDto.getEInvoiceDTO().getIrnDate());
        eInvoiceData.put(Constants.DOC_DATE, invoiceDetailsResponseDto.getEInvoiceDTO().getDocDate());
        eInvoiceData.put(Constants.TOTAL_INVOICE_AMT,
                        String.valueOf(invoiceDetailsResponseDto.getEInvoiceDTO().getTotalInvoiceValue()));
        eInvoiceData.put(Constants.INVOICE_NO, invoiceDetailsResponseDto.getEInvoiceDTO().getInvoiceNo());
        eInvoiceData.put(Constants.INVOICE_DATE, invoiceDetailsResponseDto.getEInvoiceDTO().getInvoiceDate());
        eInvoiceData.put(Constants.DOC_TYPE, invoiceDetailsResponseDto.getEInvoiceDTO().getDocType());
        eInvoiceData.put(Constants.NO_OF_LINE_ITEM,
                        String.valueOf(invoiceDetailsResponseDto.getEInvoiceDTO().getNoOfLIneItem()));
        eInvoiceData.put(Constants.HSN_CODE, invoiceDetailsResponseDto.getEInvoiceDTO().getHsnCode());
        eInvoiceData.put(Constants.BATCH_NO_HEADING, invoiceDetailsResponseDto.getEInvoiceDTO().getBatchNo());

        Map<String, String> eWayBillData = new HashMap<>();

        eWayBillData.put(Constants.GSTIN_UIN_OF_RECIPIENT,
                        invoiceDetailsResponseDto.getEwayBillDetailDTO().getTaxpayerGstin());
        eWayBillData.put(Constants.GSTIN_OF_SUPPLIER,
                        invoiceDetailsResponseDto.getEwayBillDetailDTO().getTaxpayerGstin());
        // eWayBillData.put(Constants.TITLE,
        // invoiceDetailsResponseDto.getEwayBillDetailDTO().getTitle());
        eWayBillData.put(Constants.E_WAY_BILL_NO, invoiceDetailsResponseDto.getEwayBillDetailDTO().getEwbNo());
        eWayBillData.put(Constants.E_WAY_BILL_DATE, invoiceDetailsResponseDto.getEwayBillDetailDTO().getEwbDate());
        eWayBillData.put(Constants.BILL_VALID_DATE, invoiceDetailsResponseDto.getEwayBillDetailDTO().getValidTill());
        eWayBillData.put(Constants.BATCH_NO_HEADING, invoiceDetailsResponseDto.getEwayBillDetailDTO().getBatchNo());
        eWayBillData.put(Constants.GENERATED_ON, invoiceDetailsResponseDto.getEwayBillDetailDTO().getGeneratedOn());
        eWayBillData.put(Constants.GENERATED_BY, invoiceDetailsResponseDto.getEwayBillDetailDTO().getGeneratedBy());

        Map<String, String> purchaseOrder = new HashMap<>();

        purchaseOrder.put(Constants.GSTIN_UIN_OF_RECIPIENT,
                        invoiceDetailsResponseDto.getPurchaseOrderDTO().getTaxpayerGstin());
        purchaseOrder.put(Constants.GSTIN_OF_SUPPLIER,
                        invoiceDetailsResponseDto.getPurchaseOrderDTO().getVendorGstin());
        // purchaseOrder.put(Constants.TITLE,
        // invoiceDetailsResponseDto.getPurchaseOrderDTO().getTitle());
        purchaseOrder.put(Constants.PO_NO, invoiceDetailsResponseDto.getPurchaseOrderDTO().getPoNo());
        purchaseOrder.put(Constants.PO_DATE, invoiceDetailsResponseDto.getPurchaseOrderDTO().getPoDate());

        Map<String, String> goodRecieiptNote = new HashMap<>();
        goodRecieiptNote.put(Constants.GSTIN_UIN_OF_RECIPIENT,
                        invoiceDetailsResponseDto.getGoodReceiptNoteDTO().getTaxpayerGstin());
        goodRecieiptNote.put(Constants.GSTIN_OF_SUPPLIER,
                        invoiceDetailsResponseDto.getGoodReceiptNoteDTO().getVendorGstin());
        // goodRecieiptNote.put(Constants.TITLE,
        // invoiceDetailsResponseDto.getGoodReceiptNoteDTO().getTitle());
        goodRecieiptNote.put(Constants.GRN_NO, invoiceDetailsResponseDto.getGoodReceiptNoteDTO().getGrnNo());
        goodRecieiptNote.put(Constants.GRN_DATE, invoiceDetailsResponseDto.getGoodReceiptNoteDTO().getGrnDate());

        Map<String, String> getGstr2aData = new HashMap<>();

        getGstr2aData.put(Constants.GSTIN_UIN_OF_RECIPIENT,
                        invoiceDetailsResponseDto.getGetGstr2aDTO().getTaxpayerGstin());
        getGstr2aData.put(Constants.GSTIN_OF_SUPPLIER, invoiceDetailsResponseDto.getGetGstr2aDTO().getVendorGstin());
        // getGstr2aData.put(Constants.TITLE,
        // invoiceDetailsResponseDto.getGetGstr2aDTO().getTitle());
        getGstr2aData.put(Constants.TAXABLE_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2aDTO().getTaxableAmount()));
        getGstr2aData.put(Constants.POS, invoiceDetailsResponseDto.getGetGstr2aDTO().getPlaceSupply());
        getGstr2aData.put(Constants.IGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2aDTO().getIgstAmount()));
        getGstr2aData.put(Constants.CGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2aDTO().getCgstAmount()));
        getGstr2aData.put(Constants.SGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2aDTO().getSgstAmount()));
        getGstr2aData.put(Constants.CESS_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2aDTO().getCessAmount()));
        getGstr2aData.put(Constants.INV_VALUE,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2aDTO().getInvoiceValue()));
        getGstr2aData.put(Constants.INVOICE_NO, invoiceDetailsResponseDto.getGetGstr2aDTO().getInvoiceNo());
        getGstr2aData.put(Constants.INVOICE_DATE, invoiceDetailsResponseDto.getGetGstr2aDTO().getInvoiceDate());
        getGstr2aData.put(Constants.IS_SYNC, invoiceDetailsResponseDto.getGetGstr2aDTO().isSync() ? "Yes" : "No");
        getGstr2aData.put(Constants.DEFAULTSYNCSTATUS,
                        invoiceDetailsResponseDto.getGetGstr2aDTO().isDefaultSyncStatus() ? "Yes" : "No");
        getGstr2aData.put(Constants.FORCESYNCSTATUS,
                        invoiceDetailsResponseDto.getGetGstr2aDTO().isForceSyncStatus() ? "Yes" : "No");

        Map<String, String> getGstr2bData = new HashMap<>();

        getGstr2bData.put(Constants.GSTIN_UIN_OF_RECIPIENT,
                        invoiceDetailsResponseDto.getGetGstr2bDTO().getTaxpayerGstin());
        getGstr2bData.put(Constants.GSTIN_OF_SUPPLIER, invoiceDetailsResponseDto.getGetGstr2bDTO().getVendorGstin());

        getGstr2bData.put(Constants.TAXABLE_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2bDTO().getTaxableAmount()));
        getGstr2bData.put(Constants.POS, invoiceDetailsResponseDto.getGetGstr2bDTO().getPlaceSupply());
        getGstr2bData.put(Constants.IGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2bDTO().getIgstAmount()));
        getGstr2bData.put(Constants.CGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2bDTO().getCgstAmount()));
        getGstr2bData.put(Constants.SGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2bDTO().getSgstAmount()));
        getGstr2bData.put(Constants.CESS_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2bDTO().getCessAmount()));
        getGstr2bData.put(Constants.INV_VALUE,
                        String.valueOf(invoiceDetailsResponseDto.getGetGstr2bDTO().getInvoiceValue()));
        getGstr2bData.put(Constants.INVOICE_NO, invoiceDetailsResponseDto.getGetGstr2bDTO().getInvoiceNo());
        getGstr2bData.put(Constants.INVOICE_DATE, invoiceDetailsResponseDto.getGetGstr2bDTO().getInvoiceDate());
        getGstr2bData.put(Constants.DEFAULTSYNCSTATUS,
                        invoiceDetailsResponseDto.getGetGstr2bDTO().isDefaultSyncStatus() ? "Yes" : "No");
        getGstr2bData.put(Constants.FORCESYNCSTATUS,
                        invoiceDetailsResponseDto.getGetGstr2bDTO().isForceSyncStatus() ? "Yes" : "No");

        Map<String, String> getGetEWayBillData = new HashMap<>();

        getGetEWayBillData.put(Constants.GSTIN_UIN_OF_RECIPIENT,
                        invoiceDetailsResponseDto.getGetEWayBillDTO().getTaxpayerGstin());
        getGetEWayBillData.put(Constants.GSTIN_OF_SUPPLIER,
                        invoiceDetailsResponseDto.getGetEWayBillDTO().getVendorGstin());

        getGetEWayBillData.put(Constants.TAXABLE_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetEWayBillDTO().getTaxableAmount()));
        getGetEWayBillData.put(Constants.POS, invoiceDetailsResponseDto.getGetEWayBillDTO().getPlaceSupply());
        getGetEWayBillData.put(Constants.IGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetEWayBillDTO().getIgstAmount()));
        getGetEWayBillData.put(Constants.CGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetEWayBillDTO().getCgstAmount()));
        getGetEWayBillData.put(Constants.SGST_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetEWayBillDTO().getSgstAmount()));
        getGetEWayBillData.put(Constants.CESS_AMOUNT,
                        String.valueOf(invoiceDetailsResponseDto.getGetEWayBillDTO().getCessAmount()));
        getGetEWayBillData.put(Constants.INV_VALUE,
                        String.valueOf(invoiceDetailsResponseDto.getGetEWayBillDTO().getInvValue()));
        getGetEWayBillData.put(Constants.INVOICE_NO, invoiceDetailsResponseDto.getGetEWayBillDTO().getInvoiceNo());
        getGetEWayBillData.put(Constants.INVOICE_DATE, invoiceDetailsResponseDto.getGetEWayBillDTO().getInvoiceDate());
        getGetEWayBillData.put(Constants.E_WAY_BILL_NO, invoiceDetailsResponseDto.getGetEWayBillDTO().getEwbNo());
        getGetEWayBillData.put(Constants.E_WAY_BILL_DATE, invoiceDetailsResponseDto.getGetEWayBillDTO().getEwbDate());
        getGetEWayBillData.put(Constants.STATUS,
                        invoiceDetailsResponseDto.getGetEWayBillDTO().isStatus() ? "Yes" : "No");
        getGetEWayBillData.put(Constants.DEFAULTSYNCSTATUS,
                        invoiceDetailsResponseDto.getGetEWayBillDTO().isDefaultSyncStatus() ? "Yes" : "No");
        getGetEWayBillData.put(Constants.FORCESYNCSTATUS,
                        invoiceDetailsResponseDto.getGetEWayBillDTO().isForceSyncStatus() ? "Yes" : "No");

        Map<String, String> ocrDetails = new HashMap<>();

        ocrDetails.put(Constants.GSTIN_UIN_OF_RECIPIENT, invoiceDetailsResponseDto.getOcrDetail().getTaxpayerGstin());
        ocrDetails.put(Constants.GSTIN_OF_SUPPLIER, invoiceDetailsResponseDto.getOcrDetail().getVendorGstin());
        ocrDetails.put(Constants.DOC_DATE, invoiceDetailsResponseDto.getOcrDetail().getDataType());
        ocrDetails.put(Constants.INVOICE_NO, invoiceDetailsResponseDto.getOcrDetail().getInvoiceNo());
        ocrDetails.put(Constants.INVOICE_DATE, invoiceDetailsResponseDto.getOcrDetail().getInvoiceDate());
        ocrDetails.put(Constants.TAXABLE_AMOUNT, invoiceDetailsResponseDto.getOcrDetail().getTaxableAmount());
        ocrDetails.put(Constants.IGST_AMOUNT, invoiceDetailsResponseDto.getOcrDetail().getIgstAmount());
        ocrDetails.put(Constants.SGST_AMOUNT, invoiceDetailsResponseDto.getOcrDetail().getSgstAmount());
        ocrDetails.put(Constants.CGST_AMOUNT, invoiceDetailsResponseDto.getOcrDetail().getCgstAmount());
        ocrDetails.put(Constants.CESS_AMOUNT, invoiceDetailsResponseDto.getOcrDetail().getCessAmount());
        ocrDetails.put(Constants.INV_VALUE, invoiceDetailsResponseDto.getOcrDetail().getInvoiceValue());
        ocrDetails.put(Constants.E_WAY_BILL_NO, invoiceDetailsResponseDto.getOcrDetail().getEwaybillNo());
        ocrDetails.put(Constants.E_WAY_BILL_DATE, invoiceDetailsResponseDto.getOcrDetail().getEwaybillDate());
        ocrDetails.put(Constants.IRN, invoiceDetailsResponseDto.getOcrDetail().getIrnNo());
        ocrDetails.put(Constants.IRN_DATE, invoiceDetailsResponseDto.getOcrDetail().getIrnDate());
        ocrDetails.put(Constants.INVOICE_TYPE, invoiceDetailsResponseDto.getOcrDetail().getInvoiceType());
        ocrDetails.put(Constants.VENDOR_NAME, invoiceDetailsResponseDto.getOcrDetail().getVendorName());
        ocrDetails.put(Constants.FILE_NAME_HEADER, invoiceDetailsResponseDto.getOcrDetail().getFileName());
        ocrDetails.put(Constants.EXTRACTION, String.valueOf(invoiceDetailsResponseDto.getOcrDetail().getExtraction()));
        ocrDetails.put(Constants.COMPLIANCE, String.valueOf(invoiceDetailsResponseDto.getOcrDetail().getCompliance()));

        try (XSSFWorkbook wb = new XSSFWorkbook()) {

            XSSFSheet sheet = wb.createSheet(Constants.VENDOR_INVOICE_DETAILS_HEADING);
            ExcelUtils.setFilterAndFredgeHeader(sheet, new CellRangeAddress(1, 1, 0, 36));
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 36));
            Map<String, Object> bothHeadersStyles = ExcelUtils.getHeadersStyles(wb, sheet);
            CellStyle headerCellStyle1 = (CellStyle) bothHeadersStyles.get(Constants.HEADERCELLSTYLE1);
            CellStyle headerCellStyle2 = (CellStyle) bothHeadersStyles.get(Constants.HEADERCELLSTYLE2);
            CellStyle headerCellStyle3 = (CellStyle) bothHeadersStyles.get(Constants.HEADERCELLSTYLE3);

            Row row0 = sheet.createRow(0);
            Cell headerCell = row0.createCell(0);
            headerCell.setCellValue(Constants.VENDOR_INVOICE_DETAILS_HEADING);
            headerCell.setCellStyle(headerCellStyle1);

            Row row1 = sheet.createRow(1);
            Row row2 = sheet.createRow(2);
            Row row3 = sheet.createRow(3);
            Row row4 = sheet.createRow(4);
            Row row5 = sheet.createRow(5);
            Row row6 = sheet.createRow(6);
            Row row7 = sheet.createRow(7);
            Row row8 = sheet.createRow(8);
            Row row9 = sheet.createRow(9);
            int index = 1;

            Cell cell0 = row1.createCell(0);
            cell0.setCellValue("Data Type");
            cell0.setCellStyle(headerCellStyle2);
            Cell cell1 = row2.createCell(0);
            cell1.setCellValue("e-Invoice");
            cell1.setCellStyle(headerCellStyle3);
            Cell cell2 = row3.createCell(0);
            cell2.setCellValue("e-Way Bill");
            cell2.setCellStyle(headerCellStyle3);
            Cell cell3 = row4.createCell(0);
            cell3.setCellValue("Purchase Order");
            cell3.setCellStyle(headerCellStyle3);
            Cell cell4 = row5.createCell(0);
            cell4.setCellValue("Goods Receipt Note");
            cell4.setCellStyle(headerCellStyle3);
            Cell cell5 = row6.createCell(0);
            cell5.setCellValue("GET GSTR2A");
            cell5.setCellStyle(headerCellStyle3);
            Cell cell6 = row7.createCell(0);
            cell6.setCellValue("GET GSTR2B");
            cell6.setCellStyle(headerCellStyle3);
            Cell cell7 = row8.createCell(0);
            cell7.setCellValue("GET e-Way Bill");
            cell7.setCellStyle(headerCellStyle3);
            Cell cell8 = row9.createCell(0);
            cell8.setCellValue("OCR Details");
            cell8.setCellStyle(headerCellStyle3);

            for (String header : vendorInvoiceAllHeaders) {

                Cell headercell = row1.createCell(index);
                headercell.setCellValue(header);
                headercell.setCellStyle(headerCellStyle2);

                String eInvoiceDataAccToHeader = eInvoiceData.get(header);
                Cell eInvoicecell = row2.createCell(index);
                eInvoicecell.setCellValue(eInvoiceDataAccToHeader);
                eInvoicecell.setCellStyle(headerCellStyle3);

                String eWayDataAccToHeader = eWayBillData.get(header);
                Cell eWaycell = row3.createCell(index);
                eWaycell.setCellValue(eWayDataAccToHeader);
                eWaycell.setCellStyle(headerCellStyle3);

                String purchaseOrderAccToHeader = purchaseOrder.get(header);
                Cell purchaseOrdercell = row4.createCell(index);
                purchaseOrdercell.setCellValue(purchaseOrderAccToHeader);
                purchaseOrdercell.setCellStyle(headerCellStyle3);

                String goodReceiptNoteDataAccToHeader = goodRecieiptNote.get(header);
                Cell goodReceiptNotecell = row5.createCell(index);
                goodReceiptNotecell.setCellValue(goodReceiptNoteDataAccToHeader);
                goodReceiptNotecell.setCellStyle(headerCellStyle3);

                String gstr2aDataAccToHeader = getGstr2aData.get(header);
                Cell gstr2acell = row6.createCell(index);
                gstr2acell.setCellValue(gstr2aDataAccToHeader);
                gstr2acell.setCellStyle(headerCellStyle3);

                String gstr2bDataAccToHeader = getGstr2bData.get(header);
                Cell gstr2bcell = row7.createCell(index);
                gstr2bcell.setCellValue(gstr2bDataAccToHeader);
                gstr2bcell.setCellStyle(headerCellStyle3);

                String getEwayBillDataAccToHeader = getGetEWayBillData.get(header);
                Cell getEWayBillcell = row8.createCell(index);
                getEWayBillcell.setCellValue(getEwayBillDataAccToHeader);
                getEWayBillcell.setCellStyle(headerCellStyle3);

                String getOCRDetailsDataAccToHeader = ocrDetails.get(header);
                Cell getOCRDetailscell = row9.createCell(index);
                getOCRDetailscell.setCellValue(getOCRDetailsDataAccToHeader);
                getOCRDetailscell.setCellStyle(headerCellStyle3);

                index++;

            }
            for (int i = 0; i <= 36; i++) {
                sheet.autoSizeColumn(i);
            }

            String tempfilePath = new StringBuilder().append(tempFolder).append(File.separator)
                            .append(ExcelUtils.getReportsExcelFileName(Constants.VENDOR_INVOICE_DETAILS,
                                            new Timestamp(System.currentTimeMillis())))
                            .toString();

            if (StringUtils.isBlank(tempFolder)) {
                tempfilePath = new StringBuilder()
                                .append(ExcelUtils.getReportsExcelFileName(Constants.VENDOR_INVOICE_DETAILS,
                                                new Timestamp(System.currentTimeMillis())))
                                .toString();
            }

            File file = new File(tempfilePath);

            if (file.exists()) {
                FileUtils.deleteQuietly(file);
            }
            try (FileOutputStream out = new FileOutputStream(file)) {
                wb.write(out);
                out.close();
            }

            return file;
        }

    }

    /**
     * Gets the force sync list.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the force sync list
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    public Map<String, Object> getForceSyncList(InvoiceDetailsReqDTO invoiceDetailsReqDTO)
                    throws VendorInvoiceServerException {

        int getTypepldCode;

        if (("gstr2a").equals(invoiceDetailsReqDTO.getDetailType())) {
            getTypepldCode = Constants.GET_GSTR2A_PLD_CODE;
        } else if (("gstr2b").equals(invoiceDetailsReqDTO.getDetailType())) {
            getTypepldCode = Constants.GET_GSTR2B_PLD_CODE;
        } else if (("geteWayBill").equals(invoiceDetailsReqDTO.getDetailType())) {
            getTypepldCode = Constants.GET_EWAYBILL_PLD_CODE;
        } else {
            throw new VendorInvoiceServerException("INVALID GET TYPE");
        }

        Map<String, Object> response = new LinkedHashMap<>();
        List<Gstr2aSyncUnsyncDTO> syncData = syncOperationDataListDao.getsyncData(invoiceDetailsReqDTO, getTypepldCode);
        List<Gstr2aSyncUnsyncDTO> unsyncDataList = syncOperationDataListDao.getUnsyncDataList(invoiceDetailsReqDTO,
                        getTypepldCode);
        int totalElements = syncOperationDataListDao.getCountUnsyncDataList(invoiceDetailsReqDTO, getTypepldCode);
        int page = invoiceDetailsReqDTO.getPage();
        Gstr2HeaderDTOForForceSync headerDataForForceSync = syncOperationDataListDao
                        .getInvoiceHeaderDetailsForForceSync(invoiceDetailsReqDTO);
        response.put("page", page);
        response.put("totalElements", totalElements);
        response.put("syncData", syncData);
        response.put("unsyncDataList", unsyncDataList);
        response.put(Constants.HEADERDATA, headerDataForForceSync);
        return response;

    }

    /**
     * Gets the gets the eway bill view details.
     *
     * @param getEwayBillDetailsRequestDTO
     *            the get eway bill details request DTO
     * @return the gets the eway bill view details
     * @throws InvoiceIntegrationEWBException
     *             the invoice integration EWB exception
     */
    @Override
    public Object getGetEwayBillViewDetails(GetEwayBillDetailsRequestDTO getEwayBillDetailsRequestDTO)
                    throws InvoiceIntegrationEWBException {

        Map<String, Object> response = new LinkedHashMap<>();

        if (("1").equals(getEwayBillDetailsRequestDTO.getTabId())) {
            response.put("headerData", vendorInvoiceDetailsRepository
                            .getEwayBillBasicInfoHeaderData(getEwayBillDetailsRequestDTO.getEwaybillNo()));
            response.put("billFrom", vendorInvoiceDetailsRepository
                            .getEwayBillBasicInfoBillFromDetails(getEwayBillDetailsRequestDTO.getEwaybillNo()));
            response.put("billTo", vendorInvoiceDetailsRepository
                            .getEwayBillBasicInfoBillToDetails(getEwayBillDetailsRequestDTO.getEwaybillNo()));
            response.put("dispatchFrom", vendorInvoiceDetailsRepository
                            .getEwayBillBasicInfoDispatchFromDetails(getEwayBillDetailsRequestDTO.getEwaybillNo()));
            response.put("shipTo", vendorInvoiceDetailsRepository
                            .getEwayBillBasicInfoShipToDetails(getEwayBillDetailsRequestDTO.getEwaybillNo()));

        } else if (("2").equals(getEwayBillDetailsRequestDTO.getTabId())) {

            response.put("totalElementsCount", vendorInvoiceDetailsRepository
                            .getEwayBillItemDetailsListDataCount(getEwayBillDetailsRequestDTO));

            response.put("headerData", vendorInvoiceDetailsRepository
                            .getEwayBillItemDetailsHeaderData(getEwayBillDetailsRequestDTO.getEwaybillNo()));
            response.put("itemGridData", vendorInvoiceDetailsRepository
                            .getEwayBillItemDetailsListData(getEwayBillDetailsRequestDTO));

        } else if (("3").equals(getEwayBillDetailsRequestDTO.getTabId())) {

            response.put("partA", vendorInvoiceDetailsRepository
                            .getEwayBillITransportDetaiLPartAData(getEwayBillDetailsRequestDTO.getEwaybillNo()));
            response.put("partB", vendorInvoiceDetailsRepository
                            .getEwayBillITransportDetaiLPartBData(getEwayBillDetailsRequestDTO.getEwaybillNo()));

        } else if (("4").equals(getEwayBillDetailsRequestDTO.getTabId())) {

            return vendorInvoiceDetailsRepository
                            .getEwayBillIAdditionalInfoData(getEwayBillDetailsRequestDTO.getEwaybillNo());

        } else {
            throw new InvoiceIntegrationEWBException("Invalid Tab Id");
        }
        return response;

    }

    /**
     * Gets the gets the existing EWB details.
     *
     * @param vendorInvoiceGETRequestDTO
     *            the vendor invoice GET request DTO
     * @return the gets the existing EWB details
     * @throws InvoiceIntegrationEWBException
     *             the invoice integration EWB exception
     */
    @Override
    public Object getGetExistingEWBDetails(VendorInvoiceGETRequestDTO vendorInvoiceGETRequestDTO)
                    throws InvoiceIntegrationEWBException {

        Map<String, Object> response = new LinkedHashMap<String, Object>();
        int totalElementsCount = 0;
        List<VendorInvoiceGetResponseDTO> dataList = vendorInvoiceDetailsRepository
                        .getGetExistingEWBdetails(vendorInvoiceGETRequestDTO);
        if (dataList != null) {
            totalElementsCount = dataList.get(0).getTotalElementsCount();
        }
        response.put("totalPageElements", totalElementsCount);
        response.put("vendorInvoiceEwayBillGetData", dataList);
        return response;

    }

    /**
     * Async call for get ewaybill data from govt ewb api
     *
     * @param vendorInvoiceGETRequestDTO
     *            the vendor invoice GET request DTO
     * @throws InvoiceIntegrationEWBException
     *             the invoice integration EWB exception
     */

    @Override
    @Async
    public String callForGetEwaybillDetailsByDate(GetEwayBillReqDTO reqDto) {
        try {
            getEwayBillDetailsByDateServiceImpl.getEwayBillDetails(reqDto);
        } catch (Exception ex) {
            log.error("no records found for date -" + reqDto.getEwaybillDate());
            return "No Inward Invoices found for date " + reqDto.getEwaybillDate();
        }
        return "Fetching e-way details from NIC, please wait or system will notify after the process is completed";

    }

    @Override
    @Async
    public String callForGetEwaybillDetailsOtherParty(GetEwayBillReqDTO reqDto) {
        String toDateFormat = "dd-MM-yyyy";
        String fromDateFormat = "yyyy-MM-dd";
        String date = null;

        int checkCount = 0;
        LocalDate localDate = LocalDate.now();

        if (StringUtils.isNotBlank(reqDto.getEwaybillDate())) {

            String[] datechar = reqDto.getEwaybillDate().split("-");
            String ewayBillDateFormat = datechar[0] + "-" + datechar[1] + "-" + datechar[2];

            try {
                reqDto.setEwaybillDate(ewayBillDateFormat);
                getEwayBillDetailsOtherPartyServiceImpl.getEwayBillDetails(reqDto);

            } catch (InvoiceIntegrationEWBException e) {
                checkCount++;
                log.error("Exception generated for otherparty call for date :" + reqDto.getEwaybillDate());
                log.error("Exception generated for otherparty call for date :", e);
            }
        } else {

            for (int i = 1; i <= 3; i++) {
                date = DateUtil.convertDateFormat(fromDateFormat, toDateFormat, String.valueOf(localDate.minusDays(i)));
                reqDto.setEwaybillDate(date);
                try {
                    getEwayBillDetailsOtherPartyServiceImpl.getEwayBillDetails(reqDto);
                } catch (Exception ex) {
                    log.error("No data for taxpayer gstin: " + reqDto.getTaxpayerGstin() + " for date: "
                                    + reqDto.getEwaybillDate() + "|| Error Message>> " + ex.getMessage());
                    checkCount++;
                }
            }
        }
        if (checkCount > 2) {
            return "No data found for last 3 days";
        }
        return "get ewaybill details successfully";

    }

    @Override
    public String callForGetEwaybillDetails(GetEwayBillReqDTO reqDto) throws InvoiceIntegrationEWBException {

        try {
            getEwayBillDetailsServiceImpl.getEwayBillDetails(reqDto);
        } catch (Exception ex) {
            log.error(ex.getMessage());
            return ex.getMessage();
        }

        return "E-Way Bill Get operation completed successfully";

    }

    /**
     * Gets the ewaybill view.
     *
     * @param ewbViewDTO
     *            the ewb view DTO
     * @return the ewaybill view
     * @throws InvoiceIntegrationEWBException
     *             the invoice integration EWB exception
     */
    @Override
    public Object getEwaybillView(EWBViewDTO ewbViewDTO) throws InvoiceIntegrationEWBException {
        Map<String, Object> response = new LinkedHashMap<String, Object>();
        response.put("totalPageElements", vendorInvoiceDetailsRepository.getEwaybillViewCount(ewbViewDTO));
        response.put("ewbViewList", vendorInvoiceDetailsRepository.getEwaybillView(ewbViewDTO));
        return response;
    }

    /**
     * Send wf approve or reject.
     *
     * @param wfApproveOrRejectDTO
     *            the wf approve or reject DTO
     * @return the string
     */
    @Override
    public String sendWfApproveOrReject(@Valid WfApproveOrRejectDTO wfApproveOrRejectDTO) {
        return vendorInvoiceDetailsRepository.sendWfApprovedOrRegectDataToDb(wfApproveOrRejectDTO);

    }

}
