package com.bdo.bvms.einvoice.service;

import java.io.File;
import java.io.IOException;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.InvoiceDetailsReqDTO;

public interface VendorInvoiceVendorDetailsService {

    /**
     * Gets the download invoice details.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the download invoice details
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    File getDownloadInvoiceDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO)
                    throws VendorInvoiceServerException, IOException;

}
