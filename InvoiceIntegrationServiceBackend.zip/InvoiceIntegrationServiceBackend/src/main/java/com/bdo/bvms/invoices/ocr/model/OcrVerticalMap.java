package com.bdo.bvms.invoices.ocr.model;

import java.util.Date;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class OcrVerticalMap {

    Integer id;
    Integer fileId;
    Integer ocrVendorTemplateMstId;
    Integer ocrFieldMstId;
    String ocrExtractedValue;
    Integer ocrAccuracyLvl;
    Integer ocrAccuracyLvlValue;
    Integer isTaxpayer;
    Date createdAt;
    Integer createdBy;
    String filePath;
    Integer lineNo;
    Integer isHeader;
    String name;
   
    
    // ocr_filed_master data
    Integer minLength;
    Integer maxLength;
    Boolean isMandatory;
    String regex;
    String type;
    Integer riskCategory;
    Integer pldType;
    Boolean isAmountField;
    int order;
    
    
}
