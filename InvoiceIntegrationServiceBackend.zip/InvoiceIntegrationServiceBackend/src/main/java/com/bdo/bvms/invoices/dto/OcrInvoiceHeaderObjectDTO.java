package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OcrInvoiceHeaderObjectDTO {

    int id;
    String pldOcrConfidenceId;
    String customerName;
    String customerGstin;
    String customerAddress;
    String supplierName;
    String supplierGstin;
    String supplierAddress;
    String vendorCode;
    String invoiceNo;
    String invoiceDate;
    String poNumber;
    String cgstAmt;
    String cgstP;
    String sgstAmt;
    String sgstP;
    String igstAmt;
    String igstP;
    String cessAmt;
    String cessP;
    String ugstAmt;
    String ugstP;
    String tcsAmt;
    String tcsP;
    String vatAmt;
    String vatP;
    String totalAmt;

}
