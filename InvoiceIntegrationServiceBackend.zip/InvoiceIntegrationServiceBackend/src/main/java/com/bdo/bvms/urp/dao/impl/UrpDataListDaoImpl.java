package com.bdo.bvms.urp.dao.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.sql.CommonSql;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.PowerAutomateRequestBody;
import com.bdo.bvms.invoices.dto.ProcessedListDataResDTO;
import com.bdo.bvms.invoices.dto.UrpListDataResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.invoices.util.CommonUtils;
import com.bdo.bvms.urp.dao.UrpDataListDao;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Repository
public class UrpDataListDaoImpl implements UrpDataListDao{

	@Autowired
    CommonDao commonDao;
	
	@Autowired
    JdbcTemplate jdbcTemplateMst;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;
	
	@Override
	public List<UrpListDataResDTO> getUrpDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
			String monthList) throws VendorInvoiceServerException {
		

        try {
            Map<String, String> screenAliasMap = commonDao.getSchreeAliasMap(vendorInvoiceRequestDTO);
            String whereCondition = CommonUtils.getWhereCondition(vendorInvoiceRequestDTO.getAdvanceFilter(),
                            screenAliasMap);
            Map<String, Object> out = commonDao.getGridDataUrp(vendorInvoiceRequestDTO, gstinNewList,
                            monthList, whereCondition);
            List<UrpListDataResDTO> dataResList = new ArrayList<>();
            int totalCount = ((List<Map<String, Long>>) out.get("#result-set-" + 2)).get(0).get("total_count")
					.intValue();
            List<Map<String, Object>> results = (List<Map<String, Object>>) out.get("#result-set-" + 1);
           
            results.forEach(u -> {
            	UrpListDataResDTO dataRes = new UrpListDataResDTO();
                dataRes.setId(Integer.valueOf(u.get("id").toString()));
                dataRes.setTaxpayerGstin(checkNullValue((String) u.get("taxpayer_gstin")));
                dataRes.setVendorPan(checkNullValue((String) u.get("vendor_pan")));
                dataRes.setVendorCodeErp(checkNullValue((String) u.get("vendor_code_erp")));
                dataRes.setVendorLegalName(checkNullValue((String) u.get("vendor_legal_name")));
                dataRes.setVendorTradeName(checkNullValue((String) u.get("vendor_trade_name")));
                dataRes.setInvoiceNo(checkNullValue((String) u.get("invoice_no")));
                dataRes.setInvoiceDate(checkNullValue((String) u.get("invoice_date")));
                dataRes.setTaxableAmount(checkNullValue(String.valueOf(u.get("taxable_value"))));//taxable_value
                dataRes.setIgst(checkNullValue(String.valueOf(u.get("igst"))));//igst
                dataRes.setSgst(checkNullValue(String.valueOf(u.get("sgst"))));//sgst
                dataRes.setCgst(checkNullValue(String.valueOf(u.get("cgst"))));//cgst
                dataRes.setCess(checkNullValue(String.valueOf(u.get("cess"))));//cess
                dataRes.setInvoiceValue(checkNullValue(String.valueOf(u.get("invoice_value"))));//invoice_value
                dataRes.setQrCodeValid(String.valueOf(u.get("qr_code_valid")));
                dataRes.setEwayBillNo(checkNullValue((String) u.get("eway_bill_no")));
                dataRes.setEwayBillDate(checkNullValue((String) u.get("eway_bill_date")));
                dataRes.setPoNumber(checkNullValue((String) u.get("po_number")));
                dataRes.setGrnNumber(checkNullValue((String) u.get("grn_no")));
                dataRes.setUploadDate((LocalDateTime) u.get("details_upload_date"));//not coming
                dataRes.setBookedErp(checkNullValue((String) u.get("booked_erp")));
                dataRes.setTotalCount(totalCount);
                dataRes.setDataType(checkNullValue((String) u.get("doc_type")));
                //dataRes.setTotalPOCount((Integer) (u.get("purchase_order_count")));
                dataRes.setIrnVerified(checkNullValue((String) u.get("status")));//not coming
                dataRes.setBatchNo(checkNullValue((String) u.get("status")));
                dataRes.setBatchNo(checkNullValue((String) u.get("batch_no")));
                dataRes.setOcrFileId(u.get("ocr_header_file_id") != null ? Integer.valueOf(u.get("ocr_header_file_id").toString()) : null);

                dataResList.add(dataRes);
            });

            return dataResList;
        } catch (DataAccessException e) {
            log.info("Error occurs at the time of fetching data from database in Processed invoice tab.", e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATIONGRIDDATA);
            exceptionLogDTO.setFunctionName("getProcessedInvoiceDataList");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming
            // in this function to getting data from database.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException(
                            "Error coming at the time of getting data from database in Processed invoice tab.",
                            e.getCause());

        }
    
		
	}
	
	  private static String checkNullValue(String value) {
	        if (StringUtils.isEmpty(value)) {
	            return "-";
	        } else {
	            return value;
	        }
	    }

	@Override
	public void updateEmailDocumentReceivedPullLog(String powerAutoJson) {
		jdbcTemplateTrn.update(CommonSql.UPDATE_URP_TABLE,powerAutoJson);
		
	}

	@Override
	public void updateEmailDocumentReceivedErrorLog(PowerAutomateRequestBody powerAutomateRequestBody,String message) {
		//user_id,entity_id,taxpayer_gstin,email_from,received_on,error_message,is_vendor,created_at,created_by
		jdbcTemplateTrn.update(CommonSql.UPDATE_ERROR_TABLE,powerAutomateRequestBody.getUserId(),powerAutomateRequestBody.getEntityId(),powerAutomateRequestBody.getGstin(),powerAutomateRequestBody.getEmailFrom(),
				message,powerAutomateRequestBody.getIsVendor(),powerAutomateRequestBody.getUserId());
	}

}
