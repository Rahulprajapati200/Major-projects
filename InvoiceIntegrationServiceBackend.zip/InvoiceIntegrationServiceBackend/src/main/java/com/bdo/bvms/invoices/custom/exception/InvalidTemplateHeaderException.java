package com.bdo.bvms.invoices.custom.exception;

public class InvalidTemplateHeaderException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidTemplateHeaderException() {
		super();
	}

	public InvalidTemplateHeaderException(Throwable cause) {

		super(cause);

	}

	public InvalidTemplateHeaderException(String message, Throwable cause) {

		super(message, cause);

	}

	public InvalidTemplateHeaderException(String message) {
		super(message);
	}

}
