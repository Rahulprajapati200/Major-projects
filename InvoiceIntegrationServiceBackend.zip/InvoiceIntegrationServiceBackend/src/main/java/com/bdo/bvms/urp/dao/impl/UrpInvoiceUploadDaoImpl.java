package com.bdo.bvms.urp.dao.impl;

import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.ewaybill.api.sql.Transactions;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.taxpayer.sql.URPFileSql;
import com.bdo.bvms.ocr.SQL.FileOcrSql;
import com.bdo.bvms.urp.dao.UrpInvoiceUploadDao;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class UrpInvoiceUploadDaoImpl implements UrpInvoiceUploadDao{
	
	@Autowired
	private JdbcTemplate jdbcTemplateTrn;
	@Autowired
    private JdbcTemplate jdbcTemplateMst;
	
	@Override
    public void insertToUrpOcrHeader(List<EInvoiceTemplateDTO> data,UploadReqDTO uploadDTO) throws VendorInvoiceServerException {

        jdbcTemplateTrn.batchUpdate(URPFileSql.INSERT_TO_URP_OCR_HEADER_TABLE, data, 100,
                        (PreparedStatement ps, EInvoiceTemplateDTO item) -> {
                            ps.setString(1, item.getGstinUinOfRecipient());
                            ps.setString(2, item.getGstinOfSupplier());
                            ps.setString(3, uploadDTO.getVendorPanOrGstin());
                            ps.setString(4, uploadDTO.getVendorCode());
                            ps.setInt(5, 0);
                            ps.setString(6, item.getDocType());
                            ps.setString(7, item.getInwardNo());
                            ps.setString(8, item.getInwardDate());
                            ps.setString(9,  item.getPurchaseOrderNumber());
                            ps.setString(10, item.getPurchaseOrderDate());
                            ps.setString(11, item.getPanOfRecipient());
                            ps.setString(12, uploadDTO.getBatchNo());
                            ps.setString(13, item.getFillingPeriod());
                            ps.setString(14, Timestamp.from(Instant.now()).toString());
                            ps.setInt(15, uploadDTO.getUserId());
                            ps.setInt(16, 0);
                            ps.setInt(17, 0);

                        });
      }
	
	@Override
	 public Integer getYearIdByFp(String fp) {

	        try {
	            return jdbcTemplateMst.queryForObject(Transactions.GET_YEAR_ID_BY_FP, int.class, fp);
	        } catch (Exception e) {
	            log.error("Exception generated ::", e);
	            return null;
	        }

	    }

}
