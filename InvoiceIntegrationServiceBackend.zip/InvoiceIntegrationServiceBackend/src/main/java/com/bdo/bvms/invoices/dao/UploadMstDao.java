package com.bdo.bvms.invoices.dao;

import java.util.HashMap;
import java.util.List;

import com.bdo.bvms.invoices.dto.EWayBillDTO;

public interface UploadMstDao {

    HashMap<String, String> getErrorCodeMap();

    List<EWayBillDTO> getNewErrorList(List<EWayBillDTO> errorlist);

}
