package com.bdo.bvms.invoices.controller.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.BatchUpdateException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.bvms.common.service.UrpMailFileUploadService;
import com.bdo.bvms.einvoice.service.ProcessUploadService;
import com.bdo.bvms.einvoice.service.VendorInvoiceDataListService;
import com.bdo.bvms.einvoice.service.VendorInvoiceDetailsService;
import com.bdo.bvms.einvoice.service.VendorInvoiceUploadLogHistoryService;
import com.bdo.bvms.ewaybill.api.GetEwayBillDetailsService;
import com.bdo.bvms.ewaybill.api.demo.impl.GetEwayBillDemo;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.ewaybill.api.impl.GetEwayBillDetailsByDateServiceImpl;
import com.bdo.bvms.ewaybill.api.impl.GetEwayBillDetailsOtherPartyServiceImpl;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.controller.VendorInvoiceTaxpayerController;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.APIResponseDTO;
import com.bdo.bvms.invoices.dto.EWBViewDTO;
import com.bdo.bvms.invoices.dto.GetEwayBillDetailsRequestDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsReqDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsResponseDto;
import com.bdo.bvms.invoices.dto.PowerAutomateRequestBody;
import com.bdo.bvms.invoices.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.invoices.dto.UploadHistoryResponseDTO;
import com.bdo.bvms.invoices.dto.UploadLogHistoryResDataDto;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceGETRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceResponseDTO;
import com.bdo.bvms.invoices.dto.WfApproveOrRejectDTO;
import com.bdo.bvms.ocr.dto.FileResults;
import com.bdo.bvms.ocr.dto.OcrBatchResponseReqDto;
import com.bdo.bvms.ocr.service.FileOcrProcessAndSaveService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class VendorInvoiceTaxpayerControllerImpl.
 */
@RestController
@RequestMapping("/invoice")

/** The Constant log. */
@Slf4j
public class VendorInvoiceTaxpayerControllerImpl implements VendorInvoiceTaxpayerController {

    /** The upload service. */
    @Autowired
    ProcessUploadService uploadService;

    /** The vendor invoice data list service. */
    @Autowired
    VendorInvoiceDataListService vendorInvoiceDataListService;

    /** The vendor invoice details service. */
    @Autowired
    VendorInvoiceDetailsService vendorInvoiceDetailsService;

    /** The vendor invoice upload log history service. */
    @Autowired
    VendorInvoiceUploadLogHistoryService vendorInvoiceUploadLogHistoryService;

    /** The get eway bill details service impl. */
    @Autowired
    GetEwayBillDetailsService getEwayBillDetailsServiceImpl;

    /** The get eway bill details other party service impl. */
    @Autowired
    GetEwayBillDetailsOtherPartyServiceImpl getEwayBillDetailsOtherPartyServiceImpl;

    /** The get eway bill details by date service impl. */
    @Autowired
    GetEwayBillDetailsByDateServiceImpl getEwayBillDetailsByDateServiceImpl;

    /** Get and save data of file ocr service impl. */
    @Autowired
    FileOcrProcessAndSaveService fileOcrProcessAndSaveService;
    
    @Autowired
    GetEwayBillDemo getEwayBillDemo;
    
    @Autowired
    UrpMailFileUploadService urpMailFileUploadService;

    /**
     * Upload file.
     *
     * @param request
     *            the request
     * @param uploadRequestDTO
     *            the upload request DTO
     * @return the response entity
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    @PostMapping("/upload-file")
    public ResponseEntity<APIResponseDTO> uploadFile(HttpServletRequest request,
                    @ModelAttribute UploadRequestDTO uploadRequestDTO) throws VendorInvoiceServerException {

        String fileStatus = uploadService.uploadAndProcessFile(uploadRequestDTO);

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(HttpStatus.OK.value()).message(fileStatus)
                        .tag(request.getRequestURI()).build());

    }

    /**
     * Gets the data list.
     *
     * @param request
     *            the request
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @return the data list
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    @PostMapping("/vendorInvoice-datalist")
    public ResponseEntity<VendorInvoiceResponseDTO> getDataList(HttpServletRequest request,
                    @RequestBody VendorInvoiceRequestDTO vendorInvoiceRequestDTO) throws VendorInvoiceServerException {

        Map<String, Object> data = vendorInvoiceDataListService.getDataGrid(vendorInvoiceRequestDTO);

        return ResponseEntity.ok()
                        .body(VendorInvoiceResponseDTO.builder().status(1)
                                        .message("Search operation completed successfully")
                                        .messageDescription(request.getRequestURI()).data(data).build());

    }

    /**
     * Log history.
     *
     * @param request
     *            the request
     * @param requestDTO
     *            the request DTO
     * @return the response entity
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    @PostMapping(value = "/upload-log-datalist")
    public ResponseEntity<UploadHistoryResponseDTO> logHistory(HttpServletRequest request,
                    @RequestBody UploadHistoryRequestDTO requestDTO) throws VendorInvoiceServerException {

        List<UploadLogHistoryResDataDto> uploadLogHistoryResDataDto = vendorInvoiceUploadLogHistoryService
                        .getHistoryList(requestDTO);

        return ResponseEntity.ok()
                        .body(UploadHistoryResponseDTO.builder().status(1).message("History data is uploaded.")
                                        .messageDescription(request.getRequestURI()).data(uploadLogHistoryResDataDto)
                                        .build());

    }

    /**
     * Gets the invoice details.
     *
     * @param request
     *            the request
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the invoice details
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    @PostMapping(value = "/invoice-details")
    public ResponseEntity<VendorInvoiceResponseDTO> getInvoiceDetails(HttpServletRequest request,
                    @RequestBody InvoiceDetailsReqDTO invoiceDetailsReqDTO) throws VendorInvoiceServerException {

        InvoiceDetailsResponseDto invoiceDetailsResponseDto = vendorInvoiceDetailsService
                        .getInvoiceDetails(invoiceDetailsReqDTO);

        return ResponseEntity.ok().body(VendorInvoiceResponseDTO.builder().status(1)
                        .message("Search operation completed successfully").messageDescription(request.getRequestURI())
                        .data(invoiceDetailsResponseDto).build());

    }

    /**
     * Gets the invoice line item view details.
     *
     * @param request
     *            the request
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the invoice line item view details
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    @PostMapping(value = "/invoice-item-details")
    public ResponseEntity<VendorInvoiceResponseDTO> getInvoiceLineItemViewDetails(HttpServletRequest request,
                    @RequestBody InvoiceDetailsReqDTO invoiceDetailsReqDTO) throws VendorInvoiceServerException {

        Object invoiceDetailsResponseDto = vendorInvoiceDetailsService
                        .getInvoiceLineItemViewDetails(invoiceDetailsReqDTO);

        return ResponseEntity.ok().body(VendorInvoiceResponseDTO.builder().status(1)
                        .message("Search operation completed successfully").messageDescription(request.getRequestURI())
                        .data(invoiceDetailsResponseDto).build());
    }

    /**
     * Gets the download invoice details.
     *
     * @param request
     *            the request
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the download invoice details
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    @PostMapping(value = "/invoice-details-download")
    public ResponseEntity<Resource> getDownloadInvoiceDetails(HttpServletRequest request,
                    @RequestBody InvoiceDetailsReqDTO invoiceDetailsReqDTO)
                    throws VendorInvoiceServerException, IOException {

        File file = vendorInvoiceDetailsService.getDownloadInvoiceDetails(invoiceDetailsReqDTO);
        Long length = file.length();
        ByteArrayResource resource = null;

        resource = new ByteArrayResource(Files.readAllBytes(file.toPath()));

        HttpHeaders headers = new HttpHeaders();
        headers.add("fileName", file.getName());
        headers.add("Access-Control-Expose-Headers", "fileName");
        return ResponseEntity.ok().headers(headers).contentLength(length)
                        .contentType(MediaType.APPLICATION_OCTET_STREAM).body(resource);
    }

    /**
     * Gets the force sync list.
     *
     * @param request
     *            the request
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the force sync list
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @PostMapping(value = "/invoice-force-sync-list")
    public ResponseEntity<VendorInvoiceResponseDTO> getForceSyncList(HttpServletRequest request,
                    @RequestBody InvoiceDetailsReqDTO invoiceDetailsReqDTO) throws VendorInvoiceServerException {

        Object responseObject = vendorInvoiceDetailsService.getForceSyncList(invoiceDetailsReqDTO);

        return ResponseEntity.ok()
                        .body(VendorInvoiceResponseDTO.builder().status(1)
                                        .message("Sync operation completed successfully")
                                        .messageDescription(request.getRequestURI()).data(responseObject).build());
    }

    /**
     * Gets the way bill view details.
     *
     * @param request
     *            the request
     * @param getEwayBillDetailsRequestDTO
     *            the get eway bill details request DTO
     * @return the way bill view details
     * @throws InvoiceIntegrationEWBException
     *             the invoice integration EWB exception
     */
    @Override
    @PostMapping(value = "/getewaybillDetails")
    public ResponseEntity<VendorInvoiceResponseDTO> getWayBillViewDetails(HttpServletRequest request,
                    @RequestBody GetEwayBillDetailsRequestDTO getEwayBillDetailsRequestDTO)
                    throws InvoiceIntegrationEWBException {
        Object responseObject = vendorInvoiceDetailsService.getGetEwayBillViewDetails(getEwayBillDetailsRequestDTO);

        return ResponseEntity.ok()
                        .body(VendorInvoiceResponseDTO.builder().status(1).message("e-Way details fetched sucessfully")
                                        .messageDescription(request.getRequestURI()).data(responseObject).build());
    }

    /**
     * Gets the gets the eway bill data on UI.
     *
     * @param request
     *            the request
     * @param reqDto
     *            the req dto
     * @return the gets the eway bill data on UI
     * @throws InvoiceIntegrationEWBException
     *             the invoice integration EWB exception
     */
    @Override
    @PostMapping(value = "/getewaybillList")
    public ResponseEntity<VendorInvoiceResponseDTO> getGetEwayBillDataOnUI(HttpServletRequest request,
                    @RequestBody VendorInvoiceGETRequestDTO reqDto) throws InvoiceIntegrationEWBException {
        Object responseObject = null;

        if (reqDto.getIsGet() > 0) {

            GetEwayBillReqDTO ewayBillCallDto = new GetEwayBillReqDTO();

            ewayBillCallDto.setTaxpayerGstin(reqDto.getTaxpayerGstin());
            ewayBillCallDto.setEwaybillNo(reqDto.getEwaybillNo());
            ewayBillCallDto.setEwaybillDate(reqDto.getEwaybillDate());
            ewayBillCallDto.setUserId(reqDto.getUserId());
            if (reqDto.getGetTypeID() == Constants.GET_EWAYBILL_PLD_CODE) {
                String responseMessage = vendorInvoiceDetailsService.callForGetEwaybillDetails(ewayBillCallDto);
                responseObject = vendorInvoiceDetailsService.getGetExistingEWBDetails(reqDto);
                return ResponseEntity.ok().body(VendorInvoiceResponseDTO.builder().status(1).message(responseMessage)
                                .messageDescription(request.getRequestURI()).data(responseObject).build());
            } else if (reqDto.getGetTypeID() == Constants.GET_EWAYBILL_OTHER_PARTY_PLD_CODE) {
                vendorInvoiceDetailsService.callForGetEwaybillDetailsOtherParty(ewayBillCallDto);
                return ResponseEntity.ok().body(VendorInvoiceResponseDTO.builder().status(1).message(
                                "Fetching e-way details from NIC, please wait or system will notify after the process is completed.")
                                .messageDescription(request.getRequestURI()).data(responseObject).build());
            } else if (reqDto.getGetTypeID() == Constants.GET_EWAYBILL_BY_DATE_PLD_CODE) {
                vendorInvoiceDetailsService.callForGetEwaybillDetailsByDate(ewayBillCallDto);
                return ResponseEntity.ok().body(VendorInvoiceResponseDTO.builder().status(1).message(
                                "Fetching e-way details from NIC, please wait or system will notify after the process is completed.")
                                .messageDescription(request.getRequestURI()).data(responseObject).build());
            } else {

                return ResponseEntity.ok().body(VendorInvoiceResponseDTO.builder().status(0).message("Invalid GET Type")
                                .messageDescription(request.getRequestURI()).data(null).build());
            }
        } else {
            responseObject = vendorInvoiceDetailsService.getGetExistingEWBDetails(reqDto);
            return ResponseEntity.ok()
                            .body(VendorInvoiceResponseDTO.builder().status(1)
                                            .message("Search operation completed sucessfully ")
                                            .messageDescription(request.getRequestURI()).data(responseObject).build());
        }

    }

    /**
     * Gets the ewaybill view.
     *
     * @param request
     *            the request
     * @param eWBViewDTO
     *            the e WB view DTO
     * @return the ewaybill view
     * @throws InvoiceIntegrationEWBException
     *             the invoice integration EWB exception
     */
    @Override
    @PostMapping(value = "/getewaybillView")
    public ResponseEntity<VendorInvoiceResponseDTO> getewaybillView(HttpServletRequest request,
                    @RequestBody EWBViewDTO eWBViewDTO) throws InvoiceIntegrationEWBException {
        Object responseObject = vendorInvoiceDetailsService.getEwaybillView(eWBViewDTO);

        return ResponseEntity.ok()
                        .body(VendorInvoiceResponseDTO.builder().status(1).message("e-Way details fetched successfully")
                                        .messageDescription(request.getRequestURI()).data(responseObject).build());
    }

    /**
     * Wf approve or reject.
     *
     * @param httpServletRequest
     *            the http servlet request
     * @param wfApproveOrRejectDTO
     *            the wf approve or reject DTO
     * @return the response entity
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    @PostMapping(value = "/wfApproveOrReject")
    public ResponseEntity<APIResponseDTO> wfApproveOrReject(HttpServletRequest httpServletRequest,
                    @RequestBody WfApproveOrRejectDTO wfApproveOrRejectDTO) throws VendorInvoiceServerException {
        if (wfApproveOrRejectDTO.getRequestType() == 33 && "".equals(wfApproveOrRejectDTO.getRemarks())) {
            return ResponseEntity.ok()
                            .body(APIResponseDTO.builder().status(0)
                                            .message("Comment is required while rejecting the request")
                                            .tag(httpServletRequest.getRequestURI()).build());
        }
        String paginationResDTO = vendorInvoiceDetailsService.sendWfApproveOrReject(wfApproveOrRejectDTO);

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(1).message(paginationResDTO)
                        .tag(httpServletRequest.getRequestURI()).build());

    }
    
    
    @Override
    @PostMapping(value = "/getEwbDetail")
    public Object getGetEwayBillDetailsDemo(HttpServletRequest request,
                    @RequestBody VendorInvoiceGETRequestDTO reqDto) throws InvoiceIntegrationEWBException {

            GetEwayBillReqDTO ewayBillCallDto = new GetEwayBillReqDTO();

            ewayBillCallDto.setTaxpayerGstin(reqDto.getTaxpayerGstin());
            ewayBillCallDto.setEwaybillNo(reqDto.getEwaybillNo());
            return getEwayBillDemo.callForGetEwaybillDetailsDemo(ewayBillCallDto);
           
       }
    
    @Override
    @PostMapping(value = "/urpInvoiceUpload")
    public ResponseEntity<APIResponseDTO> callUrpUploadService(HttpServletRequest request, @RequestBody PowerAutomateRequestBody powerAutomateRequestBody) throws IOException, VendorInvoiceServerException
    {
    	
    	String fileStatus =urpMailFileUploadService.callUploadUriService(powerAutomateRequestBody);
    	
    	return ResponseEntity.ok().body(APIResponseDTO.builder().status(HttpStatus.OK.value()).message(fileStatus)
                .tag(request.getRequestURI()).build());
    	
    }
    


}
