package com.bdo.bvms.common.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.repository.IPickupMasterRepository;
import com.bdo.bvms.common.sql.CommonSql;

@Repository
public class PickupMasterRepositoryImpl implements IPickupMasterRepository{

	@Autowired
	private JdbcTemplate jdbcTemplateMst;
	
	
	@Override
            public LinkedHashMap<String,Integer> getPickupListDetailsMapSortOrder(String pickupMasterName) {

                        return jdbcTemplateMst.query(CommonSql.GET_PICKUP_LIST_DETAILS_MAP_SQL,
                                                new ResultSetExtractor<LinkedHashMap<String,Integer>>() {
                                    @Override
                                    public LinkedHashMap<String,Integer> extractData(ResultSet rs)
                                                            throws SQLException, DataAccessException {
                                        LinkedHashMap<String, Integer> mapRet = new LinkedHashMap<>();
                                                while (rs.next()) {
                                                            mapRet.put(rs.getString("name"), rs.getInt("code"));
                                                }
                                                return mapRet;
                                    }
                        }, pickupMasterName);





            }

}
