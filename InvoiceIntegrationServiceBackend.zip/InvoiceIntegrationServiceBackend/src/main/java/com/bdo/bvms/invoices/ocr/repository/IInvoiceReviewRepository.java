package com.bdo.bvms.invoices.ocr.repository;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.ocr.dao.OcrStatusUpdateRequestDto;
import com.bdo.bvms.invoices.ocr.dao.UpdateOCRInvoiceDetailsReqDTO;
import com.bdo.bvms.invoices.ocr.model.OcrInvoiceHeader;
import com.bdo.bvms.invoices.ocr.model.OcrVerticalMap;
import com.bdo.bvms.ocr.dto.VendorCodeAutoTagReqDto;

public interface IInvoiceReviewRepository {

    OcrVerticalMap getOcrVerticalMap(OcrVerticalMap ocrVerticalMap);

    Map<Integer, String> getOcrInvoiceReviewVerticalFieldColumnMapping(OcrVerticalMap ocrVerticalMap);

    Map<Integer, String> getOcrInvoiceReviewMasterFieldColumnMapping();

    Integer updateOcrInvoiceDetails(String columnName, String values, String tableName)
                    throws VendorInvoiceServerException;

    OcrInvoiceHeader getInvoiceHeaderByFileId(OcrVerticalMap ocrVerticalMap);

    Integer insertOcrInvoiceHeaderArchive(OcrVerticalMap ocrVerticalMap) throws VendorInvoiceServerException;

    Integer deleteOcrInvoiceHeader(OcrVerticalMap ocrVerticalMap);

    Integer insertOcrInvoiceDetailsArchive(OcrVerticalMap ocrVerticalMap);

    Integer deleteOcrInvoiceDetails(OcrVerticalMap ocrVerticalMap);

    List<OcrVerticalMap> getOcrInvoiceReviewData(int fileId, int pldTabId, String taxpayerGstin, int countCheck);

    int[] updateOcrVerticalMap(List<Map<String, Object>> updatedValues);

    Integer insertVerticalMapLineItemArchive(OcrVerticalMap ocrVerticalMap);

    Integer deleteVerticalMapLineItemDetails(OcrVerticalMap ocrVerticalMap);

    int[] insertUpdatedLineItemDetailsOcrVerticalMap(List<UpdateOCRInvoiceDetailsReqDTO> lineItemList,
                    OcrVerticalMap ocrVerticalMap);

    OcrVerticalMap getCommonDetailsVerticalMap(OcrVerticalMap ocrVerticalMap);

    int countCheckForNewFileOcr(int fileId);

    List<OcrVerticalMap> getLineItemRefernceObject(String gstin);

    int[] insertOcrHeaderDetailsVerticalMap(List<UpdateOCRInvoiceDetailsReqDTO> dataList, OcrVerticalMap ocrVerticalMap,
                    int isHeader);

    Map<String, Object> ocrInvoiceStatusSubmission(OcrStatusUpdateRequestDto ocrStatusUpdateRequestDto,
                    String ocrStatus) throws VendorInvoiceServerException;

    Integer deleteComplianceValidations(OcrVerticalMap ocrVerticalMap);

    void updateOcrHeaderDetails(String columnName, String values, String tableName, OcrVerticalMap ocrVerticalMap)
                    throws SQLException;

    void updateOcrStatus(String ocrStatus, String ids, int userId, int integer) throws VendorInvoiceServerException;

	void markOcrAsRejected(String ids) throws VendorInvoiceServerException;

	Map<String, Object> fetchVendorCodeForAutoTagging(VendorCodeAutoTagReqDto reqObj)
			throws VendorInvoiceServerException;


}
