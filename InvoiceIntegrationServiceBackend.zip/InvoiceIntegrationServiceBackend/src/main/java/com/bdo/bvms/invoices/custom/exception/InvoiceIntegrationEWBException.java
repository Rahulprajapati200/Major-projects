package com.bdo.bvms.invoices.custom.exception;


public class InvoiceIntegrationEWBException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvoiceIntegrationEWBException() {
		super();
	}

	public InvoiceIntegrationEWBException(Throwable cause) {

		super(cause);

	}

	public InvoiceIntegrationEWBException(String message, Throwable cause) {

		super(message, cause);

	}
	
	public InvoiceIntegrationEWBException(String message) {

		super(message);

	}


}
