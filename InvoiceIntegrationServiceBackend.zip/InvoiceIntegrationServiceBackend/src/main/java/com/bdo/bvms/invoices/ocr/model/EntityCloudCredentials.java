package com.bdo.bvms.invoices.ocr.model;

import org.springframework.data.relational.core.mapping.Column;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EntityCloudCredentials {

	Integer id;
	
	@Column(value="entity_id")
	Integer entityId;
	
	String type;
	String url;
	
	@Column(value="user_id")
	Integer userId;
	
	String password;
	
	@Column(value="is_active")
	Integer isActive;
	
	@Column(value="container_name")
	String containerName;
}
