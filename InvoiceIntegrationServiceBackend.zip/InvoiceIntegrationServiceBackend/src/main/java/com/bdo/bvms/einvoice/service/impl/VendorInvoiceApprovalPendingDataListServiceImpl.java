package com.bdo.bvms.einvoice.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.CustomColumnService;
import com.bdo.bvms.einvoice.service.VendorInvoiceApprovalPendingDataListService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.VendorInvoiceConstants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceApprovalPendingDataListDao;
import com.bdo.bvms.invoices.dto.ApprovalPendingResDTO;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceColumnsNameResponseDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class VendorInvoiceApprovalPendingDataListServiceImpl implements VendorInvoiceApprovalPendingDataListService {

    @Autowired
    CustomColumnService customColumnService;

    @Autowired
    VendorInvoiceApprovalPendingDataListDao vendorInvoiceApprovalPendingDataListDao;

    @Autowired
    CommonDao commonDao;

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Value("${mst.database-name}")
    String mstDatabseName;

    int id;

    @Override
    public Map<String, Object> getApprovalPendingDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {

        Map<String, Object> data;
        try {

            data = new LinkedHashMap<>();

            int totalCount = 0;

            data.put("ColumnData", customColumnService.getCustomGridColumns(vendorInvoiceRequestDTO));

            List<ApprovalPendingResDTO> dataResList = vendorInvoiceApprovalPendingDataListDao
                            .getApprovalPendingDataList(vendorInvoiceRequestDTO, gstinNewList, monthList);

            data.put("Data", dataResList);

            if (!dataResList.isEmpty()) {
                totalCount = dataResList.get(0).getTotalCount();
            }

            data.put("totalPageElements", totalCount);

        } catch (Exception e) {
            log.error("error coming at the time of getting data of 'columnData' and 'Data' from approval pending tab",
                            e.getCause());
            throw new VendorInvoiceServerException(e.getMessage());
        }

        return data;

    }

    @Override
    public int getApprovalPendingTotalCount(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
                    String monthList) {

        return 0;
    }

    @Override
    public List<ApprovalPendingResDTO> getApprovalPendingDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {

        return new ArrayList<>();
    }

    @Override
    public List<VendorInvoiceColumnsNameResponseDTO> getApprovalPendingColumnNames(
                    VendorInvoiceRequestDTO vendorInvoiceRequestDTO) throws VendorInvoiceServerException {
        int idOfHeaders = 1;
        List<VendorInvoiceColumnsNameResponseDTO> vendorInvoiceColumnsList = new ArrayList<>();
        // here we add values of column data to the list of string.

        try {
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.TAXPAYER_GSTIN));
            vendorInvoiceColumnsList.add(
                            new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++, VendorInvoiceConstants.DATA_TYPE));
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.VENDOR_GSTIN));
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.VENDOR_LEGAL_NAME));
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.VENDOR_TRADE_NAME));
            vendorInvoiceColumnsList.add(
                            new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++, VendorInvoiceConstants.INVOICE_NO));
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.INVOICE_DATE));
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.EWAY_BILL_NO));
            vendorInvoiceColumnsList.add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++,
                            VendorInvoiceConstants.EWAY_BILL_DATE));
            vendorInvoiceColumnsList.add(
                            new VendorInvoiceColumnsNameResponseDTO(idOfHeaders++, VendorInvoiceConstants.UPLOAD_DATE));
            vendorInvoiceColumnsList
                            .add(new VendorInvoiceColumnsNameResponseDTO(idOfHeaders, VendorInvoiceConstants.ACTION));

        } catch (Exception e) {
            log.error("Exception come at the time of getting 'columnData' in Approval Pending  tab.", e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
            exceptionLogDTO.setFunctionName("getApprovalPendingColumnNames");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException(
                            "Exception come at the time of getting 'columnData' in Approval Pending  tab.");
        }

        return vendorInvoiceColumnsList;

    }
}
