package com.bdo.bvms.invoices.dao.impl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.VendorJourneyDataListDao;
import com.bdo.bvms.invoices.dto.ApprovedDocumentsDTO;
import com.bdo.bvms.invoices.dto.DraftDocumentsDTO;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.ProcessedListDataResDTO;
import com.bdo.bvms.invoices.dto.RejectedDocumentsDTO;
import com.bdo.bvms.invoices.dto.SubmittedPendingApprovalDocumentsDTO;
import com.bdo.bvms.invoices.dto.TotalDocumentsDataDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.invoices.util.CommonUtils;
import com.bdo.bvms.invoices.util.NumberUtils;
import com.bdo.bvms.invoices.vendor.dao.VendorJourneyCommonDao;

import lombok.extern.slf4j.Slf4j;

// TODO: Auto-generated Javadoc
/** The Constant log. */
@Slf4j
@Repository
public class VendorJourneyDataListDaoImpl implements VendorJourneyDataListDao {

    /** The common dao. */
    @Autowired
    CommonDao commonDao;

    /** The vendor journey common dao. */
    @Autowired
    VendorJourneyCommonDao vendorJourneyCommonDao;

    /**
     * Gets the total documents data list.
     *
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @param gstinNewList
     *            the gstin new list
     * @param monthList
     *            the month list
     * @return the total documents data list
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    public Map<String, Object> gettotalDocumentsDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {
        try {

            Map<String, Object> resulSet = new HashMap<>();
            String whereCondition = CommonUtils.getVendorJourneyWhereCondition(vendorInvoiceRequestDTO,
                            vendorInvoiceRequestDTO.getAdvanceFilter());
            Map<String, Object> out = vendorJourneyCommonDao.getDocumentData(vendorInvoiceRequestDTO, gstinNewList,
                            monthList, whereCondition);
            List<TotalDocumentsDataDTO> dataResList1 = new ArrayList<>();
            List<Map<String, Object>> results = (List<Map<String, Object>>) out.get("#result-set-" + 1);
            List<Map<String, Object>> countMap = (List<Map<String, Object>>) out.get("#result-set-" + 2);

            for (Map<String, Object> u : results) {

                TotalDocumentsDataDTO dataRes = new TotalDocumentsDataDTO();

                dataRes.setCompanyGstin(checkNullValue((String) u.get("CompanyGSTIN")));
                dataRes.setCustomerGstin(checkNullValue((String) u.get("CustomerGSTIN")));
                dataRes.setCustomerLegalName(checkNullValue((String) u.get("CustomerLegalName")));
                dataRes.setCustomerTradeName(checkNullValue((String) u.get("CustomerTradeName")));
                dataRes.setDataType(checkNullValue((String) u.get("DataType")));
                dataRes.setDocumentStatus(checkNullValue((String) u.get("DocumentStatus")));
                dataRes.setEwayBillDate(checkNullValue((String) u.get("EwayBillDate")));
                dataRes.setEwayBillNo(checkNullValue((String) u.get("EwayBillNo")));
                dataRes.setId(Integer.valueOf(u.get("id").toString()));
                dataRes.setInvoiceDate(checkNullValue((String) u.get("InvoiceDate")));
                dataRes.setInvoiceNo(checkNullValue((String) u.get("InvoiceNo")));
                dataRes.setUploadedBy(checkNullValue((String) u.get("UploadedBy")));
                dataRes.setUploadedOn((LocalDateTime) u.get("UploadedOn"));
                dataRes.setAction(checkNullValue((String) u.get("batch_no")));
                dataResList1.add(dataRes);

            }
            resulSet.put("dataRes", dataResList1);
            resulSet.put("count", countMap.get(0).get("TotalCount"));
            return resulSet;

        } catch (DataAccessException e) {
            log.info("Error occures at the time of fetching data from database", e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATIONGRIDDATA);
            exceptionLogDTO.setFunctionName("gettotalDocumentsDataList");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming
            // in this function to getting data from database.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException("Error occures at the time of fetching data from database",
                            e.getCause());

        }

    }

    /**
     * Gets the draft documents data list.
     *
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @param gstinNewList
     *            the gstin new list
     * @param monthList
     *            the month list
     * @return the draft documents data list
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    public Map<String, Object> getdraftDocumentsDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {

        try {
            Map<String, Object> resulSet = new HashMap<>();
            String whereCond = CommonUtils.getVendorJourneyWhereCondition(vendorInvoiceRequestDTO,
                            vendorInvoiceRequestDTO.getAdvanceFilter());
            Map<String, Object> draftDocumentsDataMap = vendorJourneyCommonDao
                            .getDraftDocumentsDataList(vendorInvoiceRequestDTO, gstinNewList, monthList, whereCond);

            List<DraftDocumentsDTO> dataResList1 = new ArrayList<>();
            List<Map<String, Object>> results = (List<Map<String, Object>>) draftDocumentsDataMap
                            .get("#result-set-" + 1);
            List<Map<String, Object>> countMap = (List<Map<String, Object>>) draftDocumentsDataMap
                            .get("#result-set-" + 2);
            for (Map<String, Object> u : results) {

                DraftDocumentsDTO dataRes = new DraftDocumentsDTO();

                dataRes.setCompanyGstin(checkNullValue((String) u.get("CompanyGSTIN")));
                dataRes.setCustomerGstin(checkNullValue((String) u.get("CustomerGSTIN")));
                dataRes.setCustomerLegalName(checkNullValue((String) u.get("CustomerLegalName")));
                dataRes.setCustomerTradeName(checkNullValue((String) u.get("CustomerTradeName")));
                dataRes.setDataType(checkNullValue((String) u.get("DataType")));
                dataRes.setDocumentStatus(checkNullValue((String) u.get("DocumentStatus")));
                dataRes.setEwayBillDate(checkNullValue((String) u.get("EwayBillDate")));
                dataRes.setEwayBillNo(checkNullValue((String) u.get("EwayBillNo")));
                dataRes.setId(Integer.valueOf(u.get("id").toString()));
                dataRes.setInvoiceDate(checkNullValue((String) u.get("InvoiceDate")));
                dataRes.setInvoiceNo(checkNullValue((String) u.get("InvoiceNo")));
                dataRes.setUploadedBy(checkNullValue((String) u.get("UploadedBy")));
                dataRes.setUploadedOn((LocalDateTime) u.get("UploadedOn"));
                dataRes.setAction(checkNullValue((String) u.get("batch_no")));
                dataResList1.add(dataRes);
            }
            resulSet.put("dataRes", dataResList1);
            resulSet.put("count", countMap.get(0).get("TotalCount"));
            return resulSet;
        } catch (Exception e) {

            log.info("Error occures at the time of fetching data from database", e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATIONGRIDDATA);
            exceptionLogDTO.setFunctionName("gettotalDocumentsDataList");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming
            // in this function to getting data from database.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException("Error occures at the time of fetching data from database",
                            e.getCause());
        }
    }

    /**
     * Gets the submitted pending approval documents data list.
     *
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @param gstinNewList
     *            the gstin new list
     * @param monthList
     *            the month list
     * @return the submitted pending approval documents data list
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    public Map<String, Object> getsubmittedPendingApprovalDocumentsDataList(
                    VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList, String monthList)
                    throws VendorInvoiceServerException {
        try {
            Map<String, Object> resulSet = new HashMap<>();
            String whereCond = CommonUtils.getVendorJourneyWhereCondition(vendorInvoiceRequestDTO,
                            vendorInvoiceRequestDTO.getAdvanceFilter());
            Map<String, Object> draftDocumentsDataMap = vendorJourneyCommonDao
                            .getDraftDocumentsDataList(vendorInvoiceRequestDTO, gstinNewList, monthList, whereCond);

            List<SubmittedPendingApprovalDocumentsDTO> dataResList1 = new ArrayList<>();
            List<Map<String, Object>> results = (List<Map<String, Object>>) draftDocumentsDataMap
                            .get("#result-set-" + 1);
            List<Map<String, Object>> countMap = (List<Map<String, Object>>) draftDocumentsDataMap
                            .get("#result-set-" + 2);
            for (Map<String, Object> u : results) {

                SubmittedPendingApprovalDocumentsDTO dataRes = new SubmittedPendingApprovalDocumentsDTO();

                dataRes.setCompanyGstin(checkNullValue((String) u.get("CompanyGSTIN")));
                dataRes.setCustomerGstin(checkNullValue((String) u.get("CustomerGSTIN")));
                dataRes.setCustomerLegalName(checkNullValue((String) u.get("CustomerLegalName")));
                dataRes.setCustomerTradeName(checkNullValue((String) u.get("CustomerTradeName")));
                dataRes.setDataType(checkNullValue((String) u.get("DataType")));
                dataRes.setDocumentStatus(checkNullValue((String) u.get("DocumentStatus")));
                dataRes.setEwayBillDate(checkNullValue((String) u.get("EwayBillDate")));
                dataRes.setEwayBillNo(checkNullValue((String) u.get("EwayBillNo")));
                dataRes.setId(Integer.valueOf(u.get("id").toString()));
                dataRes.setInvoiceDate(checkNullValue((String) u.get("InvoiceDate")));
                dataRes.setInvoiceNo(checkNullValue((String) u.get("InvoiceNo")));
                dataRes.setSubmittedOn((LocalDateTime) u.get("submittedon"));
                dataRes.setAction(checkNullValue((String) u.get("batch_no")));
                dataRes.setSubmittedBy(checkNullValue((String) u.get("submittedby")));
                dataRes.setWfMstId(Long.valueOf(u.get("wfrmid").toString()));
                dataResList1.add(dataRes);
            }
            resulSet.put("dataRes", dataResList1);
            resulSet.put("count", countMap.get(0).get("TotalCount"));
            return resulSet;
        } catch (Exception e) {
            log.info("Error occures at the time of fetching data from database", e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATIONGRIDDATA);
            exceptionLogDTO.setFunctionName("gettotalDocumentsDataList");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming
            // in this function to getting data from database.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException("Error occures at the time of fetching data from database",
                            e.getCause());
        }

    }

    /**
     * Gets the approved documents data list.
     *
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @param gstinNewList
     *            the gstin new list
     * @param monthList
     *            the month list
     * @return the approved documents data list
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    public Map<String, Object> getApprovedDocumentsDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {
        try {
            Map<String, Object> resulSet = new HashMap<>();
            String whereCond = CommonUtils.getVendorJourneyWhereCondition(vendorInvoiceRequestDTO,
                            vendorInvoiceRequestDTO.getAdvanceFilter());
            Map<String, Object> draftDocumentsDataMap = vendorJourneyCommonDao
                            .getDraftDocumentsDataList(vendorInvoiceRequestDTO, gstinNewList, monthList, whereCond);
            List<Map<String, Object>> countMap = (List<Map<String, Object>>) draftDocumentsDataMap
                            .get("#result-set-" + 2);
            List<ApprovedDocumentsDTO> dataResList1 = new ArrayList<>();
            List<Map<String, Object>> results = (List<Map<String, Object>>) draftDocumentsDataMap
                            .get("#result-set-" + 1);

            for (Map<String, Object> u : results) {

                ApprovedDocumentsDTO dataRes = new ApprovedDocumentsDTO();

                dataRes.setCompanyGstin(checkNullValue((String) u.get("CompanyGSTIN")));
                dataRes.setCustomerGstin(checkNullValue((String) u.get("CustomerGSTIN")));
                dataRes.setCustomerLegalName(checkNullValue((String) u.get("CustomerLegalName")));
                dataRes.setCustomerTradeName(checkNullValue((String) u.get("CustomerTradeName")));
                dataRes.setDataType(checkNullValue((String) u.get("DataType")));
                dataRes.setDocumentStatus(checkNullValue((String) u.get("DocumentStatus")));
                dataRes.setEwayBillDate(checkNullValue((String) u.get("EwayBillDate")));
                dataRes.setEwayBillNo(checkNullValue((String) u.get("EwayBillNo")));
                dataRes.setId(Integer.valueOf(u.get("id").toString()));
                dataRes.setInvoiceDate(checkNullValue((String) u.get("InvoiceDate")));
                dataRes.setInvoiceNo(checkNullValue((String) u.get("InvoiceNo")));
                dataRes.setSubmittedBy(checkNullValue((String) u.get("submittedby")));
                dataRes.setSubmittedOn((LocalDateTime) u.get("submittedon"));
                dataRes.setAction(checkNullValue((String) u.get("batch_no")));
                dataRes.setApprovedOn((LocalDateTime) u.get("approved_on"));
                dataRes.setWfMstId(Long.valueOf(u.get("wfrmID").toString()));
                dataResList1.add(dataRes);
            }
            resulSet.put("dataRes", dataResList1);
            resulSet.put("count", countMap.get(0).get("TotalCount"));
            return resulSet;
        } catch (Exception e) {
            log.info("Error occures at the time of fetching data from database", e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATIONGRIDDATA);
            exceptionLogDTO.setFunctionName("gettotalDocumentsDataList");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming
            // in this function to getting data from database.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException("Error occures at the time of fetching data from database",
                            e.getCause());
        }

    }

    /**
     * Gets the rejected documents data list.
     *
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @param gstinNewList
     *            the gstin new list
     * @param monthList
     *            the month list
     * @return the rejected documents data list
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    public Map<String, Object> getRejectedDocumentsDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {
        try {
            Map<String, Object> resulSet = new HashMap<>();
            String whereCond = CommonUtils.getVendorJourneyWhereCondition(vendorInvoiceRequestDTO,
                            vendorInvoiceRequestDTO.getAdvanceFilter());
            Map<String, Object> draftDocumentsDataMap = vendorJourneyCommonDao
                            .getDraftDocumentsDataList(vendorInvoiceRequestDTO, gstinNewList, monthList, whereCond);

            List<RejectedDocumentsDTO> dataResList1 = new ArrayList<>();
            List<Map<String, Object>> results = (List<Map<String, Object>>) draftDocumentsDataMap
                            .get("#result-set-" + 1);
            List<Map<String, Object>> countMap = (List<Map<String, Object>>) draftDocumentsDataMap
                            .get("#result-set-" + 2);
            for (Map<String, Object> u : results) {

                RejectedDocumentsDTO dataRes = new RejectedDocumentsDTO();

                dataRes.setCompanyGstin(checkNullValue((String) u.get("CompanyGSTIN")));
                dataRes.setCustomerGstin(checkNullValue((String) u.get("CustomerGSTIN")));
                dataRes.setCustomerLegalName(checkNullValue((String) u.get("CustomerLegalName")));
                dataRes.setCustomerTradeName(checkNullValue((String) u.get("CustomerTradeName")));
                dataRes.setDataType(checkNullValue((String) u.get("DataType")));
                dataRes.setDocumentStatus(checkNullValue((String) u.get("DocumentStatus")));
                dataRes.setEwayBillDate(checkNullValue((String) u.get("EwayBillDate")));
                dataRes.setEwayBillNo(checkNullValue((String) u.get("EwayBillNo")));
                dataRes.setId(Integer.valueOf(u.get("id").toString()));
                dataRes.setInvoiceDate(checkNullValue((String) u.get("InvoiceDate")));
                dataRes.setInvoiceNo(checkNullValue((String) u.get("InvoiceNo")));
                dataRes.setSubmittedBy(checkNullValue((String) u.get("submittedby")));
                dataRes.setSubmittedOn((LocalDateTime) u.get("submittedon"));
                dataRes.setAction(checkNullValue((String) u.get("batch_no")));
                dataRes.setRejectedOn((LocalDateTime) u.get("approved_on"));
                dataRes.setWfMstId(Long.valueOf(u.get("wfrmID").toString()));
                dataResList1.add(dataRes);
            }
            resulSet.put("dataRes", dataResList1);
            resulSet.put("count", countMap.get(0).get("TotalCount"));
            return resulSet;
        } catch (Exception e) {
            log.info("Error occures at the time of fetching data from database", e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATIONGRIDDATA);
            exceptionLogDTO.setFunctionName("gettotalDocumentsDataList");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming
            // in this function to getting data from database.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException("Error occures at the time of fetching data from database",
                            e.getCause());
        }

    }

    /**
     * Gets the processed invoice data list.
     *
     * @param vendorInvoiceRequestDTO
     *            the vendor invoice request DTO
     * @param gstinNewList
     *            the gstin new list
     * @param monthList
     *            the month list
     * @return the processed invoice data list
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     */
    @Override
    public List<ProcessedListDataResDTO> getProcessedInvoiceDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {
        try {
            String whereCond = CommonUtils.getVendorJourneyWhereCondition(vendorInvoiceRequestDTO,
                            vendorInvoiceRequestDTO.getAdvanceFilter());
            Map<String, Object> out = vendorJourneyCommonDao.getGridDataProcessedInvoice(vendorInvoiceRequestDTO,
                            gstinNewList, monthList, whereCond);
            List<ProcessedListDataResDTO> dataResList = new ArrayList<>();
            List<Map<String, Object>> results = (List<Map<String, Object>>) out.get("#result-set-" + 1);
            if (results.isEmpty()) {
                return dataResList;
            }
            results.forEach(u -> {
                ProcessedListDataResDTO dataRes = new ProcessedListDataResDTO();
                dataRes.setId(Integer.valueOf(u.get("id").toString()));
                dataRes.setTaxpayerPan(checkNullValue((String) u.get("taxpayer_pan")));
                dataRes.setTaxpayerGstin(checkNullValue((String) u.get("taxpayer_gstin")));
                dataRes.setVendorPan(checkNullValue((String) u.get("vendor_pan")));
                dataRes.setVendorGstin(checkNullValue((String) u.get("vendor_gstin")));
                dataRes.setCustomerLegalName(checkNullValue((String) u.get("vendor_legal_name")));
                dataRes.setCustomerTradeName(checkNullValue((String) u.get("vendor_trade_name")));
                dataRes.setInvoiceNo(checkNullValue((String) u.get("invoice_no")));
                dataRes.setInvoiceDate(checkNullValue((String) u.get("invoice_date")));
                dataRes.setSyncWithGstr2a((String) u.get("sync_with_gstr2a"));
                dataRes.setSyncWithGstr2b((String) u.get("sync_with_gstr2b"));
                dataRes.setSyncWithEwayBill((String) u.get("sync_with_eway_bill"));
                dataRes.setTaxableValue(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("taxable_value")));
                dataRes.setIgst(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("igst")));
                dataRes.setSgst(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("sgst")));
                dataRes.setCgst(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("cgst")));
                dataRes.setCess(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("cess")));
                dataRes.setInvoiceValue(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("invoice_value")));
                dataRes.setQrCodeValid(String.valueOf(u.get("qr_code_valid")));
                dataRes.setEwayBillNo(checkNullValue((String) u.get("eway_bill_no")));
                dataRes.setEwayBillDate(checkNullValue((String) u.get("eway_bill_date")));
                dataRes.setPoNumber(checkNullValue((String) u.get("po_number")));
                dataRes.setGrnNumber(checkNullValue((String) u.get("grn_no")));
                dataRes.setUploadDate((LocalDateTime) u.get("details_upload_date"));
                dataRes.setLastSyncDate((LocalDateTime) u.get("last_synced_date"));
                dataRes.setSyncStatus((u.get("sync_status")).toString().equals("1") ? Boolean.TRUE : Boolean.FALSE);
                dataRes.setBookedErp(checkNullValue((String) u.get("booked_erp")));
                dataRes.setGetType(checkNullValue((String) u.get("get_type")));
                dataRes.setBatchNo(checkNullValue((String) u.get("batch_no")));
                dataRes.setFileType(checkNullValue((String) u.get("file_type")));
                dataRes.setTotalCount(Integer.valueOf(u.get("total_count").toString()));
                dataRes.setUploadedBy(checkNullValue((String) u.get("uploaded_by")));
                dataResList.add(dataRes);
            });

            return dataResList;
        } catch (DataAccessException e) {
            log.error("Error occurs at the time of fetching data from database in Processed invoice tab.",
                            e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATIONGRIDDATA);
            exceptionLogDTO.setFunctionName("getProcessedInvoiceDataList");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming
            // in this function to getting data from database.
            commonDao.updateExceptionLogTable(exceptionLogDTO);

            throw new VendorInvoiceServerException(
                            "Error coming at the time of getting data from database in Processed invoice tab.",
                            e.getCause());

        }
    }

    /**
     * Check null value.
     *
     * @param value
     *            the value
     * @return the string
     */
    private static String checkNullValue(String value) {
        if (StringUtils.isEmpty(value)) {
            return "-";
        } else {
            return value;
        }
    }

}
