package com.bdo.bvms.invoices.ocr.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class OcrInvoiceDetails {

    Integer ocrInvId;
    Integer pldOcrConfidenceId;
    Integer productCode;
    Integer quantity;
    Integer unit;
    Double unitPrice;
    Double amount;
    Double cgstAmt;
    Double cgstP;
    Double sgstAmt;
    Double sgstP;
    Double igstAmt;
    Double igstP;
    Double cessAmt;
    Double cessP;
    Double ugstAmt;
    Double ugstP;
    Double tcsAmt;
    Double tcsP;
    Double vatAmt;
    Double vatP;
    Double totalAmt;
    
    String description;
    
}
