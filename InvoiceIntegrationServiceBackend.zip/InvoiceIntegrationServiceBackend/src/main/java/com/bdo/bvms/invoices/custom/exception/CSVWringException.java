package com.bdo.bvms.invoices.custom.exception;


public class CSVWringException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CSVWringException() {
		super();
	}

	public CSVWringException(Throwable cause) {

		super(cause);

	}

	public CSVWringException(String message, Throwable cause) {

		super(message, cause);

	}

}
