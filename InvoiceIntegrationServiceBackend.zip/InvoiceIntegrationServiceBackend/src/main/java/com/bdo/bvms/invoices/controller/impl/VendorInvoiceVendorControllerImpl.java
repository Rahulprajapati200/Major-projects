package com.bdo.bvms.invoices.controller.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.bdo.bvms.einvoice.vendor.service.ProcessUploadServiceVendor;
import com.bdo.bvms.einvoice.vendor.service.VendorJourneyUploadLogHistoryService;
import com.bdo.bvms.envoices.service.VendorDataListService;
import com.bdo.bvms.invoices.controller.VendorInvoiceVendorController;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.APIResponseDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsReqDTO;
import com.bdo.bvms.invoices.dto.UploadHistoryRequestDTO;
import com.bdo.bvms.invoices.dto.UploadHistoryResponseDTO;
import com.bdo.bvms.invoices.dto.UploadLogHistoryResDataDto;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceResponseDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceSubmitOrRemoveReqDTO;
import com.bdo.bvms.invoices.dto.VendorJourneyInvoiceGetDetailsReqDTO;
import com.bdo.bvms.invoices.dto.VendorJourneyInvoiceGetDetailsResDTO;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/vendorjourney-invoice")
@Slf4j
public class VendorInvoiceVendorControllerImpl implements VendorInvoiceVendorController {

    @Autowired
    ProcessUploadServiceVendor processUploadServiceVendorImpl;

    @Autowired
    VendorJourneyUploadLogHistoryService vendorInvoiceUploadLogHistoryService;

    @Autowired
    VendorDataListService vendorDataListService;

    @Autowired
    com.bdo.bvms.einvoice.service.VendorInvoiceVendorDetailsService VendorInvoiceVendorDetailsService;

    @Override
    @PostMapping("/upload-file")
    public ResponseEntity<APIResponseDTO> uploadFile(HttpServletRequest request,
                    @ModelAttribute UploadRequestDTO uploadRequestDTO) throws VendorInvoiceServerException {

        String fileStatus = processUploadServiceVendorImpl.uploadAndProcessVendorFile(uploadRequestDTO);

        return ResponseEntity.ok().body(APIResponseDTO.builder().status(HttpStatus.OK.value()).message(fileStatus)
                        .tag(request.getRequestURI()).build());

    }

    @Override
    @PostMapping(value = "/upload-log-datalist")
    public ResponseEntity<UploadHistoryResponseDTO> logHistory(HttpServletRequest request,
                    @RequestBody UploadHistoryRequestDTO requestDTO) throws VendorInvoiceServerException {
    	
        List<UploadLogHistoryResDataDto> uploadLogHistoryResDataDto = vendorInvoiceUploadLogHistoryService
                        .getHistoryList(requestDTO);

        return ResponseEntity.ok()
                        .body(UploadHistoryResponseDTO.builder().status(1).message("History data is uploaded.")
                                        .messageDescription(request.getRequestURI()).data(uploadLogHistoryResDataDto)
                                        .build());

    }

    @Override
    @PostMapping("/vendorInvoice-datalist")
    public ResponseEntity<VendorInvoiceResponseDTO> getDataList(HttpServletRequest request,
                    @RequestBody VendorInvoiceRequestDTO vendorInvoiceRequestDTO) throws VendorInvoiceServerException {

        Map<String, Object> data = vendorDataListService.getDataGrid(vendorInvoiceRequestDTO);

        return ResponseEntity.ok().body(VendorInvoiceResponseDTO.builder().status(1).message("Get records successfully")
                        .messageDescription(request.getRequestURI()).data(data).build());

    }

    @Override
    @PostMapping("/vendorInvoice-detailView")
    public ResponseEntity<VendorInvoiceResponseDTO> getInvoiceDetails(HttpServletRequest request,
                    @RequestBody VendorJourneyInvoiceGetDetailsReqDTO vendorJourneyInvoiceGetDetailsReqDTO)
                    throws VendorInvoiceServerException {

        VendorJourneyInvoiceGetDetailsResDTO data = processUploadServiceVendorImpl
                        .getInvoiceDetailsFromService(vendorJourneyInvoiceGetDetailsReqDTO);

        return ResponseEntity.ok().body(VendorInvoiceResponseDTO.builder().status(1).message("Get records successfully")
                        .messageDescription(request.getRequestURI()).data(data).build());

    }

    @Override
    @PostMapping("/vendorInvoice-submitOrRemove")
    public ResponseEntity<VendorInvoiceResponseDTO> getSubmitOrRemove(HttpServletRequest request,
                    @RequestBody VendorInvoiceSubmitOrRemoveReqDTO vendorInvoiceSubmitOrRemoveReqDTO)
                    throws VendorInvoiceServerException {

        String response = new String();
        if ("submit".equals(vendorInvoiceSubmitOrRemoveReqDTO.getActionType())) {
            response = processUploadServiceVendorImpl.getSubmitOrRemoveService(vendorInvoiceSubmitOrRemoveReqDTO);
        } else {
            processUploadServiceVendorImpl.deleteDataFromDb(vendorInvoiceSubmitOrRemoveReqDTO);
        }

        if (vendorInvoiceSubmitOrRemoveReqDTO.getActionType().equalsIgnoreCase("submit")
                        && response.contains("Workflow is not configured")) {
            return ResponseEntity.ok().body(VendorInvoiceResponseDTO.builder().status(0).message(response)
                            .messageDescription(request.getRequestURI()).data(null).build());

        } else if (vendorInvoiceSubmitOrRemoveReqDTO.getActionType().equalsIgnoreCase("submit")) {
            return ResponseEntity.ok().body(VendorInvoiceResponseDTO.builder().status(1).message(response)
                            .messageDescription(request.getRequestURI()).data(null).build());

        } else {
            return ResponseEntity.ok()
                            .body(VendorInvoiceResponseDTO.builder().status(1)
                                            .message("Data deleted from workflow successfully")
                                            .messageDescription(request.getRequestURI()).data(null).build());
        }
    }

    @Override
    @PostMapping("/vendorJourneyInvoice-processedInvoice")
    public ResponseEntity<VendorInvoiceResponseDTO> getProcessedInvoiceDataList(HttpServletRequest request,
                    @RequestBody VendorInvoiceRequestDTO vendorInvoiceRequestDTO) throws VendorInvoiceServerException {

        Map<String, Object> data = vendorDataListService.getProcessedInvoiceDataList(vendorInvoiceRequestDTO);

        return ResponseEntity.ok()
                        .body(VendorInvoiceResponseDTO.builder().status(1)
                                        .message("Search operation completed successfully")
                                        .messageDescription(request.getRequestURI()).data(data).build());

    }

    /**
     * Gets the download invoice details.
     *
     * @param request
     *            the request
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the download invoice details
     * @throws VendorInvoiceServerException
     *             the vendor invoice server exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    @Override
    @PostMapping(value = "/invoice-details-download")
    public ResponseEntity<Resource> getDownloadInvoiceDetails(HttpServletRequest request,
                    @RequestBody InvoiceDetailsReqDTO invoiceDetailsReqDTO)
                    throws VendorInvoiceServerException, IOException {

        File file = VendorInvoiceVendorDetailsService.getDownloadInvoiceDetails(invoiceDetailsReqDTO);
        Long length = file.length();
        ByteArrayResource resource = null;

        resource = new ByteArrayResource(Files.readAllBytes(file.toPath()));

        HttpHeaders headers = new HttpHeaders();
        headers.add("fileName", file.getName());
        headers.add("Access-Control-Expose-Headers", "fileName");
        return ResponseEntity.ok().headers(headers).contentLength(length)
                        .contentType(MediaType.APPLICATION_OCTET_STREAM).body(resource);
    }

}
