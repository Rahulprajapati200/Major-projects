package com.bdo.bvms.einvoice.service.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.CustomColumnService;
import com.bdo.bvms.einvoice.service.VendorInvoicePendingForUserInputDataListService;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.VendorInvoicePendingUserInputDataListDao;
import com.bdo.bvms.invoices.dto.PendingForUserInputResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class VendorInvoicePendingForUserInputDataListServiceImpl
                implements VendorInvoicePendingForUserInputDataListService {

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Autowired
    CustomColumnService customColumnService;

    @Autowired
    CommonDao commonDao;

    @Value("${mst.database-name}")
    String mstDatabseName;

    int id;
    @Autowired
    VendorInvoicePendingUserInputDataListDao vendorInvoicePendingUserInputDataListDao;

    @Override
    public Map<String, Object> getPendingInputDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {

        Map<String, Object> data;
        try {
            data = new LinkedHashMap<>();

            int totalCount = 0;
            data.put("ColumnData", customColumnService.getCustomGridColumns(vendorInvoiceRequestDTO));

            List<PendingForUserInputResDTO> dataResList = vendorInvoicePendingUserInputDataListDao
                            .getInvoicePendingUserInputDataList(vendorInvoiceRequestDTO, gstinNewList, monthList);
            data.put("Data", dataResList);

            if (!dataResList.isEmpty()) {
                totalCount = dataResList.get(0).getTotalCount();
            }

            data.put("totalPageElements", totalCount);

        } catch (Exception e) {
            log.error("error coming at the time of getting data of 'columnData' and 'Data' in pending for user input tab",
                            e.getCause());
            throw new VendorInvoiceServerException(e.getMessage());
        }

        return data;

    }

}

