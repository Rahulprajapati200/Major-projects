package com.bdo.bvms.invoices.ocr.dao;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class SearchSystemParameterResDTO {

    private String keyValue;
    private String keyName;
    private String descrip;
    
}
