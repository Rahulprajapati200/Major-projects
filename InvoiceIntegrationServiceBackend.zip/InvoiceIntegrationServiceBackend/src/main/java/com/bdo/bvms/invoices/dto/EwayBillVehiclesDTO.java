package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EwayBillVehiclesDTO {

    String updMode;
    String vehicleNo;
    String fromPlace;
    String fromState;
    String tripshtNo;
    String userGSTINTransin;
    String enteredDate;
    String transMode;
    String transDocNo;
    String transDocDate;
    String groupNo;

}
