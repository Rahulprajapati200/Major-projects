package com.bdo.bvms.common.service.impl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.common.service.IFileService;
import com.bdo.bvms.invoices.custom.exception.VendorMasterBusinessException;

@Component
public class FileServiceImpl implements IFileService {

    @Value("${temp.folder.path}")
    private String tempFolderPath;

    @Override
    public String saveFileInLocalStorage(MultipartFile mulFile,String fileName) {
        try {
            File fle = new File(tempFolderPath);

            if (!fle.exists()) {
                fle.mkdir();
            }

            String newFileName = tempFolderPath + File.separator + fileName;
            if (StringUtils.isBlank(tempFolderPath)) {
                newFileName =fileName;
            }

            byte[] bytes = mulFile.getBytes();
            try (FileOutputStream fileOutputStream = new FileOutputStream(newFileName)) {
                try (BufferedOutputStream stream = new BufferedOutputStream(fileOutputStream)) {
                    stream.write(bytes);
                }
            }
            return newFileName;
        } catch (Exception e) {
            throw new VendorMasterBusinessException("Something went wrong while saving file to storage", e);
        }

    }

    @Override
    public String generateFileAbsolutePath(String originalFileName) {
        String[] arr = originalFileName.split("\\.");
        return arr[0] + "-" + System.currentTimeMillis() + "." + arr[1];
    }

    @Override
    public File createFileWithURL(String fileUrl, String fileName) {
        File file = null;
        try {
            URL url = new URL(fileUrl);
            file = new File(generateFileAbsolutePath(fileName));
            try (FileOutputStream fos = (new FileOutputStream(file))) {
                fos.write(IOUtils.toByteArray(url.openStream()));
            }
        } catch (Exception e) {
            throw new VendorMasterBusinessException("Something went wrong while creating file " + fileName + " from url " + fileUrl,
                            e);
        }
        return file;
    }

}
