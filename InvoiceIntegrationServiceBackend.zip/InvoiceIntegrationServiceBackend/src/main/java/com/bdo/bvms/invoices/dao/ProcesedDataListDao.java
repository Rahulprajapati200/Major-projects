package com.bdo.bvms.invoices.dao;

import org.springframework.data.domain.Page;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.ProcessedListDataResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface ProcesedDataListDao {

    Page<ProcessedListDataResDTO> processedDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO)
                    throws VendorInvoiceServerException;

}
