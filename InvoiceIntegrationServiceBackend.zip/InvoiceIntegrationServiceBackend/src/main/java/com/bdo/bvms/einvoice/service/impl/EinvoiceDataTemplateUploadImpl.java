
package com.bdo.bvms.einvoice.service.impl;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.bdo.bvms.einvoice.service.CustomTemplateEInvoiceRead;
import com.bdo.bvms.einvoice.service.EinvoiceDataTemplateUpload;
import com.bdo.bvms.einvoice.service.InvoiceOcrFileMetaDataCloudStore;
import com.bdo.bvms.einvoice.service.UploadLogService;
import com.bdo.bvms.einvoice.service.UploadNDownloadFileService;
import com.bdo.bvms.einvoice.service.VendorInvoiceUploadLogHistoryService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.StringConstant;
import com.bdo.bvms.invoices.constant.ValidationConstants;
import com.bdo.bvms.invoices.custom.exception.CsvWriteException;
import com.bdo.bvms.invoices.custom.exception.InvalidTemplateHeaderException;
import com.bdo.bvms.invoices.custom.exception.ReadInvoiceCustomTemplate;
import com.bdo.bvms.invoices.custom.exception.ReadInvoicePojoListException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.CustomTemplateRepo;
import com.bdo.bvms.invoices.dao.EInvoiceDao;
import com.bdo.bvms.invoices.dao.UploadMasterDao;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.ResponseBean;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceGrnMappingCrudDTO;
import com.bdo.bvms.invoices.taxpayer.sql.LogSQL;
import com.bdo.bvms.invoices.taxpayer.validationrule.EInvoiceAlreadySyncedValidation;
import com.bdo.bvms.invoices.taxpayer.validationrule.EInvoiceDataTypeValidations;
import com.bdo.bvms.invoices.taxpayer.validationrule.EInvoiceValidationRules;
import com.bdo.bvms.invoices.util.AppUtil;
import com.bdo.bvms.invoices.util.CommonUtils;
import com.bdo.bvms.invoices.util.DateUtil;
import com.csvreader.CsvReader;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.monitorjbl.xlsx.StreamingReader;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class EinvoiceDataTemplateUploadImpl implements EinvoiceDataTemplateUpload {

    @Value("${temp.folder.path}")
    String tempFolder;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Autowired
    CustomTemplateRepo customTemplateRepo;

    @Autowired
    CustomTemplateEInvoiceRead customTemplateEInvoiceRead;

    @Autowired
    EInvoiceDao eInvoiceDao;

    @Autowired
    UploadNDownloadFileService uploadNDownloadFileService;

    @Autowired
    UploadMasterDao uploadMasterDao;

    @Autowired
    VendorInvoiceUploadLogHistoryService vendorInvoiceUploadLogHistoryService;

    @Autowired
    CommonDao commonDao;

    @Autowired
    UploadTransDao uploadTransDao;

    @Autowired
    UploadLogService uploadLogService;

    @Autowired
    InvoiceOcrFileMetaDataCloudStore invoiceOcrFileMetaDataCloudStore;

    @Autowired
    EInvoiceAlreadySyncedValidation eInvoiceAlreadySyncedValidation;

    @Autowired
    private MessageSource messageSource;

    Row headerRow = null;

    List<VendorInvoiceGrnMappingCrudDTO> vendorInvoiceGrnMappingCrudDTOList = new ArrayList<>();

    Map<String, Integer> duplicateRowMap = new HashMap<>();

    Map<String, Integer> colNameIndexMap = new HashMap<>();
    Map<String, Map<String, String>> invoiceExistInPreFpMap = new HashMap<String, Map<String, String>>();
    Set<String> fpSetSftp = new HashSet<>();
    Map<String, String> yearIdMap = new HashMap<>();
    /*
     * this Method will perform actions like 1. get Excel to List of Object. 2.
     * perform Validation 3. Create Error and Success CSV file From Valid and
     * Not Valid data List 4. Insertion of CSV data to Failure and Success Table
     * 5. Finally upload CSV file to Azure with one more column i.e.,
     * errordescriptionList 6. Update those actions in the Database.
     */

    @Async
    @Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
    @Override
    public String validateAndSaveData(UploadReqDTO uploadDTO, AzureConnectionCredentialsDTO map) {

        String methodName = "validateAndSaveData";

        List<EInvoiceTemplateDTO> rowToPoJoList = new ArrayList<>();

        try {
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_PROCESSING,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadDTO);
            uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_INPROGRESS);
            uploadTransDao.commonPostNotification(Constants.VENDORUPLOADMSTID,
                            Constants.INVOICE_FILE_IN_PROGRESS + uploadDTO.getBatchNo(), uploadDTO.getUserId(),
                            uploadDTO.getUserId(), uploadDTO.getUserId(), mstDatabseName,
                            Constants.NOTIFICATION_INITIATED);

            if (Constants.XLSX.equalsIgnoreCase(uploadDTO.getFileType())) {
                // getting Excel to List of Object from excel File Uploaded.
                if (uploadDTO.getIsCustomTemplate().equals(Constants.ISDEFAULTTEMPLATE)) {
                    rowToPoJoList = getEinvoiceDataList(uploadDTO);
                } else if (uploadDTO.getIsCustomTemplate().equals(Constants.ISCUSTOMETEMPLATE)) {
                    rowToPoJoList = customTemplateEInvoiceRead.getEinvoiceDataList(uploadDTO);
                }
            } else if (Constants.CSV.equalsIgnoreCase(uploadDTO.getFileType())) {
                // getting Excel to List of Object from CSV File Uploaded.
                if (uploadDTO.getIsCustomTemplate().equals(Constants.ISDEFAULTTEMPLATE)) {
                    rowToPoJoList = getCsvEInvoiceDataList(uploadDTO);
                } else if (uploadDTO.getIsCustomTemplate().equals(Constants.ISCUSTOMETEMPLATE)) {
                    Map<String, String> customTemplateHeaderMappings = CommonUtils
                                    .getCustomTemplateHeaderMappings(uploadDTO, customTemplateRepo);
                    rowToPoJoList = customTemplateEInvoiceRead.getEinvoiceDataListCDV(uploadDTO,
                                    customTemplateHeaderMappings, Constants.DELIMITER);
                }

            } else if (Constants.PDF.equalsIgnoreCase(uploadDTO.getFileType())
                            || Constants.JPG.equalsIgnoreCase(uploadDTO.getFileType())) {

                if (Constants.INVOICE_CODE.equalsIgnoreCase(uploadDTO.getUploadType())) {
                    rowToPoJoList = getPdfInvoiceDataList(uploadDTO);
                } else {

                    rowToPoJoList = getPdfEInvoiceDataList(uploadDTO);
                }

            } else {
                uploadTransDao.updateProcessStatusWithRemarks(uploadDTO.getBatchNo(),
                                Constants.UPLOAD_INVOICES_PLD_STATUS_ERROR, "This file formate is not Allowed");
                return Constants.FILEFORMATNOTALLOWED;
            }
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_PROCESSING,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadDTO);
            yearIdMap = commonDao.getYearId();
            // updating time Stamp in upload_log table
            uploadTransDao.updateTimeStamp(LogSQL.UPDATE_VALIDATION_START_TIME_STAMP, uploadDTO);
            // updating stages in upload_stage_log table
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_VALIDATION,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadDTO);

            // Validation on the list of object after file read
            validateInvoices(rowToPoJoList, 10000, uploadDTO);

            // upload_stage_log Table stage updating
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_DATA_VALIDATION,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadDTO);

            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_COMPLETED,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_START, uploadDTO);

            // converting List of Object (rowToPoJoList) to CSV file
            writeSuccessNErrorDataInCSVFile(yearIdMap, rowToPoJoList, uploadDTO);

            // getting file Path Using CommonUtil method
            String csvSuccessFilePath = CommonUtils.getSuccessFilePath(uploadDTO, tempFolder);
            String csvErrorFilePath = CommonUtils.getErrorFilePath(uploadDTO, tempFolder);

            // updating start time for Final Data insertion in DB
            uploadTransDao.updateTimeStamp(LogSQL.UPDATE_VALIDATION_START_TIME_STAMP, uploadDTO);

            // inserting data from CSV to Database
            ResponseBean responseBean = eInvoiceDao.gstInwardInvCdnInsert(csvSuccessFilePath, csvErrorFilePath,
                            Constants.SUCCESS_TRNS_TABLE, Constants.FAILURE_TRNS_TABLE);

            // update success and Error Count (Valid and not valid data) in
            // Database

            uploadTransDao.updateErrorNSuccessCountAndTotalCount(responseBean, uploadDTO.getBatchNo());

            uploadTransDao.updateTimeStamp(LogSQL.UPDATE_VALIDATION_FINAL_TIME_STAMP, uploadDTO);

            // get Data from e_invoice_failure table for new CSV
            List<EInvoiceTemplateDTO> errorDataListWithErrorCode = uploadTransDao
                            .getErrorDataListWithErrorCode(uploadDTO);

            errorDataListWithErrorCode = uploadMasterDao.setErrorDiscription(errorDataListWithErrorCode);

            if (!errorDataListWithErrorCode.isEmpty() && (Constants.PDF.equalsIgnoreCase(uploadDTO.getFileType())
                            || Constants.JPG.equalsIgnoreCase(uploadDTO.getFileType()))) {

                uploadTransDao.updateProcessStatusWithRemarks(uploadDTO.getBatchNo(),
                                Constants.UPLOAD_INVOICES_PLD_STATUS_ERROR,
                                uploadTransDao.getEinvoiceErrorMessage(errorDataListWithErrorCode));
            } else if (!errorDataListWithErrorCode.isEmpty()) {
                writeToAzureErrorDataInCSVFile(errorDataListWithErrorCode, uploadDTO);
                uploadNDownloadFileService.uploadErrorFile(uploadDTO, map);

            }

            // Update File name into Database which is uploaded on the Azure
            File file = new File(csvErrorFilePath);
            if (file.exists()) {

                uploadTransDao.updateErrorFileName(uploadDTO.getBatchNo(),
                                uploadDTO.getBatchNo() + Constants.ERROR_DOT_CSV);

            }

            // Update PLD status in upload_log table
            if (responseBean != null && responseBean.getErrorCount() > 0) {
                uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_ERROR);

                uploadTransDao.commonPostNotification(Constants.VENDORUPLOADMSTID,
                                Constants.INVOICE_FILE_UPLOAD_ERROR + uploadDTO.getBatchNo(), uploadDTO.getUserId(),
                                uploadDTO.getUserId(), uploadDTO.getUserId(), mstDatabseName,
                                Constants.NOTIFICATION_ERROR);
            } else {
                uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),
                                Constants.UPLOAD_INVOICES_PLD_STATUS_COMPLETED);
                if (responseBean != null) {
                    uploadTransDao.commonPostNotification(Constants.VENDORUPLOADMSTID,
                                    Constants.INVOICEFILEUPLOADED + uploadDTO.getBatchNo(), uploadDTO.getUserId(),
                                    uploadDTO.getUserId(), uploadDTO.getUserId(), mstDatabseName,
                                    Constants.NOTIFICATION_SUCCESS);
                }

            }
            // insert success records into invoice header table
            uploadTransDao.writeInvoiceDetailsToInvoiceHeader(uploadDTO.getBatchNo(), 0, uploadDTO.getUserId(),
                            mstDatabseName);
            ObjectMapper mapper = new ObjectMapper();
            String json = "";
            json += vendorInvoiceGrnMappingCrudDTOList.size() == 1
                            ? mapper.writeValueAsString(vendorInvoiceGrnMappingCrudDTOList).substring(1,
                                            mapper.writeValueAsString(vendorInvoiceGrnMappingCrudDTOList).length() - 1)
                            : mapper.writeValueAsString(vendorInvoiceGrnMappingCrudDTOList);
            uploadTransDao.poGrnMapping(uploadDTO, json);
            uploadTransDao.insertUploadStageNState(Constants.PROCESS_STAGE_COMPLETED,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadDTO);
            
        } catch (InvalidTemplateHeaderException ex) {

            uploadTransDao.updateProcessStatusWithRemarks(uploadDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE, ex.getMessage());
            uploadTransDao.commonPostNotification(Constants.VENDORUPLOADMSTID, Constants.INVALID_TEMPLATE,
                            uploadDTO.getUserId(), uploadDTO.getUserId(), uploadDTO.getUserId(), mstDatabseName,
                            Constants.NOTIFICATION_FAILED);

        } catch (ReadInvoicePojoListException | CsvWriteException | ReadInvoiceCustomTemplate
                        | VendorInvoiceServerException ex) {
            uploadTransDao.updateProcessStatusWithRemarks(uploadDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, ex.getMessage());
            uploadTransDao.commonPostNotification(Constants.VENDORUPLOADMSTID,
                            Constants.FAILED + uploadDTO.getBatchNo(), uploadDTO.getUserId(), uploadDTO.getUserId(),
                            uploadDTO.getUserId(), mstDatabseName, Constants.NOTIFICATION_FAILED);
        } catch (Exception ex) {

            log.error(Constants.PROCESSINGFILEEXCEPTIONLOG + uploadDTO.getBatchNo(), ex);
            if (!(StringConstant.HEADERCOUNTERRORMESSAGE + uploadDTO.getBatchNo()).equals(ex.getMessage())) {

                uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            }

            logIntoToExceptionTable(uploadDTO, ex, methodName);
        }
        finally {
        	deleteTempFiles(tempFolder, uploadDTO);
		}
        return Constants.FILEUPLOADEDSUCCESSFUL;

    }

    private void deleteTempFiles(String tempFolder, UploadReqDTO uploadDTO) {
 
        File baseFile = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR) + uploadDTO.getBatchNo()+
                         Constants.UNDERSCORE+Constants.BASE+
                         Constants.DOTSEPARATOR + uploadDTO.getFileType());
        if (baseFile.exists()) {
            FileUtils.deleteQuietly(baseFile);
        }
        File errorFile = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR) + uploadDTO.getBatchNo()
                        + Constants.ERROR_DOT_CSV);
        if (errorFile.exists()) {
            FileUtils.deleteQuietly(errorFile);
        }
        File successFile = new File(tempFolder + System.getProperty(Constants.FILESEPERATOR) + uploadDTO.getBatchNo()
                        + Constants.SUCCESS_DOT_CSV);
        if (successFile.exists()) {
            FileUtils.deleteQuietly(successFile);
        }

    }

    private List<EInvoiceTemplateDTO> getPdfEInvoiceDataList(UploadReqDTO uploadDTO)
                    throws IOException, VendorInvoiceServerException {
        List<EInvoiceTemplateDTO> eInvoiceRawData = new ArrayList<>();
        JSONObject qrScanRes = null;

        String fileName = new StringBuilder().append(tempFolder).append(System.getProperty(Constants.FILESEPERATOR))
                        .append(uploadDTO.getBatchNo()).append(Constants.UNSERSCORE_BASE).append(Constants.DOTSEPARATOR)
                        .append(uploadDTO.getFileType()).toString();
        EInvoiceTemplateDTO invoice = new EInvoiceTemplateDTO();
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            qrScanRes = scanPDFImageQR(fileName, uploadDTO);
            JSONArray resultArray = qrScanRes.getJSONArray(Constants.RESULT);

            if (resultArray.isEmpty() || resultArray == null) {
                String remarkMessage = messageSource.getMessage("upload.qr.scan.error", null,
                                LocaleContextHolder.getLocale());
                log.error(remarkMessage);

                throw new VendorInvoiceServerException(remarkMessage);
            }
            List<Map<String, Object>> resultSet = objectMapper.readValue(resultArray.toString(), List.class);

            // filter null values
            resultSet.forEach(e -> e.remove(null));

            // check no qr scanned
            if (resultSet.isEmpty()) {
                String remarkMessage = messageSource.getMessage("upload.qr.scan.error", null,
                                LocaleContextHolder.getLocale());
                log.error(remarkMessage);

                throw new VendorInvoiceServerException(remarkMessage);
            }

            for (Map<String, Object> result : resultSet) {

                String pageNumber = String.valueOf(result.get(Constants.QR_PAGE_NUMBER)) ;
                Map<String, Object> data = (Map<String, Object>) result.get(Constants.DATA);
                if (data.get(Constants.QR_DETECTED_NOT_READEBALE) != null) {
                    invoice = new EInvoiceTemplateDTO();
                    markErrorNAddErrorCode(invoice, ValidationConstants.EINVOICE_ERROR_CODE_E00513, Constants.BLANK);
                    invoice.setQrPageNo(pageNumber);
                    eInvoiceRawData.add(invoice);

                } else if (data.get(Constants.EWAYBILL_NO) != null) {
                    invoice = new EInvoiceTemplateDTO();
                    markErrorNAddErrorCode(invoice, ValidationConstants.EINVOICE_ERROR_CODE_E00585, Constants.BLANK);
                    invoice.setQrPageNo(pageNumber);
                    eInvoiceRawData.add(invoice);

                } else if (data.get(Constants.BUYERGSTIN) != null) {
                    uploadTransDao.updateQRScanFlag(uploadDTO.getBatchNo(), 1);
                    invoice = new EInvoiceTemplateDTO();
                    invoice.setGstinUinOfRecipient((String) data.get(Constants.BUYERGSTIN));
                    invoice.setGstinOfSupplier((String) data.get(Constants.SELLERGSTIN));
                    invoice.setDocType((String) data.get(Constants.DOCTYP));
                    invoice.setInwardNo((String) data.get(Constants.DOCNO));
                    invoice.setInwardDate(DateUtil.convertDateFormattoScreen2((String) data.get(Constants.DOCDT)));
                    if (uploadDTO.getFp() == null) {
                        List<String> fp = new ArrayList<>(Arrays.asList(
                                        DateUtil.convertDateToFillingPeriod((String) data.get(Constants.DOCDT))));
                        uploadDTO.setFp(fp);
                        uploadTransDao.updateFpLog(uploadDTO.getFp(), uploadDTO);
                    }
                    invoice.setFillingPeriod(uploadDTO.getFp().get(0));
                    invoice.setTotalInvoiceValue(String.valueOf(data.get(Constants.TOTINVVAL)));
                    invoice.setMainHSNCode((String) data.get(Constants.MAINHSNCODE));
                    invoice.setItemCount((Integer) data.get(Constants.ITEMCOUNT));
                    invoice.setIrn((String) data.get(Constants.IRN));
                    invoice.setIrnDate(DateUtil.convertDateFormattoScreen1((String) data.get(Constants.IRNDT)));
                    invoice.setPurchaseOrderDate(uploadDTO.getPoDate());
                    invoice.setPurchaseOrderNumber(uploadDTO.getPo());
                    invoice.setValid(true);

                    if (StringUtils.isNotBlank(invoice.getGstinUinOfRecipient())
                                    && invoice.getGstinUinOfRecipient().length() == 15) {
                        invoice.setPanOfRecipient(invoice.getGstinUinOfRecipient().substring(2, 12));
                    } else {
                        invoice.setPanOfRecipient("");
                    }
                    invoice.setQrPageNo(pageNumber);
                    eInvoiceRawData.add(invoice);
                }
            }
            if (eInvoiceRawData.isEmpty()) {
                String remarkMessage = messageSource.getMessage("upload.qr.scan.error", null,
                                LocaleContextHolder.getLocale());
                log.error(remarkMessage);
                throw new VendorInvoiceServerException(remarkMessage);
            }
            return eInvoiceRawData;
        } catch (Exception ex) {

            log.error("Error generated in getPdfEInvoiceDataList:: ", ex);
            uploadTransDao.updateProcessStatusWithRemarks(uploadDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, ex.getMessage());

            logIntoToExceptionTable(uploadDTO, ex, "getPdfEInvoiceDataList");

            if (ex.getMessage().equals(messageSource.getMessage("upload.multiple.qr.error", null,
                            LocaleContextHolder.getLocale()))) {
                throw new VendorInvoiceServerException(ex.getMessage());

            } else if (ex.getMessage().equals(
                            messageSource.getMessage("upload.qr.scan.error", null, LocaleContextHolder.getLocale()))) {
                throw new VendorInvoiceServerException(ex.getMessage());

            } else if (ex.getMessage().equals(messageSource.getMessage("upload.qr.scan.invalid.type", null,
                            LocaleContextHolder.getLocale()))) {
                throw new VendorInvoiceServerException(ex.getMessage());

            } else if (ex.getMessage().equals(messageSource.getMessage("upload.qr.scan.api.exception", null,
                            LocaleContextHolder.getLocale()))) {
                throw new VendorInvoiceServerException(ex.getMessage());

            } else {
                throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
                                LocaleContextHolder.getLocale()));
            }
        }

    }

    private JSONObject scanPDFImageQR(String fileName, UploadReqDTO uploadDTO) throws VendorInvoiceServerException {
        JSONObject qrScanRes = null;
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", new FileSystemResource(fileName));
        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body);
        String serverUrl = commonDao.getSystemParameterCredential(Constants.INVOICE_SCAN_URL);
        uploadTransDao.insertIntoQRExecutionLog(uploadDTO, null, LocalDateTime.now(), null);
        RestTemplate restTemplate = new RestTemplate();
        try {
            qrScanRes = new JSONObject(restTemplate.postForObject(serverUrl, requestEntity, String.class));
            uploadTransDao.insertIntoQRExecutionLog(uploadDTO, qrScanRes.toString(), null, LocalDateTime.now());
            return qrScanRes;
        } catch (Exception ex) {
            String remarkMessage = messageSource.getMessage("upload.qr.scan.api.exception", null,
                            LocaleContextHolder.getLocale());
            log.error(remarkMessage);

            throw new VendorInvoiceServerException(remarkMessage);
        }

    }

    private List<EInvoiceTemplateDTO> getPdfInvoiceDataList(UploadReqDTO uploadDTO)
                    throws VendorInvoiceServerException {
        List<EInvoiceTemplateDTO> eInvoiceRawData = new ArrayList<>();

        EInvoiceTemplateDTO invoice = new EInvoiceTemplateDTO();
        try {

            invoice = new EInvoiceTemplateDTO();
            invoice.setGstinUinOfRecipient(uploadDTO.getGstinOrPanList().get(0));
            invoice.setGstinOfSupplier(uploadDTO.getVendorPanOrGstin());
            invoice.setDocType(uploadDTO.getDocType());
            invoice.setInwardNo(uploadDTO.getInvoiceNo());
            invoice.setInwardDate(uploadDTO.getInvoiceDate());
            invoice.setFillingPeriod(uploadDTO.getFp().get(0));
            invoice.setPurchaseOrderDate(uploadDTO.getPoDate());
            invoice.setPurchaseOrderNumber(uploadDTO.getPo());
            invoice.setValid(true);

            if (StringUtils.isNotBlank(invoice.getGstinUinOfRecipient())
                            && invoice.getGstinUinOfRecipient().length() == 15) {
                invoice.setPanOfRecipient(invoice.getGstinUinOfRecipient().substring(2, 12));
            } else {
                invoice.setPanOfRecipient("");
            }

            eInvoiceRawData.add(invoice);

            return eInvoiceRawData;
        } catch (Exception ex) {

            log.error("Error generated in getPdfEInvoiceDataList:: ", ex);
            uploadTransDao.updateProcessStatusWithRemarks(uploadDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL, ex.getMessage());

            logIntoToExceptionTable(uploadDTO, ex, "getPdfEInvoiceDataList");

            throw new VendorInvoiceServerException("Something went wrong, try again later");
        }

    }

    @Override
    public List<EInvoiceTemplateDTO> getEinvoiceDataList(UploadReqDTO uploadDTO)
                    throws InvalidTemplateHeaderException, IOException, ReadInvoicePojoListException {

        String methodName = "getEinvoiceDataList";
        List<EInvoiceTemplateDTO> invoiceList = new ArrayList<>();
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(uploadDTO.getFileType());

        Map<String, Object> rowCountWithHeader = new HashMap<>();

        try {
            try (InputStream inputStream = new FileInputStream(new File(fileName.toString()));
                            BufferedInputStream br = new BufferedInputStream(inputStream)) {
                // getting HeaderRowIndexs , coumnsDataRow ,RowCount
                rowCountWithHeader = getRowCountWithHeader(inputStream, uploadDTO);
            }
        } catch (Exception e2) {
            log.error("Error in validateAndSaveData method", e2);
            uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();

            String methodName1 = "getExcelEWayDataList";

            exceptionLogDTO.setUserId(uploadDTO.getId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
            exceptionLogDTO.setFunctionName(methodName1);
            exceptionLogDTO.setErrorMessage(e2.getMessage());
            exceptionLogDTO.setErrorCause(Constants.NOTCONTAINPROPERDATA);
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());

            commonDao.updateExceptionLogTable(exceptionLogDTO);

            throw new ReadInvoicePojoListException(e2.getMessage());
        }

        headerRow = (Row) rowCountWithHeader.get(Constants.DATA_ROW);

        try {
            colNameIndexMap = AppUtil.getColumnNameIndexMap(headerRow);
        } catch (Exception ex) {

            log.error("Error in getEinvoiceDataList", ex);
            uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);

            logIntoToExceptionTable(uploadDTO, ex, methodName);

            throw new ReadInvoicePojoListException(ex.getMessage(), ex.getCause());
        }

        // throw exception and Update in Exception Log table as per Batch Number
        if (Constants.E_INVOICE_TEMPLATE_COLUMN_COUNT != colNameIndexMap.size()) {
            uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);
            throw new InvalidTemplateHeaderException(StringConstant.HEADERCOUNTERRORMESSAGE + uploadDTO.getBatchNo());

        }

        try (InputStream in = new FileInputStream(new File(fileName.toString()));
                        BufferedInputStream bis = new BufferedInputStream(in);
                        Workbook workbook = StreamingReader.builder().open(bis);) {

            Sheet sheet = workbook.getSheetAt(0);
            fpSetSftp = new HashSet<>();
            sheet.forEach(row -> {
                EInvoiceTemplateDTO rowObj = new EInvoiceTemplateDTO();
                if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 1) {
                    rowObj.setExcelRowId(row.getRowNum());
                    try {
                        // reading Excel Template
                        rowObj = readTemplateRecord(row, colNameIndexMap, uploadDTO);
                        rowObj.setValid(true);

                    } catch (Exception e) {
                        log.error("Error generated:: ", e);
                        markErrorNAddErrorCode(rowObj, ValidationConstants.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
                    }
                    if (rowObj.getFillingPeriod().length() == 5) {
                        rowObj.setFillingPeriod(Constants.ZEROVALUE + rowObj.getFillingPeriod());
                    }
                    if (StringUtils.isNotBlank(rowObj.getGstinUinOfRecipient())
                                    && rowObj.getGstinUinOfRecipient().length() == 15) {
                        rowObj.setPanOfRecipient(rowObj.getGstinUinOfRecipient().substring(2, 12));
                    } else {
                        rowObj.setPanOfRecipient("");

                    }
                    if (StringUtils.isNotBlank(rowObj.getFillingPeriod())) {
                        fpSetSftp.add(rowObj.getFillingPeriod());
                    }
                    invoiceList.add(rowObj);
                }
            });
            if ("ftps".equals(uploadDTO.getUplodSource()) || uploadDTO.getFp().isEmpty()) {
                uploadDTO.setFp(new ArrayList<>(fpSetSftp));
                uploadTransDao.updateFpLog(uploadDTO.getFp(), uploadDTO);
            }
        } catch (Exception exception) {
            log.error("Error in getEinvoiceDataList method", exception);
            throw new ReadInvoicePojoListException("Exception found in reading excel", exception);
        }

        return invoiceList;
    }

    private EInvoiceTemplateDTO readTemplateRecord(Row row, Map<String, Integer> colNameIndexMap,
                    UploadReqDTO uploadDTO) {

        EInvoiceTemplateDTO xlsRow = new EInvoiceTemplateDTO();

        try {

            xlsRow.setGstinUinOfRecipient(AppUtil
                            .getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setDocType(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_DOC_TYPE)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setInwardNo(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_INWARD_NO)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setInwardDate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_INWARD_DATE)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setGstinOfSupplier(
                            AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_GSTIN_OF_SUPPLIER)))
                                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setMainHSNCode(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_HSN_CODE)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setTotalInvoiceValue(AppUtil
                            .getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_TOTAL_INVOICE_AMOUNT)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setPurchaseOrderNumber(
                            AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_PURCHASE_ORDER_NO)))
                                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setFillingPeriod(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.FILLING_PERIOD)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));

            xlsRow.setPurchaseOrderDate(
                            AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_PURCHASE_ORDER_DATE)))
                                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setIrn(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_IRN)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setIrnDate(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_IRN_DATE)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));

            xlsRow.setUdf1(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_1)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf2(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_2)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf3(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_3)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf4(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_4)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf5(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_5)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf6(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_6)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf7(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_7)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf8(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_8)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf9(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_9)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf10(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_10)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf11(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_11)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf12(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_12)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf13(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_13)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf14(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_14)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf15(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_15)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf16(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_16)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf17(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_17)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf18(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_18)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf19(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_19)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setUdf20(AppUtil.getCellValue(row.getCell(colNameIndexMap.get(Constants.COLUMN_UDF_20)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));

        } catch (Exception ex) {
            // Mark as not Valid object if Exception occur
            log.error("Error generated:: ", ex);
            markErrorNAddErrorCode(xlsRow, ValidationConstants.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
            ExceptionLogDTO exceptionLogDto = new ExceptionLogDTO();
            exceptionLogDto.setUserId(uploadDTO.getUploadBy());
            exceptionLogDto.setScreenName(Constants.INVOICEINTEGRATION);
            exceptionLogDto.setFunctionName("readTemplateRecord");
            exceptionLogDto.setErrorMessage(ex.getMessage());
            exceptionLogDto.setErrorCause(ex.getCause().getMessage());
            exceptionLogDto.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDto.setCreatedAt(LocalDateTime.now());

            commonDao.updateExceptionLogTable(exceptionLogDto);

            log.error("Errro occured while reading row " + row.getRowNum() + " for batch No. " + ex);
        }
        return xlsRow;
    }

    public Map<String, Object> getRowCountWithHeader(InputStream fis, UploadReqDTO uploadDTO)
                    throws IOException, ReadInvoicePojoListException {
        Map<String, Object> dataMap = new HashMap<>();
        String methodName = "getRowCountWithHeader";
        int totalRowCount = 0;
        try (InputStream is = new BufferedInputStream(fis); Workbook workbook = StreamingReader.builder().open(is);) {

            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 1) {
                    totalRowCount++;
                } else if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() <= 1 && totalRowCount == 0) {

                    Row coumnsDataRow = null;
                    coumnsDataRow = row;
                    dataMap.put("headerRowIndex", row.getRowNum());
                    dataMap.put("coumnsDataRow", coumnsDataRow);

                }

            }
            dataMap.put("RowCount", totalRowCount);
            return dataMap;
        } catch (Exception ex) {
            log.error("Error in getEinvoiceDataList method ", ex);
            logIntoToExceptionTable(uploadDTO, ex, methodName);
            throw new ReadInvoicePojoListException(StringConstant.HEADERCOUNTERRORMESSAGE + uploadDTO.getBatchNo());

        }

    }

    private List<EInvoiceTemplateDTO> validateInvoices(List<EInvoiceTemplateDTO> dataList, int threadCnt,
                    UploadReqDTO uploadDTO) {

        List<EInvoiceTemplateDTO> validatedList = new ArrayList<>();

        Map<String, Map<String, String>> savedDataInGST = new HashMap<>();
        for (int gstinIndex = 0; gstinIndex < uploadDTO.getGstinOrPanList().size(); gstinIndex++) {

            savedDataInGST.put(uploadDTO.getGstinOrPanList().get(gstinIndex), uploadTransDao
                            .getFieldsValue(uploadDTO.getGstinOrPanList().get(gstinIndex), uploadDTO.getFp()));
        }

        Map<String, Map<String, String>> diffrenceFPMap = new HashMap<>();

        List<List<EInvoiceTemplateDTO>> partList = Lists.partition(dataList, threadCnt);
        String[] eInvoiceGstinListFromDB = null;
        // 0 for PAN and 1 for GSTIN List
        if (Constants.PAN.equals(uploadDTO.getPanOrGstn())) {
            eInvoiceGstinListFromDB = commonDao.getGstinFromDB(uploadDTO.getGstinOrPanList().get(0), mstDatabseName);
        } else if (Constants.GSTIN.equals(uploadDTO.getPanOrGstn())) {
            eInvoiceGstinListFromDB = uploadDTO.getGstinOrPanList()
                            .toArray(new String[uploadDTO.getGstinOrPanList().size()]);

        }
        yearIdMap = commonDao.getYearId();
        int totalProcessedRec = 0;
        for (List<EInvoiceTemplateDTO> sublist : partList) {

            totalProcessedRec = totalProcessedRec + sublist.size();

            List<EInvoiceTemplateDTO> rulesValidatedsublist = runParallalProcessingValidations(sublist,
                            eInvoiceGstinListFromDB, uploadDTO.getFp().toArray(new String[uploadDTO.getFp().size()]),
                            uploadDTO);

            if (!rulesValidatedsublist.isEmpty()) {
                rulesValidatedsublist.forEach(validatedList::add);
            }

        }
        savedDataInGST.clear();
        diffrenceFPMap.clear();

        return validatedList;
    }

    private List<EInvoiceTemplateDTO> runParallalProcessingValidations(List<EInvoiceTemplateDTO> dataList,
                    String[] eWayGstinListFromDB, String[] fpList, UploadReqDTO uploadDto) {

        Map<String, Map<String, String>> suppGSTNWiseMap = new ConcurrentHashMap<String, Map<String, String>>();
        Map<String, Map<String, String>> approvalValidationMap = new ConcurrentHashMap<String, Map<String, String>>();
        List<EInvoiceTemplateDTO> validatedList = new ArrayList<>();
        List<EInvoiceTemplateDTO> validatedUpdatedList = new ArrayList<>();

        dataList.forEach(rowData -> {

            if (!rowData.getErrorCodeList().toString().contains(ValidationConstants.EINVOICE_ERROR_CODE_E00513)
                            && !rowData.getErrorCodeList().toString()
                                            .contains(ValidationConstants.EINVOICE_ERROR_CODE_E00585)) {
                markDocNoLevelError(rowData);

                if (StringUtils.isBlank(rowData.getFillingPeriod())) {
                    markErrorNAddErrorCode(rowData, ValidationConstants.EINVOICE_ERROR_CODE_E00352, "");
                }
                if (yearIdMap.containsKey(rowData.getFillingPeriod())) {
                    rowData.setYearId(yearIdMap.get(rowData.getFillingPeriod()));
                } else {
                    rowData.setYearId("");
                    markErrorNAddErrorCode(rowData, ValidationConstants.EINVOICE_ERROR_CODE_E00514, "");
                }

                if ((!StringUtils.isBlank(rowData.getGstinUinOfRecipient())) && Arrays.stream(eWayGstinListFromDB)
                                .noneMatch(rowData.getGstinUinOfRecipient()::equalsIgnoreCase)) {
                    markErrorNAddErrorCode(rowData, ValidationConstants.ERROR_CODE_E00324, Constants.BLANK);
                }
                if (StringUtils.isBlank(rowData.getGstinUinOfRecipient())
                                || "0".equals(rowData.getGstinUinOfRecipient())
                                || StringUtils.isEmpty(rowData.getGstinUinOfRecipient())) {
                    markErrorNAddErrorCode(rowData, ValidationConstants.ERROR_CODE_E00114, Constants.BLANK);
                }

                try {
                    EInvoiceDataTypeValidations invDataTypeCheck = new EInvoiceDataTypeValidations();
                    // going for applying Data type Validation
                    invDataTypeCheck.validateDataType(rowData, fpList);

                    EInvoiceValidationRules invTemplValidations = new EInvoiceValidationRules();
                    // going for applying Validation Rules
                    invTemplValidations.validateRules(rowData, uploadDto);

                    if (rowData.isValid()) {

                        String supplierGstnInwardNo = rowData.getGstinOfSupplier() + rowData.getInwardNo();
                        if (StringUtils.isNotBlank(supplierGstnInwardNo)) {
                            supplierGstnInwardNo = supplierGstnInwardNo.toLowerCase();
                        }

                        int isduplicateInvoiceInDiffMonth = 0;

                        // Check invoice already saved in the GSTN
                        String keyCheckInBatchData = rowData.getGstinUinOfRecipient() + rowData.getFillingPeriod()
                                        + uploadDto.getBatchNo();
                        List<String> invoiceListForFP = null;
                        if (suppGSTNWiseMap.get(keyCheckInBatchData) == null) {
                            invoiceListForFP = uploadTransDao.getInvoiceDuplicateInvoiceInDiffFP(
                                            rowData.getGstinOfSupplier(), rowData.getGstinUinOfRecipient(),
                                            rowData.getFillingPeriod());
                            Map<String, String> map = invoiceListForFP.stream()
                                            .collect(Collectors.toMap(str -> str, str -> str));
                            suppGSTNWiseMap.put(keyCheckInBatchData, map);
                            if (suppGSTNWiseMap.get(keyCheckInBatchData).get(supplierGstnInwardNo) != null) {
                                isduplicateInvoiceInDiffMonth++;
                            }

                        } else {
                            Map<String, String> map = suppGSTNWiseMap.get(keyCheckInBatchData);
                            if (map != null && map.get(supplierGstnInwardNo) != null) {
                                isduplicateInvoiceInDiffMonth++;
                            }
                        }

                        if (isduplicateInvoiceInDiffMonth > 0) {

                            markErrorNAddErrorCode(rowData, "|O0093", "|Duplicate invoice in differernt month");
                        }

                    }

                    // check record is already Approved or not
                    if (rowData.isValid()) {
                        String keyDataToApprovalCheck = rowData.getGstinUinOfRecipient() + rowData.getGstinOfSupplier()
                                        + rowData.getInwardNo() + rowData.getDocType();
                        List<String> invoiceHeaderCrId = new ArrayList<>();
                        int isAlreadyApproved = 0;
                        if (approvalValidationMap.get(rowData.getGstinUinOfRecipient()) == null) {
                            invoiceHeaderCrId = uploadTransDao
                                            .getInvoiceAlreadyApproved(rowData.getGstinUinOfRecipient());
                            Map<String, String> map = invoiceHeaderCrId.stream()
                                            .collect(Collectors.toMap(str -> str, str -> str));

                            approvalValidationMap.put(rowData.getGstinUinOfRecipient(), map);
                            if (approvalValidationMap.get(rowData.getGstinUinOfRecipient())
                                            .get(keyDataToApprovalCheck) != null) {
                                isAlreadyApproved = 1;
                            }
                        } else {
                            if (approvalValidationMap.get(rowData.getGstinUinOfRecipient())
                                            .get(keyDataToApprovalCheck) != null) {
                                isAlreadyApproved = 1;
                            }
                        }

                        if (isAlreadyApproved > 0) {

                            markErrorNAddErrorCode(rowData, ValidationConstants.EINVOICE_ERROR_CODE_O0090,
                                            Constants.BLANK);
                        }

                    }

                } catch (Exception | Error e) {

                    log.error("Error Occured while validation row " + rowData.getExcelRowId(), e);

                    markErrorNAddErrorCode(rowData, ValidationConstants.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);

                }

                validatedList.add(rowData);
            }

        });

        /* validate already synced/processed in erp */
        validatedUpdatedList = eInvoiceAlreadySyncedValidation.validateAlreadySyncedStatus(validatedList);

        return validatedUpdatedList;
    }

    // save to Local as .csv

    public void writeSuccessNErrorDataInCSVFile(Map<String, String> yearIdMap,
                    List<EInvoiceTemplateDTO> eInvoiceTemplateDTOs, UploadReqDTO uploadDTO)
                    throws IOException, CsvWriteException {

        List<EInvoiceTemplateDTO> valid = new ArrayList<>();
        List<EInvoiceTemplateDTO> notValid = new ArrayList<>();

        eInvoiceTemplateDTOs.forEach(eInvoiceTemplateDTOObject -> {

            // adding to valid or notValid list According to Status code of
            // Object

            if (eInvoiceTemplateDTOObject.isValid()) {
                valid.add(eInvoiceTemplateDTOObject);
            } else {
                notValid.add(eInvoiceTemplateDTOObject);
            }
        });
        try {
            String csvSuccessFilePath = CommonUtils.getSuccessFilePath(uploadDTO, tempFolder);
            String csvErrorFilePath = CommonUtils.getErrorFilePath(uploadDTO, tempFolder);

            // Method for CSV writing
            if (!valid.isEmpty()) {
                InputStream validStream = null;
                validStream = einvoiceExcelDataToCSVSuccess(uploadDTO, valid);

                Files.copy(validStream, Paths.get(csvSuccessFilePath));
            }
            if (!notValid.isEmpty()) {
                InputStream nonValidStream = null;

                nonValidStream = einvoiceExcelDataToCSV(uploadDTO, notValid);

                Files.copy(nonValidStream, Paths.get(csvErrorFilePath));
            }
        } catch (Exception ex) {
            log.error("Error in writing csv");
            if (!ex.getMessage().contains("CSV file")) {
                throw new CsvWriteException("Error while writing csv File ");
            }
            throw new CsvWriteException(ex.getMessage());
        }

    }

    public ByteArrayInputStream einvoiceExcelDataToCSV(UploadReqDTO uploadDTO, List<EInvoiceTemplateDTO> excelData)
                    throws IOException, CsvWriteException {

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<String> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {

            list = Stream.of(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT, Constants.TAXPAYER_PAN, Constants.COLUMN_DOC_TYPE,
                            Constants.COLUMN_INWARD_NO, Constants.COLUMN_INWARD_DATE,
                            Constants.COLUMN_GSTIN_OF_SUPPLIER, Constants.COLUMN_HSN_CODE,
                            Constants.COLUMN_TOTAL_INVOICE_AMOUNT, Constants.COLUMN_PURCHASE_ORDER_NO,
                            Constants.COLUMN_PURCHASE_ORDER_DATE, Constants.COLUMN_IRN, Constants.COLUMN_IRN_DATE,
                            Constants.FILLING_PERIOD, Constants.COLUMN_UDF_1, Constants.COLUMN_UDF_2,
                            Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4, Constants.COLUMN_UDF_5,
                            Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7, Constants.COLUMN_UDF_8,
                            Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10, Constants.COLUMN_UDF_11,
                            Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13, Constants.COLUMN_UDF_14,
                            Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16, Constants.COLUMN_UDF_17,
                            Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19, Constants.COLUMN_UDF_20)
                            .collect(Collectors.toList());

            list.add(0, Constants.ID);
            list.add(Constants.ROWVERSION);
            list.add(Constants.COLUMN_STATUS);
            list.add(Constants.BATCHNO);
            list.add(Constants.ERROR_CODE_LIST);
            list.add("QR_Page_Number");

            csvPrinter.printRecord(list);

            if (!excelData.isEmpty()) {
                for (EInvoiceTemplateDTO eInvoiceTemplateDTO : excelData) {
                    List<Object> data = Arrays.asList(Constants.BLANK, eInvoiceTemplateDTO.getGstinUinOfRecipient(),
                                    eInvoiceTemplateDTO.getPanOfRecipient(), eInvoiceTemplateDTO.getDocType(),
                                    eInvoiceTemplateDTO.getInwardNo(), eInvoiceTemplateDTO.getInwardDate(),
                                    eInvoiceTemplateDTO.getGstinOfSupplier(), eInvoiceTemplateDTO.getMainHSNCode(),
                                    eInvoiceTemplateDTO.getTotalInvoiceValue(),
                                    eInvoiceTemplateDTO.getPurchaseOrderNumber(),
                                    eInvoiceTemplateDTO.getPurchaseOrderDate(), eInvoiceTemplateDTO.getIrn(),
                                    eInvoiceTemplateDTO.getIrnDate(), eInvoiceTemplateDTO.getFillingPeriod(),
                                    eInvoiceTemplateDTO.getUdf1(), eInvoiceTemplateDTO.getUdf2(),
                                    eInvoiceTemplateDTO.getUdf3(), eInvoiceTemplateDTO.getUdf4(),
                                    eInvoiceTemplateDTO.getUdf5(), eInvoiceTemplateDTO.getUdf6(),
                                    eInvoiceTemplateDTO.getUdf7(), eInvoiceTemplateDTO.getUdf8(),
                                    eInvoiceTemplateDTO.getUdf9(), eInvoiceTemplateDTO.getUdf10(),
                                    eInvoiceTemplateDTO.getUdf11(), eInvoiceTemplateDTO.getUdf12(),
                                    eInvoiceTemplateDTO.getUdf13(), eInvoiceTemplateDTO.getUdf14(),
                                    eInvoiceTemplateDTO.getUdf15(), eInvoiceTemplateDTO.getUdf16(),
                                    eInvoiceTemplateDTO.getUdf17(), eInvoiceTemplateDTO.getUdf18(),
                                    eInvoiceTemplateDTO.getUdf19(), eInvoiceTemplateDTO.getUdf20(),
                                    Timestamp.from(Instant.now()), Constants.NON_VALID_LIST, uploadDTO.getBatchNo(),
                                    eInvoiceTemplateDTO.getErrorCodeList(), eInvoiceTemplateDTO.getQrPageNo());
                    csvPrinter.printRecord(data);

                }
            }
            csvPrinter.flush();
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error("fail to import data to CSV file" + e);

            throw new CsvWriteException("Failed to import data to CSV file: " + e.getMessage());
        }
    }

    public ByteArrayInputStream einvoiceExcelDataToCSVSuccess(UploadReqDTO uploadDTO,
                    List<EInvoiceTemplateDTO> excelData) throws IOException, CsvWriteException {

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<String> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {

            list = Stream.of(Constants.ID, Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT, Constants.TAXPAYER_PAN,
                            Constants.YEAR_ID, Constants.COLUMN_DOC_TYPE, Constants.COLUMN_INWARD_NO,
                            Constants.COLUMN_INWARD_DATE, Constants.COLUMN_GSTIN_OF_SUPPLIER, Constants.COLUMN_HSN_CODE,
                            Constants.ITEMCOUNT, Constants.COLUMN_TOTAL_INVOICE_AMOUNT,
                            Constants.COLUMN_PURCHASE_ORDER_NO, Constants.COLUMN_PURCHASE_ORDER_DATE,
                            Constants.COLUMN_IRN, Constants.COLUMN_IRN_DATE, Constants.COLUMN_BILL_VALID_DATE,
                            Constants.TEMPLATE_TYPE, Constants.FILLING_PERIOD, Constants.COLUMN_UDF_1,
                            Constants.COLUMN_UDF_2, Constants.COLUMN_UDF_3, Constants.COLUMN_UDF_4,
                            Constants.COLUMN_UDF_5, Constants.COLUMN_UDF_6, Constants.COLUMN_UDF_7,
                            Constants.COLUMN_UDF_8, Constants.COLUMN_UDF_9, Constants.COLUMN_UDF_10,
                            Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12, Constants.COLUMN_UDF_13,
                            Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15, Constants.COLUMN_UDF_16,
                            Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18, Constants.COLUMN_UDF_19,
                            Constants.COLUMN_UDF_20, Constants.ROWVERSION, Constants.VALID, Constants.BATCHNO,
                            Constants.COLUMN_EWAY_BILL_NO, Constants.COLUMN_EWAY_BILL_DATE)
                            .collect(Collectors.toList());
            csvPrinter.printRecord(list);
            int id = 0;
            if (!excelData.isEmpty()) {

                for (EInvoiceTemplateDTO eInvoiceTemplateDTO : excelData) {
                    id++;
                    vendorInvoiceGrnMappingCrudDTOList.add(CommonUtils.setVendorInvoiceGrnMappingCrudDTO(id,
                                    eInvoiceTemplateDTO, vendorInvoiceGrnMappingCrudDTOList));
                    List<Object> data = Arrays.asList(Constants.BLANK, eInvoiceTemplateDTO.getGstinUinOfRecipient(),
                                    eInvoiceTemplateDTO.getPanOfRecipient(), eInvoiceTemplateDTO.getYearId(),
                                    eInvoiceTemplateDTO.getDocType(), eInvoiceTemplateDTO.getInwardNo(),
                                    eInvoiceTemplateDTO.getInwardDate(), eInvoiceTemplateDTO.getGstinOfSupplier(),
                                    eInvoiceTemplateDTO.getMainHSNCode(), eInvoiceTemplateDTO.getItemCount(),
                                    eInvoiceTemplateDTO.getTotalInvoiceValue(),
                                    eInvoiceTemplateDTO.getPurchaseOrderNumber(),
                                    eInvoiceTemplateDTO.getPurchaseOrderDate(), eInvoiceTemplateDTO.getIrn(),
                                    eInvoiceTemplateDTO.getIrnDate(), Constants.BLANK, uploadDTO.getTemplateType(),
                                    eInvoiceTemplateDTO.getFillingPeriod(), eInvoiceTemplateDTO.getUdf1(),
                                    eInvoiceTemplateDTO.getUdf2(), eInvoiceTemplateDTO.getUdf3(),
                                    eInvoiceTemplateDTO.getUdf4(), eInvoiceTemplateDTO.getUdf5(),
                                    eInvoiceTemplateDTO.getUdf6(), eInvoiceTemplateDTO.getUdf7(),
                                    eInvoiceTemplateDTO.getUdf8(), eInvoiceTemplateDTO.getUdf9(),
                                    eInvoiceTemplateDTO.getUdf10(), eInvoiceTemplateDTO.getUdf11(),
                                    eInvoiceTemplateDTO.getUdf12(), eInvoiceTemplateDTO.getUdf13(),
                                    eInvoiceTemplateDTO.getUdf14(), eInvoiceTemplateDTO.getUdf15(),
                                    eInvoiceTemplateDTO.getUdf16(), eInvoiceTemplateDTO.getUdf17(),
                                    eInvoiceTemplateDTO.getUdf18(), eInvoiceTemplateDTO.getUdf19(),
                                    eInvoiceTemplateDTO.getUdf20(), Timestamp.from(Instant.now()),
                                    Constants.VALID_STATUS, uploadDTO.getBatchNo(), Constants.BLANK, Constants.BLANK);
                    csvPrinter.printRecord(data);

                }
            }
            csvPrinter.flush();

            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error("fail to import data to CSV file" + e);
            throw new CsvWriteException("fail to import data to CSV file: " + e.getMessage());
        }
    }

    public List<EInvoiceTemplateDTO> getCsvEInvoiceDataList(UploadReqDTO uploadDTO) throws IOException {
        List<EInvoiceTemplateDTO> eInvoiceRawData = new ArrayList<>();
        int cnt = 0;

        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(Constants.FILESEPERATOR)).append(uploadDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(Constants.DOTSEPARATOR)
                        .append(uploadDTO.getFileType());

        CsvReader einvoices = new CsvReader(fileName.toString(), StringConstant.COMMASEPERATOR, StandardCharsets.UTF_8);
        CsvReader readHeaderCount = new CsvReader(fileName.toString(), StringConstant.COMMASEPERATOR,
                        StandardCharsets.UTF_8);

        // Add code if header is missing then mark as invalid template
        String[] indexHeaders = AppUtil.getHeaders(readHeaderCount);
        if (Constants.E_INVOICE_TEMPLATE_COLUMN_COUNT != indexHeaders.length) {

            uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);

            throw new InvalidTemplateHeaderException(StringConstant.HEADERCOUNTERRORMESSAGE + uploadDTO.getBatchNo());

        }

        fpSetSftp = new HashSet<>();
        einvoices.readHeaders();
        while (einvoices.readRecord()) {
            EInvoiceTemplateDTO invoiceDto = new EInvoiceTemplateDTO();
            try {

                cnt++;
                if (cnt > 0) {
                    invoiceDto.setGstinUinOfRecipient(
                                    einvoices.get(0).replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    invoiceDto.setDocType(einvoices.get(Constants.COLUMN_DOC_TYPE).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setInwardNo(einvoices.get(Constants.COLUMN_INWARD_NO)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    invoiceDto.setInwardDate(einvoices.get(Constants.COLUMN_INWARD_DATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    invoiceDto.setGstinOfSupplier(einvoices.get(Constants.COLUMN_GSTIN_OF_SUPPLIER)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    invoiceDto.setFillingPeriod(einvoices.get(Constants.FILLING_PERIOD)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    invoiceDto.setMainHSNCode(einvoices.get(Constants.COLUMN_HSN_CODE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    invoiceDto.setTotalInvoiceValue(einvoices.get(Constants.COLUMN_TOTAL_INVOICE_AMOUNT)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    invoiceDto.setPurchaseOrderNumber((einvoices.get(Constants.COLUMN_PURCHASE_ORDER_NO))
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    invoiceDto.setPurchaseOrderDate(einvoices.get(Constants.COLUMN_PURCHASE_ORDER_DATE)
                                    .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
                    invoiceDto.setIrn(einvoices.get(Constants.COLUMN_IRN).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setIrnDate(einvoices.get(Constants.COLUMN_IRN_DATE).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf1(einvoices.get(Constants.COLUMN_UDF_1).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf2(einvoices.get(Constants.COLUMN_UDF_2).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf3(einvoices.get(Constants.COLUMN_UDF_3).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf4(einvoices.get(Constants.COLUMN_UDF_4).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf5(einvoices.get(Constants.COLUMN_UDF_5).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf6(einvoices.get(Constants.COLUMN_UDF_6).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf7(einvoices.get(Constants.COLUMN_UDF_7).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf8(einvoices.get(Constants.COLUMN_UDF_8).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf9(einvoices.get(Constants.COLUMN_UDF_9).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf10(einvoices.get(Constants.COLUMN_UDF_10).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf11(einvoices.get(Constants.COLUMN_UDF_11).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf12(einvoices.get(Constants.COLUMN_UDF_12).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf13(einvoices.get(Constants.COLUMN_UDF_13).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf14(einvoices.get(Constants.COLUMN_UDF_14).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf15(einvoices.get(Constants.COLUMN_UDF_15).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf16(einvoices.get(Constants.COLUMN_UDF_16).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf17(einvoices.get(Constants.COLUMN_UDF_17).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf18(einvoices.get(Constants.COLUMN_UDF_18).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf19(einvoices.get(Constants.COLUMN_UDF_19).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setUdf20(einvoices.get(Constants.COLUMN_UDF_20).replaceAll(Constants.SUBSTRINGREGEX,
                                    Constants.SPACE));
                    invoiceDto.setValid(true);

                    if (invoiceDto.getFillingPeriod().length() == 5) {
                        invoiceDto.setFillingPeriod(Constants.ZEROVALUE + invoiceDto.getFillingPeriod());
                    }
                    if (StringUtils.isNotBlank(invoiceDto.getGstinUinOfRecipient())
                                    && invoiceDto.getGstinUinOfRecipient().length() == 15) {
                        invoiceDto.setPanOfRecipient(invoiceDto.getGstinUinOfRecipient().substring(2, 12));
                    } else {
                        invoiceDto.setPanOfRecipient("");
                    }
                    if (StringUtils.isNotBlank(invoiceDto.getFillingPeriod())) {
                        fpSetSftp.add(invoiceDto.getFillingPeriod());
                    }
                    eInvoiceRawData.add(invoiceDto);
                }

            } catch (Exception ex) {
                log.error("Error generated while uploading invoice::", ex);
                markErrorNAddErrorCode(invoiceDto, ValidationConstants.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
            }
        }
        if ("ftps".equals(uploadDTO.getUplodSource()) || uploadDTO.getFp().isEmpty()) {
            uploadDTO.setFp(new ArrayList<>(fpSetSftp));
            uploadTransDao.updateFpLog(uploadDTO.getFp(), uploadDTO);
        }
        return eInvoiceRawData;
    }

    public void writeToAzureErrorDataInCSVFile(List<EInvoiceTemplateDTO> eInvoiceTemplateDTOs, UploadReqDTO uploadDTO)
                    throws IOException, CsvWriteException {

        try {
            String csvErrorFilePath = CommonUtils.getErrorFilePath(uploadDTO, tempFolder);
            InputStream nonValidStream = null;

            nonValidStream = azureUploadCsvFile(uploadDTO, eInvoiceTemplateDTOs);

            File errorFile = new File(csvErrorFilePath);
            if (errorFile.exists()) {
                FileUtils.deleteQuietly(errorFile);
            }
            Files.copy(nonValidStream, Paths.get(csvErrorFilePath));
        } catch (Exception e) {
            if (!e.getMessage().contains("CSV file")) {
                throw new CsvWriteException("Error while writing csv File ");
            }
            throw new CsvWriteException(e.getMessage());
        }

    }

    public ByteArrayInputStream azureUploadCsvFile(UploadReqDTO uploadDTO, List<EInvoiceTemplateDTO> excelData)
                    throws IOException, CsvWriteException {

        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        List<String> list = new ArrayList<>();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {

            list = Stream.of(Constants.ERROR_CODE_LIST, Constants.ERROR_DESCRIPTION,
                            Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT, Constants.COLUMN_DOC_TYPE,
                            Constants.COLUMN_INWARD_NO, Constants.COLUMN_INWARD_DATE,
                            Constants.COLUMN_GSTIN_OF_SUPPLIER, Constants.FILLING_PERIOD, Constants.COLUMN_HSN_CODE,
                            Constants.COLUMN_TOTAL_INVOICE_AMOUNT, Constants.COLUMN_PURCHASE_ORDER_NO,
                            Constants.COLUMN_PURCHASE_ORDER_DATE, Constants.COLUMN_IRN, Constants.COLUMN_IRN_DATE,
                            Constants.COLUMN_UDF_1, Constants.COLUMN_UDF_2, Constants.COLUMN_UDF_3,
                            Constants.COLUMN_UDF_4, Constants.COLUMN_UDF_5, Constants.COLUMN_UDF_6,
                            Constants.COLUMN_UDF_7, Constants.COLUMN_UDF_8, Constants.COLUMN_UDF_9,
                            Constants.COLUMN_UDF_10, Constants.COLUMN_UDF_11, Constants.COLUMN_UDF_12,
                            Constants.COLUMN_UDF_13, Constants.COLUMN_UDF_14, Constants.COLUMN_UDF_15,
                            Constants.COLUMN_UDF_16, Constants.COLUMN_UDF_17, Constants.COLUMN_UDF_18,
                            Constants.COLUMN_UDF_19, Constants.COLUMN_UDF_20).collect(Collectors.toList());

            csvPrinter.printRecord(list);

            if (!excelData.isEmpty()) {
                for (EInvoiceTemplateDTO eInvoiceTemplateDTO : excelData) {

                    List<Object> data = Arrays.asList(eInvoiceTemplateDTO.getErrorCodeList(),
                                    eInvoiceTemplateDTO.getErrorDiscriptionList(),
                                    eInvoiceTemplateDTO.getGstinUinOfRecipient(), eInvoiceTemplateDTO.getDocType(),
                                    eInvoiceTemplateDTO.getInwardNo(), eInvoiceTemplateDTO.getInwardDate(),
                                    eInvoiceTemplateDTO.getGstinOfSupplier(), eInvoiceTemplateDTO.getFillingPeriod(),
                                    eInvoiceTemplateDTO.getMainHSNCode(), eInvoiceTemplateDTO.getTotalInvoiceValue(),
                                    eInvoiceTemplateDTO.getPurchaseOrderNumber(),
                                    eInvoiceTemplateDTO.getPurchaseOrderDate(), eInvoiceTemplateDTO.getIrn(),
                                    eInvoiceTemplateDTO.getIrnDate(), eInvoiceTemplateDTO.getUdf1(),
                                    eInvoiceTemplateDTO.getUdf2(), eInvoiceTemplateDTO.getUdf3(),
                                    eInvoiceTemplateDTO.getUdf4(), eInvoiceTemplateDTO.getUdf5(),
                                    eInvoiceTemplateDTO.getUdf6(), eInvoiceTemplateDTO.getUdf7(),
                                    eInvoiceTemplateDTO.getUdf8(), eInvoiceTemplateDTO.getUdf9(),
                                    eInvoiceTemplateDTO.getUdf10(), eInvoiceTemplateDTO.getUdf11(),
                                    eInvoiceTemplateDTO.getUdf12(), eInvoiceTemplateDTO.getUdf13(),
                                    eInvoiceTemplateDTO.getUdf14(), eInvoiceTemplateDTO.getUdf15(),
                                    eInvoiceTemplateDTO.getUdf16(), eInvoiceTemplateDTO.getUdf17(),
                                    eInvoiceTemplateDTO.getUdf18(), eInvoiceTemplateDTO.getUdf19(),
                                    eInvoiceTemplateDTO.getUdf20()
                    // eInvoiceTemplateDTO.getErrorDiscriptionList()
                    // .append(daoCommon.getDescriptionFromDB(daoCommon.getErrorCodeMap(),
                    // eInvoiceTemplateDTO))

                    );
                    csvPrinter.printRecord(data);

                }
            }
            csvPrinter.flush();

            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            log.error(Constants.BLANK + e);
            throw new CsvWriteException("fail to import data to CSV file: " + e.getMessage());

        }

    }

    private void markErrorNAddErrorCode(EInvoiceTemplateDTO rowData, String errorCode, String errorMessage) {

        rowData.setValid(false);
        rowData.setErrorCodeList(rowData.getErrorCodeList().append(errorCode));
        rowData.setErrorDiscriptionList(rowData.getErrorDiscriptionList().append(errorMessage));
    }

    private void logIntoToExceptionTable(UploadReqDTO uploadDTO, Exception ex, String functionName) {
        ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
        exceptionLogDTO.setUserId(uploadDTO.getId());
        exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
        exceptionLogDTO.setFunctionName(functionName);
        exceptionLogDTO.setErrorMessage(ex.getMessage());
        exceptionLogDTO.setErrorCause(Constants.NOTCONTAINPROPERDATA);
        exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
        exceptionLogDTO.setCreatedAt(LocalDateTime.now());

        commonDao.updateExceptionLogTable(exceptionLogDTO);
    }

    private void markDocNoLevelError(EInvoiceTemplateDTO rowData) {
        // Checking item level Error start
        String lineItemLevelErrorkey = new StringBuilder().append(rowData.getGstinUinOfRecipient())
                        .append(rowData.getGstinOfSupplier()).append(rowData.getInwardNo()).append(rowData.getDocType())
                        .toString();

        if (duplicateRowMap.get(lineItemLevelErrorkey) == null) {
            duplicateRowMap.put(lineItemLevelErrorkey, 1);
        } else {
            duplicateRowMap.put(lineItemLevelErrorkey, duplicateRowMap.get(lineItemLevelErrorkey) + 1);
        }
        if (duplicateRowMap.get(lineItemLevelErrorkey) > 1) {
            markErrorNAddErrorCode(rowData, ValidationConstants.ERROR_CODE_E00511, "");
        }
    }

}