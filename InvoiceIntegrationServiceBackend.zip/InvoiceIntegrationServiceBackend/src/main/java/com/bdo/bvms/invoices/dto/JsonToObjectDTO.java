package com.bdo.bvms.invoices.dto;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class JsonToObjectDTO {

    private List<String> gstinOrPanList;
    private String fileType;
    private String po;
    private String poDate;
    private String templateType;
    private String panOrGstn;
    private List<String> fp;

}
