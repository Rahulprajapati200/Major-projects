package com.bdo.bvms.erp.integration.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class DocDtls {
	 private String typ;
	 private String no;
	 private String dt;
}
