package com.bdo.bvms.invoices.ocr.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.azure.storage.blob.BlobClient;
import com.bdo.bvms.common.service.IAzureBlobService;
import com.bdo.bvms.common.service.IFileService;
import com.bdo.bvms.common.service.IPickupMasterService;
import com.bdo.bvms.common.service.ISystemParameterService;
import com.bdo.bvms.exception.apierror.CustomValidationError;
import com.bdo.bvms.invoices.constant.InvoiceOcrReviewConstant;
import com.bdo.bvms.invoices.constant.VendorInvoiceConstants;
import com.bdo.bvms.invoices.custom.exception.CustomValidationViolationException;
import com.bdo.bvms.invoices.custom.exception.ResourceNotFoundException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.ocr.dao.OcrInvoiceReviewRequestDTO;
import com.bdo.bvms.invoices.ocr.dao.OcrInvoiceReviewResponseDTO;
import com.bdo.bvms.invoices.ocr.dao.OcrStatusUpdateRequestDto;
import com.bdo.bvms.invoices.ocr.dao.SearchSystemParameterResDTO;
import com.bdo.bvms.invoices.ocr.dao.UpdateOCRInvoiceDetailsReqDTO;
import com.bdo.bvms.invoices.ocr.model.EntityCloudCredentials;
import com.bdo.bvms.invoices.ocr.model.OcrInvoiceHeader;
import com.bdo.bvms.invoices.ocr.model.OcrVerticalMap;
import com.bdo.bvms.invoices.ocr.repository.IInvoiceReviewRepository;
import com.bdo.bvms.invoices.ocr.service.IInvoiceReviewService;
import com.bdo.bvms.ocr.dto.OcrComplianceErrorDto;
import com.bdo.bvms.ocr.dto.OcrVerticalDataObj;
import com.bdo.bvms.ocr.dto.VendorCodeAutoTagReqDto;
import com.bdo.bvms.ocr.repository.FileOcrProcessAndSaveRepository;
import com.bdo.bvms.ocr.validations.OcrValidationCheck;
import com.bdo.bvms.taxpayer.request.dto.SearchSystemParameterReqDTO;
import com.bdo.bvms.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j

public class InvoiceReviewServiceImpl implements IInvoiceReviewService {

    @Autowired
    private IInvoiceReviewRepository invoiceReviewRepositoryImpl;

    @Autowired
    private ISystemParameterService systemParameterServiceImpl;

    @Autowired
    private IAzureBlobService azureBlobServiceImpl;

    @Autowired
    private IFileService fileServiceImpl;

    @Autowired
    private IPickupMasterService pickupMasterServiceImpl;

    @Autowired
    private FileOcrProcessAndSaveRepository fileOcrProcessAndSaveRepository;

    @Autowired
    private MessageSource messageSource;

    @Override
    public LinkedHashMap<String, List<OcrInvoiceReviewResponseDTO>> ocrInvoiceReview(
                    OcrInvoiceReviewRequestDTO ocrInvoiceReviewRequestDTO) {

        LinkedHashMap<String, List<OcrInvoiceReviewResponseDTO>> ocrInvoiceReviewResponse = new LinkedHashMap<>();
        VendorCodeAutoTagReqDto vendorCodeAutoTagReqDto = new VendorCodeAutoTagReqDto();

        LinkedHashMap<String, Integer> ocrTabNameMap = pickupMasterServiceImpl
                        .getPickupListDetailsMapSortOrder(InvoiceOcrReviewConstant.OCR_TAB_NAME);

        // check is ocr done or not
        int countCheck = invoiceReviewRepositoryImpl.countCheckForNewFileOcr(ocrInvoiceReviewRequestDTO.getFileId());

        for (Map.Entry<String, Integer> entryMap : ocrTabNameMap.entrySet()) {
            String tabname = entryMap.getKey();
            Integer value = entryMap.getValue() == null ? null : entryMap.getValue();

            List<OcrVerticalMap> ocrInvoiceReviewListTab = invoiceReviewRepositoryImpl.getOcrInvoiceReviewData(
                            ocrInvoiceReviewRequestDTO.getFileId(), value,
                            ocrInvoiceReviewRequestDTO.getTaxpayerGstin(), countCheck);

            if (ocrInvoiceReviewListTab.isEmpty() && value == InvoiceOcrReviewConstant.PLD_OCR_TAB_CODE_GENERAL) {
                throw new ResourceNotFoundException(messageSource.getMessage("ocr.template.configuration.error",
                                new Object[] { ocrInvoiceReviewRequestDTO.getTaxpayerGstin() },
                                LocaleContextHolder.getLocale()));
            }
            
            //add line item reference
            if (value == InvoiceOcrReviewConstant.PLD_OCR_TAB_CODE_LINE_ITEM) {
                List<OcrVerticalMap> lineItemRefObj = invoiceReviewRepositoryImpl
                                .getLineItemRefernceObject(ocrInvoiceReviewRequestDTO.getTaxpayerGstin());
                List<OcrVerticalMap> lineItemRefSortedDTOList = lineItemRefObj.stream()
                                .sorted(Comparator.comparingInt(OcrVerticalMap::getOrder)).collect(Collectors.toList());
                ocrInvoiceReviewListTab.addAll(lineItemRefSortedDTOList);
                
            }
            // set request param for vendor code tagging
            if(value == InvoiceOcrReviewConstant.PLD_OCR_TAB_CODE_GENERAL) {
            	Optional<String> poNo = ocrInvoiceReviewListTab.stream()
                        .filter(data -> data.getOcrFieldMstId() != null && data.getOcrFieldMstId() == InvoiceOcrReviewConstant.OCR_FIELD_MST_ID_PONO)
                        .map(OcrVerticalMap::getOcrExtractedValue)
                        .findFirst();
            	if (poNo.isPresent()) {
            		vendorCodeAutoTagReqDto.setPoNo(poNo.get());
            	}
            	Optional<String> vendorPan = ocrInvoiceReviewListTab.stream()
                        .filter(data -> data.getOcrFieldMstId() != null && data.getOcrFieldMstId() == InvoiceOcrReviewConstant.OCR_FIELD_MST_ID_VENDOR_PAN)
                        .map(OcrVerticalMap::getOcrExtractedValue)
                        .findFirst();
            	if (vendorPan.isPresent()) {
            		vendorCodeAutoTagReqDto.setVendorPan(vendorPan.get());
            	}
            }
            
            if(value == InvoiceOcrReviewConstant.PLD_OCR_TAB_CODE_SUPPLIER_DETAIL) {
            	Optional<String> vendorGstin = ocrInvoiceReviewListTab.stream()
                        .filter(data -> data.getOcrFieldMstId() != null && data.getOcrFieldMstId() == InvoiceOcrReviewConstant.OCR_FIELD_MST_ID_VENDOR_GSTIN)
                        .map(OcrVerticalMap::getOcrExtractedValue)
                        .findFirst();
            	if (vendorGstin.isPresent()) {
            		vendorCodeAutoTagReqDto.setVendorGstin(vendorGstin.get());
            	}
            }
            
            if(value == InvoiceOcrReviewConstant.PLD_OCR_TAB_CODE_COMPANY_DETAIL) {
            	Optional<String> taxpayerGstin = ocrInvoiceReviewListTab.stream()
                        .filter(data -> data.getOcrFieldMstId() != null && data.getOcrFieldMstId() == InvoiceOcrReviewConstant.OCR_FIELD_MST_ID_TAXPAYER_GSTIN)
                        .map(OcrVerticalMap::getOcrExtractedValue)
                        .findFirst();
            	if (taxpayerGstin.isPresent()) {
            		vendorCodeAutoTagReqDto.setTaxpayerGstin(taxpayerGstin.get());
            	}
            }


            List<OcrInvoiceReviewResponseDTO> searchVendorResDTOList = ocrInvoiceReviewListTab.stream()
                            .map(ocrVerticalMap -> OcrInvoiceReviewResponseDTO.builder()
                                            .verticalMapId(ocrVerticalMap.getId()).fileId(ocrVerticalMap.getFileId())
                                            .ocrVendorTemplateMstId(ocrVerticalMap.getOcrVendorTemplateMstId())
                                            .ocrFieldMstId(ocrVerticalMap.getOcrFieldMstId())
                                            .ocrExtractedValue(ocrVerticalMap.getOcrExtractedValue())
                                            .ocrAccuracyLvl(ocrVerticalMap.getOcrAccuracyLvl())
                                            .ocrAccuracyLvlValue(ocrVerticalMap.getOcrAccuracyLvlValue())
                                            .lineNo(ocrVerticalMap.getLineNo()).isHeader(ocrVerticalMap.getIsHeader())
                                            .labelName(ocrVerticalMap.getName())
                                            .maxLength(ocrVerticalMap.getMaxLength())
                                            .minLength(ocrVerticalMap.getMinLength())
                                            .regexStr(ocrVerticalMap.getRegex()).type(ocrVerticalMap.getType())
                                            .order(ocrVerticalMap.getOrder())
                                            .isMandatory(ocrVerticalMap.getIsMandatory())
                                            .riskCategory(ocrVerticalMap.getRiskCategory())
                                            .dataTypeId(ocrVerticalMap.getPldType())
                                            .isAmountField(ocrVerticalMap.getIsAmountField()).build())
                            .collect(Collectors.toList());

            List<OcrInvoiceReviewResponseDTO> searchVendorResSortedDTOList = searchVendorResDTOList.stream()
                            .sorted(Comparator.comparingInt(OcrInvoiceReviewResponseDTO::getOrder))
                            .collect(Collectors.toList());

            ocrInvoiceReviewResponse.put(tabname, searchVendorResSortedDTOList);
        }

        List<OcrInvoiceReviewResponseDTO> updatedList =  ocrInvoiceReviewResponse.get(InvoiceOcrReviewConstant.PLD_OCR_TAB_NAME_GENERAL).stream()
                .map(data -> {
                    if (data.getOcrFieldMstId() != null && data.getOcrFieldMstId() == InvoiceOcrReviewConstant.OCR_FIELD_MST_ID_VENDOR_CODE
                    		&& StringUtils.isBlank(data.getOcrExtractedValue())) {
                    	data.setOcrExtractedValue(fetchVendorCode(vendorCodeAutoTagReqDto));
                    }
                    return data;
                })
                .collect(Collectors.toList());
        return ocrInvoiceReviewResponse;
    }

    @Override
    public File reviewInvoiceFile(OcrInvoiceReviewRequestDTO ocrInvoiceReviewRequestDTO) {
        SearchSystemParameterResDTO searchSystemParameterResDTOAzureUrl = systemParameterServiceImpl
                        .searchSystemParameter(SearchSystemParameterReqDTO.builder()
                                        .keyName(InvoiceOcrReviewConstant.SYSTEM_PARAMETER_AZURE_BASE_URL).build());
        SearchSystemParameterResDTO searchSystemParameterResDTOContainer = systemParameterServiceImpl
                        .searchSystemParameter(SearchSystemParameterReqDTO.builder()
                                        .keyName(InvoiceOcrReviewConstant.SYSTEM_PARAMETER_CONTAINER_NAME).build());

        OcrVerticalMap ocrVerticalMap = OcrVerticalMap.builder().fileId(ocrInvoiceReviewRequestDTO.getFileId()).build();
        ocrVerticalMap = invoiceReviewRepositoryImpl.getOcrVerticalMap(ocrVerticalMap);

        BlobClient blobClient = azureBlobServiceImpl
                        .getBlobClientWithEndPoint(
                                        EntityCloudCredentials.builder()
                                                        .containerName(searchSystemParameterResDTOContainer
                                                                        .getKeyValue())
                                                        .url(searchSystemParameterResDTOAzureUrl.getKeyValue()).build(),
                                        ocrVerticalMap.getFilePath());
        String downloadFileUrl = blobClient.getBlobUrl();
        return fileServiceImpl.createFileWithURL(downloadFileUrl, ocrVerticalMap.getFilePath());
    }

    @Override
    @Transactional
    public String updateOCRInvoiceDetails(OcrInvoiceReviewRequestDTO ocrInvoiceReviewRequestDTO)
                    throws VendorInvoiceServerException {

        List<CustomValidationError> customValidationErrorList = new ArrayList<>();
        Map<Integer, String> ocrVerticalFieldColumnMapping = null;
        OcrValidationCheck ocrValidationCheck = new OcrValidationCheck();

        try {

            List<OcrVerticalDataObj> ocrVerticalDataObjList = new ArrayList<>();
            try {
                ocrVerticalFieldColumnMapping = invoiceReviewRepositoryImpl
                                .getOcrInvoiceReviewVerticalFieldColumnMapping(OcrVerticalMap.builder()
                                                .fileId(ocrInvoiceReviewRequestDTO.getFileId()).build());
            } catch (EmptyResultDataAccessException e) {
                ocrVerticalFieldColumnMapping = null;
            }
            Map<Integer, String> ocrMasterFieldColumnMapping = null;
            try {
                ocrMasterFieldColumnMapping = invoiceReviewRepositoryImpl.getOcrInvoiceReviewMasterFieldColumnMapping();
            } catch (Exception e) {
                log.error("In " + this.getClass().getName() + " No invoice review data found for fileid "
                                + ocrInvoiceReviewRequestDTO.getFileId(), e);
                throw new VendorInvoiceServerException(
                                "No invoice review data found for fileid " + ocrInvoiceReviewRequestDTO.getFileId());
            }
            List<UpdateOCRInvoiceDetailsReqDTO> headerOCRInvoiceDetailsReqDTOList = ocrInvoiceReviewRequestDTO
                            .getHeaderOCRInvoiceDetailsReqDTOList();

            OcrVerticalMap ocrVerticalMap = OcrVerticalMap.builder().fileId(ocrInvoiceReviewRequestDTO.getFileId())
                            .build();

            List<Map<String, Object>> updatedVerticalMapList = new ArrayList<>();

            Map<String, Object> headerMap = new HashMap<>();

            List<String> headerColumnList = new ArrayList<>();
            List<String> headerValueList = new ArrayList<>();

            List<String> lineColumnList = new ArrayList<>();
            List<String> lineValueList = new ArrayList<>();

            for (UpdateOCRInvoiceDetailsReqDTO headerOCRInvoiceDetailsReqDTO : headerOCRInvoiceDetailsReqDTOList) {

                if (headerOCRInvoiceDetailsReqDTO.getVerticalMapId() != null
                                && headerOCRInvoiceDetailsReqDTO.getVerticalMapId() != 0) {
                    // means review/update ocr data stage
                    String columnDescription = ocrVerticalFieldColumnMapping
                                    .get(headerOCRInvoiceDetailsReqDTO.getVerticalMapId());
                    if (columnDescription != null) {
                        if ("1".equals(columnDescription.split("~")[1])) {
                            // header case
                            headerColumnList.add(columnDescription.split("~")[0]);
                            headerMap.put(columnDescription.split("~")[0],
                                            headerOCRInvoiceDetailsReqDTO.getUpdatedValue());
                            headerValueList.add(headerOCRInvoiceDetailsReqDTO.getUpdatedValue() != null
                                            ? "'" + headerOCRInvoiceDetailsReqDTO.getUpdatedValue() + "'"
                                            : null);

                        } else {
                            CustomValidationError customValidationError = new CustomValidationError(
                                            UpdateOCRInvoiceDetailsReqDTO.class.getName(), "ocrFieldMstId",
                                            headerOCRInvoiceDetailsReqDTO.getOcrFieldMstId(),
                                            "Column is not header  " + columnDescription.split("~")[0]);
                            customValidationErrorList.add(customValidationError);
                        }
                    } else {
                        CustomValidationError customValidationError = new CustomValidationError(
                                        UpdateOCRInvoiceDetailsReqDTO.class.getName(), "ocrFieldMstId",
                                        headerOCRInvoiceDetailsReqDTO.getOcrFieldMstId(),
                                        "Column mapping not found for ocrFieldMstId "
                                                        + headerOCRInvoiceDetailsReqDTO.getOcrFieldMstId());
                        customValidationErrorList.add(customValidationError);
                    }
                } else {
                    // means line item data inserted stage
                    String columnName = ocrMasterFieldColumnMapping
                                    .get(headerOCRInvoiceDetailsReqDTO.getOcrFieldMstId());

                    // header case
                    if (StringUtils.isNotBlank(columnName)) {
                        headerColumnList.add(columnName);
                        headerValueList.add(headerOCRInvoiceDetailsReqDTO.getUpdatedValue() != null
                                        ? "'" + headerOCRInvoiceDetailsReqDTO.getUpdatedValue() + "'"
                                        : null);
                    }
                }
            }

            if (!customValidationErrorList.isEmpty())
                throw new CustomValidationViolationException(customValidationErrorList);

            OcrInvoiceHeader headerDetail = invoiceReviewRepositoryImpl.getInvoiceHeaderByFileId(ocrVerticalMap);
            headerColumnList.add("file_id");
            headerValueList.add(String.valueOf(ocrInvoiceReviewRequestDTO.getFileId()));
            headerColumnList.add("pld_ocr_status");
            headerValueList.add(ocrInvoiceReviewRequestDTO.getAction() == 0
                            ? InvoiceOcrReviewConstant.PLD_OCR_STATUS_COMPLETED
                            : InvoiceOcrReviewConstant.PLD_OCR_STATUS_VERIFIED);
            headerColumnList.add("is_taxpayer_uploaded");
            headerValueList.add("'" + headerDetail.getIsTaxpayer() + "'");
            headerColumnList.add("file_name");
            headerValueList.add("'" + headerDetail.getFileName() + "'");
            headerColumnList.add("batch_no");
            headerValueList.add("'" + headerDetail.getBatchNo() + "'");
            headerColumnList.add("ul_file_type");
            headerValueList.add("'"+ headerDetail.getFileType() +"'");
            headerColumnList.add("ul_filing_period");
            headerValueList.add("'"+ headerDetail.getFp()+ "'");
            headerColumnList.add("taxpayer_gstin");
    	    headerValueList.add("'"+ headerDetail.getCustomerGstin()+ "'");
            String headerColumnName = StringUtil.join(headerColumnList);
            String headerValues = StringUtil.join(headerValueList);

            // Archive and delete
            invoiceReviewRepositoryImpl.insertOcrInvoiceDetailsArchive(ocrVerticalMap);
            invoiceReviewRepositoryImpl.deleteOcrInvoiceDetails(ocrVerticalMap);
            invoiceReviewRepositoryImpl.insertOcrInvoiceHeaderArchive(ocrVerticalMap);
            invoiceReviewRepositoryImpl.deleteOcrInvoiceHeader(ocrVerticalMap);

            invoiceReviewRepositoryImpl.updateOcrInvoiceDetails(headerColumnName, headerValues,
                            InvoiceOcrReviewConstant.OCR_INV_HEADER_TABLE_NAME);
            OcrInvoiceHeader ocrInvoiceHeader = invoiceReviewRepositoryImpl.getInvoiceHeaderByFileId(ocrVerticalMap);

            List<UpdateOCRInvoiceDetailsReqDTO> lineItemsOCRInvoiceDetailsReqDTOList = ocrInvoiceReviewRequestDTO
                            .getLineItemsOCRInvoiceDetailsReqDTOList();

            Map<Integer, List<UpdateOCRInvoiceDetailsReqDTO>> groupedUpdateOCRInvoiceDetailsReqDTO = lineItemsOCRInvoiceDetailsReqDTOList
                            .stream().collect(Collectors.groupingBy(UpdateOCRInvoiceDetailsReqDTO::getLineNo));

            // Displaying the grouped UpdateOCRInvoiceDetailsReqDTO based on
            // line number
            for (Map.Entry<Integer, List<UpdateOCRInvoiceDetailsReqDTO>> entry : groupedUpdateOCRInvoiceDetailsReqDTO
                            .entrySet()) {
                List<UpdateOCRInvoiceDetailsReqDTO> lineItemsWithSameLineNo = entry.getValue();
                for (UpdateOCRInvoiceDetailsReqDTO updateOCRInvoiceDetailsReqDTO : lineItemsWithSameLineNo) {
                    if (updateOCRInvoiceDetailsReqDTO.getVerticalMapId() != null
                                    && updateOCRInvoiceDetailsReqDTO.getVerticalMapId() != 0) {
                        // means review/update ocr data stage
                        String columnDescription = ocrVerticalFieldColumnMapping
                                        .get(updateOCRInvoiceDetailsReqDTO.getVerticalMapId());
                        if (columnDescription != null) {
                            if ("0".equals(columnDescription.split("~")[1])) {
                                // header case
                                lineColumnList.add(columnDescription.split("~")[0]);
                                lineValueList.add(updateOCRInvoiceDetailsReqDTO.getUpdatedValue() != null
                                                ? "'" + updateOCRInvoiceDetailsReqDTO.getUpdatedValue() + "'"
                                                : null);
                            } else {
                                CustomValidationError customValidationError = new CustomValidationError(
                                                UpdateOCRInvoiceDetailsReqDTO.class.getName(), "ocrFieldMstId",
                                                updateOCRInvoiceDetailsReqDTO.getOcrFieldMstId(),
                                                "Column is not for line items " + columnDescription.split("~")[0]);
                                customValidationErrorList.add(customValidationError);
                            }
                        } else {
                            CustomValidationError customValidationError = new CustomValidationError(
                                            UpdateOCRInvoiceDetailsReqDTO.class.getName(), "ocrFieldMstId",
                                            updateOCRInvoiceDetailsReqDTO.getOcrFieldMstId(),
                                            "Column mapping not found for ocrFieldMstId "
                                                            + updateOCRInvoiceDetailsReqDTO.getOcrFieldMstId());
                            customValidationErrorList.add(customValidationError);
                        }
                    } else {
                        // means line item data inserted stage
                        String columnName = ocrMasterFieldColumnMapping
                                        .get(updateOCRInvoiceDetailsReqDTO.getOcrFieldMstId());

                        // header case
                        if (StringUtils.isNotBlank(columnName)) {
                            lineColumnList.add(columnName);
                            lineValueList.add(updateOCRInvoiceDetailsReqDTO.getUpdatedValue() != null
                                            ? "'" + updateOCRInvoiceDetailsReqDTO.getUpdatedValue() + "'"
                                            : null);
                        }
                    }

                }
                lineColumnList.add("ocr_inv_id");
                lineValueList.add(String.valueOf(ocrInvoiceHeader.getId()));
                String lineColumnName = StringUtil.join(lineColumnList);
                String lineValues = StringUtil.join(lineValueList);

                lineColumnList.clear();
                lineValueList.clear();
                invoiceReviewRepositoryImpl.updateOcrInvoiceDetails(lineColumnName, lineValues,
                                InvoiceOcrReviewConstant.OCR_INV_DETAILS_TABLE_NAME);

            }

            // update extraction and compliance issues and validations
            setOcrComplianceErrorDto(ocrVerticalDataObjList, ocrInvoiceReviewRequestDTO, ocrMasterFieldColumnMapping);
            List<OcrComplianceErrorDto> ocrComplianceErrorList;
            try {
                ocrComplianceErrorList = ocrValidationCheck.validateRules(ocrVerticalDataObjList);
                // delete previous compliance issues
                invoiceReviewRepositoryImpl.deleteComplianceValidations(ocrVerticalMap);
                // insert updated compliance issues
                fileOcrProcessAndSaveRepository.insertIntoComplianceErrorTable(ocrComplianceErrorList);

            } catch (Exception e) {
                throw new VendorInvoiceServerException(
                                "No invoice review data found for fileid " + ocrInvoiceReviewRequestDTO.getFileId());
            }

            // check is ocr done or not
            int countCheck = invoiceReviewRepositoryImpl
                            .countCheckForNewFileOcr(ocrInvoiceReviewRequestDTO.getFileId());
            if (countCheck > 0) {
                // get header values in vertical map
                for (UpdateOCRInvoiceDetailsReqDTO header : headerOCRInvoiceDetailsReqDTOList) {
                    if (header.getVerticalMapId() != null && header.getVerticalMapId() != 0) {
                        Map<String, Object> updatedValueMap = new HashMap<>();
                        updatedValueMap.put(InvoiceOcrReviewConstant.VERTICAL_MAP_ID, header.getVerticalMapId());
                        updatedValueMap.put(InvoiceOcrReviewConstant.UPDATED_VALUE, header.getUpdatedValue());
                        updatedVerticalMapList.add(updatedValueMap);
                    }
                }
                // update header values in vertical map table
                invoiceReviewRepositoryImpl.updateOcrVerticalMap(updatedVerticalMapList);

                // Archive and delete line item from vertical map
                invoiceReviewRepositoryImpl.insertVerticalMapLineItemArchive(ocrVerticalMap);
                invoiceReviewRepositoryImpl.deleteVerticalMapLineItemDetails(ocrVerticalMap);

                // insert updated line item into vertical map
                ocrVerticalMap = invoiceReviewRepositoryImpl.getCommonDetailsVerticalMap(ocrVerticalMap);
                invoiceReviewRepositoryImpl.insertUpdatedLineItemDetailsOcrVerticalMap(
                                lineItemsOCRInvoiceDetailsReqDTOList, ocrVerticalMap);

            } else {

                ocrVerticalMap.setIsTaxpayer(ocrInvoiceReviewRequestDTO.getIsTaxpayer());
                // insert new ocr header details to vertical map
                invoiceReviewRepositoryImpl.insertOcrHeaderDetailsVerticalMap(headerOCRInvoiceDetailsReqDTOList,
                                ocrVerticalMap, 1);
                // insert new ocr line item details to vertical map
                invoiceReviewRepositoryImpl.insertOcrHeaderDetailsVerticalMap(lineItemsOCRInvoiceDetailsReqDTOList,
                                ocrVerticalMap, 0);
            }
            updatedVerticalMapList.clear();

            // if action not equals to 0
            if (ocrInvoiceReviewRequestDTO.getAction() != 0) {
                OcrStatusUpdateRequestDto reqdto = OcrStatusUpdateRequestDto.builder()
                                .idList(new ArrayList<>(Arrays.asList(ocrInvoiceHeader.getId())))
                                .action(ocrInvoiceReviewRequestDTO.getAction())
                                .isTaxpayer(ocrInvoiceReviewRequestDTO.getIsTaxpayer()).build();
                return ocrStatusSubmission(reqdto);
            } else {
                return "Reviewed invoice details updated successfully";
            }

        } catch (Exception e) {

            log.error("Exception generated ::", e);

            throw new VendorInvoiceServerException("Exception generated in the OCR update operation for file id:: "
                            + ocrInvoiceReviewRequestDTO.getFileId());
        }

    }

    @Override
    public String ocrStatusSubmission(OcrStatusUpdateRequestDto ocrStatusUpdateRequestDto)
                    throws VendorInvoiceServerException {
        Map<Integer, String> ocrPldStatusMap = new HashMap<>();
        String ids = listToString(ocrStatusUpdateRequestDto.getIdList());
        ocrPldStatusMap.put(1, InvoiceOcrReviewConstant.PLD_OCR_STATUS_ACCEPT);
        ocrPldStatusMap.put(2, InvoiceOcrReviewConstant.PLD_OCR_STATUS_ACCEPT_AND_MOVE_PROCESSED_INVOICE);
        ocrPldStatusMap.put(3, InvoiceOcrReviewConstant.PLD_OCR_STATUS_ACCEPT_AND_MOVE_SYNC_PENDING);
        ocrPldStatusMap.put(4, InvoiceOcrReviewConstant.PLD_OCR_STATUS_ON_HOLD);
        ocrPldStatusMap.put(5, InvoiceOcrReviewConstant.PLD_OCR_STATUS_REJECTED);
        ocrPldStatusMap.put(6, InvoiceOcrReviewConstant.PLD_OCR_STATUS_ACCEPT_AND_MOVE_URP);
        String pldInvoiceStatus = ocrPldStatusMap.get(ocrStatusUpdateRequestDto.getAction());
        try {

            Map<String, Object> resultset = invoiceReviewRepositoryImpl
                            .ocrInvoiceStatusSubmission(ocrStatusUpdateRequestDto, pldInvoiceStatus);

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> dataList = (List<Map<String, Object>>) resultset.get("#result-set-1");
            Map<String, Object> count11 = dataList.get(0);
            int output = Integer.parseInt((String) count11.get("OUTPUT"));

            if (output < 0) {
            	invoiceReviewRepositoryImpl.updateOcrStatus(InvoiceOcrReviewConstant.PLD_OCR_STATUS_COMPLETED, ids, ocrStatusUpdateRequestDto.getUserId(),
                        ocrStatusUpdateRequestDto.getAction());
                return (String) count11.get("ErrorDescription");
            } else {

                if (InvoiceOcrReviewConstant.PLD_OCR_STATUS_REJECTED.equals(pldInvoiceStatus)) {
                    invoiceReviewRepositoryImpl.markOcrAsRejected(ids);
                    return "Records Rejected Successfully";
                } else {
                    return "Records Accepted Successfully";
                }
            }
        } catch (VendorInvoiceServerException e) {
            String pldOcrStatus = InvoiceOcrReviewConstant.PLD_OCR_STATUS_COMPLETED;
            invoiceReviewRepositoryImpl.updateOcrStatus(pldOcrStatus, ids, ocrStatusUpdateRequestDto.getUserId(),
                            ocrStatusUpdateRequestDto.getAction());
            throw new VendorInvoiceServerException("Somethong went wrong , please contact to support team");
        }
    }

    @Override
    public String updateOcrStatus(OcrStatusUpdateRequestDto ocrStatusUpdateRequestDto)
                    throws VendorInvoiceServerException {
        try {
            Map<Integer, String> ocrPldStatusMap = new HashMap<>();
            String ids = listToString(ocrStatusUpdateRequestDto.getIdList());
            ocrPldStatusMap.put(1, VendorInvoiceConstants.OCR_NOT_STARTED_PLD);
            ocrPldStatusMap.put(2, VendorInvoiceConstants.OCR_STOPPED_PLD);
            ocrPldStatusMap.put(3, VendorInvoiceConstants.PLD_OCR_STATUS_IN_REVIEW);

            String ocrStatus = ocrPldStatusMap.get(ocrStatusUpdateRequestDto.getAction());
            invoiceReviewRepositoryImpl.updateOcrStatus(ocrStatus, ids, ocrStatusUpdateRequestDto.getUserId(),
                            ocrStatusUpdateRequestDto.getAction());

            if (VendorInvoiceConstants.OCR_NOT_STARTED_PLD.equals(ocrStatus)) {
                return "Records Re-Triggred Successfully.";
            } else if (VendorInvoiceConstants.OCR_STOPPED_PLD.equals(ocrStatus)) {
                return "OCR process stopped forcefully.";
            } else if (VendorInvoiceConstants.PLD_OCR_STATUS_IN_REVIEW.equals(ocrStatus)) {
                return "Document moved to Review Tab.";
            } else {

                return "Records Stop Successfully";
            }
        } catch (VendorInvoiceServerException e) {
            throw new VendorInvoiceServerException("Somethong went wrong , please contact to support team");
        }
    }

    private void setOcrComplianceErrorDto(List<OcrVerticalDataObj> ocrVerticalDataObjList,
                    OcrInvoiceReviewRequestDTO ocrInvoiceReviewRequestDTO,
                    Map<Integer, String> ocrMasterFieldColumnMapping) {
        Integer fileId = ocrInvoiceReviewRequestDTO.getFileId();
        List<UpdateOCRInvoiceDetailsReqDTO> lineItemsOCRInvoiceDetailsReqDTOList = ocrInvoiceReviewRequestDTO
                        .getLineItemsOCRInvoiceDetailsReqDTOList();
        List<UpdateOCRInvoiceDetailsReqDTO> headerOCRInvoiceDetailsReqDTOList = ocrInvoiceReviewRequestDTO
                        .getHeaderOCRInvoiceDetailsReqDTOList();

        List<OcrVerticalDataObj> headerObjectList = headerOCRInvoiceDetailsReqDTOList.stream().map(obj -> {
            OcrVerticalDataObj ocrVerticalDataObj = new OcrVerticalDataObj();
            ocrVerticalDataObj.setFileId(fileId);
            ocrVerticalDataObj.setOcrFieldMstId(obj.getOcrFieldMstId());
            ocrVerticalDataObj.setOcrExtractedValue(obj.getUpdatedValue());
            ocrVerticalDataObj.setColumnName(ocrMasterFieldColumnMapping.get(obj.getOcrFieldMstId()));
            ocrVerticalDataObj.setLineNo(0);
            return ocrVerticalDataObj;
        }).collect(Collectors.toList());

        ocrVerticalDataObjList.addAll(headerObjectList);

        List<OcrVerticalDataObj> lineItemObjectList = lineItemsOCRInvoiceDetailsReqDTOList.stream().map(obj -> {
            OcrVerticalDataObj ocrVerticalDataObj = new OcrVerticalDataObj();
            ocrVerticalDataObj.setFileId(fileId);
            ocrVerticalDataObj.setOcrFieldMstId(obj.getOcrFieldMstId());
            ocrVerticalDataObj.setOcrExtractedValue(obj.getUpdatedValue());
            ocrVerticalDataObj.setLineNo(obj.getLineNo());
            ocrVerticalDataObj.setColumnName(ocrMasterFieldColumnMapping.get(obj.getOcrFieldMstId()));
            return ocrVerticalDataObj;
        }).collect(Collectors.toList());
        ocrVerticalDataObjList.addAll(lineItemObjectList);

    }

    private String listToString(List<Integer> list) {
        if (list.isEmpty()) {
            return "";
        }
        StringBuilder str = new StringBuilder();
        str.append("(");
        for (Integer i : list) {
            str.append("'").append(i).append("',");
        }
        str.deleteCharAt(str.length() - 1);
        str.append(")");
        return str.toString();

    }
    
    @Override
    public String fetchVendorCode(VendorCodeAutoTagReqDto reqDto) {
    	String vendorCode = "";
    	 try {
			Map<String, Object> resultset = invoiceReviewRepositoryImpl.fetchVendorCodeForAutoTagging(reqDto);
			List<Map<String, Object>> dataList = (List<Map<String, Object>>) resultset.get("#result-set-1");
            Map<String, Object> output = dataList.get(0);
            vendorCode = String.valueOf(output.get("vendor_code_erp"));
		} catch (Exception e) {
			log.error(e.getMessage());
		}

        return vendorCode;

    }

}
