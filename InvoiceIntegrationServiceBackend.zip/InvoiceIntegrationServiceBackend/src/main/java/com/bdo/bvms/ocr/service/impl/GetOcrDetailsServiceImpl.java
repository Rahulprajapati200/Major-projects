package com.bdo.bvms.ocr.service.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdo.bvms.einvoice.service.CustomColumnService;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.VendorInvoiceApprovalPendingDataListDao;
import com.bdo.bvms.invoices.dto.ApprovalPendingResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.ocr.dto.OcrResponseDto;
import com.bdo.bvms.ocr.repository.GetOcrDetailsRepository;
import com.bdo.bvms.ocr.service.GetOcrDetailsService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GetOcrDetailsServiceImpl implements GetOcrDetailsService {
	
	@Autowired
	GetOcrDetailsRepository getOcrDetailsRepository;
	
	@Autowired
    VendorInvoiceApprovalPendingDataListDao vendorInvoiceApprovalPendingDataListDao;
	
	@Autowired
    CustomColumnService customColumnService;
	
	@Override
	public Map<String, Object> getOcrDetailsDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
	           String gstinNewList, String monthList) throws VendorInvoiceServerException {
		 Map<String, Object> data;
	        try {

	            data = new LinkedHashMap<>();

	            int totalCount = 0;
	            
	            data.put("ColumnData", customColumnService.getCustomGridColumns(vendorInvoiceRequestDTO));
	            List<OcrResponseDto> dataResList = getOcrDetailsRepository.getOcrDetails(vendorInvoiceRequestDTO,gstinNewList,monthList);

	            data.put("Data", dataResList);

	            if (!dataResList.isEmpty()) {
	                totalCount = dataResList.get(0).getTotalCount();
	            }

	            data.put("totalPageElements", totalCount);

	        } catch (Exception e) {
	            log.error("error coming at the time of getting data of 'columnData' and 'Data' from ocr tab",
	                            e.getCause());
	            throw new VendorInvoiceServerException(e.getMessage());
	        }

	        return data;
		
	}
	

}
