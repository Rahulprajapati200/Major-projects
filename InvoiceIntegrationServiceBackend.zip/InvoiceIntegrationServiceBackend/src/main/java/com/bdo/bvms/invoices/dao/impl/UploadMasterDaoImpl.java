package com.bdo.bvms.invoices.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.dao.UploadMasterDao;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.EWayBillDTO;
import com.bdo.bvms.invoices.taxpayer.sql.MasterSQL;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class UploadMasterDaoImpl implements UploadMasterDao {

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Override
    public List<EInvoiceTemplateDTO> setErrorDiscription(List<EInvoiceTemplateDTO> errorDataListWithErrorCode) {

        HashMap<String, String> mapRet = new HashMap<>();

        jdbcTemplateMst.query(MasterSQL.GET_ERRORCODE_AND_SHORTDESCRIPTION,
                        new ResultSetExtractor<Map<String, String>>() {

                            @Override
                            public Map<String, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                while (rs.next()) {
                                    mapRet.put(rs.getString("ErrorCode"), rs.getString("ShortDescription"));
                                }
                                return mapRet;
                            }
                        });
        errorDataListWithErrorCode.forEach(data -> {
            String code = data.getErrorCodeList().toString().replace("|", ",");
            String[] errorCodeList = code.split(",");
            if (errorCodeList.length > 1) {
                for (int i = 1; i < errorCodeList.length; i++) {
                    String discription = mapRet.get(errorCodeList[i]);
                    data.setErrorDiscriptionList(data.getErrorDiscriptionList().append("|" + discription));
                }
            }
        });
        return errorDataListWithErrorCode;

    }

    @Override
    public List<EWayBillDTO> getNewErrorList(List<EWayBillDTO> errorlist) {
        HashMap<String, String> mapRet = new HashMap<>();

        jdbcTemplateMst.query(MasterSQL.GET_ERRORCODE_AND_SHORTDESCRIPTION,
                        new ResultSetExtractor<Map<String, String>>() {

                            @Override
                            public Map<String, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                while (rs.next()) {
                                    mapRet.put(rs.getString("ErrorCode"), rs.getString("ShortDescription"));
                                }
                                return mapRet;
                            }
                        });
        log.debug("In Method getNewErrorList getting Error Description Map For E-way Bill");
        errorlist.forEach(data -> {
            String code = data.getErrorCodeList().toString().replace("|", ",");
            String[] errorCodeList = code.split(",");
            if (errorCodeList.length > 1) {
                for (int i = 1; i < errorCodeList.length; i++) {
                    String discription = mapRet.get(errorCodeList[i].replaceAll(Constants.SUBSTRINGREGEX, ""));
                    data.setErrorDiscriptionList(data.getErrorDiscriptionList().append("|" + discription));
                }
            }
        });
        return errorlist;

    }

    @Override
    public String getFPYear(String fp) {
        String yearId = null;
        try {
            yearId = jdbcTemplateMst.queryForObject(MasterSQL.getFpYear(mstDatabseName), String.class, fp);
        } catch (EmptyResultDataAccessException e) {
            log.error("Error occured while execute getFPYear function:", e);
            yearId = "0";
        }
        return yearId;
    }
}
