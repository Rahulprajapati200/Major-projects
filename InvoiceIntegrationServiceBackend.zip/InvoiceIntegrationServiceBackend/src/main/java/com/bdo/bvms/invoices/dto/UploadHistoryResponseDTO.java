package com.bdo.bvms.invoices.dto;

import java.util.List;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UploadHistoryResponseDTO {

    Integer status;
    String message;
    String messageDescription;
    List<UploadLogHistoryResDataDto> data;

}
