package com.bdo.bvms.invoices.util;

import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.dao.CustomTemplateRepo;
import com.bdo.bvms.invoices.dto.AdvanceFilter;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.EWayBillDTO;
import com.bdo.bvms.invoices.dto.PoDetails;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceGrnMappingCrudDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class CommonUtils.
 */
@Slf4j
public class CommonUtils {

    /**
     * Instantiates a new common utils.
     */
    CommonUtils() {

    }

    /**
     * Gets the error file path.
     *
     * @param uploadDTO
     *            the upload DTO
     * @param tempFolder
     *            the temp folder
     * @return the error file path
     */
    public static String getErrorFilePath(UploadReqDTO uploadDTO, String tempFolder) {
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(Constants.FILESEPERATOR))
                        .append(uploadDTO.getBatchNo() + Constants.ERROR_DOT_CSV);
        return fileName.toString();
    }

    /**
     * Gets the success file path.
     *
     * @param uploadDTO
     *            the upload DTO
     * @param tempFolder
     *            the temp folder
     * @return the success file path
     */
    // System.getProperty(Constants.FILESEPERATOR)
    public static String getSuccessFilePath(UploadReqDTO uploadDTO, String tempFolder) {
        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(Constants.FILESEPERATOR))
                        .append(uploadDTO.getBatchNo() + Constants.SUCCESS_DOT_CSV);
        return fileName.toString();
    }

    /**
     * Gets the column name list.
     *
     * @param coumnsDataRow
     *            the coumns data row
     * @return the column name list
     */
    public static List<String> getColumnNameList(Row coumnsDataRow) {

        List<String> headerList = new ArrayList<>();
        int minColIx = coumnsDataRow.getFirstCellNum(); // get the first column
        // index for a row
        int maxColIx = coumnsDataRow.getLastCellNum(); // get the last column
        // index for a row
        Cell cell;
        for (int colIx = minColIx; colIx < maxColIx; colIx++) { // loop from
            // first to last
            // index
            cell = coumnsDataRow.getCell(colIx); // get the cell

            if (cell.getCellType() == CellType.NUMERIC) {
                headerList.add(String.valueOf(cell.getNumericCellValue()));
            } else {
                headerList.add(cell.getStringCellValue());
            }

        }
        return headerList;
    }

    /**
     * Gets the batch no.
     *
     * @param uploadRequestDTO
     *            the upload request DTO
     * @return the batch no
     */
    public static String getBatchNo(UploadRequestDTO uploadRequestDTO) {

        StringBuilder batchNo = new StringBuilder();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(Constants.DD_MM);

        String currentDate = simpleDateFormat.format(new Date());

        Long currentTimestamp = new Timestamp(System.currentTimeMillis()).getTime();

        batchNo.append(uploadRequestDTO.getTemplatetypepldCode() + Constants.UNDERSCORE + uploadRequestDTO.getUserId()
                        + Constants.UNDERSCORE + uploadRequestDTO.getEntityId() + Constants.UNDERSCORE + currentDate
                        + Constants.UNDERSCORE + currentTimestamp + Constants.UNDERSCORE
                        + generateRandonAlphabeticString(Constants.RANDOMNUM));

        return batchNo.toString();

    }

    /**
     * Gets the custom template header mappings.
     *
     * @param uploadDTO
     *            the upload DTO
     * @param customTemplateRepo
     *            the custom template repo
     * @return the custom template header mappings
     */
    public static Map<String, String> getCustomTemplateHeaderMappings(UploadReqDTO uploadDTO,
                    CustomTemplateRepo customTemplateRepo) {
        if (uploadDTO.getIsCustomTemplate().equals(Constants.ISCUSTOMETEMPLATE)) {
            // HardCoding
            return getCustomTemplateHeaderMappings(Integer.parseInt(uploadDTO.getCustomTemplateId()),
                            customTemplateRepo);
        }
        return Collections.emptyMap();
    }

    /**
     * Gets the custom template header mappings.
     *
     * @param customTemplateId
     *            the custom template id
     * @param customTemplateRepo
     *            the custom template repo
     * @return the custom template header mappings
     */
    private static Map<String, String> getCustomTemplateHeaderMappings(int customTemplateId,
                    CustomTemplateRepo customTemplateRepo) {

        return customTemplateRepo.searchCustomTemplateHeaderMappings(customTemplateId);
    }

    /**
     * Generate randon alphabetic string.
     *
     * @param length
     *            the length
     * @return the string
     */
    public static String generateRandonAlphabeticString(int length) {

        if (length < 6) {
            length = 6;
        }

        final char[] allAllowed = "abcdefghijklmnopqrstuvwxyzABCDEFGJKLMNPRSTUVWXYZ0123456789".toCharArray();

        SecureRandom random = new SecureRandom();

        StringBuilder password = new StringBuilder();

        for (int i = 0; i < length; i++) {
            password.append(allAllowed[random.nextInt(allAllowed.length)]);
        }

        return password.toString();

    }

    static String conditionMethod(String condition, String value, String alias) {
        if ("Equals".equals(condition)) {
            return " = " + '"' + value + '"';
        } else if ("Does Not Equal".equals(condition)) {
            return " <> " + '"' + value + '"';
        }else if ("In".equals(condition)) {
            return " in " + value;
        } 
        else if ("Does Not Contain Data".equals(condition)) {
            return " not like " + '"' + "%" + value + "%" + '"';
        }

        else if ("Contains".equals(condition)) {
            return " like " + '"' + "%" + value + "%" + '"';
        } else if ("Begin With".equals(condition)) {
            return " like " + '"' + value + "%" + '"';
        } else if ("Does not Begin With".equals(condition)) {
            return " not like " + '"' + value + "%" + '"';
        }

        else if ("Ends with".equals(condition)) {
            return " like " + '"' + "%" + value + '"';
        } else if ("Is null".equals(condition)) {
            return " is null ";
        } else if ("Is not null".equals(condition)) {
            return " is not null ";
        } else if(condition.contains("empty"))
		{    
			return  " = " + '"'+value+'"' +" or " +alias +" is null)";
		}
        else {
            return "" + '"';
        }

    }

    public static String getWhereCondition(List<AdvanceFilter> advanceFilter, Map<String, String> aliasMap) {

        List<String> whereConditionArray = new ArrayList<>();
        int i = 0;
        int k = advanceFilter.size();
        for (AdvanceFilter x : advanceFilter) {
            if (("Upload Date".equals(x.getAlias()) || "Fetched Date".equals(x.getAlias())
                            || "Details Upload Date".equals(x.getAlias()) || "Reject Date".equals(x.getAlias())
                            || "Last Synced Date".equals(x.getAlias()) || "Primary Sync On".equals(x.getAlias()))
                            && StringUtils.isNotBlank(x.getValue())) {
                SimpleDateFormat inSDF = new SimpleDateFormat("dd-mm-yyyy");
                SimpleDateFormat outSDF = new SimpleDateFormat("yyyy-mm-dd");
                if ("Equals".equals(x.getCondition())) {
                    x.setCondition("Contains");
                }
                Date date;
                try {
                    date = inSDF.parse(x.getValue());
                    x.setValue(outSDF.format(date));
                } catch (ParseException e) {
                    log.error("Error in Parsing Date Format");

                }

            }
            if (StringUtils.isNotBlank(aliasMap.get(x.getAlias()))) {
            	String y="";
            	if(x.getCondition().contains("Is empty"))
            	{
            		y="("+aliasMap.get(x.getAlias());
            	}
            	else if(x.getCondition().contains("Is not empty"))
            	{
            		y="not ("+aliasMap.get(x.getAlias());
            	}
            	else
            	{
            		y=aliasMap.get(x.getAlias());
            	}
           	
                whereConditionArray.add((y)
                                + conditionMethod(x.getCondition(), x.getValue(), aliasMap.get(x.getAlias())));

            }
            i++;
            
        }
        return String.join(" and ", whereConditionArray);

    }

    public static String getVendorJourneyWhereCondition(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    List<AdvanceFilter> advanceFilter) {
        List<String> whereConditionArray = new ArrayList<>();

        for (AdvanceFilter x : advanceFilter) {
        	
        	
        	
            if (("Last Synced Date".equals(x.getAlias()) || "Details Upload Date".equals(x.getAlias())
                            || "Uploaded On".equals(x.getAlias()) || "Submitted On".equals(x.getAlias())
                            || "uplg.created_at".equals(x.getAlias()) || "Rejected On".equals(x.getAlias())
                            || "Approved On".equals(x.getAlias())) && StringUtils.isNotBlank(x.getValue())) {
                SimpleDateFormat inSDF = new SimpleDateFormat("dd-mm-yyyy");
                SimpleDateFormat outSDF = new SimpleDateFormat("yyyy-mm-dd");
                if ("Equals".equals(x.getCondition())) {
                    x.setCondition("Contains");
                }
                Date date;
                try {
                    date = inSDF.parse(x.getValue());
                    x.setValue(outSDF.format(date));
                } catch (ParseException e) {
                    log.error("Error in Parsing Date Format");

                }

            }

            if (StringUtils.isNotBlank(x.getAlias())) {
            	String y="";
            	if(x.getCondition().contains("Is empty"))
            	{
            		y="("+getAliasMap1(vendorInvoiceRequestDTO.getTabId()).get(x.getAlias());
            	}
            	else if(x.getCondition().contains("Is not empty"))
            	{
            		y="not ("+getAliasMap1(vendorInvoiceRequestDTO.getTabId()).get(x.getAlias());
            	}
            	else
            	{
            		y=getAliasMap1(vendorInvoiceRequestDTO.getTabId()).get(x.getAlias());
            	}
            
            if (StringUtils.isNotBlank(getAliasMap1(vendorInvoiceRequestDTO.getTabId()).get(x.getAlias()))) {

                String aliasName = getAliasMap1(vendorInvoiceRequestDTO.getTabId()).get(x.getAlias());
                whereConditionArray.add(y + conditionMethod(x.getCondition(), x.getValue(), aliasName));
            }
            }

        }
        return String.join(" and ", whereConditionArray);

    }

    public static VendorInvoiceGrnMappingCrudDTO setVendorInvoiceGrnMappingCrudDTO(int id,
                    EInvoiceTemplateDTO eInvoiceTemplateDTO,
                    List<VendorInvoiceGrnMappingCrudDTO> vendorInvoiceGrnMappingCrudDTOList) {
        VendorInvoiceGrnMappingCrudDTO vendorInvoiceGrnMappingCrudDTO = new VendorInvoiceGrnMappingCrudDTO();
        vendorInvoiceGrnMappingCrudDTO.setId(id);
        vendorInvoiceGrnMappingCrudDTO.setInvoiceDate(eInvoiceTemplateDTO.getInwardDate());
        vendorInvoiceGrnMappingCrudDTO.setInvoiceNo(eInvoiceTemplateDTO.getInwardNo());
        vendorInvoiceGrnMappingCrudDTO.setTaxpayerGstin(eInvoiceTemplateDTO.getGstinUinOfRecipient());
        vendorInvoiceGrnMappingCrudDTO.setVendorGstin(eInvoiceTemplateDTO.getGstinOfSupplier());

        String[] poNoList = new String[20];
        String[] poDateList = new String[20];
        if (StringUtils.isNotBlank(eInvoiceTemplateDTO.getPurchaseOrderNumber())) {
            poNoList = eInvoiceTemplateDTO.getPurchaseOrderNumber().split(",");
        }
        if (StringUtils.isNotBlank(eInvoiceTemplateDTO.getPurchaseOrderDate())) {
            poDateList = eInvoiceTemplateDTO.getPurchaseOrderDate().split(",");
        }
        for (int index = 0; index < poDateList.length; index++) {
            PoDetails poDetails = new PoDetails();
            poDetails.setPoDate(poDateList[index]);
            poDetails.setPoNo(poNoList[index]);
            vendorInvoiceGrnMappingCrudDTO.getPoDetails().add(poDetails);
        }
        return vendorInvoiceGrnMappingCrudDTO;

    }

    public static VendorInvoiceGrnMappingCrudDTO setVendorInvoiceGrnMappingCrudDTO(int id,
                    EWayBillDTO eWayBillTemplateDTO,
                    List<VendorInvoiceGrnMappingCrudDTO> vendorInvoiceGrnMappingCrudDTOList) {
        VendorInvoiceGrnMappingCrudDTO vendorInvoiceGrnMappingCrudDTO = new VendorInvoiceGrnMappingCrudDTO();
        vendorInvoiceGrnMappingCrudDTO.setId(id);
        vendorInvoiceGrnMappingCrudDTO.setEWayBillDate(eWayBillTemplateDTO.getEWayBillDate());
        vendorInvoiceGrnMappingCrudDTO.setEWayBillNo(eWayBillTemplateDTO.getEWayBillNo());
        vendorInvoiceGrnMappingCrudDTO.setTaxpayerGstin(eWayBillTemplateDTO.getTaxpayerGstin());
        vendorInvoiceGrnMappingCrudDTO.setVendorGstin(eWayBillTemplateDTO.getVendorGstin());

        String[] poNoList = new String[20];
        String[] poDateList = new String[20];
        if (StringUtils.isNotBlank(eWayBillTemplateDTO.getPoDate())) {
            poNoList = eWayBillTemplateDTO.getPoNo().split(",");
        }
        if (StringUtils.isNotBlank(eWayBillTemplateDTO.getPoDate())) {
            poDateList = eWayBillTemplateDTO.getPoNo().split(",");
        }
        for (int index = 0; index < poDateList.length; index++) {
            PoDetails poDetails = new PoDetails();
            poDetails.setPoDate(poDateList[index]);
            poDetails.setPoNo(poNoList[index]);
            vendorInvoiceGrnMappingCrudDTO.getPoDetails().add(poDetails);
        }
        return vendorInvoiceGrnMappingCrudDTO;

    }

    static Map<String, String> getAliasMap1(String tabId) {
        Map<String, Map<String, String>> newAliasMap = new HashMap<>();
        if ("0".equals(tabId)) {
            Map<String, String> processedInvoiceMap = new HashMap<>();
            processedInvoiceMap.put("Company GSTIN", "vendor_gstin");
            processedInvoiceMap.put("Customer GSTIN", "taxpayer_gstin");//
            processedInvoiceMap.put("Customer Legal Name", "vendor_legal_name");
            processedInvoiceMap.put("Customer Trade Name", "vendor_trade_name");
            processedInvoiceMap.put("Invoice No.", "invoice_no");
            processedInvoiceMap.put("Invoice Date", "invoice_date");
            processedInvoiceMap.put("Sync With GSTR2A", "sync_with_gstr2a");
            processedInvoiceMap.put("Sync With GSTR2B", "sync_with_gstr2b");
            processedInvoiceMap.put("Sync With E-Way Bill", "sync_with_eway_bill");
            processedInvoiceMap.put("Taxable Value (₹)", "taxable_value");
            processedInvoiceMap.put("IGST (₹)", "igst");
            processedInvoiceMap.put("CGST (₹)", "cgst");
            processedInvoiceMap.put("SGST (₹)", "sgst");
            processedInvoiceMap.put("Cess (₹)", "cess");
            processedInvoiceMap.put("Invoice Value (₹)", "invoice_value");
            processedInvoiceMap.put("QR Code Valid", "qr_code_valid");
            processedInvoiceMap.put("Details Upload Date", "details_upload_date");
            processedInvoiceMap.put("Uploaded By", "uploaded_by");
            processedInvoiceMap.put("Last Synced Date", "last_synced_date");
            // processedInvoiceMap.put("hd.sync_status", "hd.sync_status");
            processedInvoiceMap.put("IRN Verified", "status");

            newAliasMap.put("ProcessedInvoice", processedInvoiceMap);
            return newAliasMap.get("ProcessedInvoice");
        }

        if ("1".equals(tabId)) {
            Map<String, String> totalDocumentMap = new HashMap<>();
            totalDocumentMap.put("Company GSTIN", "companygstin");//
            // totalDocumentMap.put("pld.name", "pld.name");
            totalDocumentMap.put("Data Type", "dataid");
            totalDocumentMap.put("Customer GSTIN", "customergstin  ");
            totalDocumentMap.put("Customer Legal Name", "customerlegalname");
            totalDocumentMap.put("Customer Trade Name", "customertradename");
            totalDocumentMap.put("Invoice No.", "invoiceno");
            totalDocumentMap.put("Invoice Date", "invoicedate");
            totalDocumentMap.put("e-Way Bill No.", "ewaybillno");
            totalDocumentMap.put("e-Way Bill Date", "ewaybilldate");
            totalDocumentMap.put("Uploaded On", "uploadedon");
            totalDocumentMap.put("Uploaded By", "uploadedby");
            totalDocumentMap.put("Document Status", "documentstatus");

            newAliasMap.put("TotalDocument", totalDocumentMap);
            return newAliasMap.get("TotalDocument");
        }

        if ("2".equals(tabId)) {
            Map<String, String> draftDocumentMap = new HashMap<>();
            draftDocumentMap.put("Company GSTIN", "companygstin");
            draftDocumentMap.put("Data Type", "dataid");
            draftDocumentMap.put("Customer GSTIN", "customergstin");
            draftDocumentMap.put("Customer Legal Name", "customerlegalname");
            draftDocumentMap.put("Customer Trade Name", "customertradename");
            draftDocumentMap.put("Invoice No.", "invoiceno");
            draftDocumentMap.put("Invoice Date", "invoicedate");
            draftDocumentMap.put("e-Way Bill No.", "ewaybillno");
            draftDocumentMap.put("e-Way Bill Date", "ewaybilldate");
            draftDocumentMap.put("Uploaded On", "uploadedon");
            draftDocumentMap.put("Uploaded By", "uploadedby");
            draftDocumentMap.put("Document Status", "documentstatus");

            newAliasMap.put("DraftDocument", draftDocumentMap);
            return newAliasMap.get("DraftDocument");
        }
        if ("11".equals(tabId)) {
            Map<String, String> submittedPendingApprovalDocumentsMap = new HashMap<>();
            submittedPendingApprovalDocumentsMap.put("Company GSTIN", "companygstin");
            submittedPendingApprovalDocumentsMap.put("Data Type", "dataid");
            submittedPendingApprovalDocumentsMap.put("Customer GSTIN", "customergstin");
            submittedPendingApprovalDocumentsMap.put("Customer Legal Name",
                            "customerlegalname");
            submittedPendingApprovalDocumentsMap.put("Customer Trade Name",
                            "customertradename");
            submittedPendingApprovalDocumentsMap.put("Invoice No.", "invoiceno");
            submittedPendingApprovalDocumentsMap.put("Invoice Date", "invoicedate");
            submittedPendingApprovalDocumentsMap.put("e-Way Bill No.", "ewaybillno");
            submittedPendingApprovalDocumentsMap.put("e-Way Bill Date", "ewaybilldate");
            submittedPendingApprovalDocumentsMap.put("Submitted On", "uploadedon");
            submittedPendingApprovalDocumentsMap.put("Submitted By", "submittedby");
            submittedPendingApprovalDocumentsMap.put("Document Status", "documentstatus");

            newAliasMap.put("SubmittedPendingApprovalDocuments", submittedPendingApprovalDocumentsMap);
            return newAliasMap.get("SubmittedPendingApprovalDocuments");
        }
        if ("22".equals(tabId)) {
            Map<String, String> approveDocumentMap = new HashMap<>();
            approveDocumentMap.put("Company GSTIN", "companygstin");
            approveDocumentMap.put("Data Type", "dataid");
            approveDocumentMap.put("Customer GSTIN", "customergstin");
            approveDocumentMap.put("Customer Legal Name", "customerlegalname");
            approveDocumentMap.put("Customer Trade Name", "customertradename");
            approveDocumentMap.put("Invoice No.", "invoiceno");
            approveDocumentMap.put("Invoice Date", "invoicedate");
            approveDocumentMap.put("e-Way Bill No.", "ewaybillno");
            approveDocumentMap.put("e-Way Bill Date", "ewaybilldate");
            approveDocumentMap.put("Submitted On", "submittedon");
            approveDocumentMap.put("Submitted By", "submittedby");
            approveDocumentMap.put("Approved On", "approved_on");
            approveDocumentMap.put("Document Status", "documentstatus");

            newAliasMap.put("ApproveDocument", approveDocumentMap);
            return newAliasMap.get("ApproveDocument");
        }

        else {
            Map<String, String> rejectedDocumentMap = new HashMap<>();
            rejectedDocumentMap.put("Company GSTIN", "companygstin");
            rejectedDocumentMap.put("Data Type", "dataid");
            rejectedDocumentMap.put("Customer GSTIN", "customergstin");
            rejectedDocumentMap.put("Customer Legal Name", "customerlegalname");
            rejectedDocumentMap.put("Customer Trade Name", "customertradename");
            rejectedDocumentMap.put("Invoice No.", "invoiceno");
            rejectedDocumentMap.put("Invoice Date", "invoicedate");
            rejectedDocumentMap.put("e-Way Bill No.", "ewaybillno");
            rejectedDocumentMap.put("e-Way Bill Date", "ewaybilldate");
            rejectedDocumentMap.put("Submitted On", "submittedon");
            rejectedDocumentMap.put("Submitted By", "submittedby");
            rejectedDocumentMap.put("Rejected On", "approved_on");
            rejectedDocumentMap.put("Document Status", "documentstatus");

            newAliasMap.put("newAliasMap", rejectedDocumentMap);

            return newAliasMap.get("newAliasMap");
        }

    }

}
