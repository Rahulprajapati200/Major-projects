package com.bdo.bvms.invoices.taxpayer.validationrule;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.ValidationConstants;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.UploadMasterDao;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;

import lombok.extern.slf4j.Slf4j;

// TODO: Auto-generated Javadoc
/** The Constant log. */
@Slf4j
public class EInvoiceValidationRules {

    /** The invoice exist in pre fp map. */
    Map<String, Map<String, String>> invoiceExistInPreFpMap = new HashMap<String, Map<String, String>>();

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(EInvoiceValidationRules.class);

    /**
     * Validate rules.
     *
     * @param rowdata
     *            the rowdata
     * @throws ParseException
     *             the parse exception
     */
    public void validateRules(EInvoiceTemplateDTO rowdata, UploadReqDTO uploadDto) throws ParseException {

        logger.info("Entering validateRules Method");
        EInvoiceValidationUtil inwardRules = new EInvoiceValidationUtil();
        String []poDateList = new String[20];
        String [] poNoList = new String[20];

// taxpayer GSTIN Validation 

        checkForValidGstin(rowdata, inwardRules);

        // rules for gstin_of_recipient field
        checkForTaxPayerGstinEqualsSupplierGstin(rowdata);

        List<String> docTypeList = new ArrayList<>(Arrays.asList("INV", "CRN", "DBN"));

        checkDocTypeListValueAndIsEmpty(rowdata, docTypeList);

		// Supplier GSTIN Validation 	
		checkSupplierGstinIsValid(rowdata, inwardRules);
        
        if(StringUtils.isNotBlank(rowdata.getPurchaseOrderNumber())) {

            poNoList = rowdata.getPurchaseOrderNumber().split(",");
            
        }

        Arrays.asList(poNoList).forEach(poNo -> {

            // Purchase Order Number
            checkForPurchaseOrderNumberLength(poNo, rowdata);

            checkForPONumberSpecialChar(poNo, rowdata, inwardRules);

        });

        if(StringUtils.isNotBlank(rowdata.getPurchaseOrderDate())) {
          poDateList = rowdata.getPurchaseOrderDate().split(",");
        }

        poNoAndPoDateCount(rowdata, poNoList, poDateList);

        Arrays.asList(poDateList).forEach(poDate -> {

            // Purchase Order Date
            checkFuturePoDate(poDate, rowdata, inwardRules);
            checkPoDateIsEmpty(poDate, rowdata);
            checkPoDateFor2017(poDate, rowdata, inwardRules);

            // Purchase Order Date cannot exceed Document Date

            checkPoDateExceedInwardDate(poDate, rowdata, inwardRules);

        });

//IRN Date
        checkFutureIrnDate(rowdata, inwardRules);
        checkIrnDateIsEmpty(rowdata);
// Document no./Inward no Validation 

// Inward Date Validation 	
        checkBlankInwardDate(rowdata);
        // inwardDate should be in DD-MM-YYYY format
        checkValidInwardDate(rowdata, inwardRules);

        checkInwardDatefor2017(rowdata, inwardRules);

        checkForInwardFutureDate(rowdata, inwardRules);

// Total Invoice Amount Validation  for Blank
        if (Constants.PDF.equalsIgnoreCase(uploadDto.getFileType())
                        && Constants.INVOICE_CODE.equalsIgnoreCase(uploadDto.getUploadType())) {
            log.info("no invoice value validation check for Invoice pdf");
        } else {
            checkForBlankTotalInvoiceValue(rowdata);
        }

    }

    private void poNoAndPoDateCount(EInvoiceTemplateDTO rowData, String[] poNoList, String[] poDateList) {
        if (poNoList.length != poDateList.length) {
            markErrorNAddErrorCode(rowData, ValidationConstants.ERROR_CODE_E00564, "");
        }
    }

    /**
     * Check irn date is empty.
     *
     * @param rowdata
     *            the rowdata
     */
    private void checkIrnDateIsEmpty(EInvoiceTemplateDTO rowdata) {
        if ((StringUtils.isBlank(rowdata.getIrn()) || "0".equals(rowdata.getIrn()))
                        && (StringUtils.isNotBlank(rowdata.getIrnDate()))) {

            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00268, "");

        }

    }

    /**
     * Check po date for 2017.
     *
     * @param rowdata
     *            the rowdata
     * @param inwardRules
     *            the inward rules
     */
    private void checkPoDateFor2017(String poDate, EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil inwardRules) {
        if ((StringUtils.isNoneBlank(poDate)) && (inwardRules.isValidInvoiceDate(poDate))
                        && (!inwardRules.isValidDateRange(poDate))) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00318, "");
        }

    }

    /**
     * Check po date is empty.
     *
     * @param rowdata
     *            the rowdata
     */
    private void checkPoDateIsEmpty(String poDate, EInvoiceTemplateDTO rowdata) {
        if ((StringUtils.isBlank(rowdata.getPurchaseOrderNumber()) || "0".equals(poDate))
                        && StringUtils.isNotBlank(poDate)) {

            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00266, "");

        }

    }

    /**
     * Check for blank total invoice value.
     *
     * @param rowdata
     *            the rowdata
     */
    private void checkForBlankTotalInvoiceValue(EInvoiceTemplateDTO rowdata) {
        if (StringUtils.isBlank(rowdata.getTotalInvoiceValue())
                        || StringUtils.isEmpty(rowdata.getTotalInvoiceValue())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00263, "");
        }
    }

    /**
     * Check for inward future date.
     *
     * @param rowdata
     *            the rowdata
     * @param inwardRules
     *            the inward rules
     * @throws ParseException
     *             the parse exception
     */
    private void checkForInwardFutureDate(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil inwardRules)
                    throws ParseException {
        if ((StringUtils.isNotBlank(rowdata.getInwardDate()))
                        && (inwardRules.isValidInvoiceDate(rowdata.getInwardDate()))
                        && (!inwardRules.ifFutureDate(rowdata.getInwardDate()))) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00315, "");
        }
    }

    /**
     * Check inward datefor 2017.
     *
     * @param rowdata
     *            the rowdata
     * @param inwardRules
     *            the inward rules
     */
    private void checkInwardDatefor2017(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil inwardRules) {
        if ((StringUtils.isNotBlank(rowdata.getInwardDate()))
                        && (inwardRules.isValidInvoiceDate(rowdata.getInwardDate()))
                        && (!inwardRules.isValidDateRange(rowdata.getInwardDate()))) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00314, "");
        }
    }

    /**
     * Check valid inward date.
     *
     * @param rowdata
     *            the rowdata
     * @param inwardRules
     *            the inward rules
     */
    private void checkValidInwardDate(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil inwardRules) {
        if (StringUtils.isNotBlank(rowdata.getInwardDate())
                        && !inwardRules.isValidInvoiceDate(rowdata.getInwardDate())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00313, "");
        }
    }

    /**
     * Check blank inward date.
     *
     * @param rowdata
     *            the rowdata
     */
    private void checkBlankInwardDate(EInvoiceTemplateDTO rowdata) {
        if (StringUtils.isBlank(rowdata.getInwardDate())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00262, "");
        }
    }

    /**
     * Check future irn date.
     *
     * @param rowdata
     *            the rowdata
     * @param inwardRules
     *            the inward rules
     * @throws ParseException
     *             the parse exception
     */
    private void checkFutureIrnDate(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil inwardRules)
                    throws ParseException {
        if (StringUtils.isNotBlank(rowdata.getIrnDate())
//				&& (inwardRules.isValidDateRange(rowdata.getIrnDate()))
                        && (inwardRules.isValidInvoiceDate(rowdata.getIrnDate()))
                        && (!inwardRules.ifFutureDate(rowdata.getIrnDate()))) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00320, "");
        }
    }

    /**
     * Check po date exceed inward date.
     *
     * @param rowdata
     *            the rowdata
     * @param inwardRules
     *            the inward rules
     */
    private void checkPoDateExceedInwardDate(String poDate, EInvoiceTemplateDTO rowdata,
                    EInvoiceValidationUtil inwardRules) {
        if ((StringUtils.isNotBlank(poDate)) && (inwardRules.isValidInvoiceDate(rowdata.getInwardDate()))
                        && (inwardRules.isValidInvoiceDate(poDate))
//				&& (inwardRules.isValidDateRange(rowdata.getInwardDate()))
//				&& (inwardRules.isValidDateRange(rowdata.getPurchaseOrderDate()))
//				&& (inwardRules.ifFutureDate(rowdata.getPurchaseOrderDate()))
//				&& (inwardRules.ifFutureDate(rowdata.getInwardDate()))
                        && (!inwardRules.ifExceedDate(poDate, rowdata.getInwardDate()))) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00261, "");
        }
    }

    /**
     * Check future po date.
     *
     * @param rowdata
     *            the rowdata
     * @param inwardRules
     *            the inward rules
     * @throws ParseException
     *             the parse exception
     */
    private void checkFuturePoDate(String poDate, EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil inwardRules) {
        if (StringUtils.isNotBlank(poDate) && (inwardRules.isValidInvoiceDate(poDate))
                        && !inwardRules.ifFutureDate(poDate)) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00291, "");
        }
    }

    /**
     * Check for PO number special char.
     *
     * @param rowdata
     *            the rowdata
     * @param inwardRules
     *            the inward rules
     */
    private void checkForPONumberSpecialChar(String poNo, EInvoiceTemplateDTO rowdata,
                    EInvoiceValidationUtil inwardRules) {
        if (StringUtils.isNotBlank(poNo) && !inwardRules.isSpecialCharExistInInvoiceNo(poNo)) {

            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00260, "");

        }
    }

    /**
     * Check for purchase order number length.
     *
     * @param rowdata
     *            the rowdata
     */
    private void checkForPurchaseOrderNumberLength(String poNo, EInvoiceTemplateDTO rowdata) {
        if (StringUtils.isNotBlank(poNo) && poNo.length() > 50) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00259, "");
        }
    }

    /**
     * Check supplier gstin is valid.
     *
     * @param rowdata
     *            the rowdata
     * @param inwardRules
     *            the inward rules
     */
    private void checkSupplierGstinIsValid(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil inwardRules) {
        if (!StringUtils.isBlank(rowdata.getGstinOfSupplier()) && !"0".equals(rowdata.getGstinOfSupplier())
                        && !StringUtils.isEmpty(rowdata.getGstinOfSupplier())
                        && !inwardRules.validGSTIN(rowdata.getGstinOfSupplier())) {
            logger.info("Validdating getGstinOfSupplier");
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00287, "");
        }
    }

    /**
     * Check doc type list value and is empty.
     *
     * @param rowdata
     *            the rowdata
     * @param docTypeList
     *            the doc type list
     */
    private void checkDocTypeListValueAndIsEmpty(EInvoiceTemplateDTO rowdata, List<String> docTypeList) {
        if ("0".equals(rowdata.getDocType()) || "0.00".equals(rowdata.getDocType())
                        || "0.0".equals(rowdata.getDocType()) || StringUtils.isBlank(rowdata.getDocType())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00258, "");
        } else if (!docTypeList.contains(rowdata.getDocType())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00257, "");
        }
    }

    /**
     * Check for tax payer gstin equals supplier gstin.
     *
     * @param rowdata
     *            the rowdata
     */
    private void checkForTaxPayerGstinEqualsSupplierGstin(EInvoiceTemplateDTO rowdata) {
        if (StringUtils.isNotBlank(rowdata.getGstinUinOfRecipient())
                        && rowdata.getGstinUinOfRecipient().equals(rowdata.getGstinOfSupplier())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00014, "");
        }
    }

    /**
     * Check for valid gstin.
     *
     *
     * @param rowdata
     *            the rowdata
     * @param inwardRules
     *            the inward rules
     */
    private void checkForValidGstin(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil inwardRules) {
        if (!StringUtils.isBlank(rowdata.getGstinUinOfRecipient()) && !"0".equals(rowdata.getGstinUinOfRecipient())
                        && !StringUtils.isEmpty(rowdata.getGstinUinOfRecipient())
                        && !inwardRules.validGSTIN(rowdata.getGstinUinOfRecipient())) {
            logger.info("Validdating getGstinUinOfRecipient");
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00286, "");
        }
    }

    /**
     * Mark error N add error code.
     *
     * @param rowdata
     *            the rowdata
     * @param errorCode
     *            the error code
     * @param errorMsg
     *            the error msg
     */
    private void markErrorNAddErrorCode(EInvoiceTemplateDTO rowdata, String errorCode, String errorMsg) {

        logger.info("Entering markErrorNAddErroCode Method");
        rowdata.setErrorCodeList(rowdata.getErrorCodeList().append(errorCode));
        rowdata.setErrorDiscriptionList(rowdata.getErrorDiscriptionList().append(errorMsg));
        rowdata.setValid(false);
    }

    /**
     * Check fp.
     *
     * @param rowData
     *            the row data
     * @param totalArraySize
     *            the total array size
     * @param uploadMasterDao
     *            the upload master dao
     * @param commonDao
     *            the common dao
     */
    public void checkFp(EInvoiceTemplateDTO rowData, int totalArraySize, UploadMasterDao uploadMasterDao,
                    CommonDao commonDao) {

        if (rowData.isValid()) {

            String invNDate = rowData.getInwardNo() + rowData.getInwardDate();
            if (StringUtils.isNotBlank(invNDate)) {
                invNDate = invNDate.toLowerCase();
            }

            String fp = "";
            String yearId = null;
            fp = new StringBuilder().append(rowData.getFillingPeriod()).toString();
            yearId = uploadMasterDao.getFPYear(fp);
            Integer isInvoiceInUploadedFP = 0;
            if (totalArraySize < 5000) {
                isInvoiceInUploadedFP = commonDao.checkInvoiceAlreadySaved(rowData.getGstinOfSupplier(),
                                rowData.getInwardNo(), rowData.getInwardDate(), fp, "0", yearId);

            } else {
                String savedInGSTKeyInFP = rowData.getGstinOfSupplier() + fp + "1" + yearId;
                if (invoiceExistInPreFpMap.get(savedInGSTKeyInFP) == null) {

                    List<String> invNDateList = commonDao.getBatchDataUploadedInPreviousFP(rowData.getGstinOfSupplier(),
                                    fp, yearId);
                    Map<String, String> map = invNDateList.stream().collect(Collectors.toMap(str -> str, str -> str));

                    invoiceExistInPreFpMap.put(savedInGSTKeyInFP, map);
                    if (map != null && invoiceExistInPreFpMap.get(savedInGSTKeyInFP).get(invNDate) != null) {
                        isInvoiceInUploadedFP++;
                    }

                } else {
                    Map<String, String> map = invoiceExistInPreFpMap.get(savedInGSTKeyInFP);
                    if (map != null && map.get(invNDate) != null) {
                        isInvoiceInUploadedFP++;
                    }

                }
            }

            if (isInvoiceInUploadedFP > 0) {
                markErrorNAddErrorCode(rowData, "|E00087", "");

            }
        }

    }
}
