package com.bdo.bvms.invoices.dao;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.EWayBillDTO;
import com.bdo.bvms.invoices.dto.ErrorCodeDescriptionResponseDTO;
import com.bdo.bvms.invoices.dto.ResponseBean;
import com.bdo.bvms.invoices.dto.UploadLogDto;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.bvms.invoices.dto.UploadStageLogDto;

public interface UploadTransDao {

    List<EInvoiceTemplateDTO> getErrorDataListWithErrorCode(UploadReqDTO uploadDTO);

    void uploadTxLogDetails(UploadLogDto txUploadLog) throws VendorInvoiceServerException;

    List<EWayBillDTO> getErrorData(String batchNo);

    void updateProcessStatus(String batchNo, String uploadInvoicesPldStatusFail);

    void updateErrorFileName(String batchNo, String csvSuccessFilePath);

    int getUploadIdFromDB(String batchNo);

    void updateTimeStamp(String query, UploadReqDTO uploadDTO);

    int updateAgainBatchLog(String batchNo);

    int updateBatchLog(String batchNo);

    void updateUploadStageNState(String stage, String state, int uploadLogId);

    void insertUploadStageLog(UploadStageLogDto uploadStageLogDto);

    void updateCount(String query, int count, UploadReqDTO uploadDTO);

    void updateErrorNSuccessCountAndTotalCount(ResponseBean responseBean, String batchNo);

    Map<String, String> getFieldsValue(String gstin, List<String> fillingPeriod);

    int updatePldCode(String customtemplateID);

    Map<String, Object> writeInvoiceDetailsToInvoiceHeader(String batchNo, int i,int userid,String dbName);

    int getInwardResultFPCount(String gstinUinOfRecipient, String inwardNo, String inwardDate, String gstinOfSupplier,
                    String fillingPeriod, String string);



    Map<String, Object> VendorInvoiceRegisterPo(String batchNo);

    Map<String, Object> commonPostNotification(int vendoruploadmstid, String string, int userId, int userId2,
                    int userId3, String schemaname, String notificationCode);

	void updateProcessStatusWithRemarks(String batchNo, String pldUploadStatus, String remarks);

	void updateFpLog(List<String> month, UploadReqDTO uploadRequestDTO);

	List<String> getInvoiceAlreadySynced(String taxpayerGstin, String pldUploadType);

	List<String> getInvoiceDuplicateInvoiceInDiffFP(String supplierGstn, String recipientGSTN, String fp);

	List<String> getEWayDuplicateFPInDiffMonthFP(String supplierGstn, String recipientGSTN, String fp);

	void insertUploadStageNState(String processStageDataValidation, String processFileUploadStatusStart,
			UploadReqDTO uploadDTO);

	void insertStageNState(String processStageDataValidation, String processFileUploadStatusStart,
			UploadRequestDTO uploadRequestDTO, String batchNo);

	void poGrnMapping(UploadReqDTO uploadDTO, String json);


	void insertIntoQRExecutionLog(UploadReqDTO uploadDTO, String output, LocalDateTime start, LocalDateTime end);


	void updateQRScanFlag(String batchNo, int isScan);

	List<String> getInvoiceAlreadyApproved(String taxpayerGstin);

	List<String> getEWBAlreadyApproved(String taxpayerGstin);

	List<String> getEWBAlreadySynced(String taxpayerGstin, String vendorGstin);

	String getEinvoiceErrorMessage(List<EInvoiceTemplateDTO> errorDataListWithErrorCode);
	
	String getEwayBillErrorMessage(List<EWayBillDTO> errorDataListWithErrorCode);


}
