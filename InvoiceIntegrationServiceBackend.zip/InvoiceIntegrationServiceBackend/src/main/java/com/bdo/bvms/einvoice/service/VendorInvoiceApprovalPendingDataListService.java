package com.bdo.bvms.einvoice.service;

import java.util.List;
import java.util.Map;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.ApprovalPendingResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceColumnsNameResponseDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface VendorInvoiceApprovalPendingDataListService {

    Map<String, Object> getApprovalPendingDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
                    String monthList) throws VendorInvoiceServerException;

    int getApprovalPendingTotalCount(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
                    String monthList);

    List<ApprovalPendingResDTO> getApprovalPendingDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException;

    List<VendorInvoiceColumnsNameResponseDTO> getApprovalPendingColumnNames(
                    VendorInvoiceRequestDTO vendorInvoiceRequestDTO) throws VendorInvoiceServerException;

}
