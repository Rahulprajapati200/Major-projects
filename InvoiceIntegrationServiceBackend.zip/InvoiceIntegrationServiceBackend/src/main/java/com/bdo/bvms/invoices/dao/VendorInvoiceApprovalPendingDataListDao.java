package com.bdo.bvms.invoices.dao;

import java.util.List;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.ApprovalPendingResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface VendorInvoiceApprovalPendingDataListDao {

    List<ApprovalPendingResDTO> getApprovalPendingDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException;

}
