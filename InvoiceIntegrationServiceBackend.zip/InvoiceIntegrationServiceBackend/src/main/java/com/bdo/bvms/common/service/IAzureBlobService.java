package com.bdo.bvms.common.service;

import com.azure.storage.blob.BlobClient;
import com.bdo.bvms.invoices.ocr.model.EntityCloudCredentials;

public interface IAzureBlobService {

    BlobClient getBlobClientWithEndPoint(EntityCloudCredentials entityCloudCredentials, String fileName);

}
