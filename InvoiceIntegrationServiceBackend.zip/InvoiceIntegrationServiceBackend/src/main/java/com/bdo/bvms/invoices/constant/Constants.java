
package com.bdo.bvms.invoices.constant;

public class Constants {

    Constants() {

    }

    public static final String E_INVOICE = "e-Invoice";
    public static final String E_WAY_BILL = "e-Way Bill";
    public static final String E_INVOICE_CODE = "20";
    public static final String E_WAY_BILL_CODE = "21";
    public static final String INVOICE_CODE = "97";
    public static final String E_INVOICE_CODE_VENDOR = "188";
    public static final String E_WAY_BILL_CODE_VENDOR = "189";
    public static final String INVOICE_CODE_VENDOR = "190";
    public static final String INVOICE_OCR_CODE = "332";
    public static final String INVOICE_OCR_CODE_VENDOR = "337";

    public static final String INVOICE = "Invoice";
    public static final String INVOICE_MAPPING = "Invoice & PO Mapping";

    public static final String DATEFORMATE1 = "dd-MM-yyyy";

    public static final String DATEFORMATE2 = "dd/MM/yyyy";
    public static final String FILESEPERATOR = "file.separator";
    public static final String ROWVERSION_DATEFORMATE = "dd-M-yyyy hh:mm:ss";
    public static final int E_INVOICE_TEMPLATE_COLUMN_COUNT = 32;
    public static final int E_INVOICE_TEMPLATE_MENDATORY_COLUMN_COUNT = 7;
    public static final String DATA_ROW = "coumnsDataRow";

    public static final String XLSX = "xlsx";
    public static final String XLS = "xls";
    public static final String CSV = "csv";
    public static final String PDF = "pdf";
    public static final String JPG = "jpeg";
    public static final String PNG = "png";

    public static final String SQL_ERROR = "9999";
    public static final String RESOURCE_NOT_FOUND_ERROR = "8888";

    /** The Constant DB_COMMUNICATION_ERROR. */
    public static final String DB_COMMUNICATION_ERROR = "bvms.label.common.errorOccuredInOperation";

    /** The Constant DBEXCEPTION. */
    // Common Exception Code started here
    public static final String DBEXCEPTION = "9999";

    /*
     * valid GSTIN verifying regex Strings.
     */
    public static final String GSTINFORMAT_REGEX = "[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[Z]{1}[0-9a-zA-Z]{1}";
    public static final String UINFORMAT_REGEX = "[0-9]{4}[A-Z]{3}[0-9]{5}[UO]{1}[N][A-Z0-9]{1}";
    public static final String TDSREGEX = "[0-9]{2}[a-zA-Z]{4}[a-zA-Z0-9]{1}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[D]{1}[0-9a-zA-Z]{1}";

    /*
     * Regex string for only numeric keywords
     */
    public static final String ONLYNUMERIC = "[^0-9.]";

    /*
     * regex string for NonValid date
     */
    public static final String NONVALIDDATEFORMAT = ".*[A-Za-z$&+,:;=?@#|'<>.^*()%!].*";

    /*
     * Valid Date format.
     * 
     */
    public static final String VALIDDATEFORMAT = "dd-MM-yyyy";

    /*
     * E-way bill Valid till can only have space ( ),(-)or colon (:)
     */
    public static final String SPECIALCHARACTERS = "^[a-zA-Z0-9\\-\\␣\\:]*";

    /*
     * Replaces each substring of this string that matches the given regular
     * expression.
     */
    public static final String SUBSTRINGREGEX = "[\n\r]";
    /*
     * Simple Date Format.
     */

    public static final String COMPAREABLESTRING = "capital goods";
    public static final String IMPORTINVOICE = "import invoice";
    public static final String ISDINVOICE = "isd invoice";
    public static final String INPUTS = "inputs";
    public static final String INPUTSERVICES = "input services";
    public static final String IMPGSEZ = "impgsez";
    public static final String CAPITALGOODS = "capital goods";
    public static final String UPLOAD_INVOICES_PLD_STATUS_INPROGRESS = "80";
    public static final String UPLOAD_INVOICES_PLD_STATUS_COMPLETED = "81";
    public static final String UPLOAD_INVOICES_PLD_STATUS_ERROR = "82";
    public static final String UPLOAD_INVOICES_PLD_STATUS_FAIL = "83";
    public static final String UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE = "84";

    public static final String PROCESS_STAGE_FILE_UPLOAD = "85";
    public static final String PROCESS_STAGE_DATA_VALIDATION = "87";
    public static final String PROCESS_STAGE_DATA_PROCESSING = "86";
    public static final String FILE_OCR_STAGING = "336";
    public static final String PROCESS_STAGE_COMPLETED = "88";
    public static final String PROCESS_FILE_UPLOAD_STATUS_START = "1";
    public static final String PROCESS_FILE_UPLOAD_STATUS_COMPLETED = "2";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_GSTIN_UIN_OF_RECIPIENT = "gstin_uin_of_recipient";
    public static final String COLUMN_TAXPAYER_GSTIN = "gstin_taxpayer";
    public static final String COLUMN_TAXPAYER_PAN = "pan_taxpayer";
    public static final String COLUMN_EWAY_BILL_NO = "eway_bill_no";
    public static final String COLUMN_EWAY_BILL_DATE = "eway_bill_date";
    public static final String COLUMN_EWAY_BILL_VALID = "eway_bill_valid";
    public static final String COLUMN_GSTIN_OF_SUPPLIER = "gstin_of_supplier";
    public static final String COLUMN_PURCHASE_ORDER_NO = "purchase_order_no";
    public static final String COLUMN_PURCHASE_ORDER_DATE = "purchase_order_date";
    public static final String COLUMN_DOC_TYPE = "doc_type";
    public static final String COLUMN_INWARD_NO = "inward_no";
    public static final String COLUMN_INWARD_DATE = "inward_date";
    public static final String COLUMN_GSTIN_UIN_OF_SUPPLIER = "gstin_of_supplier";
    public static final String COLUMN_GSTIN_VENDOR = "gstin_vendor";
    public static final String COLUMN_VENDOR_PAN = "pan_vendor";
    public static final String COLUMN_HSN_CODE = "hsn_code";
    public static final String COLUMN_TOTAL_INVOICE_AMOUNT = "total_invoice_amt";
    public static final String COLUMN_IRN = "irn";
    public static final String COLUMN_IRN_DATE = "irn_date";
    public static final String COLUMN_UDF_1 = "udf_1";
    public static final String COLUMN_UDF_2 = "udf_2";
    public static final String COLUMN_UDF_3 = "udf_3";
    public static final String COLUMN_UDF_4 = "udf_4";
    public static final String COLUMN_UDF_5 = "udf_5";
    public static final String COLUMN_UDF_6 = "udf_6";
    public static final String COLUMN_UDF_7 = "udf_7";
    public static final String COLUMN_UDF_8 = "udf_8";
    public static final String COLUMN_UDF_9 = "udf_9";
    public static final String COLUMN_UDF_10 = "udf_10";
    public static final String COLUMN_UDF_11 = "udf_11";
    public static final String COLUMN_UDF_12 = "udf_12";
    public static final String COLUMN_UDF_13 = "udf_13";
    public static final String COLUMN_UDF_14 = "udf_14";
    public static final String COLUMN_UDF_15 = "udf_15";
    public static final String COLUMN_UDF_16 = "udf_16";
    public static final String COLUMN_UDF_17 = "udf_17";
    public static final String COLUMN_UDF_18 = "udf_18";
    public static final String COLUMN_UDF_19 = "udf_19";
    public static final String COLUMN_UDF_20 = "udf_20";
    public static final String COLUMN_ROW_VERSION = "row_version";
    public static final String COLUMN_ERROR_CODE = "Error_Code_List";
    public static final String COLUMN_BATCH_NO = "batchNo";
    public static final String COLUMN_STATUS = "status";
    public static final int E_WAY_BILL_TEMPLATE_COLUMN_COUNT = 28;
    public static final int E_WAY_BILL_TEMPLATE_MANDATORY_COLUMN_COUNT = 5;
    public static final String GSTN_CODE_POINT_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final String ALPHA_NUMERIC_STRING = "[^0-9A-Za-z ]";
    public static final String DECIMAL_FORMAT = ".##";
    public static final String ERROR_DOT_CSV = "_error.csv";
    public static final String SUCCESS_DOT_CSV = "_success.csv";
    public static final String BASE_DOT = "_base.";
    public static final String SUCCESS_TRNS_TABLE = "invoice_eway_bill_details";
    public static final String FAILURE_TRNS_TABLE = "invoice_upload_err_log";
    public static final String THREAD_COUNT = "5";
    public static final String INVOICE_SCAN_URL = "invoice_qr_service_url";
    public static final String EWB_SCAN_URL = "ewb_qr_service_url";
    public static final String RESULT = "result";
    public static final String GSTN_CODEPOINT_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final String DOCREGEX = "^([^,]{1,})$";
    public static final String VALID = "valid";
    public static final String ERROR_CODE_LIST = "Error_Code_List";
    public static final String ERROR_DESCRIPTION = "Error_Description";
    public static final String INVOICE_EWAY_BILL_DETAILS = "invoice_eway_bill_details";
    public static final String VENDOR_INVOICE_EWAY_BILL_DETAILS = "vendor_invoice_eway_bill_details";
    public static final String E_WAY_TEMPLATE_FAILURE = "ewaybill_upload_err_log";
    public static final String VENDOR_EWAYBILL_UPLOAD_ERR_LOG = "vendor_ewaybill_upload_err_log";
    public static final String VENDOR_INVOICE_UPLOAD_ERR_LOG = "vendor_invoice_upload_err_log";

    public static final String ROWCOUNT = "RowCount";
    public static final String DOTSEPARATOR = ".";
    public static final String DATA_ERROR = "data_error";
    public static final String BATCHNO = "batchNO";
    public static final String ID = "id";
    public static final String ROWVERSION = "rowVersion";
    public static final String COMMASEPERATOR = ",";
    public static final String PIPESEPERATOR = "|";
    public static final String FILEFORMATNOTALLOWED = "Invalid file type";
    public static final String FILEUPLOADEDSUCCESSFUL = "File Uploaded successfully";
    public static final String EMPTYFILENOTALLOWED = "Empty file not allowed.";
    public static final String SPACE = "";
    public static final String PYTHON = "python";
    public static final String USERDIR = "user.dir";
    public static final String PYTHONSCRIPTANDQRCODESCAN = "\\pythonScripts\\qrcodescan.py";
    public static final String BACKWARDSLASH = "\"";
    public static final String SINGLEQUOTE = "'";
    public static final String QRDETAILS = "qrdetails";
    public static final String PAGE = "page";
    public static final String QR_PAGE_NUMBER = "Page Number";
    public static final String DATA = "Data";
    public static final String BUYERGSTIN = "BuyerGstin";
    public static final String SELLERGSTIN = "SellerGstin";
    public static final String DOCTYP = "DocTyp";
    public static final String DOCNO = "DocNo";
    public static final String DOCDT = "DocDt";
    public static final String TOTINVVAL = "TotInvVal";
    public static final String MAINHSNCODE = "MainHsnCode";
    public static final String ITEMCOUNT = "ItemCnt";
    public static final String ITEMCNT = "item_count";
    public static final String IRN = "Irn";
    public static final String IRNDT = "IrnDt";
    public static final String BLANK = "";
    public static final String VENDORJOURNYINVOICEINTEGRATION = "Vendor journey Invoice Integration Upload";
    public static final String INVOICEINTEGRATION = "Invoice Integration Upload";
    public static final String INVOICEINTEGRATIONGRIDDATA = "Invoice Integration Grid Data";
    public static final String UNEXPECTEDERROR = "Unexpected error";
    public static final String ERRORCODE = "ErrorCode";
    public static final String SHORTDESCRIPTION = "ShortDescription";
    public static final String TAXPAYER_PAN = "taxpayer_pan";
    public static final String CREATED_AT = "created_at";
    public static final String CREATED_BY = "created_by";
    public static final String TEMPLATE_TYPE = "template_type";
    public static final String FILE_NAME = "file_name";
    public static final String FILE_TYPE = "file_type";
    public static final String TOTAL_COUNT = "total_count";
    public static final String SUCCESS_COUNT = "success_count";
    public static final String ERROR_COUNT = "error_count";
    public static final String PLD_UPLOAD_STATUS = "pld_upload_status";
    public static final String BASE_FILE_LOCATION = "base_file_location";
    public static final String ERROR_FILE_LOCATION = "error_file_location";
    public static final String BATCH_NO = "batch_no";
    public static final String BATCH_NO_HEADING = "Batch Number";
    public static final String BASE = "base";
    public static final String ERROR = "error";
    public static final String COLON = " : ";
    public static final String LINERETURNTAB = "[\n\r\t]";
    public static final String DD_MM = "dd_MM";
    public static final String UNDERSCORE = "_";

    public static final String PROCESSINGFILEEXCEPTIONLOG = "Error generated while uploading templates for batch no:";
    public static final String MESSAGEEXCEPTIONFORBATCHNO = "Error occured in operation for batch no. ";
    public static final String PDFEXCEPTIONMESSAGE = null;
    public static final String UPLOAD_INVOICES_STATUS_INVALIDTEMPLATE = "84";
    public static final String NOTCONTAINPROPERDATA = "Not contain proper data.";
    public static final String FILETYPENOTCORRECT = "Please choose valid file type.";
    public static final int ONE = 1;
    public static final String COLUMN_BILL_VALID_DATE = "bill_valid_date";
    public static final String INVALIDTEMPLATETYPE = "Template Invalid";
    public static final String PAN = "0";
    public static final String GSTIN = "1";
    public static final String FPYEAR = "0";
    public static final String FPMONTH = "1";
    public static final String PLD_TEMPLATE_TYPE = "pld_template_type";
    public static final String FILEUPLOADEPROGRESS = "File upload is in Progress , View Log for more ";
    public static final String UPLOADSOURCE = "99";
    public static final String FILLING_PERIOD = "filling_period";
    public static final String FP = "fp";
    public static final String TAXPAYER_GSTIN = "taxpayer_gstin";
    public static final String NOT = "not";
    public static final String YES = "yes";
    public static final String YEARMONTH = "yyyy-MM";
    public static final String YEAR_ID = "year_id";
    public static final String PAN_NUMBER = "pan";
    public static final String VENDOR_PAN = "vendor_pan";
    public static final Object ISCUSTOMETEMPLATE = "1";
    public static final Object ISDEFAULTTEMPLATE = "0";
    public static final char DELIMITER = ',';
    public static final String VALID_STATUS = "1";
    public static final String NON_VALID_LIST = "0";
    public static final String UNSERSCORE_BASE = "_base";
    public static final String JSON = "json";
    public static final String ERP = "ERP_";

    public static final String ACCESS_CONTROL_EXPOSE_HEADERS = "Access-Control-Expose-Headers";

    public static final String HEADERS_FILENAME = "fileName";
    public static final String FILE = "file";
    public static final String HEADERS = "headers";

    public static final String COMPANY_GSTIN = "Company Gstin";
    public static final String CUSTOMER_GSTIN = "Customer Gstin";

    public static final String GSTIN_UIN_OF_RECIPIENT = "Taxpayer Gstin";
    public static final String GSTIN_OF_SUPPLIER = "Vendor Gstin";
    public static final String TITLE = "title";

    public static final String IRN_DATE = "Irn Date";
    public static final String DOC_DATE = "Doc Date";
    public static final String TOTAL_INVOICE_AMT = "Total Invoice Amount";
    public static final String DOC_TYPE = "Doc Type";
    public static final String NO_OF_LINE_ITEM = "Number of Line Item";
    public static final String HSN_CODE = "HSN Code";

    public static final String E_WAY_BILL_NO = "E Way Bill Number";
    public static final String E_WAY_BILL_DATE = "E Way Bill Date";
    public static final String BILL_VALID_DATE = "Bill Valid Date";
    public static final String GENERATED_ON = "Generated On";
    public static final String EWB_DETAILS_FETCH_STATUS = "is_ewb_details_fetched";
    public static final String EWB_DETAILS_FETCHED_COUNT = "ewb_fetch_retry_count";
    public static final String EWB_DETAILS_FETCHED_AT = "ewb_details_fetched_at";
    public static final String GENERATED_BY = "Generated By";
    public static final String PO_NO = "PO Number";
    public static final String PO_DATE = "Po Date";
    public static final String GRN_NO = "GRN Number";
    public static final String GRN_DATE = "GRN Date";
    public static final String TAXABLE_AMOUNT = "Taxable Amount";
    public static final String POS = "POS";
    public static final String IGST_AMOUNT = "IGST Amount";
    public static final String CGST_AMOUNT = "CGST Amount";
    public static final String SGST_AMOUNT = "SGST Amount";
    public static final String CESS_AMOUNT = "CESS Amount";
    public static final String INV_VALUE = "INV Value";
    public static final String INVOICE_NO = "Invoice Number";
    public static final String INVOICE_DATE = "Invoice Date";
    public static final String IS_SYNC = "Is Sync";
    public static final String DEFAULTSYNCSTATUS = "Default Sync Status";
    public static final String FORCESYNCSTATUS = "Force Sync Status";
    public static final String STATUS = "E-Way Bill Status";
    public static final String INVOICE_TYPE = "Invoice Type";
    public static final String VENDOR_NAME = "Vendor Name";
    public static final String FILE_NAME_HEADER = "File Name";
    public static final String EXTRACTION = "Extraction";
    public static final String COMPLIANCE = "Compliance";

    public static final String ISCUSTOMETEMPLATEORNOT = "is_custom_template";

    public static final String EWAYBILL_NO = "EwbNo";
    public static final String EWB_BARCODE = "BARCODE";
    public static final String EWAYBILL_DATE = "EwbDt";
    public static final String GEN_BY = "GenBy";

    public static final int GET_GSTR2A_PLD_CODE = 123;
    public static final int GET_GSTR2B_PLD_CODE = 124;

    public static final int GET_EWAYBILL_PLD_CODE = 125;
    public static final String ZEROVALUE = "0";
    public static final String BRACKET = ")";

    public static final Integer VALIDCONSTANTS = 1;
    public static final int ZERO = 0;
    public static final String UTF8_BOM = "\uFEFF";
    public static final String TEMPFILE = "tempfile";
    public static final int SMPICKMSTPICKID = 8;
    public static final String TWODECIMALREGEX = "^\\s*(?=.*\\d)\\d*(?:\\.\\d{1,2})?\\s*$";
    public static final String TWODECIMALHSNCHECKBLANK = "^\\s*(?=.*\\d)\\d*(?:\\.\\d{1,2})?\\s*$";
    public static final int RANDOMNUM = 5;
    public static final String AES_ECB_PKC_PADDING = "AES/ECB/PKCS5Padding";
    public static final String AES = "AES";
    public static final String RSA = "RSA";
    public static final String DATE_FORMAT_E_MMM_DD_HH_MM_SS_ZONE_YEAR = "E MMM dd HH:mm:ss Z yyyy";
    public static final String DATE_FORMAT_YYYY_MM_DD_HH_MM_SS = "YYYY-MM-dd hh:mm:ss";
    public static final String ACTION_TOKEN = "ACCESSTOKEN";
    public static final int GET_EWAYBILL_OTHER_PARTY_PLD_CODE = 126;
    public static final int GET_EWAYBILL_BY_DATE_PLD_CODE = 297;
    public static final String BDO_EWB_AUTH = "bdo_ewb_auth";
    public static final int TAB_MINUS_VALUE = 1;

    public static final String EWAY_SAMPLE_GSTIN = "05AAACC2870R1ZD";

    public static final String SANDBOX_KEY_FILENAME = "EWB_NIC_CERT.key";
    public static final long INVITETRACKINMODULEID = 165;
    public static final long WORKFLOWTYPEIDREJECT = 160;
    public static final long WORKFLOWTYPESUBMITTED = 159;

    public static final int VENDOR_INVOICE_PICK_KEY = 65;

    public static final String PDF_INVOICE_UPLOAD_FAILED_MESSAGE = "Invalid qr /No qr scanned";
    public static final String QR_DETECTED_NOT_READEBALE = "QR detected but not Readable ";
    public static final int VENDORUPLOADMSTID = 4;

    public static final String EWAYBILLFILEUPLOADED = "Validation Completed Successfully - ";
    public static final String INVOICEFILEUPLOADED = "Validation Completed Successfully - ";
    public static final String E_WAY_BILL_FILE_IN_PROGRESS = "Validation Initiated - ";
    public static final String INVOICE_FILE_IN_PROGRESS = "Validation Initiated - ";
    public static final String E_WAY_BILL_FILE_UPLOAD_ERROR = "Validation Error -";
    public static final String INVOICE_FILE_UPLOAD_ERROR = "Validation Error -";
    public static final String INVALID_TEMPLATE = "Invalid Template";
    public static final String FAILED = " Failed -";

    public static final String GET_EWAYBILL_BY_DATE_INPROGRESS = "GET E-Way Bill By Date Initiated for GSTIN - ";
    public static final String GET_EWAYBILL_BY_DATE_FAILED = "GET E-Way Bill By Date Failed for GSTIN - ";
    public static final String GET_EWAYBILL_BY_DATE_SUCCESS = "GET E-Way Bill By Date Successfully for GSTIN - ";
    public static final String GET_EWAYBILL_BY_OTHER_PARTY_INPROGRESS = "GET E-Way Bill By Other Party Initiated for GSTIN - ";
    public static final String GET_EWAYBILL_BY_OTHER_PARTY_FAILED = "GET E-Way Bill By Other Party Failed for GSTIN - ";
    public static final String GET_EWAYBILL_BY_OTHER_PARTY_SUCCESS = "GET E-Way Bill By Other Party Successfully for GSTIN - ";

    public static final int VENDOR_JOURNEY_PICK_KEY = 165;
    public static final String NOTIFICATION_SUCCESS = "220";
    public static final String NOTIFICATION_ERROR = "221";
    public static final String NOTIFICATION_FAILED = "387";
    public static final String NOTIFICATION_INITIATED = "340";
    public static final String NOTIFICATION_IN_PROGRESS = "222";
    public static final String NOTIFICATION_INFORMATION = "223";
    public static final String REMARKS = "remarks";
    public static final String INVALID_AUTH_TOKEN = "Invalid auth token";
    public static final int MODULEIDINVOICEUPLOAD = 65;
    public static final String HEADERDATA = "headerData";
    public static final String SFTPUPLOADSOURCE = "SFTP";
    public static final String SAPUPLOADSOURCE = "SAP";
    public static final String WEBUPLOADSOURCE = "Manual";
    public static final String SUCCESS = "SUCCESS";
    public static final Object PENDING = "PENDING";
    public static final String UPLOADSOURCESFTPORWEB = "upload_source";
    public static final String PARENTBATCHNO = "parent_batch_no";
    public static final String ISQRSCANNED = "is_qr_scan";
    public static final long INVOICE_WF_SUBMIT_ID = 65;
    public static final String COLUMN_SCREEN_NAME = "column_screen_name";
    public static final String ADVANCE_SEARCH_COLUMN_NAME = "advance_search_column_name";
    public static final String HEADERCELLSTYLE3 = "headerCellStyle3";
    public static final String HEADERCELLSTYLE2 = "headerCellStyle2";
    public static final String HEADERCELLSTYLE1 = "headerCellStyle1";
    public static final String VENDOR_INVOICE_DETAILS = "Vendor_Invoice_Details";
    public static final String INVOICE_DETAILS = "Invoice_Details";
    public static final String VENDOR_INVOICE_DETAILS_HEADING = "Vendor Invoice Details";
    public static final String INVOICE_DETAILS_HEADING = "Invoice Details";
    public static final String DOT_XLSX = ".xlsx";
    public static final int EWB_GET_STATUS_FAIL = 3;
    public static final int EWB_GET_STATUS_SUCCESS = 2;
    public static final int EWB_GET_STATUS_INPROGRESS = 1;
    public static final String TAXPAYER_GSTIN_NOT_MATCHED = "Taxpayer GSTIN didn't matched";
    public static final String VENDOR_OCR_SCREEN_NAME = "vendor-ocr-tab";
    public static final String TAXPAYER_OCR_SCREEN_NAME = "taxpayer-ocr-tab";
    public static final String ENCRYPTION_APP_KEY = "encrypt-app-key";
    public static final String KEY_NAME = "KeyNAME";
    public static final String KEY_VALUE = "KeyVALUE";

    public static final String OCR_PULL_URL = "idp_pull_url";
    public static final String OCR_PUSH_URL = "idp_push_url";
    public static final String OCR_API_KEY = "idp_api_key";
    public static final String URP_SCREEN_NAME = "taxpayer-ocr-urp-tab";
	public static final String EMAIL = "Email";

	public static final String BASE64ERRORMESSAGE = "Error while inserting Data to Database in inserting Json request body in Database";
	public static final String BASE64FILECRETIONERRORMESSAGE = "Exception in in reading or in Conversion of base64 file ";

	public static final String EXPIRED = "Expired";
	public static final String DISCARDED = "Discarded";

}
