package com.bdo.bvms.ocr.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OcrComplianceErrorDto {
	
	String errorCode;
	Integer fileId;
    Integer ocrMstId;
    Integer resolveStatus;
    Integer pldErrorType;
    Integer lineNo;
    String errorDesc;
    Integer riskCategory;

}
