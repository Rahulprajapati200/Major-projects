package com.bdo.bvms.common.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.common.repository.ISystemParameterRepository;
import com.bdo.bvms.common.sql.CommonSql;
import com.bdo.bvms.invoices.ocr.model.SystemParameter;

@Repository
public class SystemParameterRepositoryImpl implements ISystemParameterRepository{

    @Autowired
    private JdbcTemplate jdbcTemplateMst;

    @Override
    public SystemParameter searchSystemParameter(SystemParameter systemParameter) {
        return jdbcTemplateMst.queryForObject(CommonSql.GET_SYSTEM_PARAMETER, new RowMapper<SystemParameter>() {

            public SystemParameter mapRow(ResultSet rs, int rowNum) throws SQLException {
                return SystemParameter.builder()
                                .keyName(rs.getObject("KeyNAME") == null ? null : rs.getString("KeyNAME"))
                                .keyValue(rs.getObject("KeyVALUE") == null ? null : rs.getString("KeyVALUE")).build();
            }
        }, systemParameter.getKeyName());
    }

    
}
