package com.bdo.bvms.invoices.ocr.dao;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.bdo.bvms.invoices.dto.BaseReqDTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class OcrInvoiceReviewRequestDTO extends BaseReqDTO {

    @NotNull(message = "{fileId.notNull}")
    Integer fileId;
    
    List<UpdateOCRInvoiceDetailsReqDTO> headerOCRInvoiceDetailsReqDTOList;
    
    List<UpdateOCRInvoiceDetailsReqDTO> lineItemsOCRInvoiceDetailsReqDTOList;
    
    @NotBlank(message = "{taxpayerGstin.notempty}")
    String taxpayerGstin;
    
    @NotNull(message = "{fileId.notNull}")
    Integer isTaxpayer;
    
    int action;
}
