package com.bdo.bvms.invoices.dto;
import java.util.Date;

public class ExceptionDetailsDTO {
	
    private Date timestamp;
    private String message;
    private String msgId;
    private String details;
    private boolean isSuccess;

    public ExceptionDetailsDTO(Date timestamp,String message, String details,boolean isSuccess,String msgId) {
        super();
        this.timestamp = timestamp;
        this.message = message;
        this.details = details;
        this.msgId = msgId;
        this.isSuccess=isSuccess;
    }

    
    public boolean isSuccess() {
		return isSuccess;
	}


	public Date getTimestamp() {
        return timestamp;
    }

    public String getMessage() {
        return message;
   }
    public String getMsgId() {
        return msgId;
   }

    public String getDetails() {
       return details;
   }
}