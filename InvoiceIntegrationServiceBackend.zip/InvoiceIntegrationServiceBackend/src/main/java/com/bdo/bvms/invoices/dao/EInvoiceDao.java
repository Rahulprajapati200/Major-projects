package com.bdo.bvms.invoices.dao;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;

import com.bdo.bvms.invoices.dto.ResponseBean;

public interface EInvoiceDao {

    ResponseBean gstInwardInvCdnInsert(String successFilePath, String errorFilePath, String successTable,
                    String errorTable) throws VendorInvoiceServerException;

}
