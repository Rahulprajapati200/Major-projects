package com.bdo.bvms.einvoice.service;

import java.util.List;
import java.util.Map;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.RejectedResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceColumnsNameResponseDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface VendorInvoiceRejectedDataListService {

    List<VendorInvoiceColumnsNameResponseDTO> getRejectedColumnNames(VendorInvoiceRequestDTO vendorInvoiceRequestDTO)
                    throws VendorInvoiceServerException;

    Map<String, Object> getRejectedDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
                    String monthList) throws VendorInvoiceServerException;

    int getRejectedTotalCount(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList, String monthList);

    List<RejectedResDTO> getRejectedDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
                    String monthList) throws VendorInvoiceServerException;

}
