package com.bdo.bvms.ewaybill.api.impl;

import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.bdo.bvms.invoices.constant.EWBErrorCodesConstants;
import com.bdo.bvms.invoices.dto.EwayBillheaderDTO;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class EWayBillDetailsApi {

    public static final String CLASSNAME = "EWayBillDetailsApi";

    public EwayBillheaderDTO getEwayBillDetailsAPI(String appKey, String taxPayerGSTN, String clientId,
                    String clientSecretenCrypted, String eWayBillApi, RestTemplate restTemplate,
                    String bdoASPAuthenticatedInfo, String authtoken, String sek) {
        String methodName = "getEwayBillDetailsAPI";

        log.info("className: " + CLASSNAME + " methodName: " + methodName + "completed");

        EwayBillheaderDTO ewayBillheaderDTO = null;
        HttpHeaders eWayBillAuthHeader = new HttpHeaders();

        eWayBillAuthHeader.set("ClientId", clientId);
        eWayBillAuthHeader.set("client-secret", clientSecretenCrypted);
        eWayBillAuthHeader.set("bdo_auth_token", bdoASPAuthenticatedInfo);
        eWayBillAuthHeader.set("Gstin", taxPayerGSTN);
        eWayBillAuthHeader.set("authtoken", authtoken);

        HttpEntity<Void> requestEntity = new HttpEntity<>(eWayBillAuthHeader);

        ResponseEntity<String> responseEntity = restTemplate.exchange(eWayBillApi, HttpMethod.GET, requestEntity,
                        String.class);

        JSONObject response = new JSONObject(responseEntity.getBody());

        if ("0".equals(response.get("status"))) {
            ewayBillheaderDTO = new EwayBillheaderDTO();

            String errorDesc = EWBErrorCodesConstants.getEWBErrroDescription(response.get("error").toString());
            ewayBillheaderDTO.setError(errorDesc);
            ewayBillheaderDTO.setApiResponse(response.toString());
        } else {

            String decryptSEK = Encryption.decryptSEK(appKey, sek);

            String finalData = null;
            try {
                finalData = Encryption.decryptGetApiResponseData(response.toString(), decryptSEK);
                Gson gson = new Gson();
                JsonParser parser = new JsonParser();
                JsonObject object = (JsonObject) parser.parse(finalData);
                ewayBillheaderDTO = gson.fromJson(object, EwayBillheaderDTO.class);
                ewayBillheaderDTO.setApiResponse(response.toString());

            } catch (Exception e) {
                log.error("Error Generated while calling API getEwayBillDetailsAPI::", e);
            }
        }

        log.info("className: " + CLASSNAME + " methodName: " + methodName + "completed");
        return ewayBillheaderDTO;
    }

}
