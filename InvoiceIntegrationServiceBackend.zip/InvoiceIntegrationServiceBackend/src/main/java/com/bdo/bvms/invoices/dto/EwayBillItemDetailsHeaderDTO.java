package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EwayBillItemDetailsHeaderDTO {

    String taxable;
    String totalCgst;
    String totalSgst;
    String totalIgst;
    String totalCess;
    String totalNonadvcess;
    String other;
    String grossTotal;

}
