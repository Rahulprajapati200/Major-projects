package com.bdo.bvms.ocr.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OcrPullLogDto {
	String ackNo;
	String batchNo;
	String ocrExtractedData;
	Integer fileId;
	String payload;
	String status;
	String errorDesc;
	String reqOn;
	String recievedOn;
}
