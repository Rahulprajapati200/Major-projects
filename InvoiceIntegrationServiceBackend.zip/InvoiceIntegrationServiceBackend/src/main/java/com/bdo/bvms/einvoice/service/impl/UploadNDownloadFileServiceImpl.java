package com.bdo.bvms.einvoice.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import java.time.LocalDateTime;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.einvoice.service.UploadNDownloadFileService;
import com.bdo.bvms.invoices.config.AzureClientProvider;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.AzureUploadDownloadException;
import com.bdo.bvms.invoices.custom.exception.InvoiceTemplateUploadException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.bvms.invoices.util.CommonUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UploadNDownloadFileServiceImpl implements UploadNDownloadFileService {

    @Autowired
    public AzureClientProvider client;

    @Autowired
    public UploadTransDao uploadDao;

    @Autowired
    CommonDao commonDao;

    @Value("${temp.folder.path}")
    String tempFolder;

    @Override
    public String uploadFileToAzureBlob(MultipartFile file, UploadRequestDTO apiRequestDTO, String batchNo,
                    AzureConnectionCredentialsDTO credentialMap) throws AzureUploadDownloadException {

        if (log.isInfoEnabled()) {
            log.info("Class:" + this.getClass().toString() + ", method :uploadFileToAzureBlob");
        }

        try {

            if (file != null && file.getSize() > 0) {

                String fileType = FilenameUtils.getExtension(file.getOriginalFilename());

                String fileName = new StringBuilder().append(batchNo).append(Constants.UNSERSCORE_BASE)
                                .append(Constants.DOTSEPARATOR).append(fileType).toString();

                try (InputStream inputStream = file.getInputStream()) {
                    client.getClient(credentialMap).blobName(fileName).buildClient().upload(inputStream,
                                    file.getSize());
                }

            }

        } catch (Exception ex) {
            // write code update TX uplaod log = Done
            log.error("Error in uploadFileToAzureBlob Method", ex);
            uploadDao.updateProcessStatus(batchNo, Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            throw new AzureUploadDownloadException("File storage service is down");
        }

        return batchNo;

    }

    @Override
    public void downloadFileFromAzureBlob(String fileName, String targetPath, AzureConnectionCredentialsDTO map,UploadReqDTO uploadReqDTO)
                    throws AzureUploadDownloadException {

        try {
            File file = new File(targetPath + System.getProperty(Constants.FILESEPERATOR) + fileName);
            if (file.exists()) {
                FileUtils.deleteQuietly(file);
            }

            client.getClient(map).blobName(fileName).buildClient()
                            .downloadToFile(targetPath + System.getProperty(Constants.FILESEPERATOR) + fileName);
        } catch (Exception ex) {
            log.info("Exception occur during Downloading file from Azure to Templ Folder", ex);
            throw new AzureUploadDownloadException("File storage service is down", ex.getCause());
        }

    }

    @Override
    public void uploadErrorFile(UploadReqDTO uploadDTO, AzureConnectionCredentialsDTO map)
                    throws InvoiceTemplateUploadException {
        String csvErrorFilePath = CommonUtils.getErrorFilePath(uploadDTO, tempFolder);
        File file = new File(csvErrorFilePath);

        try {

            try (InputStream inputStream = new FileInputStream(file)) {
                client.getClient(map).blobName(uploadDTO.getBatchNo() + Constants.ERROR_DOT_CSV).buildClient()
                                .upload(inputStream, file.length());
                log.info("error file successfully uploaded.");
            }

        } catch (Exception e) {
            log.error("Exception occur During Uploading Error File to Azure in uploadErrorFile Method", e);
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();

            String methodName1 = "uploadErrorFile";

            exceptionLogDTO.setUserId(uploadDTO.getId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
            exceptionLogDTO.setFunctionName(methodName1);
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause(Constants.NOTCONTAINPROPERDATA);
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());

            commonDao.updateExceptionLogTable(exceptionLogDTO);

            throw new InvoiceTemplateUploadException(e.getMessage(), e.getCause());
        }

    }

	@Override
	public void uploadSftpFileToAzureBlob(UploadRequestDTO uploadRequestDTO, String batchNo,
			AzureConnectionCredentialsDTO storageCredentials) throws AzureUploadDownloadException {

        if (log.isInfoEnabled()) {
            log.info("Class:" + this.getClass().toString() + ", method :uploadFileToAzureBlob");
        }

        try {

        	File file=new File(tempFolder+"/"+uploadRequestDTO.getSftpFileName());
        	
            if (file != null && file.length() > 0) {

                String fileType = FilenameUtils.getExtension(uploadRequestDTO.getSftpFileName());

                String fileName = new StringBuilder().append(batchNo).append(Constants.UNSERSCORE_BASE)
                                .append(Constants.DOTSEPARATOR).append(fileType).toString();

                try (InputStream inputStream = new FileInputStream(file)) {
                    client.getClient(storageCredentials).blobName(fileName).buildClient().upload(inputStream,
                                    file.length());
                }

            }

        } catch (Exception ex) {
            // write code update TX uplaod log = Done
            log.error("Error in uploadFileToAzureBlob Method", ex);
            uploadDao.updateProcessStatus(batchNo, Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            throw new AzureUploadDownloadException("File storage service is down");
        }

        

    
		
	}

}