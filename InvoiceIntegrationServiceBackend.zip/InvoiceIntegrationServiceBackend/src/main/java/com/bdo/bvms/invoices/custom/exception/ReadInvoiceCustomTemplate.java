package com.bdo.bvms.invoices.custom.exception;

public class ReadInvoiceCustomTemplate extends Exception{

	private static final long serialVersionUID = 1L;

	public ReadInvoiceCustomTemplate() {
		super();
	}

	public ReadInvoiceCustomTemplate(Throwable cause) {

		super(cause);

	}

	public ReadInvoiceCustomTemplate(String message, Throwable cause) {

		super(message, cause);

	}
	
	public ReadInvoiceCustomTemplate(String message) {

		super(message);

	}
}
