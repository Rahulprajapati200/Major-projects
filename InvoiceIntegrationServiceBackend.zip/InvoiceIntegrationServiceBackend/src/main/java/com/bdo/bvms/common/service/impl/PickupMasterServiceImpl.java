package com.bdo.bvms.common.service.impl;

import java.util.LinkedHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdo.bvms.common.repository.IPickupMasterRepository;
import com.bdo.bvms.common.service.IPickupMasterService;

@Service

public class PickupMasterServiceImpl implements IPickupMasterService {

	@Autowired
	private IPickupMasterRepository pickupMasterRepository;
	

	@Override
            public LinkedHashMap<String,Integer> getPickupListDetailsMapSortOrder(String pickupMasterName) {
                        return pickupMasterRepository.getPickupListDetailsMapSortOrder(pickupMasterName);

            }
	

}
