package com.bdo.bvms.common.service;

import com.bdo.bvms.invoices.ocr.dao.SearchSystemParameterResDTO;
import com.bdo.bvms.taxpayer.request.dto.SearchSystemParameterReqDTO;

public interface ISystemParameterService {

    SearchSystemParameterResDTO searchSystemParameter(SearchSystemParameterReqDTO searchSystemParameterReqDTO) ;
    
}
