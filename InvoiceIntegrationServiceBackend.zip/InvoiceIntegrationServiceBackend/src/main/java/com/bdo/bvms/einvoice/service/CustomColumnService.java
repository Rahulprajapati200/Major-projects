package com.bdo.bvms.einvoice.service;

import java.util.List;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.InvoiceGridCustomColumnDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface CustomColumnService {
//vendor_invoice_tab_processed_invoice
    List<InvoiceGridCustomColumnDTO> getCustomGridColumns(VendorInvoiceRequestDTO vendorInvoiceRequestDTO)
                    throws VendorInvoiceServerException;

}
