package com.bdo.bvms.ewaybill.api.sql;

public class Transactions {

    Transactions() {

    }

    public static final String GET_EXPIRY_DATE_BDO_AUTH = "select bdo_auth_token from ewb_bdo_auth_api_call where status=1 and expiry>NOW() order by 1 desc limit 1";

    public static final String GET_NIC_AUTH_DATA = "select id,taxpayer_gstin,bdo_auth_id,res_sek as nic_sek,res_auth_token as nic_auth_token from external_api_call_log where taxpayer_gstin = ? and is_active=1 and expiry>now()  order by 1 desc limit 1";

    public static final String GET_BDO_AUTH_ID = "select id from ewb_bdo_auth_api_call where bdo_auth_token = ? order by 1 desc limit 1";

    public static final String GET_BDO_AUTH_TOKEN = "SELECT bdo_auth_token FROM sm_eway_bill_api_tokens where taxpayer_gstin_username = ?";

    public static final String INSERT_INTO_EWAYBILL_HEADER = "INSERT INTO ewb_header (ewb_no,ewb_date,user_gstin,supply_type,doc_type,doc_no,from_gstin,to_gstin,fromAddr1,fromAddr2,fromPlace,fromPincode,fromStateCode,toTrdName,toAddr1,toAddr2,toPlace,toPincode,toStateCode,totalValue,totInvValue,cgstValue,sgstValue,igstValue,cessValue,transporterId,transporterName,status,actualDist,noValidDays,validUpto,extendedTimes,rejectStatus,vehicleType,actFromStateCode,actToStateCode,transactionType,otherValue,cessNonAdvolValue,ewb_api_call_log_id,pld_details_get_status,doc_date,return_period,doc_return_period,year_id,is_frezzed, item_get_error_description, uuid_no, po_no, po_date, grn_no, grn_date, from_trade_name,gen_mode, sub_supply_type, sub_supply_type_desc, hsn_code, hsn_desc) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
   
    public static final String INSERT_INTO_EWAYBILL_ITEM_DETAILS = "INSERT INTO eway_bill_items_details (header_id,itemNo,productId,productName,productDesc,hsnCode,quantity,qtyUnit,cgstRate,sgstRate,igstRate,cessRate,cessNonAdvol,taxableAmount) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String INSERT_INTO_EWAYBILL_VEHICLE_DETAILS = "INSERT INTO ewb_vehicle_details (ewb_id,upd_mode,vehicle_no,from_place,from_state,tripsht_no,user_gstin_transin,entered_date,trans_mode,trans_docno,group_no,trans_docdate) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String INSERT_INTO_EWAYBILL_API_CALL_LOG = "INSERT INTO ewb_api_call_log (external_api_log_id,pld_get_type,taxpayer_gstin,eway_bill_no,eway_bill_date,req_authtoken,is_success,error_description,response_body,response_count,requested_by,is_call_from_scheduler,response_received_on,api_call_status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,now(),?)";

    public static final String INSERT_INTO_EWAYBILL_HEADER_FROM_EWB_OTHER_PARTY = "INSERT INTO ewb_header (ewb_no,ewb_date,doc_no,from_gstin,to_gstin,toTrdName,totInvValue,status,rejectStatus,ewb_api_call_log_id) VALUES (?,?,?,?,?,?,?,?,?,?)";

    public static final String INSERT_INTO_INVOICE_DETAIL = "INSERT INTO invoice_detail (taxpayer_pan,taxpayer_gstin,vendor_pan,vendor_gstin,taxable_value,igst,cgst,sgst,cess,invoice_value,eway_bill_no,eway_bill_date,pld_get_type,sync_status,return_period,year_id,doc_return_period,doc_year_id,category,note_type,created_on,created_by,invoice_no,invoice_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static String getTaxpayerEntityMaster(String taxpayerGstin) {
        return "select ewb_username,ewb_password from am_entity_master where gstin=to_base64('" + taxpayerGstin + "') ";
    }

    public static final String GET_BDO_AUTH_URL = "SELECT keyValue FROM system_parameter where KeyName = 'bdoAuthURL'";

    public static final String GET_NIC_AUTH_URL = "SELECT keyValue FROM system_parameter where KeyName = 'nicAuthURL'";

    public static final String GET_EWB_API_URL = "SELECT keyValue FROM system_parameter where KeyName = 'eWayBillApiURL'";

    public static final String GET_EWB_API_OTHER_PARTY_URL = "SELECT keyValue FROM system_parameter where KeyName = 'eWayBillOfOtherPartyApiURL'";

    public static final String GET_EWB_API_BY_DATE_URL = "SELECT keyValue FROM system_parameter where KeyName = 'getEwayBillsByDate' LIMIT 1";

    public static final String GET_EWB_APP_KEY = "SELECT keyValue FROM system_parameter where KeyName = 'ewaybill_app_key'";

    public static final String GET_EWB_CLIENT_ID = "SELECT keyValue FROM system_parameter where KeyName = 'ewaybill_client_id'";

    public static final String GET_EWB_CLIENT_SECRET_ENCRYPTED = "SELECT keyValue FROM system_parameter where KeyName = 'ewaybill_clientSecretenCrypted'";

    public static final String INSERT_INTO_EWAYBILL_BDO_AUTH = "INSERT INTO EWB_BDO_AUTH_API_CALL( BDO_AUTH_TOKEN, EXPIRY, STATUS, PLAYLOAD, IS_EXCEPTION,ERROR_DESCRIPTION) VALUES (?,?,?,?,?,?)";

    public static final String INSERT_INTO_EXTERNAL_API_CALL_LOG = "INSERT INTO external_api_call_log( bdo_auth_id,api_id, req_header, req_body, res_sek, res_auth_token,is_exception,error_description,taxpayer_gstin,expiry) VALUES (?,?,?,?,?,?,?,?,?,DATE_ADD(NOW(), INTERVAL 6 HOUR))";

    public static final String UPDATE_EXTERNAL_API_CALL_LOG_SUCCESS = "update external_api_call_log set res_sek=? ,res_auth_token = ? where id = ?";
    
    public static final String UPDATE_EXTERNAL_API_CALL_LOG_FAIL = "update external_api_call_log set is_exception=? , error_description = ? where id = ?";
    
    public static final String GET_YEAR_ID_BY_FP = "SELECT year_id FROM sm_return_periods where fp = ?";

    public static final String CHECK_EWB_DETAIL_BY_EWB_NO = "SELECT COUNT(1) FROM invoice_detail where eway_bill_no = ? and (sync_status = 0 or  COALESCE(is_forced_sync,0) = 0)";

    public static final String DELETE_EWB_RECORDS_ALLREADY_EXISTS = "DELETE FROM invoice_detail where eway_bill_no = ? and (sync_status = 0 or  COALESCE(is_forced_sync,0) = 0)";

    public static final String GET_TAXPAYER_GSTIN_LIST_FROM_ENTITY_MASTER = "SELECT distinct cast(from_base64(gstin) as char) as gstin FROM am_entity_master where from_base64(gstin) is not null and ewb_password is not null and is_active=1 and deleted_at is null";
    public static final String UPDATE_BDO_KEY_INACTIVE = "update ewb_bdo_auth_api_call set  status=0  where  bdo_auth_token=?";

    public static final String UPDATE_NIC_KEY_INACTIVE = " update external_api_call_log set is_active=0 where taxpayer_gstin=? and res_sek=?";

    public static final String GET_FAILED_TAXPAYER_EWB_LIST_TO_REPROCESS = "SELECT distinct taxpayer_gstin,eway_bill_date as ewaybillDate FROM ewb_api_call_log \r\n"
                    + "where pld_get_type=125 and is_success=0";

    public static final String GET_TAXPAYER_GSTIN_LIST_FROM_INVOICE_EWAYBILL_DETAILS = new StringBuilder(
                    "SELECT distinct id,gstin_uin_of_recipient as taxpayerGstin,e_way_bill_no  as ewaybillNo,batch_no\n")
                                    .append("FROM invoice_eway_bill_details where COALESCE(is_ewb_details_fetched,0)=0 \n")
                                    .append("and COALESCE(e_way_bill_no,'') <>'' and gstin_uin_of_recipient<>'' and COALESCE(ewb_fetch_retry_count,0) < 10\n")
                                    .toString();

    public static final String GET_TAXPAYER_GSTIN_LIST = "select distinct from_base64(gstin) from am_entity_master where from_base64(pan)=? and is_active=1 and draft_status=1 and entity_status=1";

    public static final String UPDATE_FLAG_EWB_DETAILS_FETCHED = "update invoice_eway_bill_details set is_ewb_details_fetched=1,ewb_details_fetched_at = now(),doc_type = ?, inward_no = ?,inward_date = ?,item_count = ?,total_invoice_amt = ?,bill_valid_date = ?, ewb_gen_on = ? , ewb_gen_by = ?, e_way_bill_date = ? where e_way_bill_no = ?";

    public static final String UPDATE_EWB_RE_FETCH_COUNT = "UPDATE invoice_eway_bill_details set ewb_fetch_retry_count = (COALESCE(ewb_fetch_retry_count,0)+1) where id = ?";
    
    public static final String UPDATE_EWB_API_CALL_LOG_STATUS = "UPDATE ewb_api_call_log set is_success = ? , error_description = ? , api_call_status = ?, response_count = ? where id = ?";

    public static final String CHECK_EWB_HEADER_DETAIL_BY_EWB_NO = "SELECT id FROM ewb_header where ewb_no = ? ";

    public static String insertEwbVehicalDetailsToArchived(String idString) {
        return new StringBuilder(
                        "INSERT INTO ewb_vehicle_details_archived (ewb_vehicle_details_id,ewb_id,upd_mode,vehicle_no,from_place,from_state,tripsht_no,user_gstin_transin,entered_date,trans_mode,trans_docno,group_no,trans_docdate)\r\n")
                                        .append(" SELECT id,ewb_id,upd_mode,vehicle_no,from_place,from_state,tripsht_no,user_gstin_transin,entered_date,trans_mode,trans_docno,group_no,trans_docdate\r\n")
                                        .append("FROM ewb_vehicle_details where ewb_id in " + idString).toString();
    }

    public static String insertEwbHeaderDetailsToArchived(String idString) {
        return new StringBuilder(
                        "INSERT INTO ewb_header_archived (ewb_header_id,ewb_api_call_log_id,ewb_no,ewb_date,user_gstin,supply_type,doc_type,doc_no,doc_date,year_id,return_period,doc_return_period,from_gstin,to_gstin,fromAddr1,fromAddr2,fromPlace,fromPincode,fromStateCode,toTrdName,toAddr1,toAddr2,toPlace,toPincode,toStateCode,totalValue,totInvValue,cgstValue,sgstValue,igstValue,\r\n")
                                        .append(" cessValue,transporterId,transporterName,status,actualDist,noValidDays,validUpto,extendedTimes,rejectStatus,vehicleType,\n")
                                        .append(" actFromStateCode,actToStateCode,transactionType,otherValue,cessNonAdvolValue,is_frezzed,pld_details_get_status,item_get_error_description,uuid_no,po_no,po_date,grn_no,grn_date) \n")
                                        .append(" SELECT id,ewb_api_call_log_id,ewb_no,ewb_date,user_gstin,supply_type,doc_type,doc_no,doc_date,year_id,return_period,doc_return_period,from_gstin,to_gstin,fromAddr1,fromAddr2,fromPlace,fromPincode,fromStateCode,toTrdName,toAddr1,toAddr2,toPlace,toPincode,toStateCode,totalValue,totInvValue,cgstValue,sgstValue,igstValue,cessValue,\r\n")
                                        .append(" transporterId,transporterName,status,actualDist,noValidDays,validUpto,extendedTimes,rejectStatus,vehicleType,\n")
                                        .append(" actFromStateCode,actToStateCode,transactionType,otherValue,cessNonAdvolValue,is_frezzed,pld_details_get_status,item_get_error_description,uuid_no,po_no,po_date,grn_no,grn_date \n")
                                        .append(" FROM ewb_header where id in" + idString).toString();
    }

    public static String insertEwbItemDetailsToArchived(String idString) {
        return new StringBuilder(
                        "INSERT INTO eway_bill_items_details_archived (header_id,itemNo,eway_bill_items_details_id,productId,productName,productDesc,hsnCode,quantity,qtyUnit,cgstRate,sgstRate,igstRate,cessRate,cessNonAdvol,taxableAmount) \n")
                                        .append(" SELECT header_id,itemNo,id,productId,productName,productDesc,hsnCode,quantity,qtyUnit,cgstRate,sgstRate,igstRate,cessRate,cessNonAdvol,taxableAmount \n")
                                        .append(" FROM eway_bill_items_details where header_id in " + idString)
                                        .toString();
    }

    public static String insertInvoiceDetailToArchived() {
        return new StringBuilder(
                        "INSERT INTO invoice_detail_archived (invoice_detail_id,parent_id,taxpayer_pan,taxpayer_gstin,vendor_pan,vendor_gstin,invoice_no,invoice_date,taxable_value,igst,cgst,sgst,cess,invoice_value,qr_code_valid,eway_bill_no,eway_bill_date,pld_template_type, \n")
                                        .append(" last_synced_on,last_synced_by,pld_get_type,sync_status,return_period,year_id,doc_type,doc_return_period,doc_year_id,category,note_type,main_hsn_code,irn,irn_dt, \n")
                                        .append(" iss,pos,batch_no,is_forced_sync,force_sync_unsync_by,po_no,po_date,grn_no,grn_date,vendor_upload_ref_id,created_on,created_by) \n")
                                        .append(" SELECT id,parent_id,taxpayer_pan,taxpayer_gstin,vendor_pan,vendor_gstin,invoice_no,invoice_date,taxable_value,igst,cgst,sgst,cess,invoice_value,qr_code_valid,eway_bill_no,eway_bill_date,pld_template_type, \n")
                                        .append(" last_synced_on,last_synced_by,pld_get_type,sync_status,return_period,year_id,doc_type,doc_return_period,doc_year_id,category,note_type,main_hsn_code,irn,irn_dt, \n")
                                        .append(" iss,pos,batch_no,is_forced_sync,force_sync_unsync_by,po_no,po_date,grn_no,grn_date,vendor_upload_ref_id,now(),created_by \n")
                                        .append(" FROM invoice_detail where eway_bill_no = ?").toString();
    }

    public static String deleteEwbRecordsFromEwbHeaderAllreadyExists(String idString) {
        return "DELETE FROM ewb_header where id in " + idString;
    }

    public static String deleteEwbRecordsFromEwbItemDetailsAllreadyExists(String idString) {
        return "DELETE FROM eway_bill_items_details where header_id in " + idString;
    }
    
    public static String deleteEwbRecordsFromVehicalDetailsAllreadyExists(String idString) {
        return "DELETE FROM ewb_vehicle_details where ewb_id in " + idString;
    }
    
    public static final String INSERT_INTO_SCHEDULAR_LOG = "INSERT INTO scheduler_log(scheduler_call_for,gstin,other_party_date,started_on,completed_on) VALUES (?,?,?,NOW(),NOW())";
    
    public static final String UPDATE_SCHEDULAR_LOG = "UPDATE scheduler_log SET completed_on = NOW(),is_successful = ?,error_remarks = ? where id = ?";
    
    public static final String GET_USERID_BY_GSTIN_ROLE_MAPPING = "SELECT user_id FROM am_user_role_mapping as urm WHERE (gstin = ? AND `role_type_id` NOT IN ('4' , '9') OR (`entity_id` in (SELECT parent_group_id  FROM am_entity_master where gstin = to_base64(?)) AND `gstin` = '999999')) AND urm.deleted_at IS NULL";
    
    public static final String UPDATE_EWB_STATUS_TO_EXPIRED = "UPDATE ewb_header SET status = ? WHERE COALESCE(validUpto,'') <> '' AND DATE_FORMAT(STR_TO_DATE(validUpto, '%d/%m/%Y %h:%i:%s %p'), '%d-%m-%Y') = ?";
    
    public static final String UPDATE_EWB_STATUS_TO_DISCARDED = "UPDATE ewb_header SET status = ? WHERE COALESCE(validUpto,'') = '' AND ewb_date = ?";

}