package com.bdo.bvms.invoices.taxpayer.sql;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.invoices.dto.InvoiceDetailsReqDTO;

public class TransactionSQL {

    TransactionSQL() {

    }

    public static final String GET_ALL_DATA_OF_FAILURE_RECORDS = "select * from ewaybill_upload_err_log where batch_no =?";
    public static final String GET_PERTICULAR_DATA_OF_SUCCESS_RECORDS = "select gstin_uin_of_recipient,doc_type,inward_no,inward_date,gstin_of_supplier,hsn_code,total_invoice_amt,purchase_order_no,purchase_order_date,"
                    + "irn,filing_period,irn_date,udf_1,udf_2,udf_3,udf_4,udf_5,udf_6,udf_7,udf_8,udf_9,udf_10,udf_11,udf_12,udf_13,udf_14,udf_15,udf_16,udf_17,udf_18,udf_19,udf_20,row_version,status,REPLACE(REPLACE(error_code, CHAR(13), ''), CHAR(10), '') as error_code,qr_page_no from invoice_upload_err_log where batch_no=?";
    public static final String INSERT_FILE_SQL = "LOAD DATA LOCAL INFILE ? INTO TABLE table_name CHARACTER SET latin1 FIELDS TERMINATED BY \',\' ENCLOSED BY \'"
                    + '"' + "\' ESCAPED BY '' LINES TERMINATED BY \'\n\' IGNORE 1 LINES;";

    public static final String INSERT_EXCEPTION_LOG = "insert into exception_log(screen_name,function_name,error_message,error_cause,line_no,user_id,created_at,requested_at,requested_by) VALUES (?,?,?,?,?,?,?,?,?)";

    public static StringBuilder getUploadHistory(int entityId, String mstDBname, int moduleId) {

        return new StringBuilder(
                        "  SELECT taxpayer_pan, fp ,remarks, ul.created_at , concat(from_base64(first_name) ,' ',from_base64(last_name)) as 'created_by',"
                                        + " ld.name as 'template_type', ld1.name as 'pld_upload_status',ul.taxpayer_gstin , ul.file_name , file_type , total_count , success_count ,"
                                        + " error_count ,COALESCE(is_qr_scanned,0) AS is_qr_scan, "
                                        + "  base_file_location,parent_batch_no,upload_source,fp,is_custom_template, error_file_location , ul.batch_no,oh.pld_ocr_status from upload_log  ul "
                                        + "left join " + mstDBname + ".am_user_master um  on um.user_id=ul.created_by "
                                        + "left JOIN " + mstDBname
                                        + ".sm_pickup_list_details ld on ld.id=ul.pld_template_type  and ld.sm_pick_mst_id=8 "
                                        + " left JOIN " + mstDBname
                                        + ".sm_pickup_list_details ld1 on ld1.code=ul.pld_upload_status and ld1.sm_pick_mst_id=23 "
                                        + "left JOIN " + mstDBname
                                        + ".sm_pickup_list_details ld2 on ld2.code=ul.pld_upload_source and ld2.sm_pick_mst_id=13 "
                                        + " left JOIN ocr_header oh ON ul.batch_no = oh.batch_no AND oh.is_taxpayer_uploaded = 1 "
                                        + "where  pld_upload_source=" + moduleId + " and ul.entity_id=" + entityId);

    }

    public static String getSyncPendingList(Integer pageRecords, Integer pageCount, String mstDatabseName,
                    String gstinNewList, String monthList) {
        return " SELECT gstin_uin_of_recipient, gstin_of_supplier, inward_no, inward_date, total_invoice_amt, bill_valid_date,e_way_bill_no,e_way_bill_date,invoice_eway_bill_details.status,"
                        + "inward_no,inward_date,  purchase_order_no,row_version,sm_pickup_list_details.name, company_legal_name,company_trade_name "
                        + "FROM invoice_eway_bill_details  join taxpayer_vendors on     taxpayer_vendors.gstin_taxpayer=invoice_eway_bill_details.gstin_uin_of_recipient "
                        + "  and taxpayer_vendors.gstin_vendor=invoice_eway_bill_details.gstin_of_supplier " + " join "
                        + mstDatabseName + ".sm_pickup_list_details on " + mstDatabseName
                        + ".sm_pickup_list_details.code= invoice_eway_bill_details.template_type "
                        + " and sm_pick_mst_id=8  where gstin_uin_of_recipient in " + gstinNewList + " "
                        + "and TRIM('\\r' FROM filling_period) in " + monthList + " LIMIT " + " " + pageRecords + " "
                        + "offset" + " " + (pageCount - 1) * pageRecords;

    }

    public static String getSyncTotalCount(String mstDatabseName, String gstinNewList, String monthList) {
        return " SELECT Count(1) "
                        + "FROM invoice_eway_bill_details  join taxpayer_vendors on     taxpayer_vendors.gstin_taxpayer=invoice_eway_bill_details.gstin_uin_of_recipient "
                        + "  and taxpayer_vendors.gstin_vendor=invoice_eway_bill_details.gstin_of_supplier " + " join "
                        + mstDatabseName + ".sm_pickup_list_details on " + mstDatabseName
                        + ".sm_pickup_list_details.code= invoice_eway_bill_details.template_type "
                        + " and sm_pick_mst_id=8  where gstin_uin_of_recipient in " + gstinNewList + " "
                        + "and TRIM('\\r' FROM filling_period) in " + monthList;

    }

    public static final String SEARCH_GSTR2A_SQL = new StringBuilder(
                    "SELECT taxpayer_gstin , vendor_gstin, 'GET GSTR2A' as title,taxable_value as taxable_amount, pos as placeSupply,\r\n"
                                    + " igst as 'igst_amount', cgst as 'cgst_amount',sgst as 'sgst_amount',cess as 'cess_amount',invoice_value,\r\n"
                                    + " invoice_no,invoice_date, sync_status as 'is_sync', sync_status as defaultSyncStatus, COALESCE(is_forced_sync,0) as forcesyncstatus FROM invoice_detail\n")
                                                    .append("WHERE taxpayer_gstin = ? AND vendor_gstin = ? AND invoice_no = ? AND invoice_date = ? \n")
                                                    .append(" and pld_get_type = ?").toString();

    public static final String SEARCH_GSTR2B_SQL = new StringBuilder(
                    "SELECT taxpayer_gstin , vendor_gstin, 'GET GSTR2B' as title,taxable_value as taxable_amount, pos as placeSupply,\r\n"
                                    + " igst as 'igst_amount', cgst as 'cgst_amount',sgst as 'sgst_amount',cess as 'cess_amount',invoice_value ,\r\n"
                                    + " invoice_no,invoice_date, sync_status as 'is_sync', sync_status as defaultSyncStatus, COALESCE(is_forced_sync,0) as forcesyncstatus FROM invoice_detail\n")
                                                    .append("WHERE taxpayer_gstin = ? AND vendor_gstin = ? AND invoice_no = ? AND invoice_date = ? \n")
                                                    .append(" and pld_get_type = ?").toString();

    public static final String SEARCH_GETEWAYBILL_SQL = new StringBuilder(
                    "SELECT taxpayer_gstin , vendor_gstin, 'GET EWAYBILL' as title,taxable_value, pos as placeSupply,\r\n"
                                    + " eway_bill_no as ewbNo,eway_bill_date as ewbDate,igst as 'igst_amount', cgst as 'cgst_amount',sgst as 'sgst_amount',cess as 'cess_amount',invoice_value as 'sum_gross_total_amount',\r\n"
                                    + " invoice_no,invoice_date, sync_status as 'is_sync', sync_status as defaultSyncStatus, COALESCE(is_forced_sync,0) as forcesyncstatus FROM invoice_detail\n")
                                                    .append("WHERE taxpayer_gstin = ? AND vendor_gstin = ? AND invoice_no = ? AND invoice_date = ? \n")
                                                    .append(" and pld_get_type = ?").toString();

    public static final String SEARCH_EINVOICE_DETAILS_SQL = new StringBuilder(
                    "select ih.taxpayer_gstin as taxpayerGstin, ih.vendor_gstin as vendorGstin,tv.company_legal_name,tv.company_trade_name, \r\n"
                                    + " 'e-Invoice' as title, ih.irn as irnNo, ih.irn_date, ih.invoice_date as doc_date, ih.total_invoice_amt as totalInvoiceValue, ih.invoice_no as invoiceNo, \r\n"
                                    + " ih.invoice_date as invoiceDate,ih.doc_type, COALESCE(ih.item_count,0) as noOfLIneItem, ih.hsn_code,ih.batch_no,viiv.irn_status \r\n"
                                    + " from invoice_header ih \r\n"
                                    + " LEFT JOIN taxpayer_vendors as tv ON ih.taxpayer_gstin = tv.gstin_taxpayer AND ih.vendor_gstin = tv.gstin_vendor and pld_data_version=1 \r\n"
                                    + " LEFT JOIN vendor_invoice_irn_verification_status viiv ON ih.id = viiv.inv_header_id \r\n"
                                    + " where ih.taxpayer_gstin=? and ih.vendor_gstin=? \r\n" + " and invoice_no=? \r\n"
                                    + " and invoice_date=? AND pld_upload_type IN (20,97,188,190) LIMIT 1").toString();
    
    public static final String SEARCH_URP_INVOICE_DETAILS_SQL = new StringBuilder(
            "select uoh.taxpayer_gstin as taxpayerGstin, uoh.vendor_gstin as vendorGstin,tv.company_legal_name,tv.company_trade_name, \r\n"
                            + " 'e-Invoice' as title, uoh.irn_no as irnNo, uoh.irn_date, uoh.invoice_date as doc_date, uoh.total_inv_amount as totalInvoiceValue, uoh.invoice_no as invoiceNo, \r\n"
                            + " uoh.invoice_date as invoiceDate,uoh.docType, COALESCE(uoh.total_line_items,0) as noOfLIneItem, uoh.main_hsn_code as hsn_code,uoh.batch_no \r\n"
                            + " from urp_ocr_header uoh \r\n"
                            + " LEFT JOIN taxpayer_vendors as tv ON uoh.taxpayer_gstin = tv.gstin_taxpayer AND uoh.vendor_gstin = tv.gstin_vendor and pld_data_version=1 \r\n"
                            + " where uoh.taxpayer_gstin=? and uoh.vendor_pan_number=? \r\n" + " and uoh.invoice_no=? \r\n"
                            + " and uoh.vendor_code_erp=? LIMIT 1").toString();

    public static final String WRITE_INVOICE_DETAILS_TO_INVOICE_HEADER = new StringBuilder(
                    "INSERT into invoice_header (taxpayer_pan,taxpayer_gstin,vendor_pan,vendor_gstin,invoice_no,invoice_date,sync_with_gstr2a,sync_with_gstr2b\r\n"
                                    + ",sync_with_eway_bill,qr_code_valid,eway_bill_no,eway_bill_date,last_sync_on,last_sync_by,sync_status,created_on,\r\n"
                                    + "created_by,return_period,year_id,pld_upload_type,doc_return_period,doc_year_id,batch_no,booked_in_erp,booked_in_erp_by,booked_in_erp_on)\r\n"
                                    + "\r\n"
                                    + "SELECT ied.pan_of_recipient as 'taxpayer_pan',ied.gstin_uin_of_recipient as 'taxpayer_gstin', \r\n"
                                    + "SUBSTRING(ied.gstin_of_supplier, 3, 10) as 'vendor_pan',ied.gstin_of_supplier as 'vendor_gstin',\r\n"
                                    + "ied.inward_no as 'invoice_no',ied.inward_date as 'invoice_date', 0 as sync_with_gstr2a, 0 as sync_with_gstr2b,\r\n"
                                    + "0 as sync_with_eway_bill, 0 as qr_code_valid, ied.e_way_bill_no, ied.e_way_bill_date, null as last_sync_on,0 as last_sync_by,\r\n"
                                    + "0 as sync_status, up.created_at as 'created_on' , up.created_by, '-' as return_period,\r\n"
                                    + "ied.year_id,up.pld_template_type as 'pld_upload_type','-' as doc_return_period ,0 as doc_year_id ,\r\n"
                                    + "ied.batch_no , 0 as booked_in_erp , 0 as booked_in_erp_by, null as booked_in_erp_on FROM upload_log up \r\n"
                                    + "inner join \r\n"
                                    + "invoice_eway_bill_details as ied on up.batch_no=ied.batch_no\r\n"
                                    + "left join invoice_header as ih\r\n"
                                    + "on ied.gstin_uin_of_recipient = ih.taxpayer_gstin and ied.gstin_of_supplier = ih.vendor_gstin\r\n"
                                    + "and ied.inward_no=ih.invoice_no and ied.inward_date=ih.invoice_date \r\n"
                                    + "where ih.invoice_no is null and up.pld_template_type = 20 and up.success_count>0 \r\n"
                                    + "\r\n" + "union ALL\r\n" + "\r\n"
                                    + "SELECT ied.pan_of_recipient as 'taxpayer_pan',ied.gstin_uin_of_recipient as 'taxpayer_gstin', \r\n"
                                    + "SUBSTRING(ied.gstin_of_supplier, 3, 10) as 'vendor_pan',ied.gstin_of_supplier as 'vendor_gstin',\r\n"
                                    + "ied.inward_no as 'invoice_no',ied.inward_date as 'invoice_date', 0 as sync_with_gstr2a, 0 as sync_with_gstr2b,\r\n"
                                    + "0 as sync_with_eway_bill, 0 as qr_code_valid, ied.e_way_bill_no, ied.e_way_bill_date, null as last_sync_on,0 as last_sync_by,\r\n"
                                    + "0 as sync_status, up.created_at as 'created_on' , up.created_by, '-' as return_period,\r\n"
                                    + "ied.year_id,up.pld_template_type as 'pld_upload_type','-' as doc_return_period ,0 as doc_year_id ,\r\n"
                                    + "ied.batch_no , 0 as booked_in_erp , 0 as booked_in_erp_by, null as booked_in_erp_on FROM upload_log up \r\n"
                                    + "inner join \r\n"
                                    + "invoice_eway_bill_details as ied on up.batch_no=ied.batch_no\r\n"
                                    + "left join invoice_header as ih\r\n"
                                    + "on ied.gstin_uin_of_recipient = ih.taxpayer_gstin and ied.gstin_of_supplier = ih.vendor_gstin\r\n"
                                    + "and ied.e_way_bill_no=ih.eway_bill_no and ied.e_way_bill_date=ih.eway_bill_date \r\n"
                                    + "where ih.eway_bill_no is null and up.pld_template_type = 21 and up.success_count>0")
                                                    .toString();

    public static String searchInvoiceHeaderSql(String tabId, String mstDb) {
        if ("2".equals(tabId)) {
            return new StringBuilder(
                            "SELECT distinct inv.taxpayer_gstin as taxpayerGstin , inv.vendor_gstin as vendorGstin, tv.company_legal_name as vendorLegalName,\r\n"
                                            + "tv.company_trade_name as vendorTradeName, inv.invoice_no as invNo,inv.invoice_date as invDate, inv.doc_type, null as source, inv.batch_no, \r\n")
                                                            .append(" '' as pos, '' as grossTotal,'' as gstr1FilingStatus,'' as gstr3FilingStatus,'' AS dateSupplierCancelllation, '' AS dateFilingGstrSupplier,\r\n ")
                                                            .append(" '' AS filingPeriodGstrSupplier,'' AS amendmentReturnPeriod,'' AS amendmentType,'' AS itcAvailability,'' AS itcAvailabilityReason,'' as gstr2bFp \r\n")
                                                            .append(" FROM invoice_detail as inv LEFT JOIN taxpayer_vendors as tv ON inv.taxpayer_gstin = tv.gstin_taxpayer AND inv.vendor_gstin = tv.gstin_vendor \r\n")
                                                            .append("WHERE inv.taxpayer_gstin =?  AND inv.vendor_gstin = ? AND inv.invoice_no = ? AND inv.invoice_date = ? AND inv.id=? and tv.pld_data_version = 3")
                                                            .toString();

        } else {
            return new StringBuilder(
                            "SELECT ih.taxpayer_gstin as taxpayerGstin , ih.vendor_gstin as vendorGstin, tv.company_legal_name as vendorLegalName,\r\n")
                                            .append("tv.company_trade_name as vendorTradeName, ih.invoice_no as invNo,ih.invoice_date as invDate,\r\n")
                                            .append("ih.doc_type, spld.name as source,ih.file_type, ih.batch_no\r\n")
                                            .append("FROM invoice_header ih LEFT JOIN taxpayer_vendors as tv \n")
                                            .append("ON ih.taxpayer_gstin = tv.gstin_taxpayer AND ih.vendor_gstin = tv.gstin_vendor  AND tv.pld_data_version = 3\n")
                                            .append(" LEFT JOIN " + mstDb
                                                            + ".sm_pickup_list_details spld ON ih.pld_upload_type =  spld.id \n")
                                            .append("WHERE ih.taxpayer_gstin = ? AND ih.vendor_gstin = ? AND ih.invoice_no = ? AND ih.invoice_date = ? and ih.id=?")
                                            .toString();
        }

    }

    public static String searchGstr2aDetailsSql(String getType) {
        if (StringUtils.equals(getType, "gstr2a")) {
            return new StringBuilder(
                            " SELECT gstr2a.gstin as taxpayerGstin , gstr2a.ctin as vendorGstin, tv.company_legal_name as vendorLegalName,tv.company_trade_name as vendorTradeName, gstr2a.invoice_no as invNo,gstr2a.invoice_date as invDate, gstr2a.invoice_type, gstr2a.category AS doc_type,gstr2a.note_type, gstr2a.batch_no,\n")
                                            .append(" gstr2a.pos, gstr2a.sum_gross_total_amount as grossTotal,gstr2a.cfs as gstr1FilingStatus,gstr2a.cfs_gstr3b as gstr3FilingStatus,gstr2a.date_of_cancellation AS dateSupplierCancelllation, gstr2a.date_of_filing_gstr1_5 AS dateFilingGstrSupplier,gstr2a.delink_flag, \n")
                                            .append(" gstr2a.filing_period_gstr1_5 AS filingPeriodGstrSupplier,gstr2a.amendment_fp AS amendmentReturnPeriod,gstr2a.amendment_type AS amendmentType,\n")
                                            .append(" gstr2a.itc_eligibility AS itcAvailability,gstr2b.itc_eligibility_reason AS itcUnavailabilityReason,gstr2b.fp AS gstr2bFp,")
                                            .append(" gstr2a.taxable_amount,gstr2a.igst_amount,gstr2a.cgst_amount, gstr2a.sgst_amount, gstr2a.cess_amount,gstr2a.reverse_charge as reversecharge,\n")
                                            .append(" (gstr2a.igst_amount + gstr2a.sgst_amount + gstr2a.cgst_amount + gstr2a.cess_amount ) AS totalTax,\n")
                                            .append(" (CASE WHEN COALESCE(gstr2a.igst_amount,0.00) <> 0.00 THEN gstr2a.rate ELSE 0 END) AS igst_rate,\n")
                                            .append(" (CASE WHEN COALESCE(gstr2a.igst_amount,0.00) = 0.00  THEN gstr2a.rate/2 ELSE 0 END) AS sgst_rate,\n")
                                            .append(" (CASE WHEN  COALESCE(gstr2a.igst_amount,0.00) = 0.00 THEN gstr2a.rate/2 ELSE 0 END) AS cgst_rate,\n")
                                            .append(" 0 as cess_rate FROM tx_gstr2a_reco as gstr2a LEFT JOIN taxpayer_vendors as tv ON gstr2a.gstin = tv.gstin_taxpayer AND gstr2a.ctin = tv.gstin_vendor AND tv.pld_data_version = 3\n")
                                            .append(" LEFT JOIN tx_gstr2b_reco gstr2b ON gstr2a.gstin = gstr2b.gstin AND gstr2a.ctin = gstr2b.ctin AND gstr2a.invoice_no = gstr2b.invoice_no AND gstr2a.invoice_date = gstr2b.invoice_date AND gstr2b.is_deleted = 0 \n")
                                            .append(" WHERE gstr2a.gstin = ? AND gstr2a.fp = ? AND gstr2a.is_deleted=0 AND gstr2a.category = ? AND gstr2a.ctin = ? AND gstr2a.invoice_no = ? AND gstr2a.invoice_date = ? ")
                                            .append(" limit ? offset ?").toString();
        } else {
            return new StringBuilder(
                            " SELECT gstr2b.gstin as taxpayerGstin , gstr2b.ctin as vendorGstin, tv.company_legal_name as vendorLegalName,tv.company_trade_name as vendorTradeName, gstr2b.invoice_no as invNo,gstr2b.invoice_date as invDate, gstr2b.invoice_type, gstr2b.category AS doc_type,gstr2b.note_type, gstr2b.batch_no,\n")
                                            .append(" gstr2b.pos, gstr2b.sum_gross_total_amount as grossTotal,gstr2b.cfs as gstr1FilingStatus,gstr2b.cfs_gstr3b as gstr3FilingStatus,gstr2b.date_of_cancellation AS dateSupplierCancelllation, gstr2b.date_of_filing_gstr1_5 AS dateFilingGstrSupplier,gstr2b.delink_flag, \n")
                                            .append(" gstr2b.filing_period_gstr1_5 AS filingPeriodGstrSupplier,gstr2b.amendment_fp AS amendmentReturnPeriod,gstr2b.amendment_type AS amendmentType,gstr2b.fp AS gstr2bFp,gstr2b.itc_eligibility AS itcAvailability,gstr2b.itc_eligibility_reason AS itcUnavailabilityReason,gstr2b.srctyp AS sourceType,gstr2b.irn,gstr2b.irngendate AS irnGeneratedDate,\n")
                                            .append(" gstr2b.taxable_amount,gstr2b.igst_amount,gstr2b.cgst_amount, gstr2b.sgst_amount, gstr2b.cess_amount,gstr2b.reverse_charge as reversecharge,diff_percent as differentialRate,\n")
                                            .append(" (gstr2b.igst_amount + gstr2b.sgst_amount + gstr2b.cgst_amount + gstr2b.cess_amount ) AS totalTax,\n")
                                            .append(" (CASE WHEN COALESCE(gstr2b.igst_amount,0.00) <> 0.00 THEN gstr2b.rate ELSE 0 END) AS igst_rate,\n")
                                            .append(" (CASE WHEN COALESCE(gstr2b.igst_amount,0.00) = 0.00  THEN gstr2b.rate/2 ELSE 0 END) AS sgst_rate,\n")
                                            .append(" (CASE WHEN  COALESCE(gstr2b.igst_amount,0.00) = 0.00 THEN gstr2b.rate/2 ELSE 0 END) AS cgst_rate,\n")
                                            .append(" 0 as cess_rate FROM tx_gstr2b_reco as gstr2b LEFT JOIN taxpayer_vendors as tv ON gstr2b.gstin = tv.gstin_taxpayer AND gstr2b.ctin = tv.gstin_vendor AND tv.pld_data_version = 3\n")
                                            .append(" WHERE gstr2b.gstin = ? AND gstr2b.fp = ? AND gstr2b.is_deleted=0 AND gstr2b.category = ? AND gstr2b.ctin = ? AND gstr2b.invoice_no = ? AND gstr2b.invoice_date = ? ")
                                            .append(" limit ? offset ?").toString();

        }

    }

    public static final String searchGstr2aLineItemsSql(String tabId) {
        if ("2".equals(tabId)) {
            return new StringBuilder("SELECT  '-' as description , null as hsn_code,\r\n"
                            + "1 as quantity, '-' as unit, 0 as rate, gstr2a.taxable_amount,\r\n"
                            + "gstr2a.rate as ratePercent, gstr2a.igst_amount, \r\n"
                            + "gstr2a.cgst_amount, gstr2a.sgst_amount, gstr2a.cess_amount,\r\n"
                            + "gstr2a.sum_gross_total_amount as totalItemValue,reverse_charge as reversecharge\r\n"
                            + "FROM tx_gstr2a_reco as gstr2a\r\n" + "INNER JOIN invoice_detail as inv\r\n"
                            + " ON gstr2a.gstin = inv.taxpayer_gstin AND gstr2a.ctin = inv.vendor_gstin \n").append(
                                            " and gstr2a.invoice_no=inv.invoice_no and inv.invoice_date=gstr2a.invoice_date and gstr2a.fp = inv.return_period\n")
                                            .append(" WHERE inv.taxpayer_gstin = ? AND inv.vendor_gstin = ? AND inv.invoice_no = ? AND inv.invoice_date = ? and gstr2a.is_deleted=0 and pld_get_type=123 and inv.category=gstr2a.category and inv.id = ? \n")
                                            .append(" LIMIT ? OFFSET ?").toString();
        } else {
            return new StringBuilder("SELECT  '-' as description , inv.main_hsn_code,\r\n"
                            + "0 as quantity, '-' as unit, 0 as rate, gstr2a.taxable_amount,\r\n"
                            + "gstr2a.rate as ratePercent, gstr2a.igst_amount,\r\n"
                            + "gstr2a.cgst_amount, gstr2a.sgst_amount, gstr2a.cess_amount,\r\n"
                            + "gstr2a.sum_gross_total_amount as totalItemValue,reverse_charge as reversecharge FROM tx_gstr2a_reco as gstr2a\r\n"
                            + "INNER JOIN invoice_detail as inv\r\n"
                            + " ON gstr2a.gstin = inv.taxpayer_gstin AND gstr2a.ctin = inv.vendor_gstin \r\n"
                            + " left join invoice_header ih  on inv.taxpayer_gstin = ih.taxpayer_gstin AND inv.vendor_gstin = ih.vendor_gstin \r\n")
                                            .append(" and gstr2a.invoice_no=inv.invoice_no and inv.invoice_date=gstr2a.invoice_date and  gstr2a.fp = inv.return_period \r\n")
                                            .append(" WHERE inv.taxpayer_gstin = ? AND inv.vendor_gstin = ? AND inv.invoice_no = ?")
                                            .append("AND inv.invoice_date = ? and  gstr2a.is_deleted=0 and   pld_get_type=123  and inv.category=gstr2a.category and  ih.id=?")
                                            .append(" LIMIT ? OFFSET ?").toString();

        }
    }

    public static final String getCountGstr2aLineItemsSql(String getType) {
        if (StringUtils.equals(getType, "gstr2a")) {
            return new StringBuilder(" Select COUNT(1) FROM tx_gstr2a_reco as gstr2a ").append(
                            " WHERE gstr2a.gstin = ? AND gstr2a.fp = ? AND gstr2a.is_deleted=0 AND gstr2a.category = ? AND gstr2a.ctin = ? AND gstr2a.invoice_no = ? AND gstr2a.invoice_date = ? ")
                            .toString();
        } else {
            return new StringBuilder(" Select COUNT(1) FROM tx_gstr2b_reco as gstr2b ").append(
                            " WHERE gstr2b.gstin = ? AND gstr2b.fp = ? AND gstr2b.is_deleted=0 AND gstr2b.category = ? AND gstr2b.ctin = ? AND gstr2b.invoice_no = ? AND gstr2b.invoice_date = ? ")
                            .toString();
        }

    }

    public static final String searchGstr2bLineItemsSql(String tabId) {
        if ("2".equals(tabId)) {
            return new StringBuilder("SELECT  '-' as description , null as hsn_code,\r\n"
                            + "1 as quantity, '-' as unit, 0 as rate, gstr2b.taxable_amount,\r\n"
                            + "gstr2b.rate as ratePercent, gstr2b.igst_amount, \r\n"
                            + "gstr2b.cgst_amount, gstr2b.sgst_amount, gstr2b.cess_amount,\r\n"
                            + "gstr2b.sum_gross_total_amount as totalItemValue,reverse_charge as reversecharge\r\n"
                            + "FROM tx_gstr2b_reco as gstr2b\r\n" + "INNER JOIN invoice_detail as inv\r\n"
                            + " ON gstr2b.gstin = inv.taxpayer_gstin AND gstr2b.ctin = inv.vendor_gstin \n").append(
                                            " and gstr2b.invoice_no=inv.invoice_no and inv.invoice_date=gstr2b.invoice_date and gstr2b.fp = inv.return_period  \n")
                                            .append(" WHERE inv.taxpayer_gstin = ? AND inv.vendor_gstin = ? AND inv.invoice_no = ? AND inv.invoice_date = ? "
                                                            + " and gstr2b.is_deleted=0 and pld_get_type=124 \r\n"
                                                            + " and inv.category=gstr2b.category AND inv.id=? \n")
                                            .append(" LIMIT ? OFFSET ?").toString();
        } else {
            return new StringBuilder("SELECT  '-' as description , inv.main_hsn_code,\r\n"
                            + " 0 as quantity, '-' as unit, 0 as rate, gstr2b.taxable_amount,\r\n"
                            + "gstr2b.rate as ratePercent, gstr2b.igst_amount,\r\n"
                            + "gstr2b.cgst_amount, gstr2b.sgst_amount, gstr2b.cess_amount,\r\n"
                            + "gstr2b.sum_gross_total_amount as totalItemValue,reverse_charge as reversecharge FROM tx_gstr2b_reco as gstr2b\r\n"
                            + "INNER JOIN invoice_detail as inv ON gstr2b.gstin = inv.taxpayer_gstin AND gstr2b.ctin = inv.vendor_gstin\r\n"
                            + "left join invoice_header ih  on inv.taxpayer_gstin = ih.taxpayer_gstin AND inv.vendor_gstin = ih.vendor_gstin\r\n")
                                            .append(" and gstr2b.invoice_no=inv.invoice_no and inv.invoice_date=gstr2b.invoice_date and  gstr2b.fp = inv.return_period \n")
                                            .append(" WHERE inv.taxpayer_gstin = ? AND inv.vendor_gstin = ? AND inv.invoice_no = ? AND inv.invoice_date = ? and  gstr2b.is_deleted=0 and   pld_get_type=123  and inv.category=gstr2b.category and  ih.id=?")
                                            .append(" LIMIT ? OFFSET ?").toString();

        }
    }

    public static final String getCountGstr2bLineItemsSql(String tabId) {
        if ("2".equals(tabId)) {
            return new StringBuilder("SELECT COUNT(1) FROM tx_gstr2b_reco as gstr2b\r\n"
                            + "INNER JOIN invoice_detail as inv\r\n"
                            + "ON gstr2b.gstin = inv.taxpayer_gstin AND gstr2b.ctin = inv.vendor_gstin \n").append(
                                            " and gstr2b.invoice_no=inv.invoice_no and inv.invoice_date =gstr2b.invoice_date and gstr2b.fp = inv.return_period \n")
                                            .append(" WHERE inv.taxpayer_gstin = ? AND inv.vendor_gstin = ? AND inv.invoice_no = ? AND inv.invoice_date = ? and gstr2b.is_deleted=0 and pld_get_type=124 and inv.category=gstr2b.category AND inv.id=?")
                                            .toString();
        } else {
            return new StringBuilder("SELECT COUNT(1) FROM tx_gstr2b_reco as gstr2b\r\n"
                            + "INNER JOIN invoice_detail as inv\r\n"
                            + " ON gstr2b.gstin = inv.taxpayer_gstin AND gstr2b.ctin = inv.vendor_gstin\r\n").append(
                                            " and gstr2b.invoice_no=inv.invoice_no and inv.invoice_date=gstr2b.invoice_date and  gstr2b.fp = inv.return_period")
                                            .append(" WHERE inv.taxpayer_gstin = ? AND inv.vendor_gstin = ? AND inv.invoice_no = ? AND inv.invoice_date = ? and  gstr2b.is_deleted=0 and   pld_get_type=123  and inv.category=gstr2b.category AND inv.id=? ")
                                            .toString();

        }

    }

    public static String getCustomizeSyncPendingColumnName(String mstDatabseName) {
        return new StringBuilder("select  column_screen_name,table_column_name,column_width from ( \r\n"
                        + "select gridmap.customize_column_id as column_id ,gridTab.column_screen_name,gridTab.is_mandatory, 1 as is_Selected,\r\n"
                        + "gridmap.sort_order,gridTab.table_column_name,column_width from \r\n" + mstDatabseName
                        + ".sm_grid_customize_column gridTab  inner Join \r\n"
                        + "grid_user_customize_column_mapping gridmap \r\n"
                        + "on gridTab.column_key=gridmap.customize_column_id where gridmap.user_id=1 and gridTab.tab_id=3  \r\n"
                        + "and gridTab.pld_module_id=65\r\n"
                        + "Union select gridTab.column_key  as column_id ,gridTab.column_screen_name,gridTab.is_mandatory,is_active\r\n"
                        + "as is_Selected, gridTab.sort_order ,gridTab.table_column_name,column_width from \r\n"
                        + mstDatabseName + ".sm_grid_customize_column gridTab where column_key not in \r\n"
                        + "(select customize_column_id from \r\n"
                        + "grid_user_customize_column_mapping where user_id=1\r\n"
                        + ") and gridTab.tab_id=3  and gridTab.pld_module_id=65) a   order by a.sort_order\r\n")
                                        .toString();
    }

    public static String getCustomizePendingForUserInputColumnName(String mstDatabseName) {
        return new StringBuilder("select  column_screen_name,table_column_name,column_width from ( \r\n"
                        + "select gridmap.customize_column_id as column_id ,gridTab.column_screen_name,gridTab.is_mandatory, 1 as is_Selected,\r\n"
                        + "gridmap.sort_order,gridTab.table_column_name,column_width from \r\n" + mstDatabseName
                        + ".sm_grid_customize_column gridTab  inner Join \r\n"
                        + "grid_user_customize_column_mapping gridmap \r\n"
                        + "on gridTab.column_key=gridmap.customize_column_id where gridmap.user_id=1 and gridTab.tab_id=2  \r\n"
                        + "and gridTab.pld_module_id=65\r\n"
                        + "Union select gridTab.column_key  as column_id ,gridTab.column_screen_name,gridTab.is_mandatory,is_active\r\n"
                        + "as is_Selected, gridTab.sort_order ,gridTab.table_column_name,column_width from \r\n"
                        + mstDatabseName + ".sm_grid_customize_column gridTab where column_key not in \r\n"
                        + "(select customize_column_id from \r\n"
                        + "grid_user_customize_column_mapping where user_id=1\r\n"
                        + ") and gridTab.tab_id=2  and gridTab.pld_module_id=65) a   order by a.sort_order\r\n")
                                        .toString();
    }

    public static String getColumnCountForUser(String mstDatabseName) {
        return new StringBuilder("select count(1) from " + mstDatabseName
                        + ".sm_grid_customize_column grid inner  join grid_user_customize_column_mapping cm on grid.column_key=cm.customize_column_id \n")
                                        .append(" where grid.tab_id=? and cm.user_id = ? and grid.is_active = 1 and grid.pld_module_id =65 ")
                                        .toString();
    }

    public static String insertColumnsIntoCustmizeMapping(String mstDatabseName) {
        return new StringBuilder(
                        "insert into grid_user_customize_column_mapping(user_id,customize_column_id,sort_order)\n")
                                        .append(" select ?,column_key,sort_order from " + mstDatabseName
                                                        + ".sm_grid_customize_column\n")
                                        .append(" where tab_id = ? and pld_module_id=65").toString();
    }

    public static StringBuilder getCustomizedColumnNames(String mstDatabseName, int count, int userId, String tabId) {
        if (count > 0) {
            return new StringBuilder(
                            "select column_screen_name,table_column_name,column_width,advance_search_column_name  \n")
                                            .append(" from " + mstDatabseName
                                                            + ".sm_grid_customize_column grid left join grid_user_customize_column_mapping cm \n")
                                            .append("on grid.column_key=cm.customize_column_id where grid.tab_id="
                                                            + tabId + " and grid.is_active = 1 and cm.user_id=" + userId
                                                            + " and grid.pld_module_id=65 ");

        } else {
            return new StringBuilder(
                            "select column_screen_name,table_column_name,column_width,advance_search_column_name \r\n")
                                            .append("from " + mstDatabseName
                                                            + ".sm_grid_customize_column grid where grid.tab_id = "
                                                            + tabId
                                                            + " and grid.is_active = 1   and pld_module_id=65 ");
        }
    }

    public static String getGstr2aDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {

        StringBuilder SEARCH_GSTR2A_SQL = new StringBuilder();

        if ("1".equals(invoiceDetailsReqDTO.getFlag())) {
            return SEARCH_GSTR2A_SQL.append(
                            "SELECT taxpayer_gstin , vendor_gstin, 'GET GSTR2A' as title,taxable_value as taxable_amount, pos as placeSupply,\r\n"
                                            + " igst as 'igst_amount', cgst as 'cgst_amount',sgst as 'sgst_amount',cess as 'cess_amount',invoice_value,return_period as fp,category\r\n"
                                            + " invoice_no,invoice_date, sync_status as 'is_sync', sync_status as defaultSyncStatus, COALESCE(is_forced_sync,0) as forcesyncstatus FROM invoice_detail\n")
                            .append("WHERE taxpayer_gstin = ? AND vendor_gstin = ? AND eway_bill_no = ? AND eway_bill_date = ? \n")
                            .append(" and pld_get_type = ? AND sync_status = 1").toString();
        } else {
            return SEARCH_GSTR2A_SQL.append(
                            "SELECT taxpayer_gstin , vendor_gstin, 'GET GSTR2A' as title,taxable_value as taxable_amount, pos as placeSupply,\r\n"
                                            + " igst as 'igst_amount', cgst as 'cgst_amount',sgst as 'sgst_amount',cess as 'cess_amount',invoice_value,return_period as fp,category,\r\n"
                                            + " invoice_no,invoice_date, sync_status as 'is_sync', sync_status as defaultSyncStatus, COALESCE(is_forced_sync,0) as forcesyncstatus FROM invoice_detail\n")
                            .append("WHERE taxpayer_gstin = ? AND vendor_gstin = ? AND invoice_no = ? AND invoice_date = ? \n")
                            .append(" and pld_get_type = ? AND sync_status = 1").toString();
        }
    }

    public static String getGstr2bDetailsSql(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {
        StringBuilder strBuilder = new StringBuilder();
        if ("1".equals(invoiceDetailsReqDTO.getFlag())) {
            return strBuilder.append(
                            "SELECT taxpayer_gstin , vendor_gstin, 'GET GSTR2B' as title,taxable_value as taxable_amount, pos as placeSupply,\r\n"
                                            + " igst as 'igst_amount', cgst as 'cgst_amount',sgst as 'sgst_amount',cess as 'cess_amount',invoice_value ,return_period as fp,category,\r\n"
                                            + " invoice_no,invoice_date, sync_status as 'is_sync', sync_status as defaultSyncStatus, COALESCE(is_forced_sync,0) as forcesyncstatus FROM invoice_detail\n")
                            .append("WHERE taxpayer_gstin = ? AND vendor_gstin = ? AND eway_bill_no = ? AND eway_bill_date = ? \n")
                            .append(" and pld_get_type = ? AND sync_status = 1 limit 1").toString();
        } else {
            return strBuilder.append(
                            "SELECT taxpayer_gstin , vendor_gstin, 'GET GSTR2B' as title,taxable_value as taxable_amount, pos as placeSupply,\r\n"
                                            + " igst as 'igst_amount', cgst as 'cgst_amount',sgst as 'sgst_amount',cess as 'cess_amount',invoice_value ,return_period as fp,category,\r\n"
                                            + " invoice_no,invoice_date, sync_status as 'is_sync', sync_status as defaultSyncStatus, COALESCE(is_forced_sync,0) as forcesyncstatus FROM invoice_detail\n")
                            .append("WHERE taxpayer_gstin = ? AND vendor_gstin = ? AND invoice_no = ? AND invoice_date = ? \n")
                            .append(" and pld_get_type = ? AND sync_status = 1 limit 1").toString();
        }

    }

    public static String searchEwayBillSql(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {
        StringBuilder SEARCH_EWAY_SQL = new StringBuilder();
        if ("1".equals(invoiceDetailsReqDTO.getFlag())) {
            return SEARCH_EWAY_SQL.append(
                            "SELECT taxpayer_gstin , vendor_gstin, 'GET EWAYBILL' as title,taxable_value as taxableAmount, pos as placeSupply,\r\n"
                                            + " eway_bill_no as ewbNo,eway_bill_date as ewbDate,igst as 'igst_amount', cgst as 'cgst_amount',sgst as 'sgst_amount',cess as 'cess_amount',invoice_value as 'inv_value',\r\n"
                                            + " invoice_no,invoice_date, sync_status as 'is_sync', sync_status as defaultSyncStatus, COALESCE(is_forced_sync,0) as forcesyncstatus,eh.status,fromPlace  FROM invoice_detail"
                                            + " left join ewb_header eh on eh.ewb_no=eway_bill_no \n")
                            .append("WHERE taxpayer_gstin = ? AND vendor_gstin = ? AND eway_bill_no = ? AND eway_bill_date = ? \n")
                            .append(" and pld_get_type = ? AND sync_status = 1 limit 1").toString();
        } else {
            return SEARCH_EWAY_SQL.append(
                            "SELECT taxpayer_gstin , vendor_gstin, 'GET EWAYBILL' as title,taxable_value as taxableAmount, pos as placeSupply,\r\n"
                                            + " eway_bill_no as ewbNo,eway_bill_date as ewbDate,igst as 'igst_amount', cgst as 'cgst_amount',sgst as 'sgst_amount',cess as 'cess_amount',invoice_value as 'inv_value',\r\n"
                                            + " invoice_no,invoice_date, sync_status as 'is_sync', sync_status as defaultSyncStatus, COALESCE(is_forced_sync,0) as forcesyncstatus,eh.status as ewbStatus ,fromPlace FROM invoice_detail"
                                            + "  left join ewb_header eh on eh.ewb_no=eway_bill_no \n")
                            .append("WHERE taxpayer_gstin = ? AND vendor_gstin = ? AND invoice_no = ? AND invoice_date = ? \n")
                            .append(" and pld_get_type = ? AND sync_status = 1 limit 1").toString();
        }

    }

    public static final String GET_COUNT_UNSYNC_DATALIST = new StringBuilder(
                    "select count(distinct id.id) from invoice_detail ID  ").append(
                                    " where ID.taxpayer_gstin=? and ID.vendor_gstin=? and ID.invoice_no like ? and pld_get_type=? and ID.sync_status=0 \n")
                                    .toString();

    public static final String GET_OCR_DETAIL_FROM_OCR_HEADER = new StringBuilder(
                    "SELECT id,taxpayer_gstin,vendor_gstin,invoice_no,invoice_date,eway_bill_no,eway_bill_date,docType AS dataType,po_number AS poNo,po_date, irn_no,irn_date,vendor_name,taxable_amount,file_name, ")
                                    .append(" sgst_amt AS sgstAmount,igst_amt AS igstAmount,cgst_amt AS cgstAmount,cess_amt AS cessAmount,total_inv_amount AS invoiceValue, ")
                                    .append(" (select count(ce.error_type) from  ocr_extraction_and_compliance_error ce  where ce.file_id=hd.file_id and ce.error_type=1) as extraction, ")
                                    .append(" (select count(ce1.error_type) from  ocr_extraction_and_compliance_error ce1  where ce1.file_id=hd.file_id and ce1.error_type=2) as compliance ")
                                    .append(" from ocr_header hd WHERE id = ? ").toString();

    public static final String SEARCH_UNSYNC_DATALIST = new StringBuilder(
                    "select ID.id,ID.taxpayer_gstin,ID.vendor_gstin,ID.sync_status as status,ID.invoice_no,ID.invoice_date,\r\n")
                                    .append(" taxable_value,igst,cgst,sgst,invoice_value as total_invoice_value,category,id.irn as irn_no,id.irn_dt as irn_date \n")
                                    .append(" from invoice_detail ID  ")
                                    .append(" where ID.taxpayer_gstin=? and ID.vendor_gstin=? and ID.invoice_no like ? and pld_get_type=? and ID.sync_status=0 \n")
                                    .append(" LIMIT ? OFFSET ? \n").toString();

    public static final String SEARCH_SYNC_DATALIST = new StringBuilder(
                    "select ID.id, ID.taxpayer_gstin,ID.vendor_gstin,ID.sync_status as status,ID.invoice_no,ID.invoice_date,IH.hsn_code,IH.doc_type,IH.file_type,\r\n")
                                    .append(" taxable_value,igst,cgst,sgst,invoice_value as total_invoice_value,category,ID.irn as irn_no,ID.irn_dt as irn_date \n")
                                    .append(" from invoice_detail ID  join invoice_header IH on ih.taxpayer_gstin=id.taxpayer_gstin and  ih.vendor_gstin= id.vendor_gstin and ih.inv_header_cr_id=id.parent_id \n")
                                    .append(" where IH.id = ? and ID.taxpayer_gstin=? and ID.vendor_gstin=? and pld_get_type=? and ID.sync_status=1 \n")
                                    .toString();

    public static final String getDuplicateFPInDiffMonth(String mstDb) {

        return " Select distinct lower(concat(gstin_of_supplier,e_way_bill_no)) from invoice_eway_bill_details \r\n"
                        + "where  gstin_uin_of_recipient=? and invoice_eway_bill_details.filling_period  in (select fp from "
                        + mstDb + ".sm_return_periods where fp != ?) and template_type = 21 and concat(gstin_of_supplier,e_way_bill_no) is not null";

    }

    public static final String getDuplicateInvoiceInDiffMonth(String mstDb) {
        return " Select distinct lower(concat(gstin_of_supplier,inward_no)) from invoice_eway_bill_details \r\n"
                        + "where  gstin_uin_of_recipient=? and invoice_eway_bill_details.filling_period in (select fp from "
                        + mstDb + ".sm_return_periods where fp != ?) and  template_type in (20,97) and concat(gstin_of_supplier,inward_no) is not null";
    }

    public static final String getTemplateIds(String mstDb) {
        return "select ld.id from " + mstDb + ".am_custom_template_name tn join " + mstDb
                        + ".sm_pickup_list_details ld on "
                        + "ld.code= tn.pld_template_id where tn.id =? and ld.sm_pick_mst_id=?";
    }

    public static final String getUPDATE_PLD_CODE_QUERY(String mstDb) {
        return "select ld.id from " + mstDb + ".am_custom_template_name tn join " + mstDb
                        + ".sm_pickup_list_details ld on "
                        + "ld.code= tn.pld_template_id where tn.id =? and ld.sm_pick_mst_id=? and  ld.pick_key=?";

    }

    public static final String INWARD_RESULT_FP_COUNT = "select count(1) from invoice_eway_bill_details where gstin_uin_of_recipient = ? and gstin_of_supplier = ? and invoice_eway_bill_details.filling_period in (select fp FROM sm_return_periods where year_id = ? and fp != ?)"
                    + " and inward_no =?";
    public static final String CALL_VENDOR_INVOICE_REGISTER_PO = "{call vendor_invoice_register_po(?)}";

    public static final String CALL_VENDOR_INVOICE_INVOICE_HEADER_IMPORT = "{call vendor_invoice_invoiceheader_import(?,?,?,?)}";

    public static final String GET_EWAYBILL_BASIC_INFO_HEADER_DATA = new StringBuilder(
                    "SELECT  distinct distinct (CASE WHEN transactionType = 1 THEN 'Regular' WHEN transactionType = 2 THEN 'Ship to'\r\n")
                                    .append("    WHEN transactionType = 3 THEN 'Dispatch from'  ELSE 'Combination' END ) AS transactionType,\r\n")
                                    .append(" '-' as transactionSubtype, '-' as subtypeRemarks, doc_type as documentType, doc_no as documentNo, doc_date as documentDate\r\n")
                                    .append("from ewb_header where ewb_no = ? ").toString();

    /**
     * Gets the ewaybill basic info bill to.
     *
     * @param mstDb
     *            the mst db
     * @return the string
     */
    public static final String GET_EWAYBILL_BASIC_INFO_BILL_TO(String mstDb) {
        return new StringBuilder("SELECT  distinct '-' title, toTrdName as name, to_gstin gstin, sc.name as state \r\n")
                        .append(" from ewb_header eh inner join " + mstDb
                                        + ".sm_country_state_city sc on sc.item_code= eh.toStateCode and sc.description='State Name' \n")
                        .append("where ewb_no = ? ").toString();

    }

    public static final String GET_EWAYBILL_BASIC_INFO_BILL_FROM(String mstDb) {
        return new StringBuilder(
                        "select distinct '-' title, company_trade_name as 'name', from_gstin gstin, sc.name as state \r\n"
                                        + " from ewb_header eh left join taxpayer_vendors  em on eh.from_gstin=em.gstin_vendor and eh.to_gstin = em.gstin_taxpayer and pld_data_version=1 \r\n"
                                        + "left join " + mstDb
                                        + ".sm_country_state_city sc on sc.item_code= eh.fromStateCode \r\n"
                                        + " and sc.description='State Name' where ewb_no = ? ").toString();

    }

    public static final String GET_EWAYBILL_BASIC_INFO_DISPATCH_FROM(String mstDb) {
        return new StringBuilder(
                        "select fromAddr1 AS address1,fromAddr2 AS address2,fromPlace as place,fromPincode as pincode,sc.name as state \r\n")
                                        .append(" from ewb_header eh inner join " + mstDb
                                                        + ".sm_country_state_city sc on sc.item_code= eh.fromStateCode  and sc.description='State Name' \n")
                                        .append("where ewb_no = ? limit 1 ").toString();

    }

    public static final String GET_EWAYBILL_BASIC_INFO_SHIP_TO(String mstDb) {
        return new StringBuilder(
                        "select toAddr1 AS address1,toAddr2 AS address2,toPlace as place,toPincode as pincode,sc.name as state \r\n")
                                        .append(" from ewb_header eh inner join " + mstDb
                                                        + ".sm_country_state_city sc on sc.item_code= eh.toStateCode and sc.description='State Name'\n")
                                        .append("where ewb_no = ? limit 1 ").toString();

    }

    public static final String GET_EWAYBILL_ITEM_DETAILS_HEADER_DATA = new StringBuilder(
                    "select distinct totalValue AS taxable,cgstValue AS totalCgst,sgstValue AS totalSgst,\r\n").append(
                                    "igstValue AS totalIgst,cessValue AS totalCess,otherValue AS other,cessNonAdvolValue AS totalNonadvcess,totInvValue AS grossTotal\r\n")
                                    .append("from ewb_header where ewb_no = ? ").toString();

    public static final String GET_EWAYBILL_ITEM_DETAILS_LIST = new StringBuilder(
                    "SELECT productName,productDesc as description,hsnCode,quantity,qtyUnit as unit, taxableAmount as taxable,cgstRate,sgstRate,igstRate,cessRate,cessNonAdvol\r\n")
                                    .append(" FROM eway_bill_items_details ID JOIN ewb_header IH ON ID.header_id = IH.id Where IH.ewb_no = ? \n")
                                    .append(" LIMIT ? OFFSET ? \n").toString();

    public static final String GET_EWAYBILL_ITEM_DETAILS_LIST_COUNT = new StringBuilder("SELECT COUNT(1)\r\n").append(
                    " FROM eway_bill_items_details ID JOIN ewb_header IH ON ID.header_id = IH.id Where IH.ewb_no = ? \n")
                    .toString();

    public static final String GET_EWAYBILL_TRANSPORT_DETAIL_PARTA(String mstDb) {
        return new StringBuilder(
                        "SELECT transporterId, transporterName,actualDist as approxDistance, to_gstin gstin,sc.name as fromState,fromPlace,EV.entered_date as enteredDate  \r\n")
                                        .append("from ewb_header EH inner join " + mstDb
                                                        + ".sm_country_state_city sc on sc.item_code= eh.toStateCode and sc.description='State Name' \n")
                                        .append("left join ewb_vehicle_details EV ON EH.ID = EV.ewb_id where ewb_no = ? limit 1 \n")
                                        .toString();
    }

    public static final String GET_EWAYBILL_TRANSPORT_DETAIL_PARTB = new StringBuilder(
                    "SELECT (CASE when trans_mode = 1 then 'Road' when trans_mode = 2 then 'Rail' when trans_mode = 3 then 'Air' when trans_mode= 4 then 'Ship/Road cum Ship' Else null END) as modeofTransport, \n")
                                    .append(" (Case when EH.vehicleType = 'R' then 'Regular' when EH.vehicleType = 'O' then 'ODC' Else null END) as vehicleType, \n")
                                    .append(" vehicle_no,trans_docno AS transportDocno,trans_docdate AS transportDate\r\n")
                                    .append("from ewb_vehicle_details EV inner join ewb_header EH ON EV.ewb_id = EH.id where EH.ewb_no = ? limit 1  ")
                                    .toString();

    public static final String GET_EWAYBILL_ADDITIONAL_INFO = new StringBuilder(
                    "SELECT distinct(ewb_no),ewb_date, EV.upd_mode as updateMode,EV.group_no,tripsht_no as tripsheetNo,gen_mode as genmode,validUpto,extendedTimes,rejectStatus,status,noValidDays\r\n")
                                    .append("from ewb_header EH left join ewb_vehicle_details EV ON EH.ID = EV.ewb_id where ewb_no = ? LIMIT 1 ")
                                    .toString();

    public static final String getVendorInvoiceEWBGETData(String mstDb) {
        return new StringBuilder(
                        "SELECT distinct cl.id ,pld.name, concat_ws('',from_base64(first_name),from_base64(last_name)) as 'requested_by',call_on,\r\n"
                                        + "'0' as 'success_count',\r\n" + "'0' as 'error_count',\r\n"
                                        + "'0' as 'inprogress_count'\r\n"
                                        + "FROM ewb_api_call_log cl join ewb_header eh on eh.ewb_api_call_log_id=cl.id\r\n"
                                        + "JOIN " + mstDb + ".sm_pickup_list_details pld on pld.id=cl.pld_get_type\r\n"
                                        + "left join " + mstDb + ".am_user_master um on um.user_id=cl.requested_by\r\n"
                                        + "where taxpayer_gstin=? and pld_get_type=? ").append(" LIMIT ? OFFSET ? \n")
                                                        .toString();
    }

    public static final String getVendorInvoiceEWBGETDataCount(String mstDb) {
        return new StringBuilder(
                        "SELECT COUNT(1) FROM ewb_api_call_log cl join ewb_header eh on eh.ewb_api_call_log_id=cl.id\r\n"
                                        + "JOIN " + mstDb + ".sm_pickup_list_details pld on pld.id=cl.pld_get_type\r\n"
                                        + "left join " + mstDb + ".am_user_master um on um.user_id=cl.requested_by\r\n"
                                        + "where taxpayer_gstin=? and pld_get_type=?").toString();
    }

    public static final String GET_EWAYBILL_GET_VIEW_DETAILS(String mstDb) {
        return new StringBuilder(
                        "select id,status,ewb_no,doc_no,from_gstin,totInvValue,from_base64(trade_name) as 'from_name' from ewb_header eh "
                                        + "left join " + mstDb
                                        + ".am_entity_master em on eh.to_gstin=to_base64(em.gstin) where ewb_api_call_log_id=? \n")
                                                        .append(" LIMIT ? OFFSET ? \n").toString();
    }

    public static final String GET_EWAYBILL_GET_VIEW_DETAILS_COUNT = new StringBuilder(
                    "select COUNT(1) from ewb_header where ewb_api_call_log_id=? \n").toString();

    public static final String GET_BASE_DOCUMENT_SQL = new StringBuilder(
                    "select pld_upload_type from invoice_header where is_base_document=1 and \n").append(
                                    " taxpayer_gstin=? and vendor_gstin=? and invoice_no = ? and invoice_date = ? limit 1")
                                    .toString();

    public static final String GET_BASE_DOCUMENT_SQL_EWAYBILL = new StringBuilder(
                    "select pld_upload_type from invoice_header where is_base_document=1 and \n").append(
                                    " taxpayer_gstin=? and vendor_gstin=? and eway_bill_no = ? and eway_bill_date = ? limit 1")
                                    .toString();

    public static final String GET_INVOICE_HEADER_PRIMARY_DETAILS = new StringBuilder(
                    "select hd.taxpayer_gstin,hd.vendor_gstin,hd.invoice_no,hd.invoice_date,COALESCE(id.eway_bill_no,hd.eway_bill_no) as eway_bill_no,COALESCE(id.eway_bill_date,hd.eway_bill_date) as eway_bill_date,hd.ocr_header_id From invoice_header hd left join invoice_detail id\r\n"
                                    + "on hd. taxpayer_gstin=id.taxpayer_gstin and hd.vendor_gstin=id.vendor_gstin and hd.invoice_no=id.invoice_no and id.pld_get_type=125\r\n"
                                    + "where hd.id = ?").toString();

    public static final String GET_INVOICE_HEADER_PRIMARY_DETAILS_EWB = new StringBuilder(
                    "select hd.taxpayer_gstin,hd.vendor_gstin,hd.invoice_no,hd.invoice_date,COALESCE(id.eway_bill_no,hd.eway_bill_no) as eway_bill_no,COALESCE(id.eway_bill_date,hd.eway_bill_date) as eway_bill_date From invoice_header hd left join invoice_detail id\r\n"
                                    + "on hd. taxpayer_gstin=id.taxpayer_gstin and hd.vendor_gstin=id.vendor_gstin and hd.invoice_no=id.invoice_no and id.pld_get_type=125\r\n"
                                    + "where hd.id = ? and hd.eway_bill_no=? ").toString();

    public static final String GET_INVOICE_DETAIL_PRIMARY_DETAILS = new StringBuilder(
                    "select taxpayer_gstin,vendor_gstin,invoice_no,invoice_date,eway_bill_no,eway_bill_date From invoice_detail where id = ?")
                                    .toString();

    public static final String SEARCH_EWAYBILL_DETAILS_SQL = new StringBuilder(
                    "SELECT pld_upload_type,taxpayer_gstin as taxpayerGstin, vendor_gstin as vendorGstin,\r\n"
                                    + " 'e-Way Bill' as title, eway_bill_no as ewbNo,eway_bill_date as ewbDate,ewb_validity_date \r\n"
                                    + " as validTill, batch_no, ewb_gen_on as generated_on, ewb_gen_by as generated_by FROM invoice_header   \r\n"
                                    + " WHERE taxpayer_gstin = ? AND vendor_gstin = ? \r\n"
                                    + " AND eway_bill_no = ? AND eway_bill_date = ? AND pld_upload_type IN (21,189) LIMIT 1 ")
                                                    .toString();

    public static final String SEARCH_VENDOR_EWAYBILL_DETAILS_SQL = new StringBuilder(
                    "SELECT pld_template_type as pld_upload_type,gstin_taxpayer as taxpayerGstin, gstin_vendor as vendorGstin,\r\n"
                                    + "'e-Way Bill' as title, e_way_bill_no as ewbNo,e_way_bill_date as ewbDate,bill_valid_date \r\n"
                                    + "as validTill, batch_no, '' as generated_on, '' as generated_by FROM vendor_invoice_eway_bill_details  \r\n"
                                    + " WHERE gstin_taxpayer = ? AND gstin_vendor = ? \r\n"
                                    + "AND e_way_bill_no = ? AND e_way_bill_date = ? AND pld_template_type = 189 LIMIT 1 ").toString();

    public static String searchInvoiceHeaderForceSyncSql(String tabId) {
        if ("2".equals(tabId)) {
            return new StringBuilder(
                            "SELECT distinct inv.taxpayer_gstin as taxpayerGstin , inv.vendor_gstin as vendorGstin, tv.company_legal_name as vendorLegalName,\r\n"
                                            + "tv.company_trade_name as vendorTradeName, inv.invoice_no as invNo,inv.invoice_date as invDate,\r\n"
                                            + "inv.doc_type, null as source, inv.batch_no\r\n"
                                            + "FROM invoice_detail as inv\r\n" + "LEFT JOIN taxpayer_vendors as tv \r\n"
                                            + "ON inv.taxpayer_gstin = tv.gstin_taxpayer AND inv.vendor_gstin = tv.gstin_vendor \n")
                                                            .append(" WHERE inv.taxpayer_gstin = ? AND inv.vendor_gstin = ? AND inv.invoice_no = ? AND inv.invoice_date = ? AND inv.id=? tv.pld_data_version = 1 LIMIT 1")
                                                            .toString();
        } else {
            return new StringBuilder(
                            "SELECT inv.taxpayer_gstin as taxpayerGstin , inv.vendor_gstin as vendorGstin, tv.company_legal_name as vendorLegalName,\r\n"
                                            + "tv.company_trade_name as vendorTradeName, inv.invoice_no as invNo,inv.invoice_date as invDate,\r\n"
                                            + "ih.doc_type, ih.pld_upload_type as source, ih.batch_no\r\n"
                                            + "FROM invoice_detail as inv\r\n"
                                            + "left join invoice_header ih  on inv.taxpayer_gstin = ih.taxpayer_gstin AND inv.vendor_gstin = ih.vendor_gstin\r\n"
                                            + "and inv.invoice_no =ih.invoice_no  and inv.invoice_date =ih.invoice_date\r\n"
                                            + "LEFT JOIN taxpayer_vendors as tv\r\n"
                                            + "ON inv.taxpayer_gstin = tv.gstin_taxpayer AND inv.vendor_gstin = tv.gstin_vendor   AND tv.pld_data_version = 1\n")
                                                            .append("WHERE inv.taxpayer_gstin = ? AND inv.vendor_gstin = ? AND inv.invoice_no = ? AND inv.invoice_date = ?  and ih.id=?")
                                                            .toString();
        }
    }

    public static final String CHECK_INVOICE_ALREADY_SYNCED_SQL = "select Distinct CONCAT(taxpayer_gstin,vendor_gstin,invoice_no,doc_type) from invoice_header where taxpayer_gstin = ? and vendor_gstin = ? and sync_status = 1 ";

    public static final String CHECK_EWB_ALREADY_SYNCED_SQL = "select Distinct CONCAT(taxpayer_gstin,vendor_gstin,eway_bill_no) from invoice_header where taxpayer_gstin = ? and vendor_gstin = ? and sync_status = 1 ";

    public static final String CHECK_INVOICE_ALREADY_APPROVED_SQL = "select Distinct CONCAT(COALESCE(taxpayer_gstin, ''), COALESCE(vendor_gstin, ''),COALESCE(invoice_no, ''),COALESCE(doc_type, '')) from invoice_header where taxpayer_gstin = ? and vendor_upload_ref_id is not null";

    public static final String CHECK_EWB_ALREADY_APPROVED_SQL = "select distinct CONCAT(COALESCE(taxpayer_gstin, ''), COALESCE(vendor_gstin, ''),COALESCE(eway_bill_no, '')) from invoice_header where taxpayer_gstin = ? and vendor_upload_ref_id is not null";

    public static String getErrorCodeInvoiceUpload(String tableName) {
        return new StringBuilder("select error_code from " + tableName + " where batch_no=?").toString();

    }

    public static final String GET_VENDOR_INVOICE_DETAIL_PRIMARY_DETAILS = new StringBuilder(
                    "select gstin_taxpayer as taxpayer_gstin, gstin_vendor as vendorGstin,inward_no as invoice_no,inward_date as invoice_date, e_way_bill_no as eway_bill_no, "
                                    + " e_way_bill_date as eway_bill_date  from vendor_invoice_eway_bill_details where id=?")
                                                    .toString();

    public static final String GET_VENDOR_INVOICE_DETAIL_PRIMARY_DETAILS_OCR_TAB = new StringBuilder(
                    "select taxpayer_gstin , vendor_gstin as vendorGstin,invoice_no,invoice_date, eway_bill_no , "
                                    + " eway_bill_date,id as ocrHeaderId  from ocr_header where id=?").toString();
    
    public static final String GET_VENDOR_INVOICE_DETAIL_PRIMARY_DETAILS_URP_TAB = new StringBuilder(
            "select taxpayer_gstin, vendor_pan_number as vendorPan,vendor_code_erp AS vendorCodeErp, "
            + "invoice_no,invoice_date, eway_bill_no,eway_bill_date,ocr_header_id as ocrHeaderId  from urp_ocr_header where id=?").toString();

    public static final String SEARCH_VENDOR_EINVOICE_DETAILS_SQL = new StringBuilder(
                    "select vi.gstin_taxpayer as taxpayerGstin, vi.gstin_vendor as vendorGstin,tv.company_legal_name,tv.company_trade_name, \r\n"
                                    + "'e-Invoice' as title, vi.irn as irnNo, vi.irn_date, inward_date as doc_date, vi.total_invoice_amt as totalInvoiceValue, inward_no as invoiceNo, \r\n"
                                    + "inward_date as invoiceDate,vi.doc_type, COALESCE(vi.item_count,0) as noOfLIneItem, vi.hsn_code,vi.batch_no \r\n"
                                    + " from vendor_invoice_eway_bill_details vi \r\n"
                                    + "LEFT JOIN taxpayer_vendors as tv ON vi.gstin_taxpayer = tv.gstin_taxpayer \r\n"
                                    + "AND vi.gstin_vendor = tv.gstin_vendor and pld_data_version=1  \r\n"
                                    + " WHERE vi.gstin_taxpayer = ? AND vi.gstin_vendor = ? \r\n"
                                    + " and vi.inward_no=?  and vi.inward_date=? AND vi.pld_template_type IN (188,190) LIMIT 1").toString();
    public static final String INSERTINTOSTAGELOG = " insert into upload_stage_log(batch_no,pld_process_stage,pld_process_state,created_at,created_by) VALUES (?,?,?,?,?)";

    public static String getSubmittedWorkflowCountSql(String masterDb) {
        return new StringBuilder("SELECT COUNT(1) FROM ENTITY_WORKFLOW_CONFIG WC ")
                        .append(" JOIN " + masterDb + " .AM_ENTITY_MASTER EM ON EM.ENTITY_ID=WC.ENTITY_ID ")
                        .append(" WHERE PLD_MODULE_ID=65 AND FROM_BASE64(EM.GSTIN) IN (select distinct gstin_taxpayer from vendor_invoice_eway_bill_details where id in(?)) AND EM.DELETED_AT IS NULL AND EM.IS_ACTIVE AND EM.DRAFT_STATUS=1 ")
                        .toString();
    }

    public static final String UPDATE_QR_SCAN_FLAG = "UPDATE upload_log SET is_qr_scanned = ? WHERE batch_no = ?";

    public static final String INSERT_INTO_QR_EXECUTION_LOG = " insert into qr_execution_log(upload_log_id,qr_output,start_time,end_time,created_on,created_by) VALUES (?,?,?,?,now(),?)";

}
