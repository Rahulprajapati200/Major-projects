package com.bdo.bvms.invoices.taxpayer.validationrule;

import java.text.ParseException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.ValidationConstants;
import com.bdo.bvms.invoices.dto.EWayBillDTO;

public class EwayBillDataTypeValidation {

    Map<String, Set<String>> docLevelError = new ConcurrentHashMap<>();
    Map<String, Integer> duplicateRowMap = new HashMap<>();

    static final Logger logger = LoggerFactory.getLogger(EwayBillDataTypeValidation.class);

    public void validateDataType(EWayBillDTO rowdata, String[] eWayGstinListFromDB, String[] fpList, String fileType)
                    throws ParseException {

        EWayBillValidationUtil ruleMethods = new EWayBillValidationUtil();
        String[] poDateList = new String[20];
        String[] poNoList = new String[20];

        isTaxpayerGstinMatchWithList(rowdata, eWayGstinListFromDB);
        // "check if the gstin is blank"
        isTaxpayerGstinBlank(rowdata, ruleMethods);
        // "check if the gstin is in correct format"
        // Customer GSTIN validate
        isValidTaxpayerGstin(rowdata, ruleMethods);
        if (!Constants.PDF.equals(fileType) && !Constants.JPG.equals(fileType)) {

            // check if the taxpayer Gstin is equal to vendor gstin.
            isTaxpayerEqualsVendoeGstin(rowdata);
        }

        // check filling period length and numeric.
        checkFpLength(rowdata);
        // check if it is not a future period.
        checkifFpNotFuture(rowdata, ruleMethods);

        ifFpIsBlank(rowdata);

        if (fpList != null && fpList.length != 0) {
            isFpMatchWithFpList(rowdata, fpList);
        }

        // E-way bill Number field is blank or more than 12 digits
        eWayBillBlankOrMoreThan12Digit(rowdata, ruleMethods);

        // E-way bill Number should be 12 digits numeric
        eWayBill12DigitNumeric(rowdata, ruleMethods);

        // date should not be empty or should not contain any character
        // value or
        // special
        // character except -,/

        eWayDateBlank(rowdata, ruleMethods);
        // "doc date should be in DD-MM-YYYY format"
        eWayDateFormat(rowdata, ruleMethods);
        // E-way bill Date cannot be before 1st July 2017
        eWayDateBefore1July2017(rowdata, ruleMethods);

        // E-way bill Date cannot be future date
        eWayDateCanNotFutureDate(rowdata, ruleMethods);

        // e Way bill valid till should be smaller then 50 keyword
        eWayValidTill50Keywords(rowdata);
        // e Way bill valid till can contain only the special character - /
        // :
        eWayValidTillSpecialCharacter(rowdata, ruleMethods);

        // "check if the gstin is blank"
        isVendorGstinBlank(rowdata, ruleMethods);

          // "check if the gstin is in correct format"
          vendorGstinCorrectFormat(rowdata, ruleMethods);

        if (StringUtils.isNotBlank(rowdata.getPoDate())) {

            poDateList = rowdata.getPoDate().split(",");
        }

        Arrays.asList(poDateList).forEach(poDate -> {

            // "doc date should be in DD-MM-YYYY format"
            poDateFormate(poDate, rowdata, ruleMethods);

            // PO Date cannot be future date
            poDateCannotFutureDate(poDate, rowdata, ruleMethods);

            // Purchase Order Date cannot exceed E-way bill Date
            poDateCannotExceedEWayDate(poDate, rowdata, ruleMethods);

        });

        if (StringUtils.isNotBlank(rowdata.getPoNo())) {
            poNoList = rowdata.getPoNo().split(",");
        }

        poNoAndPoDateCount(rowdata, poNoList, poDateList);

        validEwayBillValidConpare(rowdata,ruleMethods);
        
        Arrays.asList(poNoList).forEach(poNo -> {

            // PurchaseOrderNo Validations
            checkForPurchaseOrderNumberLength(poNo, rowdata);

            checkForPONumberSpecialChar(poNo, rowdata, ruleMethods);

        });

        // Utf1 must be alphanumeric"
        checkUdf1AlphaNumeric(rowdata, ruleMethods);

        udf1CheckLength(rowdata, ruleMethods);
        // Utf2 must be alphanumeric"
        checkUdf2AlphaNumeric(rowdata, ruleMethods);
        udf2CheckLength(rowdata, ruleMethods);
        // Utf3 must be alphanumeric"
        checkUdf3AlphaNumeric(rowdata, ruleMethods);
        udf3CheckLength(rowdata, ruleMethods);
        // Utf4 must be alphanumeric"
        checkUdf4AlphaNumeric(rowdata, ruleMethods);

        udf4CheckLength(rowdata, ruleMethods);
        // Utf5 must be alphanumeric"
        checkUdf5AlphaNumeric(rowdata, ruleMethods);

        udf5CheckLength(rowdata, ruleMethods);
        // Utf6 must be alphanumeric"
        checkUdf6AlphaNumeric(rowdata, ruleMethods);
        udf6CheckLength(rowdata, ruleMethods);
        // Utf7 must be alphanumeric"
        checkUdf7AlphaNumeric(rowdata, ruleMethods);

        udf7CheckLength(rowdata, ruleMethods);
        // Utf8 must be alphanumeric"
        checkUdf8AlphaNumeric(rowdata, ruleMethods);

        udf8CheckLength(rowdata, ruleMethods);
        // Utf9 must be alphanumeric"
        checkUdf9AlphaNumeric(rowdata, ruleMethods);

        udf9CheckLength(rowdata, ruleMethods);
        // Utf10 must be alphanumeric"
        checkUdf10AlphaNumeric(rowdata, ruleMethods);

        udf10CheckLength(rowdata, ruleMethods);

        // Utf11 must be alphanumeric"
        checkUdf11AlphaNumeric(rowdata, ruleMethods);

        udf11CheckLength(rowdata, ruleMethods);
        // Utf12 must be alphanumeric"
        checkUdf12AlphaNumeric(rowdata, ruleMethods);
        udf12CheckLength(rowdata, ruleMethods);
        // Utf13 must be alphanumeric"
        checkUdf13AlphaNumeric(rowdata, ruleMethods);
        udf13CheckLength(rowdata, ruleMethods);
        // Utf14 must be alphanumeric"
        checkUdf14AlphaNumeric(rowdata, ruleMethods);

        udf14CheckLength(rowdata, ruleMethods);
        // Utf15 must be alphanumeric"
        checkUdf15AlphaNumeric(rowdata, ruleMethods);

        udf15CheckLength(rowdata, ruleMethods);
        // Utf16 must be alphanumeric"
        checkUdf16AlphaNumeric(rowdata, ruleMethods);
        udf16CheckLength(rowdata, ruleMethods);
        // Utf17 must be alphanumeric"
        checkUdf17AlphaNumeric(rowdata, ruleMethods);

        udf17CheckLength(rowdata, ruleMethods);
        // Utf18 must be alphanumeric"
        checkUdf18AlphaNumeric(rowdata, ruleMethods);

        udf18CheckLength(rowdata, ruleMethods);
        // Utf19 must be alphanumeric"
        checkUdf19AlphaNumeric(rowdata, ruleMethods);

        udf19CheckLength(rowdata, ruleMethods);
        // Utf20 must be alphanumeric"
        checkUdf20AlphaNumeric(rowdata, ruleMethods);

        udf20CheckLength(rowdata, ruleMethods);

    }

    private void validEwayBillValidConpare(EWayBillDTO rowdata,EWayBillValidationUtil inwardRules) {
		if(inwardRules.isValidDocDate(rowdata.getEWayBillDate()) && inwardRules.isValidDocDate(rowdata.getEWayBillValidTill()) && !inwardRules.ifExceedDate(rowdata.getEWayBillDate(),rowdata.getEWayBillValidTill()))
		{
			markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00586);
		}
		
	}

	private void poNoAndPoDateCount(EWayBillDTO rowData, String[] poNoList, String[] poDateList) {
        if (poNoList.length != poDateList.length) {
            markErrorNAddErrorCode(rowData, ValidationConstants.ERROR_CODE_E00564);
        }
    }

    private void checkForPONumberSpecialChar(String poNo, EWayBillDTO rowdata, EWayBillValidationUtil inwardRules) {
        if (StringUtils.isNotBlank(poNo) && !inwardRules.isSpecialCharExistInEWayBillNo(poNo)) {

            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00260);

        }
    }

    private void checkForPurchaseOrderNumberLength(String poNo, EWayBillDTO rowdata) {
        if (StringUtils.isNotBlank(poNo) && poNo.length() > 50) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00259);
        }
    }

    private void markDocNoLevelError(EWayBillDTO rowData) {

        // Checking item level Error start
        String lineItemLevelErrorkey = new StringBuilder().append(rowData.getTaxpayerGstin())
                        .append(rowData.getVendorGstin()).append(rowData.getEWayBillNo())
                        .append(rowData.getEWayBillDate()).toString();

        if (duplicateRowMap.get(lineItemLevelErrorkey) == null) {
            duplicateRowMap.put(lineItemLevelErrorkey, 1);
        } else {
            duplicateRowMap.put(lineItemLevelErrorkey, duplicateRowMap.get(lineItemLevelErrorkey) + 1);

        }

    }

    private void isFpMatchWithFpList(EWayBillDTO rowdata, String[] fpList) {
        if (StringUtils.isBlank(rowdata.getFillingPeriod())
                        || Arrays.stream(fpList).noneMatch(rowdata.getFillingPeriod()::equalsIgnoreCase)) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00353);
        }

    }

    private void ifFpIsBlank(EWayBillDTO rowdata) {
        if (StringUtils.isBlank(rowdata.getFillingPeriod())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00352);

        }
    }

    private void checkifFpNotFuture(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {

        if (!StringUtils.isBlank(rowdata.getFillingPeriod()) && rowdata.getFillingPeriod().length() == 6
                        && rowdata.getFillingPeriod().matches("\\d+")
                        && ruleMethods.checkFuturePeriod(rowdata.getFillingPeriod())) {

            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00351);
        }

    }

    private void checkFpLength(EWayBillDTO rowdata) {
        boolean fp = StringUtils.isBlank(rowdata.getFillingPeriod());
        if (fp || rowdata.getFillingPeriod().length() != 6 || !rowdata.getFillingPeriod().matches("\\d+")) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00350);

        }

    }

    private void isTaxpayerGstinMatchWithList(EWayBillDTO rowdata, String[] eWayGstinListFromDB) {

        if (StringUtils.isBlank(rowdata.getTaxpayerGstin())
                        || Arrays.stream(eWayGstinListFromDB).noneMatch(rowdata.getTaxpayerGstin()::equalsIgnoreCase)) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00324);
        }

    }

    private void udf10CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf10()) && ruleMethods.checkUDFLength(rowdata.getUdf10())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00312);
        }
    }

    private void udf9CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf9()) && ruleMethods.checkUDFLength(rowdata.getUdf9())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00310);
        }
    }

    private void udf8CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf8()) && ruleMethods.checkUDFLength(rowdata.getUdf8())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00308);
        }
    }

    private void udf7CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf7()) && ruleMethods.checkUDFLength(rowdata.getUdf7())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00306);
        }
    }

    private void udf6CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf6()) && ruleMethods.checkUDFLength(rowdata.getUdf6())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00304);
        }
    }

    private void udf5CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf5()) && ruleMethods.checkUDFLength(rowdata.getUdf5())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00302);
        }
    }

    private void udf4CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf4()) && ruleMethods.checkUDFLength(rowdata.getUdf4())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00300);
        }
    }

    private void udf3CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf3()) && ruleMethods.checkUDFLength(rowdata.getUdf3())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00298);
        }
    }

    private void udf2CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf2()) && ruleMethods.checkUDFLength(rowdata.getUdf2())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00296);
        }
    }

    private void udf1CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf1()) && ruleMethods.checkUDFLength(rowdata.getUdf1())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00293);
        }
    }

    private void checkUdf10AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf10()) && !ruleMethods.isAlphanumeric(rowdata.getUdf10())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00311);
        }
    }

    private void checkUdf9AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf9()) && !ruleMethods.isAlphanumeric(rowdata.getUdf9())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00309);
        }
    }

    private void checkUdf8AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf8()) && !ruleMethods.isAlphanumeric(rowdata.getUdf8())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00307);
        }
    }

    private void checkUdf7AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf7()) && !ruleMethods.isAlphanumeric(rowdata.getUdf7())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00305);
        }
    }

    private void checkUdf6AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf6()) && !ruleMethods.isAlphanumeric(rowdata.getUdf6())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00303);
        }
    }

    private void checkUdf5AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf5()) && !ruleMethods.isAlphanumeric(rowdata.getUdf5())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00301);
        }
    }

    private void checkUdf4AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf4()) && !ruleMethods.isAlphanumeric(rowdata.getUdf4())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00299);
        }
    }

    private void checkUdf3AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf3()) && !ruleMethods.isAlphanumeric(rowdata.getUdf3())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00297);
        }
    }

    private void checkUdf2AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf2()) && !ruleMethods.isAlphanumeric(rowdata.getUdf2())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00295);
        }
    }

    private void checkUdf1AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf1()) && !ruleMethods.isAlphanumeric(rowdata.getUdf1())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00294);
        }
    }

    private void udf20CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf20()) && ruleMethods.checkUDFLength(rowdata.getUdf20())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00555);
        }
    }

    private void udf19CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf19()) && ruleMethods.checkUDFLength(rowdata.getUdf19())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00545);
        }
    }

    private void udf18CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf18()) && ruleMethods.checkUDFLength(rowdata.getUdf18())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00544);
        }
    }

    private void udf17CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf17()) && ruleMethods.checkUDFLength(rowdata.getUdf17())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00543);
        }
    }

    private void udf16CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf16()) && ruleMethods.checkUDFLength(rowdata.getUdf16())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00542);
        }
    }

    private void udf15CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf15()) && ruleMethods.checkUDFLength(rowdata.getUdf15())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00541);
        }
    }

    private void udf14CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf14()) && ruleMethods.checkUDFLength(rowdata.getUdf14())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00540);
        }
    }

    private void udf13CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf13()) && ruleMethods.checkUDFLength(rowdata.getUdf13())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00539);
        }
    }

    private void udf12CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf12()) && ruleMethods.checkUDFLength(rowdata.getUdf12())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00558);
        }
    }

    private void udf11CheckLength(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf11()) && ruleMethods.checkUDFLength(rowdata.getUdf11())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00537);
        }
    }

    private void checkUdf20AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf20()) && !ruleMethods.isAlphanumeric(rowdata.getUdf20())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00556);
        }
    }

    private void checkUdf19AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf19()) && !ruleMethods.isAlphanumeric(rowdata.getUdf19())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00554);
        }
    }

    private void checkUdf18AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf18()) && !ruleMethods.isAlphanumeric(rowdata.getUdf18())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00553);
        }
    }

    private void checkUdf17AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf17()) && !ruleMethods.isAlphanumeric(rowdata.getUdf17())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00552);
        }
    }

    private void checkUdf16AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf16()) && !ruleMethods.isAlphanumeric(rowdata.getUdf16())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00551);
        }
    }

    private void checkUdf15AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf15()) && !ruleMethods.isAlphanumeric(rowdata.getUdf15())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00550);
        }
    }

    private void checkUdf14AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf14()) && !ruleMethods.isAlphanumeric(rowdata.getUdf14())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00549);
        }
    }

    private void checkUdf13AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf13()) && !ruleMethods.isAlphanumeric(rowdata.getUdf13())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00548);
        }
    }

    private void checkUdf12AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf12()) && !ruleMethods.isAlphanumeric(rowdata.getUdf12())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00547);
        }
    }

    private void checkUdf11AlphaNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf11()) && !ruleMethods.isAlphanumeric(rowdata.getUdf11())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00546);
        }
    }

    private void poDateCannotExceedEWayDate(String poDate, EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(poDate) && StringUtils.isNotBlank(rowdata.getEWayBillDate())
                        && ruleMethods.isValidDocDate(poDate) && ruleMethods.isValidDocDate(rowdata.getEWayBillDate())
                        && !ruleMethods.ifExceedDate(poDate, rowdata.getEWayBillDate())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00282);
        }
    }

    private void poDateCannotFutureDate(String poDate, EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(poDate) && ruleMethods.isValidDocDate(poDate) && !ruleMethods.ifFutureDate(poDate)) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00291);
        }
    }

    private void poDateFormate(String poDate, EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(poDate) && StringUtils.isNotEmpty(poDate) && !ruleMethods.isValidDocDate(poDate)) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00289);
        }
    }

    private void vendorGstinCorrectFormat(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (ruleMethods.isGstinBlank(rowdata.getVendorGstin()) && !ruleMethods.validGSTIN(rowdata.getVendorGstin())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00287);
        }
    }

    private void isVendorGstinBlank(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (!ruleMethods.isGstinBlank(rowdata.getVendorGstin())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00276);
        }
    }

    private void eWayValidTillSpecialCharacter(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getEWayBillValidTill())
                        && !ruleMethods.isValidDocDate(rowdata.getEWayBillValidTill())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00281);
        }

    }

    private void eWayValidTill50Keywords(EWayBillDTO rowdata) {
        if (StringUtils.isNotBlank(rowdata.getEWayBillValidTill()) && rowdata.getEWayBillValidTill().length() > 50) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00280);
        }
    }

    private void eWayDateCanNotFutureDate(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods)
                    throws ParseException {
        if (ruleMethods.isDateEmpty(rowdata.getEWayBillDate()) && ruleMethods.isValidDocDate(rowdata.getEWayBillDate())
                        && !ruleMethods.ifFutureDate(rowdata.getEWayBillDate())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00292);
        }
    }

    private void eWayDateBefore1July2017(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (ruleMethods.isDateEmpty(rowdata.getEWayBillDate()) && ruleMethods.isValidDocDate(rowdata.getEWayBillDate())
                        && !ruleMethods.isValidDateRange(rowdata.getEWayBillDate())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00290);
        }
    }

    private void eWayDateFormat(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (ruleMethods.isDateEmpty(rowdata.getEWayBillDate())
                        && !ruleMethods.isValidDocDate(rowdata.getEWayBillDate())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00288);
        }
    }

    private void eWayDateBlank(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (!ruleMethods.isDateEmpty(rowdata.getEWayBillDate())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00279);
        }
    }

    private void eWayBill12DigitNumeric(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getEWayBillNo()) && !ruleMethods.onlyNumeric(rowdata.getEWayBillNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00278);
        }
    }

    private void eWayBillBlankOrMoreThan12Digit(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (!ruleMethods.checklenth12ebNo(rowdata.getEWayBillNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00277);
        }
    }

    private void isTaxpayerEqualsVendoeGstin(EWayBillDTO rowdata) {
        if (rowdata.getTaxpayerGstin().equals(rowdata.getVendorGstin())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00014);
        }
    }

    private void isValidTaxpayerGstin(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (ruleMethods.isGstinBlank(rowdata.getTaxpayerGstin())
                        && !ruleMethods.validGSTIN(rowdata.getTaxpayerGstin())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00286);
        }
    }

    private void isTaxpayerGstinBlank(EWayBillDTO rowdata, EWayBillValidationUtil ruleMethods) {
        if (!ruleMethods.isGstinBlank(rowdata.getTaxpayerGstin())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00114);
        }
    }

    // This function is call to add error messages in the EWayBillDTO fields.
    private void markErrorNAddErrorCode(EWayBillDTO rowdata, String errorCode) {

        rowdata.setErrorCodeList(rowdata.getErrorCodeList().append(errorCode));
        rowdata.setIsValid(0);
    }
//354
}
