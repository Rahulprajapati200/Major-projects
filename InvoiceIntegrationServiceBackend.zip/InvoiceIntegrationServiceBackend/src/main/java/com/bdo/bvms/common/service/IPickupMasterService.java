package com.bdo.bvms.common.service;

import java.util.LinkedHashMap;

public interface IPickupMasterService {
    
    LinkedHashMap<String, Integer> getPickupListDetailsMapSortOrder(String pickupMasterName);
    

}
