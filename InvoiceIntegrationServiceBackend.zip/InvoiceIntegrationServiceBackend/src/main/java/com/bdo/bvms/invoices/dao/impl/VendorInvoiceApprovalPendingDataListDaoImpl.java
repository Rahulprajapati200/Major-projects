package com.bdo.bvms.invoices.dao.impl;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceApprovalPendingDataListDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceSyncDataListDao;
import com.bdo.bvms.invoices.dto.ApprovalPendingResDTO;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.invoices.taxpayer.sql.MasterSQL;
import com.bdo.bvms.invoices.util.CommonUtils;
import com.bdo.bvms.invoices.util.EncryptionUtils;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class VendorInvoiceApprovalPendingDataListDaoImpl implements VendorInvoiceApprovalPendingDataListDao {

    @Autowired
    VendorInvoiceSyncDataListDao vendorInvoiceSyncDataListDao;

    @Autowired
    CommonDao commonDao;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Override
    public List<ApprovalPendingResDTO> getApprovalPendingDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {

        String appKey = jdbcTemplateMst.queryForObject(MasterSQL.GET_APP_KEY, String.class,
                        Constants.ENCRYPTION_APP_KEY);

        try {
            Map<String, String> screenAliasMap = commonDao.getSchreeAliasMap(vendorInvoiceRequestDTO);
            String whereCondition = CommonUtils.getWhereCondition(vendorInvoiceRequestDTO.getAdvanceFilter(),
                            screenAliasMap);
            Map<String, Object> out = commonDao.getGridDataForApprovalPending(vendorInvoiceRequestDTO, gstinNewList,
                            monthList, whereCondition);
            List<ApprovalPendingResDTO> dataResList = new ArrayList<>();
            int totalCount = ((List<Map<String, Long>>) out.get("#result-set-" + 1)).get(0).get("count").intValue();
            List<Map<String, Object>> results = (List<Map<String, Object>>) out.get("#result-set-" + 2);
            if (results.isEmpty()) {
                return dataResList;
            }

            results.forEach(u -> {
                String rejectedBy = "";

                try {
                    rejectedBy = EncryptionUtils.decrypt(appKey, (String) u.get("action_by"));
                } catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException
                                | NoSuchPaddingException | InvalidAlgorithmParameterException
                                | IllegalBlockSizeException | BadPaddingException | DecoderException e) {
                    log.error("error coming at the time of decription.");
                }
                ApprovalPendingResDTO dataRes = new ApprovalPendingResDTO();
                dataRes.setId(Integer.valueOf(u.get("id").toString()));
                dataRes.setTaxpayerGstin((String) u.get("taxpayer_gstin"));
                dataRes.setGetType((String) u.get("DataType"));
                dataRes.setEwayBillNo((String) u.get("eway_bill_no"));
                dataRes.setEwayBillDate((String) u.get("eway_bill_date"));
                dataRes.setInvoiceNo((String) u.get("invoice_no"));
                dataRes.setInvoiceDate((String) u.get("invoice_date"));
                dataRes.setVendorGstin((String) u.get("vendor_gstin"));
                dataRes.setVendorLegalName(checkNullValue((String) u.get("vendor_legal_name")));
                dataRes.setVendorTradeName(checkNullValue((String) u.get("vendor_trade_name")));
                dataRes.setUploadDate((LocalDateTime) u.get("details_upload_date"));
                dataRes.setUploadedBy(checkNullValue((String) u.get("UploadedBy")));
                dataRes.setDocumentStatus(checkNullValue((String) u.get("DocumentStatus")));
                dataRes.setBatchNo(checkNullValue((String) u.get("batch_no")));
                dataRes.setIsDuplicate(Integer.valueOf(u.get("IsDuplicate").toString()));
                dataRes.setWfMstId(Long.valueOf(u.get("wfrmID").toString()));

                dataRes.setRejectedBy(checkNullValue(rejectedBy));

                dataRes.setRejectedDate((LocalDateTime) u.get("responded_on"));
                dataRes.setFileType(checkNullValue((String) u.get("file_type")));
                dataRes.setDocType(checkNullValue((String) u.get("doc_type")));
                dataRes.setTotalCount(totalCount);
                dataRes.setPoNumber(checkNullValue((String) u.get("po_number")));
                dataRes.setGrnNumber(checkNullValue((String) u.get("grn_no")));
                dataRes.setVendorCodeErp(checkNullValue((String) u.get("vendor_code_erp")));

                dataResList.add(dataRes);

            });

            return dataResList;
        } catch (Exception e) {
            log.error("Error occures at the time of fetching data from database", e);
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATIONGRIDDATA);
            exceptionLogDTO.setFunctionName("getApprovalPendingDataList");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause(e.getCause().getMessage());
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming
            // in this function to getting data from database.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException("Error occures at the time of fetching data from database");

        }

    }

    private static String checkNullValue(String value) {
        if (StringUtils.isEmpty(value)) {
            return "-";
        } else {
            return value;
        }
    }

}
