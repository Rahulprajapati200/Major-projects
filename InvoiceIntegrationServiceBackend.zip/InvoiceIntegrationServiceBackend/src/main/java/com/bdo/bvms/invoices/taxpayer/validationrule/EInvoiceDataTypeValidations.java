
package com.bdo.bvms.invoices.taxpayer.validationrule;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.ValidationConstants;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;

public class EInvoiceDataTypeValidations {

    Map<String, Set<String>> docLevelError = new ConcurrentHashMap<>();
    private Logger logger = LoggerFactory.getLogger(EInvoiceDataTypeValidations.class);

    public void validateDataType(EInvoiceTemplateDTO rowdata, String[] fpList) {

        logger.info("Intering validateDataType");
        EInvoiceValidationUtil ruleMethods = new EInvoiceValidationUtil();
        String[] poDateList = new String[20];

        // that is to check if
        // gstin_of_recepint+Doc_no+Inward_no+Filling_Period+gstin_of_Supplier
        // is unique.

        checkForBlanckVendorGSTIN(rowdata);

        // check if it IsEmpty or Not
        checkInvoiceNo(rowdata, ruleMethods);

        checkFpLength(rowdata);
        // check if it is not a future period.
        checkifFpNotFuture(rowdata, ruleMethods);

        ifFpIsBlank(rowdata);

        inwardExceedsFP(rowdata, ruleMethods);

        if (fpList != null && fpList.length != 0) {
            isFpMatchWithFpList(rowdata, fpList);
        }

        // Check if Inward No. contains Comma
        checkSpecialCharInInvoiceNo(rowdata, ruleMethods);

        // check for 16 character in Inward No.
        check16CharacterLength(rowdata, ruleMethods);

        if (StringUtils.isNotBlank(rowdata.getPurchaseOrderDate())) {

            poDateList = rowdata.getPurchaseOrderDate().split(",");

        }

        Arrays.asList(poDateList).forEach(poDate -> {

            checkValidPurchaseOrderDate(poDate, rowdata, ruleMethods);

        });

        // IRN Date Validation
        // inwardDate should be in DD-MM-YYYY format"
        checkValidIrnDate(rowdata, ruleMethods);

        // "IRN must be 64 length
        checkValidIrnLength(rowdata);

        // irn must be alphanumeric"
        isIrnAlphanumeric(rowdata, ruleMethods);
        checkIrnIsEmpty(rowdata);

        // HSN Validation

        isHsnAlphaNumric(rowdata, ruleMethods);

        checkHsnCodeLength(rowdata);

        checkHsnCodeInvalid(rowdata);

        // Total Invoice Amount Validation
        checkTotalInvoiceAmountLength(rowdata, ruleMethods);
        // check numeric Invoice
        checkTotalInvoiceAmountNumericCheck(rowdata, ruleMethods);

        // total invoice amount check Number
        checkTotalInvoiceAmount2DeciamlCheck(rowdata, ruleMethods);

        // Utf1 must be alphanumeric"
        checkUdf1xAlphaNumeric(rowdata, ruleMethods);
        checkUdf1Length(rowdata, ruleMethods);
        // Utf2 must be alphanumeric"
        checkUdf2AlphaNumeric(rowdata, ruleMethods);
        checkUdf2Length(rowdata, ruleMethods);
        // Utf3 must be alphanumeric"
        checkUdf3AlphaNumeric(rowdata, ruleMethods);
        checkUdf3Length(rowdata, ruleMethods);
        // Utf4 must be alphanumeric"
        checkUdf4AlphaNumeric(rowdata, ruleMethods);
        checkUdf4Length(rowdata, ruleMethods);
        // Utf5 must be alphanumeric"
        checkUdf5AlphaNumeric(rowdata, ruleMethods);
        checkUdf5Length(rowdata, ruleMethods);
        // Utf6 must be alphanumeric"
        checkUdf6AlphaNumeric(rowdata, ruleMethods);
        checkUdf6Length(rowdata, ruleMethods);
        // Utf7 must be alphanumeric"
        checkUdf7AlphaNumeric(rowdata, ruleMethods);
        checkUdf7Length(rowdata, ruleMethods);
        // Utf8 must be alphanumeric"
        checkUdf8AlphaNumeric(rowdata, ruleMethods);
        checkUdf8Length(rowdata, ruleMethods);
        // Utf9 must be alphanumeric"
        checkUdf9AlphaNumeric(rowdata, ruleMethods);
        checkUdf9Length(rowdata, ruleMethods);
        // Utf10 must be alphanumeric"
        checkUdf10AlphaNumeric(rowdata, ruleMethods);
        checkUdf10Length(rowdata, ruleMethods);

        // Utf11 must be alphanumeric"
        checkUdf11xAlphaNumeric(rowdata, ruleMethods);
        checkUdf11Length(rowdata, ruleMethods);
        // Utf12 must be alphanumeric"
        checkUdf12AlphaNumeric(rowdata, ruleMethods);
        checkUdf12Length(rowdata, ruleMethods);
        // Utf13 must be alphanumeric"
        checkUdf13AlphaNumeric(rowdata, ruleMethods);
        checkUdf13Length(rowdata, ruleMethods);
        // Utf14 must be alphanumeric"
        checkUdf14AlphaNumeric(rowdata, ruleMethods);
        checkUdf14Length(rowdata, ruleMethods);
        // Utf15 must be alphanumeric"
        checkUdf15AlphaNumeric(rowdata, ruleMethods);
        checkUdf15Length(rowdata, ruleMethods);
        // Utf16 must be alphanumeric"
        checkUdf16AlphaNumeric(rowdata, ruleMethods);
        checkUdf16Length(rowdata, ruleMethods);
        // Utf17 must be alphanumeric"
        checkUdf17AlphaNumeric(rowdata, ruleMethods);
        checkUdf17Length(rowdata, ruleMethods);
        // Utf18 must be alphanumeric"
        checkUdf18AlphaNumeric(rowdata, ruleMethods);
        checkUdf18Length(rowdata, ruleMethods);
        // Utf19 must be alphanumeric"
        checkUdf19AlphaNumeric(rowdata, ruleMethods);
        checkUdf19Length(rowdata, ruleMethods);
        // Utf20 must be alphanumeric"
        checkUdf20AlphaNumeric(rowdata, ruleMethods);
        checkUdf20Length(rowdata, ruleMethods);

    }

    private void inwardExceedsFP(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {

        boolean fp = rowdata.getFillingPeriod().length() == 6 && rowdata.getFillingPeriod().matches("\\d+")
                        && StringUtils.isNotBlank(rowdata.getFillingPeriod())
                        && (ruleMethods.isValidInvoiceDate(rowdata.getInwardDate()));
        if (fp && ruleMethods.checkFPExceedsInwardDate(rowdata.getFillingPeriod(), rowdata.getInwardDate())) {

            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00356, "");
        }
    }

    private void checkForBlanckVendorGSTIN(EInvoiceTemplateDTO rowdata) {
        if (StringUtils.isBlank(rowdata.getGstinOfSupplier()) || "0".equals(rowdata.getGstinOfSupplier())
                        || StringUtils.isEmpty(rowdata.getGstinOfSupplier())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00276, Constants.BLANK);
        }
    }

    private void isFpMatchWithFpList(EInvoiceTemplateDTO rowdata, String[] fpList) {

        boolean fp = rowdata.getFillingPeriod().length() == 6 && rowdata.getFillingPeriod().matches("\\d+")
                        && StringUtils.isNotBlank(rowdata.getFillingPeriod());
        if (fp && Arrays.stream(fpList).noneMatch(rowdata.getFillingPeriod()::equalsIgnoreCase)) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00353, "");
        }

    }

    private void ifFpIsBlank(EInvoiceTemplateDTO rowdata) {
        if (StringUtils.isBlank(rowdata.getFillingPeriod()) || StringUtils.isEmpty(rowdata.getFillingPeriod())
                        || "0".equals(rowdata.getFillingPeriod())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00352, "");

        }
    }

    private void checkifFpNotFuture(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {

        boolean fp = StringUtils.isBlank(rowdata.getFillingPeriod()) && rowdata.getFillingPeriod().length() == 6
                        && rowdata.getFillingPeriod().matches("\\d+")
                        && StringUtils.isNotBlank(rowdata.getFillingPeriod());
        if (fp && ruleMethods.checkFuturePeriod(rowdata.getFillingPeriod())) {

            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00351, "");
        }

    }

    private void checkFpLength(EInvoiceTemplateDTO rowdata) {
        boolean fp = StringUtils.isNotBlank(rowdata.getFillingPeriod());
        if (fp && (rowdata.getFillingPeriod().length() != 6 || !rowdata.getFillingPeriod().matches("\\d+"))) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00350, "");

        }

    }

    private void checkIrnIsEmpty(EInvoiceTemplateDTO rowdata) {
        if ((StringUtils.isBlank(rowdata.getIrnDate()) || "0".equals(rowdata.getIrnDate()))
                        && StringUtils.isNotBlank(rowdata.getIrn())) {

            markErrorNAddErrorCode(rowdata, ValidationConstants.EWAY_ERROR_CODE_E00269, "");

        }

    }

    private void checkUdf10Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf10()) && ruleMethods.checkUDFLength(rowdata.getUdf10())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00311, "");
        }
    }

    private void checkUdf9Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf9()) && ruleMethods.checkUDFLength(rowdata.getUdf9())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00309, "");
        }
    }

    private void checkUdf8Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf8()) && ruleMethods.checkUDFLength(rowdata.getUdf8())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00307, "");
        }
    }

    private void checkUdf7Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf7()) && ruleMethods.checkUDFLength(rowdata.getUdf7())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00305, "");
        }
    }

    private void checkUdf6Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf6()) && ruleMethods.checkUDFLength(rowdata.getUdf6())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00303, "");
        }
    }

    private void checkUdf5Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf5()) && ruleMethods.checkUDFLength(rowdata.getUdf5())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00301, "");
        }
    }

    private void checkUdf4Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf4()) && ruleMethods.checkUDFLength(rowdata.getUdf4())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00299, "");
        }
    }

    private void checkUdf3Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf3()) && ruleMethods.checkUDFLength(rowdata.getUdf3())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00297, "");
        }
    }

    private void checkUdf2Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf2()) && ruleMethods.checkUDFLength(rowdata.getUdf2())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00295, "");
        }
    }

    private void checkUdf10AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf10()) && !ruleMethods.isAlphanumeric(rowdata.getUdf10())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00312, "");
        }
    }

    private void checkUdf9AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf9()) && !ruleMethods.isAlphanumeric(rowdata.getUdf9())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00310, "");
        }
    }

    private void checkUdf8AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf8()) && !ruleMethods.isAlphanumeric(rowdata.getUdf8())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00308, "");
        }
    }

    private void checkUdf7AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf7()) && !ruleMethods.isAlphanumeric(rowdata.getUdf7())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00306, "");
        }
    }

    private void checkUdf6AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf6()) && !ruleMethods.isAlphanumeric(rowdata.getUdf6())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00304, "");
        }
    }

    private void checkUdf5AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf5()) && !ruleMethods.isAlphanumeric(rowdata.getUdf5())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00301, "");
        }
    }

    private void checkUdf4AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf4()) && !ruleMethods.isAlphanumeric(rowdata.getUdf4())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00300, "");
        }
    }

    private void checkUdf3AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf3()) && !ruleMethods.isAlphanumeric(rowdata.getUdf3())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00298, "");
        }
    }

    private void checkUdf2AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf2()) && !ruleMethods.isAlphanumeric(rowdata.getUdf2())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00296, "");
        }
    }

    private void checkUdf1Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf1()) && ruleMethods.checkUDFLength(rowdata.getUdf1())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00293, "");
        }
    }

    private void checkUdf1xAlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf1()) && !ruleMethods.isAlphanumeric(rowdata.getUdf1())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00294, "");
        }
    }

    private void checkUdf20Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf20()) && ruleMethods.checkUDFLength(rowdata.getUdf20())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00555, "");
        }
    }

    private void checkUdf19Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf19()) && ruleMethods.checkUDFLength(rowdata.getUdf19())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00545, "");
        }
    }

    private void checkUdf18Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf18()) && ruleMethods.checkUDFLength(rowdata.getUdf18())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00544, "");
        }
    }

    private void checkUdf17Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf17()) && ruleMethods.checkUDFLength(rowdata.getUdf17())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00543, "");
        }
    }

    private void checkUdf16Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf16()) && ruleMethods.checkUDFLength(rowdata.getUdf16())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00542, "");
        }
    }

    private void checkUdf15Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf15()) && ruleMethods.checkUDFLength(rowdata.getUdf15())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00541, "");
        }
    }

    private void checkUdf14Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf14()) && ruleMethods.checkUDFLength(rowdata.getUdf14())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00540, "");
        }
    }

    private void checkUdf13Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf13()) && ruleMethods.checkUDFLength(rowdata.getUdf13())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00539, "");
        }
    }

    private void checkUdf12Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf12()) && ruleMethods.checkUDFLength(rowdata.getUdf12())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00558, "");
        }
    }

    private void checkUdf20AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf20()) && !ruleMethods.isAlphanumeric(rowdata.getUdf20())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00556, "");
        }
    }

    private void checkUdf19AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf19()) && !ruleMethods.isAlphanumeric(rowdata.getUdf19())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00554, "");
        }
    }

    private void checkUdf18AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf18()) && !ruleMethods.isAlphanumeric(rowdata.getUdf18())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00553, "");
        }
    }

    private void checkUdf17AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf17()) && !ruleMethods.isAlphanumeric(rowdata.getUdf17())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00552, "");
        }
    }

    private void checkUdf16AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf16()) && !ruleMethods.isAlphanumeric(rowdata.getUdf16())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00551, "");
        }
    }

    private void checkUdf15AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf15()) && !ruleMethods.isAlphanumeric(rowdata.getUdf15())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00550, "");
        }
    }

    private void checkUdf14AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf14()) && !ruleMethods.isAlphanumeric(rowdata.getUdf14())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00549, "");
        }
    }

    private void checkUdf13AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf13()) && !ruleMethods.isAlphanumeric(rowdata.getUdf13())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00548, "");
        }
    }

    private void checkUdf12AlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf12()) && !ruleMethods.isAlphanumeric(rowdata.getUdf12())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00547, "");
        }
    }

    private void checkUdf11Length(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf11()) && ruleMethods.checkUDFLength(rowdata.getUdf11())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00537, "");
        }
    }

    private void checkUdf11xAlphaNumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getUdf11()) && !ruleMethods.isAlphanumeric(rowdata.getUdf11())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00546, "");
        }
    }

    private void checkTotalInvoiceAmount2DeciamlCheck(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getTotalInvoiceValue())
                        && ruleMethods.onlyNumeric(rowdata.getTotalInvoiceValue())
                        && !ruleMethods.twoDecimalCheck(rowdata.getTotalInvoiceValue())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EINVOICE_ERROR_CODE_E00323, "");
        }
    }

    private void checkTotalInvoiceAmountNumericCheck(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getTotalInvoiceValue())
                        && !ruleMethods.onlyNumeric(rowdata.getTotalInvoiceValue())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EINVOICE_ERROR_CODE_E00153, "");
        }
    }

    private void checkTotalInvoiceAmountLength(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getTotalInvoiceValue())
                        && !ruleMethods.checkInvoiceLength13(rowdata.getTotalInvoiceValue())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EINVOICE_ERROR_CODE_E00273, "");

        }
    }

    private void checkHsnCodeLength(EInvoiceTemplateDTO rowdata) {
        if (StringUtils.isNotBlank(rowdata.getMainHSNCode()) && rowdata.getMainHSNCode().length() > 8) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EINVOICE_ERROR_CODE_E00098, "");
        }
    }

    private void checkHsnCodeInvalid(EInvoiceTemplateDTO rowdata) {
        if (StringUtils.isNotBlank(rowdata.getMainHSNCode()) && (rowdata.getMainHSNCode().length() < 4
                        || rowdata.getMainHSNCode().length() == 5 || rowdata.getMainHSNCode().length() == 7)) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EINVOICE_ERROR_CODE_E00097, "");
        }
    }

    private void isHsnAlphaNumric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getMainHSNCode())
                        && !ruleMethods.onlyNumericMainHsnCode(rowdata.getMainHSNCode())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00272, "");
        }
    }

    private void isIrnAlphanumeric(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getIrn()) && !ruleMethods.isAlphanumericwithoutSpace(rowdata.getIrn())) {
            logger.info("Checking getIrn No. Validation");
            markErrorNAddErrorCode(rowdata, ValidationConstants.EINVOICE_ERROR_CODE_I50119, "");
        }
    }

    private void checkValidIrnLength(EInvoiceTemplateDTO rowdata) {
        if ((rowdata.getIrn() != null) && (StringUtils.isNotBlank(rowdata.getIrn())) && (rowdata.getIrn().length() > 0)
                        && (rowdata.getIrn().length() != 64)) {
            logger.info("Checking IRN No. Validation");
            markErrorNAddErrorCode(rowdata, ValidationConstants.EINVOICE_ERROR_CODE_E00164, "");
        }
    }

    private void checkValidPurchaseOrderDate(String poDate, EInvoiceTemplateDTO rowdata,
                    EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(poDate) && !ruleMethods.isValidPurchaseOrderDate(poDate)) {
            logger.info("Checking  getPurchaseOrderDate Validation ");
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00316, "");
        }
    }

    private void checkValidIrnDate(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getIrnDate()) && !ruleMethods.isValidIRNDate(rowdata.getIrnDate())) {
            logger.info("Checking  getIrnDate Validation ");
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00319, "");
        }
    }

    private void check16CharacterLength(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (!ruleMethods.check16CharacterLength(rowdata.getInwardNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00322, "");
        }
    }

    private void checkSpecialCharInInvoiceNo(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (StringUtils.isNotBlank(rowdata.getInwardNo())
                        && !ruleMethods.isSpecialCharExistInInvoiceNo(rowdata.getInwardNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.ERROR_CODE_E00270, "");
        }
    }

    private void checkInvoiceNo(EInvoiceTemplateDTO rowdata, EInvoiceValidationUtil ruleMethods) {
        if (!ruleMethods.isInvoiceNoExist(rowdata.getInwardNo())) {
            markErrorNAddErrorCode(rowdata, ValidationConstants.EINVOICE_ERROR_CODE_E00030, "");
        }
    }

    void markErrorNAddErrorCode(EInvoiceTemplateDTO rowdata, String errorCode, String errorMsg) {

        logger.info("intering markErrorNAddErrorCode Method of ValidateDataType method");

        rowdata.setValid(false);
        rowdata.setErrorCodeList(rowdata.getErrorCodeList().append(errorCode));
        rowdata.setErrorDiscriptionList(rowdata.getErrorDiscriptionList().append(errorMsg));

    }

}
