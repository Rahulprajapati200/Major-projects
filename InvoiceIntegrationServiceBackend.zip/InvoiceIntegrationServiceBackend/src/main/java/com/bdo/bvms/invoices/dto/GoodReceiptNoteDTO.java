package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class GoodReceiptNoteDTO {

    String taxpayerGstin;
    String vendorGstin;
    String title;
    String grnNo;
    String grnDate;

}
