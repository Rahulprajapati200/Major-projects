package com.bdo.bvms.invoices.dao;

import org.springframework.data.domain.Page;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.RejectedResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface VendorInvoiceRejectedDataListDao {

    Page<RejectedResDTO> getRejectedDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
                    String monthList) throws VendorInvoiceServerException;

}
