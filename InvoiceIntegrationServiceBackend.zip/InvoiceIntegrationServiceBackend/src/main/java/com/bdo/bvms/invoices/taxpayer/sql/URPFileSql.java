package com.bdo.bvms.invoices.taxpayer.sql;

public class URPFileSql {
	
	private URPFileSql() {}
	
	public static final String INSERT_TO_URP_OCR_HEADER_TABLE = "INSERT INTO urp_ocr_header (taxpayer_gstin, vendor_gstin, vendor_pan_number, vendor_code_erp, booked_in_erp, docType, invoice_no, invoice_date,po_number, po_date, taxpayer_pan_number, batch_no, ul_filing_period, created_at, created_by,taxable_amount,total_inv_amount)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

}
