package com.bdo.bvms.invoices.ocr.repository.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.InvoiceOcrReviewConstant;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.ocr.dao.OcrStatusUpdateRequestDto;
import com.bdo.bvms.invoices.ocr.dao.UpdateOCRInvoiceDetailsReqDTO;
import com.bdo.bvms.invoices.ocr.model.OcrInvoiceHeader;
import com.bdo.bvms.invoices.ocr.model.OcrVerticalMap;
import com.bdo.bvms.invoices.ocr.repository.IInvoiceReviewRepository;
import com.bdo.bvms.invoices.vendor.sql.OcrInvoiceReviewSql;
import com.bdo.bvms.ocr.dto.VendorCodeAutoTagReqDto;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class InvoiceReviewRepositoryImpl implements IInvoiceReviewRepository {

    @Autowired
    private JdbcTemplate jdbcTemplateTrn;

    @Value("${txn.database-name}")
    private String trnDatabaseName;

    @Value("${mst.database-name}")
    private String mstDatabaseName;

    @Value("${spring.datasource.txn.jdbc-url}")
    String url;

    @Value("${spring.datasource.txn.username}")
    String userName;

    @Value("${spring.datasource.txn.password}")
    String password;

    @Override
    public List<OcrVerticalMap> getOcrInvoiceReviewData(int fileId, int pldTabId, String taxpayerGstin,
                    int countCheck) {
        if (countCheck > 0) {
            return jdbcTemplateTrn.query(OcrInvoiceReviewSql.getOcrInvoiceDataSql(mstDatabaseName),
                            new RowMapper<OcrVerticalMap>() {

                                public OcrVerticalMap mapRow(ResultSet rs, int rowNum) throws SQLException {
                                    return OcrVerticalMap.builder().id(rs.getInt("id")).lineNo(rs.getInt("line_no"))
                                                    .isHeader(rs.getInt("is_header")).name(rs.getString("name"))
                                                    .ocrExtractedValue(rs.getString("ocr_extracted_value"))
                                                    .ocrFieldMstId(rs.getInt("ocr_field_mst_id"))
                                                    .ocrVendorTemplateMstId(rs.getInt("ocr_vendor_template_mst_id"))
                                                    .minLength(rs.getInt("min_length"))
                                                    .maxLength(rs.getInt("max_length"))
                                                    .isMandatory(rs.getBoolean("is_mandatory"))
                                                    .regex(rs.getString("regex")).type(rs.getString("type"))
                                                    .order(rs.getInt("sort_order"))
                                                    .ocrAccuracyLvl(rs.getObject("ocr_accuracy_lvl") != null
                                                                    ? rs.getInt("ocr_accuracy_lvl")
                                                                    : null)
                                                    .ocrAccuracyLvlValue(rs.getObject("ocr_accuracy_lvl_value") != null
                                                                    ? rs.getInt("ocr_accuracy_lvl_value")
                                                                    : null)
                                                    .riskCategory(rs.getInt("risk_category"))
                                                    .pldType(rs.getInt("pld_type"))
                                                    .isAmountField(rs.getBoolean("is_amount_field")).build();
                                }
                            }, fileId, pldTabId, taxpayerGstin, InvoiceOcrReviewConstant.OCR_TAB_NAME,
                            InvoiceOcrReviewConstant.PLD_OCR_DATA_TYPE);
        } else {

            return jdbcTemplateTrn.query(OcrInvoiceReviewSql.getOcrInvoiceDataNewFileSql(mstDatabaseName),
                            new RowMapper<OcrVerticalMap>() {

                                public OcrVerticalMap mapRow(ResultSet rs, int rowNum) throws SQLException {
                                    return OcrVerticalMap.builder().id(rs.getInt("id")).lineNo(rs.getInt("line_no"))
                                                    .isHeader(rs.getInt("is_header")).name(rs.getString("name"))
                                                    .ocrExtractedValue(rs.getString("ocr_extracted_value"))
                                                    .ocrFieldMstId(rs.getInt("ocr_field_mst_id"))
                                                    .ocrVendorTemplateMstId(rs.getInt("ocr_vendor_template_mst_id"))
                                                    .minLength(rs.getInt("min_length"))
                                                    .maxLength(rs.getInt("max_length"))
                                                    .isMandatory(rs.getBoolean("is_mandatory"))
                                                    .regex(rs.getString("regex")).type(rs.getString("type"))
                                                    .ocrAccuracyLvl(rs.getObject("ocr_accuracy_lvl") != null
                                                                    ? rs.getInt("ocr_accuracy_lvl")
                                                                    : null)
                                                    .riskCategory(rs.getInt("risk_category"))
                                                    .pldType(rs.getInt("pld_type"))
                                                    .isAmountField(rs.getBoolean("is_amount_field")).build();
                                }
                            }, InvoiceOcrReviewConstant.OCR_TAB_NAME, taxpayerGstin, pldTabId);

        }
    }

    @Override
    public OcrVerticalMap getOcrVerticalMap(OcrVerticalMap ocrVerticalMap) {
        return jdbcTemplateTrn.queryForObject(OcrInvoiceReviewSql.GET_OCR_VERTICAL_MAP_SQL,
                        new RowMapper<OcrVerticalMap>() {

                            public OcrVerticalMap mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return OcrVerticalMap.builder().id(rs.getInt("id")).fileId(rs.getInt("file_id"))
                                                .ocrVendorTemplateMstId(rs.getInt("ocr_vendor_template_mst_id"))
                                                .ocrExtractedValue(rs.getString("ocr_extracted_value"))
                                                .isTaxpayer(rs.getInt("is_taxpayer"))
                                                .ocrFieldMstId(rs.getInt("ocr_field_mst_id"))
                                                .filePath(rs.getString("file_path")).build();

                            }

                        }, ocrVerticalMap.getFileId());
    }

    @Override
    public Map<Integer, String> getOcrInvoiceReviewVerticalFieldColumnMapping(OcrVerticalMap ocrVerticalMap) {

        return jdbcTemplateTrn.query(OcrInvoiceReviewSql.GET_OCR_VERTICAL_FIELD_COLUMN_MAPPING_SQL,
                        new ResultSetExtractor<Map<Integer, String>>() {

                            @Override
                            public Map<Integer, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                Map<Integer, String> mapRet = new HashMap<>();
                                while (rs.next()) {
                                    mapRet.put(rs.getInt("id"), rs.getString("columnDesc"));
                                }
                                return mapRet;
                            }
                        }, ocrVerticalMap.getFileId());
    }

    @Override
    public Integer updateOcrInvoiceDetails(String columnName, String values, String tableName)
                    throws VendorInvoiceServerException {
        return jdbcTemplateTrn.update(connection -> connection.prepareStatement(
                        OcrInvoiceReviewSql.getInsertOCRInvoiceDetailsSQL(columnName, values, tableName),
                        Statement.RETURN_GENERATED_KEYS)

        );
    }

    @Override
    public Map<Integer, String> getOcrInvoiceReviewMasterFieldColumnMapping() {
        return jdbcTemplateTrn.query(OcrInvoiceReviewSql.GET_OCR_MASTER_FIELD_COLUMN_MAPPING_SQL,
                        new ResultSetExtractor<Map<Integer, String>>() {

                            @Override
                            public Map<Integer, String> extractData(ResultSet rs)
                                            throws SQLException, DataAccessException {
                                Map<Integer, String> mapRet = new HashMap<>();
                                while (rs.next()) {
                                    mapRet.put(rs.getInt("id"), rs.getString("columnName"));
                                }
                                return mapRet;
                            }
                        });
    }

    @Override
    public OcrInvoiceHeader getInvoiceHeaderByFileId(OcrVerticalMap ocrVerticalMap) {
        return jdbcTemplateTrn.queryForObject(OcrInvoiceReviewSql.GET_OCR_INVOICE_HEADER_BY_FILEID,
                        new RowMapper<OcrInvoiceHeader>() {

                            public OcrInvoiceHeader mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return OcrInvoiceHeader.builder().id(rs.getInt("id"))
                                                .fileName(rs.getString("file_name")).docType(rs.getString("docType"))
                                                .fp(rs.getString("ul_filing_period")).fileType(rs.getString("ul_file_type"))
                                                .batchNo(rs.getString("batch_no")).pldOcrStatus(rs.getInt("pld_ocr_status"))
                                                .isTaxpayer(rs.getInt("is_taxpayer_uploaded"))
                                                .customerGstin(rs.getString("taxpayer_gstin")).build();

                            }
                        }, ocrVerticalMap.getFileId());
    }

    @Override
    public Integer insertOcrInvoiceHeaderArchive(OcrVerticalMap ocrVerticalMap) throws VendorInvoiceServerException {

        try {
            return jdbcTemplateTrn.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(
                                OcrInvoiceReviewSql.INSERT_OCR_INVOICE_HEADER_ARCHIVED_SQL,
                                Statement.RETURN_GENERATED_KEYS);
                ps.setObject(1, ocrVerticalMap.getFileId());
                return ps;
            });
        } catch (Exception e) {
            log.error("Error in insertOcrInvoiceHeaderArchive method: ", e);
            throw new VendorInvoiceServerException("Somethong went wrong , please contact to support team");
        }
    }

    @Override
    public Integer deleteOcrInvoiceHeader(OcrVerticalMap ocrVerticalMap) {
        return jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(OcrInvoiceReviewSql.DELETE_OCR_INVOICE_HEADER_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1, ocrVerticalMap.getFileId());
            return ps;
        });
    }

    @Override
    public Integer insertOcrInvoiceDetailsArchive(OcrVerticalMap ocrVerticalMap) {
        return jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                            OcrInvoiceReviewSql.INSERT_OCR_INVOICE_DETAILS_ARCHIVE_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1, ocrVerticalMap.getFileId());
            return ps;
        });
    }

    @Override
    public Integer deleteOcrInvoiceDetails(OcrVerticalMap ocrVerticalMap) {
        return jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(OcrInvoiceReviewSql.DELETE_OCR_INVOICE_DETAILS_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1, ocrVerticalMap.getFileId());
            return ps;
        });
    }

    @Override
    public Integer deleteComplianceValidations(OcrVerticalMap ocrVerticalMap) {
        return jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(OcrInvoiceReviewSql.DELETE_COMPLIANCE_VALIDATIONS_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1, ocrVerticalMap.getFileId());
            return ps;
        });
    }

    @Override
    public int[] updateOcrVerticalMap(List<Map<String, Object>> updatedValues) {

        return this.jdbcTemplateTrn.batchUpdate(OcrInvoiceReviewSql.UPDATE_OCR_VERTICAL_MAP,
                        new BatchPreparedStatementSetter() {

                            public void setValues(PreparedStatement ps, int i) throws SQLException {
                                String value = updatedValues.get(i).get(InvoiceOcrReviewConstant.UPDATED_VALUE) == null
                                                ? null
                                                : String.valueOf(updatedValues.get(i)
                                                                .get(InvoiceOcrReviewConstant.UPDATED_VALUE));
                                ps.setString(1, value);
                                ps.setInt(2, Integer.valueOf(updatedValues.get(i)
                                                .get(InvoiceOcrReviewConstant.VERTICAL_MAP_ID).toString()));
                            }

                            public int getBatchSize() {
                                return updatedValues.size();
                            }

                        });
    }

    @Override
    public Integer insertVerticalMapLineItemArchive(OcrVerticalMap ocrVerticalMap) {

        return jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                            OcrInvoiceReviewSql.INSERT_VERTICAL_MAP_LINE_ITEM_DETAILS_ARCHIVE_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1, ocrVerticalMap.getFileId());
            return ps;
        });
    }

    @Override
    public Integer deleteVerticalMapLineItemDetails(OcrVerticalMap ocrVerticalMap) {
        return jdbcTemplateTrn.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                            OcrInvoiceReviewSql.DELETE_VERTICAL_MAP_LINE_ITEM_DETAILS_SQL,
                            Statement.RETURN_GENERATED_KEYS);
            ps.setObject(1, ocrVerticalMap.getFileId());
            return ps;
        });
    }

    @Override
    public int[] insertUpdatedLineItemDetailsOcrVerticalMap(List<UpdateOCRInvoiceDetailsReqDTO> lineItemList,
                    OcrVerticalMap ocrVerticalMap) {

        return this.jdbcTemplateTrn.batchUpdate(OcrInvoiceReviewSql.INSERT_OCR_DETAILS_INTO_VERTICAL_MAP_SQL,
                        new BatchPreparedStatementSetter() {

                            public void setValues(PreparedStatement ps, int i) throws SQLException {
                                ps.setInt(1, ocrVerticalMap.getFileId());
                                ps.setInt(2, ocrVerticalMap.getOcrVendorTemplateMstId());
                                ps.setInt(3, lineItemList.get(i).getOcrFieldMstId());
                                ps.setString(4, lineItemList.get(i).getUpdatedValue());
                                ps.setInt(5, 100);
                                ps.setInt(6, ocrVerticalMap.getIsTaxpayer());
                                ps.setInt(7, lineItemList.get(i).getUserId());
                                ps.setString(8, ocrVerticalMap.getFilePath());
                                ps.setInt(9, 0);
                                ps.setInt(10, lineItemList.get(i).getLineNo());

                            }

                            public int getBatchSize() {
                                return lineItemList.size();
                            }

                        });
    }

    @Override
    public OcrVerticalMap getCommonDetailsVerticalMap(OcrVerticalMap ocrVerticalMap) {

        return jdbcTemplateTrn.queryForObject(OcrInvoiceReviewSql.GET_COMMON_DETAILS_VERTICAL_MAP_SQL,
                        new RowMapper<OcrVerticalMap>() {

                            public OcrVerticalMap mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return OcrVerticalMap.builder().fileId(rs.getInt("file_id"))
                                                .ocrVendorTemplateMstId(rs.getInt("ocr_vendor_template_mst_id"))
                                                .isTaxpayer(rs.getInt("is_taxpayer"))
                                                .filePath(rs.getString("file_path")).build();
                            }
                        }, ocrVerticalMap.getFileId());
    }

    @Override
    public int countCheckForNewFileOcr(int fileId) {
        return jdbcTemplateTrn.queryForObject(OcrInvoiceReviewSql.CHECK_OCR_DONE_BY_FILE_ID, int.class, fileId);
    }

    @Override
    public List<OcrVerticalMap> getLineItemRefernceObject(String gstin) {

        return jdbcTemplateTrn.query(OcrInvoiceReviewSql.GET_LINE_ITEM_REFERENCE_SQL, new RowMapper<OcrVerticalMap>() {

            public OcrVerticalMap mapRow(ResultSet rs, int rowNum) throws SQLException {
                return OcrVerticalMap.builder().id(null).lineNo(0).isHeader(0).name(rs.getString("name"))
                                .ocrExtractedValue(rs.getString("ocr_extracted_value"))
                                .ocrFieldMstId(rs.getInt("ocr_field_mst_id")).ocrVendorTemplateMstId(null)
                                .minLength(rs.getInt("min_length")).maxLength(rs.getInt("max_length"))
                                .isMandatory(rs.getBoolean("is_mandatory")).regex(rs.getString("regex")).type(null)
                                .ocrAccuracyLvl(0).riskCategory(0).order(rs.getInt("sort_order"))
                                .pldType(rs.getInt("pld_type")).isAmountField(rs.getBoolean("is_amount_field")).build();
            }
        }, gstin);

    }
    

    @Override
    public int[] insertOcrHeaderDetailsVerticalMap(List<UpdateOCRInvoiceDetailsReqDTO> dataList,
                    OcrVerticalMap ocrVerticalMap, int isHeader) {

        return this.jdbcTemplateTrn.batchUpdate(OcrInvoiceReviewSql.INSERT_OCR_DETAILS_INTO_VERTICAL_MAP_SQL,
                        new BatchPreparedStatementSetter() {

                            public void setValues(PreparedStatement ps, int i) throws SQLException {
                                ps.setInt(1, ocrVerticalMap.getFileId());
                                ps.setInt(2, dataList.get(i).getOcrVendorTemplateMstId());
                                ps.setInt(3, dataList.get(i).getOcrFieldMstId());
                                ps.setString(4, dataList.get(i).getUpdatedValue());
                                ps.setInt(5, 100);
                                ps.setInt(6, ocrVerticalMap.getIsTaxpayer());
                                ps.setInt(7, dataList.get(i).getUserId());
                                ps.setString(8, null);
                                ps.setInt(9, isHeader);
                                ps.setInt(10, dataList.get(i).getLineNo() == null ? 0 : dataList.get(i).getLineNo());

                            }

                            public int getBatchSize() {
                                return dataList.size();
                            }

                        });
    }

    @Override
    public Map<String, Object> ocrInvoiceStatusSubmission(OcrStatusUpdateRequestDto ocrStatusUpdateRequestDto,
                    String ocrStatus) throws VendorInvoiceServerException {
        Map<String, Object> resultSet = new HashMap<>();
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        try {
            resultSet = jdbcTemplateTrn.call(new CallableStatementCreator() {

                @Override
                public CallableStatement createCallableStatement(Connection con) throws SQLException {
                    CallableStatement cs = con.prepareCall(OcrInvoiceReviewSql.OCR_STATUS_SUBMISSION_PROC);
                    cs.setString(1, ocrStatusUpdateRequestDto.getIdList().stream().map(String::valueOf)
                                    .collect(Collectors.joining(",")));
                    cs.setString(2, ocrStatusUpdateRequestDto.getIsTaxpayer() == 0
                                    ? InvoiceOcrReviewConstant.VENDOR_JOURNEY
                                    : InvoiceOcrReviewConstant.TAXPAYER_JOURNEY);
                    cs.setInt(3, 1);
                    cs.setString(4, mstDatabaseName);
                    cs.setString(5, ocrStatus);

                    return cs;
                }
            }, parameters);
        } catch (Exception e) {
            throw new VendorInvoiceServerException("Somethong went wrong , please contact to support team");
        }
        return resultSet;

    }

    @Override
    public void updateOcrStatus(String ocrStatus, String ids, int userId, int action)
                    throws VendorInvoiceServerException {
        try {

            jdbcTemplateTrn.update(OcrInvoiceReviewSql.updateOcrStatus(ids), ocrStatus, 0,0);

            if (action == 3) {
                jdbcTemplateTrn.update(OcrInvoiceReviewSql.archiveInvoiceHeader(ids), userId, userId);
                jdbcTemplateTrn.update(OcrInvoiceReviewSql.deleteFromInvoiveHeader(ids));
            }

        } catch (Exception e) {
            log.error("updateOcrStatus::", e);
            throw new VendorInvoiceServerException("Somethong went wrong , please contact to support team");
        }

    }
    
    @Override
    public void markOcrAsRejected(String ids)
                    throws VendorInvoiceServerException {

            jdbcTemplateTrn.update(OcrInvoiceReviewSql.markOcrAsRejected(ids));

    }

    @Override
    public void updateOcrHeaderDetails(String columnName, String values, String tableName,
                    OcrVerticalMap ocrVerticalMap) throws SQLException {
        javax.sql.DataSource dataSource = jdbcTemplateTrn.getDataSource();

        if (dataSource != null) {
            String deleteSql = OcrInvoiceReviewSql.deleteOcrInvoiceHeaderSql(ocrVerticalMap.getFileId().toString());
            String insertSql = OcrInvoiceReviewSql.getInsertOCRInvoiceDetailsSQL(columnName, values, tableName);
            log.info(insertSql);
            Connection connection = dataSource.getConnection();
            try (PreparedStatement deleteStatement = connection.prepareStatement(deleteSql);
                            PreparedStatement insertStatement = connection.prepareStatement(insertSql);) {
                connection.setAutoCommit(false);
                deleteStatement.executeUpdate();
                insertStatement.executeUpdate();
                connection.commit();

            } catch (SQLException e) {
                log.error("Error occurred while establishing database connection.", e);
                connection.rollback();
            } finally {
                connection.close();
            }
        }

    }
    
    
    @Override
    public Map<String, Object> fetchVendorCodeForAutoTagging(VendorCodeAutoTagReqDto reqObj) {
        Map<String, Object> resultSet = new HashMap<>();
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        try {
            resultSet = jdbcTemplateTrn.call(new CallableStatementCreator() {

                @Override
                public CallableStatement createCallableStatement(Connection con) throws SQLException {
                    CallableStatement cs = con.prepareCall("call vendor_invoice_get_vendor_code_erp(?,?,?,?)");
                    cs.setString(1,reqObj.getTaxpayerGstin() );
                    cs.setString(2, reqObj.getVendorGstin());
                    cs.setString(3, reqObj.getVendorPan());
                    cs.setString(4, reqObj.getPoNo());
                    return cs;
                }
            }, parameters);
        } catch (Exception e) {
        	log.error(e.getMessage());
        }
        return resultSet;

    }

}
