package com.bdo.bvms.invoices.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ExceptionLogDTO {

    private String screenName;
    private String functionName;
    private String errorMessage;
    private String errorCause;
    private int lineNo;
    private int userId;
    private LocalDateTime createdAt;
    private LocalDateTime requestedAt;
    private LocalDateTime requestedBy;
}
