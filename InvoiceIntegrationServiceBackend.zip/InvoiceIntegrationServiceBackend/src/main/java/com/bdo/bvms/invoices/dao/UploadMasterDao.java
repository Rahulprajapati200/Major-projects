package com.bdo.bvms.invoices.dao;

import java.util.List;

import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.EWayBillDTO;

public interface UploadMasterDao {

    List<EInvoiceTemplateDTO> setErrorDiscription(List<EInvoiceTemplateDTO> errorDataListWithErrorCode);

    List<EWayBillDTO> getNewErrorList(List<EWayBillDTO> errorlist);

	String getFPYear(String fp);

}
