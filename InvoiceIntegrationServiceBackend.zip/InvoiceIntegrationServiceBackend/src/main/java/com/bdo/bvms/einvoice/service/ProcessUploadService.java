package com.bdo.bvms.einvoice.service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.text.ParseException;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.custom.exception.InvoiceTemplateUploadException;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.microsoft.azure.storage.StorageException;

/**
 * The Interface ProcessUploadService.
 */
public interface ProcessUploadService {

    /**
     * Process upload data N file.
     *
     * @param requestDTO
     *            the request DTO
     * @return the int
     * @throws BVMSException
     *             the BVMS exception
     * @throws InvalidKeyException
     *             the invalid key exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws URISyntaxException
     *             the URI syntax exception
     * @throws StorageException
     *             the storage exception
     * @throws BDOException
     *             the BDO exception
     * @throws ParseException
     *             the parse exception
     * @throws InvoiceTemplateUploadException
     * @throws Exception
     */

    String uploadAndProcessFile(UploadRequestDTO uploadRequestDTO) throws  VendorInvoiceServerException;

}
