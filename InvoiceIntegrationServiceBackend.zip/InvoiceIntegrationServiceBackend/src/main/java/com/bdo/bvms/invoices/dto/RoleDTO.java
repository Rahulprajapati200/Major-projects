package com.bdo.bvms.invoices.dto;

import java.util.Date;

public class RoleDTO extends BaseDTO {

    protected RoleDTO(String ipAddress, Long createdBy, Date createdDate, Long updatedBy, Date updatedDate) {
        super(ipAddress, createdBy, createdDate, updatedBy, updatedDate);

    }

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private Long roleId;
    private int no;
    private String roleName;
    private String description;
    private Integer authLevel;
    private String siteName;
    private String deptName;
    private String name;
    private String email;

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getAuthLevel() {
        return authLevel;
    }

    public void setAuthLevel(Integer authLevel) {
        this.authLevel = authLevel;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    private String role;
    private String pwd;

}
