package com.bdo.bvms.invoices.dao.impl;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.validation.Valid;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.VendorInvoiceConstants;
import com.bdo.bvms.invoices.dao.VendorInvoiceDetailsRepository;
import com.bdo.bvms.invoices.dto.EInvoiceDTO;
import com.bdo.bvms.invoices.dto.EWBViewDTO;
import com.bdo.bvms.invoices.dto.EWBViewResponseDTO;
import com.bdo.bvms.invoices.dto.EwayBillBasicInfoBillingAddressDTO;
import com.bdo.bvms.invoices.dto.EwayBillBasicInfoHeaderDTO;
import com.bdo.bvms.invoices.dto.EwayBillBasicInfoShipingAddressDTO;
import com.bdo.bvms.invoices.dto.EwayBillDetailDTO;
import com.bdo.bvms.invoices.dto.EwayBillIAdditionalInfoDTO;
import com.bdo.bvms.invoices.dto.EwayBillITransportDetaiLPartADTO;
import com.bdo.bvms.invoices.dto.EwayBillITransportDetaiLPartBDTO;
import com.bdo.bvms.invoices.dto.EwayBillItemDetailsHeaderDTO;
import com.bdo.bvms.invoices.dto.EwayBillItemDetailsListDTO;
import com.bdo.bvms.invoices.dto.GetEWayBillDTO;
import com.bdo.bvms.invoices.dto.GetEwayBillDetailsRequestDTO;
import com.bdo.bvms.invoices.dto.GetGstr2aDTO;
import com.bdo.bvms.invoices.dto.GetGstr2bDTO;
import com.bdo.bvms.invoices.dto.GoodReceiptNoteDTO;
import com.bdo.bvms.invoices.dto.Gstr2LineItemsDTO;
import com.bdo.bvms.invoices.dto.Gstr2aResponseDTO;
import com.bdo.bvms.invoices.dto.InvoiceDetailsReqDTO;
import com.bdo.bvms.invoices.dto.InvoicePrimaryDetail;
import com.bdo.bvms.invoices.dto.PurchaseOrderDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceGETRequestDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceGetResponseDTO;
import com.bdo.bvms.invoices.dto.WfApproveOrRejectDTO;
import com.bdo.bvms.invoices.taxpayer.sql.MasterSQL;
import com.bdo.bvms.invoices.taxpayer.sql.TransactionSQL;
import com.bdo.bvms.invoices.util.EncryptionUtils;
import com.bdo.bvms.ocr.dto.OcrDetail;

import lombok.extern.slf4j.Slf4j;

// TODO: Auto-generated Javadoc
/** The Constant log. */
@Slf4j
@Repository
public class VendorInvoiceDetailsRepositoryImpl implements VendorInvoiceDetailsRepository {

    /** The jdbc template trn. */
    @Autowired
    private JdbcTemplate jdbcTemplateTrn;

    /** The mst db. */
    @Value("${mst.database-name}")
    String mstDb;

    /** The jdbc template mst. */
    @Autowired
    JdbcTemplate jdbcTemplateMst;

    String mailTo = "";

    /**
     * Gets the e invoice details.
     *
     * @param invoiceDetailsReqDTO
     * 
     *            the invoice details req DTO
     * @return the e invoice details
     */
    @Override
    public EInvoiceDTO getEInvoiceDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {

        try {
            if (!StringUtils.isBlank(invoiceDetailsReqDTO.getInvoiceno())) {

                // SEARCH_VENDOR_EINVOICE_DETAILS_SQL
                if ("4".equalsIgnoreCase(invoiceDetailsReqDTO.getTabId())) {
                    return jdbcTemplateTrn.queryForObject(TransactionSQL.SEARCH_VENDOR_EINVOICE_DETAILS_SQL,
                                    BeanPropertyRowMapper.newInstance(EInvoiceDTO.class),
                                    invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                                    invoiceDetailsReqDTO.getInvoiceno(), invoiceDetailsReqDTO.getInvoicedate());
                } else if ("5".equalsIgnoreCase(invoiceDetailsReqDTO.getTabId())) {
                    return jdbcTemplateTrn.queryForObject(TransactionSQL.SEARCH_VENDOR_EINVOICE_DETAILS_SQL,
                                    BeanPropertyRowMapper.newInstance(EInvoiceDTO.class),
                                    invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                                    invoiceDetailsReqDTO.getInvoiceno(), invoiceDetailsReqDTO.getInvoicedate());
                } 
                else if ("7".equals(invoiceDetailsReqDTO.getTabId()) && invoiceDetailsReqDTO.getOcrHeaderId() == 0) {
                	return jdbcTemplateTrn.queryForObject(TransactionSQL.SEARCH_URP_INVOICE_DETAILS_SQL,
                            BeanPropertyRowMapper.newInstance(EInvoiceDTO.class),
                            invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorPan(),
                            invoiceDetailsReqDTO.getInvoiceno(), invoiceDetailsReqDTO.getVendorCodeErp());
                 }
                else {

                    return jdbcTemplateTrn.queryForObject(TransactionSQL.SEARCH_EINVOICE_DETAILS_SQL,
                                    BeanPropertyRowMapper.newInstance(EInvoiceDTO.class),
                                    invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                                    invoiceDetailsReqDTO.getInvoiceno(), invoiceDetailsReqDTO.getInvoicedate());

                }
            } else {
                return new EInvoiceDTO();
            }

        } catch (Exception e) {
            log.error("Error occured while execute getEInvoiceDetails function:", e);
            return new EInvoiceDTO();
        }
    }

    /**
     * Gets the eway bill details.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the eway bill details
     */
    @Override
    public EwayBillDetailDTO getEwayBillDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {

        try {
            if (!StringUtils.isBlank(invoiceDetailsReqDTO.getEwbno())) {
                if ("4".equals(invoiceDetailsReqDTO.getTabId())) {
                    return jdbcTemplateTrn.queryForObject(TransactionSQL.SEARCH_VENDOR_EWAYBILL_DETAILS_SQL,
                                    BeanPropertyRowMapper.newInstance(EwayBillDetailDTO.class),
                                    invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                                    invoiceDetailsReqDTO.getEwbno(), invoiceDetailsReqDTO.getEwbdate());
                } else if ("5".equals(invoiceDetailsReqDTO.getTabId())) {
                    return jdbcTemplateTrn.queryForObject(TransactionSQL.SEARCH_VENDOR_EWAYBILL_DETAILS_SQL,
                                    BeanPropertyRowMapper.newInstance(EwayBillDetailDTO.class),
                                    invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                                    invoiceDetailsReqDTO.getEwbno(), invoiceDetailsReqDTO.getEwbdate());
                } 
                else if ("7".equals(invoiceDetailsReqDTO.getTabId())) {
                	 return new EwayBillDetailDTO();
                }else {
                    return jdbcTemplateTrn.queryForObject(TransactionSQL.SEARCH_EWAYBILL_DETAILS_SQL,
                                    BeanPropertyRowMapper.newInstance(EwayBillDetailDTO.class),
                                    invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                                    invoiceDetailsReqDTO.getEwbno(), invoiceDetailsReqDTO.getEwbdate());
                }

            } else {
                return new EwayBillDetailDTO();
            }

        } catch (Exception e) {
            log.error("Error occured while execute getEwayBillDetails function:", e.getMessage());
            return new EwayBillDetailDTO();
        }

    }

    /**
     * Gets the purchase order details.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the purchase order details
     */
    @Override
    public PurchaseOrderDTO getPurchaseOrderDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {

        Map<String, Object> poDetails = getPoDetailDb(invoiceDetailsReqDTO);

        PurchaseOrderDTO dataRes = new PurchaseOrderDTO();
        List<Map<String, Object>> results = (List<Map<String, Object>>) poDetails.get("#result-set-" + 1);
        if (results.isEmpty()) {
            return dataRes;
        }

        results.forEach(u -> {

            dataRes.setPoDate((String) u.get("purchase_order_date"));
            dataRes.setPoNo((String) u.get("purchase_order_no"));
            dataRes.setTaxpayerGstin((String) u.get("gstin_uin_of_recipient"));
            dataRes.setVendorGstin((String) u.get("gstin_of_supplier"));

        });

        return dataRes;
    }

    private Map<String, Object> getPoDetailDb(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall("{call vendor_invoice_po(?,?,?,?,?)}");
                cs.setString(1, invoiceDetailsReqDTO.getTaxpayerGstin());
                cs.setString(2, invoiceDetailsReqDTO.getVendorGstin());
                cs.setString(3, invoiceDetailsReqDTO.getInvoiceno());
                cs.setString(4, invoiceDetailsReqDTO.getInvoicedate());
                cs.setString(5, invoiceDetailsReqDTO.getId());
                return cs;
            }
        }, parameters);

    }

    /**
     * Gets the good receipt note details.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the good receipt note details
     */
    @Override
    public GoodReceiptNoteDTO getGoodReceiptNoteDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {

        Map<String, Object> grnDetails = getGRNDetail(invoiceDetailsReqDTO);

        GoodReceiptNoteDTO dataRes = new GoodReceiptNoteDTO();
        List<Map<String, Object>> results = (List<Map<String, Object>>) grnDetails.get("#result-set-" + 1);
        if (results.isEmpty()) {
            return dataRes;
        }

        results.forEach(u -> {

            dataRes.setGrnDate((String) u.get("grn_date"));
            dataRes.setGrnNo((String) u.get("grn_no"));
            dataRes.setTaxpayerGstin((String) u.get("taxpayer_gstin"));
            dataRes.setVendorGstin((String) u.get("vendor_gstin"));

        });

        return dataRes;

    }

    private Map<String, Object> getGRNDetail(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall("{call vendor_invoice_GRN(?,?,?,?,?)}");
                cs.setString(1, invoiceDetailsReqDTO.getTaxpayerGstin());
                cs.setString(2, invoiceDetailsReqDTO.getVendorGstin());
                cs.setString(3, invoiceDetailsReqDTO.getInvoiceno());
                cs.setString(4, invoiceDetailsReqDTO.getInvoicedate());
                cs.setString(5, invoiceDetailsReqDTO.getId());
                return cs;
            }
        }, parameters);

    }

    /**
     * Gets the gets the gstr 2 a details.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the gets the gstr 2 a details
     */
    @Override
    public GetGstr2aDTO getGetGstr2aDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {

        try {
        	if ("7".equals(invoiceDetailsReqDTO.getTabId())) {
              	 return new GetGstr2aDTO();
                }
            return jdbcTemplateTrn.queryForObject(TransactionSQL.getGstr2aDetails(invoiceDetailsReqDTO),
                            BeanPropertyRowMapper.newInstance(GetGstr2aDTO.class),
                            invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                            invoiceDetailsReqDTO.getInvoiceno(), invoiceDetailsReqDTO.getInvoicedate(),
                            Constants.GET_GSTR2A_PLD_CODE);
        } catch (Exception e) {
            log.error("Error occured while execute getGetGstr2aDetails function:", e.getMessage());
            return new GetGstr2aDTO();
        }
    }

    /**
     * Gets the gets the gstr 2 b details.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the gets the gstr 2 b details
     */
    @Override
    public GetGstr2bDTO getGetGstr2bDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {
        try {
        	if ("7".equals(invoiceDetailsReqDTO.getTabId())) {
             	 return new GetGstr2bDTO();
               }
            return jdbcTemplateTrn.queryForObject(TransactionSQL.getGstr2bDetailsSql(invoiceDetailsReqDTO),
                            BeanPropertyRowMapper.newInstance(GetGstr2bDTO.class),
                            invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                            invoiceDetailsReqDTO.getInvoiceno(), invoiceDetailsReqDTO.getInvoicedate(),
                            Constants.GET_GSTR2B_PLD_CODE);
        } catch (Exception e) {
            log.error("Error occured while execute getGetGstr2bDetails function:", e.getMessage());
            return new GetGstr2bDTO();
        }
    }

    /**
     * Gets the gets the gstr 2 b details.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the gets the gstr 2 b details
     */
    @Override
    public OcrDetail getOcrDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {
        try {

            return jdbcTemplateTrn.queryForObject(TransactionSQL.GET_OCR_DETAIL_FROM_OCR_HEADER,
                            BeanPropertyRowMapper.newInstance(OcrDetail.class), invoiceDetailsReqDTO.getOcrHeaderId());
        } catch (Exception e) {
            log.error("Error occured while execute getOcrDetails function:", e.getMessage());
            return new OcrDetail();
        }
    }

    /**
     * Gets the gstr2a details.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the gstr2a details
     */
    @Override
    public List<Gstr2aResponseDTO> getGstr2aDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {

        try {
            return jdbcTemplateTrn.query(TransactionSQL.searchGstr2aDetailsSql(invoiceDetailsReqDTO.getDetailType()),
                            BeanPropertyRowMapper.newInstance(Gstr2aResponseDTO.class),
                            invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getFp(),
                            invoiceDetailsReqDTO.getCategory(), invoiceDetailsReqDTO.getVendorGstin(),
                            invoiceDetailsReqDTO.getInvoiceno(), invoiceDetailsReqDTO.getInvoicedate(),
                            invoiceDetailsReqDTO.getSize(),
                            invoiceDetailsReqDTO.getPage() * invoiceDetailsReqDTO.getSize());
        } catch (Exception e) {
            log.error("Error occured while execute getGstr2aDetails function:", e.getMessage());
            return Collections.emptyList();
        }
    }

    /**
     * Gets the gets the E way bill details.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the gets the E way bill details
     */
    @Override
    public GetEWayBillDTO getGetEWayBillDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {
        try {
        	if ("7".equals(invoiceDetailsReqDTO.getTabId())) {
             	 return new GetEWayBillDTO();
               }
            return jdbcTemplateTrn.queryForObject(TransactionSQL.searchEwayBillSql(invoiceDetailsReqDTO),
                            BeanPropertyRowMapper.newInstance(GetEWayBillDTO.class),
                            invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                            invoiceDetailsReqDTO.getInvoiceno(), invoiceDetailsReqDTO.getInvoicedate(),
                            Constants.GET_EWAYBILL_PLD_CODE);
        } catch (Exception e) {
            log.error("Error occured while execute getGetEWayBillDetails function:", e.getMessage());
            return new GetEWayBillDTO();
        }
    }

    /**
     * 6 Gets the gstr 2 a line items list.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the gstr 2 a line items list
     */
    @Override
    public List<Gstr2LineItemsDTO> getGstr2aLineItemsList(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {

        return jdbcTemplateTrn.query(TransactionSQL.searchGstr2aLineItemsSql(invoiceDetailsReqDTO.getTabId()),
                        BeanPropertyRowMapper.newInstance(Gstr2LineItemsDTO.class),
                        invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                        invoiceDetailsReqDTO.getInvoiceno(), invoiceDetailsReqDTO.getInvoicedate(),
                        invoiceDetailsReqDTO.getId(), invoiceDetailsReqDTO.getSize(),
                        invoiceDetailsReqDTO.getPage() * invoiceDetailsReqDTO.getSize());

    }

    /**
     * Gets the count gstr 2 a line items.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the count gstr 2 a line items
     */
    @Override
    public int getCountGstr2aLineItems(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {

        return jdbcTemplateTrn.queryForObject(
                        TransactionSQL.getCountGstr2aLineItemsSql(invoiceDetailsReqDTO.getDetailType()), Integer.class,
                        invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getFp(),
                        invoiceDetailsReqDTO.getCategory(), invoiceDetailsReqDTO.getVendorGstin(),
                        invoiceDetailsReqDTO.getInvoiceno(), invoiceDetailsReqDTO.getInvoicedate());

    }

    /**
     * Gets the gstr 2 b line items list.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the gstr 2 b line items list
     */
    @Override
    public List<Gstr2LineItemsDTO> getGstr2bLineItemsList(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {

        return jdbcTemplateTrn.query(TransactionSQL.searchGstr2bLineItemsSql(invoiceDetailsReqDTO.getTabId()),
                        BeanPropertyRowMapper.newInstance(Gstr2LineItemsDTO.class),
                        invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                        invoiceDetailsReqDTO.getInvoiceno(), invoiceDetailsReqDTO.getInvoicedate(),
                        invoiceDetailsReqDTO.getId(), invoiceDetailsReqDTO.getSize(),
                        invoiceDetailsReqDTO.getPage() * invoiceDetailsReqDTO.getSize());

    }

    /**
     * Gets the count gstr 2 b line items.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the count gstr 2 b line items
     */
    @Override
    public int getCountGstr2bLineItems(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {

        return jdbcTemplateTrn.queryForObject(
                        TransactionSQL.getCountGstr2bLineItemsSql(invoiceDetailsReqDTO.getTabId()), Integer.class,
                        invoiceDetailsReqDTO.getTaxpayerGstin(), invoiceDetailsReqDTO.getVendorGstin(),
                        invoiceDetailsReqDTO.getInvoiceno(), invoiceDetailsReqDTO.getInvoicedate(),
                        invoiceDetailsReqDTO.getId());

    }

    /**
     * Gets the eway bill basic info bill to details.
     *
     * @param ewbNo
     *            the ewb no
     * @return the eway bill basic info bill to details
     */
    @Override
    public EwayBillBasicInfoBillingAddressDTO getEwayBillBasicInfoBillToDetails(String ewbNo) {

        try {
            return jdbcTemplateTrn.queryForObject(TransactionSQL.GET_EWAYBILL_BASIC_INFO_BILL_TO(mstDb),
                            BeanPropertyRowMapper.newInstance(EwayBillBasicInfoBillingAddressDTO.class), ewbNo);
        } catch (Exception e) {
            log.error("Error occured while execute getEwayBillBasicInfoBillToDetails function:", e.getMessage());
            return null;
        }

    }

    /**
     * Gets the eway bill basic info bill from details.
     *
     * @param ewbNo
     *            the ewb no
     * @return the eway bill basic info bill from details
     */
    @Override
    public EwayBillBasicInfoBillingAddressDTO getEwayBillBasicInfoBillFromDetails(String ewbNo) {

        try {
            return jdbcTemplateTrn.queryForObject(TransactionSQL.GET_EWAYBILL_BASIC_INFO_BILL_FROM(mstDb),
                            BeanPropertyRowMapper.newInstance(EwayBillBasicInfoBillingAddressDTO.class), ewbNo);
        } catch (Exception e) {
            log.error("Error occured while execute getEwayBillBasicInfoBillFromDetails function:", e.getMessage());
            return null;
        }

    }

    /**
     * Gets the eway bill basic info dispatch from details.
     *
     * @param ewbNo
     *            the ewb no
     * @return the eway bill basic info dispatch from details
     */
    @Override
    public EwayBillBasicInfoShipingAddressDTO getEwayBillBasicInfoDispatchFromDetails(String ewbNo) {

        try {
            return jdbcTemplateTrn.queryForObject(TransactionSQL.GET_EWAYBILL_BASIC_INFO_DISPATCH_FROM(mstDb),
                            BeanPropertyRowMapper.newInstance(EwayBillBasicInfoShipingAddressDTO.class), ewbNo);
        } catch (Exception e) {
            log.error("Error occured while execute getEwayBillBasicInfoDispatchFromDetails function:", e.getMessage());
            return null;
        }

    }

    /**
     * Gets the eway bill basic info ship to details.
     *
     * @param ewbNo
     *            the ewb no
     * @return the eway bill basic info ship to details
     */
    @Override
    public EwayBillBasicInfoShipingAddressDTO getEwayBillBasicInfoShipToDetails(String ewbNo) {

        try {
            return jdbcTemplateTrn.queryForObject(TransactionSQL.GET_EWAYBILL_BASIC_INFO_SHIP_TO(mstDb),
                            BeanPropertyRowMapper.newInstance(EwayBillBasicInfoShipingAddressDTO.class), ewbNo);
        } catch (Exception e) {
            log.error("Error occured while execute getEwayBillBasicInfoShipToDetails function:", e.getMessage());
            return null;
        }

    }

    /**
     * Gets the eway bill item details header data.
     *
     * @param ewbNo
     *            the ewb no
     * @return the eway bill item details header data
     */
    @Override
    public EwayBillItemDetailsHeaderDTO getEwayBillItemDetailsHeaderData(String ewbNo) {

        try {
            return jdbcTemplateTrn.queryForObject(TransactionSQL.GET_EWAYBILL_ITEM_DETAILS_HEADER_DATA,
                            BeanPropertyRowMapper.newInstance(EwayBillItemDetailsHeaderDTO.class), ewbNo);
        } catch (Exception e) {
            log.error("Error occured while execute getEwayBillItemDetailsHeaderData function:", e.getMessage());
            return null;
        }
    }

    /**
     * Gets the eway bill item details list data.
     *
     * @param getEwayBillDetailsRequestDTO
     *            the get eway bill details request DTO
     * @return the eway bill item details list data
     */
    @Override
    public List<EwayBillItemDetailsListDTO> getEwayBillItemDetailsListData(
                    GetEwayBillDetailsRequestDTO getEwayBillDetailsRequestDTO) {

        return jdbcTemplateTrn.query(TransactionSQL.GET_EWAYBILL_ITEM_DETAILS_LIST,
                        BeanPropertyRowMapper.newInstance(EwayBillItemDetailsListDTO.class),
                        getEwayBillDetailsRequestDTO.getEwaybillNo(), getEwayBillDetailsRequestDTO.getSize(),
                        getEwayBillDetailsRequestDTO.getPage() * getEwayBillDetailsRequestDTO.getSize());

    }

    /**
     * Gets the eway bill item details list data count.
     *
     * @param getEwayBillDetailsRequestDTO
     *            the get eway bill details request DTO
     * @return the eway bill item details list data count
     */
    @Override
    public int getEwayBillItemDetailsListDataCount(GetEwayBillDetailsRequestDTO getEwayBillDetailsRequestDTO) {

        return jdbcTemplateTrn.queryForObject(TransactionSQL.GET_EWAYBILL_ITEM_DETAILS_LIST_COUNT, int.class,
                        getEwayBillDetailsRequestDTO.getEwaybillNo());

    }

    /**
     * Gets the eway bill I transport detai L part A data.
     *
     * @param ewbNo
     *            the ewb no
     * @return the eway bill I transport detai L part A data
     */
    @Override
    public EwayBillITransportDetaiLPartADTO getEwayBillITransportDetaiLPartAData(String ewbNo) {

        try {
            return jdbcTemplateTrn.queryForObject(TransactionSQL.GET_EWAYBILL_TRANSPORT_DETAIL_PARTA(mstDb),
                            BeanPropertyRowMapper.newInstance(EwayBillITransportDetaiLPartADTO.class), ewbNo);
        } catch (Exception e) {
            log.error("Error occured while execute getEwayBillITransportDetaiLPartAData function:", e.getMessage());
            return null;
        }
    }

    /**
     * Gets the eway bill I transport detai L part B data.
     *
     * @param ewbNo
     *            the ewb no
     * @return the eway bill I transport detai L part B data
     */
    @Override
    public EwayBillITransportDetaiLPartBDTO getEwayBillITransportDetaiLPartBData(String ewbNo) {

        try {
            return jdbcTemplateTrn.queryForObject(TransactionSQL.GET_EWAYBILL_TRANSPORT_DETAIL_PARTB,
                            BeanPropertyRowMapper.newInstance(EwayBillITransportDetaiLPartBDTO.class), ewbNo);
        } catch (Exception e) {
            log.error("Error occured while execute getEwayBillITransportDetaiLPartBData function:", e.getMessage());
            return null;
        }
    }

    /**
     * Gets the eway bill I additional info data.
     *
     * @param ewbNo
     *            the ewb no
     * @return the eway bill I additional info data
     */
    @Override
    public EwayBillIAdditionalInfoDTO getEwayBillIAdditionalInfoData(String ewbNo) {

        try {
            return jdbcTemplateTrn.queryForObject(TransactionSQL.GET_EWAYBILL_ADDITIONAL_INFO,
                            BeanPropertyRowMapper.newInstance(EwayBillIAdditionalInfoDTO.class), ewbNo);
        } catch (Exception e) {
            log.error("Error occured while execute getEwayBillIAdditionalInfoData function:", e.getMessage());
            return null;
        }
    }

    /**
     * Gets the gets the existing EW bdetails.
     *
     * @param vendorInvoiceGETRequestDTO
     *            the vendor invoice GET request DTO
     * @return the gets the existing EW bdetails
     */
    @Override
    public List<VendorInvoiceGetResponseDTO> getGetExistingEWBdetails(
                    VendorInvoiceGETRequestDTO vendorInvoiceGETRequestDTO) {

        try {

            Map<String, Object> out = getExistingEWBDetails(vendorInvoiceGETRequestDTO);
            List<VendorInvoiceGetResponseDTO> dataResList = new ArrayList<>();
            List<Map<String, Object>> results = (List<Map<String, Object>>) out.get("#result-set-" + 1);
            if (results.isEmpty()) {
                return null;
            }

            for (Map<?, ?> u : results) {

                VendorInvoiceGetResponseDTO dataRes = new VendorInvoiceGetResponseDTO();
                dataRes.setId((int) u.get("id"));
                dataRes.setName((String) u.get("name"));
                dataRes.setCallOn((LocalDateTime) u.get("call_on"));
                dataRes.setErrorCount(String.valueOf(u.get("error_count")));
                dataRes.setInprogressCount(String.valueOf(u.get("inprogress_count")));
                dataRes.setSuccessCount(String.valueOf(u.get("success_count")));
                dataRes.setRequestedBy(String.valueOf(u.get("requested_by")));
                dataRes.setTotalElementsCount((int) u.get("total_count"));
                dataRes.setEwaybillDate((String) u.get("eway_bill_date"));
                dataResList.add(dataRes);
            }
            return dataResList;

        } catch (Exception e) {
            log.error("Error occured while execute getGetExistingEWBdetails function:", e.getMessage());
            return null;
        }
    }

    /**
     * Gets the gets the eway bill on UI count.
     *
     * @param vendorInvoiceGETRequestDTO
     *            the vendor invoice GET request DTO
     * @return the gets the eway bill on UI count
     */
    @Override
    public int getGetEwayBillOnUICount(VendorInvoiceGETRequestDTO vendorInvoiceGETRequestDTO) {

        try {
            String sql = TransactionSQL.getVendorInvoiceEWBGETDataCount(mstDb);
            return jdbcTemplateTrn.queryForObject(sql, int.class, vendorInvoiceGETRequestDTO.getTaxpayerGstin(),
                            vendorInvoiceGETRequestDTO.getGetTypeID());
        } catch (Exception e) {
            log.error("Error occured while execute getGetEwayBillOnUICount function:", e.getMessage());
            return 0;
        }
    }

    /**
     * Gets the eway bill basic info header data.
     *
     * @param ewbNo
     *            the ewb no
     * @return the eway bill basic info header data
     */
    @Override
    public EwayBillBasicInfoHeaderDTO getEwayBillBasicInfoHeaderData(String ewbNo) {

        try {
            return jdbcTemplateTrn.queryForObject(TransactionSQL.GET_EWAYBILL_BASIC_INFO_HEADER_DATA,
                            BeanPropertyRowMapper.newInstance(EwayBillBasicInfoHeaderDTO.class), ewbNo);
        } catch (Exception e) {
            log.error("Error occured while execute getEwayBillBasicInfoHeaderData function:", e.getMessage());
            return null;
        }

    }

    /**
     * Gets the ewaybill view.
     *
     * @param ewbViewDTO
     *            the ewb view DTO
     * @return the ewaybill view
     */
    @Override
    public List<EWBViewResponseDTO> getEwaybillView(EWBViewDTO ewbViewDTO) {
        return jdbcTemplateTrn.query(TransactionSQL.GET_EWAYBILL_GET_VIEW_DETAILS(mstDb),
                        BeanPropertyRowMapper.newInstance(EWBViewResponseDTO.class), ewbViewDTO.getIdList(),
                        ewbViewDTO.getSize(), ewbViewDTO.getPage() * ewbViewDTO.getSize());
    }

    /**
     * Gets the ewaybill view count.
     *
     * @param ewbViewDTO
     *            the ewb view DTO
     * @return the ewaybill view count
     */
    @Override
    public int getEwaybillViewCount(EWBViewDTO ewbViewDTO) {
        return jdbcTemplateTrn.queryForObject(TransactionSQL.GET_EWAYBILL_GET_VIEW_DETAILS_COUNT, int.class,
                        ewbViewDTO.getIdList());
    }

    /**
     * Gets the existing EWB details.
     *
     * @param vendorInvoiceGETRequestDTO
     *            the vendor invoice GET request DTO
     * @return the existing EWB details
     */
    private Map<String, Object> getExistingEWBDetails(VendorInvoiceGETRequestDTO vendorInvoiceGETRequestDTO) {

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall("{call vendor_invoice_ewb_api_call_log(?,?,?,?,?,?)}");
                cs.setString(1, vendorInvoiceGETRequestDTO.getTaxpayerGstin());
                cs.setInt(2, vendorInvoiceGETRequestDTO.getGetTypeID());
                cs.setString(3, vendorInvoiceGETRequestDTO.getEwaybillDate());
                cs.setInt(4, vendorInvoiceGETRequestDTO.getSize());
                cs.setInt(5, vendorInvoiceGETRequestDTO.getPage() * vendorInvoiceGETRequestDTO.getSize());
                cs.setString(6, mstDb);

                return cs;
            }
        }, parameters);
    }

    /**
     * Send wf approved or regect data to db.
     *
     * @param wfApproveOrRejectDTO
     *            the wf approve or reject DTO
     * @return the string
     */
    @Override
    public String sendWfApprovedOrRegectDataToDb(@Valid WfApproveOrRejectDTO wfApproveOrRejectDTO) {

        String encryptedMailto = jdbcTemplateMst.queryForObject(MasterSQL.GET_MAIL_BY_USER_ID, String.class,
                        wfApproveOrRejectDTO.getUserId());
        String appKey = jdbcTemplateMst.queryForObject(MasterSQL.GET_APP_KEY, String.class,
                        Constants.ENCRYPTION_APP_KEY);

        try {
            mailTo = EncryptionUtils.decrypt(appKey, encryptedMailto);
        } catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException | NoSuchPaddingException
                        | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException
                        | DecoderException e) {
            log.error("error coming at the time of decripting login ID.");
        }
        try {
            String idList = getIdList(wfApproveOrRejectDTO);
            List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

            jdbcTemplateTrn.call(new CallableStatementCreator() {

                @Override
                public CallableStatement createCallableStatement(Connection con) throws SQLException {
                    CallableStatement cs = con.prepareCall("{call common_workflow_manage(?,?,?,?,?,?,?)}");
                    cs.setString(1, idList);
                    cs.setString(2, VendorInvoiceConstants.VENDOR_INVOICE_PLD_MODULE_ID);
                    cs.setLong(3, wfApproveOrRejectDTO.getUserId());
                    cs.setLong(4, wfApproveOrRejectDTO.getRequestType());
                    cs.setString(5, VendorInvoiceConstants.VENDOR_INVOICE_PLD_WF_TYPE_ID);
                    cs.setString(6, wfApproveOrRejectDTO.getRemarks());
                    cs.setString(7, mailTo);
                    return cs;
                }
            }, parameters);
            return wfApproveOrRejectDTO.getRemarks();
        } catch (Exception e) {
            log.error("Error occured while execute sendWfApprovedOrRegectDataToDb function:", e);
            return "Error";
        }
    }

    /**
     * Gets the id list.
     *
     * @param wfApproveOrRejectDTO
     *            the wf approve or reject DTO
     * @return the id list
     */
    private String getIdList(WfApproveOrRejectDTO wfApproveOrRejectDTO) {

        String gstinList = "";
        gstinList = wfApproveOrRejectDTO.getIds().toString();
        return gstinList.replace("[", "").replace("]", "").replace("{", "").replace("}", "").replace(" ", "");
    }

    /**
     * Gets the base document.
     *
     * @param invoiceDetailsReqDTO
     *            the invoice details req DTO
     * @return the base document
     */
    @Override
    public Integer getBaseDocument(InvoicePrimaryDetail invDetail) {
        try {
            if (!StringUtils.isBlank(invDetail.getInvoiceNo())) {
                String sql = TransactionSQL.GET_BASE_DOCUMENT_SQL;
                return jdbcTemplateTrn.queryForObject(sql, int.class, invDetail.getTaxpayerGstin(),
                                invDetail.getVendorGstin(), invDetail.getInvoiceNo(), invDetail.getInvoiceDate());
            } else {

                String sql = TransactionSQL.GET_BASE_DOCUMENT_SQL_EWAYBILL;
                return jdbcTemplateTrn.queryForObject(sql, int.class, invDetail.getTaxpayerGstin(),
                                invDetail.getVendorGstin(), invDetail.getEwayBillNo(), invDetail.getEwayBillDate());

            }
        } catch (Exception e) {
            log.error(e.getMessage());
            return null;
        }
    }

    @Override
    public InvoicePrimaryDetail getInvoicePrimaryDetails(InvoiceDetailsReqDTO invoiceDetailsReqDTO) {
        String sql = null;
        if ("2".equals(invoiceDetailsReqDTO.getTabId())) {
            sql = TransactionSQL.GET_INVOICE_DETAIL_PRIMARY_DETAILS;
        } else if ("4".equals(invoiceDetailsReqDTO.getTabId())) {
            sql = TransactionSQL.GET_VENDOR_INVOICE_DETAIL_PRIMARY_DETAILS;
        } else if ("5".equals(invoiceDetailsReqDTO.getTabId())) {
            sql = TransactionSQL.GET_VENDOR_INVOICE_DETAIL_PRIMARY_DETAILS;
        } else if ("6".equals(invoiceDetailsReqDTO.getTabId())) {
            sql = TransactionSQL.GET_VENDOR_INVOICE_DETAIL_PRIMARY_DETAILS_OCR_TAB;
        } 
        else if ("7".equals(invoiceDetailsReqDTO.getTabId())) {
            sql = TransactionSQL.GET_VENDOR_INVOICE_DETAIL_PRIMARY_DETAILS_URP_TAB;
        }else if ("1".equals(invoiceDetailsReqDTO.getIsEwaybill())) {
            sql = TransactionSQL.GET_INVOICE_HEADER_PRIMARY_DETAILS_EWB;
            return jdbcTemplateTrn.queryForObject(sql, BeanPropertyRowMapper.newInstance(InvoicePrimaryDetail.class),
                            invoiceDetailsReqDTO.getId(), invoiceDetailsReqDTO.getInvoiceno());
        } else {
            sql = TransactionSQL.GET_INVOICE_HEADER_PRIMARY_DETAILS;
        }
        return jdbcTemplateTrn.queryForObject(sql, BeanPropertyRowMapper.newInstance(InvoicePrimaryDetail.class),
                        invoiceDetailsReqDTO.getId());

    }

}
