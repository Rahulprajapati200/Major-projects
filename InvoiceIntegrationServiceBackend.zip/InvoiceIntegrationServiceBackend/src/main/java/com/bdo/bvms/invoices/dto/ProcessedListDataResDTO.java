package com.bdo.bvms.invoices.dto;

import java.time.LocalDateTime;

import com.bdo.bvms.invoices.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class ProcessedListDataResDTO {

    int id;
    String taxpayerGstin;
    String taxpayerPan;
    String vendorGstin;
    String vendorPan;
    String vendorLegalName;
    String vendorTradeName;
    String customerLegalName;
    String customerTradeName;
    String invoiceNo;
    String invoiceDate;
//    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    String syncWithGstr2a;
//    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    String syncWithGstr2b;
//    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    String syncWithEwayBill;
    String taxableValue;
    String igst;
    String cgst;
    String sgst;
    String cess;
    String invoiceValue;
    
    String qrCodeValid;
    String ewayBillNo;
    String ewayBillDate;
    String poNumber;
    String grnNumber;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    boolean syncStatus;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
    LocalDateTime uploadDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
    LocalDateTime lastSyncDate;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    String bookedErp;
    String getType;
    String batchNo;
    String fileType;
    int totalCount;
    String primarySync;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
    LocalDateTime primarySyncOn;
    String docType;
    String supplyType;
    String forceSync;
    String irnVerified;
    //Integer totalPOCount;
    String uploadedBy;
    String vendorCodeErp;
}
