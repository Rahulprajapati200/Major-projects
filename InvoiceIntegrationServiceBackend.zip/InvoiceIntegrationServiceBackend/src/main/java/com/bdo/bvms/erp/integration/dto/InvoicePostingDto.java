package com.bdo.bvms.erp.integration.dto;

import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class InvoicePostingDto {

	String batchNo;
    TranDtls tranDtls;
    DocDtls docDtls;
    SellerDtls sellerDtls;
    BuyerDtls buyerDtls;
    DispDtls dispDtls;
    ShipDtls shipDtls;
    ItemList itemList;
    ValDtls valDtls;
    String payDtls;
    // PayDtls payDtls;
    RefDtls refDtls;
    ArrayList<AddlDocDtls> addlDocDtls = new ArrayList<AddlDocDtls>();

    EwbDtls ewbDtls;

}
