package com.bdo.bvms.invoices.dto;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PageReqDTO extends BaseReqDTO {

    @NotNull(message = "Request param page cannot be null")
    @Range(min = 0, message = "Request param page cannot be zero or negative")
    Integer page = 1;

    public void setPage(Integer page) {
        this.page = page - 1;
    }

    int size = 50;

}
