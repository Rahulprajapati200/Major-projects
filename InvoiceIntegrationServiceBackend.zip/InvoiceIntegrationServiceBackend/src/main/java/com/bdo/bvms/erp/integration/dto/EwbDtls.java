package com.bdo.bvms.erp.integration.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EwbDtls {

    private String transid;
    private String transname;
    private String distance;
    private String transdocno;
    private String transdocDt;
    private String vehno;
    private String vehtype;
    private String transMode;
}
