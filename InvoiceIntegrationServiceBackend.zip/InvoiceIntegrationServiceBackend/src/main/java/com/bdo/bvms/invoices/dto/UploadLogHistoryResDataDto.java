package com.bdo.bvms.invoices.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UploadLogHistoryResDataDto {

    String taxpayerPan;
    String taxpayerGstin;
    
    String financialPeriod;
    String uploadedDate;
    String uploadedBy;
    String dataType;
    String fileName;
    String fileType;
    Integer totalCount;
    Integer successCount;
    Integer errorCount;
    String status;
    String baseFile;
    String errorFile;
    String batchNo;
    int customeOrDefault;
    String remarks;
    String uploadSource;
    String parentBatchNo;
    String errorMessage;
    int isQrScan;
    int pldOcrStatus;

}
