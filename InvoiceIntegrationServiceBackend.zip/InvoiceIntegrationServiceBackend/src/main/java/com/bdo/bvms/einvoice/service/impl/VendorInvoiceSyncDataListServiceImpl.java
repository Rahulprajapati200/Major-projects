package com.bdo.bvms.einvoice.service.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.CustomColumnService;
import com.bdo.bvms.einvoice.service.VendorInvoiceSyncDataListService;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceSyncDataListDao;
import com.bdo.bvms.invoices.dto.SyncPendingResponseDataDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class VendorInvoiceSyncDataListServiceImpl implements VendorInvoiceSyncDataListService {

    @Autowired
    VendorInvoiceSyncDataListDao vendorInvoiceSyncDataListDao;

    @Autowired
    CustomColumnService customColumnService;

    @Autowired
    CommonDao commonDao;

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Value("${mst.database-name}")
    String mstDatabseName;

    int id = 0;
    int idOfHeaders = 1;

    @Override
    public Map<String, Object> getSyncPendingDataGrid(VendorInvoiceRequestDTO syncPendingGridRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {

        Map<String, Object> data;
        try {

            data = new LinkedHashMap<>();

            int totalCount = 0;

            data.put("ColumnData", customColumnService.getCustomGridColumns(syncPendingGridRequestDTO));

            List<SyncPendingResponseDataDTO> dataResList = vendorInvoiceSyncDataListDao
                            .getSyncPendingDataList(syncPendingGridRequestDTO, gstinNewList, monthList);

            data.put("Data", dataResList);

            if (!dataResList.isEmpty()) {
                totalCount = dataResList.get(0).getTotalCount();
            }

            data.put("totalPageElements", totalCount);

        } catch (Exception e) {
            log.error("error coming at the time of getting data of 'columnData' and 'Data' from sync pending tab",
                            e.getCause());
            throw new VendorInvoiceServerException(e.getMessage());
        }

        return data;

    }

}
