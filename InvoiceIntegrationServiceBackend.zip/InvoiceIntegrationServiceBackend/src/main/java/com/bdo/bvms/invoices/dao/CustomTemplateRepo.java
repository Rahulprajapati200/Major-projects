package com.bdo.bvms.invoices.dao;

import java.util.Map;

public interface CustomTemplateRepo {

	Map<String, String> searchCustomTemplateHeaderMappings(int customTemplateId);

}
