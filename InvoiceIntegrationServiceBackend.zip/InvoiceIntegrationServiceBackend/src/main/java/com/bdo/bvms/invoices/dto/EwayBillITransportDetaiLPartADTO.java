package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EwayBillITransportDetaiLPartADTO {

    String transporterName;
    String transporterId;
    String approxDistance;
    String fromState;
    String fromPlace;
    String enteredDate;

}
