package com.bdo.bvms.invoices.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceRejectedDataListDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceSyncDataListDao;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.RejectedResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class VendorInvoiceRejectedDataListDaoImpl implements VendorInvoiceRejectedDataListDao {

    @Autowired
    VendorInvoiceSyncDataListDao vendorInvoiceSyncDataListDao;

    @Autowired
    CommonDao commonDao;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Override
    public Page<RejectedResDTO> getRejectedDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO,
                    String gstinNewList, String monthList) throws VendorInvoiceServerException {

        String query = "";
        List<RejectedResDTO> getRejectedDataList = new ArrayList<>();
        try {

            // Here we get pending for user Input grid data in form of list from
            // database.
            getRejectedDataList = jdbcTemplateTrn.query(query, new ResultSetExtractor<List<RejectedResDTO>>() {

                public List<RejectedResDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
                    List<RejectedResDTO> rejectedResponseDataItems = new ArrayList<>();
                    while (rs.next()) {
                        RejectedResDTO rejectedResDTO = new RejectedResDTO();

                        rejectedResDTO.setTaxpayerGstin(rs.getString(""));
                        rejectedResDTO.setDataType(query);
                        rejectedResDTO.setVendorGstin(rs.getString(""));
                        rejectedResDTO.setVendorLegalName(rs.getString(""));
                        rejectedResDTO.setVendorTradeName(rs.getString(""));
                        rejectedResDTO.setInvoiceNo(rs.getString(""));
                        rejectedResDTO.setInvoiceDate(rs.getString(""));
                        rejectedResDTO.setEwayBillNo(query);
                        rejectedResDTO.setEwayBillDate(query);
                        rejectedResDTO.setUploadDate(query);
                        rejectedResDTO.setUploadBy(query);
                        rejectedResDTO.setRejectedBy(query);
                        rejectedResDTO.setRejectedDate(query);
                        rejectedResDTO.setAction(query);

                        rejectedResponseDataItems.add(rejectedResDTO);
                    }

                    return rejectedResponseDataItems;
                }

            });
        } catch (DataAccessException e) {
            log.info("Error coming at the time of getting data from database in Rejected tab.", e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
            exceptionLogDTO.setFunctionName("getRejectedDataList");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming
            // in this function to getting data from database.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException(
                            "Error coming at the time of getting data from database in Rejected tab.", e.getCause());

        }
        if (getRejectedDataList != null) {

            return new PageImpl<>(getRejectedDataList);
        } else {

            return null;
        }

    }

}
