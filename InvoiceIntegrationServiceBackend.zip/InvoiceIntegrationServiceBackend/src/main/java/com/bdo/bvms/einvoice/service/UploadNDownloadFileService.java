package com.bdo.bvms.einvoice.service;

import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.invoices.custom.exception.AzureUploadDownloadException;
import com.bdo.bvms.invoices.custom.exception.InvoiceTemplateUploadException;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;

/**
 * The Interface UploadNDownloadFileService.
 */
public interface UploadNDownloadFileService {

    /**
     * Upload file to azure blob.
     *
     * @param file
     *            the file
     * @param apiRequestDTO
     *            the api request DTO
     * @param credentialMapFromDB
     * @return the string
     * @throws BVMSException
     *             the BVMS exception
     */
    String uploadFileToAzureBlob(MultipartFile file, UploadRequestDTO apiRequestDTO, String batchNo,
                    AzureConnectionCredentialsDTO credentialMapFromDB) throws AzureUploadDownloadException;

    /**
     * Download file from azure blob.
     *
     * @param fileName
     *            the file name
     * @param targetPath
     *            the target path
     * @throws AzureUploadDownloadException 
     * @throws BVMSException
     *             the BVMS exception
     */
    void downloadFileFromAzureBlob(String fileName, String targetPath, AzureConnectionCredentialsDTO map,
			UploadReqDTO uploadReqDTO) throws AzureUploadDownloadException;


    /**
     * Upload error file.
     *
     * @param uploadDTO
     *            the upload DTO
     * @throws BVMSException
     * @throws InvoiceTemplateUploadException 
     */
    void uploadErrorFile(UploadReqDTO uploadDTO, AzureConnectionCredentialsDTO map) throws InvoiceTemplateUploadException;
    
	void uploadSftpFileToAzureBlob(UploadRequestDTO uploadRequestDTO, String batchNo,
			AzureConnectionCredentialsDTO storageCredentials) throws AzureUploadDownloadException;

	}
