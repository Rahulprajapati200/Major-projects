package com.bdo.bvms.ocr.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VendorCodeAutoTagReqDto {
	
	String taxpayerGstin;
	String vendorGstin;
	String vendorPan;
	String poNo;
	

}
