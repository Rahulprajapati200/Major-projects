package com.bdo.bvms.einvoice.service;

import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.APIResponseDTO;

public interface ServiceCall {

	<T> ResponseEntity<T> callPostToDo(String requestURL, HttpEntity<Map<String, Integer>> entity,
			Class<APIResponseDTO> responseType) throws VendorInvoiceServerException;

}
