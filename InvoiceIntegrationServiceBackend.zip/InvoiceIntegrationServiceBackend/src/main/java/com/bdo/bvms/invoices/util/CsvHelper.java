package com.bdo.bvms.invoices.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.apache.poi.ss.usermodel.Row;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.CSVWringException;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;

/**
 * The Class CsvHelper.
 */
public class CsvHelper {

    CsvHelper() {

    }

    /**
     * Einvoice excel data to CSV.
     *
     * @param excelData
     *            the excel data
     * @param header
     *            the header
     * @return the byte array input stream
     * @throws CSVWringException
     *             the CSV wring exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public static ByteArrayInputStream einvoiceExcelDataToCSV(List<EInvoiceTemplateDTO> excelData, Row header)
                    throws IOException {

        AppLogger.info("", "", "Entering einvoiceExcelDataToCSV method");
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
                        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {

            List<String> headerList = AppUtil.getColumnNameList(header);
            headerList.add(0, "id");
            headerList.add("Valid_List_or_Not");
            headerList.add(Constants.COLUMN_ERROR_CODE);
            headerList.add("Error_Description_List");
            csvPrinter.printRecord(headerList);

            int i = 0;
            for (EInvoiceTemplateDTO eInvoiceTemplateDTO : excelData) {
                List<Object> data = Arrays.asList(i++, eInvoiceTemplateDTO.getGstinUinOfRecipient(),
                                eInvoiceTemplateDTO.getDocType(), eInvoiceTemplateDTO.getInwardNo(),
                                eInvoiceTemplateDTO.getInwardDate(), eInvoiceTemplateDTO.getGstinOfSupplier(),
                                eInvoiceTemplateDTO.getMainHSNCode(), eInvoiceTemplateDTO.getTotalInvoiceValue(),
                                eInvoiceTemplateDTO.getPurchaseOrderNumber(),
                                eInvoiceTemplateDTO.getPurchaseOrderDate(), eInvoiceTemplateDTO.getIrn(),
                                eInvoiceTemplateDTO.getIrnDate(), eInvoiceTemplateDTO.getUdf1(),
                                eInvoiceTemplateDTO.getUdf2(), eInvoiceTemplateDTO.getUdf3(),
                                eInvoiceTemplateDTO.getUdf4(), eInvoiceTemplateDTO.getUdf5(),
                                eInvoiceTemplateDTO.getUdf6(), eInvoiceTemplateDTO.getUdf7(),
                                eInvoiceTemplateDTO.getUdf8(), eInvoiceTemplateDTO.getUdf9(),
                                eInvoiceTemplateDTO.getUdf10(), String.valueOf(eInvoiceTemplateDTO.isValid()),
                                eInvoiceTemplateDTO.getErrorCodeList(), eInvoiceTemplateDTO.getErrorDiscriptionList());

                csvPrinter.printRecord(data);

            }

            csvPrinter.flush();
            return new ByteArrayInputStream(out.toByteArray());
        }

    }

}