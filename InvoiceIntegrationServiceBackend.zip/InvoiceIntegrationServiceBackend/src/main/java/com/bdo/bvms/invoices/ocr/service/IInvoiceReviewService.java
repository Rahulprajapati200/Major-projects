package com.bdo.bvms.invoices.ocr.service;

import java.io.File;
import java.text.ParseException;
import java.util.LinkedHashMap;
import java.util.List;

import com.bdo.bvms.invoices.custom.exception.FileOcrCustomException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.ocr.dao.OcrInvoiceReviewRequestDTO;
import com.bdo.bvms.invoices.ocr.dao.OcrInvoiceReviewResponseDTO;
import com.bdo.bvms.invoices.ocr.dao.OcrStatusUpdateRequestDto;
import com.bdo.bvms.ocr.dto.VendorCodeAutoTagReqDto;

public interface IInvoiceReviewService {

    LinkedHashMap<String, List<OcrInvoiceReviewResponseDTO>> ocrInvoiceReview(
                    OcrInvoiceReviewRequestDTO ocrInvoiceReviewRequestDTO);

    File reviewInvoiceFile(OcrInvoiceReviewRequestDTO ocrInvoiceReviewRequestDTO);

    String updateOCRInvoiceDetails(OcrInvoiceReviewRequestDTO ocrInvoiceReviewRequestDTO) throws VendorInvoiceServerException;

	String ocrStatusSubmission(OcrStatusUpdateRequestDto ocrStatusUpdateRequestDto) throws VendorInvoiceServerException;

	String updateOcrStatus(OcrStatusUpdateRequestDto ocrStatusUpdateRequestDto) throws VendorInvoiceServerException;

	String fetchVendorCode(VendorCodeAutoTagReqDto reqDto);
    
}
