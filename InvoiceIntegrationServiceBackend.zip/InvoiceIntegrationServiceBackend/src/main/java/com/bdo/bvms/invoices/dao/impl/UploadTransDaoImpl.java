package com.bdo.bvms.invoices.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.EWayBillDTO;
import com.bdo.bvms.invoices.dto.ErrorCodeDescriptionResponseDTO;
import com.bdo.bvms.invoices.dto.ResponseBean;
import com.bdo.bvms.invoices.dto.UploadLogDto;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.bvms.invoices.dto.UploadStageLogDto;
import com.bdo.bvms.invoices.taxpayer.sql.LogSQL;
import com.bdo.bvms.invoices.taxpayer.sql.TransactionSQL;
import com.bdo.bvms.invoices.util.AppLogger;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class UploadTransDaoImpl implements UploadTransDao {

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Autowired
    JdbcTemplate jdbcTemplateMst;

    @Value("${txn.database-name}")
    String tranDb;

    @Value("${mst.database-name}")
    String mstDb;

    @Override
    public List<EWayBillDTO> getErrorData(String batchNo) {

        String query = TransactionSQL.GET_ALL_DATA_OF_FAILURE_RECORDS;

        return jdbcTemplateTrn.query(query, new ResultSetExtractor<List<EWayBillDTO>>() {

            public List<EWayBillDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
                List<EWayBillDTO> eWayBillDtoListNew = new ArrayList<>();
                while (rs.next()) {
                    EWayBillDTO eWayBillDTO = new EWayBillDTO();
                    eWayBillDTO.setTaxpayerGstin(rs.getString("gstin_uin_of_recipient"));
                    eWayBillDTO.setEWayBillNo(rs.getString("eway_bill_no"));
                    eWayBillDTO.setEWayBillDate(rs.getString("eway_bill_date"));
                    eWayBillDTO.setEWayBillValidTill(rs.getString("eway_bill_valid"));
                    eWayBillDTO.setVendorGstin(rs.getString("gstin_of_supplier"));
                    eWayBillDTO.setPoNo(rs.getString("purchase_order_no"));
                    eWayBillDTO.setPoDate(rs.getString("purchase_order_date"));
                    eWayBillDTO.setFillingPeriod(rs.getString("filing_period"));
                    eWayBillDTO.setUdf1(rs.getString("udf_1"));
                    eWayBillDTO.setUdf2(rs.getString("udf_2"));
                    eWayBillDTO.setUdf3(rs.getString("udf_3"));
                    eWayBillDTO.setUdf4(rs.getString("udf_4"));
                    eWayBillDTO.setUdf5(rs.getString("udf_5"));
                    eWayBillDTO.setUdf6(rs.getString("udf_6"));
                    eWayBillDTO.setUdf7(rs.getString("udf_7"));
                    eWayBillDTO.setUdf8(rs.getString("udf_8"));
                    eWayBillDTO.setUdf9(rs.getString("udf_9"));
                    eWayBillDTO.setUdf10(rs.getString("udf_10"));
                    eWayBillDTO.setUdf11(rs.getString("udf_11"));
                    eWayBillDTO.setUdf12(rs.getString("udf_12"));
                    eWayBillDTO.setUdf13(rs.getString("udf_13"));
                    eWayBillDTO.setUdf14(rs.getString("udf_14"));
                    eWayBillDTO.setUdf15(rs.getString("udf_15"));
                    eWayBillDTO.setUdf16(rs.getString("udf_16"));
                    eWayBillDTO.setUdf17(rs.getString("udf_17"));
                    eWayBillDTO.setUdf18(rs.getString("udf_18"));
                    eWayBillDTO.setUdf19(rs.getString("udf_19"));
                    eWayBillDTO.setUdf20(rs.getString("udf_20"));
                    eWayBillDTO.setRowVersion(rs.getString("row_version"));
                    eWayBillDTO.setQrPageNo(rs.getString("qr_page_no"));
                    eWayBillDTO.setErrorCodeList(eWayBillDTO.getErrorCodeList().append(rs.getString("error_code")));
                    eWayBillDTO.setBatchNo(rs.getString("batch_no"));
                    eWayBillDtoListNew.add(eWayBillDTO);
                }
                return eWayBillDtoListNew;
            }

        }, batchNo);

    }

    @Override
    public List<EInvoiceTemplateDTO> getErrorDataListWithErrorCode(UploadReqDTO uploadDTO) {

        String s = TransactionSQL.GET_PERTICULAR_DATA_OF_SUCCESS_RECORDS;

        return jdbcTemplateTrn.query(s, new ResultSetExtractor<List<EInvoiceTemplateDTO>>() {

            public List<EInvoiceTemplateDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
                List<EInvoiceTemplateDTO> eInvoiceTemplateDTOList = new ArrayList<>();
                while (rs.next()) {
                    EInvoiceTemplateDTO eInvoiceTemplateDTO = new EInvoiceTemplateDTO();
                    eInvoiceTemplateDTO.setGstinUinOfRecipient(rs.getString("gstin_uin_of_recipient"));
                    eInvoiceTemplateDTO.setDocType(rs.getString("doc_type"));
                    eInvoiceTemplateDTO.setInwardNo(rs.getString("inward_no"));
                    eInvoiceTemplateDTO.setInwardDate(rs.getString("inward_date"));
                    eInvoiceTemplateDTO.setGstinOfSupplier(rs.getString("gstin_of_supplier"));
                    eInvoiceTemplateDTO.setMainHSNCode((rs.getString("hsn_code")));
                    eInvoiceTemplateDTO.setTotalInvoiceValue((String.valueOf(rs.getString("total_invoice_amt"))));
                    eInvoiceTemplateDTO.setPurchaseOrderNumber(rs.getString("purchase_order_no"));
                    eInvoiceTemplateDTO.setPurchaseOrderDate(rs.getString("purchase_order_date"));
                    eInvoiceTemplateDTO.setIrn(rs.getString("irn"));
                    eInvoiceTemplateDTO.setFillingPeriod(rs.getString("filing_period"));
                    eInvoiceTemplateDTO.setIrnDate(rs.getString("irn_date"));
                    eInvoiceTemplateDTO.setUdf1(rs.getString("udf_1"));
                    eInvoiceTemplateDTO.setUdf2(rs.getString("udf_2"));
                    eInvoiceTemplateDTO.setUdf3(rs.getString("udf_3"));
                    eInvoiceTemplateDTO.setUdf4(rs.getString("udf_4"));
                    eInvoiceTemplateDTO.setUdf5(rs.getString("udf_5"));
                    eInvoiceTemplateDTO.setUdf6(rs.getString("udf_6"));
                    eInvoiceTemplateDTO.setUdf7(rs.getString("udf_7"));
                    eInvoiceTemplateDTO.setUdf8(rs.getString("udf_8"));
                    eInvoiceTemplateDTO.setUdf9(rs.getString("udf_9"));
                    eInvoiceTemplateDTO.setUdf10(rs.getString("udf_10"));
                    eInvoiceTemplateDTO.setUdf11(rs.getString("udf_11"));
                    eInvoiceTemplateDTO.setUdf12(rs.getString("udf_12"));
                    eInvoiceTemplateDTO.setUdf13(rs.getString("udf_13"));
                    eInvoiceTemplateDTO.setUdf14(rs.getString("udf_14"));
                    eInvoiceTemplateDTO.setUdf15(rs.getString("udf_15"));
                    eInvoiceTemplateDTO.setUdf16(rs.getString("udf_16"));
                    eInvoiceTemplateDTO.setUdf17(rs.getString("udf_17"));
                    eInvoiceTemplateDTO.setUdf18(rs.getString("udf_18"));
                    eInvoiceTemplateDTO.setUdf19(rs.getString("udf_19"));
                    eInvoiceTemplateDTO.setUdf20(rs.getString("udf_20"));
                    eInvoiceTemplateDTO.setQrPageNo(rs.getString("qr_page_no"));
                    eInvoiceTemplateDTO.setRowVersion(rs.getString("row_version"));
                    eInvoiceTemplateDTO.setErrorCodeList(
                                    eInvoiceTemplateDTO.getErrorCodeList().append(rs.getString("error_code")));
                    eInvoiceTemplateDTOList.add(eInvoiceTemplateDTO);
                }
                return eInvoiceTemplateDTOList;
            }

        }, uploadDTO.getBatchNo());

    }

    @Override
    public void uploadTxLogDetails(UploadLogDto txUploadLog) throws VendorInvoiceServerException {
        jdbcTemplateTrn.update(LogSQL.INSERT_INTO_UPLOAD_LOG, txUploadLog.getUploadSource(), txUploadLog.getEntityId(),
                        txUploadLog.getBatchNo(), txUploadLog.getTemplateType(), txUploadLog.getTaxpayerPan(),
                        txUploadLog.getTaxpayerGstin(), txUploadLog.getFileName(), txUploadLog.getFp(),
                        txUploadLog.getFileType(), txUploadLog.getUploadStartTime(), txUploadLog.getFileSize(),
                        txUploadLog.getBaseFileLocation(), txUploadLog.isCustomTemplate(),
                        txUploadLog.getCustomTemplateId(), txUploadLog.getPldUploadStatus(),
                        txUploadLog.getPldUploadSource(), txUploadLog.getCreatedBy(), txUploadLog.getPaBatchNo());
    }

    @Override
    public void insertUploadStageLog(UploadStageLogDto uploadStageLogDto) {

        jdbcTemplateTrn.update(LogSQL.INSERT_INTO_UPLOAD_STAGE_LOG, uploadStageLogDto.getUploadLogId(),
                        uploadStageLogDto.getProcessStage(), uploadStageLogDto.getProcessState(),
                        uploadStageLogDto.getCreatedAt(), uploadStageLogDto.getCreatedBy(),
                        uploadStageLogDto.getBatchNo());

    }

    @Override
    public void updateErrorNSuccessCountAndTotalCount(ResponseBean responseBean, String batchNo) {
        jdbcTemplateTrn.update(LogSQL.UPDATE_SUCESSNERROR_COUNT, responseBean.getErrorCount(),
                        responseBean.getSuccessCount(), responseBean.getErrorCount() + responseBean.getSuccessCount(),
                        batchNo);
    }

    @Override
    public void updateProcessStatus(String batchNo, String pldUploadStatus) {

        jdbcTemplateTrn.update(LogSQL.UPDATE_PLD_UPLOAD_STATUS, pldUploadStatus, batchNo);

    }

    @Override
    public void updateErrorFileName(String batchNo, String csvSuccessFilePath) {

        jdbcTemplateTrn.update(LogSQL.UPDAT_ERROR_FILE_NAME, csvSuccessFilePath, batchNo);

    }

    @Override
    public int getUploadIdFromDB(String batchNo) {

        return jdbcTemplateTrn.queryForObject(LogSQL.GET_UPLOAD_LOG_ID, Integer.class, batchNo);
    }

    @Override
    public void updateCount(String query, int count, UploadReqDTO uploadDTO) {
        jdbcTemplateTrn.update(query, count, uploadDTO.getBatchNo());
    }

    @Override
    public void updateTimeStamp(String query, UploadReqDTO uploadDTO) {

        jdbcTemplateTrn.update(query, Timestamp.from(Instant.now()), uploadDTO.getBatchNo());
    }

    @Override
    public int updateBatchLog(String batchNo) {

        return jdbcTemplateTrn.update(LogSQL.UPDATE_101_TO_102, batchNo);
    }

    @Override
    public int updateAgainBatchLog(String batchNo) {

        return jdbcTemplateTrn.update(LogSQL.UPDATE_102_TO_103, batchNo);
    }

    @Override
    public void updateUploadStageNState(String stage, String state, int uploadLogId) {
        jdbcTemplateTrn.update(LogSQL.UPDATE_STAGE_STATE, stage, state, uploadLogId);
    }

    @Override
    public Map<String, String> getFieldsValue(String gstin, List<String> fillingPeriod) {

        return new HashMap<>();
    }

    @Override
    public List<String> getEWayDuplicateFPInDiffMonthFP(String supplierGstn, String recipientGSTN, String fp) {

        return jdbcTemplateTrn.queryForList(TransactionSQL.getDuplicateFPInDiffMonth(mstDb), String.class,
                        recipientGSTN, fp);

    }

    @Override
    public List<String> getInvoiceDuplicateInvoiceInDiffFP(String supplierGstn, String recipientGSTN, String fp) {

        return jdbcTemplateTrn.queryForList(TransactionSQL.getDuplicateInvoiceInDiffMonth(mstDb), String.class,
                        recipientGSTN, fp);

    }

    @Override
    public int updatePldCode(String customtemplateID) {

        return jdbcTemplateMst.queryForObject(TransactionSQL.getUPDATE_PLD_CODE_QUERY(mstDb), Integer.class,
                        customtemplateID, Constants.SMPICKMSTPICKID, Constants.VENDOR_INVOICE_PICK_KEY);
    }

    @Override
    public Map<String, Object> writeInvoiceDetailsToInvoiceHeader(String batchNo, int flag, int userid,
                    String mstDbName) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall(TransactionSQL.CALL_VENDOR_INVOICE_INVOICE_HEADER_IMPORT);
                if (cs != null) {
                    cs.setString(1, batchNo);
                    cs.setInt(2, flag);
                    cs.setInt(3, userid);
                    cs.setString(4, mstDbName);
                }
                return cs;
            }
        }, parameters);

    }

    @Override
    public int getInwardResultFPCount(String gstin, String invoiceNo, String invoiceDate, String supplierGstin,
                    String fp, String yearId) {
        String className = "";
        AppLogger.debug(className, "getBatchData", invoiceNo + " : Entered method : " + System.currentTimeMillis());

        try {

            return jdbcTemplateTrn.queryForObject(TransactionSQL.INWARD_RESULT_FP_COUNT, Integer.class, gstin,
                            supplierGstin, yearId, fp, invoiceNo);

        } catch (Exception ex) {
            log.error("Error occured while execute getFPYear function:", ex);
            return 0;
        }

    }

    @Override
    public Map<String, Object> VendorInvoiceRegisterPo(String batchNo) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall(TransactionSQL.CALL_VENDOR_INVOICE_REGISTER_PO);
                if (cs != null) {
                    cs.setString(1, batchNo);
                }
                return cs;
            }
        }, parameters);

    }

    @Override
    public Map<String, Object> commonPostNotification(int vendoruploadmstid, String string, int userId, int userId2,
                    int userId3, String schemaname, String notificationCode) {
        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        return jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall("{call common_post_notification(?,?,?,?,?,?,?)}");
                if (cs != null) {
                    cs.setInt(1, vendoruploadmstid);
                    cs.setString(2, string);
                    cs.setInt(3, userId);
                    cs.setInt(4, userId2);
                    cs.setInt(5, userId3);
                    cs.setString(6, schemaname);
                    cs.setString(7, notificationCode);

                }
                return cs;
            }
        }, parameters);

    }

    @Override
    public void updateProcessStatusWithRemarks(String batchNo, String pldUploadStatus, String remarks) {

        jdbcTemplateTrn.update(LogSQL.UPDATE_ERROR_REMARKS, pldUploadStatus, remarks, batchNo);

    }

    @Override
    public void updateFpLog(List<String> month, UploadReqDTO uploadRequestDTO) {
        String fp = "";
        fp = String.join(",", uploadRequestDTO.getFp());
        jdbcTemplateTrn.update(LogSQL.UPDATEFPLOG, fp, uploadRequestDTO.getBatchNo());
    }

    @Override
    public List<String> getInvoiceAlreadySynced(String taxpayerGstin, String vendorGstin) {

        List<String> invoiceHeaderCrId = null;
        invoiceHeaderCrId = jdbcTemplateTrn.queryForList(TransactionSQL.CHECK_INVOICE_ALREADY_SYNCED_SQL, String.class,
                        taxpayerGstin, vendorGstin);
        return invoiceHeaderCrId;

    }

    @Override
    public List<String> getEWBAlreadySynced(String taxpayerGstin, String vendorGstin) {

        List<String> invoiceHeaderCrId = null;
        invoiceHeaderCrId = jdbcTemplateTrn.queryForList(TransactionSQL.CHECK_EWB_ALREADY_SYNCED_SQL, String.class,
                        taxpayerGstin, vendorGstin);
        return invoiceHeaderCrId;

    }

    @Override
    public List<String> getInvoiceAlreadyApproved(String taxpayerGstin) {

        List<String> invoiceHeaderCrId = null;
        invoiceHeaderCrId = jdbcTemplateTrn.queryForList(TransactionSQL.CHECK_INVOICE_ALREADY_APPROVED_SQL,
                        String.class, taxpayerGstin);
        return invoiceHeaderCrId;

    }

    @Override
    public List<String> getEWBAlreadyApproved(String taxpayerGstin) {

        List<String> ewbHeaderCrId = null;
        ewbHeaderCrId = jdbcTemplateTrn.queryForList(TransactionSQL.CHECK_EWB_ALREADY_APPROVED_SQL, String.class,
                        taxpayerGstin);
        return ewbHeaderCrId;

    }

    @Override
    public String getEinvoiceErrorMessage(List<EInvoiceTemplateDTO> errorDataListWithErrorCode) {
        StringBuilder errorMessage = new StringBuilder();
        errorDataListWithErrorCode.forEach(data ->
        	errorMessage.append(data.getQrPageNo()).append(": ").append(data.getErrorDiscriptionList().replace(0, 1,"")).append("\n")
        );
        return errorMessage.toString().replace("|", ",");
        
    }
    
    @Override
    public String getEwayBillErrorMessage(List<EWayBillDTO> errorDataListWithErrorCode) {
        StringBuilder errorMessage = new StringBuilder();
        errorDataListWithErrorCode.forEach(data ->
        errorMessage.append(data.getQrPageNo()).append(": ").append(data.getErrorDiscriptionList().replace(0, 1,"")).append("\n")
        );
        return errorMessage.toString().replace("|", ",");
        
    }

    @Override
    public void insertUploadStageNState(String processStageDataValidation, String processFileUploadStatusStart,
                    UploadReqDTO uploadDTO) {
        jdbcTemplateTrn.update(TransactionSQL.INSERTINTOSTAGELOG, uploadDTO.getBatchNo(), processStageDataValidation,
                        processFileUploadStatusStart, LocalDateTime.now(), uploadDTO.getUserId());
    }

    @Override
    public void insertStageNState(String processStageDataValidation, String processFileUploadStatusStart,
                    UploadRequestDTO uploadRequestDTO, String batchNo) {
        jdbcTemplateTrn.update(TransactionSQL.INSERTINTOSTAGELOG, batchNo, processStageDataValidation,
                        processFileUploadStatusStart, LocalDateTime.now(), uploadRequestDTO.getUserId());
    }

    @Override
    public void poGrnMapping(UploadReqDTO uploadDTO, String json) {

        List<SqlParameter> parameters = Arrays.asList(new SqlParameter(Types.NVARCHAR));

        jdbcTemplateTrn.call(new CallableStatementCreator() {

            @Override
            public CallableStatement createCallableStatement(Connection con) throws SQLException {
                CallableStatement cs = con.prepareCall("{call vendor_invoice_po_mapping_crud(?,?,?,?,?,?,?)}");
                if (cs != null) {
                    cs.setString(1, uploadDTO.getBatchNo());
                    cs.setInt(2, 1);
                    cs.setString(3, json);
                    cs.setInt(4, uploadDTO.getUserId());
                    cs.setString(5, mstDb);
                    cs.setInt(6, 0);
                    cs.setInt(7, 0);

                }
                return cs;
            }
        }, parameters);

    }

    @Override
    public void updateQRScanFlag(String batchNo, int isScan) {
        jdbcTemplateTrn.update(TransactionSQL.UPDATE_QR_SCAN_FLAG, isScan, batchNo);
    }

    @Override
    public void insertIntoQRExecutionLog(UploadReqDTO uploadDTO, String output, LocalDateTime start,
                    LocalDateTime end) {
        jdbcTemplateTrn.update(TransactionSQL.INSERT_INTO_QR_EXECUTION_LOG, uploadDTO.getUploadLogId(), output, start,
                        end, uploadDTO.getUserId());
    }

}
