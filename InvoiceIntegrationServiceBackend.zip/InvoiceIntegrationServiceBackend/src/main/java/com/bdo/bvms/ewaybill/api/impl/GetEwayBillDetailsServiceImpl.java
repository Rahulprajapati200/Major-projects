package com.bdo.bvms.ewaybill.api.impl;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.bdo.bvms.ewaybill.api.GetEwayBillApiDao;
import com.bdo.bvms.ewaybill.api.GetEwayBillDetailsService;
import com.bdo.bvms.ewaybill.api.dto.GetEwayBillReqDTO;
import com.bdo.bvms.ewaybill.api.dto.NicAuthResponseDTO;
import com.bdo.bvms.ewaybill.api.dto.TaxpayerDetailsDTO;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.InvoiceIntegrationEWBException;
import com.bdo.bvms.invoices.dto.EwayBillheaderDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class GetEwayBillDetailsServiceImpl implements GetEwayBillDetailsService {

    RestTemplate restTemplate = new RestTemplate();

    @Autowired
    EWayBillBDOAuthentication eWayBillBDOAuthentication;

    @Autowired
    EWayBillNicAuthentication eWayBillNicAuthentication;

    @Autowired
    GetEwayBillInvoiceDetailServiceImpl getEwayBillInvoiceDetailServiceImpl;

    @Autowired
    GetEwayBillApiDao getEwayBillApiDao;

    @Override
    public EwayBillheaderDTO getEwayBillDetails(GetEwayBillReqDTO reqDto) throws InvoiceIntegrationEWBException {
    	

        String clientId = getEwayBillApiDao.getEwayBillClientId();
        String seckey = getEwayBillApiDao.getEwayBillClientSecretEncrypted();
        String appKey = getEwayBillApiDao.getEwayBillAppKey();
        String eWayBillApiBaseURL = getEwayBillApiDao.getEwayBillApiUrl();
        String eWayBillApiURL = eWayBillApiBaseURL + "?ewbNo= " + reqDto.getEwaybillNo();
        EwayBillheaderDTO ewayBillheaderInfo = null;

        // Get username and password
        TaxpayerDetailsDTO taxpayerDetails = getEwayBillApiDao
                        .getTaxpayerDetailsFromEntityMaster(reqDto.getTaxpayerGstin());

        String bdoAuthKey = eWayBillBDOAuthentication.bdoAuthEWB(clientId, seckey, reqDto,
                        Constants.GET_EWAYBILL_PLD_CODE);

        NicAuthResponseDTO nicAuthResponseDTO;
        try {
            nicAuthResponseDTO = eWayBillNicAuthentication.nicAuthEWB(bdoAuthKey, clientId, seckey, reqDto,
                            Constants.GET_EWAYBILL_PLD_CODE, taxpayerDetails);
        } catch (Exception e) {
            log.error("Error occured while execute getBdoAuthKey function:", e);
            throw new InvoiceIntegrationEWBException(e.getMessage());
        }

        EWayBillDetailsApi ewayBillApi = new EWayBillDetailsApi();

        try {

            ewayBillheaderInfo = ewayBillApi.getEwayBillDetailsAPI(appKey, reqDto.getTaxpayerGstin(), clientId, seckey,
                            eWayBillApiURL, restTemplate, bdoAuthKey, nicAuthResponseDTO.getNicAuthToken(),
                            nicAuthResponseDTO.getNicSek());
        } catch (Exception e) {

            log.error("Error occured in operation::", e);
        	 getEwayBillApiDao.insertToEwayBillApiCall(nicAuthResponseDTO, reqDto.getTaxpayerGstin(), reqDto,
                     "Basic Auth Failed", Constants.GET_EWAYBILL_PLD_CODE,null,Constants.EWB_GET_STATUS_FAIL);
            if (e instanceof JSONException) {
                eWayBillBDOAuthentication.markNICKeyInactive(reqDto.getTaxpayerGstin(), nicAuthResponseDTO.getNicSek());
                throw new InvoiceIntegrationEWBException("Basic Authentication failed , please retry");
            }

            throw new InvoiceIntegrationEWBException(e.getMessage());
        }

        int ewbApiCallLogId = 0;

        if (StringUtils.isNotEmpty(ewayBillheaderInfo.getError())) {

            if ("Invalid auth token".equalsIgnoreCase(ewayBillheaderInfo.getError())) {
                eWayBillBDOAuthentication.markNICKeyInactive(reqDto.getTaxpayerGstin(), nicAuthResponseDTO.getNicSek());
            }
            getEwayBillApiDao.insertToEwayBillApiCall(nicAuthResponseDTO, reqDto.getTaxpayerGstin(), reqDto,
                            ewayBillheaderInfo.getError(), Constants.GET_EWAYBILL_PLD_CODE,
                            ewayBillheaderInfo.getApiResponse()
                            ,Constants.EWB_GET_STATUS_FAIL);
            throw new InvoiceIntegrationEWBException(ewayBillheaderInfo.getError());

        } 
        else if (!reqDto.getTaxpayerGstin().equals(ewayBillheaderInfo.getToGstin())) {
        	  ewayBillheaderInfo.setError(Constants.TAXPAYER_GSTIN_NOT_MATCHED);
        	  getEwayBillApiDao.insertToEwayBillApiCall(nicAuthResponseDTO, reqDto.getTaxpayerGstin(), reqDto,
                     ewayBillheaderInfo.getError(), Constants.GET_EWAYBILL_PLD_CODE,
                     ewayBillheaderInfo.getApiResponse()
                     ,Constants.EWB_GET_STATUS_FAIL);
              throw new InvoiceIntegrationEWBException(ewayBillheaderInfo.getError());
        }        
        else {
        	reqDto.setSuccessCount(1);
            ewbApiCallLogId = getEwayBillApiDao.insertToEwayBillApiCall(nicAuthResponseDTO, reqDto.getTaxpayerGstin(),
                            reqDto, null, Constants.GET_EWAYBILL_PLD_CODE, ewayBillheaderInfo.getApiResponse(),Constants.EWB_GET_STATUS_SUCCESS);
        }

        int id = getEwayBillApiDao.insertToEwayBillHeader(ewbApiCallLogId, ewayBillheaderInfo);

        if (ewayBillheaderInfo.getItemList() != null && !ewayBillheaderInfo.getItemList().isEmpty()) {

            getEwayBillApiDao.insertToEwayBillItemDetails(ewayBillheaderInfo.getItemList(), id);
        }

        if (ewayBillheaderInfo.getVehiclListDetails() != null && !ewayBillheaderInfo.getVehiclListDetails().isEmpty()) {
            getEwayBillApiDao.insertToEwayBillVehicleDetails(ewayBillheaderInfo.getVehiclListDetails(), id);
        }

        // insert data to invoice detail
        getEwayBillInvoiceDetailServiceImpl.saveGetEwayBillDetailsToInvoiceDetail(ewayBillheaderInfo,
                        reqDto.getUserId());
        
        return ewayBillheaderInfo;
        

    }

}
