package com.bdo.bvms.invoices.custom.exception;

public class ReadInvoicePojoListException extends Exception{
	private static final long serialVersionUID = 1L;

	public ReadInvoicePojoListException() {
		super();
	}

	public ReadInvoicePojoListException(Throwable cause) {

		super(cause);

	}

	public ReadInvoicePojoListException(String message, Throwable cause) {

		super(message, cause);

	}
	
	public ReadInvoicePojoListException(String message) {

		super(message);

	}
}
