package com.bdo.bvms.erp.integration.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class RefDtls {

    private String invRm;
    DocPerdDtls docPerdDtlsObject;
    List<PrecDocDtls> precDocDtls = new ArrayList<PrecDocDtls>();
    List<ContrDtls> contrDtls = new ArrayList<ContrDtls>();
}
