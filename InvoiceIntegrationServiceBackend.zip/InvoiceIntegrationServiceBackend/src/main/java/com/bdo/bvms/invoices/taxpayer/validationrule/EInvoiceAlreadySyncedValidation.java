package com.bdo.bvms.invoices.taxpayer.validationrule;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.impl.EinvoiceDataTemplateUploadImpl;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.ValidationConstants;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dao.impl.UploadTransDaoImpl;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EInvoiceAlreadySyncedValidation {
	
	@Autowired
	UploadTransDao uploadTransDao;
	
	
	public List<EInvoiceTemplateDTO> validateAlreadySyncedStatus(List<EInvoiceTemplateDTO> dataList) {
		
		log.info("Entered into validateAlreadySyncedStatus method");
		Map<String, Map<String, String>> syncedValidationMap = new ConcurrentHashMap<String, Map<String, String>>();
        List<EInvoiceTemplateDTO> validatedList = new ArrayList<>();
        dataList.forEach(rowData -> {
            	try {
        		  if (rowData.isValid()) {
        			  int isSynced = 0;
        			  String taxpayerGstinVendorGstin = rowData.getGstinUinOfRecipient() + rowData.getGstinOfSupplier();
        			  String keyDataTocheck = rowData.getGstinUinOfRecipient() + rowData.getGstinOfSupplier() + rowData.getInwardNo() + rowData.getDocType();
        			  List<String> invoiceHeaderCrId = new ArrayList<>();
        			  if(syncedValidationMap.get(taxpayerGstinVendorGstin) == null) {  
        				  invoiceHeaderCrId =  uploadTransDao.getInvoiceAlreadySynced(rowData.getGstinUinOfRecipient(), rowData.getGstinOfSupplier());
        				  Map<String, String> map = invoiceHeaderCrId.stream()
                                  .collect(Collectors.toMap(str -> str, str -> str));
        				  
        				  syncedValidationMap.put(taxpayerGstinVendorGstin, map);
        				  if (syncedValidationMap.get(taxpayerGstinVendorGstin).get(keyDataTocheck) != null) {
        					  isSynced  = 1;
                          }
        			  }
        			  else {
        				  if (syncedValidationMap.get(taxpayerGstinVendorGstin).get(keyDataTocheck) != null) {
        					  isSynced  = 1;
                          }
                      }
        			  
        			  if (isSynced > 0) {

                          markErrorNAddErrorCode(rowData, ValidationConstants.EINVOICE_ERROR_CODE_O0091, Constants.BLANK);
                      }

        		  }
        		  
        		  validatedList.add(rowData);
        		  
        	} catch (Exception | Error e) {

                log.error("Error Occured while validation row " + rowData.getExcelRowId(), e);

                markErrorNAddErrorCode(rowData, ValidationConstants.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);

            }
        		
	
        });
        
        return validatedList;
		
	}
	
	
	private void markErrorNAddErrorCode(EInvoiceTemplateDTO rowData, String errorCode, String errorMessage) {
       
        rowData.setValid(false);
        rowData.setErrorCodeList(rowData.getErrorCodeList().append(errorCode));
        rowData.setErrorDiscriptionList(rowData.getErrorDiscriptionList().append(errorMessage));
    }

}
