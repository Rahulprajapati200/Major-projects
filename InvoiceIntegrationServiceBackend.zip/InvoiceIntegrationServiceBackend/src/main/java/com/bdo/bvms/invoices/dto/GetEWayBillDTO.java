package com.bdo.bvms.invoices.dto;

import org.springframework.data.relational.core.mapping.Column;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class GetEWayBillDTO {

    String taxpayerGstin;
    String vendorGstin;
    String title;
    String placeSupply;

    String taxableAmount = "0.00";

    @Column(value = "igst_amount")
    String igstAmount = "0.00";

    @Column(value = "cgst_amount")
    String cgstAmount = "0.00";

    @Column(value = "sgst_amount")
    String sgstAmount = "0.00";

    @Column(value = "cess_amount")
    String cessAmount = "0.00";

    @Column(value = "inv_value")
    String invValue = "0.00";

    String invoiceNo;
    String invoiceDate;
    String ewbNo;
    String ewbDate;

    @Column(value = "is_sync")
    boolean status;
    
    boolean defaultSyncStatus;
    boolean forceSyncStatus;
    
    @Column(value = "ewbStatus")
    String   ewbStatus;
    
    @Column(value = "fromPlace")
    String   pos;
}
