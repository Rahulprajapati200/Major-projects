package com.bdo.bvms.invoices.dto;

public class EInvoiceItemDetailsDTO {

    private String description;
    private String hsnSac;
    private String qty;
    private String unit;
    private String rate;
    private String taxableValue;
    private String gstRate;
    private String igst;
    private String cgst;
    private String sgst;
    private String totalItemValue;

   

    public String getDescription() {
        return description;
    }

    public String getHsnSac() {
        return hsnSac;
    }

    public String getQty() {
        return qty;
    }

    public String getUnit() {
        return unit;
    }

    public String getRate() {
        return rate;
    }

    public String getTaxableValue() {
        return taxableValue;
    }

    public String getGstRate() {
        return gstRate;
    }

    public String getIgst() {
        return igst;
    }

    public String getCgst() {
        return cgst;
    }

    public String getSgst() {
        return sgst;
    }

    public String getTotalItemValue() {
        return totalItemValue;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setHsnSac(String hsnSac) {
        this.hsnSac = hsnSac;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public void setTaxableValue(String taxableValue) {
        this.taxableValue = taxableValue;
    }

    public void setGstRate(String gstRate) {
        this.gstRate = gstRate;
    }

    public void setIgst(String igst) {
        this.igst = igst;
    }

    public void setCgst(String cgst) {
        this.cgst = cgst;
    }

    public void setSgst(String sgst) {
        this.sgst = sgst;
    }

    public void setTotalItemValue(String totalItemValue) {
        this.totalItemValue = totalItemValue;
    }

    @Override
    public String toString() {
        return "EInvoiceItemDetailsDTO [description=" + description + ", hsnSac=" + hsnSac + ", qty=" + qty + ", unit="
                        + unit + ", rate=" + rate + ", taxableValue=" + taxableValue + ", gstRate=" + gstRate
                        + ", igst=" + igst + ", cgst=" + cgst + ", sgst=" + sgst + ", totalItemValue=" + totalItemValue
                        + "]";
    }

}
