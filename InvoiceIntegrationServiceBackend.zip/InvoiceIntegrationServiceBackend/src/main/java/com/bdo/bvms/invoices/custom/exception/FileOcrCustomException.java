package com.bdo.bvms.invoices.custom.exception;

public class FileOcrCustomException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FileOcrCustomException() {
		super();
	}

	public FileOcrCustomException(Throwable cause) {

		super(cause);

	}

	public FileOcrCustomException(String message, Throwable cause) {

		super(message, cause);

	}
	
	public FileOcrCustomException(String message) {

		super(message);

	}
}
