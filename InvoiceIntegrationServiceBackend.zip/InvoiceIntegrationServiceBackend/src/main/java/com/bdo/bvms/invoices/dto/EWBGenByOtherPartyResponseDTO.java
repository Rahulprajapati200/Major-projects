package com.bdo.bvms.invoices.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EWBGenByOtherPartyResponseDTO {

    List<EWBGenByOtherPartyDTO> ewbGenByOtherPartysList;
    String error = null;
    String errroCode;
    String apiResponse;

}
