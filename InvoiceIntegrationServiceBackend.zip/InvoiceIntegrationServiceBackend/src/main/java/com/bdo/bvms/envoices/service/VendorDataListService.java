package com.bdo.bvms.envoices.service;

import java.util.Map;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface VendorDataListService {

    Map<String, Object> getDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO)
                    throws VendorInvoiceServerException;

    Map<String, Object> getProcessedInvoiceDataList(VendorInvoiceRequestDTO vendorInvoiceRequestDTO)
                    throws VendorInvoiceServerException;

}
