package com.bdo.bvms.invoices.dao.impl;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.EInvoiceDao;
import com.bdo.bvms.invoices.dto.ResponseBean;
import com.bdo.bvms.invoices.taxpayer.sql.TransactionSQL;
import com.bdo.bvms.invoices.util.AppLogger;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class EWayDaoImpl implements EInvoiceDao {

    static final Logger logger = LoggerFactory.getLogger(EWayDaoImpl.class);

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Override
    public ResponseBean gstInwardInvCdnInsert(String successFilePath, String errorFilePath, String successTable,
                    String errorTable) throws VendorInvoiceServerException {

        final String methodName = "gstInwardInvCdnInsert";

        int successCount = 0;
        int errorCount = 0;

        String query;

        ResponseBean response = new ResponseBean();

        try {
            AppLogger.info(Constants.BLANK, methodName,
                            "successTable = " + successTable + " errorTable = " + errorTable);

            query = TransactionSQL.INSERT_FILE_SQL.replace("table_name", successTable);
            AppLogger.info(Constants.BLANK, methodName, "query = " + query);
            File fileSuccess = new File(successFilePath);
            if (fileSuccess.exists()) {
                successCount = saveData(successFilePath, query);
            }
            AppLogger.info(Constants.BLANK, methodName, "successCount = " + successCount);

            query = TransactionSQL.INSERT_FILE_SQL.replace("table_name", errorTable);
            File fileError = new File(errorFilePath);
            if (fileError.exists()) {
                errorCount = saveData(errorFilePath, query);
            }
            AppLogger.info(Constants.BLANK, methodName, "errorCount = " + errorCount);

            response.setSuccessCount(successCount);
            response.setErrorCount(errorCount);
        } catch (Exception e) {
            log.error("Error in  " + "gstInwardInvCdnInsert Method " + e);
            throw new VendorInvoiceServerException(e.getMessage());
        }
        return response;
    }

    private Integer saveData(String filePath, String query) throws Exception,VendorInvoiceServerException {

        Integer count = 0;
        try {
            count = jdbcTemplateTrn.update(query, filePath);

        } catch (Exception e) {
            log.error("Error in Save date Method " + e);
            throw new VendorInvoiceServerException("Something went Wrong, Please Contact to Administrator", e);
        }
        return count;
    }

}