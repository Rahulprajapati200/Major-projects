package com.bdo.bvms.invoices.dto;

import java.time.LocalDateTime;

import com.bdo.bvms.invoices.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApprovedDocumentsDTO {

    int id;
    private String companyGstin;
    private String dataType;
    private String customerGstin;
    private String customerLegalName;
    private String customerTradeName;
    private String invoiceNo;
    private String invoiceDate;
    private String ewayBillNo;
    private String ewayBillDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
    private LocalDateTime submittedOn;

    private String submittedBy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
    private LocalDateTime approvedOn;

    private String documentStatus;
    private String action;
    int totalCount;
    Long wfMstId;
    private String docType;
    private String irnVerified;
    private String supplyType;
}
