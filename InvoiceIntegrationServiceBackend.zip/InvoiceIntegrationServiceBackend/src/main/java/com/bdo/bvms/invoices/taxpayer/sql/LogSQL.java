package com.bdo.bvms.invoices.taxpayer.sql;

public class LogSQL {

    LogSQL() {

    }

    public static final String UPDATE_TOTAL_COUNT_TXUPLOADLOGS_SQL = "update upload_log set total_count=? where batch_no = ?";
    public static final String UPDATE_SUCCESS_COUNT_TXUPLOADLOGS_SQL = "update upload_log set success_count=? where batch_no = ?";
    public static final String UPDATE_ERROR_COUNT_TXUPLOADLOGS_SQL = "update upload_log set error_count=? where batch_no = ?";
    public static final String UPDATE_VALIDATION_START_TIME_STAMP = "update upload_log set upload_start_time=? where batch_no=?";

    public static final String UPDATE_VALIDATION_FINAL_TIME_STAMP = "update upload_log set upload_end_time=? where batch_no=?";

    public static final String UPDATE_SUCESSNERROR_COUNT = "update upload_log set error_count=?,success_count=?,total_count=? where batch_no=?";

    public static final String UPDATE_PROCESSSTATUS = "update upload_log set pld_upload_status=? where batch_no=?";
    public static final String UPDAT_ERROR_FILE_NAME = "update upload_log set error_file_location=? where batch_no=?";
    public static final String UPDATE_PLD_UPLOAD_STATUS = "update upload_log set pld_upload_status=? where batch_no=?";
    public static final String UPDATE_STAGE_STATE = "update upload_stage_log set pld_process_stage=?,pld_process_state=? where upload_log_id=?";
    public static final String GET_UPLOAD_LOG_ID = "select id from upload_log where batch_no=?";

    public static final String INSERT_INTO_TX_UPLOAD_BATCH_LOG = "INSERT INTO tx_upload_batch_log (batch_no, file_name, tenant_id,jsonReq,process_status,file_size,upload_by) VALUES (?,?,?,?,?,?,?)";
    public static final String INSERT_INTO_UPLOAD_LOG = "INSERT INTO upload_log (upload_source,entity_id,batch_no,pld_template_type,taxpayer_pan,taxpayer_gstin,file_name,fp,file_type,upload_start_time,file_size,base_file_location,is_custom_template,custom_template_id,pld_upload_status,pld_upload_source,created_by,parent_batch_no) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    public static final String INSERT_INTO_UPLOAD_STAGE_LOG = "INSERT INTO upload_stage_log (upload_log_id, pld_process_stage, pld_process_state,created_at,created_by,batch_no) VALUES (?,?,?,?,?,?)";
    public static final String GET_FROM_WHERE_101 = "select *  from tx_upload_batch_log where process_status=101";
    public static final String UPDATE_101_TO_102 = "update upload_log set pld_upload_status = 102 where batch_no = ?";
    public static final String UPDATE_102_TO_103 = "update upload_log set pld_upload_status = 103 where batch_no = ?";
    public static final String GET_BASE_FILE_LOC = "select base_file_location from upload_log where batch_no = '";
    public static final String GET_ERROR_FILE_LOC = "select error_file_location from upload_log where batch_no = '";
    public static final String GET_TOTAL_COUNT_OF_UPLOAD_LOG = "select count(*) from upload_log";
    public static final String UPDATE_ERROR_REMARKS = "update upload_log set pld_upload_status=?, remarks=? where batch_no=?";
	public static final String UPDATEFPLOG = "update upload_log set fp=? where batch_no=?";

}
