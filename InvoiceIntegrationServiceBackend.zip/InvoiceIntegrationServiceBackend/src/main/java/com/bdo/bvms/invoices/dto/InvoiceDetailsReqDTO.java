package com.bdo.bvms.invoices.dto;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@Getter
@Setter
public class InvoiceDetailsReqDTO extends PageReqDTO {

    String taxpayerGstin;
    String vendorGstin;
    String invoiceno;
    String invoicedate;
    String ewbno;
    String ewbdate;
    String detailType;
    String flag;
    String searchKey;
    String tabId;
    String id;
    String fp;
    String category;
    String isEwaybill;
    Integer ocrHeaderId;
    String vendorPan;
    String vendorCodeErp;
   
}
