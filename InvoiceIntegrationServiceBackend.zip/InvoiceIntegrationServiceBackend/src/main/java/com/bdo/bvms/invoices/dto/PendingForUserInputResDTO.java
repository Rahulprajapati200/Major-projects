package com.bdo.bvms.invoices.dto;

import java.time.LocalDateTime;

import com.bdo.bvms.invoices.util.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class PendingForUserInputResDTO {

    long id;
    String taxpayerGstin;
    String taxpayerPan;
    String vendorGstin;
    String vendorPan;
    String vendorLegalName;
    String vendorTradeName;
    String invoiceNo;
    String invoiceDate;

    String syncWithGstr2a;

    String syncWithGstr2b;

    String syncWithEwayBill;
    String taxableValue;
    String igst;
    String cgst;
    String sgst;
    String cess;
    String invoiceValue;

    String qrCodeValid;
    String ewayBillNo;
    String ewayBillDate;
    String poNumber;
    String grnNumber;

    String syncStatus;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateUtil.DATETIMEFORMATTERFORUI, timezone = "IST")
    LocalDateTime uploadDate;
    String lastSyncDate;
    String batchNo;

    Integer bookedErp;
    String getType;
    String fileType;
    int totalCount;
    String docType;
    String supplyType;
    String fp;
    String vendorCodeErp;

}
