package com.bdo.bvms.invoices.taxpayer.validationrule;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.bdo.bvms.invoices.constant.Constants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EWayBillValidationUtil {

    public boolean validGSTIN(String gstin) {

        try {

            if (!"0".equals(gstin)) {

                String gstinformatRegex = Constants.GSTINFORMAT_REGEX;
                String uinformatRegex = Constants.UINFORMAT_REGEX;
                String tdsREGEX = Constants.TDSREGEX;

                boolean isValidFormat = false;
                
                if(gstin.trim().equalsIgnoreCase("URP")) {
                	return true;
                }

                if (gstin.length() < 15) {
                    return isValidFormat;
                }

                if (checkPattern(gstin, gstinformatRegex) || checkPattern(gstin, tdsREGEX)
                                || checkPattern(gstin, uinformatRegex)) {
                    isValidFormat = verifyCheckDigit(gstin);
                }
                return isValidFormat;

            }

        } catch (Exception ex) {
            log.error("Error occured while execute validGSTIN function:", ex);
            return false;
        }

        return true;
    }

    public boolean checkPattern(String inputval, String regxpatrn) {
        boolean result = false;
        if ((inputval.trim()).matches(regxpatrn)) {
            result = true;
        }
        return result;
    }

    public boolean verifyCheckDigit(String gstinWCheckDigit) {
        Boolean isCDValid = false;
        String newGstninWCheckDigit = getGSTINWithCheckDigit(
                        gstinWCheckDigit.substring(0, gstinWCheckDigit.length() - 1));
        if (gstinWCheckDigit.trim().equals(newGstninWCheckDigit)) {
            isCDValid = true;
        }

        return isCDValid;
    }

    public String getGSTINWithCheckDigit(String gstinWOCheckDigit) {

        String gstnCodepointChars = Constants.GSTN_CODE_POINT_CHARS;

        int factor = 2;
        int sum = 0;
        int checkCodePoint = 0;
        char[] cpChars;
        char[] inputChars;

        if (gstinWOCheckDigit == null) {

            return "";
        }
        cpChars = gstnCodepointChars.toCharArray();
        inputChars = gstinWOCheckDigit.trim().toUpperCase().toCharArray();

        int mod = cpChars.length;
        for (int i = inputChars.length - 1; i >= 0; i--) {
            int codePoint = -1;

            for (int j = 0; j < cpChars.length; j++) {
                if (cpChars[j] == inputChars[i]) {
                    codePoint = j;
                }
            }
            int digit = factor * codePoint;
            factor = (factor == 2) ? 1 : 2;
            digit = (digit / mod) + (digit % mod);
            sum += digit;
        }
        checkCodePoint = (mod - (sum % mod)) % mod;

        return gstinWOCheckDigit + cpChars[checkCodePoint];

    }

    public boolean isAlphanumeric(String s) {

        boolean validInvoice = true;
        if (StringUtils.isBlank(s)) {
            validInvoice = false;
        }

        if (validInvoice) {

            Pattern p = Pattern.compile(Constants.ALPHA_NUMERIC_STRING);
            Matcher m = p.matcher(s);
            if (m.find()) {
                validInvoice = false;
            }
        }
        return validInvoice;
    }

    public boolean checkUDFLength(String udfx) {
        boolean isValid = Boolean.FALSE;
        if (udfx.length() > 200) {
            isValid = Boolean.TRUE;
            return isValid;
        }
        return isValid;

    }

    public boolean checkLength12G(String value) {
        boolean isValid = true;
        DecimalFormat df2 = new DecimalFormat(Constants.DECIMAL_FORMAT);
        boolean result = onlyNumeric(value);

        try {
            if (result && df2.format(Double.parseDouble(value)).length() > 12) {

                isValid = false;

            }
        } catch (Exception ex) {
            log.error("Error occured while execute checkLength12G function:", ex);
            isValid = false;
        }

        return isValid;
    }

//E-way bill Number should be 12 digits numeric

    public boolean onlyNumeric(String value) {
        boolean isValid = true;
        if (StringUtils.isBlank(value)) {
            isValid = false;
        } else {
            Pattern p = Pattern.compile(Constants.ONLYNUMERIC);
            Matcher m = p.matcher(value);

            if (m.find()) {
                isValid = false;
            }

        }

        return isValid;
    }

//E-way bill Number field is blank or more than 12 digits 

    public boolean checklenth12ebNo(String value) {
        boolean isvalid = true;
        if (StringUtils.isBlank(value) || StringUtils.isEmpty(value) || "0".equals(value) || value.length() != 12) {
            isvalid = false;
        }

        return isvalid;
    }

// date should not be empty or should not contain any character value or special
// character except -,/

    public boolean isDateEmpty(String value) {
        boolean isValid = Boolean.TRUE;

        try {
            if (value.equals("-")) {
                isValid = Boolean.FALSE;
            }
            if (StringUtils.isBlank(value)) {
                isValid = Boolean.FALSE;
            }
            if (StringUtils.isEmpty(value)) {
                isValid = Boolean.FALSE;
            }

            return isValid;
        } catch (Exception e) {
            log.error("Error occured while execute isDateEmpty function:", e);
            return Boolean.FALSE;
        }

    }

    public boolean ifeWayBillValidTillIsValid(String value) {
        boolean valid = Boolean.TRUE;
        if (value.matches(Constants.SPECIALCHARACTERS)) {
            valid = Boolean.FALSE;
        }
        return valid;

    }

    public boolean isValidDocDate(String value) {

        boolean isValid = true;
        if (value.matches(Constants.NONVALIDDATEFORMAT) || "-".equals(value)) {
            isValid = false;
        } else {
            try {
                if (value.indexOf("-") > -1) {
                    String[] parts = value.trim().split("-");
                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        return checkDateMonthYear(value, parts);
                    } else {
                        return false;
                    }
                } else {
                    String[] parts = value.trim().split("/");
                    if (parts[0].length() == 2 && parts[1].length() == 2 && parts[2].length() == 4) {
                        isValid = checkDateMonthYear(value, parts);
                    } else {
                        isValid = false;
                    }
                }

            } catch (Exception ex) {
                log.error("Error occured while execute isValidDocDate function:", ex);
                isValid = false;
            }
        }

        return isValid;

    }

    private boolean checkDateMonthYear(String value, String[] parts) throws ParseException {
        int date = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]);
        int year = Integer.parseInt(parts[2]);
        if (date != 00 && month != 00 && month < 13 && date < 32 && year != 0000) {

            Calendar c = Calendar.getInstance();
            c.set(Calendar.DAY_OF_MONTH, date);
            c.set(Calendar.MONTH, month - 1);
            c.set(Calendar.YEAR, year);

            SimpleDateFormat formatter = new SimpleDateFormat(Constants.VALIDDATEFORMAT);
            formatter.setLenient(false);
            formatter.parse(value);
            return true;

        } else {
            return false;
        }
    }

    // "check if the gstin is blank"
    public boolean isGstinBlank(String gstinNo) {
        boolean valid = Boolean.TRUE;
        if (StringUtils.isBlank(gstinNo) || "0".equals(gstinNo) || StringUtils.isEmpty(gstinNo)) {
            valid = Boolean.FALSE;
        }
        return valid;

    }

    // E-way bill Date cannot be before 1st July 2017

    public boolean isValidDateRange(String geteWayBillDate) {
        SimpleDateFormat sdformat = new SimpleDateFormat(Constants.VALIDDATEFORMAT);
        try {
            if (StringUtils.isBlank(geteWayBillDate)) {
                return false;
            }
            Date d1 = sdformat.parse("01-07-2017");
            Date d2 = sdformat.parse(geteWayBillDate);

            if (d1.compareTo(d2) > 0) {

                return false;
            }

        } catch (ParseException e) {
            log.error("Error occured while execute isValidDateRange function:", e);
            return false;
        }
        return true;
    }

//E-way bill Date cannot be future date

    public boolean ifFutureDate(String geteWayBillDate) {
        boolean valid = Boolean.TRUE;
        SimpleDateFormat sdformat = new SimpleDateFormat(Constants.VALIDDATEFORMAT);

        Date currentDate = new Date();
        Date localDate = null;

        if (StringUtils.isNotBlank(geteWayBillDate)) {
            try {
                localDate = sdformat.parse(geteWayBillDate);
            } catch (ParseException e) {
                log.error("Error occured while execute ifFutureDate function:", e);
                return Boolean.FALSE;
            }

            if (localDate.compareTo(currentDate) > 0) {
                valid = Boolean.FALSE;
            }
        }

        return valid;

    }

    // Purchase Order Date cannot exceed E-way bill Date

    public boolean ifExceedDate(String poDate, String geteWayBillDate) {
        SimpleDateFormat sdformat = new SimpleDateFormat(Constants.VALIDDATEFORMAT);
        try {
            Date d1 = sdformat.parse(poDate);
            Date d2 = sdformat.parse(geteWayBillDate);

            if (d1.compareTo(d2) > 0) {

                return false;
            }

        } catch (ParseException e) {
            log.error("Error occured while execute ifExceedDate function:", e);
            return false;
        }
        return true;
    }

    public boolean checkFuturePeriod(String fp) {
        boolean valid;
        String year = StringUtils.right(fp, 4);
        String month = StringUtils.left(fp, 2);
        int intYear = Integer.parseInt(year);
        int intMonth = Integer.parseInt(month);
        int currentYear = LocalDate.now().getYear();
        String strCY = Integer.toString(currentYear);
        int currentMonth = LocalDate.now().getMonthValue();
        String strCM = Integer.toString(currentMonth);
        String monthYear = month + year;
        int intMonthYear = Integer.parseInt(monthYear);
        int currentMonthYear = Integer.parseInt(strCM + strCY);
        if (intYear > currentYear || intMonth >= 13 || intMonth <= 0 || intMonthYear > currentMonthYear) {
            valid = true;
        } else {
            valid = false;
        }
        return valid;
    }

    public boolean isSpecialCharExistInEWayBillNo(String invoiceNo) {

        boolean validInvoice = true;

        if (StringUtils.isBlank(invoiceNo) || "0".equals(invoiceNo)) {
            validInvoice = false;
        }

        if (validInvoice) {
            Pattern p = Pattern.compile("[^0-9A-Za-z/-]");
            Matcher m = p.matcher(invoiceNo);
            if (m.find()) {
                validInvoice = false;
            } else {
                validInvoice = true;
            }
        }
        return validInvoice;
    }
}
