package com.bdo.bvms.invoices.custom.exception;

public class CsvWriteException extends Exception{
	private static final long serialVersionUID = 1L;

	public CsvWriteException() {
		super();
	}

	public CsvWriteException(Throwable cause) {

		super(cause);

	}

	public CsvWriteException(String message, Throwable cause) {

		super(message, cause);

	}
	
	public CsvWriteException(String message) {

		super(message);

	}
}
