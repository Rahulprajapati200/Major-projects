package com.bdo.bvms.common.service.impl;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.io.IOException;
import java.util.Arrays;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;


import com.bdo.bvms.common.service.UrpMailFileUploadService;
import com.bdo.bvms.einvoice.service.ProcessUploadService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.PowerAutomateRequestBody;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.bvms.invoices.util.ByteToMultiparFileConversion;
import com.bdo.bvms.urp.dao.UrpDataListDao;
import com.bdo.invoices.sftp.upload.dao.SftpUploadDao;
import com.google.gson.Gson;

import lombok.extern.slf4j.Slf4j;

import com.bdo.bvms.einvoice.vendor.service.ProcessUploadServiceVendor;
@Service
@Slf4j
public class UrpMailFileUploadServiceImpl implements UrpMailFileUploadService{

	@Autowired
	SftpUploadDao sftpUploadDao;
	
	@Autowired
	CommonDao commonDao;
	
	@Autowired
	UploadTransDao uploadTransDao;
	
	@Autowired
    ProcessUploadService uploadService;
	
	@Autowired
	ProcessUploadServiceVendor processUploadServiceVendor;

	
	@Autowired
	UrpDataListDao urpDataListDao;
	@Override
	public String callUploadUriService(PowerAutomateRequestBody powerAutomateRequestBody) throws IOException, VendorInvoiceServerException 
	{
		UploadRequestDTO uploadRequestDTO =new UploadRequestDTO();
		
		//String entityId=commonDao.getEntityId(powerAutomateRequestBody.getGstin());
//		String date="";
//		try {
//		 date=powerAutomateRequestBody.getMailDate().substring(3,5)+powerAutomateRequestBody.getMailDate().substring(6,10);
//		}
//		catch(Exception e)
//		{
//			throw new VendorInvoiceServerException(messageSource.getMessage("iis.upload.standard.error", null,
//                    LocaleContextHolder.getLocale()));
//		}
	
		log.info("Json Request From Power Automate :" + "{"+"EMail: "+powerAutomateRequestBody.getEmailFrom()+ " , "+"EntityId: "+powerAutomateRequestBody.getEntityId()+ " , "+"FileName: "+powerAutomateRequestBody.getFileName()+ " , "
				+"Gstin: "+powerAutomateRequestBody.getGstin()+ " , "+"IsVendor: "+powerAutomateRequestBody.getIsVendor()+ " , "+"MailDate: "+powerAutomateRequestBody.getMailDate()+ " , "+"UserId: "+powerAutomateRequestBody.getUserId() +"}");
		Gson gson = new Gson();
		String powerAutoJson = gson.toJson(powerAutomateRequestBody);
		
		try {
		urpDataListDao.updateEmailDocumentReceivedPullLog(powerAutoJson);
		}
		catch(Exception ex)
		{
			urpDataListDao.updateEmailDocumentReceivedErrorLog(powerAutomateRequestBody,Constants.BASE64ERRORMESSAGE);
			log.error("Exception in inserting Json request body in Database ",ex);
		}
		MultipartFile[] fileArray=new MultipartFile[1];
		try {
		String b64 = powerAutomateRequestBody.getFile();
	    byte[] decodedFile = Base64.getDecoder().decode(b64);
        String fileName = powerAutomateRequestBody.getFileName();
        CommonsMultipartFile multipartFile = ByteToMultiparFileConversion.convert(decodedFile, fileName);
        fileArray[0]=multipartFile;
		}
		catch(Exception ex)
		{
			urpDataListDao.updateEmailDocumentReceivedErrorLog(powerAutomateRequestBody,Constants.BASE64FILECRETIONERRORMESSAGE);
			log.error("Exception in in reading or in Conversion of base64 file ",ex);
		}
		uploadRequestDTO.setFp(Arrays.asList(powerAutomateRequestBody.getMailDate()));
		uploadRequestDTO.setFile(fileArray);
		uploadRequestDTO.setEntityId(powerAutomateRequestBody.getEntityId());
		uploadRequestDTO.setGstinOrPan("1");
		uploadRequestDTO.setGstinOrPanList(Arrays.asList(powerAutomateRequestBody.getGstin()));
		uploadRequestDTO.setUserId(powerAutomateRequestBody.getUserId());
		//uploadRequestDTO.setUserTypeId(0);
		uploadRequestDTO.setModuleID(65);
		uploadRequestDTO.setUploadSftpSource("3");
		if ("0".equals(powerAutomateRequestBody.getIsVendor())) {
			uploadRequestDTO.setModuleID(65);
			uploadRequestDTO.setTemplatetypepldCode("332");
			return uploadService.uploadAndProcessFile(uploadRequestDTO);
		} else {
			uploadRequestDTO.setTemplatetypepldCode("337");
			uploadRequestDTO.setModuleID(165);
			return processUploadServiceVendor.uploadAndProcessVendorFile(uploadRequestDTO);
		}
		 
		
        
		
	}
}
