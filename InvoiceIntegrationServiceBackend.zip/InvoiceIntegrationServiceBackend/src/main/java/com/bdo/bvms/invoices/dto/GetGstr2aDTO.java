package com.bdo.bvms.invoices.dto;

import java.math.BigDecimal;

import org.springframework.data.relational.core.mapping.Column;

import com.bdo.bvms.invoices.util.NumberUtils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class GetGstr2aDTO {

    @Column(value = "taxpayer_gstin")
    String taxpayerGstin;

    @Column(value = "vendor_gstin")
    String vendorGstin;

    @Column(value = "title")
    String title;

    @Column(value = "taxable_amount")
    String taxableAmount = "0.00";

    @Column(value = "pos")
    String placeSupply;

    @Column(value = "igst_amount")
    String igstAmount = "0.00";

    @Column(value = "cgst_amount")
    String cgstAmount = "0.00";

    @Column(value = "sgst_amount")
    String sgstAmount = "0.00";

    @Column(value = "cess_amount")
    String cessAmount = "0.00";

    String invoiceValue = "0.00";

    @Column(value = "invoice_no")
    String invoiceNo;

    @Column(value = "invoice_date")
    String invoiceDate;

    @Column(value = "is_sync")
    boolean isSync;

    @Column(value = "defaultSyncStatus")
    boolean defaultSyncStatus;

    @Column(value = "forcesyncstatus")
    boolean forceSyncStatus;
    
    
    String fp;
    String category;

    public void setTaxableAmount(BigDecimal value) {
        this.taxableAmount = NumberUtils.getFormattedGrouppedNumber(value);

    }

    public void setIgstAmount(BigDecimal value) {
        this.igstAmount = NumberUtils.getFormattedGrouppedNumber(value);

    }

    public void setCgstAmount(BigDecimal value) {
        this.cgstAmount = NumberUtils.getFormattedGrouppedNumber(value);

    }

    public void setSgstAmount(BigDecimal value) {
        this.sgstAmount = NumberUtils.getFormattedGrouppedNumber(value);

    }

    public void setCessAmount(BigDecimal value) {
        this.cessAmount = NumberUtils.getFormattedGrouppedNumber(value);

    }

    public void setInvoiceValue(BigDecimal value) {
        this.invoiceValue = NumberUtils.getFormattedGrouppedNumber(value);

    }

}
