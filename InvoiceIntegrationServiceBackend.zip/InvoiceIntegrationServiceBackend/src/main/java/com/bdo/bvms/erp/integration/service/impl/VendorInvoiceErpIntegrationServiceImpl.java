package com.bdo.bvms.erp.integration.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.bdo.bvms.einvoice.service.UploadLogService;
import com.bdo.bvms.einvoice.service.UploadNDownloadFileService;
import com.bdo.bvms.erp.integration.dao.VendorInvoiceErpIntegrationDao;
import com.bdo.bvms.erp.integration.dto.AddlDocDtls;
import com.bdo.bvms.erp.integration.dto.AttribDtls;
import com.bdo.bvms.erp.integration.dto.BchDtls;
import com.bdo.bvms.erp.integration.dto.BuyerDtls;
import com.bdo.bvms.erp.integration.dto.ContrDtls;
import com.bdo.bvms.erp.integration.dto.DispDtls;
import com.bdo.bvms.erp.integration.dto.DocDtls;
import com.bdo.bvms.erp.integration.dto.DocPerdDtls;
import com.bdo.bvms.erp.integration.dto.ERPRequestDTO;
import com.bdo.bvms.erp.integration.dto.ErpInvoiceIntegrationRequestDto;
import com.bdo.bvms.erp.integration.dto.EwbDtls;
import com.bdo.bvms.erp.integration.dto.InvoicePostingDto;
import com.bdo.bvms.erp.integration.dto.Item;
import com.bdo.bvms.erp.integration.dto.ItemList;
import com.bdo.bvms.erp.integration.dto.PrecDocDtls;
import com.bdo.bvms.erp.integration.dto.RefDtls;
import com.bdo.bvms.erp.integration.dto.SellerDtls;
import com.bdo.bvms.erp.integration.dto.ShipDtls;
import com.bdo.bvms.erp.integration.dto.TranDtls;
import com.bdo.bvms.erp.integration.dto.ValDtls;
import com.bdo.bvms.erp.integration.service.VendorInvoiceErpIntegrationService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.AzureConnectionCredentialsDTO;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.ResponseBean;
import com.bdo.bvms.invoices.dto.UploadLogDto;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.bvms.invoices.util.CommonUtils;
import com.bdo.bvms.ocr.repository.FileOcrProcessAndSaveRepository;
import com.bdo.bvms.ocr.service.InvoiceOcrFileUploadService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.Files;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class VendorInvoiceErpIntegrationServiceImpl implements VendorInvoiceErpIntegrationService {
	
	public static final  String CLASSNAME = "VendorInvoiceErpIntegrationServiceImpl";
	@Autowired
	InvoiceOcrFileUploadService invoiceOcrFileUploadService;
	
	@Autowired
	UploadLogService uploadLogService;
	
	@Autowired
	UploadNDownloadFileService uploadFileService;
	
	@Autowired
	CommonDao commonDao;
	
	@Autowired
	FileOcrProcessAndSaveRepository fileOcrProcessAndSaveRepository;
	
	@Autowired
    UploadTransDao uploadTransDao;
	
	@Autowired
	VendorInvoiceErpIntegrationDao vendorInvoiceErpIntegrationDao;
	
	@Value("${mst.database-name}")
    String mstDatabseName;
	
	@Value("${temp.folder.path}")
    String tempFolder;
	
	
	
	@Override
	public String processForOcrFileUpload(ErpInvoiceIntegrationRequestDto reqDto) throws VendorInvoiceServerException {
		String methodname = "processForOcrFileUpload";
		 log.info("Classname: "+ CLASSNAME +" Methodname: "+ methodname+ " Started");
		 try {
			 
			 Long key = vendorInvoiceErpIntegrationDao.insertIntoErpRequestLog(reqDto.toString(),"Upload PDF File For OCR");
                    UploadRequestDTO uploadRequestDTO = new UploadRequestDTO().builder()
				                            .gstinOrPan(Constants.GSTIN)
				                           .gstinOrPanList(new ArrayList<>(Arrays.asList(reqDto.getTaxpayerGstin())))
				                           .fp(new ArrayList<>(Arrays.asList("092023")))
				                           .templatetypepldCode("340")
				                           .fileType(Constants.PDF)
				                           .uploadSftpSource("2").build();
                    
				                            
		String batchNo = CommonUtils.getBatchNo(uploadRequestDTO);
		
		MultipartFile file = convertFileBytesToFile(reqDto ,batchNo);
		
		uploadLogService.saveInUploadLog(file, uploadRequestDTO, batchNo);

		
		 AzureConnectionCredentialsDTO storageCredentials = commonDao.getAzureCredentialFromDB(0, "blob");
		 uploadFileService.uploadFileToAzureBlob(file, uploadRequestDTO, batchNo, storageCredentials);
		 
		 UploadReqDTO uploadDTO = new UploadReqDTO();
		 
		 setUploadDto(uploadRequestDTO, batchNo, uploadDTO, 0);
		 
		 invoiceOcrFileUploadService.readAndSaveUnprocessedData(uploadDTO, storageCredentials);

		 vendorInvoiceErpIntegrationDao.updateErpRequestLog(batchNo, null, key);
        log.info("Classname: "+ CLASSNAME +" Methodname: "+ methodname+ " Completed");
        return batchNo;
	   }
        catch (Exception e) {
			log.error("Error occured while uplaoding file for OCR Process " , e);
			throw new VendorInvoiceServerException("Error occured while uplaoding file for OCR Process ");
		}
		
	}
	
	
	 @Override
	    public Map<String, Object> getVendorinvoiceJson(String  ackNo) {

	        List<InvoicePostingDto> eWayBillJsonList = new ArrayList<>();
	        Map<String, Object> data = new HashMap<>();

	        Map<String, Object> resultSet = new HashMap<>();
	        
	        Long key = vendorInvoiceErpIntegrationDao.insertIntoErpRequestLog(ackNo,"Fetch OCR Invoice Details");
	        
	        try {
	           resultSet = vendorInvoiceErpIntegrationDao.getErpInvoiceDataParentProcCall(ackNo);
	        }
	        catch(Exception ex) {
	        	 log.error("Some error occured at the time fetching records", ex);
	        }

	        if (!resultSet.isEmpty()) {
	            @SuppressWarnings("unchecked")
	            List<Map<String, Object>> dataList = (List<Map<String, Object>>) resultSet.get("#result-set-1");
	            if(dataList.get(0).get("OUTPUT") != null && dataList.get(0).get("OUTPUT").equals("OCR is not processed yet. Please try after some time.")){
	            	data.put("ErrorMessage", "OCR is not processed yet. Please try after some time.");
	    	        data.put("ResponseData", eWayBillJsonList);

	    	        return data;
	            }
	            Set<String> uniqueId = new HashSet<>();
	            ItemList itemList = new ItemList();
	            ArrayList<Item> itemDetails = new ArrayList<>();
	            
	            TranDtls tranDtls = new TranDtls();
	            DocDtls docDtls = new DocDtls();
	            SellerDtls sellerDtls = new SellerDtls();
	            BuyerDtls buyerDtls = new BuyerDtls();
	            DispDtls dispDtls = new DispDtls();
	            ShipDtls shipDtls = new ShipDtls();
	            ValDtls valDtls = new ValDtls();
	            RefDtls refDtls = new RefDtls();
	            EwbDtls ewbDtls = new EwbDtls();
	            ArrayList<AddlDocDtls> addlDocDtlsList = new ArrayList<>();
	            int flag = 0;
	            String currentUniqueId = null;
	            String batchNo = null;
	           for(int i=0;i<=dataList.size();i++) {
	            	if(i>=dataList.size() || (!uniqueId.contains(dataList.get(i).get("unique_id")) && flag == 1)){
	            		InvoicePostingDto headerLevelData = new InvoicePostingDto();
	            		headerLevelData.setBatchNo(batchNo);
	            		headerLevelData.setTranDtls(tranDtls);
	            		headerLevelData.setDocDtls(docDtls);
	            		headerLevelData.setSellerDtls(sellerDtls);
	            		headerLevelData.setBuyerDtls(buyerDtls);
	            		headerLevelData.setDispDtls(dispDtls);
	            		headerLevelData.setShipDtls(shipDtls);
	            		headerLevelData.setItemList(itemList);
	            		headerLevelData.setValDtls(valDtls);
	            		headerLevelData.setPayDtls("");
	            		headerLevelData.setRefDtls(refDtls);
	            		headerLevelData.setAddlDocDtls(addlDocDtlsList);
	            		headerLevelData.setEwbDtls(ewbDtls);

	                    eWayBillJsonList.add(headerLevelData);
	                    if(i>=dataList.size()) {
	                    	break;
	                    }
	                    
	            		
	            	}

	                if (!uniqueId.contains(dataList.get(i).get("unique_id"))) {
	                	uniqueId.add((String) dataList.get(i).get("unique_id"));
	                	currentUniqueId = (String) dataList.get(i).get("unique_id");
	                	flag = 1;
	                	itemList = new ItemList();
	                	itemDetails = new ArrayList<>();

	                	batchNo = (String) dataList.get(i).get("batch_no");
	                    tranDtls = new TranDtls();
	                    tranDtls.setTaxSch((String) dataList.get(i).get("tranDtls_taxSch"));
	                    tranDtls.setSupTyp((String) dataList.get(i).get("tranDtls_supTyp"));

	                    docDtls = new DocDtls();
	                    docDtls.setDt((String) dataList.get(i).get("docDtls_dt"));
	                    docDtls.setNo((String) dataList.get(i).get("docDtls_no"));
	                    docDtls.setTyp((String) dataList.get(i).get("docDtls_typ"));

	                    sellerDtls = new SellerDtls();
	                    sellerDtls.setAddr1((String) dataList.get(i).get("sellerDtls_addr1"));
	                    sellerDtls.setAddr2((String) dataList.get(i).get("sellerDtls_addr2"));
	                    sellerDtls.setEm((String) dataList.get(i).get("sellerDtls_em"));
	                    sellerDtls.setGstin((String) dataList.get(i).get("sellerDtls_gstin"));
	                    sellerDtls.setLglNm((String) dataList.get(i).get("sellerDtls_lglNm"));
	                    sellerDtls.setLoc((String) dataList.get(i).get("sellerDtls_loc"));
	                    sellerDtls.setPh((String) dataList.get(i).get("sellerDtls_ph"));
	                    sellerDtls.setPin((String) dataList.get(i).get("sellerDtls_pin"));
	                    sellerDtls.setStcd((String) dataList.get(i).get("sellerDtls_stcd"));
	                    sellerDtls.setTrdNm((String) dataList.get(i).get("sellerDtls_trdNm"));
	                    sellerDtls.setVc((String) dataList.get(i).get("sellerDtls_vc"));

	                     buyerDtls = new BuyerDtls();
	                    buyerDtls.setAddr1((String) dataList.get(i).get("buyerDtls_addr1"));
	                    buyerDtls.setAddr2((String) dataList.get(i).get("buyerDtls_addr2"));
	                    buyerDtls.setEm((String) dataList.get(i).get("buyerDtls_em"));
	                    buyerDtls.setGstin((String) dataList.get(i).get("buyerDtls_gstin"));
	                    buyerDtls.setLglNm((String) dataList.get(i).get("buyerDtls_lglNm"));
	                    buyerDtls.setLoc((String) dataList.get(i).get("buyerDtls_loc"));
	                    buyerDtls.setPh((String) dataList.get(i).get("buyerDtls_ph"));
	                    buyerDtls.setPin((String) dataList.get(i).get("buyerDtls_pin"));
	                    buyerDtls.setStcd((String) dataList.get(i).get("buyerDtls_stcd"));
	                    buyerDtls.setTrdNm((String) dataList.get(i).get("buyerDtls_trdNm"));
	                    buyerDtls.setPos((String) dataList.get(i).get("buyerDtls_pos"));

	                    dispDtls = new DispDtls();
	                    dispDtls.setAddr1((String) dataList.get(i).get("dispDtls_addr1"));
	                    dispDtls.setAddr2((String) dataList.get(i).get("dispDtls_addr2"));
	                    dispDtls.setLoc((String) dataList.get(i).get("dispDtls_loc"));
	                    dispDtls.setNm((String) dataList.get(i).get("dispDtls_nm"));
	                    dispDtls.setPin((String) dataList.get(i).get("dispDtls_pin"));
	                    dispDtls.setStcd((String) dataList.get(i).get("dispDtls_stcd"));

	                    shipDtls = new ShipDtls();
	                    shipDtls.setAddr1((String) dataList.get(i).get("shipDtls_addr1"));
	                    shipDtls.setAddr2((String) dataList.get(i).get("shipDtls_addr2"));
	                    shipDtls.setGstin((String) dataList.get(i).get("shipDtls_gstin"));
	                    shipDtls.setLglNm((String) dataList.get(i).get("shipDtls_lglNm"));
	                    shipDtls.setLoc((String) dataList.get(i).get("shipDtls_loc"));
	                    shipDtls.setPin((String) dataList.get(i).get("shipDtls_pin"));
	                    shipDtls.setStcd((String) dataList.get(i).get("shipDtls_stcd"));
	                    shipDtls.setTrdNm((String) dataList.get(i).get("shipDtls_trdNm"));

	                    valDtls = new ValDtls();
	                    valDtls.setAssVal(dataList.get(i).get("valDtls_assVal"));
	                    valDtls.setCesVal(dataList.get(i).get("valDtls_cesVal"));
	                    valDtls.setCgstVal(dataList.get(i).get("valDtls_cgstVal"));
	                    valDtls.setDiscount((Long) dataList.get(i).get("valDtls_discount"));
	                    valDtls.setIgstVal(dataList.get(i).get("valDtls_igstVal"));
	                    valDtls.setOthChrg((Long) dataList.get(i).get("valDtls_othChrg"));
	                    valDtls.setRndOffAmt((Long) dataList.get(i).get("valDtls_rndOffAmt"));
	                    valDtls.setSgstVal(dataList.get(i).get("valDtls_sgstVal"));
	                    valDtls.setStCesVal((Long) dataList.get(i).get("valDtls_stCesVal"));
	                    valDtls.setTotInvVal(dataList.get(i).get("valDtls_totInvVal"));
	                    valDtls.setTotInvValFc((Long) dataList.get(i).get("valDtls_totInvValFc"));

	                    refDtls = new RefDtls();
	                    refDtls.setInvRm((String) dataList.get(i).get("refDtls_invRm"));
	                    DocPerdDtls docPerdDtlsObject = new DocPerdDtls();
	                    docPerdDtlsObject.setInvEndDt((String) dataList.get(i).get("refDtls_docPerdDtlsObject_invStDt"));
	                    docPerdDtlsObject.setInvStDt((String) dataList.get(i).get("refDtls_docPerdDtlsObject_invendDt"));
	                    refDtls.setDocPerdDtlsObject(docPerdDtlsObject);
	                    List<PrecDocDtls> precDocDtlsList = new ArrayList<>();
	                    PrecDocDtls precDocDtls = new PrecDocDtls();
	                    precDocDtls.setInvDt((String) dataList.get(i).get("refDtls_precDocDtls_invdt"));
	                    precDocDtls.setInvNo((String) dataList.get(i).get("refDtls_precDocDtls_invNo"));
	                    precDocDtls.setOthRefNo((String) dataList.get(i).get("refDtls_precDocDtls_othRefNo"));
	                    precDocDtlsList.add(precDocDtls);
	                    refDtls.setPrecDocDtls(precDocDtlsList);

	                    List<ContrDtls> contrDtlsList = new ArrayList<>();
	                    ContrDtls contrDtls = new ContrDtls();
	                    contrDtls.setContrrefr((String) dataList.get(i).get("contrDtls_contrrefr"));
	                    contrDtls.setExtrefr((String) dataList.get(i).get("contrDtls_extrefr"));
	                    contrDtls.setPoRefDt((String) dataList.get(i).get("contrDtls_poRefDt"));
	                    contrDtls.setPorefr((String) dataList.get(i).get("contrDtls_porefr"));
	                    contrDtls.setProjrefr((String) dataList.get(i).get("contrDtls_projrefr"));
	                    contrDtls.setRecAdvDt((String) dataList.get(i).get("contrDtls_recAdvDt"));
	                    contrDtls.setRecAdvRefr((String) dataList.get(i).get("contrDtls_recAdvRefr"));
	                    contrDtls.setTendrefr((String) dataList.get(i).get("contrDtls_tendrefr"));
	                    contrDtlsList.add(contrDtls);
	                    refDtls.setContrDtls(contrDtlsList);

	                    addlDocDtlsList = new ArrayList<>();
	                    AddlDocDtls addlDocDtls = new AddlDocDtls();
	                    addlDocDtls.setBvmsInvUuid((String) dataList.get(i).get("addlDocDtls_bvmsInvUuid"));
	                    addlDocDtls.setDocs((String) dataList.get(i).get("addlDocDtls_docs"));
	                    addlDocDtls.setInfo((String) dataList.get(i).get("addlDocDtls_info"));
	                    addlDocDtls.setUrl((String) dataList.get(i).get("addlDocDtls_URL"));
	                    addlDocDtlsList.add(addlDocDtls);

	                    ewbDtls = new EwbDtls();
	                    ewbDtls.setDistance((String) dataList.get(i).get("ewbDtls_distance"));
	                    ewbDtls.setTransdocDt((String) dataList.get(i).get("ewbDtls_transdocDt"));
	                    ewbDtls.setTransdocno((String) dataList.get(i).get("ewbDtls_transdocno"));
	                    ewbDtls.setTransid((String) dataList.get(i).get("ewbDtls_transid"));
	                    ewbDtls.setTransMode((String) dataList.get(i).get("ewbDtls_transMode"));
	                    ewbDtls.setTransname((String) dataList.get(i).get("ewbDtls_transname"));
	                    ewbDtls.setVehno((String) dataList.get(i).get("ewbDtls_vehno"));
	                    ewbDtls.setVehtype((String) dataList.get(i).get("ewbDtls_vehtype"));

	                }

	                if (currentUniqueId.equals(dataList.get(i).get("unique_id"))) {
	                    Item item = new Item();
	                    BchDtls bchDtls = new BchDtls();
	                    List<AttribDtls> attribDtlsList = new ArrayList<>();
	                    AttribDtls attribDtls = new AttribDtls();

	                    item.setSlNo(dataList.get(i).get("itemList_slNo"));
	                    item.setPrdDesc((String) dataList.get(i).get("itemList_prdDesc"));
	                    item.setIsServc((String) dataList.get(i).get("itemList_isServc"));
	                    item.setHsnCd((String) dataList.get(i).get("itemList_hsnCd"));
	                    bchDtls.setExpdt((String) dataList.get(i).get("itemList_bchDtls_expdt"));
	                    bchDtls.setNm((String) dataList.get(i).get("itemList_bchDtls_nm"));
	                    bchDtls.setWrDt((String) dataList.get(i).get("itemList_bchDtls_wrDt"));
	                    item.setBchDtls(bchDtls);
	                    item.setBarcde((String) dataList.get(i).get("itemList_barcde"));
	                    item.setQty(dataList.get(i).get("itemList_qty"));
	                    item.setFreeQty(dataList.get(i).get("itemList_freeQty"));
	                    item.setUnit((String) dataList.get(i).get("itemList_unit"));
	                    item.setUnitPrice(dataList.get(i).get("itemList_unitPrice"));
	                    item.setTotAmt(dataList.get(i).get("itemList_totAmt"));
	                    item.setDiscount((Long) dataList.get(i).get("itemList_discount"));
	                    item.setPreTaxVal(dataList.get(i).get("itemList_preTaxVal"));
	                    item.setAssAmt(dataList.get(i).get("itemList_assAmt"));
	                    item.setIgstRt(dataList.get(i).get("itemList_igstRt"));
	                    item.setIgstAmt(dataList.get(i).get("itemList_igstAmt"));
	                    item.setCgstRt(dataList.get(i).get("itemList_cgstRt"));
	                    item.setCgstAmt(dataList.get(i).get("itemList_sgstAmt"));
	                    item.setSgstRt(dataList.get(i).get("itemList_sgstRt"));
	                    item.setSgstAmt(dataList.get(i).get("itemList_sgstAmt"));
	                    item.setCesRt(dataList.get(i).get("itemList_cesRt"));
	                    item.setCesAmt(dataList.get(i).get("itemList_cesAmt"));
	                    item.setCesNonAdvlAmt((Long) dataList.get(i).get("itemList_cesNonAdvlAmt"));
	                    item.setStateCesRt((Long) dataList.get(i).get("itemList_stateCesRt"));
	                    item.setStateCesAmt((Long) dataList.get(i).get("itemList_stateCesAmt"));
	                    item.setStateCesNonAdvlAmt((Long) dataList.get(i).get("itemList_stateCesNonAdvlAmt"));
	                    item.setOthChrg((Long) dataList.get(i).get("itemList_othChrg"));
	                    item.setTotItemVal(dataList.get(i).get("itemList_totItemVal"));
	                    item.setOrdLineRef((String) dataList.get(i).get("itemList_ordLineRef"));
	                    item.setOrgCntry((String) dataList.get(i).get("itemList_orgCntry"));
	                    item.setPrdSlNo((String) dataList.get(i).get("itemList_prdSlNo"));
	                    attribDtls.setNm("");
	                    attribDtls.setVal("");
	                    attribDtlsList.add(attribDtls);
	                    item.setAttribDtls(attribDtlsList);
	                    itemDetails.add(item);

	                }
	                itemList.setItem(itemDetails); 

	            }
	 
	        }

	        // Initialize the Jackson ObjectMapper
	        ObjectMapper objectMapper = new ObjectMapper();
	        // Convert the object to JSON
	        String responseJson = "";
	        try {
	            responseJson = objectMapper.writeValueAsString(eWayBillJsonList);
	        } catch (JsonProcessingException e) {
	            log.error("Error coming in converting response json to string.");
	        }
	        vendorInvoiceErpIntegrationDao.updateErpRequestLog(responseJson, ackNo, key);
	        data.put("ResponseData", eWayBillJsonList);
	        data.put("AcknowledgementNo", ackNo);

	        return data;
	    }
	
	private void setUploadDto(UploadRequestDTO uploadRequestDTO, String batchNo, UploadReqDTO uploadReqDTO,
			int uploadLogId) {
		uploadReqDTO.setFileType(uploadRequestDTO.getFileType());
		uploadReqDTO.setPo(uploadRequestDTO.getPo());
		uploadReqDTO.setPoDate(uploadRequestDTO.getPoDate());
		uploadReqDTO.setGstinOrPanList(uploadRequestDTO.getGstinOrPanList());
		uploadReqDTO.setUploadType(uploadRequestDTO.getTemplatetypepldCode());
		uploadReqDTO.setTemplateType(uploadRequestDTO.getTemplatetypepldCode());
		uploadReqDTO.setPanOrGstn(uploadRequestDTO.getGstinOrPan());
		uploadReqDTO.setFp(uploadRequestDTO.getFp());
		uploadReqDTO.setBatchNo(batchNo);
		uploadReqDTO.setUploadLogId(uploadLogId);
		uploadReqDTO.setId(uploadRequestDTO.getUserId());
		uploadReqDTO.setVendorGstin(uploadRequestDTO.getVendorGstin());
		uploadReqDTO.setInvoiceNo(uploadRequestDTO.getInvoiceNo());
		uploadReqDTO.setInvoiceDate(uploadRequestDTO.getInvoiceDate());
		uploadReqDTO.setDocType(uploadRequestDTO.getDocType());
		uploadReqDTO.setIsCustomTemplate(uploadRequestDTO.getIsCustomTemplate());
		uploadReqDTO.setCustomTemplateId(uploadRequestDTO.getCustomtemplateID());
		uploadReqDTO.setGstinOrPanList(uploadRequestDTO.getGstinOrPanList());
		uploadReqDTO.setUserId(uploadRequestDTO.getUserId());
		uploadLogService.saveInUploadStageLog(uploadRequestDTO, uploadReqDTO);
	}
	
	 @Override
     public ERPRequestDTO getdbErpDetails() {
			
			String erpAppKey=vendorInvoiceErpIntegrationDao.getErpDbDetails();
			String clientErpSecret=vendorInvoiceErpIntegrationDao.getErpSecretDetail();
			return new ERPRequestDTO(erpAppKey,clientErpSecret);
		}
	 
	 
	 private MultipartFile convertFileBytesToFile(ErpInvoiceIntegrationRequestDto reqDto,String batchNo) throws VendorInvoiceServerException, IOException {
		 
		 byte[] decodedBytes = Base64.getDecoder().decode(reqDto.getFileContent());
		 String fileName = new StringBuilder().append(tempFolder).append(System.getProperty(Constants.FILESEPERATOR))
				 .append(Constants.ERP).append(batchNo).append(Constants.DOTSEPARATOR)
                 .append(Constants.PDF).toString();
		 File file = new File(fileName);
		 FileInputStream fileInputStream = null;
         OutputStream outputStream = null;
		 try {
	            Files.write(Paths.get(fileName), decodedBytes);
	            DiskFileItem fileItem = new DiskFileItem("file", Files.probeContentType(file.toPath()), false, file.getName(), (int) file.length() , file.getParentFile());
                fileInputStream = new FileInputStream(file);
	            outputStream = fileItem.getOutputStream();
	            IOUtils.copy(fileInputStream, outputStream);
	            return new CommonsMultipartFile(fileItem);
	        } catch (IOException e) {
	            log.error("Unable to write File Bytes in File :",e);
	            throw new VendorInvoiceServerException("Unable to write File Bytes in File :",e);
	        }
		 finally {
			 if(fileInputStream != null) {
			    fileInputStream.close();
			 }
			 if(outputStream != null) {
				 outputStream.close();
				 }
			 if (file.exists()) {
			       Files.delete(file.toPath());
			    }
		 }
	 }
	
	

}
