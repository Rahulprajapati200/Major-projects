
package com.bdo.bvms.einvoice.service.impl;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.bdo.bvms.einvoice.service.UploadLogService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceSavedataOnUploadException;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.UploadLogDto;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.dto.UploadRequestDTO;
import com.bdo.bvms.invoices.dto.UploadStageLogDto;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UploadLogServiceImpl implements UploadLogService {

    @Autowired
    UploadTransDao uploadTransDao;

    @Autowired
    CommonDao commonDao;

    @Value("${mst.database-name}")
    String mstDatabseName;

    @Override
    public void saveInUploadLog(MultipartFile childFile, UploadRequestDTO uploadRequestDTO, String batchNo)
                    throws VendorInvoiceServerException, VendorInvoiceSavedataOnUploadException {

        UploadLogDto uploadLog = new UploadLogDto();
        Set<String> uniquePans = new HashSet<>();

        if (Constants.PAN.equals(uploadRequestDTO.getGstinOrPan())) {
            uploadLog.setTaxpayerPan(uploadRequestDTO.getGstinOrPanList().get(0));

            uploadLog.setTaxpayerGstin(String.join(",",
                            commonDao.getGstinFromDB(uploadRequestDTO.getGstinOrPanList().get(0), mstDatabseName)));
        } else if (Constants.GSTIN.equals(uploadRequestDTO.getGstinOrPan())) {
            uploadLog.setTaxpayerGstin(String.join(",", uploadRequestDTO.getGstinOrPanList()));
            for (String gstin : uploadRequestDTO.getGstinOrPanList()) {
                String pan = gstin.substring(2, 12);
                uniquePans.add(pan);
            }
            uploadLog.setTaxpayerPan(String.join(",", new ArrayList<>(uniquePans)));

        }

        uploadLog.setTemplateType(uploadRequestDTO.getTemplatetypepldCode());
        uploadLog.setFileSize(childFile.getSize());
        uploadLog.setFileName(childFile.getOriginalFilename());
        uploadLog.setBatchNo(batchNo);
        uploadLog.setPaBatchNo(uploadRequestDTO.getPaBatchNo());
        uploadLog.setPldUploadStatus(Constants.UPLOAD_INVOICES_PLD_STATUS_INPROGRESS);
        if (!"1".equals(uploadRequestDTO.getUploadSftpSource())) {
            uploadLog.setFp(String.join(",", uploadRequestDTO.getFp()));
        }
        if ("1".equals(uploadRequestDTO.getUploadSftpSource())) {
            uploadLog.setUploadSource(Constants.SFTPUPLOADSOURCE);
        } 
        else if ("2".equals(uploadRequestDTO.getUploadSftpSource())) {
            uploadLog.setUploadSource(Constants.SAPUPLOADSOURCE);
        }
        else if ("3".equals(uploadRequestDTO.getUploadSftpSource())) {
            uploadLog.setUploadSource(Constants.EMAIL);
        }
        else {
            uploadLog.setUploadSource(Constants.WEBUPLOADSOURCE);
        }

        uploadLog.setFileType(uploadRequestDTO.getFileType());
        uploadLog.setPldUploadSource(Integer.toString(uploadRequestDTO.getModuleID()));
        if (StringUtils.isBlank(uploadRequestDTO.getCustomtemplateID())
                        || "".equals(uploadRequestDTO.getCustomtemplateID())) {
            uploadRequestDTO.setCustomtemplateID("0");
        }
        uploadLog.setCustomTemplateId(Integer.valueOf(uploadRequestDTO.getCustomtemplateID()));
        uploadLog.setEntityId(uploadRequestDTO.getEntityId());
        uploadLog.setCustomTemplate("1".equals(uploadRequestDTO.getIsCustomTemplate()));
        uploadLog.setId(uploadRequestDTO.getUserId());
        uploadLog.setUploadStartTime(Timestamp.from(Instant.now()));
        uploadLog.setBaseFileLocation(batchNo + Constants.BASE_DOT + uploadRequestDTO.getFileType());
        uploadLog.setCreatedBy(String.valueOf(uploadRequestDTO.getUserId()));

        try {

            uploadTransDao.uploadTxLogDetails(uploadLog);

        } catch (Exception ex) {
            log.error(ex + " Error come in uploading file related data into database ", ex);
            // TODO add entry in the exception log
            throw new VendorInvoiceSavedataOnUploadException("Unable to start upload process");

        }

    }

    @Override
    public void saveInUploadStageLog(UploadRequestDTO uploadRequestDTO, UploadReqDTO uploadReqDTO) {

        UploadStageLogDto uploadStageLogDto = new UploadStageLogDto();
        uploadStageLogDto.setUploadLogId(uploadReqDTO.getUploadLogId());
        uploadStageLogDto.setCreatedBy(uploadRequestDTO.getUserId());
        uploadStageLogDto.setBatchNo(uploadReqDTO.getBatchNo());
        uploadStageLogDto.setProcessStage(Constants.PROCESS_STAGE_FILE_UPLOAD);

        uploadStageLogDto.setProcessState(Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED);

        Timestamp createdAt = Timestamp.from(Instant.now());
        uploadStageLogDto.setCreatedAt(createdAt);
        try {

            uploadTransDao.insertStageNState(Constants.PROCESS_STAGE_FILE_UPLOAD,
                            Constants.PROCESS_FILE_UPLOAD_STATUS_COMPLETED, uploadRequestDTO,
                            uploadReqDTO.getBatchNo());

        } catch (Exception ex) {
            log.error(ex + " : " + ex.getMessage());

        }

    }

    @Override
    public int getUploadLogId(String batchNo) throws VendorInvoiceServerException {
        return uploadTransDao.getUploadIdFromDB(batchNo);
    }

}
