package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EWayBillDTO {

    private String taxpayerGstin;
    private String taxpayerPan;
    private String eWayBillNo;
    private String eWayBillDate;
    private String fillingPeriod;
    private String eWayBillValidTill;
    private String vendorGstin;
    private String poNo;
    private String poDate;
    private String udf1;
    private String udf2;
    private String udf3;
    private String udf4;
    private String udf5;
    private String udf6;
    private String udf7;
    private String udf8;
    private String udf9;
    private String udf10;
    private String udf11;
    private String udf12;
    private String udf13;
    private String udf14;
    private String udf15;
    private String udf16;
    private String udf17;
    private String udf18;
    private String udf19;
    private String udf20;
    private String batchNo;
    private StringBuilder errorCodeList = new StringBuilder();
    private StringBuilder errorDiscriptionList = new StringBuilder();
    private String rowVersion;
    private int excelRowId;
    private int isValid;
    private String yearId;
    private String docType;
    private String inwardNo;
    private String inwardDate;
    private int itemCount;
    private String totalInvoiceAmt;
    private String ewbGenOn;
    private String ewbGenBy;
    private String getEWBError;
    private String qrPageNo;

}
