package com.bdo.bvms.invoices.dto;

import java.util.List;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VendorInvoiceRequestDTO extends PageReqDTO {

    // 0 for pan and 1 for GSTIN.
    String gstinOrPan;
    List<String> gstinOrPanList;
    int periodTypeCD;
    String yearOrMonth;
    List<String> yearOrMonthList;
    String tabId;
    String dualRoleId;
    int bookedStatus;
    String actionKey;
    int isActionCenter;
    List<AdvanceFilter> advanceFilter;
    String sortFilter;
    String ocrSubTab;

}
