package com.bdo.bvms.einvoice.service.impl;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.bvms.einvoice.service.CustomTemplateEInvoiceRead;
import com.bdo.bvms.einvoice.service.ServiceCall;
import com.bdo.bvms.einvoice.service.UploadNDownloadFileService;
import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.constant.StringConstant;
import com.bdo.bvms.invoices.constant.ValidationConstants;
import com.bdo.bvms.invoices.custom.exception.InvalidTemplateHeaderException;
import com.bdo.bvms.invoices.custom.exception.ReadInvoiceCustomTemplate;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.CustomTemplateRepo;
import com.bdo.bvms.invoices.dao.EInvoiceDao;
import com.bdo.bvms.invoices.dao.UploadMasterDao;
import com.bdo.bvms.invoices.dao.UploadTransDao;
import com.bdo.bvms.invoices.dto.EInvoiceTemplateDTO;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.UploadReqDTO;
import com.bdo.bvms.invoices.util.AppUtil;
import com.bdo.bvms.invoices.util.CommonUtils;
import com.monitorjbl.xlsx.StreamingReader;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class CustomTemplateEInvoiceReadImpl implements CustomTemplateEInvoiceRead {

    @Value("${temp.folder.path}")
    String tempFolder;

    @Autowired
    CustomTemplateRepo customeTemplateRepo;

    @Autowired
    EInvoiceDao eInvoiceDao;

    @Autowired
    UploadNDownloadFileService uploadNDownloadFileService;

    ServiceCall serviceCall;

    @Autowired
    UploadMasterDao uploadMasterDao;

    @Autowired
    CommonDao daoCommon;

    @Autowired
    UploadTransDao uploadTransDao;

    Row headerRow = null;

    List<EInvoiceTemplateDTO> valid = new ArrayList<>();
    List<EInvoiceTemplateDTO> notValid = new ArrayList<>();
    Set<String> sftpFpMap = new HashSet<>();
    Map<String, Integer> colNameIndexMap = new HashMap<>();
    Map<String, Map<String, String>> invoiceExistInPreFpMap = new HashMap<String, Map<String, String>>();

    @Override
    public List<EInvoiceTemplateDTO> getEinvoiceDataList(UploadReqDTO uploadDTO)
                    throws NumberFormatException, ReadInvoiceCustomTemplate, InvalidTemplateHeaderException {

        String methodName = "getEinvoiceDataList";
        List<EInvoiceTemplateDTO> invoiceList = new ArrayList<>();

        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(uploadDTO.getFileType());

        Map<String, Object> rowCountWithHeader = new HashMap<>();
        Map<String, String> customTemplateHeaderMappings = CommonUtils.getCustomTemplateHeaderMappings(uploadDTO,
                        customeTemplateRepo);
        try {
            try (InputStream inputStream = new FileInputStream(new File(fileName.toString()));
                            BufferedInputStream br = new BufferedInputStream(inputStream)) {
                // getting HeaderRowIndexs , coumnsDataRow ,RowCount
                rowCountWithHeader = getRowCountWithHeader(inputStream, uploadDTO);
            }
        } catch (Exception e2) {
            log.error("Error in getEinvoiceDataList Method ", e2);
            uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();

            String methodName1 = "getExcelEWayDataList";

            exceptionLogDTO.setUserId(uploadDTO.getId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
            exceptionLogDTO.setFunctionName(methodName1);
            exceptionLogDTO.setErrorMessage(e2.getMessage());
            exceptionLogDTO.setErrorCause(Constants.NOTCONTAINPROPERDATA);
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());

            daoCommon.updateExceptionLogTable(exceptionLogDTO);

            throw new ReadInvoiceCustomTemplate(e2.getMessage());
        }

        headerRow = (Row) rowCountWithHeader.get(Constants.DATA_ROW);

        try {
            colNameIndexMap = AppUtil.getColumnNameIndexMap(headerRow);

        } catch (Exception ex) {

            log.error("Exception ", ex, "getEinvoiceDataList method");

            uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(), Constants.UPLOAD_INVOICES_PLD_STATUS_FAIL);

            logIntoToExceptionTable(uploadDTO, ex, methodName);

            throw new ReadInvoiceCustomTemplate(ex.getMessage(), ex.getCause());
        }

        // throw exception and Update in Exception Log table as per Batch Number
        if ((Constants.E_INVOICE_TEMPLATE_COLUMN_COUNT < colNameIndexMap.size())
                        || (colNameIndexMap.size() < Constants.E_INVOICE_TEMPLATE_MENDATORY_COLUMN_COUNT)) {
            uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);

            throw new InvalidTemplateHeaderException(StringConstant.HEADERCOUNTERRORMESSAGE + uploadDTO.getBatchNo());

        }

        try (InputStream in = new FileInputStream(new File(fileName.toString()));
                        BufferedInputStream bis = new BufferedInputStream(in);
                        Workbook workbook = StreamingReader.builder().open(bis);) {

            Sheet sheet = workbook.getSheetAt(0);
            sftpFpMap = new HashSet<>();
            sheet.forEach(row -> {
                EInvoiceTemplateDTO rowObj = new EInvoiceTemplateDTO();
                if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 0) {
                    rowObj.setExcelRowId(row.getRowNum());
                    try {
                        // reading Excel Template
                        rowObj = readTemplateRecord(row, colNameIndexMap, uploadDTO, customTemplateHeaderMappings);
                        rowObj.setValid(true);

                    } catch (Exception e) {
                        log.error("Error generated while reading xls ", e);
                        markErrorNAddErrorCode(rowObj, ValidationConstants.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
                    }
                    if (rowObj.getFillingPeriod().length() == 5) {
                        rowObj.setFillingPeriod(Constants.ZEROVALUE + rowObj.getFillingPeriod());
                    }
                    if (StringUtils.isNotBlank(rowObj.getGstinUinOfRecipient())
                                    && rowObj.getGstinUinOfRecipient().length() == 15) {
                        rowObj.setPanOfRecipient(rowObj.getGstinUinOfRecipient().substring(2, 12));
                    } else {
                        rowObj.setPanOfRecipient("");
                    }
                    if (StringUtils.isNotBlank(rowObj.getFillingPeriod())) {
                        sftpFpMap.add(rowObj.getFillingPeriod());
                    }
                    invoiceList.add(rowObj);
                }
            });

            if ("ftps".equals(uploadDTO.getUplodSource()) || uploadDTO.getFp().isEmpty()) {
                uploadDTO.setFp(new ArrayList<>(sftpFpMap));
                uploadTransDao.updateFpLog(uploadDTO.getFp(), uploadDTO);
            }
        } catch (Exception exception) {
            log.error("Error in getEinvoiceDataList method ", exception);
            throw new ReadInvoiceCustomTemplate("Error in reading Stream from local PC", exception);
        }

        return invoiceList;
    }

    private EInvoiceTemplateDTO readTemplateRecord(Row row, Map<String, Integer> colNameIndexMap,
                    UploadReqDTO uploadDTO, Map<String, String> columnMap) {

        EInvoiceTemplateDTO xlsRow = new EInvoiceTemplateDTO();

        try {

            String customHeaderName = columnMap.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT);

            Integer idxForGstinReceipient = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForGstinReceipient);

            customHeaderName = columnMap.get(Constants.COLUMN_DOC_TYPE);
            Integer idxForDocType = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForDocType);

            if (colNameIndexMap.size() != columnMap.size()) {
                uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),
                                Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);
            }

            customHeaderName = columnMap.get(Constants.COLUMN_INWARD_NO);
            Integer idxForInwarNo = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForInwarNo);

            customHeaderName = columnMap.get(Constants.COLUMN_INWARD_DATE);
            Integer idxForInwardDate = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForInwardDate);

            customHeaderName = columnMap.get(Constants.COLUMN_GSTIN_OF_SUPPLIER);
            Integer idxForGstinSupplier = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForGstinSupplier);

            customHeaderName = columnMap.get(Constants.COLUMN_HSN_CODE);
            Integer idxForHsnCode = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForHsnCode);

            customHeaderName = columnMap.get(Constants.COLUMN_TOTAL_INVOICE_AMOUNT);
            Integer idxForTotalInvoiceValue = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForTotalInvoiceValue);

            customHeaderName = columnMap.get(Constants.COLUMN_PURCHASE_ORDER_NO);
            Integer idxForPoNo = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForPoNo);

            customHeaderName = columnMap.get(Constants.FILLING_PERIOD);
            Integer idxForFillingPeriod = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForFillingPeriod);

            customHeaderName = columnMap.get(Constants.COLUMN_PURCHASE_ORDER_DATE);
            Integer idxForPODate = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForPODate);

            customHeaderName = columnMap.get(Constants.COLUMN_IRN);
            Integer idxForIrnNo = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForIrnNo);

            customHeaderName = columnMap.get(Constants.COLUMN_IRN_DATE);
            Integer idxForIrnDate = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForIrnDate);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_1);
            Integer idxForUdf1 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf1);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_2);
            Integer idxForUdf2 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf2);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_3);
            Integer idxForUdf3 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf3);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_4);
            Integer idxForUdf4 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf4);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_5);
            Integer idxForUdf5 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf5);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_6);
            Integer idxForUdf6 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf6);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_7);
            Integer idxForUdf7 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf7);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_8);
            Integer idxForUdf8 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf8);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_9);
            Integer idxForUdf9 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf9);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_10);
            Integer idxForUdf10 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf10);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_11);
            Integer idxForUdf11 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf11);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_12);
            Integer idxForUdf12 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf12);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_13);
            Integer idxForUdf13 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf13);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_14);
            Integer idxForUdf14 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf14);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_15);
            Integer idxForUdf15 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf15);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_16);
            Integer idxForUdf16 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf16);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_17);
            Integer idxForUdf17 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf17);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_18);
            Integer idxForUdf18 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf18);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_19);
            Integer idxForUdf19 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf19);

            customHeaderName = columnMap.get(Constants.COLUMN_UDF_20);
            Integer idxForUdf20 = colNameIndexMap.get(customHeaderName);
            checkForInvalidTemplate(uploadDTO, customHeaderName, idxForUdf20);

            xlsRow.setGstinUinOfRecipient(AppUtil.getCellValue(row.getCell((idxForGstinReceipient)))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setDocType(AppUtil.getCellValue(row.getCell(idxForDocType)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setInwardNo(AppUtil.getCellValue(row.getCell(idxForInwarNo)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setInwardDate(AppUtil.getCellValue(row.getCell(idxForInwardDate))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setGstinOfSupplier(AppUtil.getCellValue(row.getCell(idxForGstinSupplier))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setMainHSNCode(AppUtil.getCellValue(row.getCell(idxForHsnCode)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setTotalInvoiceValue(AppUtil.getCellValue(row.getCell(idxForTotalInvoiceValue))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setPurchaseOrderNumber(AppUtil.getCellValue(row.getCell(idxForPoNo))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setFillingPeriod(AppUtil.getCellValue(row.getCell(idxForFillingPeriod))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));

            xlsRow.setPurchaseOrderDate(AppUtil.getCellValue(row.getCell(idxForPODate))
                            .replaceAll(Constants.SUBSTRINGREGEX, Constants.SPACE));
            xlsRow.setIrn(AppUtil.getCellValue(row.getCell(idxForIrnNo)).replaceAll("[\n\r]", Constants.SPACE));
            xlsRow.setIrnDate(AppUtil.getCellValue(row.getCell(idxForIrnDate)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));

            xlsRow.setUdf1(AppUtil.getCellValue(row.getCell(idxForUdf1)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf2(AppUtil.getCellValue(row.getCell(idxForUdf2)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf3(AppUtil.getCellValue(row.getCell(idxForUdf3)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf4(AppUtil.getCellValue(row.getCell(idxForUdf4)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf5(AppUtil.getCellValue(row.getCell(idxForUdf5)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf6(AppUtil.getCellValue(row.getCell(idxForUdf6)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf7(AppUtil.getCellValue(row.getCell(idxForUdf7)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf8(AppUtil.getCellValue(row.getCell(idxForUdf8)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf9(AppUtil.getCellValue(row.getCell(idxForUdf9)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf10(AppUtil.getCellValue(row.getCell(idxForUdf10)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf11(AppUtil.getCellValue(row.getCell(idxForUdf11)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf12(AppUtil.getCellValue(row.getCell(idxForUdf12)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf13(AppUtil.getCellValue(row.getCell(idxForUdf13)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf14(AppUtil.getCellValue(row.getCell(idxForUdf14)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf15(AppUtil.getCellValue(row.getCell(idxForUdf15)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf16(AppUtil.getCellValue(row.getCell(idxForUdf16)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf17(AppUtil.getCellValue(row.getCell(idxForUdf17)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf18(AppUtil.getCellValue(row.getCell(idxForUdf18)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf19(AppUtil.getCellValue(row.getCell(idxForUdf19)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));
            xlsRow.setUdf20(AppUtil.getCellValue(row.getCell(idxForUdf20)).replaceAll(Constants.SUBSTRINGREGEX,
                            Constants.SPACE));

        } catch (Exception ex) {
            // Mark as not Valid object if Exception occur
            log.error("Error generated while reading xls ", ex);
            markErrorNAddErrorCode(xlsRow, ValidationConstants.EINVOICE_ERROR_CODE_DE1000, Constants.BLANK);
            ExceptionLogDTO exceptionLogDto = new ExceptionLogDTO();
            exceptionLogDto.setUserId(uploadDTO.getUploadBy());
            exceptionLogDto.setScreenName(Constants.INVOICEINTEGRATION);
            exceptionLogDto.setFunctionName("readTemplateRecord");
            exceptionLogDto.setErrorMessage(ex.getMessage());
            exceptionLogDto.setErrorCause(ex.getCause().getMessage());
            exceptionLogDto.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDto.setCreatedAt(LocalDateTime.now());

            daoCommon.updateExceptionLogTable(exceptionLogDto);

            log.error("Errro occured while reading row " + row.getRowNum() + " for batch No. " + ex);
        }
        return xlsRow;
    }

    private void checkForInvalidTemplate(UploadReqDTO uploadDTO, String customHeaderName,
                    Integer idxForGstinReceipient) {
        if (customHeaderName != null && idxForGstinReceipient == null) {
            uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),
                            Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);
        }

    }

    private void markErrorNAddErrorCode(EInvoiceTemplateDTO rowData, String errorCode, String errorMessage) {

        rowData.setValid(false);
        rowData.setErrorCodeList(rowData.getErrorCodeList().append(errorCode));
        rowData.setErrorDiscriptionList(rowData.getErrorDiscriptionList().append(errorMessage));
    }

    public Map<String, Object> getRowCountWithHeader(InputStream fis, UploadReqDTO uploadDTO)
                    throws IOException, ReadInvoiceCustomTemplate {
        Map<String, Object> dataMap = new HashMap<>();
        String methodName = "getRowCountWithHeader";
        int totalRowCount = 0;
        try (InputStream is = new BufferedInputStream(fis); Workbook workbook = StreamingReader.builder().open(is);) {

            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() > 0) {
                    totalRowCount++;
                } else if (row != null && AppUtil.isNotBlank(row) && row.getRowNum() <= 0 && totalRowCount == 0) {

                    Row coumnsDataRow = null;
                    coumnsDataRow = row;
                    dataMap.put("headerRowIndex", row.getRowNum());
                    dataMap.put("coumnsDataRow", coumnsDataRow);

                }

            }
            dataMap.put("RowCount", totalRowCount);
            return dataMap;
        } catch (Exception ex) {
            log.error("Error in getRowCountWithHeader Method", ex);
            logIntoToExceptionTable(uploadDTO, ex, methodName);
            throw new ReadInvoiceCustomTemplate("Error in getting RowCoutWith Header" + uploadDTO.getBatchNo());

        }

    }

    private void logIntoToExceptionTable(UploadReqDTO uploadDTO, Exception ex, String functionName) {
        ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
        exceptionLogDTO.setUserId(uploadDTO.getId());
        exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
        exceptionLogDTO.setFunctionName(functionName);
        exceptionLogDTO.setErrorMessage(ex.getMessage());
        exceptionLogDTO.setErrorCause(Constants.NOTCONTAINPROPERDATA);
        exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
        exceptionLogDTO.setCreatedAt(LocalDateTime.now());

        daoCommon.updateExceptionLogTable(exceptionLogDTO);
    }

    @Override
    public List<EInvoiceTemplateDTO> getEinvoiceDataListCDV(UploadReqDTO uploadDTO,
                    Map<String, String> customTemplateHeaderMappings, char delimiter)
                    throws VendorInvoiceServerException, FileNotFoundException {
        Iterable<CSVRecord> records = null;
        List<EInvoiceTemplateDTO> vendorUploadStage1List = new ArrayList<>();

        StringBuilder fileName = new StringBuilder().append(tempFolder)
                        .append(System.getProperty(StringConstant.FILESEPARATOR)).append(uploadDTO.getBatchNo())
                        .append(Constants.UNSERSCORE_BASE).append(StringConstant.DOTSEPARATOR)
                        .append(uploadDTO.getFileType());

        File file = new File(fileName.toString());
        Path path = file.toPath();

        Map<String, Integer> columnIndexMap = new HashMap<>();

        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String headerLine = reader.readLine();
            String[] headers = headerLine.split(",");

            Map<String, String> customTemplateMap = new HashMap<>();
            String columnNameNotMatchedWithTemplate = "";
            for (Entry<String, String> map : customTemplateHeaderMappings.entrySet()) {

                byte[] bytes = map.getValue().trim().getBytes();
                String str = new String(bytes, StandardCharsets.UTF_8);

                customTemplateMap.put(str, str);
            }

            for (int cnt = 0; cnt <= headers.length - 1; cnt++) {
                byte[] bytes = headers[cnt].trim().getBytes();
                String str = new String(bytes, StandardCharsets.UTF_8).replaceAll("[^a-zA-Z0-9\\s+_-]", "");
                columnIndexMap.put(str, cnt);
                if (!str.trim().equals(customTemplateMap.get(str))) {
                    if ("".equals(columnNameNotMatchedWithTemplate)) {
                        columnNameNotMatchedWithTemplate = columnNameNotMatchedWithTemplate + headers[cnt];
                    } else {
                        columnNameNotMatchedWithTemplate = columnNameNotMatchedWithTemplate + "," + headers[cnt];
                    }

                }

            }

            if (columnNameNotMatchedWithTemplate.length() > 2) {
                log.error("Uploaded file(s) some columns does not matching with defined template");
                uploadTransDao.updateProcessStatus(uploadDTO.getBatchNo(),
                                Constants.UPLOAD_INVOICES_PLD_STATUS_INVALIDTEMPLATE);
                throw new VendorInvoiceServerException(
                                "Uploaded file(s) some columns does not matching with defined template,column(s) are "
                                                + columnNameNotMatchedWithTemplate);
            }

            records = CSVFormat.DEFAULT.withDelimiter(delimiter).withAllowMissingColumnNames(true).parse(reader);

            sftpFpMap = new HashSet<>();
            for (CSVRecord csvRecord : records) {

                boolean isEmptyRow = true;
                for (String value : csvRecord) {
                    if (!value.trim().isEmpty()) {
                        isEmptyRow = false;
                        break;
                    }
                }

                if (!isEmptyRow) {
                    readCsvRecord(uploadDTO, csvRecord, customTemplateHeaderMappings, vendorUploadStage1List,
                                    columnIndexMap);
                }

            }

        } catch (Exception e) {
            log.error("Error in getEinvoiceDataListCDV method ", e);
            if (e.getMessage().contains("matching with defined template,column(s)")) {
                throw new VendorInvoiceServerException(e.getMessage());
            } else {
                throw new VendorInvoiceServerException("Error while reading custom template for vendor details import ",
                                e);
            }
        } finally {
            records = null;
        }
        if ("ftps".equals(uploadDTO.getUploadType()) || uploadDTO.getFp().isEmpty()) {
            uploadDTO.setFp(new ArrayList<>(sftpFpMap));
            uploadTransDao.updateFpLog(uploadDTO.getFp(), uploadDTO);
        }
        return vendorUploadStage1List;
    }

    private void readCsvRecord(UploadReqDTO uploadDTO, CSVRecord csvRecord, Map<String, String> templateColumnMap,
                    List<EInvoiceTemplateDTO> vendorUploadStage1List, Map<String, Integer> columnIndexMap) {
// standard= key, custom=value
        try {

            if (csvRecord.size() != Constants.E_INVOICE_TEMPLATE_COLUMN_COUNT) {
                // Update uploadStatus Invalida Template
            }

            EInvoiceTemplateDTO vendorUploadStage1 = new EInvoiceTemplateDTO();
            vendorUploadStage1.setValid(true);
            String taxpayerGSTCustomHeaderName = templateColumnMap.get(Constants.COLUMN_GSTIN_UIN_OF_RECIPIENT);

            checkForInvalidTemplate(taxpayerGSTCustomHeaderName);

            String docTypeCustomHeaderName = templateColumnMap.get(Constants.COLUMN_DOC_TYPE);

            // checkForInvalidTemplate(docTypeCustomHeaderName);

            String inwardNoCustomHeaderName = templateColumnMap.get(Constants.COLUMN_INWARD_NO);

            // checkForInvalidTemplate(inwardNoCustomHeaderName);

            String inwardDateCustomHeaderName = templateColumnMap.get(Constants.COLUMN_INWARD_DATE);

            // checkForInvalidTemplate(inwardDateCustomHeaderName);

            String supplierGstinCustomHeaderName = templateColumnMap.get(Constants.COLUMN_GSTIN_OF_SUPPLIER);

            // checkForInvalidTemplate(supplierGstinCustomHeaderName);

            String hsnCodeCustomHeaderName = templateColumnMap.get(Constants.COLUMN_HSN_CODE);

            // checkForInvalidTemplate(hsnCodeCustomHeaderName);

            String totalInvoiceAmountCustomHeaderName = templateColumnMap.get(Constants.COLUMN_TOTAL_INVOICE_AMOUNT);

            // checkForInvalidTemplate(totalInvoiceAmountCustomHeaderName);

            String poNoCustomHeaderName = templateColumnMap.get(Constants.COLUMN_PURCHASE_ORDER_NO);

            // checkForInvalidTemplate(poNoCustomHeaderName);

            String fillingPeriodCustomHeaderName = templateColumnMap.get(Constants.FILLING_PERIOD);

            // checkForInvalidTemplate(inwardNoCustomHeaderName);

            String poDateCustomHeaderName = templateColumnMap.get(Constants.COLUMN_PURCHASE_ORDER_DATE);

            // checkForInvalidTemplate(fillingPeriodCustomHeaderName);

            String irnNoCustomHeaderName = templateColumnMap.get(Constants.COLUMN_IRN);

            // checkForInvalidTemplate(irnNoCustomHeaderName);

            String irnDateCustomHeaderName = templateColumnMap.get(Constants.COLUMN_IRN_DATE);

            // checkForInvalidTemplate(irnDateCustomHeaderName);

            String udf1CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_1);

            // checkForInvalidTemplate(udf1CustomHeaderName);

            String udf2CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_2);

            // checkForInvalidTemplate(udf2CustomHeaderName);

            String udf3CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_3);

            // checkForInvalidTemplate(udf3CustomHeaderName);

            String udf4CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_4);

            // checkForInvalidTemplate(udf4CustomHeaderName);

            String udf5CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_5);

            // checkForInvalidTemplate(udf5CustomHeaderName);

            String udf6CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_6);

            // checkForInvalidTemplate(udf6CustomHeaderName);

            String udf7CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_7);

            // checkForInvalidTemplate(udf7CustomHeaderName);

            String udf8CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_8);

            // checkForInvalidTemplate(udf8CustomHeaderName);

            String udf9CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_9);

            // checkForInvalidTemplate(udf9CustomHeaderName);

            String udf10CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_10);

            // checkForInvalidTemplate(udf10CustomHeaderName);

            String udf11CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_11);

            // checkForInvalidTemplate(udf1CustomHeaderName);

            String udf12CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_12);

            // checkForInvalidTemplate(udf2CustomHeaderName);

            String udf13CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_13);

            // checkForInvalidTemplate(udf3CustomHeaderName);

            String udf14CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_14);

            // checkForInvalidTemplate(udf4CustomHeaderName);

            String udf15CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_15);

            // checkForInvalidTemplate(udf5CustomHeaderName);

            String udf16CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_16);

            // checkForInvalidTemplate(udf6CustomHeaderName);

            String udf17CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_17);

            // checkForInvalidTemplate(udf7CustomHeaderName);

            String udf18CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_18);

            // checkForInvalidTemplate(udf8CustomHeaderName);

            String udf19CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_19);

            // checkForInvalidTemplate(udf9CustomHeaderName);

            String udf20CustomHeaderName = templateColumnMap.get(Constants.COLUMN_UDF_20);

            // checkForInvalidTemplate(udf10CustomHeaderName);

            vendorUploadStage1.setGstinUinOfRecipient(csvRecord.get(columnIndexMap.get(taxpayerGSTCustomHeaderName)));

            vendorUploadStage1.setDocType(csvRecord.get(columnIndexMap.get(docTypeCustomHeaderName)));

            vendorUploadStage1.setInwardNo(csvRecord.get(columnIndexMap.get(inwardNoCustomHeaderName)));

            vendorUploadStage1.setInwardDate(csvRecord.get(columnIndexMap.get(inwardDateCustomHeaderName)));

            vendorUploadStage1.setGstinOfSupplier(csvRecord.get(columnIndexMap.get(supplierGstinCustomHeaderName)));

            vendorUploadStage1.setFillingPeriod(csvRecord.get(columnIndexMap.get(fillingPeriodCustomHeaderName)));

            vendorUploadStage1.setMainHSNCode(csvRecord.get(columnIndexMap.get(hsnCodeCustomHeaderName)));

            vendorUploadStage1.setTotalInvoiceValue(
                            csvRecord.get(columnIndexMap.get(totalInvoiceAmountCustomHeaderName)));

            vendorUploadStage1.setPurchaseOrderDate(csvRecord.get(columnIndexMap.get(poDateCustomHeaderName)));

            vendorUploadStage1.setPurchaseOrderNumber(csvRecord.get(columnIndexMap.get(poNoCustomHeaderName)));

            vendorUploadStage1.setIrn(csvRecord.get(columnIndexMap.get(irnNoCustomHeaderName)));

            vendorUploadStage1.setIrnDate(csvRecord.get(columnIndexMap.get(irnDateCustomHeaderName)));

            vendorUploadStage1.setUdf1(csvRecord.get(columnIndexMap.get(udf1CustomHeaderName)));

            vendorUploadStage1.setUdf2(csvRecord.get(columnIndexMap.get(udf2CustomHeaderName)));

            vendorUploadStage1.setUdf3(csvRecord.get(columnIndexMap.get(udf3CustomHeaderName)));

            vendorUploadStage1.setUdf4(csvRecord.get(columnIndexMap.get(udf4CustomHeaderName)));

            vendorUploadStage1.setUdf5(csvRecord.get(columnIndexMap.get(udf5CustomHeaderName)));
            vendorUploadStage1.setUdf6(csvRecord.get(columnIndexMap.get(udf6CustomHeaderName)));

            vendorUploadStage1.setUdf7(csvRecord.get(columnIndexMap.get(udf7CustomHeaderName)));

            vendorUploadStage1.setUdf8(csvRecord.get(columnIndexMap.get(udf8CustomHeaderName)));

            vendorUploadStage1.setUdf9(csvRecord.get(columnIndexMap.get(udf9CustomHeaderName)));

            vendorUploadStage1.setUdf10(csvRecord.get(columnIndexMap.get(udf10CustomHeaderName)));

            vendorUploadStage1.setUdf11(csvRecord.get(columnIndexMap.get(udf11CustomHeaderName)));

            vendorUploadStage1.setUdf12(csvRecord.get(columnIndexMap.get(udf12CustomHeaderName)));

            vendorUploadStage1.setUdf13(csvRecord.get(columnIndexMap.get(udf13CustomHeaderName)));

            vendorUploadStage1.setUdf14(csvRecord.get(columnIndexMap.get(udf14CustomHeaderName)));

            vendorUploadStage1.setUdf15(csvRecord.get(columnIndexMap.get(udf15CustomHeaderName)));
            vendorUploadStage1.setUdf16(csvRecord.get(columnIndexMap.get(udf16CustomHeaderName)));

            vendorUploadStage1.setUdf17(csvRecord.get(columnIndexMap.get(udf17CustomHeaderName)));

            vendorUploadStage1.setUdf18(csvRecord.get(columnIndexMap.get(udf18CustomHeaderName)));

            vendorUploadStage1.setUdf19(csvRecord.get(columnIndexMap.get(udf19CustomHeaderName)));

            vendorUploadStage1.setUdf20(csvRecord.get(columnIndexMap.get(udf20CustomHeaderName)));

            if (vendorUploadStage1.getFillingPeriod().length() == 5) {
                vendorUploadStage1.setFillingPeriod(Constants.ZEROVALUE + vendorUploadStage1.getFillingPeriod());
            }
            if (StringUtils.isNotBlank(vendorUploadStage1.getGstinUinOfRecipient())
                            && vendorUploadStage1.getGstinUinOfRecipient().length() == 15) {
                vendorUploadStage1.setPanOfRecipient(vendorUploadStage1.getGstinUinOfRecipient().substring(2, 12));
            } else {
                vendorUploadStage1.setPanOfRecipient("");
            }
            if (StringUtils.isNotBlank(vendorUploadStage1.getFillingPeriod())) {
                sftpFpMap.add(vendorUploadStage1.getFillingPeriod());
            }

            vendorUploadStage1List.add(vendorUploadStage1);

        } catch (IllegalStateException | IllegalArgumentException e) {
            //
            log.error(" Error in readCsvRecord Method getting CSV data", e);

        }

    }

    private String getValue(CSVRecord csvRecord, String customHeaderName) {

        return csvRecord.get(customHeaderName.replaceAll("[^\\x00-\\x7F]", ""));

    }

    private void checkForInvalidTemplate(String customHeaderName) {
        byte[] bytes = customHeaderName.getBytes(StandardCharsets.UTF_8);
        customHeaderName = new String(bytes, StandardCharsets.UTF_8);

    }

}
