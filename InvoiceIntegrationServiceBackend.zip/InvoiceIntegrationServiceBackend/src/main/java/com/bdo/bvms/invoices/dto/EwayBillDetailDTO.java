package com.bdo.bvms.invoices.dto;

import org.springframework.data.relational.core.mapping.Column;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EwayBillDetailDTO {

    @Column(value = "gstin_uin_of_recipient")
    String taxpayerGstin;

    @Column(value = "gstin_of_supplier")
    String vendorGstin;

    @Column(value = "title")
    String title;

    @Column(value = "e_way_bill_no")
    String ewbNo;

    @Column(value = "e_way_bill_date")
    String ewbDate;

    @Column(value = "bill_valid_date")
    String validTill;

    @Column(value = "batch_no")
    String batchNo;

    @Column(value = "generated_on")
    String generatedOn;

    @Column(value = "generated_by")
    String generatedBy;

}