package com.bdo.bvms.ocr.dto;


import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class LineItems {
	
	@JsonProperty("qty")
	String qty;
	@JsonProperty("price")
	String price;
	@JsonProperty("description")
	String description;

}
