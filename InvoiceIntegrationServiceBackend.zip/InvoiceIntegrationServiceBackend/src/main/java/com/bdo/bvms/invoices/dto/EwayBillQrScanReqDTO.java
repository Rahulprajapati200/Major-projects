package com.bdo.bvms.invoices.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EwayBillQrScanReqDTO {

    private String EwbNo;
    private String EwbDt;
    private String Gen_By;
}
