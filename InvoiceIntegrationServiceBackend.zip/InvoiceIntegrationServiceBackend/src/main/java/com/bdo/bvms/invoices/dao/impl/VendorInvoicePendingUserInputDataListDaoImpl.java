package com.bdo.bvms.invoices.dao.impl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bdo.bvms.invoices.constant.Constants;
import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dao.CommonDao;
import com.bdo.bvms.invoices.dao.VendorInvoicePendingUserInputDataListDao;
import com.bdo.bvms.invoices.dao.VendorInvoiceSyncDataListDao;
import com.bdo.bvms.invoices.dto.ExceptionLogDTO;
import com.bdo.bvms.invoices.dto.PendingForUserInputResDTO;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;
import com.bdo.bvms.invoices.util.CommonUtils;
import com.bdo.bvms.invoices.util.NumberUtils;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class VendorInvoicePendingUserInputDataListDaoImpl implements VendorInvoicePendingUserInputDataListDao {

    @Autowired
    VendorInvoiceSyncDataListDao vendorInvoiceSyncDataListDao;

    @Autowired
    CommonDao commonDao;

    @Autowired
    JdbcTemplate jdbcTemplateTrn;

    @Override
    public List<PendingForUserInputResDTO> getInvoicePendingUserInputDataList(
                    VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList, String monthList)
                    throws VendorInvoiceServerException {
        try {
            Map<String, String> screenAliasMap = commonDao.getSchreeAliasMap(vendorInvoiceRequestDTO);
            String whereCondition = CommonUtils.getWhereCondition(vendorInvoiceRequestDTO.getAdvanceFilter(),
                            screenAliasMap);
            Map<String, Object> out = commonDao.getGridDataPendingForUserInput(vendorInvoiceRequestDTO, gstinNewList,
                            monthList, whereCondition);
            List<PendingForUserInputResDTO> dataResList = new ArrayList<>();
            List<Map<String, Object>> results = (List<Map<String, Object>>) out.get("#result-set-" + 1);
            if (results.isEmpty()) {
                return dataResList;
            }
            results.forEach(u -> {

                PendingForUserInputResDTO dataRes = new PendingForUserInputResDTO();
                dataRes.setId(Integer.valueOf(u.get("id").toString()));
                dataRes.setTaxpayerPan(checkNullValue((String) u.get("taxpayer_pan")));
                dataRes.setTaxpayerGstin(checkNullValue((String) u.get("taxpayer_gstin")));
                dataRes.setVendorPan(checkNullValue((String) u.get("vendor_pan")));
                dataRes.setVendorGstin(checkNullValue((String) u.get("vendor_gstin")));
                dataRes.setVendorLegalName(checkNullValue((String) u.get("vendor_legal_name")));
                dataRes.setVendorTradeName(checkNullValue((String) u.get("vendor_trade_name")));
                dataRes.setInvoiceNo(checkNullValue((String) u.get("invoice_no")));
                dataRes.setInvoiceDate(checkNullValue((String) u.get("invoice_date")));
                dataRes.setSyncWithEwayBill((String) u.get("sync_with_eway_bill"));
                dataRes.setSyncWithGstr2a((String) u.get("sync_with_gstr2a"));
                dataRes.setSyncWithGstr2b((String) u.get("sync_with_gstr2b"));
                dataRes.setTaxableValue(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("taxable_value")));
                dataRes.setIgst(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("igst")));
                dataRes.setSgst(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("sgst")));
                dataRes.setCgst(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("cgst")));
                dataRes.setCess(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("cess")));
                dataRes.setInvoiceValue(NumberUtils.getFormattedGrouppedNumber((BigDecimal) u.get("invoice_value")));
                dataRes.setQrCodeValid(String.valueOf(u.get("qr_code_valid")));
                dataRes.setEwayBillNo(checkNullValue((String) u.get("eway_bill_no")));
                dataRes.setEwayBillDate(checkNullValue((String) u.get("eway_bill_date")));
                dataRes.setPoNumber(checkNullValue((String) u.get("po_number")));
                dataRes.setGrnNumber(checkNullValue((String) u.get("grn_no")));
                dataRes.setBatchNo(checkNullValue((String) u.get("batch_no")));
                dataRes.setUploadDate((LocalDateTime) u.get("details_upload_date"));
                dataRes.setLastSyncDate(checkNullValue((String) u.get("last_synced_date")));
                dataRes.setSyncStatus(String.valueOf(u.get("sync_status")));
                dataRes.setBookedErp(0);
                dataRes.setGetType(checkNullValue((String) u.get("pld_get_type")));
                dataRes.setFileType(checkNullValue((String) u.get("file_type")));
                dataRes.setSupplyType(checkNullValue((String) u.get("category")));
                dataRes.setDocType(checkNullValue((String) u.get("doc_type")));
                dataRes.setFp(checkNullValue((String) u.get("return_period")));
                dataRes.setVendorCodeErp(checkNullValue((String) u.get("vendor_code_erp")));
                dataRes.setTotalCount(Integer.valueOf(u.get("total_count").toString()));
                dataResList.add(dataRes);

            });

            return dataResList;
        } catch (DataAccessException e) {
            log.info("Error coming at the time of getting data from database in pending for user input tab.",
                            e.getCause());
            ExceptionLogDTO exceptionLogDTO = new ExceptionLogDTO();
            exceptionLogDTO.setUserId(vendorInvoiceRequestDTO.getUserId());
            exceptionLogDTO.setScreenName(Constants.INVOICEINTEGRATION);
            exceptionLogDTO.setFunctionName("getInvoicePendingUserInputDataList");
            exceptionLogDTO.setErrorMessage(e.getMessage());
            exceptionLogDTO.setErrorCause("Some error in constants.");
            exceptionLogDTO.setLineNo(new Throwable().getStackTrace()[0].getLineNumber());
            exceptionLogDTO.setCreatedAt(LocalDateTime.now());
            // Add exception into exception log table if an exception is coming
            // in this function to getting data from database.
            commonDao.updateExceptionLogTable(exceptionLogDTO);
            throw new VendorInvoiceServerException(
                            "Error coming at the time of getting data from database in pending for user input tab.",
                            e.getCause());

        }

    }

    private static String checkNullValue(String value) {
        if (StringUtils.isEmpty(value)) {
            return "-";
        } else {
            return value;
        }
    }

}
