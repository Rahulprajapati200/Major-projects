package com.bdo.bvms.invoices.util;

import java.text.DecimalFormat;

public class NumberUtils {

    NumberUtils() {

    }

    public static String getFormattedGrouppedNumber(java.math.BigDecimal bigDecimal) {
        if (bigDecimal == null) {
            return "0.0";
        }
        DecimalFormat df = new DecimalFormat("###,###,##0.00");
        return df.format(bigDecimal);
    }
    
    public static String getFormattedGrouppedNumber(Double bigDecimal) {
        if (bigDecimal == null) {
            return "0.0";
        }
        DecimalFormat df = new DecimalFormat("0.###");
        return df.format(bigDecimal);
    }

}
