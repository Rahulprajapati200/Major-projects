package com.bdo.bvms.invoices.dto;

import java.math.BigDecimal;

import org.springframework.data.relational.core.mapping.Column;

import com.bdo.bvms.invoices.util.NumberUtils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EInvoiceDTO {

    @Column(value = "gstin_uin_of_recipient")
    String taxpayerGstin;

    @Column(value = "gstin_of_supplier")
    String vendorGstin;

    @Column(value = "title")
    String title;

    @Column(value = "irn")
    String irnNo;

    @Column(value = "irn_date")
    String irnDate;

    @Column(value = "doc_date")
    String docDate;

    @Column(value = "total_invoice_amt")
    String totalInvoiceValue = "0.0";

    @Column(value = "inward_no")
    String invoiceNo;

    @Column(value = "inv_date")
    String invoiceDate;

    @Column(value = "doc_type")
    String docType;

    String companyLegalName;
    String companyTradeName;
    @Column(value = "item_count")
    int noOfLIneItem;

    @Column(value = "hsn_code")
    String hsnCode;

    @Column(value = "batch_no")
    String batchNo;
    
    @Column(value = "irn_status")
    Integer irnStatus;

    public void setTotalInvoiceValue(BigDecimal value) {
        this.totalInvoiceValue = NumberUtils.getFormattedGrouppedNumber(value);
    }
}
