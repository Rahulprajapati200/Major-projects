package com.bdo.bvms.ewaybill.api.dto;

public class EntityMasterTaxpayerGstin {

    String taxpayerGstin;
    String ewbUsername;
    String ewbPassword;
}
