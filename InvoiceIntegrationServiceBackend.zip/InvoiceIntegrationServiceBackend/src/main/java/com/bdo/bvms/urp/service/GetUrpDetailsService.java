package com.bdo.bvms.urp.service;

import java.util.Map;

import com.bdo.bvms.invoices.custom.exception.VendorInvoiceServerException;
import com.bdo.bvms.invoices.dto.VendorInvoiceRequestDTO;

public interface GetUrpDetailsService {

	Map<String, Object> getUrpDetailsDataGrid(VendorInvoiceRequestDTO vendorInvoiceRequestDTO, String gstinNewList,
			String monthList) throws VendorInvoiceServerException;

}
