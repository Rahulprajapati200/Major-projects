package com.bdo.bvms.ewaybill.api;

import java.util.Map;

public interface EwayBillApi {
	
	public int updateSessionExpiryOfBDO(String clientid,String clientSecretKeyEncrypted);
	
	public int updateSessionExpiryOfNIC(String clientid,String clientSecretKeyEncrypted);
	
	public Map<String,String> bdoEWBAPIAuthenticate(String clientid,String clientSecretKeyEncrypted); 
	
	public String ewbGSPAPIAuthenticate(String clientIdt,String clientSecret,String bdoAuthToken,String taxPayerGSTN); 
	
}
